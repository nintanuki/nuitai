"""Where the 256 by 224 picture sits in the window, and how it is enlarged.

Fullscreen shows the picture at the 4:3 shape a Super Nintendo had on a
TV (pixels a bit wider than tall, 8:7), as big as the screen allows, with
black bars only where the screen is wider or taller than 4:3. It is
enlarged "sharp bilinear" (Frankie, 10/30): first by the biggest whole
number that fits, with no smoothing, so every pixel is an even block;
then the rest of the way smoothly, so the blocks line up with the screen
without any row or column coming out thicker than the others.
"""

import pygame

from settings import ScreenSettings

TV_WIDTH = 4
TV_HEIGHT = 3


def tv_size(window_w: int, window_h: int) -> tuple[int, int]:
    """The largest 4:3 picture that fits a window of this size."""
    width = min(window_w, window_h * TV_WIDTH // TV_HEIGHT)
    return width, width * TV_HEIGHT // TV_WIDTH


def view_rect(window_w: int, window_h: int) -> pygame.Rect:
    """The 4:3 picture, centred in the window."""
    width, height = tv_size(window_w, window_h)
    return pygame.Rect((window_w - width) // 2, (window_h - height) // 2, width, height)


def whole_factor(view_w: int, view_h: int) -> int:
    """The biggest whole number the 256 by 224 picture can be enlarged by
    and still fit inside the view; at least 1."""
    width, height = ScreenSettings.RESOLUTION
    return max(1, min(view_w // width, view_h // height))


def enlarge(source: pygame.Surface, view: pygame.Rect, out: pygame.Surface, stage: pygame.Surface | None):
    """Draw ``source`` onto ``out`` filling ``view``, sharp bilinear.

    ``stage`` is the whole-number step, made once per view by
    ``make_stage`` and reused every frame. Returns nothing.
    """
    target = out.subsurface(view)
    if stage is None:
        pygame.transform.scale(source, view.size, target)
        return
    pygame.transform.scale(source, stage.get_size(), stage)
    pygame.transform.smoothscale(stage, view.size, target)


def make_stage(view: pygame.Rect, like: pygame.Surface) -> pygame.Surface | None:
    """The reusable surface for the whole-number step, or None when the
    view is already a whole-number size (nothing smooth is needed)."""
    width, height = ScreenSettings.RESOLUTION
    k = whole_factor(*view.size)
    if (width * k, height * k) == view.size:
        return None
    return pygame.Surface((width * k, height * k), 0, like)


def to_game(pos: tuple[int, int], view: pygame.Rect) -> tuple[int, int]:
    """A window point as a point on the 256 by 224 game screen."""
    width, height = ScreenSettings.RESOLUTION
    return ((pos[0] - view.x) * width // view.w, (pos[1] - view.y) * height // view.h)
