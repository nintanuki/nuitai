"""The Workshop's story bar: which moment of the story the map shows (Frankie, 11/5).

The main story always runs in one order, so it is a slider: ``MOMENTS``
below, each with every party flag set by then, who is in the party and
the checkpoint Play starts from. Everything else the game remembers is a
switch, a checkbox each (``SWITCHES``): whether Melia was found, whether
Maika joined, and so on. The map then shows the room as it is at that
moment with those switches: anyone not there is hidden, by the game's own
rule (``core/world.py``'s ``person_here``), and a person's Edit Dialogue
shows only the lines they say then (``branch``).

No pygame and no tkinter in here, so the tests can ask it things. The
map's bar (``StoryBar`` in ``workshop.py``) and the dialogue window's
slider (``workshop_dialogue.py``) share one ``Story``, so moving either
moves both.
"""

from __future__ import annotations

from typing import Callable

from core.world import first_form_on, person_here
from settings import StorySettings

# The main story, in order. ``flags`` are those the moment adds to every one before it;
# ``joined`` who is in the party; ``checkpoint`` the one Play starts from (else the
# nearest one before). Names in Frankie's plain words (Claude's split of the story, 11/5).
_BOSS = "field_boss:farm_field:great_boar"
MOMENTS: tuple[dict, ...] = (
    {"name": "The opening", "flags": (), "joined": ("kailo", "hina"), "checkpoint": None},
    {"name": "Taro patch over", "flags": (StorySettings.TARO_FLAG, "beaten:Wild Boar"),
     "joined": ("kailo",), "checkpoint": "after_taro_patch"},
    {"name": "Hina joined", "flags": (StorySettings.HOME_FLAG,), "joined": ("kailo", "hina"),
     "checkpoint": "hina_joined"},
    {"name": "Boar beaten", "flags": (StorySettings.BOAR_BEATEN_FLAG, "beaten:Tandayag na Opon", _BOSS),
     "joined": ("kailo", "hina")},
    # Giving her the tusk means she was found and went home first.
    {"name": "Tusk given", "flags": ("found_melia", "melia_home", StorySettings.TUSK_FLAG),
     "joined": ("kailo", "hina")},
    {"name": "Night", "flags": (StorySettings.NIGHT_FLAG,), "joined": ("kailo", "hina"), "checkpoint": "night"},
    {"name": "After the jump", "flags": (StorySettings.AFTER_JUMP_FLAG,), "joined": ("kailo", "hina")},
    {"name": "Boat ready", "flags": (StorySettings.BOAT_ASKED, StorySettings.BOAT_WOOD_FLAG,
                                     StorySettings.BOAT_FIXED), "joined": ("kailo", "hina")},
)

# The switches: flag, plain name, and whose it is (the bar colors each group alike).
SWITCHES: tuple[tuple[str, str, str], ...] = (
    ("found_melia", "Melia found", "melia"),
    ("melia_home", "Melia went home", "melia"),
    ("melia_asked_dad", "Melia asked about Dad", "melia"),
    (StorySettings.SEED_FLAG, "Hina learned Seed", "hina"),
    ("met_maika", "Met Maika", "maika"),
    (StorySettings.JOINER_JOINS, "Maika joined", "maika"),
    (StorySettings.JOINER_JOINS_LATE, "Maika joined late", "maika"),
    (StorySettings.SISTER_DEAL_FLAG, "Sister's deal", "maika"),
    (StorySettings.JOINER_ASKED_FLAG, "Maika said don't tell", "maika"),
    (StorySettings.SISTER_LIED_FLAG, "Lied to his sister", "maika"),
    (StorySettings.SISTER_TOLD_FLAG, "Told his sister", "maika"),
    (StorySettings.STEW_LOST_FLAG, "Stew lost", "village"),
    ("tutori_met", "Met Tutori", "village"),
    ("ama_talked", "Talked to Ama", "village"),
)
# The switches that put someone in the party.
JOINS = {StorySettings.JOINER_JOINS: "maika", StorySettings.JOINER_JOINS_LATE: "maika"}


def moment_flags(index: int) -> set[str]:
    """Every flag set by moment ``index``: its own and every one's before it."""
    flags: set[str] = set()
    for moment in MOMENTS[: index + 1]:
        flags.update(moment["flags"])
    return flags


def found_switches(rooms: dict[str, list[dict]]) -> list[tuple[str, str, str]]:
    """``SWITCHES``, plus any flag a person in ``rooms`` waits on that neither the
    main story nor ``SWITCHES`` knows, under its own name, so a new one is never missing."""
    known = {flag for flag, _name, _group in SWITCHES} | moment_flags(len(MOMENTS) - 1)
    extra: list[str] = []

    def note(flag) -> None:
        if isinstance(flag, str) and flag not in known and flag not in extra:
            extra.append(flag)

    def walk(lines) -> None:
        for line in lines or []:
            if isinstance(line, dict):
                note(line.get("once"))

    for people in rooms.values():
        for person in people:
            for key in ("after", "until", "gone"):
                note(person.get(key))
            for flag in person.get("flag_lines") or {}:
                note(flag)
            if person.get("first"):
                note(person["first"].get("flag"))
            walk(person.get("lines"))
            walk(person.get("night_lines"))
            for lines in (person.get("flag_lines") or {}).values():
                walk(lines)
    return [*SWITCHES, *((flag, flag, "other") for flag in sorted(extra))]


class Story:
    """Where the story bar stands: a moment and the switches that are on."""

    def __init__(self, switches: list[tuple[str, str, str]] | None = None) -> None:
        self.moment = 0
        self.on: set[str] = set()
        self.switches = list(switches if switches is not None else SWITCHES)
        self._listeners: list[Callable[[], None]] = []

    # --- changing it -------------------------------------------------------------

    def listen(self, call: Callable[[], None]) -> None:
        """Call ``call`` whenever the moment or a switch changes (the dialogue window)."""
        self._listeners.append(call)

    def forget(self, call: Callable[[], None]) -> None:
        if call in self._listeners:
            self._listeners.remove(call)

    def _changed(self) -> None:
        for call in list(self._listeners):
            call()

    def set_moment(self, index: int) -> None:
        index = max(0, min(len(MOMENTS) - 1, index))
        if index != self.moment:
            self.moment = index
            self._changed()

    def next_moment(self) -> None:
        """C: the next moment, round to the opening after the last."""
        self.moment = (self.moment + 1) % len(MOMENTS)
        self._changed()

    def toggle(self, flag: str) -> bool:
        """Turn a switch on or off; False for one the moment already sets (it stays on)."""
        if self.locked(flag):
            return False
        self.on ^= {flag}
        self._changed()
        return True

    # --- reading it --------------------------------------------------------------

    @property
    def name(self) -> str:
        return MOMENTS[self.moment]["name"]

    def locked(self, flag: str) -> bool:
        """Whether the main story has already set ``flag`` by this moment."""
        return flag in moment_flags(self.moment)

    def is_on(self, flag: str) -> bool:
        return flag in self.on or self.locked(flag)

    def flags(self) -> dict[str, bool]:
        return {flag: True for flag in moment_flags(self.moment) | self.on}

    def night(self) -> bool:
        """The game's ``is_night``: the night flag, until the morning after the jump."""
        flags = self.flags()
        return bool(flags.get(StorySettings.NIGHT_FLAG)) and not flags.get(StorySettings.AFTER_JUMP_FLAG)

    def joined(self) -> set[str]:
        members = set(MOMENTS[self.moment]["joined"])
        members |= {member for flag, member in JOINS.items() if flag in self.on}
        if StorySettings.JOINER_LEAVES in self.on:
            members.discard("maika")
        return members

    def checkpoint(self) -> str | None:
        """The checkpoint Play starts from: this moment's, else the nearest one before it;
        with Maika joined before the night, the one where he has (Frankie's checkpoints)."""
        if self.moment >= 2 and not self.night() and self.moment < 6 and self.is_on(StorySettings.JOINER_JOINS):
            return "maika_joined"
        for moment in reversed(MOMENTS[: self.moment + 1]):
            if moment.get("checkpoint"):
                return moment["checkpoint"]
        return None

    def shows_person(self, room: str, person: dict) -> bool:
        return person_here(person, room, self.flags(), self.joined(), self.night())

    def shows_monster(self, room: str, spot: dict) -> bool:
        """A beaten boss is gone; a ``night`` monster walks only at night (as ``_place_monsters``)."""
        if spot.get("boss") and self.flags().get(f"field_boss:{room}:{spot['kind']}"):
            return False
        return not spot.get("night") or self.night()

    def shows_building(self, building: dict) -> bool:
        return self.night() or not building.get("night")

    def branch(self, person: dict) -> list[tuple[str, str]]:
        """Which of ``person``'s fields they say at this moment, as (field, heading):
        the field names of ``core/dialogue_text`` (``lines``, ``flag_lines.FLAG``,
        ``night_lines``, ``first.talk``, ``first.lines``). Picked as the field does
        (``_say_lines``, ``_talk_at_night``, ``World._visit_form``)."""
        flags, night = self.flags(), self.night()
        if first_form_on(person, flags, night):
            out = [("first.talk", "First visit, the scene")]
            if person["first"].get("lines"):
                out.append(("first.lines", "First visit, after the scene"))
            return out
        if night and (person.get("night") or person.get("night_lines")):
            return [("night_lines", "At night")]
        for flag in person.get("flag_lines") or {}:
            if flags.get(flag):
                return [(f"flag_lines.{flag}", f"Once {self.switch_name(flag)}")]
        return [("lines", "What they say")]

    def switch_name(self, flag: str) -> str:
        """A flag in plain words: its switch's name, or the moment that sets it."""
        for key, name, _group in self.switches:
            if key == flag:
                return name.lower()
        for moment in MOMENTS:
            if flag in moment["flags"]:
                return moment["name"].lower()
        return flag
