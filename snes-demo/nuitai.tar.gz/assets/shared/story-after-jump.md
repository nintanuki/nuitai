# After the jump

The first scene after the demo, right where the wake ends: Kailo has jumped off the pier after the
black sails. The pygame game reads this file (`core/story.py`); the website's demo still stops at
TO BE CONTINUED, and the desktop game plays this instead (`StorySettings.DEMO_ONLY`). The rules
for writing a script are at the top of `story.md`.

What happens is Frankie's (10/31, `game/answers.md`, "Right after the demo"): Ama pulls Kailo out
of the water onto his own boat as he is about to drown from exhaustion; Kailo tells him they took
Melia and tries to jump back in; Ama teaches him patience. Kailo saw a red lotus on the sails, and
Ama goes cold: Kirasame Ren's flag, the Killer Shark, and he is puzzled why she is this far out. He
sends them to the chief. In the chief's hut the villagers worry ("first zombies, then pirates?"),
and they work out the ship went south. Hina goes, south anyway; Maika offers if he came along;
Tawiri is going home, south too. Keo wants to come; Kailo says no, but remembers Melia ran off
after he kept brushing her off, so he encourages Keo while making sure he stays. Noelani will look
after everyone. Ama can fix the boat but needs wood.

Every line below is Claude's draft (10/31), for Frankie to rewrite; the boat scene at the top and
Tawiri's ghosts are Claude's drafts of 11/2. Ama's boat is not drawn yet, so the rescue is words on
black, and the harbor beach opens when the boat lands: Kailo on the sand, Ama over him, dripping.

On the map the actors are named for their walk sheets: OldMan is Ama, Master the chief, Cousin
Noelani, LittleBoy Keo, FighterRed and FighterWhite two villagers.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Tawiri**: Ata, art/portraits/tawiri-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png

## Scene

**Place:** The harbor at Kulāiwi, the same night
**Background:** art/wiki/location/mala-iki-islands-2.webp
**Music:** calm-bay.mp3
**Card:** Kailo went into the sea after them. Someone pulled him out.

Cold water, then nothing.

Something hooks under his arms and hauls. Wet boards. A deck rocking under him.

**Ama:** There you are. Cough it up, boy. That's it.

**Kailo:** Melia... They took her!

Kailo throws a leg over the side. A hand catches his belt.

**Ama:** Sit down.

**Kailo:** Let go! They're getting away!

**Ama:** They are. And you'll swim after a ship? You were going under when I got to you. Another minute and I'd have pulled out a body, not a boy.

**Kailo:** I can't just sit here!

**Ama:** You can, and you will. Your dad was the same. Jump first, think after. You can't save her if you drown. And you won't catch that ship by swimming.

The sails are a smudge on the dark water already. Kailo's hands shake on the rail. After a while, he sits.

**Ama:** Good. Now tell me what you saw. All of it.

**Kailo:** Her tusk was on the sand. Then her sling, with the stone gone. Boot prints, two men. Then she screamed.

**Kailo:** There was a ship out past the reef. Black sails.

**Ama:** Was there a mark on them? Anything?

**Wait:** 1

**Kailo:** ...A flower. A red one. A lotus, I think.

**Ama:** ...?!

**Ama:** A red lotus. On black. Are you sure?

**Kailo:** Why would I lie?

**Ama:** You wouldn't. That's what I don't like.

**Ama:** That's Kirasame Ren's flag. The Killer Shark.

**Ama:** She hunts the big trade routes, far from here. There's nothing out this way worth her time. So why come all this way?

**Wait:** 1.5

**Kailo:** Maybe she got lost.

**Ama:** The Killer Shark doesn't get lost.

**Wait:** 1

**Ama:** ...Hm. Something's been scratching at me since this morning.

**Ama:** A stranger came down this harbor today, in boots, asking after a girl. I thought nothing of it.

**Kailo:** They came looking for her.

**Ama:** Then we're going in. The chief needs to hear this.

Ama takes the oar. The lantern at the harbor gets bigger.

**Fade:** out

**Room:** harbor
**Stand:** Kailo at 6,5 facing up; OldMan at 7,5 facing left; Hina at 10,4 facing left; Tawiri at 11,4 facing left
**Stand** (if maika along): Maika at 11,5 facing left
**Fall:** Kailo
**Wait:** 1
**Fade:** in
**Wait:** 1.5

**Stand:** Kailo at 6,5 facing right

**Hina:** Kailo! You could have drowned!

**Kailo:** Ama says I almost did.

**Ama:** A near thing. All of you, to the chief's hut. I'll say it once.

**Run:** Kailo to 6,4 to 13,4 to the east edge; Hina to 13,4 to the east edge; Tawiri to the east edge
**Run** (if maika along): Maika to 13,5 to the east edge
**Fade:** out
**Room:** chief_house
**Stand:** Master at 8,7 facing down; Kailo at 7,10 facing up; Hina at 6,10 facing up; Tawiri at 9,10 facing up; OldMan at 11,9 facing left; Cousin at 3,10 facing right; LittleBoy at 4,10 facing up; FighterRed at 12,10 facing left; FighterWhite at 13,9 facing left
**Stand** (if maika along): Maika at 5,10 facing up
**Fade:** in
**Wait:** 1

**Villager:** First zombies, then pirates? What's next, the volcano?

**Turn:** FighterWhite to FighterRed

**Villager:** Nobody comes out this far. There's nothing here to take.

**Chief Ulu:** Enough. Kailo. Tell me what you saw.

**Kailo:** Black sails, out past the reef. They wrecked the Meialana so nobody could follow. They took Melia.

**Chief Ulu:** Which way did they go?

**Ama:** The tide was going out, and the wind's blowing from the north tonight. A ship that wants to get away fast goes where the wind pushes it.

**Tawiri:** Then they went with it. South.

**Chief Ulu:** South. Toward Lanuloa.

**Turn:** Hina to Kailo

**Hina:** I was leaving in the morning anyway, and my road goes south. I'm coming with you.

**Kailo:** Hina, your pilgrimage...

**Hina:** Will still be there. Melia might not be.

**Turn** (if maika along): Maika to Kailo

**Maika** (if maika along): A wise man knows when he is needed. Also, south is a long way from my sister.

**Hina** (if maika along): There it is.

**Turn:** Tawiri to Kailo

**Tawiri:** I'm going home, and home is south. You'll want someone along who has dead friends. They fight for me, and they work cheap.

**Tawiri:** Pirates are a superstitious lot, you know. Show one a ghost and he forgets which end of the sword to hold. I haven't scared the pants off anybody in years. I'm looking forward to it.

**Kailo:** Thank you. All of you.

**Run:** LittleBoy to 4,9 to 6,9
**Turn:** Kailo, Hina to LittleBoy

**Keo:** I'm coming too! I'm not little! I can fight!

**Kailo:** No, Keo. You're staying.

**Keo:** You always say that!

**Wait:** 1.5

**Kailo:** ...

**Kailo:** I said that to Melia too. All day. Then she went off on her own.

**Turn:** Kailo to LittleBoy

**Kailo:** Listen. While I'm gone, you're the man of the house. Noelani needs you here. That's a real job. Okay?

**Keo:** You always say stuff like that.

**Keo:** ...Okay. But you have to bring her back.

**Kailo:** I will. Promise.

**Turn:** Kailo to Cousin

**Noelani:** Don't you worry about this house. I'll keep it standing, and I'll keep this one in it.

**Turn:** Kailo to OldMan

**Kailo:** Ama. The Meialana. Can you fix her?

**Ama:** Your dad built her well, boy. The hull will hold. But they cut her up good. I need wood. Koa, and plenty of it.

**Kailo:** I'll get it. As much as you need.

**Chief Ulu:** Then rest tonight. All of you. Tomorrow you start.

**Fade:** out

**End:** The next morning.
