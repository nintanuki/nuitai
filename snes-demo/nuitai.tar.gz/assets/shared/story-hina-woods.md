# Hina catches up

So Hina cannot be missed (Frankie, 10/23): if Kailo has not been to her house yet when he walks into
the gate yard, the room just before the Great Boar's, she runs in after him through the south
doorway, the way he came, and joins (Frankie, 10/25; it was the hedge garden, which came before
Maika). So most of the map can be explored without her, but the Great Boar cannot be faced without
her. Then her scene at home no longer plays. The games play it. How to write a script is at the top of `story.md`. The scene starts
where Kailo stands, just inside the doorway.

Hina's line is a placeholder in Frankie's spirit, for him to rewrite.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png

## Scene

**Room:** gate_yard
**Walk:** Kailo to 8,12 to 8,10
**Run:** Hina from the south edge to 8,12 to 8,11
**Turn:** Kailo down

**Kailo:** Hina? What are you doing here?

**Hina:** You need a healer, don't you? I'm coming too.

**End:** Hina joins.
