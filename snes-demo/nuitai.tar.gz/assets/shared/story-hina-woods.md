# Hina catches up

So Hina cannot be missed (Frankie, 10/23): if Kailo has not been to her house yet when he walks into
the hedge garden, halfway from town to Maika's stall, she runs in after him through the south
doorway, the way he came, and joins. Then her scene at home no longer plays. The games play it; the
browser's story page does not. How to write a script is at the top of `story.md`. The scene starts
where Kailo stands, just inside the doorway.

Hina's line is a placeholder in Frankie's spirit, for him to rewrite.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png

## Scene

**Room:** hedge_garden
**Walk:** Kailo to 8,12 to 9,12 to 9,7
**Run:** Hina from the south edge to 8,12 to 9,12 to 9,8
**Turn:** Kailo down

**Kailo:** Hina? What are you doing here?

**Hina:** You need a healer, don't you? I'm coming too.

**End:** Hina joins.
