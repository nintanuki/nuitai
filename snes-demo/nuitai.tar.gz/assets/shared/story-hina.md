# Hina joins

After the taro patch Hina goes home and is out of the party. Talking to her in her house plays this
scene, and when Kailo is back outside she is in the party (Frankie, 10/23). The games play it; the
browser's story page does not. How to write a script is at the top of `story.md`. The scene starts
where Kailo stands, beside her; walking him onto a doorway, facing out, takes him through the door
when it ends.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png

## Scene

**Room:** hina_house
**Stand:** Hina at 10,7 facing down
**Turn:** Hina to Kailo

**Hina:** You're still here?

**Kailo:** I...

**Hina:** Did you forget what you were doing? You're hopeless, aren't you? Well, you need a healer anyway, so I'm coming too.

**Walk:** Kailo to 7,8 to 7,13; Hina to 10,8 to 7,8 to 7,12

**End:** Hina joins.
