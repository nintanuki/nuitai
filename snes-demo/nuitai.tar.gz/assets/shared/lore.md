# Lore pages

The pages under Lore on the Data screen, in pygame and on the cartridge (`game/answers.md`, the
Lore line). Both games read this file: pygame at run time (`core/lore.py`), the cartridge through
`game/snes/tools/make_art.py`. Edit the words here, never in the games.

Each page is drawn from its wiki article in `lore/` and checked against `lore/answers.md`, with
nothing a spoiler: a short summary in the wiki's neutral voice, American spelling. The games show
it in capitals, wrapped to 30 letters a line; two or three screens at most.

Each page is a `##` title (as the list shows it), then two lines:

- **Unlocks:** when the page appears, silently. `start` is there from New Game. `stance <name>`
  is the first time a member acts in that stance in a fight. `event <name>` is a moment in the
  story: `met_maika` (Maika's scene at his stall), `hina_home` (Hina rejoins at her house, or in the
  woods), `tawiri_joins` (Tawiri joins at the wake), `wake_shaka` (the wake ends, where Hina says Shaka keep
  him), `wake_lanu` (the same, with Maika there to answer her with Lanu), `deep_woods` (Hina or
  Maika warns Kailo off the deep woods west of the log yard, naming Lanu's beasts). Several joined
  by `or` mean whichever comes first.
- **Draft:** `yes` while the words are Claude's, for Frankie to rewrite; `no` once they are his.

Then the page's words, one paragraph.

Not here yet: Shakan Mudras, Ata Kanikani and Wili Hula, the other stances of the
demo's four, have no article in `lore/` to draw from, so acting in them unlocks nothing.

## Kailo

**Unlocks:** start
**Draft:** yes

Kailo is a young cook of about nineteen from Kulāiwi, in the Māla Iki Islands. He looks after his many younger siblings and cousins and has never left the chain. His father left when Kailo was young to explore the ocean, and Kailo dreams of exploring the world himself. Wasting food upsets him.

## Hina

**Unlocks:** start
**Draft:** yes

Hina is a young priestess of Māla and a devout follower of the teachings of Shaka. She was born in Kota Emas and raised on Māla Iki. To become the high priestess of her village she must make a pilgrimage to Kota Emas once in her life and pray at its golden temple. She is a vegetarian, as is common among devotees of Lanu.

## Melia

**Unlocks:** start
**Draft:** yes

Melia is Kailo's cousin, about eight years old, raised in his household on Kulāiwi. Cousins in the household are raised as siblings, so Kailo calls her his sister. She has his thick, wavy red hair, with hazel eyes and freckles.

## Kulāiwi

**Unlocks:** start
**Draft:** no

Kulāiwi is a small island in the Māla Iki Islands, beside Māla Iki itself, the largest island of the chain. It has one village, also called Kulāiwi. This is Kailo and Hina's home.

## Māla Iki

**Unlocks:** start
**Draft:** yes

Māla Iki, "Little Garden," is the largest island of the Māla Iki Islands, a small chain northeast of the Great Whirlpool. The chain has the mildest weather in Nuitai and has known little war. Most islanders are fishers, weavers or farmers who grow taro and sweet potato, and few sail out of sight of their own shore.

## Lelua

**Unlocks:** stance Lelua
**Draft:** yes

Lelua is the fire dance of the fire dancers of Velafi, a rite honoring Mauga and a fighting art in one. It has almost no blocking or guarding. Its defense is constant motion: spins, feints, flying kicks and somersaults. Devotional dancers turn Mana into fire that bursts from the end of a kick or a punch.

## Wai'Kenpō

**Unlocks:** stance Wai'Kenpō
**Draft:** yes

Wai'Kenpō, "the Way of the Water Fist," is a famous martial art inspired by the flow of water, with a philosophy of self defense over attack. It was developed by devout practitioners of Wai'Ki and has spread throughout Nuitai, but none practice it as well as the Kame.

## Māla Hula

**Unlocks:** stance Māla Hula
**Draft:** yes

Māla Hula is the sacred dance of the Priests of Māla. It is slow and gentle, with turns in circles and arms raised from the ground to the sky, and is danced to help crops grow and wounds heal.

## Kilomi

**Unlocks:** stance Kilomi
**Draft:** yes

Kilomi is the healers' martial art of Māla Iki and Lanuloa, devoted to Lanu. Its healers learn the points where Mana runs through a body and press them open to heal. In a fight they close the same points with open palms and fingertips, numbing a limb or cutting a channeler off from Mana. Its name joins kī, the ti plant, and lomi, to press.

## Maika

**Unlocks:** event met_maika
**Draft:** yes

Maika is a young Maki Sage of Māla Iki, with white hair and eyes of green and purple. He is well spoken and calm, can be tactless and a little arrogant, and admits when he is wrong. He practices Kilomi, the healers' martial art, and is a vegetarian.

## Maki Sages

**Unlocks:** event met_maika
**Draft:** yes

The Maki Sages are worshipers of Lanu who broke away from the Priests of Māla a century ago, when the priests took in the Teachings of Shaka. To the Sages, giving the sunlight to Shaka takes from Lanu what was always hers. They live as hermits in the more dangerous forests of Māla Iki and wear green robes marked with a purple spiral, the symbol of Mana. Unlike the peaceful priests, they use their nature magic to fight as well as to heal.

## Māla

**Unlocks:** event hina_home
**Draft:** yes

Māla is a faith of the eastern seas, born on the Māla Iki Islands. It joins the native worship of Lanu with the teachings of Shaka, brought by Bandari missionaries, and holds that Shaka is an aspect of Lanu. Its followers are pacifists who teach that harmony must be tended like a garden.

## Māla Priests

**Unlocks:** event hina_home
**Draft:** yes

The Priests of Māla are an old order of Māla Iki whose temple is the forest. They are healers, midwives and teachers, wear robes of green and yellow, and dance slow sacred dances for the growth of crops and the healing of wounds. The Maki Sages broke away from them.

## Tawiri

**Unlocks:** event tawiri_joins
**Draft:** yes

Tawiri is an old Caller of the dead from the Matua Archipelago, cynical and morbidly funny. One of her eyes is clouded white and blind with age. Her staff doubles as a walking stick, hung with feathers and little skulls.

## Callers

**Unlocks:** event tawiri_joins
**Draft:** yes

The Callers are the shamans of the Matua Archipelago, who commune with the spirits of the dead. They wear black robes adorned with bones and skulls and are both revered and feared. In Matua their work is not taboo: they prepare the dead, lead funerals and help the grieving say a last goodbye.

## Shaka

**Unlocks:** event wake_shaka
**Draft:** yes

Shaka is the founder of the Teachings of Shaka, the faith the Bandari brought to the eastern seas. He was a mortal man who awakened two thousand years ago, and for many he is now represented by the light of the sun. Shakans never picture him. Their art shows only his symbols: the sun, and his sword standing upright in the sand. Māla holds that he is the sunlight of Lanu in human form.

## Lanu

**Unlocks:** event deep_woods or event wake_lanu
**Draft:** yes

Lanu is the Akua of the sky and the forests. Her domain is the energy of all living things: life, light, growth, harmony and the gentle rain. She was once the goddess of the sun as well, but as the teachings of Shaka spread through Māla Iki and Lanuloa, the sun and its light came to be given to him instead. The Maki Sages have never accepted this.
