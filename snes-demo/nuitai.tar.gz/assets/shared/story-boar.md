# The Great Boar falls

When the Great Boar is beaten the characters talk, no narration, and they remember the wake
(Frankie, 10/23). Then it is night until the demo ends, once the stew is made too (Frankie, 10/30; the beaten boar first leaves it day, and the stew's lines after are Claude's drafts). The games play it. How to write a script is at the top of `story.md`; here `(if hina)` and `(if maika along)`
mean only if she or he is in the party, not a choice. Claude's draft lines, for Frankie to rewrite.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png

## Scene

**Kailo:** That's the last of him. The taro's safe.

**Hina** (if hina along and stew made): Kailo, look at the sky. It's nearly dark.

**Kailo** (if stew made): Pono's wake! We have to get back.

**Maika** (if maika along and stew made): A wise man never misses a free meal.

**Hina** (if hina along and stew not made): Good. Now go and finish that stew. We have all day, but I'd rather not cut it close.

**Kailo** (if stew not made): Right. Noelani's waiting on the makings, and the wake won't be the same without it.

**Maika** (if maika along and stew not made): A wise man never misses a free meal. Or a long walk to find the ingredients for one.

**End:** Night falls once the stew is made.
