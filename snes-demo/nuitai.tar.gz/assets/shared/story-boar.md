# The Great Boar falls

When the Great Boar is beaten the characters talk, no narration, and they remember the wake
(Frankie, 10/23). Then it is night until the demo ends. The games play it; the browser's story page
does not. How to write a script is at the top of `story.md`; here `(if hina)` and `(if maika along)`
mean only if she or he is in the party, not a choice. Claude's draft lines, for Frankie to rewrite.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png

## Scene

**Kailo:** That's the last of him. The taro's safe.

**Hina** (if hina): Kailo, look at the sky. It's nearly dark.

**Kailo:** Pono's wake! We have to get back.

**Maika** (if maika along): A wise man never misses a free meal.

**End:** Night falls.
