# Are you ready?

The Great Boar's fight never starts on touch (Frankie, 10/23): walking into him plays this scene
instead, a question before the point of no return, so the player can go back and heal and save
first. "Fight now" starts the fight; "Go back" walks the party a few steps away from him, and he
asks again the next time they walk up. If Maika and Hina are both along, Maika's Seed lines
(`story-maika.md`) have already played on the way into the room. The games play it. How to write a script is at the top of `story.md`.

Whoever is along asks: Hina; Maika if Hina is not along; Kailo himself if nobody is.
`(if hina)` plays with Hina along, `(if maika)` with Maika but not Hina, `(if alone)` with Kailo by
himself.

Every line here is Claude's draft, for Frankie to rewrite (10/23).

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png

## Scene

**Hina** (if hina): That's him. Are you ready?

**Maika** (if maika): That's him. A wise man checks his potions first. Ready?

**Kailo** (if alone): That's him. Am I ready for this?

**Choice:** Fight the Great Boar now?
- Fight now → fight
- Go back → back

**End:** Fight now starts the fight; Go back walks the party away from him.
