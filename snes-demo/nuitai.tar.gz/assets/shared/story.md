# The taro patch

The story test, written as a script. `python game/shared/build.py` reads this file and builds
`game/browser/story.html` from it (with the other scenes in its `STORIES`, as a menu), so this is the one place the dialogue is written. A draft
scene, not canon: the taro patch, the uncles and the boars are made up. Dialogue is in each
speaker's own accent (D-119); everyone here is eastern.

How to write it:

- `**Name:** line` is someone talking. `**Name** (if lid):` only plays if that choice was made;
  `(if hina)` only with Hina in the party, `(if maika)` only with Maika but not Hina, `(if alone)`
  only with Kailo by himself.
- A plain line is narration.
- `**Hina:** (fast) Why do you sages always have to—` types the line out three times as fast,
  in the games. A fast line that ends on a dash is cut off: the next line comes up the moment it
  is typed, with no button (Frankie, 10/23). The browser's page shows the words.
- `**Name** (if maika along):` plays whenever that one is in the party, whoever leads
  (`story-boar.md`; the games only).
- `**Name** (if maika not along):` plays only when he is not in the party (the wake's ending,
  10/25; pygame reads it, the cartridge not yet).
- `**Choice:**` is followed by the options, each `- text → flag`.
- `**Fight:**` names the party, then `against`, then each enemy as `Name (monster, element)`, or
  `Name (monster, element, sprite)` to draw it as a sprite it is not named after (the wake's Pono,
  drawn as the amaranhig). The first three named fight; a fourth or more wait on the bench to swap in. The story carries
  on under `## If you win` or `## If you lose`.
- `**Place:**`, `**Background:**` and `**Music:**` set the scene. `**End:**` closes it. The music
  is one or more songs from `game/shared/music/`, picked at random; it plays under the waves on the
  story screens, and the fights have their own.
- `**Card:**` is the scene's one line under its name on the story menu: a teaser of what happens, not
  a count of its parts (Frankie, 10/20). The menu numbers the scenes in the order of `STORIES`.

Stage directions act the scene out on the map, as a Super Nintendo cutscene does (Frankie, 10/23).
The games play them; the browser's story page skips them. A tile is its column and row counted from
the top left of the room, from 0 (`5,6`). Several people at once are separated by semicolons.

- `**Room:** beach_west` plays the scene in that room of the map. Kailo is the player.
- `**Stand:** Hina at 11,4 facing down` puts someone on a tile, facing up, down, left or right.
- `**Walk:** Hina to 11,7 to 5,7` moves someone at the map's walking speed; `**Run:**` twice as
  fast. Each `to` is a stop, reached across first, then up or down. `from 11,4` or `from the east
  edge` puts them there first (an edge in the row or column of the first stop); `to the east edge`
  goes off the map in the row they are in, and off it they are gone. Everyone on one line moves
  together, and the next line waits until they all arrive.
- `**Turn:** Kailo right` turns someone; `**Turn:** Kailo, Melia to Hina` turns them to face her.
- `**Fall:** Body` lays someone down on their tile: their sheet's fifth row if it has one, else
  their standing frame on its side. Standing them again gets them up.
- `**Fade:** out` takes the screen to black, `**Fade:** in` brings it back, as the Super Nintendo's
  brightness does (the wake, Frankie 10/23). A scene can change room while it is black.
- `**Wait:** 1` holds the scene that many seconds, for a pause no one speaks in.
- A direction can be `(if maika along)` like a line, and plays only then.
- Someone on the stage is named for their walk sheet (`<Name>-Walk.png` with the map's people), or
  is Kailo.
- A tile can be past the edge: `from -2,6` starts someone two tiles out, so two arriving together
  do not walk on top of each other.
- The scene's foes can stand on the stage too, under their names in its `**Fight:**` line, as the
  map draws their kind. A walker that only faces left or right turns that way; `facing down` has
  it rooting, head down, bobbing between its frames.

The people of the room (Melia at home) are hidden while their scene is acted out, and everyone but
Kailo leaves when it ends. A scene whose `Room` is the one Kailo is in starts with him where he
stands; one that ends with him on a doorway, facing out, takes him through the door.
After this scene Hina walks home and is out of the party until Kailo talks to her there
(`story-hina.md`), or catches him up in the gate yard, the room before the Great Boar's (`story-hina-woods.md`).

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Melia**: Lau, art/portraits/melia-portrait-a.png

## Scene

**Place:** A small island beside Māla Iki, morning
**Background:** art/wiki/location/mala-iki-islands-1.webp
**Music:** calm-bay.mp3, where-the-winds-roam.mp3, definitely-our-town.mp3
**Card:** Boars are tearing up the taro patch, and all Kailo has is his cooking gear.

**Room:** beach_west
**Stand:** Kailo at 5,6 facing up

**Kailo:** Stew, cakes, breadfruit... If I leave now I'll be back before Melia's done her chores.

**Run:** Melia from the east edge to 10,6

**Melia:** Kailo! KAILO!

**Turn:** Kailo right
**Run:** Melia to 6,6

**Kailo:** I'm right here. What happened?

**Melia:** Boars! Two of them, in the taro patch. They're digging up everything!

**Kailo:** The taro? That patch feeds three houses!

**Stand:** Hina at 11,4 facing down

**Hina:** Then stop shouting and do something about it.

**Turn:** Kailo, Melia to Hina
**Walk:** Hina to 11,7 to 5,7
**Turn:** Hina up; Kailo down

**Hina:** I was coming over for one of your taro cakes. I'd like there to still be taro tomorrow.

**Turn:** Hina to Melia; Melia to Hina

**Hina:** Melia, stay here and keep the gulls off the stew.

**Melia:** Why do I always get the gulls?

**Melia:** It's fine. I've got my sling.

**Kailo:** Melia, put that thing away before you break something.

**Run:** Kailo to the east edge; Hina to 5,6 to the east edge
**Turn:** Melia up

**Room:** beach_east
**Stand:** Wild Boar A at 6,7 facing down; Wild Boar B at 5,8 facing down
**Run:** Kailo from the west edge to 3,6; Hina from -2,6 to 2,6

**Kailo:** Shoo! Shoo!

**Turn:** Wild Boar A, Wild Boar B to Kailo

**Wild Boar A:** SQUEEEE!

**Fight:** Kailo the Cook, Holy Hina against Wild Boar A (boar, Lau), Wild Boar B (boar, Lau)

## If you win

**Room:** beach_east
**Stand:** Kailo at 6,6 facing down; Hina at 8,7 facing left

**Kailo:** Look at this. Half of it's dug up. That's a month of poi, just lying in the mud.

**Hina:** It's not all ruined. Some of those roots are only bruised.

**Kailo:** ...yeah, bruised taro still cooks. I just hate seeing the rest go to waste.

**Run:** Melia from the west edge to 5,6
**Turn:** Kailo left

**Melia:** They'll be back, you know.

**Kailo:** How do you know that?

**Melia:** Everybody knows. The Great Boar lives at the top of the woods, and he's the boss of all the boars. He sends the little ones down to steal taro for him, because he's too fat to come get it himself.

**Turn:** Hina to Melia

**Hina:** That is not how boars work.

**Melia:** Then why do they keep coming?

**Turn:** Kailo down

**Kailo:** ...Change of plans. Nobody's going to the next island today. If there's a boss boar up there, I'm going to go tell him to get his own taro.

**Hina:** Then I'll take my cake now.

**Hina:** Be back before dark. Old Pono's wake is tonight.

**Turn:** Kailo to Melia

**Kailo:** Melia, go back to your chores.

**Melia:** Aw.

**Walk:** Hina to 8,9 to 3,9 to 3,6 to the west edge; Melia to the west edge

**End:** The end of the test scene.

## If you lose

**Room:** beach_east
**Stand:** Kailo at 6,6 facing down; Melia at 5,6 facing right; Wild Boar A at 9,7 facing down; Wild Boar B at 10,8 facing down
**Fall:** Kailo
**Wait:** 1

**Uncle:** Hyah! Get out of that taro, you pigs!

**Run:** Wild Boar A to the east edge; Wild Boar B to the east edge
**Wait:** 0.5
**Stand:** Kailo at 6,6 facing down
**Turn:** Melia to Kailo

**Melia:** You lost to a pig.

**Kailo:** Two pigs.

**Melia:** The gulls got the stew, by the way.

**End:** The end of the test scene. Try again?
