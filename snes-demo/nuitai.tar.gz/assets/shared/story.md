# The taro patch

The story test, written as a script. `python game/shared/build.py` reads this file and builds
`game/browser/story.html` from it (with the other scenes in its `STORIES`, as a menu), so this is the one place the dialogue is written. A draft
scene, not canon: the taro patch, the uncles and the boars are made up. Dialogue is in each
speaker's own accent (D-119); everyone here is eastern.

How to write it:

- `**Name:** line` is someone talking. `**Name** (if lid):` only plays if that choice was made.
- A plain line is narration.
- `**Choice:**` is followed by the options, each `- text → flag`.
- `**Fight:**` names the party, then `against`, then each enemy as `Name (monster, element)`.
  The first three named fight; a fourth or more wait on the bench to swap in. The story carries
  on under `## If you win` or `## If you lose`.
- `**Place:**`, `**Background:**` and `**Music:**` set the scene. `**End:**` closes it. The music
  is one or more songs from `game/shared/music/`, picked at random; it plays under the waves on the
  story screens, and the fights have their own.
- `**Card:**` is the scene's one line under its name on the story menu: a teaser of what happens, not
  a count of its parts (Frankie, 10/20). The menu numbers the scenes in the order of `STORIES`.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Melia**: Lau, art/portraits/melia-portrait-a.png

## Scene

**Place:** A small island beside Māla Iki, morning
**Background:** art/wiki/location/mala-iki-islands-1.webp
**Music:** calm-bay.mp3, where-the-winds-roam.mp3, definitely-our-town.mp3
**Card:** Boars are tearing up the taro patch, and all Kailo has is his cooking gear.

The tide is out. Kailo's boat is half loaded: taro cakes wrapped in leaves, a pot of fish stew, and a basket of breadfruit for the next island over.

**Kailo:** Stew, cakes, breadfruit... If I leave now I'll be back before Melia's done her chores.

**Melia:** Kailo! KAILO!

**Kailo:** I'm right here. What happened?

**Melia:** Boars! Two of them, in the taro patch. They're digging up everything!

**Kailo:** The taro? That patch feeds three houses!

**Hina:** Then stop shouting about it and go.

**Kailo:** Hina? What are you doing down here?

**Hina:** I came for one of your taro cakes. I'd like there to still be taro tomorrow.

Kailo looks at his boat. There's nothing in it to fight with but cooking gear.

**Choice:** What does Kailo take?
- Grab the pot lid and the big ladle → lid
- Grab the rolling pin → pin

**Kailo** (if lid): A lid to block, a ladle to swing. Good enough.

**Kailo** (if pin): This thing's made of ironwood. It'll do.

**Hina:** Melia, stay here and keep the gulls off the stew.

**Melia:** Why do I always get the gulls?

Up past the houses, the taro patch is a mess of mud and torn leaves. Two boars look up from it.

**Fight:** Kailo the Cook, Holy Hina against Wild Boar A (boar, Lau), Wild Boar B (boar, Wai)

## If you win

The boars crash off into the trees. The patch is quiet again.

**Kailo:** Look at this. Half of it's dug up. That's a month of poi, just lying in the mud.

**Hina:** It's not all ruined. Most of those roots are only bruised.

**Kailo:** ...Bruised taro still cooks.

Melia comes running up the path, still flapping her arms at a gull.

**Melia:** They'll be back, you know.

**Kailo:** How do you know that?

**Melia:** Everybody knows. The Great Boar lives at the top of the woods, and he's the boss of all the boars. He sends the little ones down to steal taro for him, because he's too fat to come get it himself.

**Hina:** That is not how boars work.

**Melia:** Then why do they keep coming?

**Kailo:** ...Change of plans. Nobody's going to the next island today. If there's a boss boar up there, I'm going to go tell him to get his own taro.

**Hina:** Then I'll take my cake now. You can keep the stew.

**Hina** (if pin): And wash that rolling pin first.

**Hina** (if lid): And wash that ladle first.

**End:** The end of the test scene.

## If you lose

Kailo wakes up on the mud with a sore head. Two of his uncles are chasing the boars off with sticks.

**Melia:** You lost to a pig.

**Kailo:** Two pigs.

**Melia:** The gulls got the stew, by the way.

**End:** The end of the test scene. Try again?
