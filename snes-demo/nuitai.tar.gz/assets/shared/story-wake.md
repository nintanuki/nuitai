# The wake

The second story test, separate from the taro patch. `python game/shared/build.py` reads this file
and puts it on the menu of `game/browser/story.html`, beside the taro patch. A draft scene, not canon: Old Pono, his wake,
the dwende and why Tawiri is in Māla Iki are made up (Frankie, 10/16: she travels and was in the
area; a deeper motive may come later). The rules for writing a script are at the top of
`story.md`. Here the Fight names four, so the first three fight and the fourth waits on the bench
to swap in.

Staged as Frankie played it (`game/answers.md`, "The wake, as played", 10/23): yes to Melia fades
out and the wake fades in beside the chief's house, the whole village there. The exchange about
Shaka and Lanu after the fight is Frankie's (10/23): the young get caught up in their faiths and the
old shrug, and Tawiri's line is the first hint. Claude's draft, for Frankie to rewrite: Pono's
wife's scream, the villager back from the harbor, Melia's question about the ocean and Kailo's "Come
on. There's still food." Everyone in the village is
eastern and says Makua for Matua (D-119); Tawiri, from Matua, says it her own way.

On the map the actors are named for their walk sheets: Master is the chief, OldMan the old man of
the stall, FighterRed and FighterWhite the two who spar, Widow Pono's wife, Body his body with the
dwende riding it, Spirit his spirit (`game/pygame/tools/make_wake_sprites.py`).

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Tawiri**: Ata, art/portraits/tawiri-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png
- **Melia**: Lau, art/portraits/melia-portrait-a.png

## Scene

**Place:** A village in Māla Iki, the night of a wake
**Background:** art/wiki/location/mala-iki-islands-2.webp
**Music:** where-the-winds-roam.mp3, calm-bay.mp3
**Card:** Old Pono died three days ago. Tonight his body got up and walked into the trees.

**Fade:** out
**Room:** beach_east
**Stand:** Kailo at 10,7 facing up; Hina at 9,7 facing right; Melia at 10,8 facing up; Master at 12,7 facing down; OldMan at 13,7 facing left; Boy at 14,7 facing left; FighterRed at 12,8 facing left; FighterWhite at 13,8 facing left
**Stand** (if maika along): Maika at 11,7 facing left
**Fade:** in

**Kailo:** Pork, poi, sweet potato, and the stew's still hot. Nobody leaves Pono's wake hungry.

**Maika** (if maika along): A wise man knows grief is best faced on a full stomach.

**Hina** (if maika along): That's your third plate.

**Maika** (if maika along): Fourth. The grief is very large tonight.

**Hina** (if maika along): Show some respect. A man is dead.

**Run:** Widow from the east edge to 14,11 to 14,8
**Turn:** Kailo, Hina, Maika, Melia, Master, OldMan, Boy, FighterRed, FighterWhite to Widow
**Turn:** Widow left

**Widow:** PONO! His mat is empty! He's gone!

**Walk:** Body from the east edge to 13,11
**Turn:** Kailo, Hina, Maika, Melia, Master, OldMan, Boy, FighterRed, FighterWhite, Widow to Body
**Walk:** Body to 8,11 to 8,4
**Turn:** Kailo, Hina, Maika, Melia, Master, OldMan, Boy, FighterRed, FighterWhite, Widow to Body
**Walk:** Body to the north edge
**Run:** FighterWhite to 13,10 to 8,10 to the north edge

**Kailo:** He was dead. I helped carry him!

**Run:** FighterWhite from the north edge to 8,5 to 6,5
**Turn:** Kailo, Hina, Maika, Melia, Master to FighterWhite

**Villager:** I ran all the way to the harbor! The Caller from Makua is coming!

**Hina:** Everyone stay calm. I am calm. I am completely calm.

**Walk:** Tawiri from the north edge to 8,5
**Turn:** Kailo, Hina, Maika, Melia, Master, OldMan, Boy, FighterRed, FighterWhite, Widow to Tawiri

**Tawiri:** Then stop squeaking, girl.

**Turn:** Tawiri to Hina

**Tawiri:** Tawiri. Caller. I hear you've lost a dead man.

**Kailo:** Kawili?

**Turn:** Tawiri to Kailo

**Tawiri:** Ta. Wi. Ri. You easterners sand the corners off everything.

**Kailo:** Makua's a long way from here.

**Tawiri:** I walk slow, and I've had a long time to do it. I was passing through.

**Run:** Melia to 8,8 to 8,6
**Turn:** Melia up

**Melia:** Did you walk here on the ocean? All the way?

**Turn:** Tawiri to Melia
**Wait:** 1

**Hina:** Passing through to where?

**Turn:** Tawiri to Hina

**Tawiri:** Wherever the dead are misbehaving.

**Tawiri:** Listen. The dead stay put. That's the whole arrangement. Whatever got up off that mat, it isn't your Pono.

**Hina:** Then what is it?

**Tawiri:** Let's ask him.

**Turn:** Tawiri left
**Wait:** 0.25
**Turn:** Tawiri up
**Wait:** 0.25
**Turn:** Tawiri right
**Wait:** 0.25
**Turn:** Tawiri down
**Wait:** 0.25
**Turn:** Tawiri left
**Wait:** 0.25
**Turn:** Tawiri up
**Wait:** 0.25
**Turn:** Tawiri right
**Wait:** 0.25
**Turn:** Tawiri down
**Wait:** 0.5
**Stand:** Spirit at 8,4 facing down
**Turn:** Kailo, Hina, Maika, Melia, Master, OldMan, Boy, FighterRed, FighterWhite, Widow to Spirit
**Turn:** Tawiri up

**Kailo:** Uncle Pono!

**Turn:** Spirit up
**Walk:** Spirit to 8,2
**Turn:** Spirit down
**Wait:** 0.5

**Tawiri:** He wants it back. Rude to keep a man waiting.

**Maika** (if maika along): I'll guard the food. Someone must.

**Hina** (if maika along): Maika.

**Maika** (if maika along): A wise man knows three is plenty for one dead man. If it goes badly, call my name and I'll come running. After this plate.

**Walk:** Spirit to the north edge; Tawiri to the north edge; Hina to 9,5 to 8,5 to the north edge; Kailo to 9,7 to 9,5 to 8,5 to the north edge
**Fade:** out
**Room:** sand_garden
**Stand:** Body at 7,4 facing down; Spirit at 9,3 facing left
**Fade:** in
**Walk:** Kailo from the south edge to 7,7; Hina from the south edge to 8,7; Tawiri from 8,15 to 8,8

**Tawiri:** An amaranhig. And a dwende riding it. Little wretch.

**Fight:** Kailo the Cook, Holy Hina, Granny Tawiri, Maika the Sage against Pono (rot, Ata, amaranhig), Wicked Dwende (rot, Lau)

## If you win

**Stand:** Wicked Dwende at 8,4 facing right
**Fall:** Body
**Run:** Wicked Dwende to the north edge

**Kailo:** Is he...

**Tawiri:** Dead. Properly, this time.

**Walk:** Spirit to 8,5
**Turn:** Spirit down
**Wait:** 1

**Kailo:** What's he looking at?

**Turn:** Tawiri down
**Wait:** 1.5

**Tawiri:** Nothing for you to worry about tonight.

**Hina:** That's not an answer.

**Tawiri:** No. It isn't.

**Walk:** Spirit to the south edge
**Fade:** out
**Room:** beach_east
**Stand:** Kailo at 10,7 facing up; Hina at 9,7 facing right; Tawiri at 8,7 facing right; Melia at 10,8 facing up; Master at 12,7 facing down; OldMan at 13,7 facing left; Boy at 14,7 facing left; FighterRed at 12,8 facing left; FighterWhite at 13,8 facing left; Widow at 14,8 facing left
**Stand** (if maika along): Maika at 11,7 facing left
**Fade:** in

**Kailo:** Come on. There's still food.

**Maika** (if maika along): There's a little less food.

**Hina:** Shaka keep him.

**Maika** (if maika along): Lanu keeps him. He feeds her roots now, like all of us will.

**Turn** (if maika along): Hina to Maika

**Hina** (if maika along): And her roots drink Shaka's light. That's the whole teaching.

**Maika** (if maika along): Your teaching.

**Hina** (if maika along): (fast) Why do you sages always have to—

**Kailo** (if maika along): (fast) You guys...

**Turn** (if maika along): Tawiri to Hina

**Tawiri** (if maika along): Enough of your squabbling, children.

**Fade:** out

**End:** TO BE CONTINUED

## If you lose

**Fall:** Kailo
**Wait:** 1
**Stand:** Kailo at 7,7 facing up

**Tawiri:** You fight like a man carrying soup.

**Kailo:** I usually am.

**Hina:** This is not funny.

**Tawiri:** Child, it's a little funny.

**End:** The end of the second test scene. Try again?
