# The wake

Old Pono's wake, separate from the taro patch. The pygame game reads this file (`core/story.py`). A draft scene, not canon: Old Pono, his wake
and why Tawiri is in Māla Iki are made up (Frankie, 10/16: she travels and was in the
area; a deeper motive may come later). The rules for writing a script are at the top of
`story.md`. Here the Fight names four, so the first three fight and the fourth waits on the bench
to swap in.

Staged as Frankie played it (`game/answers.md`, "The wake, as played", 10/23): yes to Hina's
question in the chief's room (since 10/25; it was Melia's) fades out and the wake fades in beside the chief's house, the whole village there. The exchange about
Shaka and Lanu after the fight is Frankie's (10/23): the young get caught up in their faiths and the
old shrug, and Tawiri's line is the first hint. Claude's draft, for Frankie to rewrite: Pono's
wife's scream, the villager back from the harbor, Melia's question about the ocean and Kailo's "Come
on. There's still food." Everyone in the village is
eastern and says Makua for Matua (D-119); Tawiri, from Matua, says it her own way. "Aduh" slips
out of Hina when she is flustered (Frankie, 10/26); Claude's draft.

What is happening (Frankie, 10/30, written in 10/31): an evil spirit has possessed Pono's body,
and his own spirit is restless because his body is being defiled, so the party helps to free him,
not to bring him back. Tawiri reads it from his spirit turning toward his house (the summoned dead
point, they never speak), and Hina's "Can you bring him back?" lets her say so in two lines. Tawiri
is morbidly jolly (Frankie, 10/30): cheerful about death, never about the grief, so her jokes go
to the dead and to herself, and the wake's sad and frightening moments (the widow, the kidnapping)
get none. Claude's drafts from 10/31, for Frankie to rewrite: "Keeps me young", the two lines
about the stranger in Pono's body and Hina's question between them, "Something old and nasty,
walking around in poor Pono", "isn't getting any fresher" and "He's dead, not deaf."

The stew (Frankie, 10/26): if the boars at the taro patch were beaten, the stew was saved, and
the chief thanks Kailo for it and gives him something, a random rare drop or relic (the games add
it after his line); if the fight was lost, the new stew came out plain (it was the gulls before 10/30), and the wake plays as usual. Claude's drafts, for
Frankie to rewrite: the chief's line, and Kailo's opener without the stew.

Since 10/25 (Frankie) the fight is at Pono's house, in its own room east of the chief's: his body
walks out of his door, and the foe is Pono's Corpse alone, no dwende, with a shadow and a spirit
stance. Since 10/27 (Frankie approved this order) the talk is beside the chief's house through
Pono's spirit appearing and Maika staying with the food; then at Pono's house his body walks out,
Tawiri names the amaranhig, the party readies, and Kailo spots Melia, who followed them, and sends
her home before the fight. Hina's "How do you fight a dead man?", Tawiri's answer, Kailo's "I can
do this", Hina's "Behind you" and Tawiri's "Done?" are Claude's drafts, for Frankie to
rewrite. After the fight his spirit walks down to the shoreline and looks out to sea (Frankie,
10/25). Voices of the Past, Tawiri's theme, starts as she walks in and plays through the fight;
winning it plays the victory theme on the victory screen, and Regrets comes back once it closes
(Frankie, 10/26 and 10/27). From the cut to Melia on the beach to TO BE CONTINUED there is no music
(Frankie, 10/27).

With Maika along he starts the fight on the bench, and on the first turn the swap is taught as a
talk between Hina and Maika, then forced: the player picks who sits out, Kailo or Hina, the cursor
on Hina; Tawiri cannot be swapped out of this fight, and Maika may go straight back out after
(Frankie, 10/30; it was Hina alone, nothing forced, 10/26). The pygame game has the lines in
`settings.py` (`StorySettings.SWAP_TALK` and `SWAP_GRUMBLE`), Claude's drafts (10/30 and 10/31),
for Frankie to reword. The cartridge still plays the 10/26 lesson.

The kidnapping ending (Frankie's plan, 10/24, in `game/answers.md`; Claude's lines, 10/25, for
Frankie to rewrite): Kailo sends Melia home at Pono's house and she goes to sulk on the beach; a
short cut away to two pirates taking her; back at the wake Kailo notices she is gone, during the
argument, or, without Maika, when he goes to take her a plate; the search, the tusk Kailo gave her
on the sand, then her sling, its stone gone (Frankie, 10/25: the tusk first, then the sling), and
boot prints (the east goes barefoot). Since 10/28 (Frankie) her scream comes from the west and
they run to the harbor, where they see the black sails, find the Meialana wrecked, and Kailo
jumps off the end of the pier; the demo ends as he goes in. Claude's lines there, for Frankie to
rewrite: Hina's "That came from the harbor!", the sails seen by Maika, or by Hina without him,
Kailo's "They wrecked her" and Tawiri's "So nobody can follow." The sling is Frankie's
(10/25), foreshadowed at the taro patch, where Kailo tells her to put it away.

On the map the actors are named for their walk sheets: Master is the chief, OldMan the old man of
the stall, FighterRed and FighterWhite the two who spar, Widow Pono's wife, Body his body, Spirit his
spirit (`game/pygame/tools/make_wake_sprites.py`).

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Tawiri**: Ata, art/portraits/tawiri-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png
- **Melia**: Lau, art/portraits/melia-portrait-a.png

## Scene

**Place:** A village in Māla Iki, the night of a wake
**Background:** art/wiki/location/mala-iki-islands-2.webp
**Music:** where-the-winds-roam.mp3, calm-bay.mp3
**Card:** Old Pono died three days ago. Tonight his body got up.

**Fade:** out
**Room:** beach_east
**Stand:** Kailo at 10,7 facing up; Hina at 9,7 facing right; Melia at 10,8 facing up; Master at 12,7 facing down; OldMan at 13,7 facing left; Boy at 14,7 facing left; FighterRed at 12,8 facing left; FighterWhite at 13,8 facing left
**Stand** (if maika along): Maika at 11,7 facing left
**Fade:** in

**Kailo** (if stew saved): Pork, poi, sweet potato, and the stew's still hot. Nobody leaves Pono's wake hungry.

**Kailo** (if stew lost): Pork, poi, sweet potato, and a stew that came out plain. Nobody leaves Pono's wake hungry.

**Turn** (if stew saved): Master to Kailo

**Chief Ulu** (if stew saved): Kailo, this stew is delicious. Pono was right, it's the best on the island. Here, take this. Mahalo, for feeding us all tonight.

**Maika** (if maika along): A wise man knows grief is best faced on a full stomach.

**Hina** (if maika along): That's your third plate.

**Maika** (if maika along): Fourth. The grief is very large tonight.

**Hina** (if maika along): Show some respect. A man is dead.

**Run:** Widow from the east edge to 14,11 to 14,8
**Turn:** Kailo, Hina, Maika, Melia, Master, OldMan, Boy, FighterRed, FighterWhite to Widow
**Turn:** Widow left

**Nene:** PONO! His mat is empty! He's gone!

**Kailo:** Gone? He was dead. I helped carry him!

**Run:** FighterWhite to 13,9 to 13,10 to 2,10 to the west edge
**Wait:** 1.5
**Run:** FighterWhite from the west edge to 2,10 to 8,10 to 8,5 to 6,5
**Turn:** Kailo, Hina, Maika, Melia, Master to FighterWhite

**Villager:** I ran all the way to the harbor! The Caller from Makua is coming!

**Hina:** Aduh. Everyone stay calm. I am calm. I am completely calm.

**Song:** Voices of the Past
**Walk:** Tawiri from the west edge to 2,10 to 8,10 to 8,5
**Turn:** Kailo, Hina, Maika, Melia, Master, OldMan, Boy, FighterRed, FighterWhite, Widow to Tawiri

**Tawiri:** Then stop squeaking, girl.

**Turn:** Tawiri to Hina

**Tawiri:** Kia ora. Tawiri. Caller of the Matua. I hear you've lost a dead man.

**Kailo:** Kawili?

**Turn:** Tawiri to Kailo

**Tawiri:** Ta. Wi. Ri. You easterners sand the corners off everything.

**Kailo:** Makua's a long way from here.

**Tawiri:** I walk slow, and I've had a long time to do it. I was passing through.

**Walk:** Melia to 8,8 to 8,6
**Turn:** Melia up

**Melia:** Did you walk here on the ocean? All the way?

**Turn:** Tawiri to Melia
**Wait:** 1

**Hina:** Passing through to where?

**Turn:** Tawiri to Hina

**Tawiri:** Wherever the dead are misbehaving. Keeps me young.

**Tawiri:** Listen. The dead stay put. That's the whole arrangement. Whatever got up off that mat, it isn't your Pono.

**Hina:** Then what is it?

**Tawiri:** Let's ask him.

**Turn:** Tawiri left
**Wait:** 0.25
**Turn:** Tawiri up
**Wait:** 0.25
**Turn:** Tawiri right
**Wait:** 0.25
**Turn:** Tawiri down
**Wait:** 0.25
**Turn:** Tawiri left
**Wait:** 0.25
**Turn:** Tawiri up
**Wait:** 0.25
**Turn:** Tawiri right
**Wait:** 0.25
**Turn:** Tawiri down
**Wait:** 0.5
**Stand:** Spirit at 10,5 facing down
**Turn:** Kailo, Hina, Maika, Melia, Master, OldMan, Boy, FighterRed, FighterWhite, Widow to Spirit
**Turn:** Tawiri up

**Kailo:** Uncle Pono!

**Turn:** Spirit right
**Wait:** 0.5

**Tawiri:** Something's moved into his body, and he wants it out. Hard to rest with a stranger walking around in you.

**Hina:** Can you bring him back?

**Turn:** Tawiri to Hina

**Tawiri:** Back? Kāo, girl. He's done with living, and good for him. We throw the squatter out, and he gets to be dead in peace.

**Maika** (if maika along): I'll guard the food. Someone must.

**Hina** (if maika along): Maika.

**Maika** (if maika along): A wise man knows three is plenty for one dead man. If it goes badly, call my name and I'll come running. After this plate.

**Run:** Spirit to 10,4 to 4,4 to 4,10 to the east edge; Tawiri to 8,10 to the east edge; Hina to 9,11 to the east edge; Kailo to 10,11 to the east edge
**Fade:** out
**Room:** pono_yard
**Stand:** Kailo at 6,8 facing up; Hina at 5,8 facing up; Tawiri at 7,8 facing up; Spirit at 9,7 facing left
**Fade:** in
**Wait:** 0.5
**Walk:** Body from 7,5 to 7,7

**Tawiri:** An amaranhig. Something old and nasty, walking around in poor Pono.

**Hina:** How do you fight a dead man?

**Turn:** Tawiri to Hina

**Tawiri:** Same as a live one. He just won't complain about it after.

**Kailo:** Okay. Okay. I can do this.

**Walk:** Melia from the west edge to 2,10 to 2,7
**Turn:** Hina to Melia

**Hina:** Kailo. Behind you.

**Turn:** Kailo to Melia

**Kailo:** Melia! What are you doing here? Go home!

**Melia:** But I want to see the Caller do magic!

**Kailo:** This isn't a show. Go home. Now!

**Wait:** 1

**Melia:** You never let me do anything!

**Run:** Melia to 2,10 to the west edge
**Turn:** Hina to Kailo

**Hina:** Good. That thing won't care how little she is.

**Kailo:** She'll sulk it off. She always does.

**Turn:** Tawiri to Body

**Tawiri:** Done? Pono's been patient for three days, and he isn't getting any fresher.

**Turn:** Kailo, Hina to Body
**Fight:** Kailo the Cook, Holy Hina, Granny Tawiri, Maika the Sage against Pono's Corpse (ponos_corpse, Ata, amaranhig)

## If you win

**Fall:** Body

**Kailo:** Is he...

**Tawiri:** Āe. Dead. Properly, this time.

**Walk:** Spirit to 9,11
**Turn:** Spirit down
**Wait:** 1

**Kailo:** What's he looking at?

**Turn:** Tawiri down
**Wait:** 1.5

**Tawiri:** Nothing for you to worry about tonight.

**Hina:** That's not an answer.

**Tawiri:** Kāo. It isn't.

**Walk:** Spirit to the south edge
**Fade:** out
**Song:** none
**Room:** beach_west
**Stand:** Melia at 7,6 facing down
**Fade:** in
**Wait:** 1

**Melia:** "Go home, Melia." "Do your chores, Melia." I'm not a baby.

**Song:** Black Flags
**Walk:** Pirate from the west edge to 3,6; PirateTwo from -2,6 to 2,6
**Wait:** 0.5

**Pirate:** A girl, on her own, down by the beach.

**PirateTwo:** Is she supposed to be this small? I can never tell with them.

**Pirate:** It's a human girl, isn't it? Works for me.

**Turn:** Melia left

**Melia:** Who are you?

**PirateTwo:** Nobody, kid. Hold still. I want to get paid and go to bed.

**Run:** Pirate to 6,6; PirateTwo to 2,7 to 7,7
**Fade:** out
**Song:** none
**Room:** beach_east
**Stand:** Kailo at 10,7 facing up; Hina at 9,7 facing right; Tawiri at 8,7 facing right; Master at 12,7 facing down; OldMan at 13,7 facing left; Boy at 14,7 facing left; FighterRed at 12,8 facing left; FighterWhite at 13,8 facing left; Widow at 14,8 facing left
**Stand** (if maika along): Maika at 11,7 facing left
**Fade:** in

**Kailo:** Come on. There's still food.

**Maika** (if maika along): There's a little less food.

**Hina:** Shaka keep him.

**Maika** (if maika along): Lanu keeps him. He feeds her roots now, like all of us will.

**Turn** (if maika along): Hina to Maika

**Hina** (if maika along): And her roots drink Shaka's light. That's the whole teaching.

**Maika** (if maika along): Your teaching.

**Hina** (if maika along): (quick) This is why nobody invites sages to anything. You turn every—

**Kailo** (if maika along): (fast) You guys...

**Turn** (if maika along): Tawiri to Hina

**Tawiri** (if maika along): Enough of your squabbling, children. He's dead, not deaf.

**Wait:** 1
**Turn** (if maika along): Kailo down

**Kailo** (if maika along): Where's Melia?

**Kailo** (if maika not along): I'll take Melia a plate. She'll be done sulking by now.

**Walk** (if maika not along): Kailo to 10,10
**Turn** (if maika not along): Kailo left
**Wait** (if maika not along): 1

**Kailo** (if maika not along): Melia?

**Turn:** Hina to Kailo

**Hina:** She went home. You sent her.

**Kailo:** She never goes home. She hides and waits for me to come find her.

**Kailo:** MELIA!

**Wait:** 1
**Fade:** out
**Room:** beach_west
**Stand:** Kailo at 10,8 facing left; Hina at 6,8 facing down; Tawiri at 12,9 facing down
**Stand** (if maika along): Maika at 4,8 facing left
**Fade:** in

**Kailo:** Melia! Come out! I'm not mad anymore!

**Walk:** Kailo to 10,10
**Turn:** Kailo down
**Wait:** 1

**Kailo:** Her tusk. Forever, huh? She'll be crying about this tomorrow.

**Walk:** Hina to 6,10
**Turn:** Hina down
**Wait:** 1

**Hina:** Kailo. Her sling.

**Run:** Kailo to 7,10
**Turn:** Kailo down
**Wait:** 1

**Kailo:** ...The stone's gone.

**Walk:** Tawiri to 8,9 to 8,10
**Turn:** Tawiri down

**Tawiri:** Then she hit something. Boot prints. Two men.

**Hina:** Nobody here wears boots.

**Melia:** KAILO!

**Turn:** Kailo, Hina, Tawiri left
**Turn** (if maika along): Maika left
**Wait:** 1

**Hina:** That came from the harbor!

**Run:** Kailo to the west edge; Hina to 6,11 to the west edge; Tawiri to 8,11 to the west edge
**Run** (if maika along): Maika to 4,10 to the west edge
**Fade:** out
**Room:** harbor
**Stand:** Kailo at 13,8 facing left; Hina at 14,8 facing left; Tawiri at 14,7 facing left
**Stand** (if maika along): Maika at 13,7 facing left
**Fade:** in
**Wait:** 1

**Maika** (if maika along): Out there. Sails.

**Hina** (if maika not along): Out there. Sails.

**Tawiri:** Black ones.

**Run:** Kailo to 13,10 to 9,10
**Turn:** Kailo up
**Wait:** 1

**Kailo:** No... The Meialana. They wrecked her.

**Tawiri:** So nobody can follow.

**Kailo:** Hold on, Melia! I'm coming!

**Hina:** Kailo, wait!

**Run:** Kailo to 1,10
**Fade:** out

**End:** TO BE CONTINUED

## If you lose

**Fall:** Kailo
**Wait:** 1
**Stand:** Kailo at 6,8 facing up

**Tawiri:** You fight like a man carrying soup.

**Kailo:** I usually am.

**Hina:** This is not funny.

**Tawiri:** Child, it's a little funny.

**End:** The end of the second test scene. Try again?
