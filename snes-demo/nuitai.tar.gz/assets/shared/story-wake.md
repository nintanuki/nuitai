# The wake

The second story test, separate from the taro patch. `python game/shared/build.py` reads this file
and puts it on the menu of `game/browser/story.html`, beside the taro patch. A draft scene, not canon: Old Pono, his wake,
the dwende and why Tawiri is in Māla Iki are made up (Frankie, 10/16: she travels and was in the
area; a deeper motive may come later). The rules for writing a script are at the top of
`story.md`. Here the Fight names four, so the first three fight and the fourth waits on the bench
to swap in.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Tawiri**: Ata, art/portraits/tawiri-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png

## Scene

**Place:** A village in Māla Iki, the night of a wake
**Background:** art/wiki/location/mala-iki-islands-2.webp
**Music:** where-the-winds-roam.mp3, calm-bay.mp3
**Card:** Old Pono died three days ago. Tonight his body got up and walked into the trees.

Lanterns drift up over the beach. Old Pono died three days ago, and the whole village has come to send him off.

**Kailo:** Pork, poi, sweet potato, and the stew's still hot. Nobody leaves Pono's wake hungry.

**Maika:** A wise man knows grief is best faced on a full stomach.

**Hina:** That's your third plate.

**Maika:** Fourth. The grief is very large tonight.

**Hina:** Show some respect. A man is dead.

A scream comes from Pono's house. His widow runs out onto the sand. Behind her, his sleeping mat is empty.

Something is moving into the trees. Stiff legged. Hopping.

**Kailo:** He was dead. I helped carry him!

**Hina:** Everyone stay calm. I am calm. I am completely calm.

**Tawiri:** Then stop squeaking, girl.

An old woman hobbles out of the dark on a staff hung with feathers and little skulls. The children scatter. Someone ran to the harbor for the Caller from Matua who has been staying there, and here she is.

**Tawiri:** Tawiri. Caller. I hear you've lost a dead man.

**Kailo:** Kawili?

**Tawiri:** Ta. Wi. Ri. You easterners sand the corners off everything.

**Kailo:** Matua's a long way from here.

**Tawiri:** I walk slow, and I've had a long time to do it. I was passing through.

**Hina:** Passing through to where?

**Tawiri:** Wherever the dead are misbehaving.

**Tawiri:** Listen. The dead stay put. That's the whole arrangement. Whatever got up off that mat, it isn't your Pono.

**Hina:** Then what is it?

**Tawiri:** Let's ask him.

She plants her staff and turns, slowly, once, twice. The lantern light bends around her. Old Pono stands beside her, pale and silent.

**Kailo:** Uncle Pono!

Pono says nothing. The dead never do. He looks at the trees, then points into them, and his face says exactly what he thinks of whoever is wearing his body.

**Tawiri:** He wants it back. Rude to keep a man waiting.

**Choice:** What does Kailo bring?
- A torch from the fire → torch
- The leftover pork → pork

**Kailo** (if torch): Light. Good. I want to see it before it sees me.

**Kailo** (if pork): If it's hungry, it can have the pork instead of me.

**Tawiri** (if pork): Ha! I like this one.

**Maika:** I'll guard the food. Someone must.

**Hina:** Maika.

**Maika:** A wise man knows three is plenty for one dead man. If it goes badly, call my name and I'll come running. After this plate.

Under the trees, Pono's body stands very still, stiff as a plank. Something small and grinning sits on its shoulder, steering it like a canoe.

**Tawiri:** An amaranhig. And a dwende riding it. Little wretch.

**Fight:** Kailo the Cook, Holy Hina, Granny Tawiri, Maika the Sage against Amaranhig (rot, Ata), Wicked Dwende (rot, Lau)

## If you win

The dwende shrieks and bolts into the dark. Pono's body tips over like a felled tree.

**Kailo:** Is he...

**Tawiri:** Dead. Properly, this time.

**Hina:** Shaka keep him. And Lanu. And whoever else is listening.

**Tawiri:** Moanatu is listening. He always is.

Pono stands over his body a moment longer. Then he turns and points out to sea. He keeps pointing for a long time.

**Kailo:** What's he pointing at?

Tawiri looks the same way. She doesn't say anything for a while.

**Tawiri:** Nothing for you to worry about tonight.

**Hina:** That's not an answer.

**Tawiri:** No. It isn't.

Pono fades. Back on the beach, the lanterns are still going up.

**Kailo** (if pork): Wait. Where's the pork?

**Maika** (if pork): Gone to a better place.

**Kailo:** Everyone back to the wake. There's still food.

**Maika:** There's a little less food.

**End:** The end of the second test scene.

## If you lose

Kailo wakes up on the sand with the lanterns going up over him. Tawiri is sitting beside him.

**Tawiri:** You fight like a man carrying soup.

**Kailo:** I usually am.

**Tawiri:** The village chased it into the sea with torches. Your Pono is floating out to the reef. I'll fetch him in the morning.

**Hina:** This is not funny.

**Tawiri:** Child, it's a little funny.

**End:** The end of the second test scene. Try again?
