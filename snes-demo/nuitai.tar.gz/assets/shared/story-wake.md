# The wake

The second story test, separate from the taro patch. `python game/shared/build.py` reads this file
and puts it on the menu of `game/browser/story.html`, beside the taro patch. A draft scene, not canon: Old Pono, his wake
and why Tawiri is in Māla Iki are made up (Frankie, 10/16: she travels and was in the
area; a deeper motive may come later). The rules for writing a script are at the top of
`story.md`. Here the Fight names four, so the first three fight and the fourth waits on the bench
to swap in.

Staged as Frankie played it (`game/answers.md`, "The wake, as played", 10/23): yes to Melia fades
out and the wake fades in beside the chief's house, the whole village there. The exchange about
Shaka and Lanu after the fight is Frankie's (10/23): the young get caught up in their faiths and the
old shrug, and Tawiri's line is the first hint. Claude's draft, for Frankie to rewrite: Pono's
wife's scream, the villager back from the harbor, Melia's question about the ocean and Kailo's "Come
on. There's still food." Everyone in the village is
eastern and says Makua for Matua (D-119); Tawiri, from Matua, says it her own way.

Since 10/25 (Frankie) the fight is at Pono's house, in its own room east of the chief's: his body
walks out of his door, and the foe is Pono's Corpse alone, no dwende, with a shadow and a spirit
stance. Claude restaged the lines around it (Maika's guarding the food comes before they go, and
Melia tags along), for Frankie to rewrite. After the fight his spirit walks down to the
shoreline and looks out to sea (Frankie, 10/25).

The kidnapping ending (Frankie's plan, 10/24, in `game/answers.md`; Claude's lines, 10/25, for
Frankie to rewrite): Kailo sends Melia home before the fight and she goes to sulk on the beach; a
short cut away to two pirates taking her; back at the wake Kailo notices she is gone, during the
argument, or, without Maika, when he goes to take her a plate; the search, her sling on the sand,
its stone gone, and boot prints (the east goes barefoot), her scream, the black sails, and Kailo running
into the sea. Not built yet: the pirates need walk sheets (Pirate and PirateTwo), and
`(if maika not along)` is a new condition the games do not read yet. The sling is Frankie's
(10/25), foreshadowed at the taro patch, where Kailo tells her to put it away.

On the map the actors are named for their walk sheets: Master is the chief, OldMan the old man of
the stall, FighterRed and FighterWhite the two who spar, Widow Pono's wife, Body his body, Spirit his
spirit (`game/pygame/tools/make_wake_sprites.py`).

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Tawiri**: Ata, art/portraits/tawiri-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png
- **Melia**: Lau, art/portraits/melia-portrait-a.png

## Scene

**Place:** A village in Māla Iki, the night of a wake
**Background:** art/wiki/location/mala-iki-islands-2.webp
**Music:** where-the-winds-roam.mp3, calm-bay.mp3
**Card:** Old Pono died three days ago. Tonight his body got up.

**Fade:** out
**Room:** beach_east
**Stand:** Kailo at 10,7 facing up; Hina at 9,7 facing right; Melia at 10,8 facing up; Master at 12,7 facing down; OldMan at 13,7 facing left; Boy at 14,7 facing left; FighterRed at 12,8 facing left; FighterWhite at 13,8 facing left
**Stand** (if maika along): Maika at 11,7 facing left
**Fade:** in

**Kailo:** Pork, poi, sweet potato, and the stew's still hot. Nobody leaves Pono's wake hungry.

**Maika** (if maika along): A wise man knows grief is best faced on a full stomach.

**Hina** (if maika along): That's your third plate.

**Maika** (if maika along): Fourth. The grief is very large tonight.

**Hina** (if maika along): Show some respect. A man is dead.

**Run:** Widow from the east edge to 14,11 to 14,8
**Turn:** Kailo, Hina, Maika, Melia, Master, OldMan, Boy, FighterRed, FighterWhite to Widow
**Turn:** Widow left

**Widow:** PONO! His mat is empty! He's gone!

**Kailo:** Gone? He was dead. I helped carry him!

**Run:** FighterWhite to 13,9 to 8,9 to 8,1 to the north edge

**Maika** (if maika along): I'll guard the food. Someone must.

**Hina** (if maika along): Maika.

**Maika** (if maika along): A wise man knows three is plenty for one dead man. If it goes badly, call my name and I'll come running. After this plate.

**Run:** Widow to 14,11 to the east edge; Kailo to 10,10 to 14,11 to the east edge; Hina to 9,10 to 14,11 to the east edge; Melia to 10,11 to the east edge
**Fade:** out
**Room:** pono_yard
**Stand:** Widow at 9,8 facing up; Kailo at 6,9 facing up; Hina at 5,9 facing up; Melia at 4,10 facing up
**Fade:** in
**Wait:** 0.5
**Walk:** Body from 7,5 to 7,7
**Turn:** Kailo, Hina, Melia, Widow to Body
**Wait:** 0.5

**Widow:** Pono?

**Run:** FighterWhite from the west edge to 3,10 to 3,9
**Turn:** Kailo, Hina, Melia to FighterWhite

**Villager:** I ran all the way to the harbor! The Caller from Makua is coming!

**Hina:** Everyone stay calm. I am calm. I am completely calm.

**Walk:** Tawiri from the west edge to 4,11 to 4,8
**Turn:** Kailo, Hina, Melia, Widow, FighterWhite to Tawiri

**Tawiri:** Then stop squeaking, girl.

**Turn:** Tawiri to Hina

**Tawiri:** Tawiri. Caller. I hear you've lost a dead man.

**Kailo:** Kawili?

**Turn:** Tawiri to Kailo

**Tawiri:** Ta. Wi. Ri. You easterners sand the corners off everything.

**Kailo:** Makua's a long way from here.

**Tawiri:** I walk slow, and I've had a long time to do it. I was passing through.

**Run:** Melia to 4,9
**Turn:** Melia up

**Melia:** Did you walk here on the ocean? All the way?

**Turn:** Tawiri to Melia
**Wait:** 1

**Hina:** Passing through to where?

**Turn:** Tawiri to Hina

**Tawiri:** Wherever the dead are misbehaving.

**Tawiri:** Listen. The dead stay put. That's the whole arrangement. Whatever got up off that mat, it isn't your Pono.

**Hina:** Then what is it?

**Tawiri:** Let's ask him.

**Turn:** Tawiri left
**Wait:** 0.25
**Turn:** Tawiri up
**Wait:** 0.25
**Turn:** Tawiri right
**Wait:** 0.25
**Turn:** Tawiri down
**Wait:** 0.25
**Turn:** Tawiri left
**Wait:** 0.25
**Turn:** Tawiri up
**Wait:** 0.25
**Turn:** Tawiri right
**Wait:** 0.25
**Turn:** Tawiri down
**Wait:** 0.5
**Stand:** Spirit at 9,6 facing down
**Turn:** Kailo, Hina, Melia, Widow, FighterWhite to Spirit
**Turn:** Tawiri right

**Kailo:** Uncle Pono!

**Turn:** Spirit to Body
**Wait:** 0.5

**Tawiri:** He wants it back. Rude to keep a man waiting.

**Turn:** Kailo to Melia

**Kailo:** Melia! What are you doing here? Go home!

**Melia:** But I want to see the Caller do magic!

**Kailo:** This isn't a show. Go home. Now!

**Wait:** 1

**Melia:** You never let me do anything!

**Run:** Melia to 4,11 to the west edge; Widow to 11,9 to 12,9
**Turn:** Hina to Kailo

**Hina:** Good. That thing won't care how little she is.

**Kailo:** She'll sulk it off. She always does.

**Walk:** Kailo to 6,8; Hina to 5,8; Tawiri to 4,8 to 7,8
**Turn:** Kailo, Hina, Tawiri up

**Tawiri:** An amaranhig. Older and angrier than most.

**Fight:** Kailo the Cook, Holy Hina, Granny Tawiri, Maika the Sage against Pono's Corpse (ponos_corpse, Ata, amaranhig)

## If you win

**Fall:** Body

**Kailo:** Is he...

**Tawiri:** Dead. Properly, this time.

**Walk:** Spirit to 9,11
**Turn:** Spirit down
**Wait:** 1

**Kailo:** What's he looking at?

**Turn:** Tawiri down
**Wait:** 1.5

**Tawiri:** Nothing for you to worry about tonight.

**Hina:** That's not an answer.

**Tawiri:** No. It isn't.

**Walk:** Spirit to the south edge
**Fade:** out
**Room:** beach_west
**Stand:** Melia at 7,10 facing down
**Fade:** in
**Wait:** 1

**Melia:** "Go home, Melia." "Do your chores, Melia." I'm not a baby.

**Walk:** Pirate from the west edge to 3,11; PirateTwo from -2,11 to 2,11
**Wait:** 0.5

**Pirate:** A girl, on her own, down by the beach.

**PirateTwo:** Smaller than I thought.

**Pirate:** Still. This looks like the girl.

**Turn:** Melia left

**Melia:** Who are you?

**PirateTwo:** Nobody, sweetheart. Nobody at all.

**Run:** Pirate to 6,11; PirateTwo to 2,10 to 6,10
**Fade:** out
**Room:** beach_east
**Stand:** Kailo at 10,7 facing up; Hina at 9,7 facing right; Tawiri at 8,7 facing right; Master at 12,7 facing down; OldMan at 13,7 facing left; Boy at 14,7 facing left; FighterRed at 12,8 facing left; FighterWhite at 13,8 facing left; Widow at 14,8 facing left
**Stand** (if maika along): Maika at 11,7 facing left
**Fade:** in

**Kailo:** Come on. There's still food.

**Maika** (if maika along): There's a little less food.

**Hina:** Shaka keep him.

**Maika** (if maika along): Lanu keeps him. He feeds her roots now, like all of us will.

**Turn** (if maika along): Hina to Maika

**Hina** (if maika along): And her roots drink Shaka's light. That's the whole teaching.

**Maika** (if maika along): Your teaching.

**Hina** (if maika along): (fast) Why do you sages always have to—

**Kailo** (if maika along): (fast) You guys...

**Turn** (if maika along): Tawiri to Hina

**Tawiri** (if maika along): Enough of your squabbling, children.

**Wait:** 1
**Turn** (if maika along): Kailo down

**Kailo** (if maika along): Where's Melia?

**Kailo** (if maika not along): I'll take Melia a plate. She'll be done sulking by now.

**Walk** (if maika not along): Kailo to 10,10
**Turn** (if maika not along): Kailo left
**Wait** (if maika not along): 1

**Kailo** (if maika not along): Melia?

**Turn:** Hina to Kailo

**Hina:** She went home. You sent her.

**Kailo:** She never goes home. She hides and waits for me to come find her.

**Kailo:** MELIA!

**Wait:** 1
**Fade:** out
**Room:** beach_west
**Stand:** Kailo at 10,8 facing left; Hina at 6,10 facing down; Tawiri at 12,9 facing down
**Stand** (if maika along): Maika at 4,8 facing left
**Fade:** in

**Kailo:** Melia! Come out! I'm not mad anymore!

**Hina:** Kailo. Over here.

**Run:** Kailo to 7,8 to 7,10
**Turn:** Kailo down
**Wait:** 1

**Kailo:** Her sling. I told her to put that thing away.

**Hina:** The stone's gone.

**Walk:** Tawiri to 8,9 to 8,10
**Turn:** Tawiri down

**Tawiri:** Then she hit something. Boot prints. Two men.

**Hina:** Nobody here wears boots.

**Melia:** KAILO!

**Turn:** Kailo, Hina, Tawiri down
**Turn** (if maika along): Maika down
**Wait:** 1

**Maika** (if maika along): Out there. Sails.

**Tawiri:** Black ones.

**Kailo:** Hold on, Melia! I'm coming!

**Hina:** Kailo, wait!

**Run:** Kailo to 7,12
**Fade:** out

**End:** TO BE CONTINUED

## If you lose

**Fall:** Kailo
**Wait:** 1
**Stand:** Kailo at 6,8 facing up

**Tawiri:** You fight like a man carrying soup.

**Kailo:** I usually am.

**Hina:** This is not funny.

**Tawiri:** Child, it's a little funny.

**End:** The end of the second test scene. Try again?
