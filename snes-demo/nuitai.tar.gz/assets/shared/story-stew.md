# Kohuapua

Kailo brings Noelani everything the stew needs, and the two of them make it at the pot in his
house (Frankie, 10/30). Kailo is the cook and leads; Noelani helps and does not teach him
(Frankie, 10/30). At its end Kailo is given the stew as a key item, **Kohuapua**. Every line
here is Claude's draft (10/30), for Frankie to rewrite, in Noelani's bossy older-cousin voice and
Kailo's terse one. The pygame game plays it. How to write a script is at the top of `story.md`.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png

## Scene

**Noelani:** Not on the floor, Kailo! The boars had better manners.

**Kailo:** Pot. Fire.

**Noelani:** Fire's already going. You're slow today.

**Kailo:** Pork and niu first.

**Noelani:** Chopped. Don't look at me like that, I'm helping.

**Kailo:** Eggs. Fish. 'Awapuhi, soy sauce.

**Noelani:** Look at you, so gentle with an egg. Pity the boars weren't.

**Kailo:** 'Uala. Cover it. Let it braise.

**Noelani:** I'll mind the fire. You stand there and look important.

**Kailo:** Green onion last.

**Noelani:** Pono used to sneak a taste right about now. Every time.

**Kailo:** ...He thought I didn't see.

**Noelani:** He saw you seeing. Go on, taste.

**Kailo:** ...Good. He'd have had three bowls.

**Noelani:** Then take it to him. And keep it away from the boars.

**End:** Kailo has the stew.
