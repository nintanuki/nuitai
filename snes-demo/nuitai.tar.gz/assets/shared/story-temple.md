# The temple of Mauga

The third story test, rewritten 10/20 from why everyone is there (D-664): Melia is sick, the
fireflower that would cure her grows only in Mauga's crater, the chief says no, and the party sneaks
in anyway, so Olola's anger is fair. Damar walks in, and his contempt for Mauga is what turns her on
him. The tablet of the first draft is gone; Kailo will learn Lelua from Olola herself. The rules for writing a script are at the top of
`story.md`; this one adds four:

- `**Pick:**` lets the player choose the party: how many, then the names, with `(always)` on anyone
  who must come. The first three picked fight, the fourth waits on the bench. Each one picked turns on
  a flag with their short name, so `**Maika** (if Maika):` plays only if Maika came.
- `**Fight:** the party` fights with whoever was picked; `with Olola` adds a guest the player can
  neither control nor swap out.
- `**Go to:** a heading` jumps there, so both ends of a fight can meet again.
- `## Foes` writes enemies that are not in `battle.json`: element, HP, `boss`, a picture, then their
  moves as `kind, element, power`, with `all`, `warmup N` or `weight N` after if needed.

A fight's `If you win` and `If you lose` are the next headings after it that start with those words.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Melia**: Ahi, art/portraits/melia-portrait-a.png
- **Gen'emon**: Wai, art/portraits/genemon-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Tawiri**: Ata, art/portraits/tawiri-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png
- **Sarjana**: La, art/portraits/sarjana-portrait-a.png
- **Olola**: Ahi, art/portraits/olola-portrait-a.png
- **Damar**: La, art/portraits/jago-portrait-a.png

## Foes

- **Olola**: Ahi, 420, boss, art/portraits/pixel/olola.png
- Fire Spin: magic, ahi, 16, all, weight 2
- Flying Kick: physical, ahi, 24, weight 3
- Ember Lash: physical, ahi, 18, weight 3
- Wildfire: magic, ahi, 30, all, warmup 3, weight 1
- **Damar**: La, 520, boss, art/portraits/pixel/jago.png
- Sunblade: physical, la, 26, weight 3
- Judgement: magic, la, 32, warmup 3, weight 1
- Purging Flame: magic, ahi, 18, all, weight 2

## Scene

**Place:** Velafi, a borrowed hut below the mountain, night
**Background:** art/wiki/location/velafi-1.webp
**Music:** goblins-den.mp3
**Card:** Melia is burning with fever. The one flower that could save her grows inside Mauga's mountain, and outsiders may not go in.

Melia hasn't woken properly since the boat. Her forehead is hot under Kailo's hand, hotter than it was this morning.

**Kailo:** She hasn't eaten since Lanuloa. Not even broth.

**Gen'emon:** The fever came off the pirate ship with her. My medicine holds it back. It does not send it away.

**Kailo:** Then what does?

**Gen'emon:** Fireflower. It grows in one place in the world, on the inside wall of Mauga's mountain. A tea of the petals breaks a fever like this in a night.

**Kailo:** And the chief said no.

**Gen'emon:** The chief said the mountain is Mauga's house, and Mauga does not open her house to strangers. He was not unkind about it.

**Kailo:** He doesn't have to sit here and watch her.

Melia stirs.

**Melia:** Kailo? Is it morning?

**Kailo:** Not yet. Go back to sleep. I'm going to get you something.

**Melia:** Bring food.

**Kailo:** I always bring food.

**Gen'emon:** If you go up there tonight, you go as thieves. You understand that.

**Kailo:** I understand.

**Gen'emon:** Then go quietly. I will stay and keep her cool.

**Pick:** 4 from Kailo the Cook (always), Holy Hina, Granny Tawiri, Maika the Sage, Prof. Sarjana

**Place:** Velafi, the temple of Mauga

Black sand, then black steps cut into the side of the mountain. At the top, the temple of Mauga breathes heat like an open oven. Nobody is on the steps. Nobody is supposed to be.

**Tawiri** (if Tawiri): Sneaking into a goddess's house in the dark. I've done stupider things. Not many.

**Maika** (if Maika): Lanu forgive us. And Mauga, if she's in a forgiving mood.

**Sarjana** (if Sarjana): For the record, I'd have asked the chief again in the morning. Politely. With gifts.

**Hina** (if Hina): We're breaking their law, Kailo. Whatever happens up there, we earned it.

**Kailo:** I know. She might not have a morning.

Inside, the hall runs straight into the crater wall. Torches line it. At the far end, a doorway of black rock lets in red light and the smell of sulfur, and through it, on the crater wall, small flowers glow orange like coals.

**Kailo:** There. That's them.

**Olola:** Stop.

A woman steps out of the dark beside the doorway, barefoot, painted in red and black. She was dancing alone. Fire still clings to her wrists.

**Olola:** Mauga's floor. In the middle of the night. In sandals.

**Kailo:** We're not...

**Olola:** I know what you are. The chief turned away a boat of outsiders this morning. Tonight the outsiders are in the temple.

**Hina** (if Hina): Please. Let us explain.

**Olola:** If you had a good reason, you would have come in daylight.

**Choice:** What does Kailo do?
- Tell her about Melia → truth
- Run for the flowers → run

**Kailo** (if truth): My sister is sick. She's eight. Our healer says fireflower is the only thing that...

**Olola** (if truth): Every thief has a sick sister. Mauga has heard that one before.

**Kailo** (if run): Sorry! I'm really sorry!

**Olola** (if run): That's the crater, boy. Touch a fireflower without knowing how and it's ash before you close your hand.

Olola rolls her shoulders. Every torch along the wall leans toward her, as if she called it.

**Olola:** You walked into my goddess's house like it was yours. I'm going to throw you out of it.

**Fight:** the party against Olola (Olola, Ahi)

## If you win against Olola

Olola drops to one knee, smoking. Then she laughs, and the fire crawls back up her arms.

**Olola:** Good. You can fight. Now get up and fight properly.

**Go to:** Damar arrives

## If you lose against Olola

The party is down. Olola stands over Kailo with fire in both hands.

**Kailo:** Please. She's eight.

Olola doesn't move. For a moment, neither does the fire.

**Go to:** Damar arrives

## Damar arrives

Boots ring on the stone behind them.

**Damar:** So this is where you ran.

A man in white and gold walks in from the doorway. The sun of Shaka on his chest catches the firelight.

**Kailo:** Not you again.

**Tawiri** (if Tawiri): Half the sea, and he's still behind us. I've had shorter marriages.

**Damar:** You can't hide from the light. Even here, in a hole in a mountain, with a woman who dances for rocks.

**Olola:** Take off your boots.

**Damar:** I don't take off my boots for a pile of stone.

The temple goes quiet. Even the torches stop moving.

**Olola:** These ones came in the dark, ashamed, and asked to explain. You stomp in and insult her to her face.

**Olola:** Outsiders. Get up. You've stopped being my problem.

**Hina** (if Hina): You're fighting with us?

**Olola:** I'm fighting him. Stand wherever you like.

**Damar:** Then you all burn together, in the light.

**Fight:** the party with Olola against Damar (Damar, La)

## If you win against Damar

Damar backs out through the doorway, his white robes scorched black at the hem.

**Damar:** This isn't finished.

**Olola:** Come back barefoot and we'll finish it.

The hall is quiet. Olola turns to Kailo.

**Olola:** Your sister. Tell me.

**Kailo:** Melia. Pirates took her. By the time we got her back she was already sick. Six days now. She can't keep broth down.

**Olola:** And your healer says fireflower.

**Kailo:** He says it's the only thing.

Olola looks out at the crater for a long time.

**Olola:** He's right. And you'd have killed it. Pick it wrong and it's ash in your hand before you're down the mountain.

**Kailo:** Then how do we get it?

**Olola:** The hunters. Mauga lets them gather it, and they know how to carry it home. Go to their village at first light. Tell them Olola sent you.

**Hina** (if Hina): Thank you. Truly.

**Olola:** Don't thank me. I'd still have burned you.

**Kailo:** That thing you do. The fire, the way you move. Could you teach me?

**Olola:** You? You fight like a cook.

**Kailo:** I am a cook.

**Olola:** Get the flower. Make your sister well. Then come back up here in daylight, through the front, barefoot, and ask me again.

**End:** The hunters have the flower. Olola will be waiting.

## If you lose against Damar

Light floods the hall, white and blinding, and the torches gutter out one by one.

**Damar:** Pray it was worth it.

**End:** The light wins tonight. Try again?
