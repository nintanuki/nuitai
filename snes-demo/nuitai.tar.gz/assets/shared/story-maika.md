# Maika

Maika sells medicine at the market stall in the blocks room (Frankie, 10/25; was the crossroads), and joins only if the player buys
something (Frankie, 10/22). Meeting him is a scene with faces, not straight into his shop (Frankie,
10/23). The games play it; the browser's story page does not. How to write a script is at the top
of `story.md`. Nobody walks: the lines play where everyone stands.

This file is four small scenes, each under its own heading, and the games play each one at its
moment:

- **The scene** when Kailo first talks to Maika. Then his shop opens.
- **If you buy**, when the shop closes with something bought. At its end Maika joins, with his
  pop-up ("Maika joined the party. While he is in your party, shops charge less."), and his shop is
  gone.
- **If you leave**, when the shop closes with nothing bought. Talking to him again opens the shop
  straight away.
- **The first planting**, right after the party replants a garden patch with both Maika and Hina
  along (Frankie, 10/24; it was walking into the Great Boar's room, 10/23), which gives his talk of
  gardening its reason. Once. Without Maika, or without Hina, it does not play.

`(if hina)` plays only with Hina in the party, `(if alone)` only with Kailo by himself (Maika is
not along yet in his first three).

Claude's drafts, for Frankie to rewrite (10/23): every line here except "Lost? Everyone who finds
me is lost.", "So what brings you all the way out here?", Kailo's "...going after the Great Boar.",
"The Great Boar? He's the other way. You went the wrong way.", Maika's "A wise man never lets a good
customer get lost. I'll come with you." and Maika's Seed line, which are Frankie's from before.
Hina's answer to it is Claude's draft (10/24).

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png

## Scene

**Maika:** Lost? Everyone who finds me is lost.

**Maika** (if hina): But not everyone who finds me is so lovely. 'Awapuhi, miss? Pressed from the ginger flower this morning. Your hair would shine like moonlight on the reef.

**Hina** (if hina): My hair shines just fine on its own.

**Maika** (if alone): These woods are dangerous for a man alone. A wise man buys medicine.

**End:** His shop opens.

## If you buy

**Maika:** So what brings you all the way out here?

**Kailo** (if hina): We're going after the Great Boar.

**Kailo** (if alone): I'm going after the Great Boar.

**Maika:** The Great Boar? He's the other way. You went the wrong way.

**Maika** (if hina): A wise man never lets a lovely lady get lost. I'll come with you.

**Hina** (if hina): Then walk behind us.

**Maika** (if alone): A wise man never lets a good customer get lost. I'll come with you.

**End:** Maika joins.

## If you leave

**Maika:** Come back if you get hurt.

**End:** The shop stays.

## The first planting

**Maika:** Hina, you garden? Here. Plant this on a friend.

**Hina:** On a friend? Fine. But I'm not watering Kailo.

Hina learned Seed!

**End:** Back to the garden.
