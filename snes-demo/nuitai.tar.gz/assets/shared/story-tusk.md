# Melia's tusk

By day Melia asks Kailo to bring her back a tusk from the Great Boar (her lines in
`game/pygame/data/cells/beach_west.json`, in front of Kailo's house). The Great Boar always drops one, a key item, and at night,
the first time Kailo talks to her with it in the bag, he gives it to her: a happy moment just before
she is taken (Frankie's idea, Claude's lines, 10/25, for Frankie to rewrite). She no longer asks
about the wake; after the scene she has a plain night line, and giving her the tusk is what lets
Hina ask about the wake in the chief's room (Frankie, 10/25). The games play it; the browser's story
page does not. How to write a script is at the top of `story.md`.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Melia**: Lau, art/portraits/melia-portrait-a.png

## Scene

**Kailo:** Hold on. Close your eyes and hold out your hands.

**Melia:** Why? Is it a frog? It better not be a frog.

**Kailo:** It's not a frog.

**Melia:** A tusk! A real one! From the Great Boar?

**Hina** (if hina along): We took him down together, you know.

**Kailo:** You asked for one, didn't you?

**Melia:** I'm going to wear it on a string. Forever!

**End:** Melia has her tusk.
