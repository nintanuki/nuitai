# Melia's tusk

By day Melia asks Kailo to bring her back a tusk from the Great Boar (her lines in
`game/pygame/data/cells/beach_west.json`, in front of Kailo's house). The Great Boar always drops one, a key item, and
the first time Kailo talks to her with it in the bag, by day or at night, he gives it to her: a happy
moment before she is taken (Frankie's idea, Claude's lines, 10/25, for Frankie to rewrite; by day too,
Frankie 11/5). Giving it is not needed for the wake (Frankie, 11/5): if he never does, it stays in the
bag and the beach has only her sling. Either way it is back in the bag, a key item, the morning after. The games play it. How to write a script is at the top of `story.md`.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Melia**: Lau, art/portraits/melia-portrait-a.png

## Scene

**Kailo:** Hold on. Close your eyes and hold out your hands.

**Melia:** Why? Is it a frog? It better not be a frog.

**Kailo:** It's not a frog.

**Melia:** A tusk! A real one! From the Great Boar?

**Hina** (if hina along): We took him down together, you know.

**Kailo:** You asked for one, didn't you?

**Melia:** Mahalo e Kailo! I'm going to wear it on a string. Forever!

**End:** Melia has her tusk.
