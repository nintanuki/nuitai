# Field lines

The words said on the field, outside the story scenes: Noelani and the stew, the garden, the
hens, digging, fishing, the shops and the rest. They were in the game's settings; since 10/31
they are here, with the scenes, so every line of dialogue is in one place (Frankie). The Workshop's
lines window (L) edits them like a scene.

How to write it:

- `- OFFER_LINES` is the name the game reads the lines under it by. Keep the names as they are.
- A name ending in LINES can have several lines, said in order. Any other name has exactly one.
- `- EDGE_LINES harbor` is one line for one place or one person.
- `**Noelani:** line` shows who says it. Who says a field line is decided by the game, so changing
  the name here does not change the speaker. A line with no name is narration, or said by
  whoever is being talked to (the meal orders, the shop's greeting).
- Words in curly brackets, like `{things}`, are filled in by the game. Keep them.

## Chopping and picking

- WOOD_LINE
Got {count} wood.

- FRUIT_LINE
A {item} fell from the tree.

- ROOT_LINE
Found some {item} under the tree.

## The shops

- BUY_LINE
Aloha! Help yourself!

- SELL_LINE
What'll you sell?

- SOY_HINT_LINES
**Kailo:** A thousand pule?! I don't have that. Nobody does.
**Kailo:** I'll have to find soy sauce some other way.

## The village

- WATCH_LINES
By watching the villagers spar, Kailo learned a few tricks.
Kailo's strength and agility went up.

- NAP_LINE
The party recovered HP.

- POND_LINE
The party drinks from the cool pond. Everyone is rested.

- PRAY_LINE
The party kneels at the totem and tells the Akua all that has happened.

- REVIVE_LINE
The fallen are back on their feet.

- EDGE_LINES harbor
The rocks are too sharp to climb, and the tide's coming in. Better turn back.

## The hens

- EGG_LINE
Kailo found an Egg.

- NO_EGG_LINE
The hen clucks. No egg yet.

## Fishing

- CAUGHT_LINE
Kailo caught a Fish.

- MISS_LINE
It got away.

- NORI_LINE
Kailo hooked a tangle of Nori.

- PULE_LINE
Kailo reeled in a string of {pule} pule.

## Digging

- FOUND_LINE
Kailo dug up {item}.

- NOTHING_LINE
Kailo dug, but found nothing.

- AGAIN_LINE
Kailo already dug here.

- VILLAGE_LINE
Hey! Don't dig up the village!

- GRASS_LINE
The roots are too thick. Sand digs easier.

## Noelani and the stew

- OFFER_LINES
**Noelani:** I heard what happened. The boars, the pot, all of it. I'll help you cook it. Don't make that face.
**Noelani:** So what goes in?

- LIST_LINE
**Kailo:** {things}.

- SEND_LINES
**Noelani:** That's a lot. Then go and get it, the wake isn't going to wait. I'll clean up this mess and get the fire ready.

- MISSING_LINE
**Noelani:** Still missing: {things}.

- AFTER_LINE
**Noelani:** Kohuapua's done. Take it to the wake, and don't you dare drop it.

- DUSK_LINE
The sun is going down. Time for Old Pono's wake.

## Nori

- FOUND_LINE
Kailo found some Nori washed up on the sand.

- NOTHING_LINE
Just foam and sand.

## The garden

- ABILITY_DONE_LINE
Maika does the Maki Hula.

- GROWING_LINE
It is still growing.

- NEEDS_HINA_LINE
This soil can be replanted, but you're bad at gardening.

- NO_SEED_LINE
You need a {item} or a {crop} to plant it.

- ABILITY_LINE
It will grow faster now.

- NO_FARM_SEED_LINE
You need a seed or a crop to plant here.

- WAIT_LINE
**Hina:** It takes a while to grow. Let's go do something else instead of standing here waiting.

- HINA_OFFER_LINE
**Hina:** Don't leave it bare. It should be replanted. I'll show you how.

- MAIKA_OFFER_LINE
**Maika:** Let a wise man dance. My nature magic will make it grow faster.

## Cooking and crafting

- FIND_LINES
Put two together
to find a new recipe.

- WITH_LINE
Put {item} with what?

- PUT_BACK_LINE
B puts it back.

- MADE_LINE
Made {item}.

- NEW_RECIPE_LINE
A new recipe!

- NO_MIX_LINES
Those don't go together.
Both are lost.

- ONLY_ONE_LINE
There is only one {item}.

- AWAY_LINE
{crafter} would know about these.

- EMPTY_LINE
Nothing here goes in the pot.

- PICK_LINE
Put two things in the pot.

- NO_MIX_LINE
Those don't go together.

- WATER_LINE
Kailo scoops up some fresh water.

- HEAVY_LINE
**Kailo:** Oof. These canteens are getting heavy.

- REST_LINE
**Kailo:** Let me catch my breath first.

- FULL_LINE
Kailo can't carry any more water.

## Meal orders

- HINT_LINES
I could really go for some {meal} today.
Been thinking about {meal} all morning.
Nothing beats {meal}. ...Not that I have any.
My stomach keeps asking for {meal}.

- ASK_LINE
Is that {meal} on you, Kailo? Could I have it?

- THANKS_LINE
Mahalo! That smells so good.

- GAVE_LINE
Kailo gave away the {meal}.

- ORDERS_ASK
Orders

- PRICES_ASK
Pay {page}/{pages}

- NONE_LINE
No orders at the window.

- MISSING_LINE
No {meal} in the bag.

- SOLD_LINE
Kailo delivered the {meal} to {who} and got {price} pule.

## Joining the party

- JOIN_LINES hina
While she is in your party, the fallen get back up after a win.

- JOIN_LINES maika
While he is in your party, shops charge less.

- JOIN_LINES tawiri
While she is in your party, stats grow faster.

- FIRST_LINES hina
**Hina:** Up, all of you. I'm not carrying anyone home.

- FIRST_LINES kailo
**Kailo:** Eat up. Nobody fights on an empty stomach.

## Between the scenes

- WAKE_GIFT_LINE
Kailo received {item}.

- SISTER_SOY_LINE
Kailo got Māla Shoyu!

- JOINED_SHOP_LINE
Still want to buy something, Kailo?

- ASK_LINE
**Hina:** Ready to go to Pono's wake?

- WAKE_JOIN_LINE
Tawiri joined the party. While she is in your party, stats grow faster.
