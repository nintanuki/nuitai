# Field lines

The words said on the field, outside the story scenes: Noelani and the stew, the garden, the
hens, digging, fishing, the shops and the rest. They were in the game's settings; since 10/31
they are here, with the scenes, so every line of dialogue is in one place (Frankie). The Workshop's
lines window (L) edits them like a scene.

How to write it:

- `- OFFER_LINES` is the name the game reads the lines under it by. Keep the names as they are.
- A name ending in LINES can have several lines, said in order. Any other name has exactly one.
- `- EDGE_LINES harbor` is one line for one place or one person.
- `**Noelani:** line` shows who says it. Who says a field line is decided by the game, so changing
  the name here does not change the speaker. A line with no name is narration, or said by
  whoever is being talked to (the meal orders, the shop's greeting).
- Words in curly brackets, like `{things}`, are filled in by the game. Keep them.

## The opening cards

- BLURB_LINES
In a world covered by endless ocean, people live on scattered islands, venturing across the waves at their own peril.
Sea monsters lurk beneath the surface, unpredictable storms swallow ships, and miracles and strange wonders are commonplace.
It is a world as beautiful as it is deadly...
Far to the northeast lies a small, verdant island, untouched by the troubles of the wider world. Here live a warmhearted young cook and a headstrong, devout priestess...

## Chopping and picking

- WOOD_LINE
Got {count} wood.

- FRUIT_LINE
A {item} fell from the tree.

- ROOT_LINE
Found some {item} under the tree.

- VILLAGE_CHOP_LINE
Hey! Don't chop down the village trees!

## The shops

- BUY_LINE
Aloha! Help yourself!

- SELL_LINE
What'll you sell?

- SOY_HINT_LINES
**Kailo:** A thousand pule?! I don't have that. Nobody does.
**Kailo:** I'll have to find soy sauce some other way.

## The village

- WATCH_LINES
By watching the villagers spar, Kailo learned a few tricks.
Kailo's strength and agility went up.

- NAP_LINE
The party recovered HP.

- POND_LINE
The party drinks from the cool pond. Everyone is rested.

- PRAY_LINE
The party kneels at the totem and tells the Akua all that has happened.

- REVIVE_LINE
The fallen are back on their feet.

- EDGE_LINES harbor
The rocks are too sharp to climb, and the tide's coming in. Better turn back.

## The hens

- EGG_LINE
Kailo found an Egg.

- NO_EGG_LINE
The hen clucks. No egg yet.

## Fishing

- CAUGHT_LINE
Kailo caught a {fish}.

- MISS_LINE
It got away.

- NIBBLE_LINE
Just a nibble. Nothing on the hook.

- NORI_LINE
Kailo hooked a tangle of Nori.

- PULE_LINE
Kailo reeled in a string of {pule} pule.

- REEL_HINT
Roll the D-pad to reel it in!

- ESCAPED_LINE
It got off the hook.

- RARE_LINE
Kailo hooked something: {item}!

## Digging

- FOUND_LINE
Kailo dug up {item}.

- NOTHING_LINE
Kailo dug, but found nothing.

- AGAIN_LINE
Kailo already dug here.

- VILLAGE_LINE
Hey! Don't dig up the village!

- GRASS_LINE
The roots are too thick. Sand digs easier.

## Noelani and the stew

- OFFER_LINES
**Noelani:** I heard what happened. The boars, the pot, all of it. I'll help you cook it. Don't make that face.
**Noelani:** So what goes in?

- LIST_LINE
**Kailo:** {things}.

- SEND_LINES
**Noelani:** That's a lot. You fetch, I'll clean up this mess and get the fire going. Deal?

- MISSING_LINE
**Noelani:** Still missing: {things}.

- AFTER_LINE
**Noelani:** Kohuapua's done. Drop it on the way and I'm telling the whole village.

- DUSK_LINE
The sun is going down. Time for Old Pono's wake.

## Noelani and the pule

Noelani keeps pule for Kailo. From her second talk on she says one of her own lines (the house
lines in `kailo_house`), then what is here, and a menu opens. Claude's drafts (11/2) for Frankie to rewrite.

- BANK_LEAD_LINE
**Noelani:** And look at that pouch of yours, it's stuffed. Leave me what you don't need and I'll keep it in the jar. I won't even spend it. Much.

- BANK_WHAT_LINE
**Noelani:** What is it, Kailo? I'm elbow deep in something.

- INGREDIENTS_CHOICE
How many ingredients do I have?

- STEW_READY_CHOICE
Ok, I have everything we need.

- STEW_CHOICE
About the stew

- PULE_FIRST_CHOICE
Can you hold some pule for me?

- PULE_CHOICE
About the pule you're holding for me

- NEVER_CHOICE
Never mind

- NEVER_LINE
**Noelani:** Mm-hm. You know where I am.

- BANK_ASK
**Noelani:** I'm holding {held} for you. Want to leave some, or take some back?

- BANK_CHOICES_LINES
Leave pule
Take pule
Never mind

- LEAVE_ASK
How much?

- LEAVE_CHOICES_LINES
10
100
All of it
Never mind

- TAKE_ASK
How much?

- TAKE_CHOICES_LINES
10
100
All you can carry
Never mind

- LEFT
**Noelani:** I'll keep it safe. That's {held} pule with me.

- TOOK
**Noelani:** Here. That leaves {held} pule with me.

- NONE_LEFT
**Noelani:** You've got nothing on you to leave, Kailo.

- NONE_HELD
**Noelani:** I'm not holding anything for you.

- FULL
**Noelani:** Your pouch is already full.

## Nori

- FOUND_LINE
Kailo found some Nori washed up on the sand.

- NOTHING_LINE
Just foam and sand.

## The garden

- ABILITY_DONE_LINE
Maika does the Maki Hula.

- GROWING_LINE
It is still growing.

- NEEDS_HINA_LINE
This soil can be replanted, but you're bad at gardening.

- NO_SEED_LINE
You need a {item} or a {crop} to plant it.

- ABILITY_LINE
It will grow faster now.

- NO_FARM_SEED_LINE
You need a seed or a crop to plant here.

- WAIT_LINE
**Hina:** It takes a while to grow. Let's go do something else instead of standing here waiting.

- HINA_OFFER_LINE
**Hina:** Don't leave it bare. It should be replanted. I'll show you how.

- MAIKA_OFFER_LINE
**Maika:** Let a wise man dance. My nature magic will make it grow faster.

## Cooking and crafting

- FIND_LINES
Put two together
to find a new recipe.

- FIND_THREE_LINES
Put up to three in
to find a new recipe.

- WITH_LINE
Put {item} with what?

- COOK_ROW
Cook

- ADD_LINE
Add more, or pick Cook.

- PUT_BACK_LINE
B puts it back.

- MADE_LINE
Made {item}.

- NEW_RECIPE_LINE
A new recipe!

- NO_MIX_LINES
Those don't go together.
Both are lost.

- DUBIOUS_LINES
Those don't go together.
Kailo made... something.

- ONLY_ONE_LINE
There is only one {item}.

- AWAY_LINE
{crafter} would know about these.

- EMPTY_LINE
Nothing here goes in the pot.

- PICK_LINE
Put two things in the pot.

- NO_MIX_LINE
Those don't go together.

- WATER_LINE
Kailo scoops up some fresh water.

- HEAVY_LINE
**Kailo:** Oof. These canteens are getting heavy.

- REST_LINE
**Kailo:** Let me catch my breath first.

- FULL_LINE
Kailo can't carry any more water.

## Meal orders

- HINT_LINES
I could really go for some {meal} today.
Been thinking about {meal} all morning.
Nothing beats {meal}. ...Not that I have any.
My stomach keeps asking for {meal}.

- ASK_LINE
Is that {meal} on you, Kailo? Could I have it?

- THANKS_LINE
Mahalo! That smells so good.

- GAVE_LINE
Kailo gave away the {meal}.

- ORDERS_ASK
Orders

- PRICES_ASK
Pay {page}/{pages}

- NONE_LINE
No orders at the window.

- MISSING_LINE
No {meal} in the bag.

- SOLD_LINE
Kailo delivered the {meal} to {who} and got {price} pule.

## Joining the party

- JOIN_LINES hina
While she is in your party, the fallen get back up after a win.

- JOIN_LINES maika
While he is in your party, shops charge less.

- JOIN_LINES tawiri
While she is in your party, stats grow faster.

- FIRST_LINES hina
**Hina:** Up, all of you. I'm not carrying anyone home.

- FIRST_LINES kailo
**Kailo:** Eat up. Nobody fights on an empty stomach.

## Between the scenes

- WAKE_GIFT_LINE
Kailo received {item}.

- SISTER_SOY_LINE
Kailo got Māla Shoyu!

- JOINED_SHOP_LINE
Still want to buy something, Kailo?

- ASK_LINE
**Hina:** Ready to go to Pono's wake?

- WAKE_JOIN_LINE
Tawiri joined the party. While she is in your party, stats grow faster.

## Landing

- DEMO_END_LINE
This is the end of the demo. The rest of Nuitai is still under construction, but feel free to keep exploring.
