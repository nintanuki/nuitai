# The Maki Sages' village

East of the room where Maika is met, a sand path runs out past the spiral tree to the Maki Sages'
village, which cannot be entered (Frankie, 10/26). Stepping into the opening, Kailo is stopped and
the party walks back a tile. With Maika in the party, on the bench or not, he says it; before he
joins he is still at his stall in that room, and calls it from there (Claude's call, 10/26). It
plays every time. Nobody else walks: the lines play where everyone stands.

The games play it. How to write a script is at the top of
`story.md`. Every line here is Claude's draft, for Frankie to rewrite (10/26).

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png

## Maika along

**Maika:** That's my friends' village. They don't welcome visitors.

**Maika:** They'd turn you around very kindly. It's quicker if I do it.

**Kailo:** ...fine.

**End:** Back to the field.

## Maika at his stall

**Maika:** Not that way. My friends live down that path, and they don't welcome visitors.

**Kailo:** How did you even see me from there?

**Maika:** You're not quiet.

**End:** Back to the field.
