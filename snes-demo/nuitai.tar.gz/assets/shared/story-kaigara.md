# Kaigara

Gajumaru, the Kame in the hunters' lodge, plays Kaigara, the Kame shell game, with anyone who asks
(`game/answers.md`, the Kaigara line, Frankie 10/26 and 10/27). He sits at a low table beside the
barrel, his board on it, and never walks. His name is Okinawan for the banyan tree. Until he has a
face of his own he borrows Gen'emon's pixel one (Kame have no beards, so not the painted portrait).
Both games play these; the cartridge compiles them after its demo scenes (10/27). The board itself is `game/pygame/core/scenes/kaigara_scene.py`. How to write a script is at
the top of `story.md`. Nobody walks: the lines play where everyone stands.

He talks REALLY slowly (Frankie, 10/26). `(slow)` before a line types it out at a crawl, and the
button cannot hurry it; it only turns the page once every letter is out. Every Gajumaru line is
slow, and he talks in pieces with dots between them.

The scenes, each under its own heading, and when the game plays them:

- **The scene**, the first time Kailo talks to him. It finds the Kame's Lore page.
- **His questions**, after meeting him and every time Kailo talks to him after: Play, three
  questions, and Leave. Play opens the board. A question plays its answer, then the questions come
  back; a question can be asked again, and its Lore pages are found the first time.
- **Where he is from** finds the Kame Kingdom; **How he got here** Kota Emas and the Bandari (not
  Bandar); **What Kaigara is** Kaigara.
- **The first win**, when the player beats him the first time. He gives the kupang, the game's
  first (Frankie, 10/27). The kupang goes in the bag as the scene starts.
- **You win**, **He wins** and **A draw**, after any other game. A game resigned is one he wins.

Playing him, won or lost, finds Kaigara's page too if it is not found yet. Bandar, the Bandari and
the Kame Kingdom are also found the moment any line in these scenes names them (`game/shared/lore.md`,
`named`).

`(if hina)` plays with Hina in the party, `(if maika)` with Maika but not Hina, `(if alone)` with
Kailo by himself; `(if maika along)` whenever Maika is in the party, `(if hina not along)` whenever
Hina is not, and `and` joins two (`(if maika along and hina along)`). Hina is not always along: she
goes home after the taro patch until Kailo fetches her, and the lodge is open the whole time.

**Frankie's, approved 10/27:** the meeting and the three answers; the lines after Play ("Take... your...
time...") and Leave ("I will... be... right... here..."), and black going first told in the rules. **Claude's drafts, for Frankie to
reword (10/27):** "I am... Gaju... maru..."; Kailo's "Maika." and "Years?" when Hina is not along to
say them; the first win; You win, He wins and A draw.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png
- **Gajumaru**: art/portraits/draw/gajumaru-closeup.png

## Scene

**Gajumaru:** (slow) Ahh... a... visitor...

**Gajumaru:** (slow) I am... Gaju... maru...

**Gajumaru:** (slow) Do you... know... Kaigara...?

**Kailo:** Kai-what?

**Gajumaru:** (slow) Kai... ga... ra...

**Maika** (if maika along): Sorry, I didn't catch that. Can you repeat it?

**Hina** (if maika along and hina along): Maika.

**Kailo** (if maika along and hina not along): Maika.

**Maika** (if maika along): What? I'd love to hear the entire history of Kaigara.

**Gajumaru** (if maika along): (slow) Ahh... it began... long... ago...

**Kailo** (if maika along): Maika, please.

**Gajumaru:** (slow) Shells... and... patience...

**Gajumaru:** (slow) Sit... I will... teach you...

**End:** His questions.

## His questions

**Choice:** Gajumaru

- Play → play
- Where are you from? → home
- How did you get here? → trip
- What is Kaigara? → what
- Leave → leave

**Gajumaru** (if play): (slow) Take... your... time...

**Gajumaru** (if leave): (slow) I will... be... right... here...

**End:** Play opens the board; a question, its answer.

## Where he is from

**Gajumaru:** (slow) Kami Kuku... the Kame Kingdom...

**Gajumaru:** (slow) Far... to the northwest... green islands... clear springs...

**Gajumaru:** (slow) Great turtles... swim there... older than... anyone...

**Gajumaru:** (slow) We heal... the sick... with what... the springs give...

**End:** His questions.

## How he got here

**Gajumaru:** (slow) A Bandari... trader... from Kota Emas...

**Gajumaru:** (slow) My friend... Gin'imun... and I... rode with him...

**Gajumaru:** (slow) His ship... was fast... too fast...

**Gajumaru:** (slow) He sold... his goods... and left... without us...

**Gajumaru:** (slow) Gin'imun... swam on... to Māla Iki...

**Kailo:** Your friend just left you here?

**Gajumaru:** (slow) I was... still... thinking... about my move...

**End:** His questions.

## What Kaigara is

**Gajumaru:** (slow) Black shells... white shells... a chalk grid...

**Gajumaru:** (slow) Surround... the other's shells... and they are... yours...

**Gajumaru:** (slow) Black... always... goes first...

**Gajumaru:** (slow) Some games... last... years...

**Hina** (if hina along): Years?

**Kailo** (if hina not along): Years?

**Gajumaru:** (slow) This one... started... last spring...

**End:** His questions.

## The first win

**Gajumaru:** (slow) Ahh... you win... Take this...

Kailo received a kupang.

**Kailo:** A gold shell? What is it?

**Hina** (if hina): A kupang, Kailo. A Bandari gold coin. The west pays with these instead of pule.

**Maika** (if maika): A kupang! Bandari gold. Out west, that buys you anything.

**Gajumaru** (if alone): (slow) A kupang... Bandari... gold...

**Gajumaru:** (slow) The trader... paid me... with it...

**Gajumaru:** (slow) But nobody... here... takes kupang... So now... it is yours...

**Kailo:** Mahalo!

**End:** Back to the lodge.

## You win

**Gajumaru:** (slow) Ahh... you win... again... Good...

**End:** Back to the lodge.

## He wins

**Gajumaru:** (slow) The shells... were kind... to me... today...

**End:** Back to the lodge.

## A draw

**Gajumaru:** (slow) Even... A good... game...

**End:** Back to the lodge.
