# Maika's sister

Maika's sister waits in the hunters' lodge, looking for her flake of a brother (Frankie, 10/30). She
asked Kailo to find him for a share of the soy sauce she brought from Māla Iki, which the stew for
the wake needs. Her name is **Miki** (Frankie, 10/30); the lore calls her "a sister he does not get on with".
Every line here is Claude's draft (10/30), for
Frankie to rewrite. How to write a script is at the top of `story.md`.

Two scenes:

- **The scene**, the first time Kailo talks to her. At its end the deal is made.
- **The report**, once Maika has asked Kailo not to tell her where he is. Kailo picks what to tell her:
  a lie gets Maika to join and no soy sauce, the truth gets the soy sauce and Maika stays away.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png

## Scene

**Miki:** You there. Have you seen a man with white hair and a mouth that never stops? Tall. Looks like he's doing you a favor by existing.

**Kailo:** ...Maybe? Who's asking?

**Miki:** His sister. He walked out of Māla Iki without a word, and our mother has been asking where he is ever since. He's a flake. I came all this way to drag him home.

**Kailo:** Is that soy sauce? From home? I need some for Pono's stew.

**Miki:** The last of what I brought. I'm not wasting it on a stranger.

**Kailo:** Then I'll find your brother. Share some with me when I do.

**Miki:** Find him, tell me where he is, and half of it is yours.

**End:** The deal is made.

## The report

**Miki:** Well? Did you find that flake?

**Choice:** What does Kailo tell her?

- He took a boat to the next island. → lie
- He's in the woods, selling medicine. → truth

**Miki** (if lie): A boat. To the next island. Of course he did, without so much as a goodbye.

**Miki** (if lie): Then you found nothing worth paying for. The soy sauce stays with me. Don't look at me like that. A deal is a deal.

**Miki** (if truth): In the woods. Selling medicine. Of course he is.

**Miki** (if truth): Here. A deal is a deal, and he's alive, which is more than I hoped. Mother will want to hear it.

**End:** She is told.
