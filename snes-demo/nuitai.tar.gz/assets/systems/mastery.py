"""Weapon mastery (Frankie, 10/30; ``MasterySettings`` has the numbers, all Claude's drafts).

A character has a level in each of their three weapon types. The save keeps
only the total EXP per type; the level and the EXP to the next are worked out
from it, so the curve can change without touching a save. A stroke that lands
earns EXP for the type of the weapon held, empty hands counting as handwraps
when the character can use them. Each level above the first adds a little to
the stroke's chance to land and to its damage.
"""

from __future__ import annotations

from core.shared import by_id
from settings import MasterySettings


def total_for(level: int) -> int:
    """The total EXP at which ``level`` is reached: 0 for level 1."""
    steps = max(0, min(level, MasterySettings.MAX_LEVEL) - 1)
    return MasterySettings.EXP_STEP * steps * (steps + 1) // 2


CAP = total_for(MasterySettings.MAX_LEVEL)


def level_for(exp: int) -> int:
    """The level ``exp`` total EXP makes, 1 to the top."""
    level = 1
    while level < MasterySettings.MAX_LEVEL and exp >= total_for(level + 1):
        level += 1
    return level


def progress(exp: int) -> tuple[int, int] | None:
    """EXP into the current level and EXP the level takes; None at the top level."""
    level = level_for(exp)
    if level >= MasterySettings.MAX_LEVEL:
        return None
    return exp - total_for(level), total_for(level + 1) - total_for(level)


def hit_bonus(level: int) -> float:
    """The chance a stroke gains from ``level``, 0 to 1."""
    return MasterySettings.HIT_PER_LEVEL * (level - 1)


def damage_bonus(level: int) -> float:
    """The share a stroke's damage gains from ``level``."""
    return MasterySettings.DAMAGE_PER_LEVEL * (level - 1)


def weapon_types(member_id: str) -> list[str]:
    """The three weapon type ids ``member_id`` can use."""
    return list(by_id("characters").get(member_id, {}).get("weapon_types", []))


def type_held(member_id: str, weapon_id: str | None) -> str | None:
    """The weapon type that trains when ``member_id`` strikes holding ``weapon_id``.

    Empty hands train handwraps, for those who can use them; None otherwise.
    """
    weapon = by_id("weapons").get(weapon_id or "")
    if weapon:
        return weapon["type"] if weapon["type"] in weapon_types(member_id) else None
    return "handwraps" if "handwraps" in weapon_types(member_id) else None


def type_name(type_id: str) -> str:
    """A weapon type's plural name: "Tools"."""
    return by_id("weapon_types")[type_id]["name"]


def add(mastery: dict[str, int], type_id: str, amount: int) -> int | None:
    """Add ``amount`` EXP to ``type_id`` in ``mastery``; the new level if it rose, else None."""
    before = mastery.get(type_id, 0)
    after = min(CAP, before + amount)
    mastery[type_id] = after
    new = level_for(after)
    return new if new > level_for(before) else None
