"""The timed block meter's logic, apart from any drawing (Frankie, 10/30).

A monster's plain strokes come as pairs of red arrows sliding left along a long bar
toward a yellow zone near its left end, one pair per stroke, in order. The
player presses confirm as each bar crosses the zone: over the zone is a
catch, centered is perfect, and no press or a press off the zone is a miss.
The scene draws it (``ui/block_meter.py``) and, as each stroke lands, hands
its result to ``Battle.block_stroke``. A stroke lands when it is decided: at
the press for a catch or a perfect, as the bar leaves the zone for a miss, and
always in order. Sizes are in ``BlockSettings``.
"""

from __future__ import annotations

from dataclasses import dataclass

from settings import BlockSettings


@dataclass
class _Bar:
    """One incoming stroke."""

    kind: str
    width: int
    x: float  # Its middle column's place, from the well's left end.
    result: str | None = None
    announced: bool = False  # Its swing has been started.
    entered: bool = False  # Its front edge has reached the zone.
    landed: bool = False  # Its stroke has been handed to the battle.


class BlockMeter:
    """The red bars on their way across the meter, and what the player did to each."""

    def __init__(self, strokes: tuple, zone: int, speed: float,
                 perfect: int = BlockSettings.PERFECT_PIXELS) -> None:
        """Line the bars up past the right end, the first stroke's nearest."""
        self.zone_left = BlockSettings.ZONE_LEFT
        self.zone = zone
        self.perfect = perfect  # From the defender's Luck (Frankie, 11/1).
        self.speed = speed
        self.bars = [
            _Bar(kind, BlockSettings.BAR_WIDTH[kind],
                 BlockSettings.LENGTH + BlockSettings.BAR_WIDTH[kind] / 2 + i * BlockSettings.BAR_GAP)
            for i, kind in enumerate(strokes)
        ]
        self._after = 0.0  # Seconds since the last bar landed.

    @property
    def done(self) -> bool:
        """True once every stroke has landed and the meter has lingered a moment."""
        return all(b.landed for b in self.bars) and self._after >= BlockSettings.LINGER_SECONDS

    @property
    def results(self) -> list[str]:
        """"perfect", "catch" or "miss" for each stroke, in order."""
        return [b.result or "miss" for b in self.bars]

    def update(self, dt: float) -> None:
        """Slide the bars left; one that has gone wholly past the zone is a miss."""
        zone_right = self.zone_left + self.zone
        for bar in self.bars:
            bar.x -= self.speed * dt
            if not bar.entered and bar.x - bar.width / 2 <= zone_right:
                bar.entered = True
            if bar.result is None and bar.x + bar.width / 2 < self.zone_left:
                bar.result = "miss"
        if all(b.landed for b in self.bars):
            self._after += dt

    def entries(self) -> list[int]:
        """The strokes whose bars have just reached the zone, for their swing to begin; each once."""
        fresh = [i for i, b in enumerate(self.bars) if b.entered and not b.announced]
        for i in fresh:
            self.bars[i].announced = True
        return fresh

    def landings(self) -> list[tuple[int, str]]:
        """The strokes that land now, in order: (index, result).

        A catch or a perfect lands at its press; a miss, once its bar has left
        the zone (an early press misses too, but its stroke still waits for
        the bar). A stroke never lands before the one ahead of it.
        """
        landed: list[tuple[int, str]] = []
        for i, bar in enumerate(self.bars):
            if bar.landed:
                continue
            ready = bar.result in ("catch", "perfect") or (
                bar.result == "miss" and bar.x + bar.width / 2 < self.zone_left)
            if not ready:
                break
            bar.landed = True
            self._after = 0.0
            landed.append((i, bar.result))
        return landed

    def press(self) -> str | None:
        """Confirm was pressed: settle the first bar not yet settled.

        Over the zone it is a catch, within ``perfect`` pixels of centered a
        perfect; otherwise a miss, so mashing does not help. One press per bar.
        Returns the result, or None when there is no bar left.
        """
        bar = next((b for b in self.bars if b.result is None), None)
        if bar is None:
            return None
        bar.result = self._judge(bar)
        return bar.result

    def _judge(self, bar: _Bar) -> str:
        """How a press at the bar's present place lands."""
        zone_right = self.zone_left + self.zone
        if bar.x + bar.width / 2 <= self.zone_left or bar.x - bar.width / 2 >= zone_right:
            return "miss"
        centers = abs(bar.x - (self.zone_left + self.zone / 2))
        return "perfect" if centers <= self.perfect else "catch"
