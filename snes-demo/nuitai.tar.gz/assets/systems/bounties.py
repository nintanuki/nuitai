"""The hunters' lodge's bounties (Frankie, 10/26; ``data/bounties/``).

Beat a monster so many times and the lodge's keeper pays pule and a prize,
more than the monsters drop. One bounty is posted at a time; paid, the next
one goes up, round and round, so they never run out (Skyrim's radiant
quests). Three party flags keep it, so it saves with the rest:
``bounty`` (which post is up), ``bounty_taken`` and ``bounty_count`` (how
many beaten since it was taken). Only a taken bounty counts.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from systems.party import Party

POST_FLAG = "bounty"
TAKEN_FLAG = "bounty_taken"
COUNT_FLAG = "bounty_count"


def posted(party: "Party", board: dict) -> dict:
    """The bounty up on ``board`` now."""
    posts = board["posts"]
    return posts[int(party.flags.get(POST_FLAG, 0)) % len(posts)]


def taken(party: "Party") -> bool:
    return bool(party.flags.get(TAKEN_FLAG))


def take(party: "Party") -> None:
    """Take the posted bounty; the count starts at nothing."""
    party.flags[TAKEN_FLAG] = True
    party.flags[COUNT_FLAG] = 0


def count(party: "Party") -> int:
    return int(party.flags.get(COUNT_FLAG, 0))


def record(party: "Party", board: dict, beaten: list[str]) -> None:
    """Count the monsters just beaten (shared file ids) toward the taken bounty, up to its number."""
    if not taken(party):
        return
    post = posted(party, board)
    hits = sum(1 for monster in beaten if monster == post["monster"])
    party.flags[COUNT_FLAG] = min(post["count"], count(party) + hits)


def done(party: "Party", board: dict) -> bool:
    return taken(party) and count(party) >= posted(party, board)["count"]


def pay(party: "Party", board: dict) -> dict:
    """Pay out the finished bounty and put up the next; return the one paid."""
    post = posted(party, board)
    party.pule += post["pule"]
    party.inventory[post["prize"]] = party.inventory.get(post["prize"], 0) + 1
    party.flags[POST_FLAG] = (int(party.flags.get(POST_FLAG, 0)) + 1) % len(board["posts"])
    party.flags[TAKEN_FLAG] = False
    party.flags[COUNT_FLAG] = 0
    return post
