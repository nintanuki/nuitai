"""The hunters' lodge's bounties (Frankie, 10/26; ``data/bounties/``).

Beat a monster so many times and the lodge's keeper pays pule and a prize,
more than the monsters drop. One bounty is posted at a time; paid, the next
one goes up, round and round, so they never run out (Skyrim's radiant
quests). Three party flags keep it, so it saves with the rest:
``bounty`` (which post is up), ``bounty_taken`` and ``bounty_count`` (how
many beaten since it was taken). Only a taken bounty counts.

The board's ``first`` post comes before all the rest, once (Frankie, 11/1: the Great Boar is
the lodge's first bounty, and after it the radiant hunts begin). Its ``beaten`` flag makes it done
even if he fell before it was taken, since he is fought only once; ``first_paid`` keeps that it
was paid.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from systems.party import Party

POST_FLAG = "bounty"
TAKEN_FLAG = "bounty_taken"
COUNT_FLAG = "bounty_count"
FIRST_FLAG = "bounty_first_paid"


def posted(party: "Party", board: dict) -> dict:
    """The bounty up on ``board`` now: its ``first`` until that is paid, then the round."""
    if board.get("first") and not party.flags.get(FIRST_FLAG):
        return board["first"]
    posts = board["posts"]
    return posts[int(party.flags.get(POST_FLAG, 0)) % len(posts)]


def taken(party: "Party") -> bool:
    return bool(party.flags.get(TAKEN_FLAG))


def take(party: "Party") -> None:
    """Take the posted bounty; the count starts at nothing."""
    party.flags[TAKEN_FLAG] = True
    party.flags[COUNT_FLAG] = 0


def count(party: "Party") -> int:
    return int(party.flags.get(COUNT_FLAG, 0))


def tally(party: "Party", board: dict) -> str:
    """The taken bounty's count as the player sees it: "Boars 4/10" (Frankie, 10/28)."""
    post = posted(party, board)
    return board["lines"]["tally"].format(name=post["name"], done=count(party), count=post["count"])


def record(party: "Party", board: dict, beaten: list[str]) -> str | None:
    """Count the monsters just beaten (shared file ids) toward the taken bounty, up to its number.

    Returns the line to show after the fight ("Boars 4/10."), or None when none counted.
    """
    if not taken(party) or done(party, board):
        return None
    post = posted(party, board)
    hits = sum(1 for monster in beaten if monster == post["monster"])
    if not hits:
        return None
    party.flags[COUNT_FLAG] = min(post["count"], count(party) + hits)
    line = board["lines"]["kill_done" if done(party, board) else "kill"]
    return line.format(tally=tally(party, board))


def done(party: "Party", board: dict) -> bool:
    post = posted(party, board)
    if post.get("beaten") and party.flags.get(post["beaten"]):
        return True
    return taken(party) and count(party) >= post["count"]


def pay(party: "Party", board: dict) -> dict:
    """Pay out the finished bounty and put up the next; return the one paid."""
    post = posted(party, board)
    party.pule += post["pule"]
    if post.get("prize"):
        party.inventory[post["prize"]] = party.inventory.get(post["prize"], 0) + 1
    if post is board.get("first"):
        party.flags[FIRST_FLAG] = True
    else:
        party.flags[POST_FLAG] = (int(party.flags.get(POST_FLAG, 0)) + 1) % len(board["posts"])
    party.flags[TAKEN_FLAG] = False
    party.flags[COUNT_FLAG] = 0
    return post
