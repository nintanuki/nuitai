"""The four kits' moves: what each one does, by move id.

The browser battle (``game/browser/ctb-battle.html``) runs every move
with its own few lines of code, ``mvAct(id, run)``; this is the same
table for the four who are in the pygame game so far, Kailo, Hina,
Tawiri and Maika (``docs/<name>-kit.md``). A move's numbers (power,
turns, how much it gives) come from the shared battle file as always;
only what it does is here.

Each runner takes the battle, the one acting, the target and the move
as it plays from its row (``systems/loadout.py``'s ``grown``), plus
``other``: for a move that takes from an enemy and gives to someone
(Drain, Osmose, Borrowed Life), the target is the enemy and ``other``
the one it gives to. Each returns the events, as the rest of the battle
does. The rules they lean on (burn, guards, boosts, the dead) are in
``systems/battle.py``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable

from core.elements import Element
from core.events import GuardRaisedEvent, NoteEvent, RevivedEvent, StatusAppliedEvent
from core.stats import defense_scale, offense_scale
from settings import BattleSettings

if TYPE_CHECKING:
    from systems.battle import Battle, Combatant

AFI, WAI, LAU, LA, ATA, MANA = (
    Element.AFI, Element.WAI, Element.LAU, Element.LA, Element.ATA, Element.MANA,
)

Runner = Callable[["Battle", "Combatant", "Combatant", dict, "Combatant | None"], list]
KITS: dict[str, Runner] = {}


def kit(move_id: str):
    """Register the function below as the runner for ``move_id``."""
    def register(run: Runner) -> Runner:
        KITS[move_id] = run
        return run
    return register


# ----------------------------------------------------------------------
# SHARED PIECES
# ----------------------------------------------------------------------

def foes_of(battle: "Battle", actor: "Combatant") -> list["Combatant"]:
    """The living fighters on the other side."""
    return [c for c in (battle.enemies if actor.is_party else battle.party) if c.alive]


def allies_of(battle: "Battle", actor: "Combatant") -> list["Combatant"]:
    """The living fighters on the actor's side."""
    return [c for c in (battle.party if actor.is_party else battle.enemies) if c.alive]


def most_hurt(fighters: list["Combatant"]) -> "Combatant | None":
    """The one with the smallest share of HP left."""
    return min(fighters, key=lambda c: c.hp / c.max_hp, default=None)


def mend(actor: "Combatant", power: float) -> int:
    """A nature heal's size: its power by the healer's Magic (D-342)."""
    return round(power * offense_scale(actor.points["magic"]))


def turns(move: dict[str, Any], base: int) -> int:
    """A timed effect's turns, more for a move slotted above its row (D-319)."""
    return base + move.get("extra_turns", 0)


def raise_guard(actor: "Combatant", kind: str, move: dict[str, Any], left: int | None = None) -> list:
    """Put ``actor`` on guard: ``left`` more turns it holds (a row above home adds them)."""
    actor.guard = kind
    actor.guard_left = move.get("extra_turns", 0) if left is None else left
    actor.guard_m = move.get("guard_multiplier")
    return [GuardRaisedEvent(actor.id, actor.name, kind)]


def each(battle: "Battle", actor: "Combatant", hit: Callable[["Combatant"], list]) -> list:
    """Hit every living foe in turn while the actor stands."""
    events: list[Any] = []
    for foe in foes_of(battle, actor):
        if actor.alive:
            events.extend(hit(foe))
    return events


# ----------------------------------------------------------------------
# KAILO (docs/kailo-kit.md): fire hits, water guards and water hits,
# and guards that turn a hit into one back.
# ----------------------------------------------------------------------

@kit("sear")
def _sear(b, u, t, m, o):
    return b._physical(u, t, m["power"], AFI)


@kit("char")
def _char(b, u, t, m, o):
    return b._physical(u, t, m["power"], AFI, m.get("statuses", ()))


@kit("flambe")
def _flambe(b, u, t, m, o):
    return [NoteEvent(f"{u.name} lights the pan.")] + each(
        b, u, lambda f: b._physical(u, f, m["power"], AFI))


@kit("stir_fry")
def _stir_fry(b, u, t, m, o):
    events: list[Any] = []
    for _ in range(m.get("hits", 1)):
        foes = foes_of(b, u)
        if not foes or not u.alive:
            break
        events.extend(b._physical(u, b._rng.choice(foes), m["power"], AFI))
    return events


@kit("hot_pan")
def _hot_pan(b, u, t, m, o):
    # A sure hit: it cannot be dodged.
    return b._physical(u, t, m["power"], AFI, accuracy=9)


@kit("open_flame")
def _open_flame(b, u, t, m, o):
    return [NoteEvent(f"{u.name} sends fire over the enemy.")] + each(
        b, u, lambda f: b._physical(u, f, m["power"], AFI, m.get("statuses", ())))


@kit("well_done")
def _well_done(b, u, t, m, o):
    hot = "burn" in t.statuses
    events: list[Any] = [NoteEvent(f"{t.name} is cooked through.", t.id)] if hot else []
    events.extend(b._physical(u, t, m["power"] * (2 if hot else 1), AFI))
    if hot and t.alive and t.statuses.pop("burn", None):
        events.append(NoteEvent(f"The burn on {t.name} goes out.", t.id))
    return events


@kit("ice_bath")
def _ice_bath(b, u, t, m, o):
    # A water move cannot curse, so no slow; twice as hard on a burning enemy instead (audit, 10/21).
    hot = "burn" in t.statuses
    events: list[Any] = [NoteEvent(f"The cold water hits {t.name}'s burns.", t.id)] if hot else []
    return events + b._physical(u, t, m["power"] * (2 if hot else 1), WAI)


@kit("wash_up")
def _wash_up(b, u, t, m, o):
    return [NoteEvent(f"{u.name} punches through the enemy like a wave.")] + each(
        b, u, lambda f: b._physical(u, f, m["power"], WAI))


@kit("oven_mitt")
def _oven_mitt(b, u, t, m, o):
    return raise_guard(u, "oven_mitt", m)


@kit("lid_on")
def _lid_on(b, u, t, m, o):
    u.statuses["protect"] = turns(m, BattleSettings.BUFF_TURNS)
    return [StatusAppliedEvent(u.id, u.name, "protect", True)]


@kit("cast_iron")
def _cast_iron(b, u, t, m, o):
    return raise_guard(u, "cast_iron", m, left=m.get("turns", 1))


@kit("dinner_bell")
def _dinner_bell(b, u, t, m, o):
    return raise_guard(u, "bell", m)


@kit("pan_flip")
def _pan_flip(b, u, t, m, o):
    events = b._physical(u, t, m["power"], AFI)
    if u.alive:
        u.guard, u.guard_left, u.guard_m = "sentinel", 0, None
        events.append(NoteEvent(f"{u.name} lands on guard."))
    return events


@kit("hot_oil")
def _hot_oil(b, u, t, m, o):
    return raise_guard(u, "oil", m)


@kit("steam_vent")
def _steam_vent(b, u, t, m, o):
    return raise_guard(u, "steam", m)


@kit("boil_over")
def _boil_over(b, u, t, m, o):
    events = raise_guard(u, "boil", m, left=0)
    u.cooker_took = 0
    return events


# ----------------------------------------------------------------------
# HINA (docs/hina-kit.md): nature heals, light buffs, and light making
# the healing grow (D-652).
# ----------------------------------------------------------------------

@kit("seed")
def _seed(b, u, t, m, o):
    t.statuses["sprout"] = mend(u, m["power"])
    return [StatusAppliedEvent(t.id, t.name, "sprout", True)]


@kit("petal_rain")
def _petal_rain(b, u, t, m, o):
    events: list[Any] = [NoteEvent(f"{u.name} rises and falls, and petals fall over the party.")]
    for ally in allies_of(b, u):
        events.extend(b._heal(ally, mend(u, m["power"])))
    return events


@kit("sun_salute")
def _sun_salute(b, u, t, m, o):
    events = b._heal(t, mend(u, m["power"]))
    if t.alive:
        t.haste = BattleSettings.HASTE_ACTIONS
        events.append(StatusAppliedEvent(t.id, t.name, "haste", True))
    return events


@kit("radiant_seal")
def _radiant_seal(b, u, t, m, o):
    # Magic up (D-716): nature's stat, so on Hina herself it makes her heals bigger too.
    return b._boost(t, "magic", turns(m, BattleSettings.BUFF_TURNS))


@kit("vigor_seal")
def _vigor_seal(b, u, t, m, o):
    return b._boost(t, "hp", turns(m, BattleSettings.BUFF_TURNS))


@kit("dawn_seal")
def _dawn_seal(b, u, t, m, o):
    t.statuses["protect"] = turns(m, BattleSettings.BUFF_TURNS)
    return [StatusAppliedEvent(t.id, t.name, "protect", True)]


@kit("bloom")
def _bloom(b, u, t, m, o):
    events = b._heal(t, round(t.max_hp * m["bloom"][0]))
    if t.alive:
        t.statuses["bloom"] = 1
        events.append(StatusAppliedEvent(t.id, t.name, "bloom", True))
    return events


@kit("perennial")
def _perennial(b, u, t, m, o):
    t.statuses["perennial"] = 1
    return [StatusAppliedEvent(t.id, t.name, "perennial", True)]


@kit("mending_hula")
def _mending_hula(b, u, t, m, o):
    # The two most hurt allies (audit, 10/21).
    events: list[Any] = [NoteEvent(f"{u.name} sways over the wounded.")]
    hurt = sorted(allies_of(b, u), key=lambda c: c.hp / c.max_hp)[:2]
    for ally in hurt:
        events.extend(b._heal(ally, mend(u, m["power"])))
    return events


@kit("solar_seal")
def _solar_seal(b, u, t, m, o):
    for ally in allies_of(b, u):
        ally.ward = True
        ally.safe = True
    return [NoteEvent(f"{u.name}'s seals light up the whole party.")]


# ----------------------------------------------------------------------
# TAWIRI (docs/tawiri-kit.md): Mana is her lightning, shadow her
# curses, and both are the dead.
# ----------------------------------------------------------------------

@kit("static")
def _static(b, u, t, m, o):
    events = b._magic(u, t, m["power"], MANA)
    if b.dealt(events, t) > 0 and t.alive:
        lost, lose = b._lose_mana(t, 1)
        events += lose + b._mana_burn(u, t, lost, m["burn_power"])
    return events


@kit("evil_eye")
def _evil_eye(b, u, t, m, o):
    if not b._roll():
        return [NoteEvent(f"The evil eye slides off {t.name}.", t.id)]
    t.statuses["weak"] = turns(m, BattleSettings.BUFF_TURNS)
    return [StatusAppliedEvent(t.id, t.name, "weak", True)]


@kit("mental_break")
def _mental_break(b, u, t, m, o):
    if not b._roll():
        return [NoteEvent(f"{t.name}'s mind holds.", t.id)]
    t.statuses["mbreak"] = 1
    return [StatusAppliedEvent(t.id, t.name, "mbreak", True)]


@kit("hex_bolt")
def _hex_bolt(b, u, t, m, o):
    from systems.battle import _HEXES  # local: the rules module imports this one.

    curses = sum(1 for k in _HEXES if k in t.statuses)
    events: list[Any] = []
    if curses:
        events.append(NoteEvent(f"{curses} curse{'s' if curses > 1 else ''} feed the bolt."))
    return events + b._magic(u, t, m["power"] * (1 + m["per_curse"] * curses), MANA)


@kit("sap")
def _sap(b, u, t, m, o):
    events = b._magic(u, t, m.get("power", 0), MANA, m.get("statuses", ()))
    if "sap" in t.statuses:
        t.cursed_by["sap"] = u.id
    return events


@kit("stillness")
def _stillness(b, u, t, m, o):
    if "calm" in t.immune or not b._roll():
        return [NoteEvent(f"{t.name} keeps moving.", t.id)]
    t.statuses["calm"] = turns(m, BattleSettings.BUFF_TURNS)
    return [StatusAppliedEvent(t.id, t.name, "calm", True)]


@kit("haunt")
def _haunt(b, u, t, m, o):
    t.haunt_damage = max(1, round(
        m["power"] * offense_scale(u.points["magic"]) * defense_scale(t.points["spirit"])
        * b._weakness(MANA, t)))
    t.statuses["haunt"] = m["turns"]
    return [StatusAppliedEvent(t.id, t.name, "haunt", True)]


@kit("call_the_dead")
def _call_the_dead(b, u, t, m, o):
    u.spirit = {"left": m["turns"], "power": m["power"]}
    return [NoteEvent(f"{u.name} calls one of the dead to her side.")]


@kit("feedback")
def _feedback(b, u, t, m, o):
    return b._magic(u, t, m["power"] + m["per_mana"] * t.mana, MANA)


@kit("blight")
def _blight(b, u, t, m, o):
    return [NoteEvent("Rotten lightning falls on the enemy.")] + each(
        b, u, lambda f: b._magic(u, f, m["power"], MANA, m.get("statuses", ())))


@kit("storm_call")
def _storm_call(b, u, t, m, o):
    events = b._toll(u, m) + [NoteEvent(f"{u.name} calls down the storm.")]
    return events + each(b, u, lambda f: b._magic(u, f, m["power"], MANA))


@kit("death_knell")
def _death_knell(b, u, t, m, o):
    events = b._toll(u, m)
    if t.boss:
        return events + [NoteEvent(f"{t.name} does not hear the knell.", t.id)]
    events.append(NoteEvent(f"The dead toll for {t.name}.", t.id))
    return events + b._inflict(t, "doom")


@kit("chain_lightning")
def _chain_lightning(b, u, t, m, o):
    events = b._magic(u, t, m["power"], MANA)
    for foe in foes_of(b, u):
        if foe is not t and u.alive:
            events.append(NoteEvent(f"The lightning jumps to {foe.name}.", foe.id))
            events.extend(b._magic(u, foe, m["power"] / 2, MANA))
    return events


@kit("thunderhead")
def _thunderhead(b, u, t, m, o):
    events = b._toll(u, m) + [NoteEvent(f"{u.name}'s seeing eye turns purple.")]
    return events + b._magic(u, t, m["power"], MANA)


@kit("grave_grip")
def _grave_grip(b, u, t, m, o):
    events = b._toll(u, m)
    t.statuses["grip"] = 1 if t.boss else m["turns"]
    events.append(NoteEvent(f"Hands of the dead seize {t.name}.", t.id))
    return events


# ----------------------------------------------------------------------
# MAIKA (docs/maika-kit.md): nature heals, Mana hits and blocks mana,
# and both move life from the enemy to the party (D-659).
# ----------------------------------------------------------------------

@kit("spin")
def _spin(b, u, t, m, o):
    return b._magic(u, t, m["power"], MANA)


@kit("whirl")
def _whirl(b, u, t, m, o):
    return [NoteEvent(f"{u.name}'s spiral widens.")] + each(
        b, u, lambda f: b._magic(u, f, m["power"], MANA))


@kit("unravel")
def _unravel(b, u, t, m, o):
    # Plain spirit damage, no mana taken (D-721).
    events: list[Any] = []
    for _ in range(m.get("hits", 1)):
        if not t.alive or not u.alive:
            break
        events.extend(b._magic(u, t, m["power"], MANA))
    return events


@kit("maelstrom")
def _maelstrom(b, u, t, m, o):
    foes = foes_of(b, u)
    power = m["power"] * (1 + m["per_foe"] * (len(foes) - 1))
    return [NoteEvent(f"{u.name} spins up a maelstrom.")] + each(
        b, u, lambda f: b._magic(u, f, power, MANA))


@kit("osmose")
def _osmose(b, u, t, m, o):
    # Take mana from the enemy and give it to Maika or an ally, with a little more (D-409).
    to = o or u
    lost, events = b._lose_mana(t, int(m.get("gift", 1)))
    if lost:
        events = events + b._gain(to, lost + int(m.get("bonus", 0)))
    return events


@kit("drain")
def _drain(b, u, t, m, o):
    # Half the damage comes back, to Maika or the ally he gives it to.
    events = b._magic(u, t, m["power"], LAU)
    dealt = b.dealt(events, t)
    if dealt:
        events.extend(b._heal(o or u, round(dealt / 2)))
    return events


@kit("leech")
def _leech(b, u, t, m, o):
    t.statuses["seed"] = m["turns"]
    return [StatusAppliedEvent(t.id, t.name, "seed", True)]


@kit("mana_leech")
def _mana_leech(b, u, t, m, o):
    # For its turns, what the enemy builds goes to Maika (D-723).
    t.statuses["mleech"] = turns(m, m["turns"])
    t.cursed_by["mleech"] = u.id
    return [StatusAppliedEvent(t.id, t.name, "mleech", True)]


@kit("graft")
def _graft(b, u, t, m, o):
    to = most_hurt(allies_of(b, u))
    kind = next((k for k in ("regen", "protect", "shell")
                 if (t.regen > 0 if k == "regen" else k in t.statuses)), None)
    if kind is None or to is None:
        return [NoteEvent(f"{t.name} has nothing worth taking.", t.id)]
    if kind == "regen":
        left, t.regen = t.regen, 0
        to.regen = max(to.regen, left)
    else:
        left = t.statuses.pop(kind)
        to.statuses[kind] = max(to.statuses.get(kind, 0), left)
    return [
        NoteEvent(f"{u.name} takes {kind} off {t.name} and gives it to {to.name}.", to.id),
        StatusAppliedEvent(to.id, to.name, kind, True),
    ]


@kit("lomilomi")
def _lomilomi(b, u, t, m, o):
    events = b._heal(t, mend(u, m["power"]))
    if t.alive:
        events.extend(b._gain(t, int(m.get("gift", 1))))
    return events


@kit("indulge")
def _indulge(b, u, t, m, o):
    events = b._magic(u, t, m["power"], LAU)
    dealt = b.dealt(events, t)
    if dealt:
        events.extend(b._heal(u, dealt))
    return events + b._gain(u, int(m.get("gift", 1)))


@kit("tide_of_life")
def _tide_of_life(b, u, t, m, o):
    events: list[Any] = [NoteEvent(f"{u.name} draws the tide of life.")]
    took = 0
    for foe in foes_of(b, u):
        if u.alive:
            hit = b._magic(u, foe, m["power"], LAU)
            took += b.dealt(hit, foe)
            events.extend(hit)
    party = allies_of(b, u)
    if took and party:
        for ally in party:
            events.extend(b._heal(ally, round(took / len(party))))
    return events


@kit("borrowed_life")
def _borrowed_life(b, u, t, m, o):
    # Plant magic on an enemy; the fallen friend gets up with what it took, at least a share of max HP (D-492).
    events = b._magic(u, t, m["power"], LAU)
    if o is None or o.alive:
        return events
    floor = round(o.max_hp * m.get("revive_floor", 0.25))
    o.hp = min(o.max_hp, max(floor, b.dealt(events, t), 1))
    o.statuses.clear()
    o.counter = u.counter + BattleSettings.FATIGUE_OTHER * defense_scale(o.points["speed"])
    return events + [RevivedEvent(o.id, o.name, o.hp)]


def run(battle: "Battle", actor: "Combatant", target: "Combatant", move: dict[str, Any],
        other: "Combatant | None" = None) -> list | None:
    """Run ``move`` if it is a kit move; None if this table does not have it."""
    runner = KITS.get(move["id"])
    if runner is None:
        return None
    return runner(battle, actor, target, move, other)

