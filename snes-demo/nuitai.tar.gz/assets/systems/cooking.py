"""What the pot makes from one, two or three ingredients (Frankie, 11/2).

The rules, in order, as in Breath of the Wild:

1. An exact recipe in ``data/crafting/pot.json``'s ``recipes`` wins. A part is an
   ingredient's id, or ``@`` and a kind (``@fish`` is any fish). A recipe of one
   part is that food cooked by itself: the roast, grilled or boiled version.
2. Salt seasons: if nothing matched, the mix is tried again without it, so salt
   with anything makes what that thing makes (salt and pork, Roast Pork).
3. Then the kinds (``groups``): every ingredient left is of a kind, two or more,
   and the kinds they cover are one of the pot's group dishes (meat and a
   vegetable, Meat Stew).
4. Anything else makes ??? (``ItemSettings.DUBIOUS``), which makes whoever eats it sick.

Kailo's Cook in battle makes a meal already made at the pot, and from tool level 4 can swap
(Frankie, 11/4; ``battle_mix``): an ingredient stands in for another of its kind, and a
vegetable for a meat or a fish.

No mix holds two of the same ingredient (Frankie, 10/28).
"""

from __future__ import annotations

import itertools
import json
import os

from settings import ItemSettings

_POT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "crafting", "pot.json")
_DATA: dict = {}
MAX_PARTS = 3


def data() -> dict:
    """The pot file, read once."""
    if not _DATA:
        with open(_POT, encoding="utf-8") as f:
            _DATA.update(json.load(f))
    return _DATA


def recipes() -> list[dict]:
    """The exact recipes, one part to three."""
    return data()["recipes"]


def group_dishes() -> list[dict]:
    """The dishes made by kind of ingredient."""
    return data()["groups"]


def results() -> list[dict]:
    """Every dish the pot can make, recipes then group dishes, in the file's order, each once."""
    seen, out = set(), []
    for entry in recipes() + group_dishes():
        if entry["id"] not in seen:
            seen.add(entry["id"])
            out.append(entry)
    return out


def entry(dish: str) -> dict | None:
    """The first recipe or group dish that makes ``dish``."""
    return next((e for e in results() if e["id"] == dish), None)


def group_of(item: str) -> str | None:
    """The kind ``item`` is (meat, fish, vegetable, fruit, water), or None."""
    return next((g for g, members in ItemSettings.FOOD_GROUPS.items() if item in members), None)


def members(part: str) -> tuple[str, ...]:
    """What fills a recipe's part: the ingredient itself, or every one of a kind for ``@kind``."""
    if part.startswith("@"):
        return tuple(ItemSettings.FOOD_GROUPS.get(part[1:], ()))
    return (part,)


def _fits(parts: list[str], mix: list[str]) -> bool:
    """Whether ``mix`` fills ``parts`` one for one, in any order."""
    if len(parts) != len(mix):
        return False
    return any(all(item in members(part) for part, item in zip(parts, order))
               for order in itertools.permutations(mix))


def _exact(mix: list[str]) -> dict | None:
    """The exact recipe ``mix`` makes, the one naming the most ingredients outright first."""
    fitting = [r for r in recipes() if _fits(r["from"], mix)]
    return min(fitting, key=lambda r: sum(p.startswith("@") for p in r["from"]), default=None)


def _by_kind(mix: list[str]) -> dict | None:
    """The group dish ``mix`` makes: two or more, every one of a kind, the kinds matching."""
    if len(mix) < 2:
        return None
    kinds = [group_of(item) for item in mix]
    if None in kinds:
        return None
    return next((g for g in group_dishes() if set(g["groups"]) == set(kinds)), None)


def cook(mix: list[str]) -> dict | None:
    """What ``mix`` makes: a recipe or group dish entry, or None for ???."""
    mix = list(mix)
    if not mix or len(mix) > MAX_PARTS or len(set(mix)) != len(mix):
        return None
    found = _exact(mix)
    if found is None:
        plain = [i for i in mix if i not in ItemSettings.SEASONINGS]
        if plain and len(plain) < len(mix):
            found = _exact(plain) or _by_kind(plain)
        else:
            found = _by_kind(mix)
    return found


def makes(mix: list[str]) -> str:
    """The id of what ``mix`` makes, ??? when nothing."""
    found = cook(mix)
    return found["id"] if found else ItemSettings.DUBIOUS


def sources(dish: str) -> set[str]:
    """Every ingredient that can go into ``dish`` one way or another (for what a dish holds)."""
    found: set[str] = set()
    for e in recipes():
        if e["id"] == dish:
            for part in e["from"]:
                found |= set(members(part))
    for g in group_dishes():
        if g["id"] == dish:
            for kind in g["groups"]:
                found |= set(ItemSettings.FOOD_GROUPS.get(kind, ()))
    return found


def example(dish: str) -> list[str]:
    """One way to make ``dish``, the first of each kind (for how hard it is to make)."""
    e = entry(dish)
    if e is None:
        return []
    if "from" in e:
        return [members(p)[0] for p in e["from"]]
    return [ItemSettings.FOOD_GROUPS[k][0] for k in e["groups"]]


def mixes(items: list[str]) -> list[tuple[str, ...]]:
    """Every mix of one to three different ``items``."""
    out: list[tuple[str, ...]] = []
    for n in range(1, MAX_PARTS + 1):
        out += list(itertools.combinations(items, n))
    return out


def stands_for(item: str) -> set[str]:
    """What ``item`` can stand in for when Kailo swaps (Frankie, 11/4): itself, every ingredient
    of its kind, and, for a vegetable, any meat or fish, so a vegetarian will eat the dish."""
    out = {item}
    kind = group_of(item)
    if kind:
        out |= set(ItemSettings.FOOD_GROUPS[kind])
    if kind == "vegetable":
        out |= set(ItemSettings.FOOD_GROUPS["meat"]) | set(ItemSettings.FOOD_GROUPS["fish"])
    return out


def _makes_swapped(mix: list[str], dish: str) -> bool:
    """Whether swapping some of ``mix``'s ingredients (``stands_for``) would make ``dish``:
    each fills one part of a recipe for it, itself or by standing in for what the part takes."""
    loose = [stands_for(i) for i in mix]
    shapes = [e["from"] for e in recipes() if e["id"] == dish]
    shapes += [["@" + k for k in g["groups"]] for g in group_dishes() if g["id"] == dish]
    for parts_ in shapes:
        if len(parts_) != len(mix):
            continue
        for order in itertools.permutations(range(len(mix))):
            if all(loose[i] & set(members(part)) for part, i in zip(parts_, order)):
                return True
    return False


def battle_mix(dish: str, have: list[str], level: int, eaters: list[str]) -> tuple[str, ...] | None:
    """What Kailo's Cook puts in the pot for ``dish`` in a fight (Frankie, 11/4), or None if he cannot.

    ``have`` is the bag's ingredients, ``level`` his tool level, ``eaters`` who will eat it.
    The game picks the mix: first one everyone will eat, then the exact recipe before a swap,
    then the fewest things. From COOK_SWAP_LEVEL a swap counts; at COOK_FREE_LEVEL, with
    nothing that fits, he cooks it from nothing: ``()``.
    """
    from settings import MinigameSettings
    from systems import diet

    swaps = level >= MinigameSettings.COOK_SWAP_LEVEL
    found: list[tuple[int, int, int, tuple[str, ...]]] = []
    for mix_ in mixes(have):
        exact = makes(list(mix_)) == dish
        if not exact and not (swaps and _makes_swapped(list(mix_), dish)):
            continue
        refused = sum(diet.refuses(who, parts=mix_) for who in eaters)
        found.append((refused, 0 if exact else 1, len(mix_), mix_))
    if found:
        return min(found)[3]
    return () if level >= MinigameSettings.COOK_FREE_LEVEL else None
