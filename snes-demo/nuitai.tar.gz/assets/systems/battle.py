"""Turn-based battle simulation. Pure data; emits events; never draws.

The rules are a port of the browser battle test
(``game/browser/ctb-battle.html``); the design notes are in
``game/browser/battle-moves.md``. In short:

* **Conditional turns.** Every combatant has a counter. The lowest
  counter acts next. Acting adds a wait to the actor's counter, and the
  wait is fatigue (D-328): what the turn built, each stroke its points,
  anything else 1, Defend 1 less. Speed shrinks every wait.
* **Mana is the meter** (D-213 to D-220), up to 7. Attack is a chain
  of strokes on one enemy, light, medium or strong, up to 7 points a
  turn; each stroke that lands builds its points in mana. Defend
  builds 1, and so does dodging or blocking a blow. A technique costs
  the mana row it is slotted in, and a higher row grows it (D-318 to
  D-320, ``systems/loadout.py``). Monsters play by the same rules (D-329): a
  monster picks a move, and if it cannot pay for it yet it attacks
  with strokes instead.
* **Stats come from elements** (``core/stats.py``). Strength and Magic
  scale damage dealt; Vitality and Spirit scale damage taken.
* **Element moves are shared** by everyone who carries that element.
  Each party member also owns one special. Moves are data, in the
  shared battle file (``core/shared.py``); this module knows how to
  run each ``effect``.
* **Stances** (D-257, D-285, D-286, D-365). A party member fights in
  one of two stances, one per element, starting in the first. The
  stance's element counts twice in the stats and the other not at all,
  HP keeping its share. A move works in the stance of each element icon
  it shows (D-362): an element move shows its own element, a special
  both of its owner's unless the file lists ``elements``. Switching
  builds 1 mana and ends the turn.
* **Physical and magic are separate.** Defend and the guard stances
  only work on physical hits. Monsters have one element that decides
  what they are weak to; party members have no weakness.

The scene drives a battle in two beats:

1. ``start_turn()`` picks the next combatant, runs start-of-turn
   effects, and resolves the turn if it is a monster's. For a party
   member it parks the battle in awaiting-command mode
   (``is_awaiting_command()``).
2. One of the ``submit_*`` methods resolves the player's choice.

Both return a list of events (``core/events.py``) for a view to narrate.
"""

from __future__ import annotations

import random
from typing import Any, Iterable

from core.elements import Element, NEUTRAL_MULTIPLIER, damage_multiplier
from core.events import (
    AbilityUsedEvent,
    AttackEvent,
    BattleEndedEvent,
    ChainEndedEvent,
    CleansedEvent,
    ComboUsedEvent,
    CombatantDefeatedEvent,
    DamageEvent,
    DefendEvent,
    DodgeEvent,
    EscapeEvent,
    GuardInterceptEvent,
    GuardRaisedEvent,
    HealEvent,
    ManaEvent,
    MissEvent,
    PotionUsedEvent,
    RevivedEvent,
    StatusAppliedEvent,
    StanceEvent,
    StatusResistedEvent,
    StrokeEvent,
    SwapEvent,
    TurnSkippedEvent,
    TurnStartEvent,
    WardBlockedEvent,
    WeaponEvent,
)
from core.stats import defense_scale, max_hp_for, offense_scale, stat_points
from systems.loadout import grown, home_row, knows
from settings import BattleSettings, StatSettings


# The combos this game can play so far, out of the fifteen in the shared
# file (D-419). Each needs only rules this game already has; the rest
# wait, added slowly (Frankie, 10/18).
COMBOS_BUILT: tuple[str, ...] = ("solar_fist", "vine_whip", "eclipse", "daybreak")

# Statuses Cure All removes; Cure Blind, Sleep and Poison name their own. Purification removes every status.
_CLEANSABLE: tuple[str, ...] = ("blind", "sleep", "poison")


class Combatant:
    """One participant in a battle."""

    def __init__(
        self,
        combatant_id: str,
        name: str,
        elements: Iterable[Element],
        is_party: bool,
        max_hp: int,
        hp: int | None = None,
        moves: list[dict[str, Any]] | None = None,
        beast: bool = False,
        immune: Iterable[str] = (),
        poison_rate: float | None = None,
        stances: list[dict[str, Any]] | None = None,
        stance: int = 0,
        loadout: dict[str, int] | None = None,
    ) -> None:
        """Construct a combatant.

        Args:
            combatant_id: Stable id, e.g. a party member or enemy id.
            name: Display name.
            elements: The combatant's elements. Party members carry
                two. A monster carries one, listed twice for a boss.
            is_party: True for party members, False for monsters.
            max_hp: Hit point ceiling.
            hp: Starting HP for this battle; defaults to ``max_hp``.
                A party member who walked in hurt passes less.
            moves: A monster's move list, from the shared battle file.
                Party members leave this empty; their moves come from
                ``Battle.moves_for``.
            beast: True for an animal. Nothing reads this yet; it is
                carried for moves that will care, like Leilagi's Hunt.
            immune: Status ids this combatant can never be given.
            poison_rate: Share of max HP lost to poison each turn, for
                a boss that poison should only nibble at. None means
                the ordinary rate.
            stances: A party member's two stances from the shared file
                (``name``, ``element``). Monsters have none.
            stance: Which stance a party member starts the fight in,
                chosen on the party screen.
            loadout: A party member's slotted techniques, move id ->
                row (``systems/loadout.py``). None offers every move
                they know, each in its own row.
        """
        self.id = combatant_id
        self.name = name
        self.elements = tuple(elements)
        self.is_party = is_party
        self.stances = list(stances or [])
        self.stance = stance if 0 <= stance < len(self.stances) else 0
        self.loadout = dict(loadout) if loadout is not None else None
        self.points = stat_points(self.elements, self.stance_element)
        self.max_hp = max_hp
        self.hp = max_hp if hp is None else hp
        if self.stances:
            self._fit_hp_to_stance()
        self.moves = list(moves) if moves else []
        self.beast = beast
        self.immune = frozenset(immune)
        self.poison_rate = (
            BattleSettings.POISON_RATE if poison_rate is None else poison_rate
        )
        # Turn counter. The lowest counter in the battle acts next.
        self.counter = 0.0
        # The mana meter, 0 to ``BattleSettings.MANA_CAP``.
        self.mana = BattleSettings.MANA_START
        # Status id -> turns left. Blind and poison have no timer and
        # hold a 1 until cured; sleep counts down.
        self.statuses: dict[str, int] = {}
        # Shaka's Light: blocks the next shadow attack, then is spent.
        self.ward = False
        # Remaining actions that cost a shortened wait.
        self.haste = 0
        # Set by Defend, cleared at the top of this combatant's turn.
        self.defending = False
        # Guard stance id ("sentinel", "counter") or None. Cleared at
        # the top of this combatant's turn.
        self.guard: str | None = None
        # Set by Defend: until their next turn an ally can pull them into
        # a combo (D-182).
        self.ready = False
        # The weapon held, by name, or None. Weapons do nothing in a fight yet.
        self.weapon: str | None = None

    @property
    def alive(self) -> bool:
        """Return True while HP is above zero."""
        return self.hp > 0

    @property
    def stance_element(self) -> Element | None:
        """Return the element of the stance this combatant is in, or None."""
        if not self.stances:
            return None
        return Element(self.stances[self.stance]["element"])

    def take_stance(self, index: int) -> None:
        """Move into stance ``index``: new stats, the same share of HP."""
        self.stance = index
        self.points = stat_points(self.elements, self.stance_element)
        self._fit_hp_to_stance()

    def _fit_hp_to_stance(self) -> None:
        """Set max HP from the stance's stats, keeping the share of HP (D-365).

        Rounded, never below 1 while standing: a switch never kills or heals.
        """
        new_max = max_hp_for(self.points)
        if new_max == self.max_hp:
            return
        if self.hp > 0:
            self.hp = min(new_max, max(1, round(self.hp * new_max / self.max_hp)))
        self.max_hp = new_max

    @property
    def element(self) -> Element | None:
        """Return the element that decides weakness, or None.

        Only monsters have one. Party members take every element at
        the neutral rate.
        """
        return None if self.is_party else self.elements[0]


class Battle:
    """A turn-based encounter that emits events as it resolves."""

    def __init__(
        self,
        party_combatants: list[Combatant],
        enemy_combatants: list[Combatant],
        moves: dict[str, dict[str, Any]] | None = None,
        potions: int | None = None,
        rng: random.Random | None = None,
        bench: list[Combatant] | None = None,
        combos: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        """Construct a battle from two rosters.

        Args:
            party_combatants: The player's side, the three who fight.
            enemy_combatants: The monsters.
            moves: The moves from the shared battle file, keyed by id.
            potions: Shared potion count; defaults to the new-game stack.
            rng: Random source. Pass a seeded one for a repeatable fight.
            bench: Party members waiting to be swapped in (D-196).
            combos: The combos from the shared battle file, keyed by id.
                Only those in ``COMBOS_BUILT`` are ever offered.
        """
        self.party = party_combatants
        self.enemies = enemy_combatants
        self.bench = list(bench or [])
        self._combos = {
            cid: combo for cid, combo in (combos or {}).items() if cid in COMBOS_BUILT
        }
        self._moves = dict(moves or {})
        self.potions = (
            BattleSettings.STARTING_POTIONS if potions is None else potions
        )
        self._rng = rng or random.Random()
        # Everyone starts at a random point inside the first tick, so
        # the opening order is not always the same.
        for combatant in self.party + self.enemies:
            combatant.counter = self._rng.random()
        self._ended = False
        self._outcome: str | None = None
        self._current_actor: Combatant | None = None
        self._awaiting_command = False
        # The Attack being chained this turn: the enemy it is aimed at,
        # the stroke points used, and how many strokes landed.
        self._chain: dict[str, Any] | None = None

    # ------------------------------------------------------------------
    # PUBLIC
    # ------------------------------------------------------------------

    @property
    def is_over(self) -> bool:
        """Return True once the battle has an outcome."""
        return self._ended

    @property
    def outcome(self) -> str | None:
        """Return "victory", "defeat", "flee", or None while running."""
        return self._outcome

    @property
    def current_actor(self) -> Combatant | None:
        """Return the combatant whose turn it is."""
        return self._current_actor

    def is_awaiting_command(self) -> bool:
        """Return True while a party member's turn waits on the player."""
        return self._awaiting_command

    def moves_for(self, combatant: Combatant) -> list[dict[str, Any]]:
        """Return the moves ``combatant`` can pick, shared ones first.

        Moves come back in the order the shared file lists them, which
        is the menu order in both games. A move with an ``owner``
        belongs to that one character (their special, or their own
        version of a shared move). Any other move belongs to everyone
        carrying its element, unless they are named in its ``except``
        list. A move marked ``off`` is not built yet and is left out, and
        so is one marked ``browser_only``, which only the browser game
        has code for so far. A party member in a stance gets only the
        moves that work in it (``icons_of``, D-362).
        """
        element_ids = [element.value for element in combatant.elements]
        available: list[dict[str, Any]] = []
        for move in self._moves.values():
            if not knows(move, combatant.id, element_ids):
                continue
            if combatant.loadout is not None and move["id"] not in combatant.loadout:
                continue
            if self.works_in_stance(combatant, move):
                available.append(move)
        return available

    @staticmethod
    def row_of(combatant: Combatant, move: dict[str, Any]) -> int:
        """Return the mana row ``move`` sits in for ``combatant``: its slot, or its own row."""
        if combatant.loadout is not None and move["id"] in combatant.loadout:
            return combatant.loadout[move["id"]]
        return home_row(move)

    @staticmethod
    def icons_of(combatant: Combatant, move: dict[str, Any]) -> list[Element]:
        """Return the element icons ``move`` shows for ``combatant`` (D-361, D-362).

        A move that lists ``elements`` shows those; an element move its
        own element; a special both of its user's, its own element first.
        """
        if move.get("elements"):
            return [Element(e) for e in move["elements"]]
        own = Element(move["element"])
        if move.get("tier") in (None, "element") or not combatant.is_party:
            return [own]
        if own in combatant.elements:
            return [own] + [e for e in combatant.elements if e is not own]
        return list(combatant.elements)

    def works_in_stance(self, combatant: Combatant, move: dict[str, Any]) -> bool:
        """Return True when ``move`` works in the stance ``combatant`` is in.

        It works in the stance of each icon it shows; a move whose icons
        are all elements the character lacks works in both.
        """
        stance = combatant.stance_element
        if stance is None:
            return True
        icons = self.icons_of(combatant, move)
        return stance in icons or not any(e in combatant.elements for e in icons)

    def other_stance(self, combatant: Combatant) -> dict[str, Any] | None:
        """Return the stance ``combatant`` could switch to, or None."""
        if len(combatant.stances) < 2:
            return None
        return combatant.stances[1 - combatant.stance]

    def cost_of(self, combatant: Combatant, move: dict[str, Any]) -> int:
        """Return the mana ``move`` costs ``combatant``: the row it sits in."""
        return self.row_of(combatant, move)

    def can_afford(self, combatant: Combatant, move: dict[str, Any]) -> bool:
        """Return True when ``combatant`` has the mana for ``move``."""
        return combatant.mana >= self.cost_of(combatant, move)

    @property
    def chain_points_left(self) -> int:
        """Return the stroke points left in this turn's Attack."""
        used = self._chain["points"] if self._chain else 0
        return BattleSettings.STROKE_POINTS - used

    @property
    def chaining(self) -> bool:
        """Return True once a stroke has been swung this turn."""
        return self._chain is not None

    def chain_target(self) -> Combatant | None:
        """Return the living enemy this turn's strokes are aimed at, or None."""
        if self._chain is None:
            return None
        for combatant in self.enemies:
            if combatant.id == self._chain["target"] and combatant.alive:
                return combatant
        return None

    def stroke_chance(self, kind: str, target: Combatant) -> float:
        """Return the current actor's chance, 0 to 1, that a ``kind`` stroke lands on ``target``.

        The same sum ``_physical`` rolls against: the stroke's own aim,
        steadied by each stroke landed this turn, plus Accuracy, minus
        the target's Evasion; a blind striker misses half outright.
        """
        actor = self._current_actor
        landed = self._chain["landed"] if self._chain else 0
        chance = (
            BattleSettings.STROKES[kind]["hit"]
            + BattleSettings.STROKE_STEADY * landed
            + self._aim(actor) - self._evade(target)
        )
        if "blind" in actor.statuses:
            chance *= 1 - BattleSettings.BLIND_MISS_CHANCE
        return max(0.0, min(1.0, chance))

    def preview_wait(self, kind: str) -> float:
        """Return the wait the current actor would pay for ``kind`` now.

        ``kind`` is "attack" (end the chain), "defend", or anything else
        for a technique or an item. Speed and haste are applied when the
        wait is spent, as for everyone.
        """
        return self._fatigue(kind)

    def upcoming(
        self, count: int, pending_wait: float | None = None
    ) -> list[Combatant]:
        """Predict who acts over the next ``count`` turns.

        The current actor is not included. While a party member's turn
        is waiting, ``pending_wait`` is the wait to assume they pay, so a
        menu can preview its effect on the order. Everyone after that is
        assumed to wait ``BattleSettings.PREVIEW_WAIT``: fatigue depends
        on what they choose, so the order further out is a guess.

        Args:
            count: How many future turns to return.
            pending_wait: The current actor's wait, from ``preview_wait``.

        Returns:
            Combatants in the order they would act. One combatant can
            appear more than once.
        """
        living = [c for c in self.party + self.enemies if c.alive]
        counters = {c.id: c.counter for c in living}
        hastes = {c.id: c.haste for c in living}

        def spend(combatant: Combatant, base_wait: float) -> None:
            wait = base_wait
            if hastes[combatant.id] > 0:
                wait *= BattleSettings.HASTE_WAIT_MULTIPLIER
                hastes[combatant.id] -= 1
            counters[combatant.id] += wait * defense_scale(
                combatant.points["speed"]
            )

        actor = self._current_actor
        if self._awaiting_command and actor is not None and actor.alive:
            spend(actor, pending_wait or BattleSettings.PREVIEW_WAIT)
        order: list[Combatant] = []
        while living and len(order) < count:
            nxt = min(living, key=lambda c: counters[c.id])
            order.append(nxt)
            spend(nxt, BattleSettings.PREVIEW_WAIT)
        return order

    def start_turn(self) -> list[Any]:
        """Advance to the next combatant's turn.

        Runs poison and sleep for whoever is up. A monster's turn is
        resolved here; a party member's turn parks the battle until a
        ``submit_*`` call. A turn lost to sleep or ended by poison
        returns with nothing awaiting, so the scene simply calls
        ``start_turn`` again.
        """
        if self._ended or self._awaiting_command:
            return []
        living = [c for c in self.party + self.enemies if c.alive]
        actor = min(living, key=lambda c: c.counter)
        self._current_actor = actor
        actor.guard = None
        actor.defending = False
        actor.ready = False
        self._chain = None
        events: list[Any] = [TurnStartEvent(actor.id, actor.name)]
        if "poison" in actor.statuses:
            amount = round(actor.max_hp * actor.poison_rate)
            events.extend(self._deal(actor, amount, cause="poison"))
            if not actor.alive:
                events.extend(self._check_terminal())
                return events
        if "sleep" in actor.statuses:
            actor.statuses["sleep"] -= 1
            if actor.statuses["sleep"] <= 0:
                del actor.statuses["sleep"]
            events.append(TurnSkippedEvent(actor.id, actor.name, "sleep"))
            self._spend(actor, BattleSettings.FATIGUE_OTHER)
            return events
        if actor.is_party:
            self._awaiting_command = True
            return events
        events.extend(self._monster_turn(actor))
        events.extend(self._check_terminal())
        return events

    def submit_stroke(self, kind: str, target_id: str) -> list[Any]:
        """Swing one stroke of the Attack at ``target_id``.

        The turn goes on until the player ends the chain, picks a
        technique or Defend, or spends the last of the 7 points; the
        last stroke ends it by itself.

        Args:
            kind: "light", "medium" or "strong".
            target_id: The enemy struck. The first stroke picks it;
                later strokes keep it while it stands.
        """
        actor = self._require_player_actor()
        stroke = BattleSettings.STROKES[kind]
        if stroke["points"] > self.chain_points_left:
            raise ValueError(f"not enough points left for a {kind} stroke")
        if self._chain is None:
            self._chain = {"target": target_id, "points": 0, "landed": 0}
        self._chain["target"] = target_id
        target = self._find(self.enemies, target_id)
        events = self._stroke(actor, target, kind, self._chain)
        terminal = self._check_terminal()
        if terminal:
            self._awaiting_command = False
            return events + terminal
        lightest = BattleSettings.STROKES["light"]["points"]
        if self.chain_points_left < lightest or not actor.alive:
            return self._finish_player_turn(events, "attack")
        return events

    def submit_end_chain(self) -> list[Any]:
        """End the turn after one or more strokes."""
        self._require_player_actor()
        return self._finish_player_turn([], "attack")

    def submit_attack(self, target_id: str) -> list[Any]:
        """Attack with the whole chain at once: light, medium, strong.

        The chain monsters use, for tests and anything that plays the
        party's turn by itself.
        """
        actor = self._require_player_actor()
        self._chain = {"target": target_id, "points": 0, "landed": 0}
        target = self._find(self.enemies, target_id)
        events = self._auto_strokes(actor, target, self._chain)
        return self._finish_player_turn(events, "attack")

    def submit_defend(self) -> list[Any]:
        """Resolve Defend: halve physical damage until the next turn, build 1 mana."""
        actor = self._require_player_actor()
        actor.defending = True
        actor.ready = True
        events: list[Any] = [DefendEvent(actor.id, actor.name)]
        events.extend(self._gain(actor, BattleSettings.DEFEND_MANA))
        return self._finish_player_turn(events, "defend")

    def submit_stance(self) -> list[Any]:
        """Switch to the other stance: builds 1 mana and ends the turn (D-285)."""
        actor = self._require_player_actor()
        other = self.other_stance(actor)
        if other is None:
            raise ValueError(f"{actor.id} has no other stance")
        actor.take_stance(actor.stances.index(other))
        events: list[Any] = [StanceEvent(
            actor.id, actor.name, other["name"], Element(other["element"])
        )]
        events.extend(self._gain(actor, BattleSettings.STANCE_MANA))
        return self._finish_player_turn(events, "move")

    def submit_move(
        self, move_id: str, target_id: str | None = None
    ) -> list[Any]:
        """Resolve a technique, paying its mana.

        Args:
            move_id: An id from the shared file's move list.
            target_id: The chosen combatant, or None for a move whose
                ``target`` is "none". A "fallen" move names a downed ally.
        """
        actor = self._require_player_actor()
        move = self._moves[move_id]
        if not self.can_afford(actor, move):
            raise ValueError(f"{actor.id} cannot pay for {move_id}")
        if not self.works_in_stance(actor, move):
            raise ValueError(f"{move_id} does not work in {actor.id}'s stance")
        pool = self.enemies if move["target"] == "foe" else self.party
        target = self._find(pool, target_id) if target_id else actor
        if move["target"] == "fallen" and target.alive:
            raise ValueError(f"{target.id} is still standing")
        events: list[Any] = [
            AbilityUsedEvent(
                actor.id, actor.name, move_id, move["name"],
                target.name if target is not actor else None,
            )
        ]
        row = self.row_of(actor, move)
        events.extend(self._pay(actor, row))
        events.extend(self._run_effect(actor, target, grown(move, row)))
        return self._finish_player_turn(events, "move")

    def submit_potion(self, target_id: str) -> list[Any]:
        """Resolve drinking or handing over a potion."""
        actor = self._require_player_actor()
        if self.potions <= 0:
            return []
        self.potions -= 1
        target = self._find(self.party, target_id)
        events: list[Any] = [
            PotionUsedEvent(
                actor.id, actor.name, target.id, target.name, self.potions
            )
        ]
        events.extend(self._heal(target, BattleSettings.POTION_HEAL_AMOUNT))
        return self._finish_player_turn(events, "item")

    def combos_for(self, actor: Combatant) -> list[tuple[dict[str, Any], Combatant]]:
        """Return the combos ``actor`` could start now, each with its partner.

        The partner is the ally whose turn comes right after (D-180), or
        anyone who Defended and stands ready (D-182). Each brings the
        element of the stance they are in (D-259). Mana is not checked
        here; ``can_pay_combo`` says whether both have it.
        """
        partners: list[Combatant] = [c for c in self.party if c.ready and c is not actor]
        upcoming = self.upcoming(1, self._fatigue("move"))
        if upcoming and upcoming[0].is_party and upcoming[0] not in partners:
            partners.insert(0, upcoming[0])
        found: list[tuple[dict[str, Any], Combatant]] = []
        for partner in partners:
            if partner is actor or not partner.alive or "sleep" in partner.statuses:
                continue
            for combo in self._combos.values():
                if self._combo_roles(combo, actor, partner) is not None:
                    found.append((combo, partner))
        return found

    def can_pay_combo(self, actor: Combatant, partner: Combatant) -> bool:
        """Return True when both partners have the mana a combo takes."""
        need = BattleSettings.COMBO_MANA
        return actor.mana >= need and partner.mana >= need

    @staticmethod
    def _combo_roles(
        combo: dict[str, Any], actor: Combatant, partner: Combatant
    ) -> dict[str, Combatant] | None:
        """Return who brings each of ``combo``'s elements, or None if they cannot."""
        x, y = combo["elements"]
        mine = actor.stance_element.value if actor.stance_element else None
        theirs = partner.stance_element.value if partner.stance_element else None
        if (mine, theirs) == (x, y):
            return {x: actor, y: partner}
        if (mine, theirs) == (y, x):
            return {y: actor, x: partner}
        return None

    def submit_combo(
        self, combo_id: str, partner_id: str, target_id: str | None = None
    ) -> list[Any]:
        """Strike together with a partner. Both pay the mana; it uses up the partner's coming turn."""
        actor = self._require_player_actor()
        combo = self._combos[combo_id]
        partner = self._find(self.party, partner_id)
        roles = self._combo_roles(combo, actor, partner)
        if roles is None:
            raise ValueError(f"{actor.id} and {partner_id} cannot do {combo_id}")
        if not self.can_pay_combo(actor, partner):
            raise ValueError(f"{combo_id} needs more mana")
        events: list[Any] = [ComboUsedEvent(
            actor.id, actor.name, partner.id, partner.name, combo["name"]
        )]
        events.extend(self._pay(actor, BattleSettings.COMBO_MANA))
        events.extend(self._pay(partner, BattleSettings.COMBO_MANA))
        target = self._find(self.enemies, target_id) if target_id else None
        events.extend(self._run_combo(combo, roles, target))
        partner.ready = False
        self._spend(partner, BattleSettings.FATIGUE_OTHER)
        return self._finish_player_turn(events, "move")

    def _run_combo(
        self,
        combo: dict[str, Any],
        roles: dict[str, Combatant],
        target: Combatant | None,
    ) -> list[Any]:
        """Play one combo's effect, as the browser does."""
        power = combo["power"]
        cid = combo["id"]
        events: list[Any] = []
        if cid == "solar_fist":
            return self._physical(roles["ahi"], target, power, Element.LA)
        if cid == "vine_whip":
            return self._physical(roles["ahi"], target, power, Element.LAU)
        if cid == "eclipse":
            for foe in [c for c in self.enemies if c.alive]:
                events.extend(self._magic(roles["la"], foe, power, Element.LA))
                if foe.alive:
                    events.extend(self._magic(roles["ata"], foe, power, Element.ATA))
                if foe.alive:
                    events.extend(self._inflict(foe, "blind"))
            return events
        if cid == "daybreak":
            for foe in [c for c in self.enemies if c.alive]:
                foe.haste = 0
                foe.ward = False
                events.extend(self._magic(roles["mana"], foe, power, Element.LA))
            return events
        raise ValueError(f"combo {cid} is not built")

    def submit_swap(self, bench_id: str) -> list[Any]:
        """Send the one acting to the bench and bring ``bench_id`` in, as the browser does.

        The one coming in takes the same place and clock, and the turn
        is theirs at once.
        """
        actor = self._require_player_actor()
        newcomer = self._find(self.bench, bench_id)
        if not newcomer.alive:
            raise ValueError(f"{bench_id} cannot fight")
        newcomer.counter = actor.counter
        newcomer.guard = None
        newcomer.defending = False
        newcomer.ready = False
        self.party[self.party.index(actor)] = newcomer
        self.bench.remove(newcomer)
        self.bench.append(actor)
        actor.guard = None
        actor.defending = False
        actor.ready = False
        self._chain = None
        self._current_actor = newcomer
        return [SwapEvent(actor.id, actor.name, newcomer.id, newcomer.name)]

    def submit_weapon(self, weapon_name: str) -> list[Any]:
        """Change the weapon held: builds 1 mana, 1 fatigue less, ends the turn (D-455)."""
        actor = self._require_player_actor()
        actor.weapon = weapon_name
        events: list[Any] = [WeaponEvent(actor.id, actor.name, weapon_name)]
        events.extend(self._gain(actor, BattleSettings.WEAPON_MANA))
        return self._finish_player_turn(events, "defend")

    def escape_chance(self) -> float:
        """Return the one acting's chance, 0 to 1, of running away."""
        actor = self._current_actor
        fastest = max(
            (c.points["speed"] for c in self.enemies if c.alive), default=0
        )
        low, high = BattleSettings.ESCAPE_LIMITS
        chance = BattleSettings.ESCAPE_CHANCE + BattleSettings.ESCAPE_PER_SPEED * (
            actor.points["speed"] - fastest
        )
        return max(low, min(high, chance))

    def submit_escape(self) -> list[Any]:
        """Try to run (D-455). A failure builds no mana, costs 1 fatigue less and ends the turn."""
        actor = self._require_player_actor()
        escaped = self._rng.random() < self.escape_chance()
        events: list[Any] = [EscapeEvent(actor.id, actor.name, escaped)]
        if escaped:
            self._awaiting_command = False
            return events + self._end("flee")
        return self._finish_player_turn(events, "defend")

    def flee(self) -> list[Any]:
        """End the battle by running away."""
        self._awaiting_command = False
        return self._end("flee")

    # ------------------------------------------------------------------
    # MOVE EFFECTS
    # ------------------------------------------------------------------

    def _run_effect(
        self, actor: Combatant, target: Combatant, move: dict[str, Any]
    ) -> list[Any]:
        """Run one party move's ``effect`` and return its events."""
        effect = move["effect"]
        element = Element(move["element"])
        statuses = move.get("statuses", [])
        if effect == "physical":
            return self._physical(
                actor, target, move["power"], element, statuses
            )
        if effect == "magic":
            return self._magic(actor, target, move["power"], element, statuses)
        if effect == "guard":
            actor.guard = move["guard"]
            return [GuardRaisedEvent(actor.id, actor.name, move["guard"])]
        if effect == "cure":
            amount = round(
                move["power"] * offense_scale(actor.points["magic"])
            )
            return self._heal(target, amount)
        if effect == "cleanse":
            for status in move.get("statuses", _CLEANSABLE):
                target.statuses.pop(status, None)
            return [CleansedEvent(target.id, target.name)]
        if effect == "ward":
            target.ward = True
            return [StatusAppliedEvent(target.id, target.name, "ward", True)]
        if effect == "haste":
            target.haste = BattleSettings.HASTE_ACTIONS + move.get("extra_turns", 0)
            return [StatusAppliedEvent(target.id, target.name, "haste", True)]
        if effect == "purify":
            target.statuses.clear()
            events = self._heal(target, target.max_hp)
            target.ward = True
            events.append(
                StatusAppliedEvent(target.id, target.name, "ward", True)
            )
            return events
        if effect == "revive":
            return self._revive(actor, target, move.get("revive_share", 0.5))
        if effect == "drain":
            # Half the damage comes back to the caster. The browser can
            # give it to an ally instead; that waits.
            before = target.hp
            events = self._magic(actor, target, move["power"], element, statuses)
            dealt = before - target.hp
            if dealt > 0:
                events.extend(self._heal(actor, round(dealt / 2)))
            return events
        raise ValueError(f"move {move['id']} has unknown effect {effect!r}")

    def _revive(self, actor: Combatant, target: Combatant, share: float) -> list[Any]:
        """Bring a fallen ally back with ``share`` of their max HP (D-456).

        Revive brings half, Full Revive all of it.

        As in the browser, they rejoin the order as if they had just used
        a technique: the reviver's counter plus one technique's wait,
        shortened by their own Speed.
        """
        target.hp = max(1, round(target.max_hp * share))
        target.statuses.clear()
        target.counter = actor.counter + BattleSettings.FATIGUE_OTHER * defense_scale(
            target.points["speed"]
        )
        return [RevivedEvent(target.id, target.name, target.hp)]

    def _monster_turn(self, monster: Combatant) -> list[Any]:
        """Pick one of ``monster``'s moves by weight and play it.

        Every named move costs its ``tier`` in mana (D-329). A monster
        that cannot pay yet attacks with a chain of strokes instead,
        which builds the mana, so a big move comes once it is paid for.
        """
        move = self._rng.choices(
            monster.moves, weights=[m["weight"] for m in monster.moves]
        )[0]
        cost = min(
            BattleSettings.MANA_CAP,
            max(1, int(move.get("tier") or move.get("warmup") or 0)),
        )
        living = [c for c in self.party if c.alive]
        if cost > monster.mana:
            chain = {"target": None, "points": 0, "landed": 0}
            events = self._auto_strokes(monster, self._rng.choice(living), chain)
            struck = {e.target_name for e in events if isinstance(e, StrokeEvent)}
            events.append(ChainEndedEvent(
                monster.id, monster.name,
                struck.pop() if len(struck) == 1 else None,
                sum(e.amount for e in events
                    if isinstance(e, DamageEvent) and e.cause == "stroke"),
            ))
            self._spend(monster, max(
                BattleSettings.FATIGUE_LEAST,
                chain["points"] * BattleSettings.STROKE_WAIT,
            ))
            return events
        element = Element(move["element"]) if move["element"] else None
        power = move["power"] * BattleSettings.MONSTER_POWER_SCALE
        # A move that hits everyone cannot be guarded.
        targets = living if move["all"] else [self._rng.choice(living)]
        events: list[Any] = []
        for target in targets:
            if not target.alive or not monster.alive:
                continue
            events.append(
                AttackEvent(
                    monster.id, monster.name, target.id, target.name,
                    element, move["name"],
                )
            )
            if move["kind"] == "physical":
                events.extend(
                    self._physical(
                        monster, target, power, element,
                        move["statuses"], unguardable=move["all"],
                    )
                )
            else:
                events.extend(
                    self._magic(
                        monster, target, power, element, move["statuses"]
                    )
                )
        events.extend(self._pay(monster, cost))
        self._spend(monster, BattleSettings.FATIGUE_OTHER)
        return events

    def _stroke(
        self,
        attacker: Combatant,
        target: Combatant,
        kind: str,
        chain: dict[str, Any],
    ) -> list[Any]:
        """Swing one stroke and keep the chain's count.

        Each stroke that lands this turn steadies the next one, and
        builds the striker its points in mana.
        """
        stroke = BattleSettings.STROKES[kind]
        power = BattleSettings.STROKE_POWER * stroke["power"]
        if not attacker.is_party:
            power *= BattleSettings.MONSTER_POWER_SCALE
        events: list[Any] = [
            StrokeEvent(
                attacker.id, attacker.name, target.id, target.name, stroke["name"]
            )
        ]
        hit = self._physical(
            attacker, target, power, None,
            accuracy=stroke["hit"] + BattleSettings.STROKE_STEADY * chain["landed"],
            stroke=stroke["name"],
        )
        events.extend(hit)
        chain["points"] += stroke["points"]
        if any(isinstance(e, DamageEvent) and e.cause == "stroke" for e in hit):
            chain["landed"] += 1
            events.extend(self._gain(attacker, stroke["points"]))
        return events

    def _auto_strokes(
        self, attacker: Combatant, target: Combatant, chain: dict[str, Any]
    ) -> list[Any]:
        """Swing the light, medium and strong chain, as far as the points go.

        If the target falls, the rest of the chain goes to the weakest
        one standing on its side.
        """
        events: list[Any] = []
        for kind in BattleSettings.AUTO_STROKES:
            points = BattleSettings.STROKES[kind]["points"]
            if chain["points"] + points > BattleSettings.STROKE_POINTS or not attacker.alive:
                break
            if not target.alive:
                side = self.party if target.is_party else self.enemies
                standing = [c for c in side if c.alive]
                if not standing:
                    break
                target = min(standing, key=lambda c: c.hp)
            events.extend(self._stroke(attacker, target, kind, chain))
        return events

    # ------------------------------------------------------------------
    # DAMAGE AND HEALING
    # ------------------------------------------------------------------

    def _physical(
        self,
        attacker: Combatant,
        target: Combatant,
        power: float,
        element: Element | None,
        statuses: Iterable[str] = (),
        unguardable: bool = False,
        accuracy: float | None = None,
        stroke: str | None = None,
    ) -> list[Any]:
        """Resolve one physical hit, including any guard in the way.

        Any blow can be dodged (Evasion against Accuracy) or blocked for
        half damage (Vitality); either builds the defender 1 mana.
        ``accuracy`` is a stroke's chance to land, None for a sure blow.
        """
        if (
            "blind" in attacker.statuses
            and self._rng.random() < BattleSettings.BLIND_MISS_CHANCE
        ):
            return [
                MissEvent(attacker.id, attacker.name, target.id, target.name)
            ]
        events: list[Any] = []
        guard = None if unguardable else self._guard_for(target)
        struck = guard or target
        if guard is not None and guard is not target:
            events.append(
                GuardInterceptEvent(
                    guard.id, guard.name, target.id, target.name
                )
            )
        if element is Element.ATA and struck.ward:
            struck.ward = False
            events.append(WardBlockedEvent(struck.id, struck.name))
            return events
        chance = (1.0 if accuracy is None else accuracy) + self._aim(attacker) - self._evade(struck)
        if self._rng.random() >= chance:
            events.append(DodgeEvent(attacker.id, attacker.name, struck.id, struck.name, stroke))
            events.extend(self._gain(struck, BattleSettings.DODGE_MANA))
            return events
        blocked = self._rng.random() < self._block(struck)
        if guard is not None:
            multiplier = BattleSettings.GUARD_MULTIPLIER
            if element is Element.AHI:
                multiplier *= BattleSettings.GUARD_AHI_MULTIPLIER
            elif element is Element.LAU:
                multiplier *= BattleSettings.GUARD_LAU_MULTIPLIER
        else:
            multiplier = self._weakness(element, struck)
            if struck.defending:
                multiplier *= BattleSettings.DEFEND_MULTIPLIER
        if blocked:
            multiplier *= BattleSettings.BLOCK_MULTIPLIER
        amount = self._jitter(
            power
            * multiplier
            * offense_scale(attacker.points["strength"])
            * defense_scale(struck.points["vitality"])
        )
        woke = struck.statuses.pop("sleep", None) is not None
        events.extend(
            self._deal(
                struck, amount, element, multiplier,
                guarded=guard is not None, woke=woke,
                cause="stroke" if stroke else "hit", blocked=blocked,
                attacker_name=attacker.name, stroke=stroke,
            )
        )
        if blocked:
            events.extend(self._gain(struck, BattleSettings.DODGE_MANA))
        for status in statuses:
            events.extend(self._inflict(struck, status))
        if (
            guard is not None
            and guard.alive
            and guard.guard == "counter"
            and attacker.alive
        ):
            counter_multiplier = self._weakness(Element.AHI, attacker)
            counter = self._jitter(
                BattleSettings.ATTACK_POWER
                * counter_multiplier
                * offense_scale(guard.points["strength"])
                * defense_scale(attacker.points["vitality"])
            )
            events.extend(
                self._deal(
                    attacker, counter, Element.AHI, counter_multiplier,
                    cause="counter",
                )
            )
        return events

    def _magic(
        self,
        attacker: Combatant,
        target: Combatant,
        power: float,
        element: Element | None,
        statuses: Iterable[str] = (),
    ) -> list[Any]:
        """Resolve one spell. Guards and Defend do nothing against it."""
        if element is Element.ATA and target.ward:
            target.ward = False
            return [WardBlockedEvent(target.id, target.name)]
        events: list[Any] = []
        if power:
            multiplier = self._weakness(element, target)
            amount = self._jitter(
                power
                * multiplier
                * offense_scale(attacker.points["magic"])
                * defense_scale(target.points["spirit"])
            )
            events.extend(
                self._deal(target, amount, element, multiplier, cause="spell")
            )
        for status in statuses:
            events.extend(self._inflict(target, status))
        return events

    def _deal(
        self,
        target: Combatant,
        amount: int,
        element: Element | None = None,
        multiplier: float = NEUTRAL_MULTIPLIER,
        guarded: bool = False,
        woke: bool = False,
        cause: str = "hit",
        blocked: bool = False,
        attacker_name: str | None = None,
        stroke: str | None = None,
    ) -> list[Any]:
        """Take ``amount`` HP off ``target`` and report it."""
        if not target.alive:
            return []
        target.hp = max(0, target.hp - amount)
        events: list[Any] = [
            DamageEvent(
                target.id, target.name, amount, element, multiplier,
                guarded, woke, cause, blocked, attacker_name, stroke,
            )
        ]
        if not target.alive:
            target.statuses.clear()
            target.guard = None
            target.ward = False
            target.haste = 0
            events.append(CombatantDefeatedEvent(target.id, target.name))
        return events

    def _heal(self, target: Combatant, amount: int) -> list[Any]:
        """Restore up to ``amount`` HP on a living ``target``."""
        if not target.alive:
            return []
        before = target.hp
        target.hp = min(target.max_hp, target.hp + max(0, amount))
        return [HealEvent(target.id, target.name, target.hp - before)]

    def _inflict(self, target: Combatant, status: str) -> list[Any]:
        """Try to give ``target`` a status."""
        if not target.alive:
            return []
        if status in target.immune:
            return [
                StatusResistedEvent(target.id, target.name, status, True)
            ]
        if self._rng.random() > BattleSettings.STATUS_HIT_CHANCE:
            return [
                StatusResistedEvent(target.id, target.name, status, False)
            ]
        if status == "sleep":
            target.statuses["sleep"] = BattleSettings.SLEEP_TURNS
            target.guard = None
        else:
            target.statuses[status] = 1
        return [StatusAppliedEvent(target.id, target.name, status, True)]

    # ------------------------------------------------------------------
    # INTERNALS
    # ------------------------------------------------------------------

    @staticmethod
    def _aim(attacker: Combatant) -> float:
        """Accuracy's share of a blow's chance to land."""
        over = attacker.points["accuracy"] - StatSettings.BASE_POINTS
        return BattleSettings.PER_ACCURACY * over

    @staticmethod
    def _evade(target: Combatant) -> float:
        """The chance ``target`` dodges a sure blow. A sleeper cannot."""
        if "sleep" in target.statuses:
            return 0.0
        over = target.points["evasion"] - StatSettings.BASE_POINTS
        return BattleSettings.EVADE_BASE + BattleSettings.PER_EVASION * over

    @staticmethod
    def _block(target: Combatant) -> float:
        """The chance ``target`` blocks a blow that lands. A sleeper cannot."""
        if "sleep" in target.statuses:
            return 0.0
        over = target.points["vitality"] - StatSettings.BASE_POINTS
        return BattleSettings.BLOCK_BASE + BattleSettings.PER_VITALITY * over

    def _gain(self, combatant: Combatant, amount: int) -> list[Any]:
        """Build ``amount`` mana, up to the cap."""
        if not combatant.alive or amount <= 0:
            return []
        before = combatant.mana
        combatant.mana = min(BattleSettings.MANA_CAP, before + amount)
        if combatant.mana == before:
            return []
        return [ManaEvent(
            combatant.id, combatant.name, combatant.mana - before, combatant.mana
        )]

    def _pay(self, combatant: Combatant, amount: int) -> list[Any]:
        """Spend ``amount`` mana."""
        before = combatant.mana
        combatant.mana = max(0, before - amount)
        if combatant.mana == before:
            return []
        return [ManaEvent(
            combatant.id, combatant.name, combatant.mana - before, combatant.mana
        )]

    def _fatigue(self, kind: str) -> float:
        """Return the wait the current turn has built (D-328).

        Each stroke its points; "attack" adds nothing more, "defend"
        takes 1 off (0.5 at least), anything else adds 1.
        """
        points = self._chain["points"] if self._chain else 0
        strokes = points * BattleSettings.STROKE_WAIT
        if kind == "attack":
            return max(BattleSettings.FATIGUE_LEAST, strokes)
        if kind == "defend":
            return max(
                BattleSettings.FATIGUE_DEFEND_LEAST,
                strokes + BattleSettings.FATIGUE_DEFEND,
            )
        return max(BattleSettings.FATIGUE_LEAST, strokes + BattleSettings.FATIGUE_OTHER)

    def _guard_for(self, target: Combatant) -> Combatant | None:
        """Return the living ally on ``target``'s side holding a guard."""
        side = self.party if target.is_party else self.enemies
        for combatant in side:
            if combatant.alive and combatant.guard is not None:
                return combatant
        return None

    def _weakness(
        self, element: Element | None, target: Combatant
    ) -> float:
        """Return the element multiplier for ``element`` hitting ``target``."""
        if element is None or target.element is None:
            return NEUTRAL_MULTIPLIER
        return damage_multiplier(element, target.element)

    def _jitter(self, amount: float) -> int:
        """Roll ``amount`` within the jitter band and round it."""
        spread = BattleSettings.DAMAGE_JITTER
        roll = 1 - spread + self._rng.random() * 2 * spread
        return int(amount * roll + 0.5)

    def _spend(self, combatant: Combatant, base_wait: float) -> None:
        """Push ``combatant``'s counter forward by one action's wait."""
        wait = base_wait
        if combatant.haste > 0:
            wait *= BattleSettings.HASTE_WAIT_MULTIPLIER
            combatant.haste -= 1
        combatant.counter += wait * defense_scale(combatant.points["speed"])

    def _find(self, pool: list[Combatant], combatant_id: str) -> Combatant:
        """Return the combatant with ``combatant_id`` from ``pool``."""
        for combatant in pool:
            if combatant.id == combatant_id:
                return combatant
        raise KeyError(combatant_id)

    def _require_player_actor(self) -> Combatant:
        """Return the party member whose turn is waiting on input."""
        if not self._awaiting_command or self._current_actor is None:
            raise RuntimeError("No party command is awaiting input")
        return self._current_actor

    def _finish_player_turn(self, events: list[Any], kind: str) -> list[Any]:
        """Charge the turn's fatigue and close it.

        ``kind`` is "attack", "defend", "move" or "item" (``_fatigue``).
        """
        self._spend(self._current_actor, self._fatigue(kind))
        self._chain = None
        self._awaiting_command = False
        events.extend(self._check_terminal())
        return events

    def _check_terminal(self) -> list[Any]:
        """End the battle if either side has nobody standing."""
        if not any(c.alive for c in self.enemies):
            return self._end("victory")
        if not any(c.alive for c in self.party):
            return self._end("defeat")
        return []

    def _end(self, outcome: str) -> list[Any]:
        """Record ``outcome`` once and report it."""
        if self._ended:
            return []
        self._ended = True
        self._outcome = outcome
        return [BattleEndedEvent(outcome)]
