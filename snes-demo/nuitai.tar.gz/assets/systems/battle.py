"""Turn-based battle simulation. Pure data; emits events; never draws.

The rules are a port of the browser battle test
(``archive/browser-battle/ctb-battle.html``); the design notes are in
``archive/browser-battle/battle-moves.md``. In short:

* **Conditional turns.** Every combatant has a counter. The lowest
  counter acts next. Acting adds a wait to the actor's counter, and the
  wait is fatigue (D-328): what the turn built, each stroke its points,
  a Skill 7, anything else 1, Defend included. Speed shrinks every wait.
* **Mana is the meter** (D-213 to D-220), up to 7. Attack is a chain
  of strokes on one enemy, light, medium or strong, up to 7 points a
  turn; each stroke that lands builds its points in mana. Defend
  builds 1, and so does dodging or blocking a blow. A technique costs
  the mana row it is slotted in, and a higher row grows it (D-318 to
  D-320, ``systems/loadout.py``). Monsters play by the same rules (D-329): a
  monster picks a move, and if it cannot pay for it yet it attacks
  with strokes instead.
* **Stats come from elements** (``core/stats.py``). Strength and Magic
  scale damage dealt; Vitality and Spirit scale damage taken.
* **Element moves are shared** by everyone who carries that element.
  Each party member also owns one special. Moves are data, in the
  shared battle file (``core/shared.py``); this module knows how to
  run each ``effect``.
* **Stances** (D-257, D-285, D-286, D-365). A party member fights in
  one of two stances, one per element, starting in the first. The
  stance's element counts twice in the stats and the other not at all,
  HP keeping its share. A move works in the stance of each element icon
  it shows (D-362): an element move shows its own element, a special
  both of its owner's unless the file lists ``elements``. Switching
  builds 1 mana and ends the turn.
* **Stats grow by use** (D-498, D-500, D-507). When a party member
  does a stat's action (lands a stroke, casts, is hit, dodges) it puts
  points in that stat's hidden meter; a full meter raises the stat by 1,
  said at once; see ``_fill``.
* **Physical and magic are separate.** Defend and the guard stances
  only work on physical hits. A monster has one element that decides
  what it is weak to; a party member, the element of their stance
  (D-590). A boss has two elements and changes stance for a reason
  (D-591, D-601), and a monster's damage is its strokes (D-598), as
  strong as its own Strength and Magic make them, on the heroes' rules.

The scene drives a battle in two beats:

1. ``start_turn()`` picks the next combatant, runs start-of-turn
   effects, and resolves the turn if it is a monster's. For a party
   member it parks the battle in awaiting-command mode
   (``is_awaiting_command()``).
2. One of the ``submit_*`` methods resolves the player's choice.

Both return a list of events (``core/events.py``) for a view to narrate.
"""

from __future__ import annotations

import random
from fractions import Fraction
from typing import Any, Iterable

from core.elements import Element, NEUTRAL_MULTIPLIER, damage_multiplier
from core.equipment import relic_multiplier
from core.events import (
    AbilityUsedEvent,
    AttackEvent,
    BattleEndedEvent,
    ChainEndedEvent,
    CleansedEvent,
    ComboUsedEvent,
    CombatantDefeatedEvent,
    DamageEvent,
    DefendEvent,
    DodgeEvent,
    EscapeEvent,
    GuardInterceptEvent,
    GuardRaisedEvent,
    HealEvent,
    ManaEvent,
    MissEvent,
    NoteEvent,
    NoniUsedEvent,
    RevivedEvent,
    StatusAppliedEvent,
    StanceEvent,
    StatGrowthEvent,
    StatusResistedEvent,
    StrokeEvent,
    SummonEvent,
    SwapEvent,
    TurnSkippedEvent,
    TurnStartEvent,
    WardBlockedEvent,
    WeaponEvent,
)
from core.shared import SHARED
from core.stats import defense_scale, max_hp_for, offense_scale, stat_points
from systems import battle_kits
from systems.loadout import grown, home_row, knows
from settings import BattleSettings, ItemSettings, LoadoutSettings, StatSettings


# The combos this game can play so far, out of the fifteen in the shared
# file (D-419). Each needs only rules this game already has; the rest
# wait, added slowly (Frankie, 10/18).
COMBOS_BUILT: tuple[str, ...] = ("solar_fist", "vine_whip", "eclipse", "daybreak")

# Growth by use (D-507): the shared file's numbers, these if it has none.
# ``step`` multiplies every point: 1, or more with Tawiri along.
_GROWTH: dict[str, Any] = {
    "meter": 100, "cap": 255, "step": 1,
    "strong_stroke": 4, "technique_per_row": 10, "spell_per_row": 15, "vitality_share": 0.5,
    "light_streak": 4, "perception_miss": 0.4, "luck_hit": 0.3, "weaker_floor": 0.1,
    **{
        key: value for key, value in SHARED.get("stats", {}).get("growth", {}).items()
        if not key.startswith("_")
    },
}


# Statuses Cure All removes; Cure Blind, Sleep and Poison name their own. Purification removes every status.
_CLEANSABLE: tuple[str, ...] = ("blind", "sleep", "poison")

# The shared file's rules, combos and moves, for the numbers the kits read.
_RULES: dict[str, Any] = SHARED.get("rules", {})
_COMBO: dict[str, dict[str, Any]] = {c["id"]: c for c in SHARED.get("combos", [])}
_MOVE: dict[str, dict[str, Any]] = {m["id"]: m for m in SHARED.get("moves", [])}
SHARED_MONSTERS: dict[str, dict[str, Any]] = {m["id"]: m for m in SHARED.get("monsters", [])}
_ITEM_NAME: dict[str, str] = {i["id"]: i["name"] for i in SHARED.get("items", [])}
# Kailo's Cook (Frankie, 10/22): the shared file's cooking table.
_COOKING: dict[str, Any] = SHARED["cooking"]
_DISH: dict[str, dict[str, Any]] = {d["id"]: d for d in _COOKING["dishes"]}


def dish_from(first: str, second: str) -> dict[str, Any] | None:
    """The dish two ingredients make, in either order, or None."""
    pair = sorted((first, second))
    return next((d for d in _COOKING["dishes"] if sorted(d["from"]) == pair), None)


def fresh_heal(dish_id: str) -> int:
    """What a dish heals served fresh by Cook: half again its bag version, rounded half up as the browser rounds."""
    return int(ItemSettings.HEALS[dish_id] * _COOKING["fresh_multiplier"] + 0.5)

# The guards that step in front of a physical hit (the browser's SENT), and
# those that step in only for fire (FIRE_SENT). A self guard cuts one
# element's hits on its holder only (SELF_EL).
_SENTINELS: tuple[str, ...] = (
    "sentinel", "cooker", "counter", "bell", "oil", "steam", "boil", "cast_iron",
)
_FIRE_SENTINELS: tuple[str, ...] = ("fire_sentinel", "fire_spring")
_SELF_GUARDS: dict[str, Element] = {"oven_mitt": Element.AFI, "fire_guard": Element.AFI}

# The curses Hex Bolt counts (the browser's HEXES).
_HEXES: tuple[str, ...] = (
    "blind", "sleep", "poison", "weak", "mbreak", "slow", "possess", "sap", "doom",
    "haunt", "grip", "burn", "wasting", "abreak",
)

# Statuses that count down one a turn at the top of their holder's turn.
_COUNTED: tuple[str, ...] = ("weak", "calm", "mleech")

# Stat boosts (D-351, D-716): a stat up by a quarter of base plus the stat,
# until the third turn from now. Max HP up adds a quarter to max HP.
_BOOST_UP = (_RULES.get("stat_steps") or {}).get("up", 0.25)
_DROP_DOWN = (_RULES.get("stat_steps") or {}).get("down", 0.2)

# The shared file's short stat names, as Scold's reactions write them.
_STAT_KEY: dict[str, str] = {
    "hp": "hp", "str": "strength", "mag": "magic", "vit": "vitality",
    "spr": "spirit", "spd": "speed", "acc": "accuracy", "eva": "evasion",
}
# The browser's words for the stats, which its stat messages use.
_STAT_WORD: dict[str, str] = {
    "hp": "Max HP", "strength": "Strength", "magic": "Magic", "vitality": "Vitality",
    "spirit": "Spirit", "speed": "Speed", "accuracy": "Accuracy", "evasion": "Evasion",
}


class Combatant:
    """One participant in a battle."""

    def __init__(
        self,
        combatant_id: str,
        name: str,
        elements: Iterable[Element],
        is_party: bool,
        max_hp: int,
        hp: int | None = None,
        moves: list[dict[str, Any]] | None = None,
        beast: bool = False,
        immune: Iterable[str] = (),
        poison_rate: float | None = None,
        stances: list[dict[str, Any]] | None = None,
        stance: int = 0,
        loadout: dict[str, int] | None = None,
        growth: dict[str, int] | None = None,
        meters: dict[str, float] | None = None,
        pools: list[tuple[Element, list[dict[str, Any]]]] | None = None,
        switch: list[dict[str, Any]] | None = None,
        kind: str | None = None,
        loot: str | None = None,
        multipliers: dict[str, Fraction] | None = None,
        relic: str | None = None,
    ) -> None:
        """Construct a combatant.

        Args:
            combatant_id: Stable id, e.g. a party member or enemy id.
            name: Display name.
            elements: The combatant's elements. Party members carry
                two. A monster carries one, listed twice for a boss.
            is_party: True for party members, False for monsters.
            max_hp: Hit point ceiling.
            hp: Starting HP for this battle; defaults to ``max_hp``.
                A party member who walked in hurt passes less.
            moves: A monster's move list, from the shared battle file.
                Party members leave this empty; their moves come from
                ``Battle.moves_for``.
            beast: True for an animal. Nothing reads this yet; it is
                carried for moves that will care, like Leilagi's Hunt.
            immune: Status ids this combatant can never be given.
            poison_rate: Share of max HP lost to poison each turn, for
                a boss that poison should only nibble at. None means
                the ordinary rate.
            stances: A party member's two stances from the shared file
                (``name``, ``element``). Monsters have none.
            stance: Which stance a party member starts the fight in,
                chosen on the party screen.
            loadout: A party member's slotted techniques, move id ->
                row (``systems/loadout.py``). None offers every move
                they know, each in its own row.
            growth: A party member's points grown by use (D-498), stat
                key -> points. Copied: the battle grows its own, and the
                scene writes them back when the fight ends. A monster's
                are its own stats from the shared file, which never grow.
            meters: A party member's hidden meter for each stat (Frankie,
                10/27), stat key -> points toward the next rise. Copied,
                and written back by the scene like ``growth``.
            pools: A two-stance monster's stances (D-591): for each, its
                element and its moves, the first the one it starts in.
            switch: Why that monster leaves each stance (D-601), from
                the shared file. None switches at random.
            kind: A monster's kind in the shared file ("boar"), which
                Hina's Scold reacts to. None for a party member.
            loot: The item a monster carries (its ``steal``), until it
                is given away.
            multipliers: What a party member's weapon does to their
                stats (core/equipment.py), stat key -> multiplier.
            relic: The relic a party member wears, whose element adds
                its stance weakness to theirs (core/equipment.py).
        """
        self.id = combatant_id
        self.name = name
        self.elements = tuple(elements)
        self.is_party = is_party
        self.stances = list(stances or [])
        self.stance = stance if 0 <= stance < len(self.stances) else 0
        self.loadout = dict(loadout) if loadout is not None else None
        self.growth: dict[str, int] = dict(growth or {})
        self.meters: dict[str, float] = dict(meters or {})
        # What has grown this fight, stat key -> points, for the victory
        # screen; a stat can rise more than once a fight (Frankie, 10/26).
        self.grown: dict[str, int] = {}
        # What Kailo's Cook has on the fire, served at the start of his next
        # turn: "cure" or "heal" (Frankie, 10/25).
        self.dish: str | None = None
        self.kind = kind
        self.loot = loot
        self.multipliers = dict(multipliers or {})
        self.relic = relic
        # Left the fight (Scold): down, but not beaten.
        self.gone = False
        # Tawiri's spirit (Call): the turns it has left on the party's side; 0 for anyone else.
        self.summon_turns = 0
        self.points = stat_points(self.elements, self.stance_element, self.growth, self.multipliers)
        self.max_hp = max_hp
        self.hp = max_hp if hp is None else hp
        if self.stances:
            self._fit_hp_to_stance()
        self.moves = list(moves) if moves else []
        self.beast = beast
        self.immune = frozenset(immune)
        self.poison_rate = (
            BattleSettings.POISON_RATE if poison_rate is None else poison_rate
        )
        # Turn counter. The lowest counter in the battle acts next.
        self.counter = 0.0
        # The mana meter, 0 to ``BattleSettings.MANA_CAP``.
        self.mana = BattleSettings.MANA_START
        # Status id -> turns left. Blind and poison have no timer and
        # hold a 1 until cured; sleep counts down.
        self.statuses: dict[str, int] = {}
        # Shaka's Light: the share of the next shadow hit it cuts, then it is
        # spent (Frankie, 10/28); 0 for none.
        self.ward = 0.0
        # Remaining actions that cost a shortened wait.
        self.haste = 0
        # Safeguard: stops the next blind, sleep or poison, then is spent.
        self.safe = False
        # Regen: turns left that heal a little at the top of the turn.
        self.regen = 0
        # Set by Defend, cleared at the top of this combatant's turn.
        self.defending = False
        # Guard stance id ("sentinel", "counter", "cooker", Kailo's
        # "bell", "oil", ...) or None. At the top of this combatant's
        # turn it holds while ``guard_left`` counts down (a guard slotted
        # above its row holds longer, D-325), then it drops.
        self.guard: str | None = None
        self.guard_left = 0
        # The share of a hit a guard lets through, when it is not the usual.
        self.guard_m: float | None = None
        # How hard Counter kicks back, when it is not the usual (grown, Frankie 10/28).
        self.guard_kick: float | None = None
        # Simmer and Boil Over (Frankie, 10/19): the enemy it
        # will go off on, and the damage held in since it was raised.
        self.cooker_target: str | None = None
        self.cooker_took = 0
        # Tawiri's called spirit (Call the Dead): turns left and its power.
        self.spirit: dict[str, Any] | None = None
        # Who put a status on: "sap" and "mleech" pay back their caster.
        self.cursed_by: dict[str, str] = {}
        # Haunt's bite, worked out when it was cast.
        self.haunt_damage = 0
        # Stat boosts in force (D-716), stat key -> points added (max HP for "hp").
        self.boosts: dict[str, int] = {}
        # Stat drops in force, stat key -> points taken off.
        self.drops: dict[str, int] = {}
        # A boss: Death Knell does nothing to it, Grave Grip holds it one turn.
        self.boss = False
        # Set by Defend: until their next turn an ally can pull them into
        # a combo (D-182).
        self.ready = False
        # The weapon held, by name, or None. What it does to the stats is ``multipliers``.
        self.weapon: str | None = None
        # A two-stance monster (D-591, D-601): its pools, which one it is
        # in, why it leaves each, its turns in this one, and the physical
        # blows taken since its last turn.
        self.pools = list(pools or [])
        self.pool = 0
        self.switch = list(switch or [])
        self.in_stance = 0
        self.struck = 0
        # Looked at through a Seer's Shell this fight (Frankie, 10/28): its
        # element and HP stay up on screen. A new fight builds new monsters.
        self.seen = False
        # From the monster's entry in the shared file (Frankie, 10/28): its
        # ``skill``, one signature move as a party member has (the Great
        # Boar's Squeal calls its kind to its side); ``angry`` (what changes
        # below a share of its HP) and whether it is angry yet; the move it
        # is winding up, played on its next turn; the move it changed stance
        # to use, played on its next turn; and, for a monster called in, who
        # called it and its picture.
        self.skill: dict[str, Any] | None = None
        self.angry_rule: dict[str, Any] | None = None
        self.angry = False
        self.winding: dict[str, Any] | None = None
        self.wanting: dict[str, Any] | None = None
        self.caller: str | None = None
        self.picture: str | None = None

    @property
    def alive(self) -> bool:
        """Return True while HP is above zero."""
        return self.hp > 0

    @property
    def stance_element(self) -> Element | None:
        """Return the element of the stance this combatant is in, or None."""
        if not self.stances:
            return None
        return Element(self.stances[self.stance]["element"])

    def take_stance(self, index: int) -> None:
        """Move into stance ``index``: new stats, the same share of HP. Boosts and drops stay on."""
        self.stance = index
        self.points = stat_points(self.elements, self.stance_element, self.growth, self.multipliers)
        hp_boost = self.boosts.get("hp", 0)
        self.max_hp -= hp_boost
        self._fit_hp_to_stance()
        for key, added in self.boosts.items():
            if key == "hp":
                self.max_hp += added
            else:
                self.points[key] += added
        for key, taken in self.drops.items():
            self.points[key] -= taken

    def _fit_hp_to_stance(self) -> None:
        """Set max HP from the stance's stats, keeping the share of HP (D-365).

        Rounded, never below 1 while standing: a switch never kills or heals.
        """
        new_max = max_hp_for(self.points)
        if new_max == self.max_hp:
            return
        if self.hp > 0:
            # Extra HP from a meal keeps its share too (Kailo's Cook, 10/25).
            top = new_max if self.hp <= self.max_hp else round(self.hp * new_max / self.max_hp)
            self.hp = min(top, max(1, round(self.hp * new_max / self.max_hp)))
        self.max_hp = new_max

    @property
    def element(self) -> Element | None:
        """Return the element that decides weakness, or None.

        A monster has its one element. A party member has the element
        of the stance they are in (D-590).
        """
        return self.stance_element if self.is_party else self.elements[0]


class Battle:
    """A turn-based encounter that emits events as it resolves."""

    def __init__(
        self,
        party_combatants: list[Combatant],
        enemy_combatants: list[Combatant],
        moves: dict[str, dict[str, Any]] | None = None,
        noni: int | None = None,
        rng: random.Random | None = None,
        bench: list[Combatant] | None = None,
        combos: dict[str, dict[str, Any]] | None = None,
        opening: str | None = None,
    ) -> None:
        """Construct a battle from two rosters.

        Args:
            party_combatants: The player's side, the three who fight.
            enemy_combatants: The monsters.
            moves: The moves from the shared battle file, keyed by id.
            noni: Shared Noni count; defaults to the new-game stack.
            rng: Random source. Pass a seeded one for a repeatable fight.
            bench: Party members waiting to be swapped in (D-196).
            combos: The combos from the shared battle file, keyed by id.
                Only those in ``COMBOS_BUILT`` are ever offered.
            opening: "preemptive" when the party caught the monsters from
                behind or the side, "ambush" when the monsters caught them;
                the caught side starts with full fatigue (Frankie, 10/27).
        """
        self.party = party_combatants
        self.enemies = enemy_combatants
        self.bench = list(bench or [])
        self._combos = {
            cid: combo for cid, combo in (combos or {}).items() if cid in COMBOS_BUILT
        }
        self._moves = dict(moves or {})
        self.noni = (
            BattleSettings.STARTING_NONI if noni is None else noni
        )
        self._rng = rng or random.Random()
        # Growth by use (D-507), copied so a test can change the numbers.
        self.growth = dict(_GROWTH)
        # Everyone starts at a random point inside the first tick, so
        # the opening order is not always the same.
        for combatant in self.party + self.enemies:
            combatant.counter = self._rng.random()
        caught = {"preemptive": self.enemies, "ambush": self.party}.get(opening or "", [])
        for combatant in caught:
            combatant.counter += BattleSettings.FATIGUE_TECH * defense_scale(combatant.points["speed"])
        self._ended = False
        self._outcome: str | None = None
        # Monsters whose last turn went to sulking: they shrug off the next Scold (Frankie, 10/24).
        self._sulked: set[str] = set()
        # Monsters called this fight by a Squeal, to letter the next one (Frankie, 10/28).
        self._calls = 0
        # The row of the move being used, for a fire move's chance to burn
        # (D-561); None for Attack and everything else, which roll at row 1.
        self._tier: int | None = None
        self._current_actor: Combatant | None = None
        self._awaiting_command = False
        # The Attack being chained this turn: the enemy it is aimed at,
        # the stroke points used, and how many strokes landed.
        self._chain: dict[str, Any] | None = None
        # Items given to the party mid-fight (a scolded Aghoy's present),
        # for the scene to put in the bag.
        self.gifts: list[str] = []

    # ------------------------------------------------------------------
    # PUBLIC
    # ------------------------------------------------------------------

    @property
    def is_over(self) -> bool:
        """Return True once the battle has an outcome."""
        return self._ended

    @property
    def outcome(self) -> str | None:
        """Return "victory", "defeat", "flee", or None while running."""
        return self._outcome

    @property
    def current_actor(self) -> Combatant | None:
        """Return the combatant whose turn it is."""
        return self._current_actor

    def is_awaiting_command(self) -> bool:
        """Return True while a party member's turn waits on the player."""
        return self._awaiting_command

    def moves_for(self, combatant: Combatant, stance: int | None = None) -> list[dict[str, Any]]:
        """Return the moves ``combatant`` can pick, shared ones first.

        Moves come back in the order the shared file lists them, which
        is the menu order in both games. A move with an ``owner``
        belongs to that one character (their special, or their own
        version of a shared move). Any other move belongs to everyone
        carrying its element, unless they are named in its ``except``
        list. A move marked ``off`` is not built yet and is left out, and
        so is one marked ``browser_only``, which only the browser game
        has code for so far. A party member in a stance gets only the
        moves that work in it (``icons_of``, D-362); ``stance`` asks about
        another of theirs instead, for the switch's preview.
        """
        element_ids = [element.value for element in combatant.elements]
        available: list[dict[str, Any]] = []
        for move in self._moves.values():
            if not knows(move, combatant.id, element_ids):
                continue
            # A signature move (Skill) takes no slot and works in either stance.
            if move.get("signature"):
                available.append(move)
                continue
            if combatant.loadout is not None and move["id"] not in combatant.loadout:
                continue
            if self.works_in_stance(combatant, move, stance):
                available.append(move)
        return available

    def move(self, move_id: str) -> dict[str, Any]:
        """Return the shared file's move ``move_id``."""
        return self._moves[move_id]

    @staticmethod
    def row_of(combatant: Combatant, move: dict[str, Any]) -> int:
        """Return the mana row ``move`` sits in for ``combatant``: its slot, or its own row."""
        if combatant.loadout is not None and move["id"] in combatant.loadout:
            return combatant.loadout[move["id"]]
        return home_row(move)

    @staticmethod
    def icons_of(combatant: Combatant, move: dict[str, Any]) -> list[Element]:
        """Return the element icons ``move`` shows for ``combatant`` (D-361, D-362).

        A move that lists ``elements`` shows those; an element move its
        own element; a special both of its user's, its own element first.
        """
        if move.get("elements"):
            return [Element(e) for e in move["elements"]]
        own = Element(move["element"])
        if move.get("tier") in (None, "element") or not combatant.is_party:
            return [own]
        if own in combatant.elements:
            return [own] + [e for e in combatant.elements if e is not own]
        return list(combatant.elements)

    def works_in_stance(self, combatant: Combatant, move: dict[str, Any], index: int | None = None) -> bool:
        """Return True when ``move`` works in the stance ``combatant`` is in, or in stance ``index``.

        It works in the stance of each icon it shows; a move whose icons
        are all elements the character lacks works in both.
        """
        stance = combatant.stance_element
        if index is not None and combatant.stances:
            stance = Element(combatant.stances[index]["element"])
        if stance is None:
            return True
        icons = self.icons_of(combatant, move)
        return stance in icons or not any(e in combatant.elements for e in icons)

    def other_stance(self, combatant: Combatant) -> dict[str, Any] | None:
        """Return the stance ``combatant`` could switch to, or None."""
        if len(combatant.stances) < 2:
            return None
        return combatant.stances[1 - combatant.stance]

    def cost_of(self, combatant: Combatant, move: dict[str, Any]) -> int:
        """Return the mana ``move`` costs ``combatant``: the row it sits in.

        A signature move (Skill) costs nothing (Frankie, 10/21).
        """
        return 0 if move.get("signature") else self.row_of(combatant, move)

    def can_afford(self, combatant: Combatant, move: dict[str, Any]) -> bool:
        """Return True when ``combatant`` has the mana for ``move``."""
        return combatant.mana >= self.cost_of(combatant, move)

    @property
    def chain_points_left(self) -> int:
        """Return the stroke points left in this turn's Attack."""
        used = self._chain["points"] if self._chain else 0
        return BattleSettings.STROKE_POINTS - used

    @property
    def chaining(self) -> bool:
        """Return True once a stroke has been swung this turn."""
        return self._chain is not None

    def chain_target(self) -> Combatant | None:
        """Return the living enemy this turn's strokes are aimed at, or None."""
        if self._chain is None:
            return None
        for combatant in self.enemies:
            if combatant.id == self._chain["target"] and combatant.alive:
                return combatant
        return None

    def stroke_chance(self, kind: str, target: Combatant) -> float:
        """Return the current actor's chance, 0 to 1, that a ``kind`` stroke lands on ``target``.

        The same sum ``_physical`` rolls against: the stroke's own aim,
        steadied by each stroke landed this turn, plus Accuracy, minus
        the Evasion of whoever takes the blow (a sentinel stepping in
        dodges with its own); a blind striker misses half outright.
        """
        actor = self._current_actor
        landed = self._chain["landed"] if self._chain else 0
        struck = self._guard_for(target) or target
        chance = max(0.0, min(1.0, self._land_chance(
            actor, struck, BattleSettings.STROKES[kind]["hit"] + BattleSettings.STROKE_STEADY * landed)))
        if "blind" in actor.statuses:
            chance *= 1 - BattleSettings.BLIND_MISS_CHANCE
        return chance

    def preview_wait(self, kind: str) -> float:
        """Return the wait the current actor would pay for ``kind`` now.

        ``kind`` is "attack" (end the chain), "defend", "tech", or
        anything else for a technique or an item. Speed and haste are applied when the
        wait is spent, as for everyone.
        """
        return self._fatigue(kind)

    def upcoming(
        self, count: int, pending_wait: float | None = None
    ) -> list[Combatant]:
        """Predict who acts over the next ``count`` turns.

        The current actor is not included. While a party member's turn
        is waiting, ``pending_wait`` is the wait to assume they pay, so a
        menu can preview its effect on the order. Everyone after that is
        assumed to wait ``BattleSettings.PREVIEW_WAIT``: fatigue depends
        on what they choose, so the order further out is a guess.

        Args:
            count: How many future turns to return.
            pending_wait: The current actor's wait, from ``preview_wait``.

        Returns:
            Combatants in the order they would act. One combatant can
            appear more than once.
        """
        living = [c for c in self.party + self.enemies if c.alive]
        counters = {c.id: c.counter for c in living}
        hastes = {c.id: c.haste for c in living}

        def spend(combatant: Combatant, base_wait: float) -> None:
            wait = base_wait
            if hastes[combatant.id] > 0:
                wait *= BattleSettings.HASTE_WAIT_MULTIPLIER
                hastes[combatant.id] -= 1
            if combatant.angry and combatant.angry_rule:
                wait *= combatant.angry_rule.get("wait", 1)
            counters[combatant.id] += wait * defense_scale(
                combatant.points["speed"]
            )

        actor = self._current_actor
        if self._awaiting_command and actor is not None and actor.alive:
            spend(actor, pending_wait or BattleSettings.PREVIEW_WAIT)
        order: list[Combatant] = []
        while living and len(order) < count:
            nxt = min(living, key=lambda c: counters[c.id])
            order.append(nxt)
            spend(nxt, BattleSettings.PREVIEW_WAIT)
        return order

    def start_turn(self) -> list[Any]:
        """Advance to the next combatant's turn.

        Runs poison and sleep for whoever is up. A monster's turn is
        resolved here; a party member's turn parks the battle until a
        ``submit_*`` call. A turn lost to sleep or ended by poison
        returns with nothing awaiting, so the scene simply calls
        ``start_turn`` again.
        """
        if self._ended or self._awaiting_command:
            return []
        living = [c for c in self.party + self.enemies if c.alive]
        actor = min(living, key=lambda c: c.counter)
        self._current_actor = actor
        self._tier = None
        events: list[Any] = [TurnStartEvent(actor.id, actor.name)]
        if actor.guard == "cooker":
            events.extend(self._let_out(actor))
        elif actor.guard == "boil":
            events.extend(self._boil_over(actor))
        ended = self._check_terminal()
        if ended:
            return events + ended
        # A guard slotted above its row holds for more turns (D-325).
        if actor.guard is not None and actor.guard_left > 0:
            actor.guard_left -= 1
        else:
            actor.guard = None
        actor.defending = False
        actor.ready = False
        self._chain = None
        events.extend(self._turn_ticks(actor))
        if not actor.alive:
            events.extend(self._check_terminal())
            return events
        ended = self._check_terminal()
        if ended:
            return events + ended
        # The hands of the dead hold the gripped one still (Grave Grip).
        if actor.statuses.get("grip"):
            actor.statuses["grip"] -= 1
            if actor.statuses["grip"] <= 0:
                del actor.statuses["grip"]
            events.append(NoteEvent(f"The dead hold {actor.name} still.", actor.id))
            events.extend(self._spend(actor, BattleSettings.FATIGUE_OTHER, still=True))
            events.extend(self._check_terminal())
            return events
        # Scold: a sulking enemy loses SULK_TURNS turns, then stops sulking, and a hit
        # does not snap it out (Frankie, 10/25; it was one turn).
        if actor.statuses.get("sulk"):
            actor.statuses["sulk"] -= 1
            events.append(NoteEvent(f"{actor.name} is still sulking.", actor.id))
            if actor.statuses["sulk"] <= 0:
                del actor.statuses["sulk"]
                self._sulked.add(actor.id)
                events.append(NoteEvent(f"{actor.name} stops sulking.", actor.id))
            events.extend(self._spend(actor, BattleSettings.FATIGUE_OTHER, still=True))
            events.extend(self._check_terminal())
            return events
        self._sulked.discard(actor.id)
        if "sleep" in actor.statuses:
            actor.statuses["sleep"] -= 1
            if actor.statuses["sleep"] <= 0:
                del actor.statuses["sleep"]
            events.append(TurnSkippedEvent(actor.id, actor.name, "sleep"))
            events.extend(self._spend(actor, BattleSettings.FATIGUE_OTHER, still=True))
            events.extend(self._check_terminal())
            return events
        if actor.summon_turns:
            events.extend(self._summon_turn(actor))
            events.extend(self._check_terminal())
            return events
        if actor.is_party:
            # What Kailo cooked last turn is served first (Frankie, 10/25).
            if actor.dish:
                events.extend(self._serve(actor))
            self._awaiting_command = True
            return events
        events.extend(self._monster_turn(actor))
        events.extend(self._check_terminal())
        return events

    def submit_stroke(self, kind: str, target_id: str) -> list[Any]:
        """Swing one stroke of the Attack at ``target_id``.

        The turn goes on until the player ends the chain, picks a
        technique or Defend, or spends the last of the 7 points; the
        last stroke ends it by itself.

        Args:
            kind: "light", "medium" or "strong".
            target_id: The enemy struck. The first stroke picks it;
                later strokes keep it while it stands.
        """
        actor = self._require_player_actor()
        stroke = BattleSettings.STROKES[kind]
        if stroke["points"] > self.chain_points_left:
            raise ValueError(f"not enough points left for a {kind} stroke")
        if self._chain is None:
            self._chain = {"target": target_id, "points": 0, "landed": 0}
        self._chain["target"] = target_id
        target = self._find(self.enemies, target_id)
        events = self._stroke(actor, target, kind, self._chain)
        terminal = self._check_terminal()
        if terminal:
            self._awaiting_command = False
            return events + terminal
        lightest = BattleSettings.STROKES["light"]["points"]
        if self.chain_points_left < lightest or not actor.alive:
            return self._finish_player_turn(events, "attack")
        return events

    def submit_end_chain(self) -> list[Any]:
        """End the turn after one or more strokes."""
        self._require_player_actor()
        return self._finish_player_turn([], "attack")

    def submit_attack(self, target_id: str) -> list[Any]:
        """Attack with the whole chain at once: light, medium, strong.

        The chain monsters use, for tests and anything that plays the
        party's turn by itself.
        """
        actor = self._require_player_actor()
        self._chain = {"target": target_id, "points": 0, "landed": 0}
        target = self._find(self.enemies, target_id)
        events = self._auto_strokes(actor, target, self._chain)
        return self._finish_player_turn(events, "attack")

    def submit_defend(self) -> list[Any]:
        """Resolve Defend: halve physical damage until the next turn, build 1 mana."""
        actor = self._require_player_actor()
        actor.defending = True
        actor.ready = True
        events: list[Any] = [DefendEvent(actor.id, actor.name)]
        events.extend(self._gain(actor, BattleSettings.DEFEND_MANA))
        return self._finish_player_turn(events, "defend")

    def submit_stance(self) -> list[Any]:
        """Switch to the other stance: builds 1 mana and ends the turn (D-285)."""
        actor = self._require_player_actor()
        other = self.other_stance(actor)
        if other is None:
            raise ValueError(f"{actor.id} has no other stance")
        actor.take_stance(actor.stances.index(other))
        events: list[Any] = [StanceEvent(
            actor.id, actor.name, other["name"], Element(other["element"])
        )]
        events.extend(self._gain(actor, BattleSettings.STANCE_MANA))
        return self._finish_player_turn(events, "move")

    def submit_move(
        self, move_id: str, target_id: str | None = None, give_to_id: str | None = None,
    ) -> list[Any]:
        """Resolve a technique, paying its mana.

        Args:
            move_id: An id from the shared file's move list.
            target_id: The chosen combatant, or None for a move whose
                ``target`` is "none". A "fallen" move names a downed ally.
            give_to_id: For a move with ``give_to`` (Drain, Osmose,
                Borrowed Life), who gets what it takes from the enemy:
                an ally, or a fallen one. None gives it to the one acting.
        """
        actor = self._require_player_actor()
        move = self._moves[move_id]
        if not self.can_afford(actor, move):
            raise ValueError(f"{actor.id} cannot pay for {move_id}")
        if not self.works_in_stance(actor, move):
            raise ValueError(f"{move_id} does not work in {actor.id}'s stance")
        pool = self.enemies if move["target"] == "foe" else self.party
        target = self._find(pool, target_id) if target_id else actor
        if move["target"] == "fallen" and target.alive:
            raise ValueError(f"{target.id} is still standing")
        events: list[Any] = [
            AbilityUsedEvent(
                actor.id, actor.name, move_id, move["name"],
                target.name if target is not actor else None,
            )
        ]
        row = self.row_of(actor, move)
        events.extend(self._pay(actor, self.cost_of(actor, move)))
        # A fire move slotted higher burns more often (D-561).
        self._tier = row
        other = self._find(self.party, give_to_id) if give_to_id else None
        effect = self._run_effect(actor, target, grown(move, row), other)
        events.extend(effect)
        # A technique's own damage grows by its kind (D-527): a physical
        # hit Strength, magic damage or healing Intelligence, more points
        # the higher its mana row (D-528, Frankie, 10/27).
        hurt = [e for e in effect if isinstance(e, DamageEvent) and e.amount > 0]
        hit = [e.target_id for e in hurt if e.cause == "hit"]
        spell = [e.target_id for e in hurt if e.cause == "spell"]
        if hit:
            events.extend(self._fill(actor, "strength", self.growth["technique_per_row"] * max(1, row)
                                     * self._teaches(actor, "strength", hit)))
        if spell or any(
            isinstance(e, HealEvent) and e.amount > 0 or isinstance(e, RevivedEvent)
            for e in effect
        ):
            events.extend(self._fill(actor, "magic", self.growth["spell_per_row"] * max(1, row)
                                     * self._teaches(actor, "magic", spell)))
        if move.get("signature"):
            return self._finish_tech(events)
        return self._finish_player_turn(events, "move")

    def submit_noni(self, target_id: str) -> list[Any]:
        """Resolve putting on, or handing over, a Noni."""
        actor = self._require_player_actor()
        if self.noni <= 0:
            return []
        self.noni -= 1
        target = self._find(self.party, target_id)
        events: list[Any] = [
            NoniUsedEvent(
                actor.id, actor.name, target.id, target.name, self.noni
            )
        ]
        events.extend(self._heal(target, BattleSettings.NONI_HEAL_AMOUNT))
        return self._finish_player_turn(events, "item")

    def submit_bag_heal(self, item_name: str, amount: int, target_id: str) -> list[Any]:
        """Give an ally something from the bag that heals, a dish from Kailo's pot.

        The bag is the party's, so the scene spends the item (Frankie, 10/22).
        """
        actor = self._require_player_actor()
        target = self._find(self.party, target_id)
        events: list[Any] = [NoteEvent(f"{actor.name} gives {target.name} the {item_name}.", target.id)]
        events.extend(self._heal(target, amount))
        return self._finish_player_turn(events, "item")

    def submit_bag_cure(self, item_name: str, statuses: tuple[str, ...], target_id: str) -> list[Any]:
        """Give an ally a plant from the bag that cures (Frankie, 10/23): those ailments are gone.

        The bag is the party's, so the scene spends the item, as for a heal.
        """
        actor = self._require_player_actor()
        target = self._find(self.party, target_id)
        events: list[Any] = [NoteEvent(f"{actor.name} gives {target.name} the {item_name}.", target.id)]
        cured = [status for status in statuses if target.statuses.pop(status, None) is not None]
        events += [StatusAppliedEvent(target.id, target.name, status, False) for status in cured]
        if not cured:
            events.append(NoteEvent("Nothing happens.", target.id))
        return self._finish_player_turn(events, "item")

    def submit_cook(self) -> list[Any]:
        """Kailo's Cook, his Skill (Frankie, 10/25): he spends the turn cooking for the party.

        What he makes is set now: a cure if anyone standing has a status
        food can fix (``COOK_CURES``), else a meal. It is served at the start
        of his next turn (``_serve``), and a hit before then ruins it
        (``_deal``). A Skill costs no mana, builds 1 and waits 7.
        """
        actor = self._require_player_actor()
        standing = [c for c in self.party if c.alive]
        cure = any(s in c.statuses for c in standing for s in BattleSettings.COOK_CURES)
        actor.dish = "cure" if cure else "heal"
        name = BattleSettings.COOK_DISHES[actor.dish]
        events: list[Any] = [NoteEvent(f"{actor.name} starts cooking {name}.", actor.id)]
        return self._finish_tech(events)

    def _serve(self, actor: Combatant) -> list[Any]:
        """At the start of Kailo's turn, what he cooked goes to the party, and he acts as usual.

        The meal gives everyone a share of their max HP, and what goes past
        full stays as extra HP, up to that share over, for the rest of the
        fight (Frankie, 10/25). A heal that takes is a try at Intelligence,
        as a technique's is (D-527).
        """
        kind, actor.dish = actor.dish, None
        events: list[Any] = [NoteEvent(f"{actor.name} serves {BattleSettings.COOK_DISHES[kind]}.", actor.id)]
        standing = [c for c in self.party if c.alive]
        if kind == "cure":
            for c in standing:
                for status in BattleSettings.COOK_CURES:
                    if c.statuses.pop(status, None) is not None:
                        events.append(StatusAppliedEvent(c.id, c.name, status, False))
            return events
        healed = False
        for c in standing:
            if "burn" in c.statuses:
                events.append(NoteEvent(f"{c.name} is burning and cannot be healed.", c.id))
                continue
            share = max(1, round(c.max_hp * BattleSettings.COOK_HEAL))
            before = c.hp
            c.hp = min(c.max_hp + share, c.hp + share)
            events.append(HealEvent(c.id, c.name, c.hp - before))
            healed = healed or c.hp > before
            if c.hp > c.max_hp:
                events.append(NoteEvent(f"{c.name} is full: {c.hp - c.max_hp} extra HP.", c.id))
        if healed:
            events += self._fill(actor, "magic", self.growth["spell_per_row"] * self._teaches(actor, "magic", []))
        return events

    def will_chance(self, actor: Combatant, target: Combatant) -> float:
        """How likely Scold or Charm takes hold: the user's Willpower over theirs and the monster's together, kept in bounds."""
        mine, theirs = actor.points["spirit"], target.points["spirit"]
        share = mine / max(1, mine + theirs)
        return min(BattleSettings.WILL_MOST, max(BattleSettings.WILL_LEAST, share))

    def submit_charm(self, target_id: str) -> list[Any]:
        """Maika's Charm, his Skill (Frankie, 10/25): the charmed status, if it takes hold.

        For CHARM_TURNS of its turns the monster fights for the party
        (``_charmed_turn``). Whether it takes hold is a Willpower contest
        (``will_chance``). A Skill costs no mana, builds 1 and waits 7.
        """
        actor = self._require_player_actor()
        target = self._find(self.enemies, target_id)
        events: list[Any] = [NoteEvent(f"{actor.name} turns on the charm at {target.name}.", target.id)]
        # Bosses cannot be charmed (Frankie, 10/25).
        if target.boss:
            events.append(NoteEvent(f"{target.name} cannot be charmed.", target.id))
        elif "charmed" in target.immune or self._rng.random() >= self.will_chance(actor, target):
            events.append(StatusResistedEvent(target.id, target.name, "charmed", "charmed" in target.immune))
        else:
            target.statuses["charmed"] = BattleSettings.CHARM_TURNS
            events.append(StatusAppliedEvent(target.id, target.name, "charmed", True))
        return self._finish_tech(events)

    def submit_scold(self, target_id: str) -> list[Any]:
        """Hina's Scold, her Skill (Frankie, 10/25): the monster sulks, if it takes hold.

        For now it only sets the monster sulking for SULK_TURNS of its turns
        (a rework comes later), taking hold by Willpower (``will_chance``).
        A monster sulking, or that just stopped, shrugs it off, so none can be
        kept sulking (Frankie, 10/24). A Skill costs no mana, builds 1 and waits 7.
        """
        actor = self._require_player_actor()
        target = self._find(self.enemies, target_id)
        events: list[Any] = [NoteEvent(f"{actor.name} scolds {target.name}.", target.id)]
        # Bosses do not listen (Frankie, 10/25).
        if target.boss:
            events.append(NoteEvent(f"{target.name} does not listen.", target.id))
        elif target.id in self._sulked or target.statuses.get("sulk"):
            events.append(NoteEvent(f"{target.name} shrugs it off.", target.id))
        elif self._rng.random() >= self.will_chance(actor, target):
            events.append(NoteEvent(f"{target.name} ignores her.", target.id))
        else:
            target.statuses["sulk"] = BattleSettings.SULK_TURNS
            events.append(StatusAppliedEvent(target.id, target.name, "sulk", True))
        return self._finish_tech(events)

    def submit_seer_shell(self, target_id: str) -> list[Any]:
        """Look at an enemy through a Seer's Shell: its element, HP and mana, as Scan reads them.

        The shell is the bag's, so the scene spends it (Frankie, 10/22). What
        it shows stays up for the rest of the fight (Frankie, 10/28).
        """
        actor = self._require_player_actor()
        target = self._find(self.enemies, target_id)
        target.seen = True
        element = target.elements[0].label
        events: list[Any] = [
            NoteEvent(f"{actor.name} looks through the Seer's Shell.", target.id),
            NoteEvent(f"{target.name}: {element}.", target.id),
            NoteEvent(f"HP {target.hp}/{target.max_hp}, mana {target.mana}.", target.id),
        ]
        return self._finish_player_turn(events, "item")

    def combos_for(self, actor: Combatant) -> list[tuple[dict[str, Any], Combatant]]:
        """Return the combos ``actor`` could start now, each with its partner.

        The partner is the ally whose turn comes right after (D-180), or
        anyone who Defended and stands ready (D-182). Each brings the
        element of the stance they are in (D-259). Mana is not checked
        here; ``can_pay_combo`` says whether both have it.
        """
        partners: list[Combatant] = [c for c in self.party if c.ready and c is not actor]
        upcoming = self.upcoming(1, self._fatigue("move"))
        if upcoming and upcoming[0].is_party and upcoming[0] not in partners:
            partners.insert(0, upcoming[0])
        found: list[tuple[dict[str, Any], Combatant]] = []
        for partner in partners:
            if partner is actor or not partner.alive or "sleep" in partner.statuses:
                continue
            for combo in self._combos.values():
                if self._combo_roles(combo, actor, partner) is not None:
                    found.append((combo, partner))
        return found

    def can_pay_combo(self, actor: Combatant, partner: Combatant) -> bool:
        """Return True when both partners have the mana a combo takes."""
        need = BattleSettings.COMBO_MANA
        return actor.mana >= need and partner.mana >= need

    @staticmethod
    def _combo_roles(
        combo: dict[str, Any], actor: Combatant, partner: Combatant
    ) -> dict[str, Combatant] | None:
        """Return who brings each of ``combo``'s elements, or None if they cannot."""
        x, y = combo["elements"]
        mine = actor.stance_element.value if actor.stance_element else None
        theirs = partner.stance_element.value if partner.stance_element else None
        if (mine, theirs) == (x, y):
            return {x: actor, y: partner}
        if (mine, theirs) == (y, x):
            return {y: actor, x: partner}
        return None

    def submit_combo(
        self, combo_id: str, partner_id: str, target_id: str | None = None
    ) -> list[Any]:
        """Strike together with a partner. Both pay the mana; it uses up the partner's coming turn."""
        actor = self._require_player_actor()
        combo = self._combos[combo_id]
        partner = self._find(self.party, partner_id)
        roles = self._combo_roles(combo, actor, partner)
        if roles is None:
            raise ValueError(f"{actor.id} and {partner_id} cannot do {combo_id}")
        if not self.can_pay_combo(actor, partner):
            raise ValueError(f"{combo_id} needs more mana")
        events: list[Any] = [ComboUsedEvent(
            actor.id, actor.name, partner.id, partner.name, combo["name"]
        )]
        events.extend(self._pay(actor, BattleSettings.COMBO_MANA))
        events.extend(self._pay(partner, BattleSettings.COMBO_MANA))
        target = self._find(self.enemies, target_id) if target_id else None
        events.extend(self._run_combo(combo, roles, target))
        partner.ready = False
        events.extend(self._spend(partner, BattleSettings.FATIGUE_OTHER))
        return self._finish_player_turn(events, "move")

    def _run_combo(
        self,
        combo: dict[str, Any],
        roles: dict[str, Combatant],
        target: Combatant | None,
    ) -> list[Any]:
        """Play one combo's effect, as the browser does."""
        power = combo["power"]
        cid = combo["id"]
        events: list[Any] = []
        if cid == "solar_fist":
            return self._physical(roles["afi"], target, power, Element.LA)
        if cid == "vine_whip":
            return self._physical(roles["afi"], target, power, Element.LAU)
        if cid == "eclipse":
            for foe in [c for c in self.enemies if c.alive]:
                events.extend(self._magic(roles["la"], foe, power, Element.LA))
                if foe.alive:
                    events.extend(self._magic(roles["ata"], foe, power, Element.ATA))
                if foe.alive:
                    events.extend(self._inflict(foe, "blind"))
            return events
        if cid == "daybreak":
            for foe in [c for c in self.enemies if c.alive]:
                foe.haste = 0
                foe.ward = 0.0
                events.extend(self._magic(roles["mana"], foe, power, Element.LA))
            return events
        raise ValueError(f"combo {cid} is not built")

    def submit_swap(self, bench_id: str) -> list[Any]:
        """Send the one acting to the bench and bring ``bench_id`` in, as the browser does.

        The one coming in takes the same place and clock, and the turn
        is theirs at once.
        """
        actor = self._require_player_actor()
        newcomer = self._find(self.bench, bench_id)
        if not newcomer.alive:
            raise ValueError(f"{bench_id} cannot fight")
        newcomer.counter = actor.counter
        newcomer.guard = None
        newcomer.defending = False
        newcomer.ready = False
        self.party[self.party.index(actor)] = newcomer
        self.bench.remove(newcomer)
        self.bench.append(actor)
        actor.guard = None
        actor.defending = False
        actor.ready = False
        self._chain = None
        self._current_actor = newcomer
        return [SwapEvent(actor.id, actor.name, newcomer.id, newcomer.name)]

    def submit_weapon(self, weapon_name: str, multipliers: dict[str, Fraction] | None = None) -> list[Any]:
        """Change the weapon held: builds 1 mana, 1 fatigue less, ends the turn (D-455).

        ``multipliers`` is what the new weapon does to the stats (core/equipment.py):
        they change at once, the share of HP kept. None leaves the stats alone.
        """
        actor = self._require_player_actor()
        actor.weapon = weapon_name
        if multipliers is not None:
            actor.multipliers = dict(multipliers)
            actor.take_stance(actor.stance)
        events: list[Any] = [WeaponEvent(actor.id, actor.name, weapon_name)]
        events.extend(self._gain(actor, BattleSettings.WEAPON_MANA))
        return self._finish_player_turn(events, "defend")

    def escape_chance(self) -> float:
        """Return the one acting's chance, 0 to 1, of running away."""
        actor = self._current_actor
        fastest = max(
            (c.points["speed"] for c in self.enemies if c.alive), default=0
        )
        low, high = BattleSettings.ESCAPE_LIMITS
        chance = BattleSettings.ESCAPE_CHANCE + BattleSettings.ESCAPE_PER_SPEED * (
            actor.points["speed"] - fastest
        )
        return max(low, min(high, chance))

    def submit_escape(self) -> list[Any]:
        """Try to run (D-455). A failure builds no mana, costs 1 fatigue less and ends the turn."""
        actor = self._require_player_actor()
        escaped = self._rng.random() < self.escape_chance()
        events: list[Any] = [EscapeEvent(actor.id, actor.name, escaped)]
        if escaped:
            self._awaiting_command = False
            return events + self._end("flee")
        return self._finish_player_turn(events, "defend")

    def flee(self) -> list[Any]:
        """End the battle by running away."""
        self._awaiting_command = False
        return self._end("flee")

    # ------------------------------------------------------------------
    # MOVE EFFECTS
    # ------------------------------------------------------------------

    def _run_effect(
        self, actor: Combatant, target: Combatant, move: dict[str, Any],
        other: Combatant | None = None,
    ) -> list[Any]:
        """Run one party move and return its events.

        A kit move (``systems/battle_kits.py``) runs its own code; any
        other runs by its ``effect``.
        """
        ran = battle_kits.run(self, actor, target, move, other)
        if ran is not None:
            return ran
        effect = move["effect"]
        element = Element(move["element"])
        statuses = move.get("statuses", [])
        if effect == "physical":
            return self._physical(
                actor, target, move["power"], element, statuses
            )
        if effect == "magic":
            return self._magic(
                actor, target, move["power"], element, statuses,
                extra_turns=move.get("extra_turns", 0),
            )
        if effect == "guard":
            actor.guard = move["guard"]
            actor.guard_left = move.get("extra_turns", 0)
            actor.guard_m = move.get("guard_multiplier")
            actor.guard_kick = move.get("kick")
            if move["guard"] == "cooker":
                actor.cooker_target = target.id
                actor.cooker_took = 0
            return [GuardRaisedEvent(actor.id, actor.name, move["guard"])]
        if effect == "cure":
            amount = round(
                move["power"] * offense_scale(actor.points["magic"])
            )
            return self._heal(target, amount)
        if effect == "cleanse":
            for status in move.get("statuses", _CLEANSABLE):
                target.statuses.pop(status, None)
            return [CleansedEvent(target.id, target.name)]
        if effect == "ward":
            target.ward = move.get("ward_share", LoadoutSettings.WARD_SHARE)
            return [StatusAppliedEvent(target.id, target.name, "ward", True)]
        if effect == "haste":
            target.haste = BattleSettings.HASTE_ACTIONS + move.get("extra_turns", 0)
            return [StatusAppliedEvent(target.id, target.name, "haste", True)]
        if effect == "safeguard":
            target.safe = True
            return [StatusAppliedEvent(target.id, target.name, "safeguard", True)]
        if effect == "regen":
            target.regen = BattleSettings.REGEN_TURNS + move.get("extra_turns", 0)
            return [StatusAppliedEvent(target.id, target.name, "regen", True)]
        if effect == "mana_gift":
            return self._gain(target, int(move.get("gift", 1)))
        if effect == "purify":
            target.statuses.clear()
            events = self._heal(target, target.max_hp)
            target.ward = LoadoutSettings.WARD_SHARE
            events.append(
                StatusAppliedEvent(target.id, target.name, "ward", True)
            )
            return events
        if effect == "revive":
            return self._revive(actor, target, move.get("revive_share", 0.5))
        if effect == "drain":
            # Half the damage comes back to the caster. The browser can
            # give it to an ally instead; that waits.
            before = target.hp
            events = self._magic(actor, target, move["power"], element, statuses)
            dealt = before - target.hp
            if dealt > 0:
                events.extend(self._heal(actor, round(dealt / 2)))
            return events
        raise ValueError(f"move {move['id']} has unknown effect {effect!r}")

    def _revive(self, actor: Combatant, target: Combatant, share: float) -> list[Any]:
        """Bring a fallen ally back with ``share`` of their max HP (D-456).

        Revive brings half, Full Revive all of it.

        As in the browser, they rejoin the order as if they had just used
        a technique: the reviver's counter plus one technique's wait,
        shortened by their own Speed.
        """
        target.hp = max(1, round(target.max_hp * share))
        target.statuses.clear()
        target.counter = actor.counter + BattleSettings.FATIGUE_OTHER * defense_scale(
            target.points["speed"]
        )
        return [RevivedEvent(target.id, target.name, target.hp)]

    def _monster_turn(self, monster: Combatant) -> list[Any]:
        """Pick one of ``monster``'s moves by weight and play it.

        Every named move costs its ``tier`` in mana (D-329). A monster
        that cannot pay yet attacks with a chain of strokes instead,
        which builds the mana, so a big move comes once it is paid for.
        """
        if monster.statuses.get("charmed"):
            return self._charmed_turn(monster, *self._pick_move(monster))
        return self._foe_turn(monster, *self._pick_move(monster, own=True))

    def _pick_move(self, monster: Combatant, own: bool = False) -> tuple[dict, int]:
        """One of a monster's moves by weight, and its cost in mana (D-329).

        On its own side (``own``) it may also pick its Skill, which costs
        no mana, and an ordinary two-stance monster the moves of its other
        stance too, which it changes stance to use (Frankie, 10/28).
        Squeal is never picked: it comes when the Great Boar is short of help.
        """
        moves = list(monster.moves)
        if own:
            moves += [m for m in self._other_moves(monster) if m not in moves]
            skill = monster.skill
            if skill and skill.get("kind") != "call" and skill.get("weight"):
                moves.append(skill)
        move = self._rng.choices(moves, weights=[m["weight"] for m in moves])[0]
        return move, 0 if move is monster.skill else self._move_cost(move)

    @staticmethod
    def _other_moves(monster: Combatant) -> list[dict]:
        """An ordinary two-stance monster's other stance's moves; none for a boss (Frankie, 10/28).

        A monster with reasons of its own to switch (a boss's ``switch``)
        keeps to the stance it is in until a reason moves it.
        """
        if len(monster.pools) < 2 or monster.switch:
            return []
        return list(monster.pools[1 - monster.pool][1])

    @staticmethod
    def _move_cost(move: dict) -> int:
        """A monster move's cost in mana, its row (D-329)."""
        return min(BattleSettings.MANA_CAP, max(1, int(move.get("tier") or move.get("warmup") or 0)))

    def _foe_turn(self, monster: Combatant, move: dict, cost: int) -> list[Any]:
        """A monster's own turn, on its own side (``_monster_turn``)."""
        living = [c for c in self.party if c.alive]
        events: list[Any] = []
        # Possess plays as confusion (D-547): for its next turns, half the
        # time the monster turns on its own side, itself if it is alone.
        if monster.statuses.get("possess"):
            turned = self._rng.random() < BattleSettings.POSSESS_CHANCE
            monster.statuses["possess"] -= 1
            if monster.statuses["possess"] <= 0:
                del monster.statuses["possess"]
                if not turned:
                    events.append(StatusAppliedEvent(monster.id, monster.name, "possess", False))
            if turned:
                kin = [c for c in self.enemies if c.alive and c is not monster]
                living = kin or [monster]
                events.append(StatusAppliedEvent(monster.id, monster.name, "turned", True))
        # A move wound up last turn comes now, whatever else has changed (Frankie, 10/28),
        # and so does the move it changed stance for.
        winding, monster.winding = monster.winding, None
        wanted, monster.wanting = monster.wanting, None
        if winding is not None:
            move, cost = winding, self._move_cost(winding)
        elif wanted is not None:
            move, cost = wanted, self._move_cost(wanted)
            monster.in_stance += 1
        # Its Skill first: short of help, the Great Boar squeals for it (Frankie, 10/28).
        elif self._squeals(monster):
            return events + self._squeal(monster)
        # A boss changes stance for a reason (D-601); the switch is its turn.
        elif self._foe_switches(monster):
            return events + self._foe_switch(monster)
        # An ordinary one changes stance when the move it wants is in its other
        # stance, and uses it next turn (Frankie, 10/28); the switch is its turn.
        elif self._needs_switch(monster, move, cost):
            return events + self._switch_for(monster, move)
        else:
            monster.in_stance += 1
        if move["kind"] in ("heal", "support"):
            # Black Water's ring is browser only for now, and a caring move with
            # nothing to mend is skipped: either way the monster attacks instead.
            if move.get("guard") or self._idle(monster, move):
                cost = BattleSettings.MANA_CAP + 1
            elif cost <= monster.mana:
                return events + self._monster_tend(monster, move, cost)
        elif move["kind"] == "puppet":
            if cost <= monster.mana:
                return events + self._puppet(monster, move, cost)
        elif move["kind"] not in ("physical", "magic"):
            cost = BattleSettings.MANA_CAP + 1
        if cost > monster.mana:
            chain = {"target": None, "points": 0, "landed": 0}
            events += self._auto_strokes(monster, self._rng.choice(living), chain)
            struck = {e.target_name for e in events if isinstance(e, StrokeEvent)}
            events.append(ChainEndedEvent(
                monster.id, monster.name,
                struck.pop() if len(struck) == 1 else None,
                sum(e.amount for e in events
                    if isinstance(e, DamageEvent) and e.cause == "stroke"),
            ))
            events.extend(self._spend(monster, max(
                BattleSettings.FATIGUE_LEAST,
                chain["points"] * BattleSettings.STROKE_WAIT,
            )))
            return events
        # A big blow can take a turn to wind up (the Great Boar's, Frankie 10/28): said
        # out loud, so the party can brace, and struck on its next turn.
        if move.get("winds_up") and winding is None:
            monster.winding = move
            events.append(NoteEvent(f"{monster.name} winds up for {move['name']}!", monster.id))
            events.extend(self._spend(monster, BattleSettings.WINDUP_WAIT))
            return events
        element = Element(move["element"]) if move["element"] else None
        power = move["power"]
        # Angry, it hits harder (Frankie, 10/29; the number is Claude's).
        if monster.angry and monster.angry_rule:
            power *= monster.angry_rule.get("power", 1)
        # A move that hits everyone cannot be guarded.
        targets = living if move["all"] else [self._rng.choice(living)]
        for target in targets:
            if not target.alive or not monster.alive:
                continue
            events.append(
                AttackEvent(
                    monster.id, monster.name, target.id, target.name,
                    element, move["name"],
                )
            )
            if move["kind"] == "physical":
                events.extend(
                    self._physical(
                        monster, target, power, element,
                        move["statuses"], unguardable=move["all"],
                    )
                )
            else:
                events.extend(
                    self._magic(
                        monster, target, power, element, move["statuses"]
                    )
                )
        events.extend(self._end_move(monster, move, cost))
        return events

    def _charmed_turn(self, monster: Combatant, move: dict, cost: int) -> list[Any]:
        """A charmed monster's turn (Maika's Charm, Frankie 10/25): it fights for the party.

        It plays as an ally (``_ally_turn``) against its own side; alone, it
        does nothing. It does not change stance while charmed. The last
        charmed turn ends with it snapping out of it.
        """
        monster.statuses["charmed"] -= 1
        monster.winding = monster.wanting = None
        events = self._ally_turn(monster, move, cost, [c for c in self.enemies if c.alive and c is not monster])
        if monster.statuses.get("charmed", 0) <= 0:
            monster.statuses.pop("charmed", None)
            events.append(StatusAppliedEvent(monster.id, monster.name, "charmed", False))
        return events

    def submit_call(self) -> list[Any]:
        """Tawiri's Call, her Skill (Frankie, 10/25): a spirit joins the party for CALL_TURNS of its turns.

        It is the monster ``tawiri_spirit`` on the party's side, by the
        monsters' rules (``_summon_turn``), with CALL_HP of her max HP and
        CALL_STATS of her points, the spirit element; enemies may hit it.
        Calling again sends the one out away first. A Skill costs no mana,
        builds 1 and waits 7.
        """
        actor = self._require_player_actor()
        events: list[Any] = [NoteEvent(f"{actor.name} calls one of the dead to fight beside her.", actor.id)]
        for old in [c for c in self.party if c.summon_turns]:
            events += self._dismiss(old)
        kind = SHARED_MONSTERS["tawiri_spirit"]
        spirit = Combatant(
            combatant_id="tawiri_spirit", name=kind["name"], elements=(Element.MANA,), is_party=True,
            max_hp=max(1, round(actor.max_hp * BattleSettings.CALL_HP)), moves=kind["moves"],
            immune=kind.get("immune", ()), stances=[{"name": kind["name"], "element": "mana"}], kind="tawiri_spirit",
        )
        spirit.points = {k: max(1, round(v * BattleSettings.CALL_STATS)) for k, v in actor.points.items()}
        spirit.max_hp = spirit.hp = max(1, round(actor.max_hp * BattleSettings.CALL_HP))
        spirit.summon_turns = BattleSettings.CALL_TURNS
        # It acts next, ahead of everyone.
        spirit.counter = min(c.counter for c in self.party + self.enemies if c.alive) - 0.01
        self.party.append(spirit)
        events.append(SummonEvent(spirit.id, spirit.name, True))
        return self._finish_tech(events)

    def _summon_turn(self, spirit: Combatant) -> list[Any]:
        """Tawiri's spirit's turn: a monster's move by weight, played as an ally, then a turn less."""
        move, cost = self._pick_move(spirit)
        events = self._ally_turn(spirit, move, cost, [c for c in self.enemies if c.alive])
        spirit.summon_turns -= 1
        if spirit.summon_turns <= 0 and spirit in self.party:
            events += self._dismiss(spirit)
        return events

    def _dismiss(self, spirit: Combatant) -> list[Any]:
        """Tawiri's spirit fades: out of the fight and off the party's rows."""
        if spirit in self.party:
            self.party.remove(spirit)
        spirit.hp, spirit.gone, spirit.summon_turns = 0, True, 0
        return [NoteEvent(f"The {spirit.name.lower()} fades away.", spirit.id), SummonEvent(spirit.id, spirit.name, False)]

    def _ally_turn(self, monster: Combatant, move: dict, cost: int, foes: list[Combatant]) -> list[Any]:
        """A monster's turn fought for the party: a charmed one, or Tawiri's spirit.

        A caring move it can pay for tends the party; anything else goes at
        ``foes``, strokes when it cannot pay; with no foes it does nothing.
        """
        kin = foes
        events: list[Any] = []
        if move["kind"] in ("heal", "support") and not move.get("guard") and cost <= monster.mana \
                and not self._idle(monster, move, self.party):
            events += self._monster_tend(monster, move, cost, self.party)
        elif not kin:
            events.append(NoteEvent(f"{monster.name} is charmed and does nothing.", monster.id))
            events.extend(self._spend(monster, BattleSettings.FATIGUE_OTHER, still=True))
        elif move["kind"] in ("physical", "magic") and cost <= monster.mana:
            element = Element(move["element"]) if move["element"] else None
            for target in (kin if move["all"] else [self._rng.choice(kin)]):
                if not target.alive or not monster.alive:
                    continue
                events.append(AttackEvent(monster.id, monster.name, target.id, target.name, element, move["name"]))
                if move["kind"] == "physical":
                    events += self._physical(monster, target, move["power"], element, move["statuses"],
                                             unguardable=move["all"])
                else:
                    events += self._magic(monster, target, move["power"], element, move["statuses"])
            events.extend(self._pay(monster, cost))
            events.extend(self._spend(monster, BattleSettings.FATIGUE_OTHER))
        else:
            chain = {"target": None, "points": 0, "landed": 0}
            events += self._auto_strokes(monster, self._rng.choice(kin), chain)
            struck = {e.target_name for e in events if isinstance(e, StrokeEvent)}
            events.append(ChainEndedEvent(
                monster.id, monster.name, struck.pop() if len(struck) == 1 else None,
                sum(e.amount for e in events if isinstance(e, DamageEvent) and e.cause == "stroke")))
            events.extend(self._spend(monster, max(
                BattleSettings.FATIGUE_LEAST, chain["points"] * BattleSettings.STROKE_WAIT)))
        return events

    def _monster_tend(self, monster: Combatant, move: dict, cost: int,
                      side: list[Combatant] | None = None) -> list[Any]:
        """Play a monster's caring move (D-592, D-594, D-598).

        It heals, cures, buffs, braces or naps. A move marked ``self``
        tends the monster itself, one marked ``allies`` every monster
        standing; otherwise it tends the most hurt monster on its side,
        itself included. A charmed monster's ``side`` is the party.
        """
        kin = [c for c in (self.enemies if side is None else side) if c.alive]
        if move.get("allies"):
            targets = kin
        elif move.get("self"):
            targets = [monster]
        else:
            targets = [min(kin, key=lambda c: c.hp / c.max_hp)]
        aimed = None if move.get("allies") or targets[0] is monster else targets[0].name
        events: list[Any] = [AbilityUsedEvent(
            monster.id, monster.name, move["name"].lower().replace(" ", "_"), move["name"], aimed)]
        for target in targets:
            if move.get("cure"):
                for status in ("blind", "sleep", "poison"):
                    target.statuses.pop(status, None)
            if move.get("heal"):
                events += self._heal(target, round(target.max_hp * move["heal"]))
            for buff in move.get("buffs", ()):
                if buff == "haste":
                    target.haste = BattleSettings.HASTE_ACTIONS
                elif buff == "regen":
                    target.regen = BattleSettings.REGEN_TURNS
                else:
                    target.statuses[buff] = BattleSettings.BUFF_TURNS
                events.append(StatusAppliedEvent(target.id, target.name, buff, True))
        if move.get("defend"):
            monster.defending = True
            events.append(DefendEvent(monster.id, monster.name))
        if move.get("nap"):
            events += self._inflict(monster, "sleep")
        events.extend(self._end_move(monster, move, cost))
        return events

    def _idle(self, monster: Combatant, move: dict, side: list[Combatant] | None = None) -> bool:
        """Return True for a heal-only move with nothing to mend: everyone whole and well."""
        if move.get("buffs") or move.get("defend") or move.get("nap"):
            return False
        kin = [monster] if move.get("self") else [c for c in (self.enemies if side is None else side) if c.alive]

        def sick(c: Combatant) -> bool:
            return any(s in c.statuses for s in ("blind", "sleep", "poison"))

        return all(c.hp >= c.max_hp and not (move.get("cure") and sick(c)) for c in kin)

    def _puppet(self, monster: Combatant, move: dict, cost: int) -> list[Any]:
        """Puppet Strings, the shadow and spirit pair (D-597): one of the party strikes another."""
        living = [c for c in self.party if c.alive]
        puppet = self._rng.choice(living)
        others = [c for c in living if c is not puppet]
        victim = self._rng.choice(others) if others else puppet
        events: list[Any] = [AbilityUsedEvent(
            monster.id, monster.name, "puppet_strings", move["name"], puppet.name)]
        events += self._physical(
            puppet, victim, BattleSettings.ATTACK_POWER * 2, None, unguardable=True)
        events.extend(self._end_move(monster, move, cost))
        return events

    def _end_move(self, monster: Combatant, move: dict, cost: int) -> list[Any]:
        """Close a monster's move: pay its mana and wait, or, for its Skill, build 1 and wait 7.

        A monster's Skill costs no mana, builds TECH_MANA and waits its
        ``wait``, a Skill's (FATIGUE_TECH), as the party's do (Frankie, 10/24 and 10/28).
        """
        if move is monster.skill:
            return self._gain(monster, BattleSettings.TECH_MANA) + \
                self._spend(monster, move.get("wait", BattleSettings.FATIGUE_TECH))
        return self._pay(monster, cost) + self._spend(monster, BattleSettings.FATIGUE_OTHER)

    def _called(self, monster: Combatant) -> list[Combatant]:
        """The monsters ``monster`` has called to its side that still stand."""
        return [c for c in self.enemies if c.alive and c.caller == monster.id]

    def _squeals(self, monster: Combatant) -> bool:
        """Return True when ``monster`` uses its calling Skill now, Squeal (Frankie, 10/28).

        A monster whose Skill is of kind ``call`` uses it when fewer than
        its ``below`` of the monsters it called stand at its side, and the
        field has room for one more (``BattleSettings.FOES``, the cartridge's three).
        """
        rule = monster.skill
        if not rule or rule.get("kind") != "call" or monster.statuses.get("charmed"):
            return False
        # Angry, it stops squealing (Frankie, 10/29).
        if monster.angry:
            return False
        room = BattleSettings.FOES - sum(1 for c in self.enemies if c.alive)
        return room > 0 and len(self._called(monster)) < rule.get("below", 1)

    def _squeal(self, monster: Combatant) -> list[Any]:
        """The Great Boar's Skill, Squeal (Frankie, 10/28): its kind come running to its side.

        ``count`` of the encounter entry ``calls`` join the enemies, never
        past the field's room, lettered by how many it has called this
        fight (Wild Boar A, Wild Boar B), each acting after one ordinary
        wait. They fight as any of their kind do, and run off when their
        caller falls. A Skill costs no mana, builds 1 and waits 7, as the
        party's do (Frankie, 10/24).
        """
        from core.factories import combatant_from_monster_data  # local: factories imports this module.
        from core.shared import by_id

        rule = monster.skill or {}
        name = rule.get("name", "Squeal")
        events: list[Any] = [AbilityUsedEvent(
            monster.id, monster.name, name.lower().replace(" ", "_"), name, None)]
        template = next(e for en in by_id("encounters").values() for e in en["enemies"]
                        if e["id"] == rule["calls"])
        kind = SHARED_MONSTERS[template["monster"]]
        base = template["name"].removesuffix(" A")
        room = BattleSettings.FOES - sum(1 for c in self.enemies if c.alive)
        for _ in range(min(room, rule.get("count", 1))):
            self._calls += 1
            letter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"[(self._calls - 1) % 26]
            entry = dict(template, id=f"{monster.id}_call_{self._calls}", name=f"{base} {letter}")
            called = combatant_from_monster_data(entry, kind)
            called.caller = monster.id
            called.counter = monster.counter + BattleSettings.FATIGUE_OTHER * defense_scale(called.points["speed"])
            self.enemies.append(called)
            events.append(NoteEvent(f"{called.name} comes running!", called.id))
            events.append(SummonEvent(called.id, called.name, True))
        events.extend(self._gain(monster, BattleSettings.TECH_MANA))
        events.extend(self._spend(monster, rule.get("wait", BattleSettings.FATIGUE_TECH)))
        return events

    def _run_off(self, caller: Combatant) -> list[Any]:
        """The monsters ``caller`` called leave the fight when it falls (Frankie, 10/28)."""
        events: list[Any] = []
        for c in self._called(caller):
            c.hp, c.gone = 0, True
            c.statuses.clear()
            events.append(CombatantDefeatedEvent(c.id, c.name, fled=True))
        return events

    def _foe_switches(self, monster: Combatant) -> bool:
        """Return True when a two-stance monster leaves its stance now (D-601).

        One reason per stance, from the shared file: "hurt" (HP below a
        share), "mended" (back above one), "struck" (that many physical
        blows since its last turn), "after" (that many turns in the
        stance), "cursed" (that many of the party carry a curse). A
        monster with no reasons switches only for a move it wants
        (``_needs_switch``, Frankie, 10/28; it was at random, D-596).
        """
        struck, monster.struck = monster.struck, 0
        if len(monster.pools) < 2 or not monster.switch:
            return False
        # Angry, it locks into its first stance, fire, for the rest of the fight (Frankie, 10/29).
        if monster.angry and monster.angry_rule:
            return monster.pool != 0
        why = monster.switch[monster.pool]
        share = monster.hp / monster.max_hp
        when = why.get("when")
        if when == "hurt":
            return share < why["below"]
        if when == "mended":
            return share >= why["above"]
        if when == "struck":
            return struck >= why["n"]
        if when == "after":
            return monster.in_stance >= why["n"]
        if when == "cursed":
            curses = ("poison", "blind", "sleep", "doom", "possess", "slow")
            cursed = [c for c in self.party if c.alive and any(k in c.statuses for k in curses)]
            return len(cursed) >= why["n"]
        return False

    def _needs_switch(self, monster: Combatant, move: dict, cost: int) -> bool:
        """Return True when an ordinary monster changes stance for ``move`` (Frankie, 10/28).

        The move is in its other stance only, it can pay for it, and it
        would do something (a heal with nothing to mend is not worth a turn).
        """
        if move in monster.moves or move not in self._other_moves(monster):
            return False
        if cost > monster.mana:
            return False
        return not (move["kind"] in ("heal", "support") and self._idle(monster, move))

    def _switch_for(self, monster: Combatant, move: dict) -> list[Any]:
        """Change stance to use ``move`` next turn, said aloud so the party sees it coming (Frankie, 10/28)."""
        events = self._foe_switch(monster)
        monster.wanting = move
        events.insert(1, NoteEvent(f"{monster.name} readies {move['name']}!", monster.id))
        return events

    def _foe_switch(self, monster: Combatant) -> list[Any]:
        """Move a monster into its other stance: element, stats and moves change, the turn is spent.

        It builds STANCE_MANA, as a hero's switch does (Frankie, 10/28). The
        StanceEvent is always shown, scanned or not: its words and the effect
        over the monster in the new element's color (ui/battle_stage.py).
        """
        monster.pool = 1 - monster.pool
        element, moves = monster.pools[monster.pool]
        monster.elements = (element,) * len(monster.elements)
        monster.points = stat_points(monster.elements, None, monster.growth)
        monster.moves = list(moves)
        monster.in_stance = 0
        events: list[Any] = [StanceEvent(monster.id, monster.name, "", element)]
        events.extend(self._gain(monster, BattleSettings.STANCE_MANA))
        return events + self._spend(monster, BattleSettings.FATIGUE_OTHER)

    def _stroke(
        self,
        attacker: Combatant,
        target: Combatant,
        kind: str,
        chain: dict[str, Any],
    ) -> list[Any]:
        """Swing one stroke and keep the chain's count.

        Each stroke that lands this turn steadies the next one, and
        builds the striker its points in mana.
        """
        stroke = BattleSettings.STROKES[kind]
        power = BattleSettings.STROKE_POWER * stroke["power"]
        events: list[Any] = [
            StrokeEvent(
                attacker.id, attacker.name, target.id, target.name, stroke["name"]
            )
        ]
        land = self.stroke_chance(kind, target) if attacker is self._current_actor else 1.0
        hit = self._physical(
            attacker, target, power, None,
            accuracy=stroke["hit"] + BattleSettings.STROKE_STEADY * chain["landed"],
            stroke=stroke["name"],
        )
        events.extend(hit)
        chain["points"] += stroke["points"]
        if any(isinstance(e, DamageEvent) and e.cause == "stroke" for e in hit):
            chain["landed"] += 1
            events.extend(self._gain(attacker, stroke["points"]))
            # Strength from strong strokes, Agility from light ones landed
            # in a row, the first of a streak giving nothing, and Perception
            # more the less likely the hit was (D-500, D-521, Frankie, 10/27).
            if kind == "strong":
                events.extend(self._fill(attacker, "strength", self.growth["strong_stroke"]
                                         * self._teaches(attacker, "strength", [target.id])))
            chain["lights"] = chain.get("lights", 0) + 1 if kind == "light" else 0
            if chain["lights"] > 1:
                events.extend(self._fill(attacker, "speed", self.growth["light_streak"]))
            events.extend(self._fill(
                attacker, "accuracy", 100 * self.growth["perception_miss"] * (1 - land)))
        else:
            # A miss breaks a streak of light strokes.
            chain["lights"] = 0
        return events

    def _auto_strokes(
        self, attacker: Combatant, target: Combatant, chain: dict[str, Any]
    ) -> list[Any]:
        """Swing the light, medium and strong chain, as far as the points go.

        If the target falls, the rest of the chain goes to the weakest
        one standing on its side.
        """
        events: list[Any] = []
        for kind in BattleSettings.AUTO_STROKES:
            points = BattleSettings.STROKES[kind]["points"]
            if chain["points"] + points > BattleSettings.STROKE_POINTS or not attacker.alive:
                break
            if not target.alive:
                side = self.party if target.is_party else self.enemies
                standing = [c for c in side if c.alive]
                if not standing:
                    break
                target = min(standing, key=lambda c: c.hp)
            events.extend(self._stroke(attacker, target, kind, chain))
        return events

    # ------------------------------------------------------------------
    # DAMAGE AND HEALING
    # ------------------------------------------------------------------

    def _physical(
        self,
        attacker: Combatant,
        target: Combatant,
        power: float,
        element: Element | None,
        statuses: Iterable[str] = (),
        unguardable: bool = False,
        accuracy: float | None = None,
        stroke: str | None = None,
    ) -> list[Any]:
        """Resolve one physical hit, including any guard in the way.

        Any blow can be dodged (Evasion against Accuracy) or blocked for
        half damage (Vitality); either builds the defender 1 mana.
        ``accuracy`` is a stroke's chance to land, None for a sure blow
        (9 for one that cannot be dodged, Hot Pan). A status "ignite" is a
        sure burn. Kailo's guards answer the hit: Counter Guard and Dinner
        Bell kick back, Hot Oil burns the striker, Steam Vent scalds every
        enemy.
        """
        if (
            "blind" in attacker.statuses
            and self._rng.random() < BattleSettings.BLIND_MISS_CHANCE
        ):
            return [
                MissEvent(attacker.id, attacker.name, target.id, target.name)
            ]
        events: list[Any] = []
        guard = None if unguardable else self._guard_for(target, element)
        # Dinner Bell (D-305) is a taunt: a hit on an ally can ignore it, and a boss always does.
        if (guard is not None and guard is not target and guard.guard == "bell"
                and (attacker.boss or self._rng.random() >= _MOVE["dinner_bell"]["chance"])):
            guard = None
        struck = guard or target
        if guard is not None and guard is not target:
            events.append(
                GuardInterceptEvent(
                    guard.id, guard.name, target.id, target.name
                )
            )
        land = self._land_chance(attacker, struck, accuracy)
        if self._rng.random() >= land:
            events.append(DodgeEvent(attacker.id, attacker.name, struck.id, struck.name, stroke))
            events.extend(self._gain(struck, BattleSettings.DODGE_MANA))
            # Luck grows from dodging (D-500), more the likelier the hit was.
            events.extend(self._fill(struck, "evasion", 100 * self.growth["luck_hit"] * land))
            # Counter answers a dodged blow too (Frankie, 10/28).
            if guard is not None and guard.guard == "counter" and attacker.alive:
                events.extend(self._kick_back(guard, attacker))
            return events
        warded = self._spend_ward(struck, element, events)
        if warded <= 0:
            return events
        blocked = self._rng.random() < self._block(struck)
        # A self guard (Oven Mitt) cuts one element's hits on its holder only.
        own = (guard is None and struck.guard is not None and element is not None
               and _SELF_GUARDS.get(struck.guard) is element)
        if guard is not None and guard.guard in _FIRE_SENTINELS:
            multiplier = guard.guard_m or BattleSettings.GUARD_MULTIPLIER
        elif guard is not None:
            multiplier = guard.guard_m or BattleSettings.GUARD_MULTIPLIER
            if element is Element.AFI:
                multiplier *= BattleSettings.GUARD_AFI_MULTIPLIER
            elif element is Element.LAU:
                multiplier *= BattleSettings.GUARD_LAU_MULTIPLIER
        else:
            multiplier = struck.guard_m if own else self._weakness(element, struck)
            if struck.defending:
                multiplier *= BattleSettings.DEFEND_MULTIPLIER
        if "protect" in struck.statuses:
            multiplier *= BattleSettings.PROTECT_MULTIPLIER
        if blocked:
            multiplier *= BattleSettings.BLOCK_MULTIPLIER
        # Evil Eye's weakness (D-720): the weakened hit softer.
        weak = _MOVE["lure"]["weaken"] if "weak" in attacker.statuses else 1.0
        amount = self._jitter(
            power
            * multiplier
            * warded
            * offense_scale(attacker.points["strength"])
            * defense_scale(struck.points["vitality"])
            * weak
        )
        woke = struck.statuses.pop("sleep", None) is not None
        events.extend(
            self._deal(
                struck, amount, element, multiplier,
                guarded=guard is not None or own, woke=woke,
                cause="stroke" if stroke else "hit", blocked=blocked,
                attacker_name=attacker.name, stroke=stroke,
            )
        )
        events.extend(self._scald(struck, element, amount))
        if amount > 0 and not struck.is_party:
            struck.struck += 1
        if blocked:
            events.extend(self._gain(struck, BattleSettings.DODGE_MANA))
        # A physical hit knocks a possessing spirit out (D-547).
        if amount > 0 and struck.alive and struck.statuses.pop("possess", None):
            events.append(StatusAppliedEvent(struck.id, struck.name, "spirit_knocked", False))
        # Physical damage snaps a monster out of Maika's Charm, never out of a sulk (Frankie, 10/25).
        if amount > 0 and struck.alive and struck.statuses.pop("charmed", None):
            events.append(StatusAppliedEvent(struck.id, struck.name, "charmed", False))
        for status in statuses:
            if status == "ignite":
                events.extend(self._scald(struck, Element.AFI, amount, chance=1.0))
            else:
                events.extend(self._inflict(struck, status))
        if guard is None or not guard.alive:
            return events
        if guard.guard == "oil" and attacker.alive and amount > 0:
            events.extend(self._scald(attacker, Element.AFI, amount, chance=1.0))
        if guard.guard == "steam" and amount > 0:
            events.append(NoteEvent(f"Steam bursts off {guard.name}.", guard.id))
            other = self.enemies if guard.is_party else self.party
            for foe in [c for c in other if c.alive]:
                steam = self._weakness(Element.WAI, foe)
                scalded = max(1, round(amount * _MOVE["steam_vent"]["back"] * steam))
                events.append(NoteEvent(f"{foe.name} is scalded for {scalded}.", foe.id))
                events.extend(self._deal(foe, scalded, Element.WAI, steam, cause="steam"))
        if guard.guard in ("counter", "bell") and attacker.alive:
            events.extend(self._kick_back(guard, attacker))
        return events

    def _kick_back(self, guard: Combatant, attacker: Combatant) -> list[Any]:
        """Counter's or Dinner Bell's fire kick at the one who struck."""
        counter_multiplier = self._weakness(Element.AFI, attacker)
        counter = self._jitter(
            (guard.guard_kick or BattleSettings.ATTACK_POWER)
            * counter_multiplier
            * offense_scale(guard.points["strength"])
            * defense_scale(attacker.points["vitality"])
        )
        return self._deal(
            attacker, counter, Element.AFI, counter_multiplier,
            cause="counter", attacker_id=guard.id,
        )

    def _magic(
        self,
        attacker: Combatant,
        target: Combatant,
        power: float,
        element: Element | None,
        statuses: Iterable[str] = (),
        extra_turns: int = 0,
    ) -> list[Any]:
        """Resolve one spell. Guards and Defend do nothing against it.

        ``extra_turns`` is what a higher row adds to a sleep (D-319). A
        mind broken by Mental Break takes more.
        """
        events: list[Any] = []
        warded = self._spend_ward(target, element, events) if power else 1.0
        if warded <= 0:
            return events
        if power:
            multiplier = self._weakness(element, target)
            if "shell" in target.statuses:
                multiplier *= BattleSettings.SHELL_MULTIPLIER
            if "mbreak" in target.statuses:
                multiplier *= _COMBO["red_hot_poker"]["break_multiplier"]
            amount = self._jitter(
                power
                * multiplier
                * warded
                * offense_scale(attacker.points["magic"])
                * defense_scale(target.points["spirit"])
            )
            events.extend(
                self._deal(target, amount, element, multiplier, cause="spell")
            )
            events.extend(self._scald(target, element, amount))
        for status in statuses:
            events.extend(self._inflict(target, status, extra_turns))
        return events

    @staticmethod
    def dealt(events: Iterable[Any], target: Combatant | None = None) -> int:
        """Return the damage in ``events``, on ``target`` alone if given (a move's own hit)."""
        return sum(
            e.amount for e in events
            if isinstance(e, DamageEvent) and e.cause in ("hit", "spell", "stroke")
            and (target is None or e.target_id == target.id)
        )

    def _deal(
        self,
        target: Combatant,
        amount: int,
        element: Element | None = None,
        multiplier: float = NEUTRAL_MULTIPLIER,
        guarded: bool = False,
        woke: bool = False,
        cause: str = "hit",
        blocked: bool = False,
        attacker_name: str | None = None,
        stroke: str | None = None,
        attacker_id: str | None = None,
    ) -> list[Any]:
        """Take ``amount`` HP off ``target`` and report it."""
        if not target.alive:
            return []
        # Simmer and Boil Over hold in physical hits only; magic gets through.
        if target.guard in ("cooker", "boil") and amount > 0 and cause in ("hit", "stroke"):
            target.cooker_took += min(target.hp, amount)
        target.hp = max(0, target.hp - amount)
        events: list[Any] = [
            DamageEvent(
                target.id, target.name, amount, element, multiplier,
                guarded, woke, cause, blocked, attacker_name, stroke,
                attacker_id,
            )
        ]
        # Tawiri's spirit knocked out fades at once (Frankie, 10/25).
        if not target.alive and target.summon_turns:
            return events + self._dismiss(target)
        # A hit while Kailo cooks ruins it, not poison or the like (Frankie, 10/25).
        if target.dish and amount > 0 and cause in ("hit", "stroke", "spell"):
            events.append(NoteEvent(f"{target.name}'s {BattleSettings.COOK_DISHES[target.dish]} is ruined!", target.id))
            target.dish = None
        # Hina's Perennial (D-653): the first fall of the fight is not the last.
        if not target.alive and target.statuses.pop("perennial", None):
            target.hp = max(1, round(target.max_hp * _MOVE["perennial"]["revive_share"]))
            events.append(NoteEvent(
                f"{target.name} falls, and gets back up with {target.hp} HP.", target.id))
            return events
        # Her Seed blooms the first time they are hurt.
        if target.alive and amount > 0 and target.statuses.get("sprout"):
            sprout = target.statuses.pop("sprout")
            events.append(NoteEvent(f"The seed on {target.name} blooms.", target.id))
            events.extend(self._heal(target, sprout))
        if not target.alive:
            for key in list(target.boosts):
                self._unboost(target, key)
            for key in list(target.drops):
                self._undrop(target, key)
            target.statuses.clear()
            target.guard = None
            target.ward = 0.0
            target.haste = 0
            target.safe = False
            target.regen = 0
            target.spirit = None
            target.cursed_by.clear()
            target.winding = target.wanting = None
            events.append(CombatantDefeatedEvent(target.id, target.name))
            return events + self._run_off(target)
        # Below a share of its HP the Great Boar gets angry, once (Frankie, 10/28).
        rule = target.angry_rule
        if rule and not target.angry and target.hp < target.max_hp * rule["below"]:
            target.angry = True
            events.append(NoteEvent(f"{target.name} is angry!", target.id))
        # Vitality grows from any damage, Endurance from a physical hit,
        # Willpower from a magic one (D-500), by the share of max HP lost;
        # Vitality, which every hit feeds, at a share of that.
        share = 100 * amount / max(1, target.max_hp)
        events.extend(self._fill(target, "hp", share * self.growth["vitality_share"]))
        if cause in ("stroke", "hit", "counter"):
            events.extend(self._fill(target, "vitality", share))
        elif cause == "spell":
            events.extend(self._fill(target, "spirit", share))
        return events

    def _teaches(self, actor: Combatant, key: str, foe_ids: list[str]) -> float:
        """How much of a Strength or Intelligence point ``actor`` earns: weaker enemies teach less (Frankie, 10/28).

        Strength is weighed against the foe's Endurance, Intelligence
        against its Willpower: full against an equal or stronger foe,
        their share below that, never under ``weaker_floor``. Of several
        foes hurt the strongest counts; with none, as for a heal, the
        strongest enemy standing does.
        """
        guard = {"strength": "vitality", "magic": "spirit"}[key]
        foes = [c for c in self.enemies if c.id in foe_ids] or [c for c in self.enemies if c.alive]
        if not foes:
            return 1.0
        best = max(c.points[guard] for c in foes)
        return max(self.growth["weaker_floor"], min(1.0, best / max(1, actor.points[key])))

    def _fill(self, combatant: Combatant, key: str, points: float) -> list[Any]:
        """Put ``points`` in ``combatant``'s hidden meter for stat ``key``; each full meter is +1 (D-498, D-507).

        The meter (Frankie, 10/27, replacing the chance): every stat
        has one, ``meter`` points long, kept between fights and saved;
        what goes past full carries into the next. Only party members
        grow, as often as their meters fill (Frankie, 10/26), never past
        the cap. Tawiri's passive multiplies every point (``step``,
        ``systems/passives.py``). The point goes into the base and every
        multiplier applies again; a Vitality point raises max HP at once.
        """
        if not combatant.is_party or combatant.summon_turns or not combatant.alive or points <= 0:
            return []
        filled = combatant.meters.get(key, 0) + points * self.growth["step"]
        events: list[Any] = []
        while filled >= self.growth["meter"]:
            if StatSettings.BASE_POINTS + combatant.growth.get(key, 0) >= self.growth["cap"]:
                break
            filled -= self.growth["meter"]
            events.append(self._raise(combatant, key))
        combatant.meters[key] = filled
        return events

    def _raise(self, combatant: Combatant, key: str) -> StatGrowthEvent:
        """Raise ``combatant``'s stat ``key`` by 1 now, said at once (D-498, D-526)."""
        combatant.grown[key] = combatant.grown.get(key, 0) + 1
        combatant.growth[key] = combatant.growth.get(key, 0) + 1
        points = stat_points(combatant.elements, combatant.stance_element, combatant.growth,
                             combatant.multipliers)
        combatant.points[key] = points[key] + combatant.boosts.get(key, 0) * (key != "hp")
        if key == "hp":
            combatant.max_hp = max_hp_for(points) + combatant.boosts.get("hp", 0)
        return StatGrowthEvent(combatant.id, combatant.name, key, combatant.points[key])

    def _heal(self, target: Combatant, amount: int) -> list[Any]:
        """Restore up to ``amount`` HP on a living ``target``. A burn stops it (D-312)."""
        if not target.alive:
            return []
        if "burn" in target.statuses:
            return [NoteEvent(f"{target.name} is burning and cannot be healed.", target.id)]
        before = target.hp
        # A heal never takes away the extra HP a meal left (Kailo's Cook, 10/25).
        target.hp = min(max(target.max_hp, before), target.hp + max(0, amount))
        return [HealEvent(target.id, target.name, target.hp - before)]

    def _spend_ward(self, target: Combatant, element: Element | None, events: list[Any]) -> float:
        """Spend ``target``'s ward on a shadow hit; return the share of the hit left (Frankie, 10/28)."""
        if element is not Element.ATA or not target.ward:
            return 1.0
        share, target.ward = target.ward, 0.0
        events.append(WardBlockedEvent(target.id, target.name, share=share))
        return max(0.0, 1.0 - share)

    def _inflict(self, target: Combatant, status: str, extra_turns: int = 0) -> list[Any]:
        """Try to give ``target`` a status; a sleep slotted higher lasts ``extra_turns`` longer."""
        if not target.alive:
            return []
        if status in target.immune:
            return [
                StatusResistedEvent(target.id, target.name, status, True)
            ]
        # Hina's Safeguard stops the next blind, sleep or poison (D-291).
        if status in _CLEANSABLE and target.safe:
            target.safe = False
            return [WardBlockedEvent(target.id, target.name, status)]
        if self._rng.random() > BattleSettings.STATUS_HIT_CHANCE:
            return [
                StatusResistedEvent(target.id, target.name, status, False)
            ]
        if status == "sleep":
            target.statuses["sleep"] = BattleSettings.SLEEP_TURNS + extra_turns
            target.guard = None
        elif status == "possess":
            target.statuses["possess"] = BattleSettings.POSSESS_TURNS
        elif status == "doom":
            target.statuses.setdefault("doom", _RULES["doom_turns"])
        elif status == "burn":
            target.statuses["burn"] = _COMBO["scorch"]["burn_turns"]
        else:
            target.statuses[status] = 1
        events: list[Any] = [StatusAppliedEvent(target.id, target.name, status, True)]
        # A status that takes hold on an enemy counts like a hit for whoever
        # cast it, by its chance to fail: Perception (D-521).
        caster = self._current_actor
        if caster is not None and caster.is_party and not target.is_party:
            events.extend(self._fill(
                caster, "accuracy",
                100 * self.growth["perception_miss"] * (1 - BattleSettings.STATUS_HIT_CHANCE)))
        return events

    # ------------------------------------------------------------------
    # STATUSES OVER TIME (the browser's startTurn and spend)
    # ------------------------------------------------------------------

    def _turn_ticks(self, actor: Combatant) -> list[Any]:
        """Run what happens at the top of ``actor``'s turn, in the browser's order.

        Leech Seed drinks, poison bites, Sap drains a mana and burns it,
        Doom counts down; then, if they still stand, Regen heals, Haunt
        bites, Tawiri's called spirit strikes, Bloom heals a little more,
        and the timed statuses and stat boosts count down.
        """
        events: list[Any] = []
        statuses = actor.statuses
        if statuses.get("seed"):
            amount = max(1, round(actor.max_hp * _COMBO["leech_seed"]["seed_rate"]))
            other = self.enemies if actor.is_party else self.party
            drinker = min((c for c in other if c.alive), key=lambda c: c.hp / c.max_hp, default=None)
            events.append(NoteEvent(f"The seed drinks {amount} from {actor.name}.", actor.id))
            events.extend(self._deal(actor, amount, cause="seed"))
            if drinker is not None:
                events.extend(self._heal(drinker, amount))
            statuses["seed"] = statuses.get("seed", 1) - 1
            if statuses.get("seed", 0) <= 0:
                statuses.pop("seed", None)
        if "poison" in statuses and actor.alive:
            amount = round(actor.max_hp * actor.poison_rate)
            events.extend(self._deal(actor, amount, cause="poison"))
        if actor.alive and statuses.get("sap") and actor.mana > 0:
            actor.mana -= 1
            events.append(ManaEvent(actor.id, actor.name, -1, actor.mana))
            events.append(NoteEvent(f"{actor.name}'s mana drains away.", actor.id))
            caster = self._by_id(actor.cursed_by.get("sap"))
            events.extend(self._mana_burn(
                caster if caster is not None and caster.alive else None,
                actor, 1, _MOVE["sap"]["burn_power"]))
        if actor.alive and statuses.get("doom"):
            statuses["doom"] -= 1
            if statuses["doom"] <= 0:
                events.append(NoteEvent(f"Doom takes {actor.name}.", actor.id))
                events.extend(self._deal(actor, actor.max_hp, cause="doom"))
            else:
                events.append(NoteEvent(f"Doom: {statuses['doom']} turns left for {actor.name}.", actor.id))
        if not actor.alive:
            return events
        if actor.regen > 0:
            actor.regen -= 1
            events.extend(self._heal(
                actor, round(actor.max_hp * BattleSettings.REGEN_RATE)
            ))
        if statuses.get("haunt"):
            events.append(NoteEvent(
                f"The spirit haunting {actor.name} bites for {actor.haunt_damage}.", actor.id))
            events.extend(self._deal(actor, actor.haunt_damage, element=Element.MANA, cause="haunt"))
            statuses["haunt"] = statuses.get("haunt", 1) - 1
            if statuses.get("haunt", 0) <= 0:
                statuses.pop("haunt", None)
            if not actor.alive:
                return events
        if actor.spirit:
            foes = [c for c in (self.enemies if actor.is_party else self.party) if c.alive]
            if foes:
                foe = self._rng.choice(foes)
                events.append(NoteEvent(f"{actor.name}'s spirit strikes {foe.name}.", foe.id))
                events.extend(self._magic(actor, foe, actor.spirit["power"], Element.ATA))
            actor.spirit["left"] -= 1
            if actor.spirit["left"] <= 0:
                actor.spirit = None
        if statuses.get("bloom"):
            rates = _MOVE["bloom"]["bloom"]
            step = statuses["bloom"]
            events.extend(self._heal(actor, round(actor.max_hp * rates[step])))
            if step + 1 >= len(rates):
                statuses.pop("bloom", None)
            else:
                statuses["bloom"] = step + 1
        for key in ("protect", "shell") + _COUNTED:
            if key in statuses:
                statuses[key] -= 1
                if statuses[key] <= 0:
                    del statuses[key]
                    if key == "mleech":
                        actor.cursed_by.pop("mleech", None)
        for key in list(actor.boosts):
            name = "up_" + key
            statuses[name] = statuses.get(name, 1) - 1
            if statuses[name] <= 0:
                events.extend(self._unboost(actor, key))
        for key in list(actor.drops):
            name = "dn_" + key
            statuses[name] = statuses.get(name, 1) - 1
            if statuses[name] <= 0:
                events.extend(self._undrop(actor, key))
        return events

    def _burn_tick(self, combatant: Combatant, still: bool) -> list[Any]:
        """Burn (D-312) flares when the burned one moves: any action but Defend, not asleep or held."""
        turns = combatant.statuses.get("burn")
        if not turns or not combatant.alive:
            return []
        events: list[Any] = []
        if not combatant.defending and not still:
            amount = round(combatant.max_hp * combatant.poison_rate)
            events.append(NoteEvent(f"{combatant.name} moves and the burn flares: {amount}.", combatant.id))
            events.extend(self._deal(combatant, amount, element=Element.AFI, cause="burn"))
        if combatant.statuses.get("burn"):
            combatant.statuses["burn"] -= 1
            if combatant.statuses["burn"] <= 0:
                del combatant.statuses["burn"]
        return events

    def _scald(self, target: Combatant, element: Element | None, dealt: int,
               chance: float | None = None) -> list[Any]:
        """Any fire hit that does damage may leave a burn (D-312, D-561).

        The chance is the shared file's, more for a move slotted higher;
        ``chance`` 1 is a sure burn ("ignite", Char and Open Flame). Fire
        users never burn.
        """
        if (element is not Element.AFI or not dealt or not target.alive
                or "burn" in target.statuses or Element.AFI in target.elements
                or "burn" in target.immune):
            return []
        if chance is None:
            tier = min(7, max(1, self._tier or 1))
            chance = _RULES["fire_burn_chance"] + _RULES.get("fire_burn_per_tier", 0) * (tier - 1)
        if self._rng.random() >= chance:
            return []
        target.statuses["burn"] = _RULES["fire_burn_turns"]
        return [StatusAppliedEvent(target.id, target.name, "burn", True)]

    def _lose_mana(self, target: Combatant, amount: int) -> tuple[int, list[Any]]:
        """Knock up to ``amount`` mana out of ``target``; return how much and the events."""
        lost = min(amount, target.mana)
        if not lost:
            return 0, [NoteEvent(f"{target.name} has no mana to lose.", target.id)]
        target.mana -= lost
        return lost, [ManaEvent(target.id, target.name, -lost, target.mana)]

    def _mana_burn(self, caster: Combatant | None, target: Combatant, lost: int,
                   power: float) -> list[Any]:
        """Tawiri's mana burn (D-722): each mana knocked out hurts as spirit damage."""
        if not lost or not target.alive or not power:
            return []
        magic = offense_scale(caster.points["magic"]) if caster is not None else 1.0
        multiplier = self._weakness(Element.MANA, target)
        amount = max(1, round(
            lost * power * magic * defense_scale(target.points["spirit"]) * multiplier))
        events: list[Any] = [NoteEvent(f"The burned mana sears {target.name} for {amount}.", target.id)]
        return events + self._deal(target, amount, Element.MANA, multiplier, cause="mana_burn")

    def _toll(self, actor: Combatant, move: dict[str, Any]) -> list[Any]:
        """Tawiri's biggest spells cost her HP: never below 1."""
        share = move.get("hp_cost")
        if not share:
            return []
        cost = min(actor.hp - 1, round(actor.max_hp * share))
        if cost <= 0:
            return []
        actor.hp -= cost
        return [
            DamageEvent(actor.id, actor.name, cost, None, NEUTRAL_MULTIPLIER, cause="toll"),
            NoteEvent(f"The power takes {cost} HP from {actor.name}.", actor.id),
        ]

    def _roll(self) -> bool:
        """Return True when a status cast by a move takes hold (the shared chance)."""
        return self._rng.random() <= BattleSettings.STATUS_HIT_CHANCE

    def _boost(self, target: Combatant, key: str, turns: int) -> list[Any]:
        """One stat up until the third turn from now (D-716), more turns slotted higher.

        ``key`` is a stat key; "hp" raises max HP (and HP) by a quarter.
        Cast again while it holds, it only lasts longer.
        """
        if not target.alive:
            return []
        if key not in target.boosts:
            if key == "hp":
                added = round(target.max_hp * _BOOST_UP)
                target.max_hp += added
                target.hp += added
            else:
                added = round((StatSettings.BASE_POINTS + target.points[key]) * _BOOST_UP)
                target.points[key] += added
            target.boosts[key] = added
        target.statuses["up_" + key] = turns
        return [StatusAppliedEvent(target.id, target.name, "up_" + key, True)]

    def _unboost(self, target: Combatant, key: str) -> list[Any]:
        """Take a stat boost back off."""
        added = target.boosts.pop(key, 0)
        target.statuses.pop("up_" + key, None)
        if key == "hp":
            target.max_hp -= added
            target.hp = min(target.hp, target.max_hp)
        else:
            target.points[key] -= added
        return [StatusAppliedEvent(target.id, target.name, "up_" + key, False)]

    def _drop(self, target: Combatant, key: str, turns: int) -> list[Any]:
        """One stat down by a fifth of base plus the stat, for ``turns`` (the browser's stat down).

        An enemy may shake it off, at the chance any status has to take
        hold. Cast again while it holds, it only lasts longer.
        """
        if not target.alive:
            return []
        if "dn_" + key in target.immune:
            return [NoteEvent(f"{target.name} shrugs it off.", target.id)]
        if not target.is_party and self._rng.random() > BattleSettings.STATUS_HIT_CHANCE:
            return [NoteEvent(f"{_STAT_WORD[key]} down does not take hold on {target.name}.", target.id)]
        if key not in target.drops:
            taken = round((StatSettings.BASE_POINTS + target.points[key]) * _DROP_DOWN)
            target.points[key] -= taken
            target.drops[key] = taken
        target.statuses["dn_" + key] = turns
        return [StatusAppliedEvent(target.id, target.name, "dn_" + key, True)]

    def _undrop(self, target: Combatant, key: str) -> list[Any]:
        """Give a stat drop back."""
        target.points[key] += target.drops.pop(key, 0)
        target.statuses.pop("dn_" + key, None)
        return [StatusAppliedEvent(target.id, target.name, "dn_" + key, False)]

    def _boil_over(self, cook: Combatant) -> list[Any]:
        """Kailo's Boil Over: Simmer, but what he held comes back on every enemy."""
        took, cook.cooker_took = cook.cooker_took, 0
        foes = [c for c in self.enemies if c.alive]
        if took <= 0 or not foes:
            return [NoteEvent(f"{cook.name} lets the lid off, but nothing has built up.", cook.id)]
        events: list[Any] = [NoteEvent(f"{cook.name} boils over.", cook.id)]
        for foe in foes:
            multiplier = self._weakness(Element.AFI, foe)
            amount = round(took * _MOVE["boil_over"]["return_multiplier"] * multiplier)
            events.extend(self._deal(foe, amount, Element.AFI, multiplier,
                                     cause="cooker", attacker_name=cook.name))
        return events

    def _by_id(self, combatant_id: str | None) -> Combatant | None:
        """Return the fighter with ``combatant_id`` on either side, or None."""
        for combatant in self.party + self.enemies + self.bench:
            if combatant.id == combatant_id:
                return combatant
        return None

    # ------------------------------------------------------------------
    # INTERNALS
    # ------------------------------------------------------------------

    def _land_chance(self, attacker: Combatant, struck: Combatant, accuracy: float | None) -> float:
        """The chance a blow lands, before blindness: its aim plus Accuracy minus Evasion.

        Both ``_physical``'s roll and ``stroke_chance``'s preview read this,
        so the number shown is the number rolled.
        """
        return (1.0 if accuracy is None else accuracy) + self._aim(attacker) - self._evade(struck)

    @staticmethod
    def _aim(attacker: Combatant) -> float:
        """Accuracy's share of a blow's chance to land."""
        over = attacker.points["accuracy"] - StatSettings.BASE_POINTS
        return BattleSettings.PER_ACCURACY * over

    @staticmethod
    def _evade(target: Combatant) -> float:
        """The chance ``target`` dodges a sure blow. A sleeper cannot."""
        if "sleep" in target.statuses:
            return 0.0
        over = target.points["evasion"] - StatSettings.BASE_POINTS
        return BattleSettings.EVADE_BASE + BattleSettings.PER_EVASION * over

    @staticmethod
    def _block(target: Combatant) -> float:
        """The chance ``target`` blocks a blow that lands. A sleeper cannot."""
        if "sleep" in target.statuses:
            return 0.0
        over = target.points["vitality"] - StatSettings.BASE_POINTS
        return BattleSettings.BLOCK_BASE + BattleSettings.PER_VITALITY * over

    def _gain(self, combatant: Combatant, amount: int) -> list[Any]:
        """Build ``amount`` mana, up to the cap.

        Stillness blocks it (no mana builds while it holds), and Mana
        Leech (D-723) sends it to whoever leeches instead.
        """
        if not combatant.alive or amount <= 0:
            return []
        if combatant.statuses.get("calm"):
            return [NoteEvent(f"{combatant.name} is stilled and builds no mana.", combatant.id)]
        if combatant.statuses.get("mleech"):
            leech = self._by_id(combatant.cursed_by.get("mleech"))
            if leech is not None and leech.alive and leech is not combatant:
                return [NoteEvent(
                    f"{leech.name} leeches the mana {combatant.name} builds.", leech.id,
                )] + self._gain(leech, amount)
        before = combatant.mana
        combatant.mana = min(BattleSettings.MANA_CAP, before + amount)
        if combatant.mana == before:
            return []
        return [ManaEvent(
            combatant.id, combatant.name, combatant.mana - before, combatant.mana
        )]

    def _pay(self, combatant: Combatant, amount: int) -> list[Any]:
        """Spend ``amount`` mana."""
        before = combatant.mana
        combatant.mana = max(0, before - amount)
        if combatant.mana == before:
            return []
        return [ManaEvent(
            combatant.id, combatant.name, combatant.mana - before, combatant.mana
        )]

    def _fatigue(self, kind: str) -> float:
        """Return the wait the current turn has built (D-328).

        Each stroke its points; "attack" adds nothing more, "defend"
        adds 1 like any other action (Frankie, 10/26), "tech" adds 7 (Frankie, 10/24),
        anything else adds 1.
        """
        points = self._chain["points"] if self._chain else 0
        strokes = points * BattleSettings.STROKE_WAIT
        if kind == "attack":
            return max(BattleSettings.FATIGUE_LEAST, strokes)
        if kind == "defend":
            return max(
                BattleSettings.FATIGUE_DEFEND_LEAST,
                strokes + BattleSettings.FATIGUE_DEFEND,
            )
        if kind == "tech":
            return strokes + BattleSettings.FATIGUE_TECH
        return max(BattleSettings.FATIGUE_LEAST, strokes + BattleSettings.FATIGUE_OTHER)

    def _let_out(self, cook: Combatant) -> list[Any]:
        """Simmer goes off at the top of its holder's turn (Frankie, 10/19).

        Every point of damage held in comes back times the move's
        ``return_multiplier`` as fire, on the chosen enemy, or on a
        random living one if it has fallen.
        """
        foes = [c for c in self.enemies if c.alive]
        chosen = next((c for c in foes if c.id == cook.cooker_target), None)
        target = chosen or (self._rng.choice(foes) if foes else None)
        took, cook.cooker_took = cook.cooker_took, 0
        if target is None or took <= 0:
            return []
        multiplier = self._weakness(Element.AFI, target)
        amount = round(
            took * self._moves["pressure_cooker"]["return_multiplier"] * multiplier
        )
        return self._deal(
            target, amount, Element.AFI, multiplier,
            cause="cooker", attacker_name=cook.name,
        )

    def _guard_for(self, target: Combatant, element: Element | None = None) -> Combatant | None:
        """Return the living ally on ``target``'s side whose guard steps in front of a hit.

        The sentinel kinds always do; the fire sentinels only for fire.
        A self guard (Oven Mitt) never steps in for anyone.
        """
        kinds = _SENTINELS + (_FIRE_SENTINELS if element is Element.AFI else ())
        side = self.party if target.is_party else self.enemies
        for combatant in side:
            if combatant.alive and combatant.guard in kinds:
                return combatant
        return None

    def _weakness(
        self, element: Element | None, target: Combatant
    ) -> float:
        """Return the element multiplier for ``element`` hitting ``target``."""
        if element is None or target.element is None:
            return NEUTRAL_MULTIPLIER
        # A relic adds its element stance's weakness, multiplied (Frankie, 10/24).
        return damage_multiplier(element, target.element) * relic_multiplier(element, target.relic)

    def _jitter(self, amount: float) -> int:
        """Roll ``amount`` within the jitter band and round it."""
        spread = BattleSettings.DAMAGE_JITTER
        roll = 1 - spread + self._rng.random() * 2 * spread
        return int(amount * roll + 0.5)

    def _spend(self, combatant: Combatant, base_wait: float, still: bool = False) -> list[Any]:
        """Push ``combatant``'s counter forward by one action's wait.

        A burn flares first, unless the turn was Defend or ``still`` (lost
        to sleep or a grip). Returns what that did.
        """
        events = self._burn_tick(combatant, still)
        wait = base_wait
        if combatant.haste > 0:
            wait *= BattleSettings.HASTE_WAIT_MULTIPLIER
            combatant.haste -= 1
        # Angry, the Great Boar acts faster (Frankie, 10/28).
        if combatant.angry and combatant.angry_rule:
            wait *= combatant.angry_rule.get("wait", 1)
        combatant.counter += wait * defense_scale(combatant.points["speed"])
        return events

    def _find(self, pool: list[Combatant], combatant_id: str) -> Combatant:
        """Return the combatant with ``combatant_id`` from ``pool``."""
        for combatant in pool:
            if combatant.id == combatant_id:
                return combatant
        raise KeyError(combatant_id)

    def _require_player_actor(self) -> Combatant:
        """Return the party member whose turn is waiting on input."""
        if not self._awaiting_command or self._current_actor is None:
            raise RuntimeError("No party command is awaiting input")
        return self._current_actor

    def _finish_tech(self, events: list[Any]) -> list[Any]:
        """Close a Skill's turn: it builds 1 mana and waits 7 (Frankie, 10/24)."""
        events.extend(self._gain(self._current_actor, BattleSettings.TECH_MANA))
        return self._finish_player_turn(events, "tech")

    def _finish_player_turn(self, events: list[Any], kind: str) -> list[Any]:
        """Charge the turn's fatigue and close it.

        ``kind`` is "attack", "defend", "tech", "move" or "item" (``_fatigue``).
        """
        events.extend(self._spend(self._current_actor, self._fatigue(kind)))
        self._chain = None
        self._awaiting_command = False
        events.extend(self._check_terminal())
        return events

    def _check_terminal(self) -> list[Any]:
        """End the battle if either side has nobody standing."""
        if not any(c.alive for c in self.enemies):
            return self._end("victory")
        # Tawiri's spirit does not hold the fight up when the party is down.
        if not any(c.alive and not c.summon_turns for c in self.party):
            return self._end("defeat")
        return []

    def _end(self, outcome: str) -> list[Any]:
        """Record ``outcome`` once and report it."""
        if self._ended:
            return []
        self._ended = True
        self._outcome = outcome
        return [BattleEndedEvent(outcome)]
