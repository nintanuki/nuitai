"""Ability slots: which techniques a character takes into a fight, and in which row.

The browser battle's slot system (D-318 to D-320, built there as D-327,
here on 2026-10-17): every character has three slots in each mana row,
1 to 7, shared by both stances. A technique sits in its own row (its
``warmup``) or, if it has an ``upcast`` field, in any higher row, which
grows it: damage and healing by row over home row, so Heal in row 4
heals four times what it heals in row 1; turns by 1 a row. It costs the
row it sits in. Whatever is not slotted waits in the bank. The numbers
are the shared file's ``rules.slots``.

A loadout is a plain dict, move id -> row, so it saves as JSON as it is.
"""

from __future__ import annotations

from typing import Any, Iterable

from settings import BattleSettings, LoadoutSettings


# The order the browser lists elements in, for sorting the first loadout.
_ELEMENT_ORDER: tuple[str, ...] = ("ahi", "wai", "lau", "la", "ata", "mana")


def knows(move: dict[str, Any], member_id: str, element_ids: Iterable[str]) -> bool:
    """Return True when the character knows ``move``, in either stance.

    A move with an ``owner`` belongs to that one character. A move with
    ``needs`` (a kick or blast in a character's other element, 10/8)
    goes to whoever carries every element it names. Any other move goes
    to everyone carrying its element, unless they are in its ``except``
    list. Anyone in its ``also`` list knows it as well. A move marked
    ``off`` or ``browser_only`` is not built in this game.
    """
    if move.get("off") or move.get("browser_only"):
        return False
    element_ids = list(element_ids)
    if "owner" in move:
        usable = move["owner"] == member_id
    elif "needs" in move:
        usable = all(e in element_ids for e in move["needs"])
    else:
        usable = (
            move["element"] in element_ids
            and member_id not in move.get("except", ())
        )
    return usable or member_id in move.get("also", ())


def home_row(move: dict[str, Any]) -> int:
    """Return the row a technique belongs in: its ``warmup``, 1 to 7."""
    return min(BattleSettings.MANA_CAP, max(1, int(move.get("warmup") or 1)))


def reach(move: dict[str, Any]) -> list[int]:
    """Return the rows ``move`` may sit in: its own, and higher if it grows."""
    home = home_row(move)
    if move.get("upcast"):
        return list(range(home, LoadoutSettings.ROWS + 1))
    return [home]


def grown(move: dict[str, Any], row: int) -> dict[str, Any]:
    """Return ``move`` as it plays from ``row`` (D-319).

    "power" grows by row over home row; "turns" adds one turn a row
    above home, carried as ``extra_turns``; "gift" (Nectar) one more
    mana a row. Anything else is unchanged.
    """
    home = home_row(move)
    extra = row - home
    if extra <= 0 or not move.get("upcast"):
        return move
    if move["upcast"] == "power" and move.get("power"):
        return {**move, "power": move["power"] * row / home}
    if move["upcast"] == "turns":
        return {**move, "extra_turns": extra * LoadoutSettings.TURNS_PER_ROW}
    if move["upcast"] == "gift":
        return {**move, "gift": move.get("gift", 1) + extra * LoadoutSettings.GIFT_PER_ROW}
    return move


def _spare(move: dict[str, Any]) -> int:
    """How readily a move waits in the bank when its row is full (Frankie, 10/15).

    Healing never; a single cure first, since Cure All covers it.
    """
    if move.get("effect") == "cure":
        return 0
    name = move["name"]
    if name.startswith("Cure ") and name != "Cure All":
        return 2
    return 1


def default_loadout(known: list[dict[str, Any]]) -> dict[str, int]:
    """Return the first loadout, as the browser makes it.

    Each technique goes in its own row, moved up if it can grow and the
    row is full. Those that fit only one row go first, so the ones that
    can grow make room and nothing starts in the bank (Frankie, 10/15).
    """
    def key(move: dict[str, Any]) -> tuple:
        element = move.get("element")
        order = _ELEMENT_ORDER.index(element) if element in _ELEMENT_ORDER else 0
        return (
            len(reach(move)), _spare(move), home_row(move),
            move.get("tier") == "element", order, move["name"],
        )

    loadout: dict[str, int] = {}
    count: dict[int, int] = {}
    for move in sorted(known, key=key):
        for row in reach(move):
            if count.get(row, 0) < LoadoutSettings.PER_ROW:
                loadout[move["id"]] = row
                count[row] = count.get(row, 0) + 1
                break
    return loadout


def checked(loadout: dict[str, int] | None, known: list[dict[str, Any]]) -> dict[str, int]:
    """Return ``loadout`` with anything no longer known or in reach dropped to the bank.

    None, a character who has never had one, gets the first loadout.
    """
    if loadout is None:
        return default_loadout(known)
    by_id = {move["id"]: move for move in known}
    kept: dict[str, int] = {}
    count: dict[int, int] = {}
    for move_id, row in loadout.items():
        move = by_id.get(move_id)
        if move is None or row not in reach(move):
            continue
        if count.get(row, 0) >= LoadoutSettings.PER_ROW:
            continue
        kept[move_id] = row
        count[row] = count.get(row, 0) + 1
    return kept


def place(loadout: dict[str, int], move: dict[str, Any], row: int | None,
          others: dict[str, dict[str, Any]]) -> dict[str, int]:
    """Return a new loadout with ``move`` put in ``row``, or banked when ``row`` is None.

    A full row swaps: the last move in it goes where ``move`` came from
    if it can sit there, and to the bank if not.
    """
    result = dict(loadout)
    came_from = result.pop(move["id"], None)
    if row is None:
        return result
    if row not in reach(move):
        return loadout
    in_row = [mid for mid, r in result.items() if r == row]
    if len(in_row) >= LoadoutSettings.PER_ROW:
        bumped = in_row[-1]
        del result[bumped]
        if came_from is not None and came_from in reach(others[bumped]):
            result[bumped] = came_from
    result[move["id"]] = row
    return result
