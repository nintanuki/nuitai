"""Config: the player's settings, as Final Fantasy VI's Config keeps them (Frankie, 10/26).

Five settings, each a row on the Config screen (``core/scenes/config_scene.py``):

* **Cursor**, Reset or Memory: each character's battle commands open on
  Attack every turn, or where that character left them.
* **Message speed**, Slow, Normal, Fast or Instant: how fast the usual text
  types. A scene's own fast and quick lines slow down with Slow but never
  type quicker than written, so a line that is cut off is still seen
  typing before it is cut off; the opening's slow first line keeps its own
  pace, timed to the beach fading in.
* **Window color**, red, green and blue in the console's 32 steps each
  (0 to 31, 15 bit color): the top of every window's gradient, its bottom
  shaded down from it as the default is. A color bright enough to wash out
  the white text is dimmed when drawn (``window_colors``), the sliders
  keeping what was set.
* **Sound**, Stereo or Mono: mono mixes both channels to the middle,
  music and sound effects alike (``AudioManager.set_mono``).
* **Buttons**: A swapped with B (confirm with cancel), X with Y, on the
  keyboard and the pad alike (``ui/input_map.py``).

``current`` is the one in use. It goes in the save, and the last one set
is kept beside the saves too, so the title screen has it before a save is
loaded (``core/save.py``).
"""

from __future__ import annotations

from typing import Any

from settings import UISettings

CURSORS = ("Reset", "Memory")
SPEEDS = ("Slow", "Normal", "Fast", "Instant")
SOUNDS = ("Stereo", "Mono")
# How many times the usual speed each message speed types; None is at once.
SPEED_TIMES: dict[str, float | None] = {"Slow": 0.5, "Normal": 1.0, "Fast": 2.0, "Instant": None}
# A scene's own fast or quick line types no quicker than written, so it is seen.
OWN_SPEED_MOST = 1.0

STEPS = 32  # The console's steps for each of red, green and blue.
# The default window's top and bottom (``UISettings``) in 15 bit color.
WINDOW_DEFAULT = tuple(c >> 3 for c in UISettings.WINDOW_TOP)
_BOTTOM_DEFAULT = tuple(c >> 3 for c in UISettings.WINDOW_BOTTOM)
# The brightest a window's top may be drawn, as relative luminance: white
# text on it keeps at least 7 to 1 contrast, (1.05 / 7) - 0.05.
_MOST_LUMINANCE = 0.10


class Config:
    """The settings, their defaults, and how they save."""

    def __init__(self) -> None:
        self.cursor = "Reset"
        self.message_speed = "Normal"
        self.window = WINDOW_DEFAULT
        self.sound = "Stereo"
        self.swap_ab = False
        self.swap_xy = False
        # With Memory, where each character left their commands this
        # session: their id to (page, row). Not saved.
        self.cursors: dict[str, tuple[int, int]] = {}

    def to_dict(self) -> dict[str, Any]:
        """The settings as the save keeps them."""
        return {
            "cursor": self.cursor,
            "message_speed": self.message_speed,
            "window": list(self.window),
            "sound": self.sound,
            "swap_ab": self.swap_ab,
            "swap_xy": self.swap_xy,
        }

    def load(self, data: dict[str, Any] | None) -> None:
        """Take the settings in ``data``; anything missing or unknown keeps its default."""
        fresh = Config()
        data = data if isinstance(data, dict) else {}
        self.cursor = data.get("cursor") if data.get("cursor") in CURSORS else fresh.cursor
        speed = data.get("message_speed")
        self.message_speed = speed if speed in SPEEDS else fresh.message_speed
        self.window = fresh.window
        window = data.get("window")
        if isinstance(window, (list, tuple)) and len(window) == 3:
            try:
                self.window = tuple(max(0, min(STEPS - 1, int(c))) for c in window)
            except (TypeError, ValueError):
                pass
        self.sound = data.get("sound") if data.get("sound") in SOUNDS else fresh.sound
        self.swap_ab = bool(data.get("swap_ab", False))
        self.swap_xy = bool(data.get("swap_xy", False))
        self.cursors = {}

    # ------------------------------------------------------------------
    # MESSAGE SPEED
    # ------------------------------------------------------------------

    def text_times(self, own: bool = False) -> float | None:
        """How many times its speed a line types; None for at once.

        ``own`` is a scene's own fast or quick line, which types no
        quicker than ``OWN_SPEED_MOST`` times, so it is always seen.
        """
        times = SPEED_TIMES[self.message_speed]
        if own:
            return OWN_SPEED_MOST if times is None else min(times, OWN_SPEED_MOST)
        return times


def to_8bit(step: int) -> int:
    """One of the console's 32 steps as 0 to 255, as an emulator shows it."""
    return (step << 3) | (step >> 2)


def _luminance(color: tuple[int, int, int]) -> float:
    """Relative luminance of an 8 bit color, as WCAG counts it."""
    def channel(c: int) -> float:
        c = c / 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (channel(c) for c in color)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def readable(window: tuple[int, int, int]) -> tuple[int, int, int]:
    """``window`` dimmed, all three alike, until white text reads on it; unchanged if it already does."""
    shown = tuple(window)
    scale = 1.0
    while _luminance(tuple(to_8bit(c) for c in shown)) > _MOST_LUMINANCE and scale > 0:
        scale -= 1 / STEPS
        shown = tuple(int(c * scale) for c in window)
    return shown


def window_colors(window: tuple[int, int, int] | None = None) -> tuple[tuple[int, int, int], tuple[int, int, int]]:
    """A window's top and bottom gradient colors, 8 bit, for ``window`` (the current one if None).

    The bottom is the top shaded down channel by channel as the default
    is shaded, so a tinted window keeps the same gradient. The default
    is drawn in ``UISettings``' own colors, as before Config.
    """
    top = readable(current.window if window is None else window)
    if top == WINDOW_DEFAULT:
        return UISettings.WINDOW_TOP, UISettings.WINDOW_BOTTOM
    bottom = tuple(round(c * low / high) for c, low, high in zip(top, _BOTTOM_DEFAULT, WINDOW_DEFAULT))
    return tuple(to_8bit(c) for c in top), tuple(to_8bit(c) for c in bottom)


def apply(gm) -> None:
    """Put ``current`` into effect where it is not read as it is needed: the sound."""
    audio = getattr(gm, "audio", None)
    if audio is not None:
        audio.set_mono(current.sound == "Mono")


def changed(gm) -> None:
    """``current`` was just changed on the Config screen: put it into effect and keep it for the title."""
    from core import save  # local: save reads settings, which this reads.

    apply(gm)
    save.write_settings(current.to_dict())


def boot(gm) -> None:
    """At start: the settings last set, before any save is loaded."""
    from core import save  # local: as above.

    current.load(save.read_settings())
    apply(gm)


def from_save(gm, data: dict[str, Any] | None) -> None:
    """A save loaded: its settings, or, from a save older than Config, the ones in use already."""
    if isinstance(data, dict) and "config" in data:
        current.load(data["config"])
        changed(gm)
    current.cursors = {}


current = Config()
