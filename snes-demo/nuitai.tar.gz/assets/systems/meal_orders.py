"""Kailo gets paid to cook (Frankie, 10/28): villagers ask for a meal and buy it.

Random villagers ask Kailo for a random meal and buy it from him, one more
way to earn the boat's pule. No shop buys or sells meals, so they come only
from his pot. How it plays is Claude's plainest reading:

* One order is open at a time, kept in the party flag ``meal_order`` as
  ``"<who>|<meal>"``, ``who`` naming the villager by room and place in the
  room's file, so it lasts across rooms and saves.
* With none open, talking to a villager who can order (``OrderSettings.SPEAKERS``,
  not a sparring one) by day, once they have said a line of their own, one
  time in ``OrderSettings.CHANCE`` they ask for one of the meals in the
  shared file's ``cooking`` instead of their next line, which waits its turn.
* Talking to them again with the meal in the bag, they take it and pay its
  price (``OrderSettings.PRICES``); without it, they remind him.
"""

from __future__ import annotations

import random

from core.shared import SHARED
from settings import ItemSettings, OrderSettings

FLAG = "meal_order"


def meals() -> list[str]:
    """Every meal a villager can ask for: the dishes Kailo cooks."""
    return [dish["id"] for dish in SHARED["cooking"]["dishes"]]


def can_order(person: dict) -> bool:
    """Whether ``person`` is a villager who may ask for a meal: one of ``OrderSettings.SPEAKERS``,
    not sparring, who has said a line already, so the first talk is always their own."""
    return (person.get("speaker") in OrderSettings.SPEAKERS and not person.get("spar")
            and bool(person.get("lines")) and any(person.get("turn", {}).values()))


def open_order(party) -> tuple[str, str] | None:
    """The open order as (who, meal), or None."""
    value = party.flags.get(FLAG)
    if not isinstance(value, str) or "|" not in value:
        return None
    who, meal = value.rsplit("|", 1)
    return who, meal


def name(meal: str) -> str:
    return ItemSettings.NAMES.get(meal, meal)


def talk(party, who: str, person: dict, rng: random.Random | None = None) -> list[tuple[bool, str]] | None:
    """What is said about a meal when ``person`` (called ``who``) is talked to, or None
    for their own line: each line with whether the villager says it (else no one does).

    Places a new order now and then, or settles theirs: the meal leaves
    the bag and its price goes in the purse.
    """
    order = open_order(party)
    if order is not None:
        if order[0] != who:
            return None
        meal = order[1]
        if party.inventory.get(meal, 0) < 1:
            return [(True, OrderSettings.WAITING_LINE.format(meal=name(meal)))]
        party.inventory[meal] -= 1
        if party.inventory[meal] <= 0:
            del party.inventory[meal]
        price = OrderSettings.PRICES[meal]
        party.pule += price
        del party.flags[FLAG]
        return [(True, OrderSettings.THANKS_LINE), (False, OrderSettings.SOLD_LINE.format(meal=name(meal), price=price))]
    if not can_order(person):
        return None
    rng = rng or random
    if rng.random() >= OrderSettings.CHANCE:
        return None
    meal = rng.choice(meals())
    party.flags[FLAG] = f"{who}|{meal}"
    return [(True, OrderSettings.ASK_LINE.format(meal=name(meal), price=OrderSettings.PRICES[meal]))]
