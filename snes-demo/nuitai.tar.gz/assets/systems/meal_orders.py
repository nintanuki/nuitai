"""Kailo gets paid to cook (Frankie, 10/28 and 11/1): cravings and the Meialana's orders.

Two ways a named villager (``OrderSettings.NAMED``) turns a dish into pule or
a gift. No shop buys or sells meals, so they come only from Kailo's pot.
How they play is Claude's plainest reading:

* **Cravings.** Talking to a named villager by day, with no craving open, one time
  in ``OrderSettings.CHANCE`` they hint at the end of their usual line that they
  are in the mood for a dish (the party flag ``craving``, ``"<who>|<dish>"``).
  Talking to them again with the dish in the bag, they ask for it at the end of their
  line; yes, and they give a random gift (``gift``), the harder the dish the better.
  Then the craving is over and another may come to anyone, never the same dish twice
  in a row.
* **Orders.** The Meialana gets orders (the flag ``boat_orders``, up to
  ``OrderSettings.MAX_ORDERS`` as ``"<who>|<dish>;..."``): when Kailo goes up to it, a
  new one may have come, one time in ``ORDER_CHANCE`` for each ``ORDER_STEPS``
  steps walked since the last. "Check orders" lists who ordered what; delivering
  takes the dish from the bag and pays its price (``pay``).
* **How hard a dish is** is its ingredients' effort added up (``effort``), and the
  pay and the gift's tier go by it.
"""

from __future__ import annotations

import json
import os
import random

from settings import ItemSettings, OrderSettings, ShopSettings
from systems import diet, garden, sailing

CRAVING = "craving"
LAST = "craving_last"
ORDERS = "boat_orders"
ORDERS_AT = "boat_orders_at"

_POT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "crafting", "pot.json")
_RECIPES: dict[str, list[str]] = {}


def _recipes() -> dict[str, list[str]]:
    if not _RECIPES:
        with open(_POT, encoding="utf-8") as f:
            _RECIPES.update({r["id"]: r["from"] for r in json.load(f)["recipes"]})
    return _RECIPES


def effort(item: str) -> int:
    """How hard ``item`` is to get or make: a raw ingredient's own effort, a dish's
    parts added up plus ``POT_STEP`` for the pot."""
    recipe = _recipes().get(item)
    if recipe is None:
        return OrderSettings.EFFORT.get(item, 0)
    return sum(effort(part) for part in recipe) + OrderSettings.POT_STEP


def meals() -> list[str]:
    """Every dish a villager can want: the pot's dishes, not the noodles and broth that go into them."""
    dishes = {"poi", "saimin", *ItemSettings.POT_DISHES, *ItemSettings.SALT_DISHES}
    return [meal for meal in _recipes() if meal in dishes]


def pay(meal: str) -> int:
    """What ``meal`` pays at the boat, and what a craving's pule gift is worth: by effort."""
    step = OrderSettings.PAY_ROUND
    return max(step, round(effort(meal) / OrderSettings.PAY_PER / step) * step)


def tier(meal: str) -> int:
    """1, 2 or 3: how good a gift the dish earns."""
    hard = effort(meal)
    return 1 + sum(hard >= edge for edge in OrderSettings.TIERS)


def name(meal: str) -> str:
    return ItemSettings.NAMES.get(meal, meal)


def _take(party, meal: str) -> bool:
    """Take one ``meal`` from the bag; whether there was one."""
    if party.inventory.get(meal, 0) < 1:
        return False
    party.inventory[meal] -= 1
    if party.inventory[meal] <= 0:
        del party.inventory[meal]
    return True


def _pair(value) -> tuple[str, str] | None:
    if not isinstance(value, str) or "|" not in value:
        return None
    who, meal = value.rsplit("|", 1)
    return who, meal


# --- Cravings ---------------------------------------------------------------

def can_crave(person: dict) -> bool:
    """Whether ``person`` may crave a dish: named, not the boat's Ama, not sparring, with lines."""
    return (person.get("speaker") in OrderSettings.NAMED and not person.get("boat") and not person.get("spar")
            and bool(person.get("lines")))


def craving(party) -> tuple[str, str] | None:
    """The open craving as (who, dish), or None."""
    return _pair(party.flags.get(CRAVING))


def talk(party, person: dict, rng: random.Random | None = None) -> tuple[str, str] | None:
    """Called after ``person``'s usual line: ("hint", dish) when they are in the mood and
    Kailo has none on him, ("ask", dish) when he has it, else None.

    Places a new craving now and then when none is open.
    """
    rng = rng or random
    who = person.get("speaker")
    open_one = craving(party)
    if open_one is None:
        if not can_crave(person) or rng.random() >= OrderSettings.CHANCE:
            return None
        last = _pair(party.flags.get(LAST))
        pool = [meal for meal in meals() if (not last or meal != last[1]) and not diet.refuses(who, meal)]
        open_one = (who, rng.choice(pool))
        party.flags[CRAVING] = f"{open_one[0]}|{open_one[1]}"
    if open_one[0] != who:
        return None
    return ("ask" if party.inventory.get(open_one[1], 0) > 0 else "hint"), open_one[1]


def gift(party, meal: str, rng: random.Random | None = None) -> str:
    """Give the gift for ``meal``, taken from the bag: pule half the time (its pay), else one
    thing from its tier's pool. Returns what Kailo received, in words."""
    rng = rng or random
    _take(party, meal)
    party.flags[LAST] = party.flags.pop(CRAVING)
    if rng.random() < OrderSettings.PULE_CHANCE:
        amount = min(pay(meal), ShopSettings.PULE_MAX - party.pule)
        if amount > 0:
            party.pule += amount
            return f"{amount} pule"
    item = rng.choice(OrderSettings.GIFTS[tier(meal)])
    count = OrderSettings.SEED_COUNT if item.endswith("_seed") else 1
    party.inventory[item] = party.inventory.get(item, 0) + count
    return name(item) if count == 1 else f"{count} {name(item)}"


# --- The boat's orders ------------------------------------------------------

def customers(party) -> list[str]:
    """Who can order now: the named, Kupulau's once the town is on Kailo's map."""
    people = list(OrderSettings.NAMED)
    if sailing.known(party, "Kupulau"):
        people += OrderSettings.KUPULAU_NAMED
    return people


def orders(party) -> list[tuple[str, str]]:
    """The open orders as (who, dish), oldest first."""
    value = party.flags.get(ORDERS)
    if not isinstance(value, str):
        return []
    return [pair for pair in map(_pair, value.split(";")) if pair]


def _store(party, found: list[tuple[str, str]]) -> None:
    if found:
        party.flags[ORDERS] = ";".join(f"{who}|{meal}" for who, meal in found)
    else:
        party.flags.pop(ORDERS, None)


def roll_orders(party, rng: random.Random | None = None) -> None:
    """Kailo goes up to the boat: once ``ORDER_STEPS`` steps have been walked since the
    last time, a new order may have come, from someone with none open."""
    rng = rng or random
    now = garden.steps(party)
    last = party.flags.get(ORDERS_AT)
    if last is not None and now - last < OrderSettings.ORDER_STEPS:
        return
    party.flags[ORDERS_AT] = now
    found = orders(party)
    if len(found) >= OrderSettings.MAX_ORDERS or rng.random() >= OrderSettings.ORDER_CHANCE:
        return
    busy = {who for who, _ in found}
    asking = craving(party)
    if asking:
        busy.add(asking[0])
    free = [who for who in customers(party) if who not in busy]
    if free:
        who = rng.choice(free)
        found.append((who, rng.choice([meal for meal in meals() if not diet.refuses(who, meal)])))
        _store(party, found)


def deliver(party, index: int) -> str | None:
    """Deliver order ``index``: the dish leaves the bag and its pay goes in the purse.
    Returns the pule paid, or None when the bag has no such dish."""
    found = orders(party)
    who, meal = found[index]
    if not _take(party, meal):
        return None
    del found[index]
    _store(party, found)
    price = min(pay(meal), ShopSettings.PULE_MAX - party.pule)
    party.pule += price
    return price
