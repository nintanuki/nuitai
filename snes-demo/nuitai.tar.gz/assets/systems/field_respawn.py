"""When a beaten monster on the map comes back (Frankie, 10/28).

A beaten monster stays gone until the party has walked
``FieldMonsterSettings.RESPAWN_STEPS`` steps since it was beaten; a nap in
Kailo's bed or a drink from a spring brings every one back at once. Bosses
are not counted here: they are gone for good (``field_boss:`` flags).

Each beaten monster is a party flag, ``field_beaten:<room>:<index>``, the
step count (``garden.steps``) when it was beaten, so it saves with the
rest. ``<index>`` is the spot's place in the room's list of monsters, the
same for the generated woods, which are built again from the saved seed.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from settings import FieldMonsterSettings
from systems import garden

if TYPE_CHECKING:
    from systems.party import Party

PREFIX = "field_beaten:"


def _key(cell_name: str, index: int) -> str:
    return f"{PREFIX}{cell_name}:{index}"


def beat(party: "Party", cell_name: str, index: int) -> None:
    """Stamp the monster at spot ``index`` of ``cell_name`` as beaten now."""
    party.flags[_key(cell_name, index)] = garden.steps(party)


def is_gone(party: "Party", cell_name: str, index: int) -> bool:
    """Whether that monster is still away; once its steps are walked, its stamp is dropped."""
    key = _key(cell_name, index)
    stamp = party.flags.get(key)
    if stamp is None:
        return False
    if garden.steps(party) - stamp >= FieldMonsterSettings.RESPAWN_STEPS:
        del party.flags[key]
        return False
    return True


def bring_back_all(party: "Party") -> None:
    """A nap or a spring: every beaten monster comes back."""
    for key in [k for k in party.flags if k.startswith(PREFIX)]:
        del party.flags[key]
