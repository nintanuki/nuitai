"""Digging with Pono's 'O'o (Frankie, 10/27 and 10/30; ``data/crafting/dig.json``).

Facing soft ground (sand, never grass) with the 'O'o set to Y, a tap digs.
A few spots always give 'awapuhi, wild ginger, once each: the stew's buried
ingredient, a sure find so it never depends on luck. Anywhere else a dig turns
up nothing (25%), an item from the monster drop pool plus 'awapuhi (10%) or
some pule, small mostly (65%) (Frankie, 10/30). In the village someone yells at him instead. A spot dug is the
party flag ``dig:<room>:<col>:<row>``, so it saves with the rest.
"""

from __future__ import annotations

import json
import os
import random
from typing import TYPE_CHECKING

from settings import DigSettings, ItemSettings, StewSettings

if TYPE_CHECKING:
    from systems.party import Party

_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                     "data", "crafting", "dig.json")
with open(_PATH, encoding="utf-8") as _f:
    DIG: dict = json.load(_f)


def _key(room: str, col: int, row: int) -> str:
    return f"dig:{room}:{col}:{row}"


def is_spot(room: str, col: int, row: int) -> bool:
    """Whether the tile is one of the buried 'awapuhi spots."""
    return [col, row] in DIG["spots"].get(room, [])


def item_pool() -> dict[str, float]:
    """What an item dig can turn up: the monster drop pool, each kind weighted as a monster's
    chance for it, plus the buried 'awapuhi (Frankie, 10/30)."""
    pool: dict[str, float] = {DigSettings.BURIED: DigSettings.BURIED_WEIGHT}
    for item, weight in ItemSettings.EVERYDAY.items():
        pool[item] = ItemSettings.EVERYDAY_CHANCE * weight / sum(ItemSettings.EVERYDAY.values())
    for item in ItemSettings.SEEDS:
        pool[item] = ItemSettings.SEED_CHANCE / len(ItemSettings.SEEDS)
    for item in ItemSettings.INGREDIENT_DROPS:
        pool[item] = ItemSettings.INGREDIENT_CHANCE / len(ItemSettings.INGREDIENT_DROPS)
    for item in ItemSettings.EQUIP_DROPS:
        pool[item] = ItemSettings.EQUIP_CHANCE / len(ItemSettings.EQUIP_DROPS)
    return pool


def roll_pule(rng: random.Random) -> int:
    """Pule from a dig: mostly a few, now and then many."""
    return min(DigSettings.PULE_MAX, 1 + int(rng.expovariate(1 / DigSettings.PULE_MEAN)))


def found_important(party: "Party", had: int) -> bool:
    """Whether the dig just made earns the "found something important" jingle (Frankie, 10/30):
    'awapuhi came up, and it is the first time ever, or the stew still needs it and the bag
    had none (eaten or sold). ``had`` is how many the bag held before the dig."""
    if party.inventory.get(DigSettings.BURIED, 0) <= had:
        return False
    if not party.flags.get(DigSettings.FOUND_FLAG):
        party.flags[DigSettings.FOUND_FLAG] = True
        return True
    from systems import stew  # local: stew imports settings only, but keep the systems loose.
    return had == 0 and stew.active(party) and DigSettings.BURIED in StewSettings.NEEDS


def _give(party: "Party", item: str, count: int = 1) -> None:
    party.inventory[item] = party.inventory.get(item, 0) + count


def dig(party: "Party", room: str, col: int, row: int, rng: random.Random | None = None) -> tuple[str, bool]:
    """Dig the tile: what is said, and whether something came up."""
    rng = rng or random
    if is_spot(room, col, row) and not party.flags.get(_key(room, col, row)):
        party.flags[_key(room, col, row)] = True
        _give(party, DigSettings.BURIED)
        return DigSettings.FOUND_LINE.format(item=ItemSettings.NAMES[DigSettings.BURIED]), True
    # Anywhere else (Frankie, 10/30): nothing, an item or some pule, by the settings' chances.
    roll = rng.random()
    if roll < DigSettings.NOTHING_CHANCE:
        return DigSettings.NOTHING_LINE, False
    if roll < DigSettings.NOTHING_CHANCE + DigSettings.ITEM_CHANCE:
        pool = item_pool()
        pick = rng.choices(list(pool), weights=list(pool.values()))[0]
        _give(party, pick)
        return DigSettings.FOUND_LINE.format(item=ItemSettings.NAMES.get(pick, pick)), True
    pule = roll_pule(rng)
    party.pule += pule
    return DigSettings.FOUND_LINE.format(item=f"{pule} pule"), True
