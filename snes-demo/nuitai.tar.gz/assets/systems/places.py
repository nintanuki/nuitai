"""The places the field pop-up names (Frankie, 10/25).

Kulāiwi Village, the town's rooms and every house in them, and Kulāiwi Forest,
the woods north of it; and on the first Lanuloa island (Frankie, 11/1) Kupulau,
its harbor, farm and every house, and Kupulau Forest. A room in none has no
name and shows nothing.
"""

from __future__ import annotations

from core.overworld_cells import BUILDINGS, WORLD_LAYOUT
from settings import AudioSettings, PlaceSettings

# The town's houses, as the town's song reads them (overworld_scene._room_sound).
HOUSES = {b["inside"] for room in AudioSettings.BEACH_ROOMS for b in BUILDINGS.get(room, []) if b.get("inside")}
HOME = "kailo_house"
# Kupulau's town rooms; its forest is the painted forest and the woods grown off it.
KUPULAU_ROOMS = ("kupulau_harbor", "kupulau_farm")
KUPULAU_HOUSES = {b["inside"] for room in KUPULAU_ROOMS for b in BUILDINGS.get(room, []) if b.get("inside")}
KUPULAU_FOREST = "kupulau_forest"


def name_of(room: str) -> str | None:
    """What the pop-up says on walking into ``room``: its own name if it has one (a house),
    else its place (Frankie, 11/1)."""
    return PlaceSettings.ROOMS.get(room) or place_of(room)


def place_of(room: str) -> str | None:
    """The place ``room`` is in, or None."""
    if room in AudioSettings.BEACH_ROOMS or room in HOUSES:
        return PlaceSettings.VILLAGE
    if room in KUPULAU_ROOMS or room in KUPULAU_HOUSES:
        return PlaceSettings.KUPULAU
    if room == KUPULAU_FOREST or room.startswith("kupulau_woods"):
        return PlaceSettings.KUPULAU_FOREST
    pos = next((pos for pos, name in WORLD_LAYOUT.items() if name == room), None)
    # The woods are every room north of the beach.
    if pos is not None and pos[1] < 0:
        return PlaceSettings.FOREST
    return None
