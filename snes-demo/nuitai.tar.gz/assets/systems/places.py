"""The places the field pop-up names (Frankie, 10/25).

For now two: Kulāiwi Village, the town's rooms and every house in them,
and Kulāiwi Forest, the woods north of it. A room in neither has no name
and shows nothing.
"""

from __future__ import annotations

from core.overworld_cells import BUILDINGS, WORLD_LAYOUT
from settings import AudioSettings, PlaceSettings

# The town's houses, as the town's song reads them (overworld_scene._room_sound).
HOUSES = {b["inside"] for room in AudioSettings.BEACH_ROOMS for b in BUILDINGS.get(room, []) if b.get("inside")}
HOME = "kailo_house"


def place_of(room: str) -> str | None:
    """The place ``room`` is in, or None."""
    if room in AudioSettings.BEACH_ROOMS or room in HOUSES:
        return PlaceSettings.VILLAGE
    pos = next((pos for pos, name in WORLD_LAYOUT.items() if name == room), None)
    # The woods are every room north of the beach.
    if pos is not None and pos[1] < 0:
        return PlaceSettings.FOREST
    return None
