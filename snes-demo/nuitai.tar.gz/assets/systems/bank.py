"""Noelani holds pule for Kailo (Frankie, 11/1), as the hero's mom keeps money in Pokemon.

What she holds is the party flag ``bank``, so it saves with the rest. The purse holds only
``ShopSettings.PULE_MAX``; what she holds has no limit.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from systems.party import Party

FLAG = "bank"
OFFERED_FLAG = "bank_offered"   # she has said she will keep what he does not need
ASKED_FLAG = "bank_asked"       # he has asked her about it once


def held(party: "Party") -> int:
    """The pule Noelani holds."""
    return int(party.flags.get(FLAG, 0))


def leave(party: "Party", amount: int | None) -> int:
    """Leave ``amount`` pule with her (None for all of it), never more than the purse has; returns what was left."""
    amount = party.pule if amount is None else min(amount, party.pule)
    party.pule -= amount
    party.flags[FLAG] = held(party) + amount
    return amount


def take(party: "Party", amount: int | None) -> int:
    """Take ``amount`` pule back (None for as much as the purse holds); returns what was taken."""
    from settings import ShopSettings

    room = ShopSettings.PULE_MAX - party.pule
    amount = room if amount is None else amount
    amount = max(0, min(amount, held(party), room))
    party.flags[FLAG] = held(party) - amount
    party.pule += amount
    return amount
