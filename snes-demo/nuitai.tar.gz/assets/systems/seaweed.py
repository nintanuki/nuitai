"""Seaweed on the beach (Frankie, 10/29): broth is seaweed and water, and seaweed
turns up now and then on the shore.

Pressing confirm facing the sea in a salt room looks along the shoreline. When
the beach has been picked over for ``SeaweedSettings.WAIT_STEPS`` steps, there is
a ``CHANCE`` of finding some; a find starts the wait over. Both numbers are
Claude's. The wait is the party flag ``seaweed_ready``, the step count (the
garden's, ``garden.steps``) at which the shore can give again; missing is ready.

Fishing is not built yet; when it is, it will also give seaweed by chance.
"""

from __future__ import annotations

import random
from typing import TYPE_CHECKING

from settings import ItemSettings, SeaweedSettings
from systems import garden

if TYPE_CHECKING:
    from systems.party import Party

READY_FLAG = "seaweed_ready"


def ready(party: "Party") -> bool:
    """Whether the shore can give seaweed again."""
    return garden.steps(party) >= int(party.flags.get(READY_FLAG, 0))


def search(party: "Party", rng: random.Random | None = None) -> str:
    """Pressing confirm facing the sea: seaweed in the bag, maybe; what is said."""
    roll = (rng or random).random()
    if not ready(party) or roll >= SeaweedSettings.CHANCE:
        return SeaweedSettings.NOTHING_LINE
    party.inventory[ItemSettings.SEAWEED] = party.inventory.get(ItemSettings.SEAWEED, 0) + SeaweedSettings.COUNT
    party.flags[READY_FLAG] = garden.steps(party) + SeaweedSettings.WAIT_STEPS
    return SeaweedSettings.FOUND_LINE
