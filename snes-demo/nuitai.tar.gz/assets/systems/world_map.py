"""The world map's picture (Frankie, 10/28; the scene is ``core/scenes/map_scene.py``).

The picture map of Nuitai (``tools/mapgen/artmap.py``) at one pixel per
tile, 180 by 180, no words on it at all, made by ``tools/mapgen/worldpic.py``
into ``assets/graphics/world_map.png``; the same tool writes the named spots
on it into ``data/world_map.json``. Kailo's dot goes on his area's spot:
the area a room is in (``area_of``, the whole demo Māla Iki), then that
area's spot (``MapSettings.WORLD_SPOTS``), then its pixel from the json.
A later area adds its line to ``WORLD_SPOTS`` and, if artmap has no spot
for it yet, one to artmap's recipe.

The cartridge draws the same picture (``game/snes``, ``world_map.h``).
"""

from __future__ import annotations

import json
import os

import pygame

from settings import MapSettings

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PICTURE = os.path.join(HERE, "assets", "graphics", "world_map.png")
SPOTS = os.path.join(HERE, "data", "world_map.json")

_picture: pygame.Surface | None = None
_spots: dict[str, tuple[int, int]] | None = None


def picture() -> pygame.Surface:
    """The world map, loaded once."""
    global _picture
    if _picture is None:
        _picture = pygame.image.load(PICTURE)
    return _picture


def spots() -> dict[str, tuple[int, int]]:
    """The named spots on the picture, each a pixel: column and row."""
    global _spots
    if _spots is None:
        with open(SPOTS, encoding="utf-8") as f:
            _spots = {name: (at[0], at[1]) for name, at in json.load(f)["spots"].items()}
    return _spots


def area_of(room: str) -> str:
    """The area of the world ``room`` is in: in the demo every room is Māla Iki's."""
    return MapSettings.WORLD_AREA


def dot_at(room: str) -> tuple[int, int] | None:
    """The pixel of the picture Kailo's dot goes on, or None for an area with no spot."""
    spot = MapSettings.WORLD_SPOTS.get(area_of(room))
    return spots().get(spot) if spot else None
