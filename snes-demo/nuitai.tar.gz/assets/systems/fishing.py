"""What a bite brings up (Frankie, 11/1: he caught a fish every single time).

A tap while a fish is biting lands something by chance: usually a fish, sometimes
nori or a few pule, and sometimes the catch gets away. The odds and amounts are
Claude's (``FishingSettings.ODDS``, ``PULE_RANGE``); a roll is one table lookup,
nothing the cartridge cannot do.
"""

from __future__ import annotations

import random
from typing import TYPE_CHECKING

from settings import FishingSettings, ItemSettings, ShopSettings

if TYPE_CHECKING:
    from systems.party import Party


def reel_in(party: "Party", rng: random.Random | None = None) -> str:
    """Land what bit, put it in the bag or purse, and return the line to say."""
    roll = (rng or random).uniform(0, sum(weight for _, weight in FishingSettings.ODDS))
    for kind, weight in FishingSettings.ODDS:
        roll -= weight
        if roll < 0:
            break
    bag = party.inventory
    if kind == "fish":
        bag["fish"] = bag.get("fish", 0) + 1
        return FishingSettings.CAUGHT_LINE
    if kind == "nori":
        bag[ItemSettings.SEAWEED] = bag.get(ItemSettings.SEAWEED, 0) + 1
        return FishingSettings.NORI_LINE
    if kind == "pule":
        amount = (rng or random).randint(*FishingSettings.PULE_RANGE)
        party.pule = min(party.pule + amount, ShopSettings.PULE_MAX)
        return FishingSettings.PULE_LINE.format(pule=amount)
    return FishingSettings.MISS_LINE
