"""What a bite brings up (Frankie, 11/1: he caught a fish every single time).

A tap while something is biting hooks it by chance: mostly nothing, now and then a
fish, nori or a few pule, and rarely an item (Frankie, 11/2). Bait doubles the fish
chance; the rod decides which fish (``FishingSettings.ODDS``, ``ODDS_NO_BAIT``, ``RODS``).
A roll is one table lookup, nothing the cartridge cannot do. A fish or a rare item is
not landed yet: it has to be reeled in (``Reel``).
"""

from __future__ import annotations

import random
from typing import TYPE_CHECKING

from settings import FishingSettings, ItemSettings, ShopSettings

if TYPE_CHECKING:
    from systems.party import Party

# The d-pad's circle, clockwise from up.
_CIRCLE = ((0, -1), (1, 0), (0, 1), (-1, 0))


def _pick(table, rng: random.Random | None) -> str:
    roll = (rng or random).uniform(0, sum(weight for _, weight in table))
    for kind, weight in table:
        roll -= weight
        if roll < 0:
            break
    return kind


def roll(baited: bool = True, rng: random.Random | None = None) -> str:
    """What bit: "fish", "rare", "nori", "pule" or "nothing"; bait makes a fish likelier."""
    return _pick(FishingSettings.ODDS if baited else FishingSettings.ODDS_NO_BAIT, rng)


def rod(party: "Party") -> str:
    """The best rod Kailo carries; the Old Rod until a better one is in the game."""
    rods = list(FishingSettings.RODS)
    return next((r for r in reversed(rods) if party.inventory.get(r)), rods[0])


def pick_fish(rng: random.Random | None = None, rod_id: str | None = None) -> str:
    """Which fish (Frankie, 11/2): only the rod's own, by their weights; bait never changes it."""
    fish = FishingSettings.RODS[rod_id or next(iter(FishingSettings.RODS))]
    return _pick([(f, w) for f, w in FishingSettings.FISH_ODDS if f in fish], rng)


def hook(kind: str, party: "Party", rng: random.Random | None = None) -> str:
    """The item on the line for a "fish" or "rare" bite, to be reeled in."""
    if kind == "rare":
        return _pick(FishingSettings.RARE_ODDS, rng)
    return pick_fish(rng, rod(party))


def catch(party: "Party", item: str) -> str:
    """Put a reeled-in fish or rare item in the bag and return the line to say."""
    party.inventory[item] = party.inventory.get(item, 0) + 1
    name = ItemSettings.NAMES[item]
    if item in ItemSettings.FISH:
        return FishingSettings.CAUGHT_LINE.format(fish=name)
    return FishingSettings.RARE_LINE.format(item=name)


def land(party: "Party", kind: str, rng: random.Random | None = None) -> str:
    """Land what bit, put it in the bag or purse, and return the line to say."""
    if kind in ("fish", "rare"):
        return catch(party, hook(kind, party, rng))
    if kind == "nori":
        party.inventory[ItemSettings.SEAWEED] = party.inventory.get(ItemSettings.SEAWEED, 0) + 1
        return FishingSettings.NORI_LINE
    if kind == "pule":
        amount = (rng or random).randint(*FishingSettings.PULE_RANGE)
        party.pule = min(party.pule + amount, ShopSettings.PULE_MAX)
        return FishingSettings.PULE_LINE.format(pule=amount)
    return FishingSettings.MISS_LINE


def reel_in(party: "Party", rng: random.Random | None = None, baited: bool = True) -> str:
    """A bite rolled and landed at once, with no reeling."""
    return land(party, roll(baited, rng), rng)


def has_bait(party: "Party") -> bool:
    """Whether a cast is baited (Frankie, 11/2): it is whenever Kailo carries any bait."""
    return party.inventory.get(FishingSettings.BAIT, 0) > 0


def spend_bait(party: "Party") -> None:
    """A fish landed on a baited hook eats the bait (Frankie, 11/2); nothing else uses it up."""
    bag = party.inventory
    if bag.get(FishingSettings.BAIT, 0) <= 0:
        return
    bag[FishingSettings.BAIT] -= 1
    if bag[FishingSettings.BAIT] <= 0:
        del bag[FishingSettings.BAIT]


class Reel:
    """A hooked fish or rare item (Frankie, 11/2): roll the d-pad round to fill the meter before it drains."""

    def __init__(self, item: str) -> None:
        self.item = item
        self.fill = FishingSettings.REEL_START
        self.left = FishingSettings.REEL_SECONDS
        self._last: int | None = None  # where on the circle the d-pad last was
        self._spin = 0  # +1 clockwise, -1 the other way, 0 not yet

    def press(self, direction: tuple[int, int]) -> bool:
        """The d-pad held now; True when it moved a quarter turn on the way it is going.
        Diagonals and letting go are passed over, so a roll through the corners counts."""
        if direction not in _CIRCLE:
            return False
        here = _CIRCLE.index(direction)
        last, self._last = self._last, here
        if last is None or last == here:
            return False
        step = {1: 1, 3: -1}.get((here - last) % 4)
        if step is None:  # straight across: no turn
            self._spin = 0
            return False
        if self._spin not in (0, step):  # turned back: start the new way
            self._spin = step
            return False
        self._spin = step
        self.fill = min(1.0, self.fill + FishingSettings.REEL_PER_TURN / 4)
        return True

    def tick(self, dt: float) -> str | None:
        """Drain and run the clock: "caught" once full, "escaped" once empty or out of time."""
        if self.fill >= 1.0:
            return "caught"
        self.left -= dt
        self.fill -= FishingSettings.REEL_DRAIN * dt
        if self.fill <= 0 or self.left <= 0:
            return "escaped"
        return None
