"""Hina's gardening and Maika's growing, the field abilities of the demo (Frankie, 10/22).

Plants grow in patches on the map (``data/crafting/garden.json``): taro in
the town, wheat in the palm grove (Frankie, 10/23). One press, one thing
(Frankie, 10/23): pressing on a ripe patch picks it; on a bare one, with
Hina in the party, asks to replant it, since only she knows how; on a
planted one, with Maika in the party, asks "Do the Maki Hula?", once a
planting. Planted, it is ripe after ``grow_steps`` steps walked, or
``ability_steps`` with the Maki Hula, never at once. The first time each
can be used, Hina or Maika offers it in their own words before the
question, once a game (Frankie, 10/23): Hina on the first pick with her
along, Maika at the first planted patch.

A patch's state is a party flag, ``garden:<room>:<index>``, so it saves
with the rest: missing is ripe (every patch starts ripe), ``0`` is bare,
and any other number is the step count at which it is ripe again.
A patch with ``"free": true`` (the farm behind Pono's house, Frankie, 10/29) takes any
plantable crop: bare, it asks which, from what the bag holds, and the choice is the
flag ``garden:<room>:<index>:plant``; ``plant`` in the file is what it starts with, and
``ripe_at`` the step it starts ripe at (``0`` bare), so the farm begins at mixed stages.
``garden:<room>:<index>:ability`` says Maika's ability was used on this
planting. The steps walked are the flag ``garden_steps``, and
``garden_offer:<id>`` says that character has offered their ability.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import TYPE_CHECKING, Callable

from settings import GardenSettings, ItemSettings

if TYPE_CHECKING:
    from systems.party import Party

_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                     "data", "crafting", "garden.json")
with open(_PATH, encoding="utf-8") as _f:
    GARDEN: dict = json.load(_f)

STEPS_FLAG = "garden_steps"
BARE = 0
# Who offers which ability the first time, and their line.
OFFERS = {"hina": GardenSettings.HINA_OFFER_LINE, "maika": GardenSettings.MAIKA_OFFER_LINE}


def patches_in(cell_name: str) -> list[dict]:
    """The patches in room ``cell_name``, in the file's order."""
    return GARDEN["patches"].get(cell_name, [])


def _key(cell_name: str, index: int) -> str:
    return f"garden:{cell_name}:{index}"


def steps(party: "Party") -> int:
    """The steps walked since the game began, as the garden counts them."""
    return int(party.flags.get(STEPS_FLAG, 0))


def walked(party: "Party") -> None:
    """Count one step walked."""
    party.flags[STEPS_FLAG] = steps(party) + 1


def _due(party: "Party", cell_name: str, index: int) -> int | None:
    """The patch's flag, else the step it starts ripe at (``ripe_at``), else None (ripe)."""
    value = party.flags.get(_key(cell_name, index))
    if value is None:
        value = patches_in(cell_name)[index].get("ripe_at")
    return value


def state(party: "Party", cell_name: str, index: int) -> str:
    """``"ripe"``, ``"bare"`` or ``"growing"``."""
    value = _due(party, cell_name, index)
    if value is None:
        return "ripe"
    if value == BARE:
        return "bare"
    return "ripe" if steps(party) >= value else "growing"


def _ability_key(cell_name: str, index: int) -> str:
    return f"{_key(cell_name, index)}:ability"


def stage(party: "Party", cell_name: str, index: int) -> int:
    """Which of the four pictures shows: 0 bare, 1 and 2 growing, 3 ripe."""
    now = state(party, cell_name, index)
    if now == "ripe":
        return 3
    if now == "bare":
        return 0
    left = _due(party, cell_name, index) - steps(party)
    grow = GARDEN["ability_steps"] if party.flags.get(_ability_key(cell_name, index)) else GARDEN["grow_steps"]
    return 1 if left > grow // 2 else 2


def _plant_key(cell_name: str, index: int) -> str:
    return f"{_key(cell_name, index)}:plant"


def is_free(cell_name: str, index: int) -> bool:
    """A farm patch, which takes any plantable crop (Frankie, 10/29)."""
    return bool(patches_in(cell_name)[index].get("free"))


def plant_of(cell_name: str, index: int, party: "Party | None" = None) -> str:
    """What grows in the patch, e.g. ``"taro"``: a farm patch's chosen crop, else the file's."""
    if party is not None and is_free(cell_name, index):
        chosen = party.flags.get(_plant_key(cell_name, index))
        if chosen in GARDEN["plants"]:
            return chosen
    return patches_in(cell_name)[index]["plant"]


@dataclass
class Press:
    """What pressing on a patch does: a line to say, a NO / YES question, or
    both, the line first. ``offer`` is who speaks between them, and what
    they say: the first time an ability can be used.

    ``yes`` is what YES does; it returns the lines to say after.
    """

    line: str | None = None
    question: str | None = None
    yes: Callable[[], list[str]] | None = None
    offer: tuple[str, str] | None = None
    # A farm patch asks which crop (Frankie, 10/29): the answers, and what picking one does.
    choices: list[str] | None = None
    pick: Callable[[int], list[str]] | None = None


def _offer(party: "Party", who: str) -> tuple[str, str] | None:
    """``who``'s first offer of their ability, once a game; None after.
    Spoken as the story speaks: "Hina", not her title."""
    flag = f"garden_offer:{who}"
    if party.flags.get(flag):
        return None
    party.flags[flag] = True
    return who.capitalize(), OFFERS[who]


def pick(party: "Party", cell_name: str, index: int) -> str:
    """Pick a ripe patch: its plant goes in the bag and the patch is bare."""
    plant = GARDEN["plants"][plant_of(cell_name, index, party)]
    item, count = plant["item"], plant["picked"]
    party.inventory[item] = party.inventory.get(item, 0) + count
    party.flags[_key(cell_name, index)] = BARE
    party.flags.pop(_ability_key(cell_name, index), None)
    return f"Picked {count} {ItemSettings.NAMES.get(item, item)}."


def seed_of(cell_name: str, index: int, party: "Party | None" = None) -> str:
    """The item replanting a patch uses up: its plant's seed (Frankie, 10/29; it was one of the crop)."""
    return GARDEN["plants"][plant_of(cell_name, index, party)]["seed"]


def crop_of(cell_name: str, index: int, party: "Party | None" = None) -> str:
    """The crop the patch grows, which can also plant it, one for one (Frankie, 10/29)."""
    return GARDEN["plants"][plant_of(cell_name, index, party)]["item"]


def planting_of(party: "Party", plant: str) -> tuple[str, int] | None:
    """What Hina plants ``plant`` with, and how many: its seed, else one of the crop
    (Frankie, 10/29: pick two, plant one, the berry system); None with neither."""
    seed = GARDEN["plants"][plant]["seed"]
    if party.inventory.get(seed, 0) >= 1:
        return seed, 1
    crop = GARDEN["plants"][plant]["item"]
    if party.inventory.get(crop, 0) >= GARDEN["crop_cost"]:
        return crop, GARDEN["crop_cost"]
    return None


def planting_with(party: "Party", cell_name: str, index: int) -> tuple[str, int] | None:
    """What Hina plants the patch with (``planting_of`` for its plant)."""
    return planting_of(party, plant_of(cell_name, index, party))


def replant(party: "Party", cell_name: str, index: int, plant: str | None = None) -> None:
    """Hina plants a bare patch with its seed, or one of its crop: ripe after ``grow_steps`` steps.
    On a farm patch ``plant`` is the crop chosen, which the patch then grows."""
    if plant is not None and is_free(cell_name, index):
        party.flags[_plant_key(cell_name, index)] = plant
    used, count = planting_with(party, cell_name, index) or (seed_of(cell_name, index, party), 1)
    party.inventory[used] = party.inventory.get(used, 0) - count
    if party.inventory[used] <= 0:
        del party.inventory[used]
    party.flags[_key(cell_name, index)] = steps(party) + GARDEN["grow_steps"]
    party.flags.pop(_ability_key(cell_name, index), None)


def use_ability(party: "Party", cell_name: str, index: int) -> None:
    """Maika's ability: the planting is ripe ``ability_steps`` after it was planted, not ``grow_steps``."""
    key = _key(cell_name, index)
    party.flags[key] = party.flags[key] - GARDEN["grow_steps"] + GARDEN["ability_steps"]
    party.flags[_ability_key(cell_name, index)] = True


def _ask_replant(party: "Party", cell_name: str, index: int, line: str | None = None) -> Press:
    """Hina along, and a seed in the bag: "Plant Taro Seed?", after her offer the first time."""
    if is_free(cell_name, index):
        return _ask_plant(party, cell_name, index, line)
    used, _ = planting_with(party, cell_name, index)

    def yes() -> list[str]:
        replant(party, cell_name, index)
        return []
    return Press(line=line, question=GardenSettings.REPLANT_BOX.format(item=ItemSettings.NAMES.get(used, used)),
                 yes=yes, offer=_offer(party, "hina"))


def _ask_plant(party: "Party", cell_name: str, index: int, line: str | None = None) -> Press:
    """A bare farm patch, Hina along: which crop to plant, from what the bag holds, or leave it."""
    plants = [plant for plant in GARDEN["plants"] if planting_of(party, plant) is not None]
    if not plants:
        return Press(line=line or GardenSettings.NO_FARM_SEED_LINE)
    answers = []
    for plant in plants:
        used, _ = planting_of(party, plant)
        answers.append(GardenSettings.PLANT_CHOICE.format(item=ItemSettings.NAMES.get(used, used)))
    answers.append(GardenSettings.LEAVE_CHOICE)

    def pick(choice: int) -> list[str]:
        if choice < len(plants):
            replant(party, cell_name, index, plants[choice])
        return []
    return Press(line=line, question=GardenSettings.PLANT_BOX, choices=answers, pick=pick,
                 offer=_offer(party, "hina"))


def press(party: "Party", cell_name: str, index: int) -> Press:
    """Face a patch and press confirm: one thing happens, or one question is asked."""
    now = state(party, cell_name, index)
    if now == "ripe":
        line = pick(party, cell_name, index)
        if party.find("hina") is not None and not party.flags.get("garden_offer:hina"):
            return _ask_replant(party, cell_name, index, line)
        return Press(line=line)
    if now == "bare":
        if party.find("hina") is None:
            return Press(line=GardenSettings.NEEDS_HINA_LINE)
        if is_free(cell_name, index):
            return _ask_plant(party, cell_name, index)
        seed = seed_of(cell_name, index)
        if planting_with(party, cell_name, index) is None:
            return Press(line=GardenSettings.NO_SEED_LINE.format(item=ItemSettings.NAMES.get(seed, seed),
                                                                      crop=ItemSettings.NAMES.get(crop_of(cell_name, index), seed)))
        return _ask_replant(party, cell_name, index)
    if party.find("maika") is not None and not party.flags.get(_ability_key(cell_name, index)):

        def grow() -> list[str]:
            use_ability(party, cell_name, index)
            return [GardenSettings.ABILITY_DONE_LINE, GardenSettings.ABILITY_LINE]
        return Press(question=GardenSettings.ABILITY_BOX, yes=grow, offer=_offer(party, "maika"))
    return Press(line=GardenSettings.GROWING_LINE)
