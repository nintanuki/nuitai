"""The village hens, where eggs come from (Frankie, 10/28).

Eggs come from chickens and are a Papanok drop. How the hens lay is
Claude's plainest reading, after the garden: a hen is someone in a room
file with ``hen``, and pressing confirm facing one with an egg puts it in
the bag. She lays again after ``HenSettings.LAY_STEPS`` steps walked, so
an egg cannot be pressed out of her over and over.

A hen's state is the party flag ``hen:<who>``, ``who`` naming her by room
and place in its file: missing, she has an egg (every hen starts with
one); a number is the step count at which she has one again. The steps
are the garden's, ``garden.steps``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from settings import HenSettings, ItemSettings
from systems import garden

if TYPE_CHECKING:
    from systems.party import Party


def _key(who: str) -> str:
    return f"hen:{who}"


def has_egg(party: "Party", who: str) -> bool:
    """Whether the hen called ``who`` has an egg to give."""
    return garden.steps(party) >= int(party.flags.get(_key(who), 0))


def collect(party: "Party", who: str) -> str:
    """Pressing confirm facing the hen ``who``: her egg in the bag if she has one; what is said."""
    if not has_egg(party, who):
        return HenSettings.NO_EGG_LINE
    party.inventory[ItemSettings.EGG] = party.inventory.get(ItemSettings.EGG, 0) + 1
    party.flags[_key(who)] = garden.steps(party) + HenSettings.LAY_STEPS
    return HenSettings.EGG_LINE
