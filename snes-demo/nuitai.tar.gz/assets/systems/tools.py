"""Kailo's field tools on Y (Frankie, 10/26 to 10/28): which he owns, and which is set.

Each tool does one job (``ToolSettings.LINES``): the ko'i chops, the fishing
rod fishes, the shovel digs. A job's line runs from its first tool to its
upgrades; the tools are key items in the bag, and an upgrade replaces the one
before it rather than sitting beside it (``take``). Y uses one tool at a time,
the job set on the tool wheel, kept in the save as ``Party.tool``. With
nothing set, or a job he no longer has a tool for, the first job he owns is
the one used, so the ko'i works the moment it is out of the chest.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from settings import ToolSettings

if TYPE_CHECKING:
    from systems.party import Party


def is_tool(item_id: str) -> bool:
    """Whether ``item_id`` is one of the field tools."""
    return any(item_id in line for line in ToolSettings.LINES.values())


def best(party: "Party", job: str) -> str | None:
    """The tool Kailo has for ``job``, the furthest up its line, or None."""
    owned = [item for item in ToolSettings.LINES.get(job, ()) if party.inventory.get(item, 0) > 0]
    return owned[-1] if owned else None


def wheel(party: "Party") -> list[str | None]:
    """The wheel's slots, from up clockwise: each slot's job if he owns its tool, else None."""
    jobs = list(ToolSettings.WHEEL)[:ToolSettings.WHEEL_SLOTS]
    jobs += [None] * (ToolSettings.WHEEL_SLOTS - len(jobs))
    return [job if job and best(party, job) else None for job in jobs]


def current(party: "Party") -> str | None:
    """The job a tap of Y does: the one set, else the first owned, else None."""
    if party.tool and best(party, party.tool):
        return party.tool
    return next((job for job in wheel(party) if job), None)


def take(party: "Party", item_id: str) -> None:
    """Put the tool ``item_id`` in the bag; the tools before it in its line go."""
    for line in ToolSettings.LINES.values():
        if item_id in line:
            for older in line[:line.index(item_id)]:
                party.inventory.pop(older, None)
    party.inventory[item_id] = 1


def slot_at(dx: int, dy: int, slots: int = ToolSettings.WHEEL_SLOTS) -> int | None:
    """The slot a held direction points at, 0 up then clockwise; None with nothing held.

    Four slots are the d-pad's four ways; with eight the diagonals count too.
    """
    if dx == 0 and dy == 0:
        return None
    # The eight ways, up first, clockwise.
    ways = [(0, -1), (1, -1), (1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1)]
    if slots == 4 and dx and dy:
        # A diagonal on four slots keeps its up or down.
        dx = 0
    return ways.index((dx, dy)) * slots // len(ways)
