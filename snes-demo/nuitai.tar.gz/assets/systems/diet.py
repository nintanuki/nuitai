"""Who will not eat what (Frankie, 11/2).

It goes by faith (``ItemSettings.FAITHS``): Māla, and the Luminary, eat no meat
or fish, eggs fine; the Golden Sun no pork; Wai'Ki no meat but fish. A dish holds what its recipe holds, all the
way down (laulau holds pork, so it is refused), by the pot's recipes and the
battle Cook's.
"""

from __future__ import annotations

from settings import BattleSettings, ItemSettings



def holds(item: str, _seen: frozenset = frozenset()) -> set[str]:
    """Everything ``item`` may be made from, itself included, all the way down: a Meat Stew
    holds every meat, since any of them makes it (``systems/cooking.py``)."""
    from systems import cooking

    found = {item}
    for part in cooking.sources(item):
        if part not in _seen and part != item:
            found |= holds(part, _seen | {item})
    return found


def refuses(who: str, item: str | None = None, parts: tuple | list = ()) -> bool:
    """Whether ``who`` (a party id, or a villager's name) will not eat ``item``, or a dish of ``parts``."""
    faith = ItemSettings.FAITHS.get(ItemSettings.DIET_BY_NAME.get(who, who))
    banned = set(ItemSettings.FAITH_REFUSES.get(faith, ()))
    return bool(banned) and bool(kinds([item] if item else [], parts) & banned)


def kinds(items: list, parts: tuple | list = ()) -> set[str]:
    """What kinds of food (pork, meat, fish) these items, or a dish of ``parts``, hold."""
    found: set[str] = set()
    for thing in list(items) + list(parts):
        for raw in holds(thing):
            found |= set(ItemSettings.FOOD_KINDS.get(raw, ()))
    return found


def sickens(who: str, item: str) -> bool:
    """Whether eating ``item`` makes ``who`` sick (Frankie, 11/2): ???, raw pork (but for
    Gen'emon), or raw fish (but for the Nuitagata, Gen'emon and Ren)."""
    if item == ItemSettings.DUBIOUS:
        return True
    if item in ItemSettings.RAW_DISHES:
        raw = {ItemSettings.RAW_DISHES[item]}
    elif item in ItemSettings.INGREDIENTS:
        raw = set(ItemSettings.FOOD_KINDS.get(item, ()))
    else:
        return False
    if "meat" in raw and who not in ItemSettings.RAW_MEAT_EATERS:
        return True
    return "fish" in raw and who not in ItemSettings.RAW_FISH_EATERS


def respond(who: str, item: str, present: list[str]) -> tuple[str, list[tuple[str, str]]]:
    """Handed ``item`` with ``present`` (party ids) around: "eat", "refuse" or "sick", and who says what.

    A refusal is their own line. Sarjana eats pork and says he shouldn't, unless Hina or Damar
    is there to scold him, and then he does not eat it (Frankie, 11/2). What makes them sick
    they eat, and it poisons them instead of healing.
    """
    if refuses(who, item):
        return "refuse", [(who, refusal(who))]
    said: list[tuple[str, str]] = []
    guilt = ItemSettings.PORK_GUILT
    if who == guilt["who"] and "pork" in kinds([item]):
        scolder = next((p for p in present if p in guilt["scolds"] and p != who), None)
        if scolder:
            return "refuse", [(scolder, guilt["scolds"][scolder]), (who, guilt["backs_down"])]
        said = [(who, guilt["line"])]
    return ("sick" if sickens(who, item) else "eat"), said


def cook_refuses(who: str, kind: str) -> bool:
    """Whether ``who`` will not eat what Kailo's Cook serves for ``kind`` (heal, cure, rest)."""
    return refuses(who, parts=BattleSettings.COOK_RECIPES.get(kind, ()))


def refusal(who: str) -> str:
    """What ``who`` says when handed something they will not eat."""
    return ItemSettings.REFUSE_LINES.get(who, "No, thank you.")
