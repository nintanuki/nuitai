"""Who will not eat what (Frankie, 11/2).

It goes by faith (``ItemSettings.FAITHS``): Māla, and the Luminary, eat no meat
or fish, eggs fine; the Golden Sun no pork; Wai'Ki no meat but fish. A dish holds what its recipe holds, all the
way down (laulau holds pork, so it is refused), by the pot's recipes and the
battle Cook's.
"""

from __future__ import annotations

import json
import os

from settings import BattleSettings, ItemSettings

_POT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "crafting", "pot.json")
_RECIPES: dict[str, list[str]] = {}


def _recipes() -> dict[str, list[str]]:
    """The pot's recipes, dish id to what goes in."""
    if not _RECIPES:
        with open(_POT, encoding="utf-8") as f:
            _RECIPES.update({r["id"]: r["from"] for r in json.load(f)["recipes"]})
    return _RECIPES


def holds(item: str) -> set[str]:
    """Everything ``item`` is made from, itself included, all the way down."""
    found = {item}
    for part in _recipes().get(item, ()):
        found |= holds(part)
    return found


def refuses(who: str, item: str | None = None, parts: tuple | list = ()) -> bool:
    """Whether ``who`` (a party id, or a villager's name) will not eat ``item``, or a dish of ``parts``."""
    faith = ItemSettings.FAITHS.get(ItemSettings.DIET_BY_NAME.get(who, who))
    banned = set(ItemSettings.FAITH_REFUSES.get(faith, ()))
    return bool(banned) and bool(kinds([item] if item else [], parts) & banned)


def kinds(items: list, parts: tuple | list = ()) -> set[str]:
    """What kinds of food (pork, meat, fish) these items, or a dish of ``parts``, hold."""
    found: set[str] = set()
    for thing in list(items) + list(parts):
        for raw in holds(thing):
            found |= set(ItemSettings.FOOD_KINDS.get(raw, ()))
    return found


def respond(who: str, item: str, present: list[str]) -> tuple[bool, list[tuple[str, str]]]:
    """Handed ``item`` with ``present`` (party ids) around: whether ``who`` eats it, and who says what.

    A refusal is their own line. Sarjana eats pork and says he shouldn't, unless Hina or Damar
    is there to scold him, and then he does not eat it (Frankie, 11/2).
    """
    if refuses(who, item):
        return False, [(who, refusal(who))]
    guilt = ItemSettings.PORK_GUILT
    if who == guilt["who"] and "pork" in kinds([item]):
        scolder = next((p for p in present if p in guilt["scolds"] and p != who), None)
        if scolder:
            return False, [(scolder, guilt["scolds"][scolder]), (who, guilt["backs_down"])]
        return True, [(who, guilt["line"])]
    return True, []


def cook_refuses(who: str, kind: str) -> bool:
    """Whether ``who`` will not eat what Kailo's Cook serves for ``kind`` (heal, cure, rest)."""
    return refuses(who, parts=BattleSettings.COOK_RECIPES.get(kind, ()))


def refusal(who: str) -> str:
    """What ``who`` says when handed something they will not eat."""
    return ItemSettings.REFUSE_LINES.get(who, "No, thank you.")
