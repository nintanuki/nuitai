"""The area map's picture (Frankie, 10/26; the scene is ``core/scenes/map_scene.py``).

Every outside room sits on the world grid (``WORLD_LAYOUT``), so the map
lays them side by side as they join: room ``(cx, cy)`` is drawn
``cx * 16`` tiles across and ``cy * 14`` down from the north-west room.
Each tile is one block of ``MapSettings.TILE_PIXELS`` pixels in its tile's
color; a house, a stall or the boat is drawn over the tiles it covers.
Only rooms Kailo has walked into are drawn, the rest stay dark. The map's
size is every outside room's, found or not, so it fills in without moving.
The insides of buildings sit far below (``INSIDE_ROW``) and are left off;
inside one, Kailo's dot is at its door.

An area can be any size, most bigger than the view under the title at two
pixels a tile, so the map is seen through that view (``VIEW_W`` by ``VIEW_H``): it opens centered on Kailo's
dot, the d-pad pans it to the area's edges, and an area smaller than the
view one way is centered that way and does not pan (Frankie, 10/28).

The cartridge draws the same map from the same rules (``game/snes``).
"""

from __future__ import annotations

import pygame

from core.overworld_cells import BUILDINGS, CELLS, INSIDE_ROW, WORLD_LAYOUT, building_tiles
from settings import MapSettings, OverworldSettings
from systems import places

COLS, ROWS = OverworldSettings.COLS, OverworldSettings.ROWS


def outside_rooms() -> dict[tuple[int, int], str]:
    """Every outside room this game, by its place on the world grid."""
    return {pos: name for pos, name in WORLD_LAYOUT.items() if pos[1] < INSIDE_ROW}


def bounds() -> tuple[int, int, int, int]:
    """The outside rooms' corners on the world grid: west, north, east, south."""
    rooms = outside_rooms()
    xs = [pos[0] for pos in rooms]
    ys = [pos[1] for pos in rooms]
    return min(xs), min(ys), max(xs), max(ys)


def size(block: int = MapSettings.TILE_PIXELS) -> tuple[int, int]:
    """The map picture's size in pixels."""
    west, north, east, south = bounds()
    return (east - west + 1) * COLS * block, (south - north + 1) * ROWS * block


def tile_colors(name: str) -> list[list[tuple[int, int, int] | None]]:
    """Room ``name`` as one color per tile, None for nothing (the black around an inside room)."""
    grid = CELLS[name]
    colors = [[MapSettings.TILE_COLORS.get(char) for char in row] for row in grid]
    for building in BUILDINGS.get(name, []):
        if building["kind"] not in MapSettings.BUILDING_KINDS or building.get("night"):
            continue
        for col, row in building_tiles(building):
            if 0 <= col < COLS and 0 <= row < ROWS:
                colors[row][col] = MapSettings.BUILDING_COLOR
    return colors


def door_of(inside: str) -> tuple[str, int, int] | None:
    """The outside room and tile below the door of the building ``inside`` is the inside of."""
    for room, spots in BUILDINGS.items():
        for building in spots:
            door = OverworldSettings.DOORS.get(building["kind"])
            if building.get("inside") == inside and door is not None:
                return room, building["col"] + door[0], building["row"] + door[1] + 1
    return None


def where(room: str, col: int, row: int) -> tuple[str, int, int] | None:
    """The outside room and tile to put Kailo's dot on: where he stands, or the door he went in by."""
    pos = next((pos for pos, name in WORLD_LAYOUT.items() if name == room), None)
    if pos is None:
        return None
    if pos[1] < INSIDE_ROW:
        return room, col, row
    return door_of(room)


def title(room: str) -> str | None:
    """The map's title: the place Kailo is in (a house's is the room it stands in)."""
    door = door_of(room)
    return places.place_of(room) or (places.place_of(door[0]) if door else None)


def draw(seen: set[str], block: int = MapSettings.TILE_PIXELS) -> pygame.Surface:
    """The map of the rooms in ``seen``, on a see-through picture of ``size()``."""
    picture = pygame.Surface(size(block), pygame.SRCALPHA)
    west, north, _, _ = bounds()
    for (cx, cy), name in outside_rooms().items():
        if name not in seen:
            continue
        x0 = (cx - west) * COLS * block
        y0 = (cy - north) * ROWS * block
        for row, line in enumerate(tile_colors(name)):
            for col, color in enumerate(line):
                if color is not None:
                    picture.fill(color, (x0 + col * block, y0 + row * block, block, block))
    return picture


def dot_at(room: str, col: int, row: int, block: int = MapSettings.TILE_PIXELS) -> tuple[int, int] | None:
    """The top left pixel of Kailo's tile on the map picture, or None off it."""
    spot = where(room, col, row)
    if spot is None:
        return None
    name, col, row = spot
    pos = next(pos for pos, who in WORLD_LAYOUT.items() if who == name)
    west, north, _, _ = bounds()
    return ((pos[0] - west) * COLS + col) * block, ((pos[1] - north) * ROWS + row) * block


def clamp(x: float, y: float, picture: tuple[int, int] | None = None) -> tuple[float, float]:
    """The view's top left on the map picture, kept inside it; an axis the view is wider than
    is centered (a negative start) and stays put."""
    width, height = picture or size()
    return (_clamp_axis(x, width, MapSettings.VIEW_W), _clamp_axis(y, height, MapSettings.VIEW_H))


def _clamp_axis(at: float, length: int, view: int) -> float:
    if length <= view:
        return -((view - length) // 2)
    return max(0, min(at, length - view))


def start(room: str, col: int, row: int) -> tuple[float, float]:
    """Where the view opens: centered on Kailo's dot, then kept inside the map."""
    at = dot_at(room, col, row)
    if at is None:
        return clamp(0, 0)
    half = MapSettings.TILE_PIXELS // 2
    return clamp(at[0] + half - MapSettings.VIEW_W // 2, at[1] + half - MapSettings.VIEW_H // 2)
