"""The stew quest (Frankie, 10/26, reshaped 10/30).

After the opening fight the boars knock the stew pot over as they run into the
forest, so there is nothing for the wake. Noelani, Kailo's cousin, offers to cook
a new one if the player brings her the ingredients (``StewSettings.NEEDS``): fish
from fishing, pork from a wild boar, an egg, niu from chopping trees, soy sauce
from the old man's stall, and 'uala and akai lau, which only grow from seeds. It
is a quest, not the cooking pot. Its point is to make the player try what the game
offers before the Great Boar.

Two party flags: ``stew_quest`` once the opening is over, ``stew_made`` once
Noelani has what she needs. The stew gates the night: it falls only once the stew
is made and the Great Boar is beaten, in either order.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from settings import ItemSettings, StewSettings, StorySettings

if TYPE_CHECKING:
    from systems.party import Party


def active(party: "Party") -> bool:
    """Whether the quest is on: the opening is over and the stew not yet made."""
    return bool(party.flags.get(StewSettings.QUEST_FLAG)) and not made(party)


def made(party: "Party") -> bool:
    """Whether Noelani has cooked the stew."""
    return bool(party.flags.get(StewSettings.MADE_FLAG))


def missing(party: "Party") -> dict[str, int]:
    """What the bag still lacks, item id to how many more."""
    return {item: need - party.inventory.get(item, 0) for item, need in StewSettings.NEEDS.items()
            if party.inventory.get(item, 0) < need}


def _name(item: str, count: int) -> str:
    name = ItemSettings.NAMES.get(item, item)
    return name if count == 1 else f"{count} {name}"


def things(lacking: dict[str, int], hints: bool = False) -> str:
    """The ingredients ``lacking`` as a sentence's list: "a, b and c"; with ``hints`` each says where it is from."""
    parts = [StewSettings.HINTS[item] if hints else _name(item, count) for item, count in lacking.items()]
    return ", ".join(parts[:-1]) + (" and " if len(parts) > 1 else "") + parts[-1]


def cook(party: "Party") -> bool:
    """Hand over the ingredients if the bag has them all: they are used up, the stew is made."""
    if missing(party):
        return False
    for item, need in StewSettings.NEEDS.items():
        party.inventory[item] -= need
        if party.inventory[item] <= 0:
            del party.inventory[item]
    party.flags[StewSettings.MADE_FLAG] = True
    return True


def night_falls(party: "Party") -> bool:
    """Whether it is time for night: the stew made and the Great Boar beaten."""
    return made(party) and bool(party.flags.get(StorySettings.BOAR_BEATEN_FLAG))
