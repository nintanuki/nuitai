"""Kaigara, the Kame shell game (Frankie, 10/26 and 10/27; ``game/answers.md``).

Roughly Go on a 9 by 9 chalk grid, black and white cowries. The rules are
Claude's pick, simplified Go (10/27):

- Black (the player) goes first; each turn a player puts a shell on an
  open point or passes.
- A group of shells with no open point beside it is taken off the board.
- No suicide: a shell may not go where its group would have no open point,
  unless it takes something.
- Simple ko: a shell may not put the board back the way it was just before
  the other player's last turn.
- The game ends when both pass in a row, or when the player resigns.
- Area scoring: every shell on the board, plus every open point walled in
  by one color only. No komi, and nothing is counted dead: a shell on the
  board at the end is alive, so take what you can before you pass. A tie
  is a draw.

The Kame is weak (Frankie, 10/27): he puts his shell on any legal point at
random, and passes when the player has just passed, or when he has no move.
Pure rules, no pygame, so the tests can play it.
"""

from __future__ import annotations

import random
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from systems.party import Party

BLACK, WHITE, EMPTY = "b", "w", "."
SIZE = 9
# The party flag of the first win, which pays the kupang once (Frankie, 10/27).
WON_FLAG = "kaigara_won"
# The Lore pages a game unlocks, won or lost (``game/shared/lore.md``).
PLAYED_EVENT = "event kaigara"

Point = tuple[int, int]


def other(color: str) -> str:
    return WHITE if color == BLACK else BLACK


class Board:
    """The chalk grid: whose shell is on each point, whose turn, what was taken."""

    def __init__(self, size: int = SIZE) -> None:
        self.size = size
        self.grid: list[list[str]] = [[EMPTY] * size for _ in range(size)]
        self.turn = BLACK
        # Shells each color has taken from the other.
        self.taken = {BLACK: 0, WHITE: 0}
        # The board before the last move, for simple ko.
        self._before: Optional[tuple[str, ...]] = None
        self.passes = 0
        self.over = False
        self.resigned: Optional[str] = None
        self.last: Optional[Point] = None

    @classmethod
    def from_rows(cls, rows: list[str], turn: str = BLACK) -> "Board":
        """A board drawn as text, one row a string of ``b``, ``w`` and ``.`` (the tests)."""
        board = cls(len(rows))
        board.grid = [list(row) for row in rows]
        board.turn = turn
        return board

    # ------------------------------------------------------------------
    # LOOKING
    # ------------------------------------------------------------------

    def at(self, point: Point) -> str:
        col, row = point
        return self.grid[row][col]

    def on_board(self, point: Point) -> bool:
        col, row = point
        return 0 <= col < self.size and 0 <= row < self.size

    def neighbors(self, point: Point) -> list[Point]:
        col, row = point
        return [p for p in ((col - 1, row), (col + 1, row), (col, row - 1), (col, row + 1)) if self.on_board(p)]

    def group(self, point: Point) -> tuple[set[Point], set[Point]]:
        """The shells joined to the one on ``point``, and the open points beside them (its liberties)."""
        color = self.at(point)
        stones, liberties, todo = {point}, set(), [point]
        while todo:
            for n in self.neighbors(todo.pop()):
                if self.at(n) == EMPTY:
                    liberties.add(n)
                elif self.at(n) == color and n not in stones:
                    stones.add(n)
                    todo.append(n)
        return stones, liberties

    def snapshot(self) -> tuple[str, ...]:
        return tuple("".join(row) for row in self.grid)

    def points(self) -> list[Point]:
        return [(col, row) for row in range(self.size) for col in range(self.size)]

    # ------------------------------------------------------------------
    # PLAYING
    # ------------------------------------------------------------------

    def _try(self, point: Point, color: str) -> Optional[tuple[list[list[str]], int]]:
        """The grid after ``color`` plays ``point`` and how many it took, or None if illegal."""
        if self.over or not self.on_board(point) or self.at(point) != EMPTY:
            return None
        saved = [row[:] for row in self.grid]
        col, row = point
        self.grid[row][col] = color
        took = 0
        for n in self.neighbors(point):
            if self.at(n) == other(color):
                stones, liberties = self.group(n)
                if not liberties:
                    for c, r in stones:
                        self.grid[r][c] = EMPTY
                    took += len(stones)
        legal = bool(self.group(point)[1])              # no suicide
        if legal and self.snapshot() == self._before:   # simple ko
            legal = False
        after = self.grid
        self.grid = saved
        return (after, took) if legal else None

    def legal(self, point: Point, color: Optional[str] = None) -> bool:
        return self._try(point, color or self.turn) is not None

    def why_not(self, point: Point) -> str:
        """Why the player cannot play ``point``: "taken", "suicide" or "ko" ("" if they can)."""
        if self.at(point) != EMPTY:
            return "taken"
        if self.legal(point):
            return ""
        col, row = point
        self.grid[row][col] = self.turn
        captures = any(self.at(n) == other(self.turn) and not self.group(n)[1] for n in self.neighbors(point))
        self.grid[row][col] = EMPTY
        return "ko" if captures else "suicide"

    def legal_moves(self, color: Optional[str] = None) -> list[Point]:
        return [p for p in self.points() if self.legal(p, color)]

    def play(self, point: Point) -> int:
        """Put the shell of whoever's turn it is on ``point``; how many it took. Raises if illegal."""
        result = self._try(point, self.turn)
        if result is None:
            raise ValueError(f"illegal move {point}")
        self._before = self.snapshot()
        self.grid, took = result
        self.taken[self.turn] += took
        self.turn = other(self.turn)
        self.passes = 0
        self.last = point
        return took

    def pass_turn(self) -> None:
        """Pass; the second pass in a row ends the game."""
        self._before = self.snapshot()
        self.turn = other(self.turn)
        self.passes += 1
        self.last = None
        if self.passes >= 2:
            self.over = True

    def resign(self, color: str = BLACK) -> None:
        self.resigned = color
        self.over = True

    # ------------------------------------------------------------------
    # COUNTING
    # ------------------------------------------------------------------

    def score(self) -> dict[str, int]:
        """Area scoring: each color's shells plus the open points only it walls in."""
        score = {BLACK: 0, WHITE: 0}
        seen: set[Point] = set()
        for point in self.points():
            here = self.at(point)
            if here != EMPTY:
                score[here] += 1
                continue
            if point in seen:
                continue
            # An open region and the colors on its edge.
            region, edge, todo = {point}, set(), [point]
            while todo:
                for n in self.neighbors(todo.pop()):
                    if self.at(n) == EMPTY:
                        if n not in region:
                            region.add(n)
                            todo.append(n)
                    else:
                        edge.add(self.at(n))
            seen |= region
            if len(edge) == 1:
                score[edge.pop()] += len(region)
        return score

    def winner(self) -> Optional[str]:
        """Who won the finished game: BLACK, WHITE, or None for a draw."""
        if self.resigned:
            return other(self.resigned)
        score = self.score()
        if score[BLACK] == score[WHITE]:
            return None
        return BLACK if score[BLACK] > score[WHITE] else WHITE


def kame_move(board: Board, rng: random.Random | None = None) -> Optional[Point]:
    """The Kame's move: any legal point at random; None to pass.

    He passes when the player has just passed (he is happy to count), or
    when he has nowhere to play.
    """
    if board.passes:
        return None
    moves = board.legal_moves()
    return (rng or random).choice(moves) if moves else None


def settle(party: "Party", winner: Optional[str]) -> bool:
    """A game is over: the Lore pages, and the kupang for a first win. True if it was paid."""
    from core import lore  # local: lore reads the shared pages on import

    lore.unlock(party, PLAYED_EVENT)
    if winner != BLACK or party.flags.get(WON_FLAG):
        return False
    party.flags[WON_FLAG] = True
    party.kupang += 1
    return True
