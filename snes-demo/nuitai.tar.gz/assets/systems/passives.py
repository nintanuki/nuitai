"""The party passives: what a member does for everyone just by travelling along.

Each is on while its member is in the party, bench included (Frankie,
10/21 and 10/22), about the journey, not the fight. None is shown on a
menu: one sentence says it when the member joins (``join_line``), and
then it just works.

* **Hina:** after a won fight anyone fainted gets up with 1 HP; without
  her they stay at 0. Hers comes first, so Kailo's meal reaches them too.
* **Kailo:** after a won fight, if he is standing, he feeds everyone, and
  all who are standing get back a tenth of their max HP (``meal_rate`` in
  the shared file's ``cooking``).
* **Maika:** shops charge less (``core/scenes/shop_scene.py``).
* **Tawiri:** stats grow from use in a fight more often (``growth_chance``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from core.shared import SHARED, short_name
from settings import PassiveSettings

if TYPE_CHECKING:
    from systems.party import Party


def join_line(member_id: str) -> str:
    """The pop-up said when ``member_id`` joins: who, and their passive in one sentence."""
    line = f"{short_name(member_id)} joined the party."
    passive = PassiveSettings.JOIN_LINES.get(member_id)
    return f"{line} {passive}" if passive else line


def after_victory(party: "Party") -> list[str]:
    """Hina's and Kailo's passives, after a won fight. Returns the lines to say.

    Both say nothing (Frankie, 10/23: a passive just works): Hina scolds
    the fainted up, and Kailo feeds whoever standing was hurt.
    """
    if party.find("hina") is not None:
        for member in party.members:
            if member.current_hp <= 0:
                member.current_hp = 1
    kailo = party.find("kailo")
    if kailo is None or kailo.current_hp <= 0:
        return []
    rate = SHARED["cooking"]["meal_rate"]
    hurt = [m for m in party.members if 0 < m.current_hp < m.max_hp]
    if not hurt:
        return []
    for member in hurt:
        member.current_hp = min(member.max_hp, member.current_hp + max(1, round(member.max_hp * rate)))
    return []


def growth_chance(party: "Party", chance: float) -> float:
    """The chance a stat grows from use in a fight: more with Tawiri along."""
    if party.find("tawiri") is not None:
        return chance * PassiveSettings.TAWIRI_GROWTH
    return chance
