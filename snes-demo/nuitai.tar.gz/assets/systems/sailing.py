"""Sailing: the sea, the current and the food (Frankie, 10/31; the scene is
``core/scenes/sea_scene.py``, the numbers ``SailingSettings``).

The sea is the to-scale map at one tile to 25 miles (``data/sea_map.json`` and
``assets/graphics/sea_map.png``, both made by ``tools/mapgen/seapic.py``), so a
distance at sea is a true one. Positions are in tiles, fractions allowed:
column then row, east and south positive.

Provisions, as Frankie set them: each person aboard eats one food a day; every
food keeps a number of days at sea and is wasted past them; the soonest to
spoil is eaten first, which stretches the stock as far as it can go. The
count of days is from leaving port (``DAY_FLAG``), and goes back to nought on
going ashore (Claude's call, for now: the food's clock starts at the dock).
Nothing here draws; the tests run it without a window.
"""

from __future__ import annotations

import json
import math
import os
from typing import TYPE_CHECKING

from settings import SailingSettings

if TYPE_CHECKING:
    from systems.party import Party

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(HERE, "data", "sea_map.json")
PICTURE = os.path.join(HERE, "assets", "graphics", "sea_map.png")

# The days sailed since leaving port, in the party's flags.
DAY_FLAG = "sea_day"

_sea: "Sea | None" = None


class Sea:
    """The sea map: where land is, the whirlpool's zones, and the named spots."""

    def __init__(self, data: dict) -> None:
        self.width, self.height = data["size"]
        self.miles_per_tile = data["miles_per_tile"]
        self.middle = float(data["middle"])
        # Where each zone starts, in tiles from the middle, outermost first.
        self.zone_inner = [zone["inner"] for zone in data["zones"]]
        self.zone_names = [zone["name"] for zone in data["zones"]]
        self.kinds = data["kinds"]   # the tile pictures' names, in sea_tiles.png's order
        self.spots = {name: (at[0], at[1]) for name, at in data["spots"].items()}
        self._land = bytearray(self.width * self.height)
        for row, runs in enumerate(data["land"]):
            for start, length in runs:
                self._land[row * self.width + start: row * self.width + start + length] = b"\1" * length

    def is_land(self, col: int, row: int) -> bool:
        """Whether tile ``col``, ``row`` is land, or off the map (which counts as land)."""
        if not (0 <= col < self.width and 0 <= row < self.height):
            return True
        return bool(self._land[row * self.width + col])

    def zone(self, x: float, y: float) -> int:
        """The whirlpool zone at ``x``, ``y``: 0 the Calm Ring, counting inward."""
        r = math.hypot(x - self.middle, y - self.middle)
        band = 0
        while band < len(self.zone_inner) - 1 and r < self.zone_inner[band]:
            band += 1
        return band

    def sailable(self, x: float, y: float) -> bool:
        """Whether the Meialana can be at ``x``, ``y``: water, no further in than she can sail."""
        return (not self.is_land(int(math.floor(x)), int(math.floor(y)))
                and self.zone(x, y) <= SailingSettings.INNERMOST_ZONE)

    def current(self, x: float, y: float) -> tuple[float, float]:
        """The current at ``x``, ``y`` in tiles a day: clockwise round the middle, by its zone."""
        dx, dy = x - self.middle, y - self.middle
        r = math.hypot(dx, dy)
        if r == 0:
            return 0.0, 0.0
        knots = SailingSettings.CURRENT_KNOTS[min(self.zone(x, y), len(SailingSettings.CURRENT_KNOTS) - 1)]
        speed = knots * SailingSettings.MILES_PER_KNOT_DAY / self.miles_per_tile
        # Clockwise on a map with north up and rows running south: north of the middle it runs east.
        return -dy / r * speed, dx / r * speed

    def boat_speed(self) -> float:
        """The Meialana's own speed in tiles a day."""
        return SailingSettings.MILES_PER_DAY / self.miles_per_tile

    def water_near(self, at: tuple[float, float]) -> tuple[float, float]:
        """The middle of the sailable tile nearest ``at``: where the boat waits off a port."""
        col0, row0 = int(at[0]), int(at[1])
        for reach in range(1, 12):
            best = None
            for row in range(row0 - reach, row0 + reach + 1):
                for col in range(col0 - reach, col0 + reach + 1):
                    x, y = col + 0.5, row + 0.5
                    if self.sailable(x, y):
                        d = math.hypot(col - col0, row - row0)
                        if best is None or d < best[0]:
                            best = (d, (x, y))
            if best:
                return best[1]
        return at[0] + 0.5, at[1] + 0.5

    def nearest_port(self, x: float, y: float, ports=None) -> tuple[str, float]:
        """The nearest port's name and its distance in tiles, as the bird flies."""
        names = [name for name in (ports or SailingSettings.PORTS) if name in self.spots]
        name = min(names, key=lambda n: math.hypot(self.spots[n][0] + 0.5 - x, self.spots[n][1] + 0.5 - y))
        at = self.spots[name]
        return name, math.hypot(at[0] + 0.5 - x, at[1] + 0.5 - y)


def sea() -> Sea:
    """The sea map, loaded once."""
    global _sea
    if _sea is None:
        with open(DATA, encoding="utf-8") as f:
            _sea = Sea(json.load(f))
    return _sea


# ---------------------------------------------------------------------------
# PROVISIONS
# ---------------------------------------------------------------------------

def keeps(item: str) -> int | None:
    """How many days ``item`` keeps at sea, or None when it is not voyage food."""
    return SailingSettings.FOOD_DAYS.get(item)


def larder(inventory: dict[str, int]) -> list[tuple[int, int]]:
    """The voyage food in the bag as (days it keeps, how many), soonest to spoil first."""
    stock: dict[int, int] = {}
    for item, count in inventory.items():
        days = keeps(item)
        if days is not None and count > 0:
            stock[days] = stock.get(days, 0) + count
    return sorted(stock.items())


def days_of_food(inventory: dict[str, int], people: int, day: int = 0) -> int:
    """How many more days ``people`` can eat, ``day`` days out from port.

    Each person eats one food a day, the soonest to spoil first; a food is
    good through day ``keeps`` and wasted after it. The example, Frankie's:
    five saimin that keep five days and ten coconuts feed one person fifteen
    days; twenty of that saimin alone, only five.
    """
    need = max(1, people) * SailingSettings.FOOD_PER_PERSON
    stock = [[keep, count] for keep, count in larder(inventory) if keep > day]
    fed = 0
    today = day
    while True:
        today += 1
        stock = [lot for lot in stock if lot[0] >= today and lot[1] > 0]
        if sum(count for _, count in stock) < need:
            return fed
        left = need
        for lot in stock:
            took = min(left, lot[1])
            lot[1] -= took
            left -= took
            if left == 0:
                break
        fed += 1


def free(party: "Party") -> bool:
    """Whether this is scene select's free sailing: food never runs out, no monsters."""
    return bool(party.flags.get(SailingSettings.FREE_FLAG))


def people_aboard(party: "Party") -> int:
    """Everyone sailing: the party, bench included."""
    return max(1, len(party.members))


def food_left(party: "Party") -> int:
    """The number the sea shows: how many days the food in the bag reaches."""
    day = 0 if free(party) else int(party.flags.get(DAY_FLAG, 0))
    return days_of_food(party.inventory, people_aboard(party), day)


def eat_a_day(party: "Party") -> bool:
    """One more day at sea: what has spoiled is thrown out, and everyone eats.

    Returns False when there was not enough for everyone: the food ran out.
    """
    day = int(party.flags.get(DAY_FLAG, 0)) + 1
    party.flags[DAY_FLAG] = day
    if free(party):
        return True   # the days pass, nothing is eaten or spoils
    for item in list(party.inventory):
        days = keeps(item)
        if days is not None and days < day:
            del party.inventory[item]
    need = people_aboard(party) * SailingSettings.FOOD_PER_PERSON
    food = sorted((keeps(item), item) for item, count in party.inventory.items()
                  if keeps(item) is not None and count > 0)
    if sum(party.inventory[item] for _, item in food) < need:
        for _, item in food:
            del party.inventory[item]
        return False
    for _, item in food:
        took = min(need, party.inventory[item])
        party.inventory[item] -= took
        if party.inventory[item] <= 0:
            del party.inventory[item]
        need -= took
        if need == 0:
            break
    return True


def go_ashore(party: "Party", place: str) -> None:
    """Landfall at ``place``: the days out start again, and the place is known on the map."""
    party.flags[DAY_FLAG] = 0
    know(party, place)


def know(party: "Party", place: str) -> None:
    """``place``'s name shows on the sea from now on (visited, or marked on Kailo's map)."""
    party.flags[SailingSettings.KNOWN_FLAG + place] = True


def known(party: "Party", place: str) -> bool:
    return bool(party.flags.get(SailingSettings.KNOWN_FLAG + place))


def should_warn(party: "Party", x: float, y: float) -> bool:
    """Whether the food reaches no further than the nearest port and a spare day."""
    if free(party):
        return False
    s = sea()
    _, tiles = s.nearest_port(x, y, [p for p in SailingSettings.PORTS if known(party, p)] or None)
    days_back = math.ceil(tiles / s.boat_speed())
    return food_left(party) <= days_back + SailingSettings.WARN_SPARE_DAYS
