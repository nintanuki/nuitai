"""The date and Data's records: time played and steps walked (Frankie, 10/23).

Each is a party flag, so it saves with the rest. The date is ``date``, the
day counted from SPRING 1 as 1; a save from before it reads as the start,
SUMMER 30. Steps never move it (sailing will). The time played is
``play_seconds``, counted while a game is on (``GameManager``). The steps
are the garden's own count (``systems/garden.py``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from settings import RecordSettings
from systems import garden

if TYPE_CHECKING:
    from systems.party import Party

DATE_FLAG = "date"
TIME_FLAG = "play_seconds"


def day(party: "Party") -> int:
    """The day of the year, 1 (SPRING 1) to 120 (WINTER 30)."""
    return int(party.flags.get(DATE_FLAG, RecordSettings.START_DAY))


def date_text(party: "Party") -> str:
    """The date as the field menu shows it, e.g. ``SUMMER 30``."""
    season, date = divmod(day(party) - 1, RecordSettings.SEASON_DAYS)
    return f"{RecordSettings.SEASONS[season]} {date + 1}"


def add_time(party: "Party", seconds: float) -> None:
    """Count ``seconds`` more played."""
    party.flags[TIME_FLAG] = float(party.flags.get(TIME_FLAG, 0.0)) + seconds


def time_text(party: "Party") -> str:
    """Hours and minutes played since New Game, as ``1:05``."""
    minutes = int(party.flags.get(TIME_FLAG, 0.0)) // 60
    return f"{minutes // 60}:{minutes % 60:02d}"


def steps(party: "Party") -> int:
    """Every step walked since New Game."""
    return garden.steps(party)
