"""The date and the records: time played and steps walked (Frankie, 10/23).

Each is a party flag, so it saves with the rest. The date is ``date``, the
day counted from Mohala 1 as 1; a save from before it reads as the start,
the 30th of Kau. A nap in Kailo's bed moves it on a day, Ho'oilo rolling
back round to Mohala; nothing else does, and nothing in the story or the
fights reads it (Frankie, 10/25). ``slept`` is set by the nap and cleared
when he walks out of his house, where the date shows. The time played is
``play_seconds``, counted while a game is on (``GameManager``). The steps
are the garden's own count (``systems/garden.py``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from settings import RecordSettings
from systems import garden

if TYPE_CHECKING:
    from systems.party import Party

DATE_FLAG = "date"
TIME_FLAG = "play_seconds"
SLEPT_FLAG = "slept"


def day(party: "Party") -> int:
    """The day of the year, 1 (Mohala 1) to 120 (Ho'oilo 30)."""
    return int(party.flags.get(DATE_FLAG, RecordSettings.START_DAY))


def ordinal(number: int) -> str:
    """``1st``, ``2nd``, ``3rd``, ``4th``, ``11th``, ``21st``."""
    suffix = "th" if 10 <= number % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(number % 10, "th")
    return f"{number}{suffix}"


def date_text(party: "Party") -> str:
    """The date as the pop-up shows it, e.g. ``1st of Hauhake``."""
    season, date = divmod(day(party) - 1, RecordSettings.SEASON_DAYS)
    return f"{ordinal(date + 1)} of {RecordSettings.SEASONS[season]}"


def sleep(party: "Party") -> None:
    """A night in Kailo's bed: the next day, and the date to show once he walks out."""
    year = RecordSettings.SEASON_DAYS * len(RecordSettings.SEASONS)
    party.flags[DATE_FLAG] = day(party) % year + 1
    party.flags[SLEPT_FLAG] = True


def add_time(party: "Party", seconds: float) -> None:
    """Count ``seconds`` more played."""
    party.flags[TIME_FLAG] = float(party.flags.get(TIME_FLAG, 0.0)) + seconds


def time_text(party: "Party") -> str:
    """Hours and minutes played since New Game, as ``1:05``."""
    minutes = int(party.flags.get(TIME_FLAG, 0.0)) // 60
    return f"{minutes // 60}:{minutes % 60:02d}"


def steps(party: "Party") -> int:
    """Every step walked since New Game."""
    return garden.steps(party)
