"""The demo's two story scenes, read from the scripts in ``game/shared/``.

``story.md`` (the taro patch) and ``story-wake.md`` (Old Pono's wake)
are the one place their dialogue is written; the browser's story test
reads them too (``game/shared/build.py``, whose rules for writing a
script are at the top of ``story.md``). This module turns a script into
steps and walks them; ``OverworldScene`` shows each step over the field
(the text box, the choice box, the fight) and does what the demo adds
around them (the demo line in ``game/answers.md``).

Only what the demo plays is read: the scene, ``If you win`` and ``If you
lose``. The place, background, music and card are the browser's.
"""

from __future__ import annotations

import os
import re
from typing import Any

from core.shared import SHARED_DIR, by_id

# The demo's scenes by name, and the script each is read from.
SCRIPTS: dict[str, str] = {
    "taro_patch": "story.md",
    "wake": "story-wake.md",
}

WIN, LOSE = "If you win", "If you lose"


def _element(word: str) -> str:
    """An element as the battle names it: the eastern Ahi is the battle's Afi."""
    word = word.lower()
    return "afi" if word == "ahi" else word


def _sprite_for(name: str, monster: str) -> str:
    """A foe named after a sprite gets that sprite ("Wicked Dwende"), else its monster's first."""
    sprite_of: dict[str, str] = {}
    sprites: set[str] = set()
    for encounter in by_id("encounters").values():
        for entry in encounter["enemies"]:
            sprite_of.setdefault(entry["monster"], entry.get("sprite"))
            sprites.add(entry.get("sprite"))
    slug = re.sub(r"\s+[A-Z]$", "", name.strip()).lower().replace(" ", "_")
    return slug if slug in sprites else sprite_of.get(monster, monster)


def read_script(text: str) -> list[dict[str, Any]]:
    """Turn a script into steps, the way ``game/shared/build.py`` reads it.

    A step is one of: ``{"say", "text"}`` someone talking (with ``"if"``
    when it plays only after a choice), ``{"text"}`` narration,
    ``{"choice", "options"}`` with ``(label, flag)`` pairs,
    ``{"fight"}`` the enemies as ``BattleScene`` takes them,
    ``{"label"}`` where ``If you win`` or ``If you lose`` starts, and
    ``{"end"}``.
    """
    steps: list[dict[str, Any]] = []
    section = None
    choice = None
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("# "):
            continue
        if line.startswith("## "):
            section = line[3:]
            if section not in ("Cast", "Scene", "Foes"):
                steps.append({"label": section})
            continue
        if section in (None, "Cast", "Foes"):
            continue
        if choice is not None and line.startswith("- "):
            label, _, flag = line[2:].partition("→")
            choice["options"].append((label.strip(), flag.strip()))
            continue
        choice = None
        match = re.match(r"\*\*(.+?)(?::\*\*|\*\*\s*\(if (\w+)\):)\s*(.*)", line)
        if not match:
            steps.append({"text": line})
            continue
        who, flag, rest = match[1], match[2], match[3]
        if who in ("Place", "Background", "Music", "Card"):
            continue
        if who == "End":
            steps.append({"end": rest})
        elif who == "Choice":
            choice = {"choice": rest, "options": []}
            steps.append(choice)
        elif who == "Fight":
            foes = rest.partition(" against ")[2]
            steps.append({"fight": [
                {"id": f"story_{index}", "name": name.strip(), "monster": monster,
                 "element": _element(element), "sprite": _sprite_for(name, monster)}
                for index, (name, monster, element)
                in enumerate(re.findall(r"([^,(]+?)\s*\((\w+),\s*(\w+)\)", foes))
            ]})
        else:
            step = {"say": who, "text": rest}
            if flag:
                step["if"] = flag
            steps.append(step)
    return steps


def load(name: str) -> list[dict[str, Any]]:
    """The steps of the demo scene ``name`` (``SCRIPTS``)."""
    with open(os.path.join(SHARED_DIR, SCRIPTS[name]), encoding="utf-8") as f:
        return read_script(f.read())


class StoryRunner:
    """Walk one scene's steps: what to show next, a choice made, a fight's end.

    ``next_step`` hands back the next step to show, skipping lines whose
    choice was not made and any ``skip`` test the demo adds, and None once
    the part being played is over (an ``End``, or the next ``If you...``).
    """

    def __init__(self, name: str, skip=None) -> None:
        """Start scene ``name`` at its top.

        Args:
            name: A key of ``SCRIPTS``.
            skip: Called with a step; True leaves it out (the demo's own
                tests, such as a line that needs someone in the party).
        """
        self.name = name
        self.steps = load(name)
        self.index = 0
        self.flags: set[str] = set()
        self.part = "scene"          # "scene", then WIN or LOSE after the fight
        self._fight_at: int | None = None
        self._skip = skip or (lambda step: False)

    def next_step(self) -> dict[str, Any] | None:
        """The next step to show, or None when this part has ended."""
        while self.index < len(self.steps):
            step = self.steps[self.index]
            self.index += 1
            if "label" in step or "end" in step:
                self.index = len(self.steps)
                return None
            if step.get("if") and step["if"] not in self.flags:
                continue
            if self._skip(step):
                continue
            if "fight" in step:
                self._fight_at = self.index - 1
            return step
        return None

    def choose(self, flag: str) -> None:
        """Remember a choice, for the lines that play only after it."""
        self.flags.add(flag)

    def fought(self, won: bool) -> None:
        """Carry on at ``If you win`` or ``If you lose``."""
        self.part = WIN if won else LOSE
        self.index = next(
            index + 1 for index, step in enumerate(self.steps) if step.get("label") == self.part
        )

    def retry(self) -> None:
        """Back to the fight, to try it again (after losing it)."""
        self.part = "scene"
        self.index = self._fight_at if self._fight_at is not None else 0
