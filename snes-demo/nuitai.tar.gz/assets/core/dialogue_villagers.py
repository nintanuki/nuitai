"""The villagers' lines, for the Workshop's lines window (Frankie, 11/1).

What people say on the map lives in the room files (``data/cells/*.json``)
and in the question menus (``data/asks/*.json``), not in the story
scripts, so the lines window could not show the chief, the boy or Keo.
This module shows a room or a menu as a script the window already knows,
and writes the edits back into the JSON, so the game reads what it always
read and nothing is kept in two places.

A room is a script, each person who speaks a scene named for them and
where they stand. Plain lines are said by the person; a ``- talk`` or
``- once FLAG`` direction opens an exchange whose rows each have a
speaker, and ``- more`` goes back to plain lines after one:

    # chief_house
    ## Chief Ulu at 8,10
    - lines
    **Chief Ulu:** Aloha e Kailo. Bring your stew...
    - flag_lines stew_lost
    - talk
    **Chief Ulu:** Kailo. I hear the boars knocked your stew over.
    - more
    **Chief Ulu:** Ever since your dad left...

A menu is a script with a scene for each question, in the file's order.

Saving goes through ``Document.save`` like any file, so the same merge
and the same choosing between versions apply; ``_store`` is the only part
that differs, writing the changed people (or questions) back and nothing else.

No pygame and no tkinter here.
"""

from __future__ import annotations

import json
import os
import re

from core.dialogue_editor import SAY, Document, _write
from core.shared import SHARED_DIR

DATA_DIR = os.path.join(os.path.dirname(SHARED_DIR), "pygame", "data")
PREFIXES = ("cells/", "asks/")
PERSON_HEADING = re.compile(r"^(?P<who>.*) at (?P<col>\d+),(?P<row>\d+)$")


def is_villager_file(name: str) -> bool:
    return name.startswith(PREFIXES)


def path_of(name: str) -> str:
    return os.path.join(DATA_DIR, *name.split("/"))


def villager_files() -> list[str]:
    """Every room and menu with something said in it: ``cells/chief_house.json``..."""
    found = []
    for folder in ("cells", "asks"):
        directory = os.path.join(DATA_DIR, folder)
        if not os.path.isdir(directory):
            continue
        for file in sorted(os.listdir(directory)):
            if file.endswith(".json") and _scenes(folder, os.path.join(directory, file)):
                found.append(f"{folder}/{file}")
    return found


# ----------------------------------------------------------------------
# JSON TO A SCRIPT
# ----------------------------------------------------------------------


def _say(who: str, text: str, along: str = "") -> str:
    return f"**{who}** (if {along}): {text}" if along else f"**{who}:** {text}"


def _row(row: list) -> str:
    return _say(row[0], row[1], row[2] if len(row) > 2 else "")


def _items(items: list, speaker: str) -> list[str]:
    """A list of plain lines and exchanges as the script's lines."""
    out: list[str] = []
    exchange = False
    for item in items:
        if isinstance(item, dict):
            out.append(f"- once {item['once']}" if item.get("once") else "- talk")
            out.extend(_row(row) for row in item["talk"])
            exchange = True
        else:
            if exchange:
                out.append("- more")
                exchange = False
            out.append(_say(speaker, item))
    return out


def person_lines(person: dict) -> list[str]:
    """What one person says, as script lines; empty if they say nothing."""
    speaker = person.get("speaker", "")
    out: list[str] = []
    if person.get("lines"):
        out += ["- lines", *_items(person["lines"], speaker)]
    if person.get("night_lines"):
        out += ["- night_lines", *_items(person["night_lines"], speaker)]
    for flag, items in (person.get("flag_lines") or {}).items():
        out += [f"- flag_lines {flag}", *_items(items, speaker)]
    gift = person.get("gift") or {}
    if gift.get("lines"):
        out += ["- gift.lines", *_items(gift["lines"], speaker)]
    first = person.get("first") or {}
    if first.get("talk"):
        out += ["- first.talk", *(_row(row) for row in first["talk"])]
    if first.get("lines"):
        out += ["- first.lines", *_items(first["lines"], speaker)]
    return out


def _scenes(folder: str, path: str) -> list[tuple[str, list[str]]]:
    """(heading, lines) for each scene of a room or menu file."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if folder == "asks":
        return [(question["ask"], [_row(row) for row in question["lines"]])
                for question in data.get("questions", [])]
    scenes = []
    for person in data.get("people", []):
        lines = person_lines(person)
        if lines:
            who = person.get("speaker") or person.get("sheet", "")
            scenes.append((f"{who} at {person['col']},{person['row']}", lines))
    return scenes


def synthesize(path: str) -> list[str]:
    folder = os.path.basename(os.path.dirname(path))
    lines = [f"# {os.path.splitext(os.path.basename(path))[0]}", ""]
    for heading, scene in _scenes(folder, path):
        lines += [f"## {heading}", *scene, ""]
    return [line + "\n" for line in lines]


# ----------------------------------------------------------------------
# A SCRIPT BACK TO JSON
# ----------------------------------------------------------------------


def _split(lines: list[str]) -> list[tuple[str, list[str]]]:
    """The scenes of a synthesized script: (heading, its non-blank lines)."""
    scenes: list[tuple[str, list[str]]] = []
    for raw in lines:
        line = raw.rstrip("\r\n")
        if line.startswith("## "):
            scenes.append((line[3:].strip(), []))
        elif scenes and line.strip():
            scenes[-1][1].append(line.strip())
    return scenes


def _spoken(line: str) -> list[str]:
    match = SAY.match(line)
    if match is None:
        raise ValueError(f"Cannot read this line: {line}")
    row = [match["who"], match["rest"].strip()]
    return row + [match["cond"]] if match["cond"] else row


def _field(lines: list[str], plain: bool) -> list:
    """One field's script lines as the list the room file holds."""
    out: list = []
    exchange: dict | None = None
    for line in lines:
        if line.startswith("- "):
            word, _, flag = line[2:].partition(" ")
            if word == "talk":
                exchange = {"talk": []}
            elif word == "once":
                exchange = {"once": flag.strip(), "talk": []}
            else:
                exchange = None
                continue
            out.append(exchange)
        elif exchange is not None:
            exchange["talk"].append(_spoken(line))
        elif plain:
            out.append(_spoken(line)[1])
        else:
            out.append(_spoken(line))
    return out


def rebuild_person(person: dict, lines: list[str]) -> dict:
    """``person`` with its spoken fields read from the script ``lines``."""
    fields: dict[str, list[str]] = {}
    key = None
    for line in lines:
        if line.startswith("- ") and line[2:].partition(" ")[0] in ("lines", "night_lines", "flag_lines",
                                                                     "first.talk", "first.lines", "gift.lines"):
            key = line[2:].strip()
            fields[key] = []
        elif key is not None:
            fields[key].append(line)
    rebuilt = dict(person)
    for key, body in fields.items():
        if key == "lines" or key == "night_lines":
            rebuilt[key] = _field(body, True)
        elif key.startswith("flag_lines "):
            flags = dict(rebuilt.get("flag_lines") or {})
            flags[key.partition(" ")[2]] = _field(body, True)
            rebuilt["flag_lines"] = flags
        elif key == "first.talk":
            rebuilt["first"] = {**rebuilt.get("first", {}), "talk": [_spoken(line) for line in body]}
        elif key == "gift.lines":
            rebuilt["gift"] = {**rebuilt.get("gift", {}), "lines": _field(body, True)}
        elif key == "first.lines":
            rebuilt["first"] = {**rebuilt.get("first", {}), "lines": _field(body, True)}
    return rebuilt


def _people_lines(raw: list[str]) -> list[int]:
    """Where each person is in a room file's text: one line each, under ``"people": [``."""
    start = next(i for i, line in enumerate(raw) if line.strip() == '"people": [')
    found = []
    for i in range(start + 1, len(raw)):
        if raw[i].startswith("  ]"):
            break
        found.append(i)
    return found


def write_back(path: str, edited: list[str]) -> None:
    """Put the edited script's lines into the room or menu file; only what changed is written."""
    folder = os.path.basename(os.path.dirname(path))
    scenes = _split(edited)
    with open(path, encoding="utf-8", newline="") as f:
        text = f.read()
    if folder == "asks":
        data = json.loads(text)
        questions = data["questions"]
        if len(scenes) != len(questions):
            raise ValueError("A menu's questions cannot be added or removed here, only their lines.")
        for question, (_heading, body) in zip(questions, scenes):
            question["lines"] = [_spoken(line) for line in body]
        _write(path, _format_asks(text, data))
        return
    raw = text.splitlines(keepends=True)
    data = json.loads(text)
    spots = _people_lines(raw)
    at = {(p["col"], p["row"]): k for k, p in enumerate(data["people"])}
    for heading, body in scenes:
        match = PERSON_HEADING.match(heading)
        if match is None or (int(match["col"]), int(match["row"])) not in at:
            raise ValueError(f"{os.path.basename(path)} has no one at '{heading}' now.")
        k = at[(int(match["col"]), int(match["row"]))]
        person = data["people"][k]
        rebuilt = rebuild_person(person, body)
        if rebuilt != person:
            line = raw[spots[k]]
            comma = "," if line.rstrip().endswith(",") else ""
            ending = line[len(line.rstrip("\r\n")):]
            escaped = "\\u" in line     # keep each file's way with accented letters
            raw[spots[k]] = f"    {json.dumps(rebuilt, ensure_ascii=escaped)}{comma}{ending}"
    _write(path, "".join(raw))


def _format_asks(text: str, data: dict) -> str:
    """A menu file as it is written: the head kept as it is, one question per block."""
    head = text[:text.index('"questions": [')]
    out = [head + '"questions": [']
    questions = data["questions"]
    escaped = "\\u" in text
    for i, question in enumerate(questions):
        keys = [f"{json.dumps(k)}: {json.dumps(v, ensure_ascii=escaped)}" for k, v in question.items() if k != "lines"]
        rows = ",\n".join(f"      {json.dumps(row, ensure_ascii=escaped)}" for row in question["lines"])
        comma = "," if i < len(questions) - 1 else ""
        out.append(f'    {{{", ".join(keys)}, "lines": [\n{rows}\n    ]}}{comma}')
    return "\n".join(out) + "\n  ]\n}\n"


# ----------------------------------------------------------------------
# THE DOCUMENT
# ----------------------------------------------------------------------


class VillagerDocument(Document):
    """A room or a menu, kept as a script and saved into its JSON."""

    def _read(self) -> list[str]:
        return synthesize(self.path)

    def _store(self, merged: list[str]) -> None:
        write_back(self.path, merged)
