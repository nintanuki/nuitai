"""Generated places: rooms made fresh from a seed, different every game (D-731).

The map has two kinds of room. Named places (the town, the boss's field)
are painted in the Workshop and kept in ``data/cells/``; they never
change. A generated place is a stretch of the map described in
``data/generated/<id>.json`` and built when a game starts, so every
playthrough walks a different one. The objective, the boss and the kinds
of monster stay the same, because those are set in the description and
in the named rooms around it; only the layout moves.

A description gives:

* ``entered_from``: the named rooms the party walks in from; the
  rooms beside them are the shallow end.
* ``area``: the world-grid slots the place may use, ``x`` and ``y`` as
  ``[low, high]``. The game skips any painted room in the area: the
  place takes it over, and the room's file stays for the Workshop.
* ``rooms``: ``[fewest, most]`` rooms to build.
* ``loops``: how many extra doorways to add after the paths are made, so
  the place is not only one branching path.
* ``trees``: ``clumps`` of palms per room as ``[fewest, most]``, and
  ``deeper``, how many more a room at the far end gets.
* ``spring_chance`` and ``pond_chance``: the odds a room has a healing
  pond, or a small pool of water.
* ``pack``: more slots in every monster's fight, so its own kind comes in bigger
  groups (Kupulau, Frankie 11/1); left out, none.
* ``monsters_per_room`` as ``[fewest, most]``, and ``monsters``: bands of
  ``depth`` (0 at the way in, 1 at the far end) each with the ``kinds``
  from ``data/field_monsters/`` that walk there, by weight.

How a place is built, in plain steps:

1. Which slots are rooms. A random tree is grown over every free slot,
   then rooms are pruned off its ends until the count is right. A slot
   that a named room has a doorway into is never pruned, so every door
   from a named room leads somewhere.
2. Doorways. Two rooms joined in the tree get a two-tile gap in the
   palms between them, at the same spot on both sides. A side facing a
   named room copies that room's gaps.
3. Inside a room. Clumps of palms, maybe a pond or a spring, then a sand
   trail dug from every doorway to the middle so nothing is ever shut
   off, then any grass the trail cannot reach is filled with palms.
4. Monsters, on open grass away from the doorways, harder the further
   in the room is, and every kind the description lists at least once.

The same seed always builds the same place. The seed is kept in the save,
so a loaded game walks the woods it left.
"""

from __future__ import annotations

import json
import os
import random

from core import overworld_cells as cells
from settings import OverworldSettings

GENERATED_DIR = os.path.join(cells.ROOT, "data", "generated")

WALL = OverworldSettings.WALL_CHAR
FLOOR = OverworldSettings.FLOOR_CHAR
SAND = OverworldSettings.SAND_CHAR
WATER = OverworldSettings.WATER_CHAR
SPRING = OverworldSettings.SPRING_CHAR
WALKABLE = (FLOOR, SAND)
COLS, ROWS = OverworldSettings.COLS, OverworldSettings.ROWS

# (dx, dy) to the room next door, and the name of that side.
SIDES: dict[str, tuple[int, int]] = {"north": (0, -1), "south": (0, 1), "west": (-1, 0), "east": (1, 0)}
OPPOSITE = {"north": "south", "south": "north", "west": "east", "east": "west"}

# The rooms the last ``install`` put in, so the next one can take them out.
INSTALLED: set[str] = set()


def load_places(directory: str = GENERATED_DIR) -> list[dict]:
    """Every place description in ``directory``, in file order."""
    places = []
    if os.path.isdir(directory):
        for file_name in sorted(os.listdir(directory)):
            if file_name.endswith(".json"):
                with open(os.path.join(directory, file_name), "r", encoding="utf-8") as f:
                    places.append(json.load(f))
    return places


# ----------------------------------------------------------------------
# EDGES
# ----------------------------------------------------------------------

def edge_tiles(side: str) -> list[tuple[int, int]]:
    """The (col, row) tiles along one side of a room, in order."""
    if side == "north":
        return [(c, 0) for c in range(COLS)]
    if side == "south":
        return [(c, ROWS - 1) for c in range(COLS)]
    if side == "west":
        return [(0, r) for r in range(ROWS)]
    return [(COLS - 1, r) for r in range(ROWS)]


def open_spots(grid: list[list[str]], side: str) -> list[int]:
    """Which places along a side are walkable, counted along that side."""
    return [i for i, (c, r) in enumerate(edge_tiles(side)) if grid[r][c] in WALKABLE]


def _inside(col: int, row: int, side: str) -> tuple[int, int]:
    """The tile one step into the room from an edge tile."""
    dx, dy = SIDES[side]
    return col - dx, row - dy


# ----------------------------------------------------------------------
# WHICH SLOTS ARE ROOMS
# ----------------------------------------------------------------------

def area_slots(place: dict) -> set[tuple[int, int]]:
    """Every world-grid slot in the place's area."""
    (x0, x1), (y0, y1) = place["area"]["x"], place["area"]["y"]
    return {(x, y) for x in range(x0, x1 + 1) for y in range(y0, y1 + 1)}


def _grow(free: set, required: set, rng: random.Random, target: int):
    """One random tree over ``free``, pruned toward ``target`` rooms; returns (slots, joins)."""
    start = min(required) if required else min(free)
    tree: set[frozenset] = set()
    seen = {start}
    frontier = [start]
    while frontier:
        slot = frontier[rng.randrange(len(frontier))]
        options = [
            (slot[0] + dx, slot[1] + dy) for dx, dy in SIDES.values()
            if (slot[0] + dx, slot[1] + dy) in free and (slot[0] + dx, slot[1] + dy) not in seen
        ]
        if not options:
            frontier.remove(slot)
            continue
        nxt = rng.choice(options)
        tree.add(frozenset((slot, nxt)))
        seen.add(nxt)
        frontier.append(nxt)
    slots = set(seen)
    while len(slots) > target:
        ends = [s for s in slots if s not in required
                and sum(1 for j in tree if s in j) <= 1]
        if not ends:
            break
        cut = rng.choice(sorted(ends))
        slots.discard(cut)
        tree = {j for j in tree if cut not in j}
    return slots, tree


def _plan(place: dict, rng: random.Random, layout: dict, grids: dict):
    """Pick the slots and the doorways between them.

    Returns ``(slots, joins, fixed_doors)``: the chosen slots, the pairs
    of slots joined by a doorway, and for each slot the sides that face a
    named room with a doorway, mapped to that room's open spots.
    """
    free = area_slots(place)

    fixed_doors: dict[tuple[int, int], dict[str, list[int]]] = {}
    for slot in free:
        for side, (dx, dy) in SIDES.items():
            neighbor = layout.get((slot[0] + dx, slot[1] + dy))
            if neighbor is None:
                continue
            spots = open_spots(grids[neighbor], OPPOSITE[side])
            if spots:
                fixed_doors.setdefault(slot, {})[side] = spots
    required = set(fixed_doors)

    # A random tree over the free slots, grown from one required slot,
    # then ends that no named room needs pruned until the count is right.
    # A tree whose needed part alone is too big is grown again.
    target = rng.randint(*place["rooms"])
    for _ in range(20):
        slots, tree = _grow(free, required, rng, target)
        if len(slots) <= target:
            break
    # A few extra doorways between rooms side by side.
    extra = [
        frozenset((a, (a[0] + dx, a[1] + dy)))
        for a in sorted(slots) for dx, dy in ((1, 0), (0, 1))
        if (a[0] + dx, a[1] + dy) in slots and frozenset((a, (a[0] + dx, a[1] + dy))) not in tree
    ]
    rng.shuffle(extra)
    joins = tree | set(extra[: place.get("loops", 0)])
    return slots, joins, fixed_doors


def _depths(slots: set, joins: set, starts: set) -> dict[tuple[int, int], float]:
    """How far in each room is, 0 at the doors from named rooms and 1 at the far end."""
    distance = {s: 0 for s in starts if s in slots}
    queue = list(distance)
    while queue:
        slot = queue.pop(0)
        for join in joins:
            if slot in join:
                (other,) = join - {slot}
                if other not in distance:
                    distance[other] = distance[slot] + 1
                    queue.append(other)
    far = max(distance.values(), default=0) or 1
    return {s: distance.get(s, 0) / far for s in slots}


# ----------------------------------------------------------------------
# ONE ROOM
# ----------------------------------------------------------------------

def _room(place: dict, rng: random.Random, doors: dict[str, list[int]], depth: float) -> list[list[str]]:
    """Build one room's grid with doorways at ``doors`` (side to open spots)."""
    grid = [[WALL] * COLS for _ in range(ROWS)]
    for r in range(1, ROWS - 1):
        for c in range(1, COLS - 1):
            grid[r][c] = FLOOR

    # Palms in clumps, more of them deeper in.
    low, high = place["trees"]["clumps"]
    clumps = rng.randint(low, high) + round(place["trees"].get("deeper", 0) * depth)
    for _ in range(clumps):
        cc, cr = rng.randint(2, COLS - 3), rng.randint(2, ROWS - 3)
        radius = rng.choice((0, 1, 1, 2))
        for r in range(cr - radius, cr + radius + 1):
            for c in range(cc - radius, cc + radius + 1):
                if 1 <= r < ROWS - 1 and 1 <= c < COLS - 1 and rng.random() < 0.75:
                    grid[r][c] = WALL

    # Maybe a small pool, maybe a healing spring.
    if rng.random() < place.get("pond_chance", 0):
        pc, pr = rng.randint(3, COLS - 5), rng.randint(3, ROWS - 5)
        for r in (pr, pr + 1):
            for c in (pc, pc + 1):
                grid[r][c] = WATER
    if rng.random() < place.get("spring_chance", 0):
        grid[rng.randint(3, ROWS - 4)][rng.randint(3, COLS - 4)] = SPRING

    # Doorways, and a sand trail from each one to the middle.
    hub = (rng.randint(6, 9), rng.randint(5, 8))
    starts = []
    for side, spots in doors.items():
        tiles = edge_tiles(side)
        for i in spots:
            c, r = tiles[i]
            grid[r][c] = SAND
            starts.append(_inside(c, r, side))
    for c, r in starts:
        while (c, r) != hub:
            grid[r][c] = SAND
            dc, dr = hub[0] - c, hub[1] - r
            if rng.random() < 0.3:
                # Wander a step sideways, so the trail is not a ruler line.
                if dc and rng.random() < 0.5:
                    dr = rng.choice((-1, 1))
                    dc = 0
                elif dr:
                    dc = rng.choice((-1, 1))
                    dr = 0
            if dc and (not dr or rng.random() < 0.5):
                c += 1 if dc > 0 else -1
            elif dr:
                r += 1 if dr > 0 else -1
            c = min(max(c, 1), COLS - 2)
            r = min(max(r, 1), ROWS - 2)
        grid[r][c] = SAND

    # Grass the trail cannot reach becomes palms. A spring beside the
    # reachable ground stays; one shut in by palms is useless, so it goes.
    reach = _reachable(grid, hub)
    for r in range(ROWS):
        for c in range(COLS):
            if grid[r][c] in WALKABLE and (c, r) not in reach:
                grid[r][c] = WALL
            if grid[r][c] == SPRING and not any(
                (c + dx, r + dy) in reach for dx, dy in SIDES.values()
            ):
                grid[r][c] = WALL
    return grid


def _reachable(grid: list[list[str]], start: tuple[int, int]) -> set[tuple[int, int]]:
    """Every walkable tile a party can walk to from ``start``."""
    seen = {start}
    queue = [start]
    while queue:
        c, r = queue.pop()
        for dx, dy in SIDES.values():
            n = (c + dx, r + dy)
            if 0 <= n[0] < COLS and 0 <= n[1] < ROWS and n not in seen and grid[n[1]][n[0]] in WALKABLE:
                seen.add(n)
                queue.append(n)
    return seen


def _monsters(place: dict, rng: random.Random, grid: list[list[str]],
              doors: dict[str, list[int]], depth: float) -> list[dict]:
    """Stand this room's monsters on open grass, away from the doorways."""
    band = _band(place, depth)
    kinds, weights = zip(*sorted(band["kinds"].items()))
    near_door = set()
    for side, spots in doors.items():
        for i in spots:
            c, r = edge_tiles(side)[i]
            near_door |= {(c + dx, r + dy) for dx in range(-3, 4) for dy in range(-3, 4)}
    open_tiles = [
        (c, r) for r in range(2, ROWS - 2) for c in range(2, COLS - 2)
        if grid[r][c] == FLOOR and (c, r) not in near_door
    ]
    rng.shuffle(open_tiles)
    spots: list[dict] = []
    count = rng.randint(*place["monsters_per_room"])
    for c, r in open_tiles:
        if len(spots) >= count:
            break
        if any(abs(c - s["col"]) < 3 and abs(r - s["row"]) < 3 for s in spots):
            continue
        spots.append({"col": c, "row": r, "kind": rng.choices(kinds, weights)[0]})
        if place.get("pack"):
            spots[-1]["pack"] = place["pack"]
    return spots


# ----------------------------------------------------------------------
# A WHOLE PLACE
# ----------------------------------------------------------------------

def generate(place: dict, seed: int, layout: dict | None = None,
             grids: dict | None = None) -> list[dict]:
    """Build every room of ``place`` from ``seed``, around the named rooms.

    ``layout`` and ``grids`` are the named rooms (position to name, name
    to grid); they default to the rooms loaded from ``data/cells/``.
    Returns room entries shaped like a room file's (``id``, ``pos``,
    ``grid``, ``people``, ``monsters``).
    """
    layout = cells.WORLD_LAYOUT if layout is None else layout
    grids = cells.CELLS if grids is None else grids
    area = area_slots(place)
    layout = {pos: name for pos, name in layout.items() if pos not in area}
    rng = random.Random(f"{place['id']}:{seed}")
    slots, joins, fixed_doors = _plan(place, rng, layout, grids)
    entrances = {
        slot for slot in slots for side, (dx, dy) in SIDES.items()
        if side in fixed_doors.get(slot, {})
        and layout.get((slot[0] + dx, slot[1] + dy)) in place.get("entered_from", [])
    }
    depth = _depths(slots, joins, entrances or set(fixed_doors))

    # One doorway spot per join, shared by both rooms.
    doors: dict[tuple[int, int], dict[str, list[int]]] = {s: dict(fixed_doors.get(s, {})) for s in slots}
    for join in sorted(joins, key=sorted):
        a, b = sorted(join)
        side = "east" if b[0] > a[0] else "south"
        length = COLS if side == "south" else ROWS
        at = rng.randint(2, length - 4)
        doors[a][side] = [at, at + 1]
        doors[b][OPPOSITE[side]] = [at, at + 1]

    rooms = []
    for index, slot in enumerate(sorted(slots, key=lambda s: (-s[1], s[0])), start=1):
        grid = _room(place, rng, doors[slot], depth[slot])
        rooms.append({
            "id": f"{place['id']}_{index}",
            "pos": slot,
            "grid": grid,
            "people": [],
            "monsters": _monsters(place, rng, grid, doors[slot], depth[slot]),
            "depth": depth[slot],
        })
    _every_kind(place, rooms)
    for room in rooms:
        del room["depth"]
    return rooms


def _band(place: dict, depth: float) -> dict:
    """The monster band a room this far in draws from."""
    return next((b for b in place["monsters"] if b["depth"][0] <= depth <= b["depth"][1]),
                place["monsters"][-1])


def _every_kind(place: dict, rooms: list[dict]) -> None:
    """Make sure every kind the place lists walks somewhere in it.

    The lodge's bounties are posted one after another and only move on when
    one is done, so a kind the dice left out (a woods with no kapre)
    would stop them for good. A missing kind takes the place of a monster
    in the deepest room whose band has it, one of a kind there is more
    than one of. No dice, so the same seed still builds the same woods.
    """
    kinds = sorted({k for band in place["monsters"] for k in band["kinds"]})
    for kind in kinds:
        counts: dict[str, int] = {}
        for room in rooms:
            for m in room["monsters"]:
                counts[m["kind"]] = counts.get(m["kind"], 0) + 1
        if counts.get(kind):
            continue
        for room in sorted(rooms, key=lambda r: (-r["depth"], r["id"])):
            if kind not in _band(place, room["depth"])["kinds"]:
                continue
            spare = next((m for m in room["monsters"] if counts[m["kind"]] > 1), None)
            if spare is not None:
                spare["kind"] = kind
                break


def reachable_rooms(layout: dict, grids: dict, start: tuple[int, int]) -> set[str]:
    """Every room the party can reach on foot from the middle of ``start``'s room."""
    seen = set()
    queue = [(start, (COLS // 2, ROWS // 2))]
    while queue:
        pos, (c, r) = queue.pop()
        if (pos, c, r) in seen:
            continue
        seen.add((pos, c, r))
        for dx, dy in SIDES.values():
            nc, nr, npos = c + dx, r + dy, pos
            if not (0 <= nc < COLS and 0 <= nr < ROWS):
                npos = (pos[0] + dx, pos[1] + dy)
                if npos not in layout:
                    continue
                nc, nr = nc % COLS, nr % ROWS
            if grids[layout[npos]][nr][nc] in WALKABLE:
                queue.append((npos, (nc, nr)))
    return {layout[pos] for pos, _, _ in seen}


def _walkable_back(place: dict, rooms: list[dict], layout: dict, grids: dict) -> bool:
    """True if every room of ``rooms`` leads back to the room the place is entered from.

    The party must never be stuck in a generated place (no field ability
    is ever needed there), so this is checked before anyone walks in.
    """
    layout = dict(layout)
    grids = dict(grids)
    for room in rooms:
        layout[room["pos"]] = room["id"]
        grids[room["id"]] = room["grid"]
    way_out = next((pos for pos, name in layout.items() if name in place.get("entered_from", [])), None)
    if way_out is None:
        return True
    reached = reachable_rooms(layout, grids, way_out)
    return all(room["id"] in reached for room in rooms)


def install(seed: int) -> None:
    """Build every generated place from ``seed`` into the game's rooms.

    Takes out the rooms the last call put in first, so a new game or a
    loaded one replaces the woods instead of stacking a second copy, and
    takes out any painted room standing in a place's area.
    """
    for name in INSTALLED:
        cells.CELLS.pop(name, None)
        cells.PEOPLE.pop(name, None)
        cells.FIELD_MONSTERS.pop(name, None)
    for pos in [pos for pos, name in cells.WORLD_LAYOUT.items() if name in INSTALLED]:
        del cells.WORLD_LAYOUT[pos]
    INSTALLED.clear()
    for place in load_places():
        area = area_slots(place)
        for pos in [pos for pos in cells.WORLD_LAYOUT if pos in area]:
            name = cells.WORLD_LAYOUT.pop(pos)
            cells.CELLS.pop(name, None)
            cells.PEOPLE.pop(name, None)
            cells.FIELD_MONSTERS.pop(name, None)
        named = {pos: name for pos, name in cells.WORLD_LAYOUT.items()}
        # A place that would leave a room shut off is built again from the
        # next seed; the save keeps the first seed, so this is repeatable.
        for attempt in range(20):
            rooms = generate(place, seed + attempt * 7919)
            if _walkable_back(place, rooms, named, cells.CELLS):
                break
        for room in rooms:
            name = room["id"]
            cells.CELLS[name] = room["grid"]
            cells.PEOPLE[name] = room["people"]
            cells.FIELD_MONSTERS[name] = room["monsters"]
            cells.WORLD_LAYOUT[room["pos"]] = name
            INSTALLED.add(name)
