"""The lines said on the field, read from ``game/shared/story-field.md`` (Frankie, 10/31).

They lived in ``settings.py`` as strings; Frankie wanted every line of
dialogue in one place, to edit in the Workshop's lines window like the
story scenes. ``settings.py`` keeps every name the game and the
cartridge build read (``StewSettings.OFFER_LINES``...) and fills it from
here, so nothing else changed. How the file is written is at its top.

No imports from the game: ``settings.py`` reads this as it loads.
"""

from __future__ import annotations

import os
import re

from core.shared import SHARED_DIR

PATH = os.path.join(SHARED_DIR, "story-field.md")
# ``**Noelani:** words``: the name shows who says it; the game decides that.
_SPOKEN = re.compile(r"\*\*[^*]+?:\*\*\s?(.*)")


def read(text: str) -> dict[str, dict[str, list[str]]]:
    """Heading, then name (``OFFER_LINES``, or ``EDGE_LINES harbor``), then its lines in order."""
    found: dict[str, dict[str, list[str]]] = {}
    heading = key = None
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith("## "):
            heading, key = line[3:].strip(), None
            found[heading] = {}
        elif heading is None or not line:
            continue
        elif line.startswith("- "):
            key = " ".join(line[2:].split())
            found[heading][key] = []
        elif key is not None:
            spoken = _SPOKEN.fullmatch(line)
            found[heading][key].append(spoken[1] if spoken else line)
    return found


class FieldLines:
    """The file, read once; ``one``, ``many`` and ``keyed`` hand ``settings.py`` its values."""

    def __init__(self, path: str = PATH) -> None:
        with open(path, encoding="utf-8") as f:
            self.lines = read(f.read())
        self.path = path

    def _get(self, heading: str, key: str) -> list[str]:
        try:
            return self.lines[heading][key]
        except KeyError:
            raise KeyError(f"{os.path.basename(self.path)} has no '- {key}' under '## {heading}'") from None

    def one(self, heading: str, key: str) -> str:
        """A name with exactly one line."""
        lines = self._get(heading, key)
        if len(lines) != 1:
            raise ValueError(f"'- {key}' under '## {heading}' needs exactly one line; it has {len(lines)}")
        return lines[0]

    def many(self, heading: str, key: str) -> tuple[str, ...]:
        """A name ending in LINES: its lines, said in order."""
        return tuple(self._get(heading, key))

    def keyed(self, heading: str, key: str) -> dict[str, str]:
        """``- EDGE_LINES harbor`` and its kin: one line for each place or person."""
        prefix = key + " "
        return {name[len(prefix):]: self.one(heading, name)
                for name in self.lines.get(heading, {}) if name.startswith(prefix)}
