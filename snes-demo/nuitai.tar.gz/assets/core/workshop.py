"""The Workshop's model: the rooms as things to edit. No pygame in here.

``workshop.py`` at the top of the game folder is the window; this is
what it edits. Everything here works on the dicts in
``core/overworld_cells.py`` in place, so the same rooms the game walks
are the ones being painted, and ``save`` writes them back to
``data/cells/``.

A *brush* is what a click puts down: a tile (one character of the
alphabet), a monster (a kind from ``data/field_monsters/``) or a person
(a walk sheet from ``AssetPaths.PEOPLE_DIR``). A monster placed from a
kind that has a fixed ``encounter`` is a boss: it stands still and is
gone for good once beaten, like the Great Boar.

Undo is one snapshot of the room per change: a stroke of painting (mouse
down to mouse up) is one change, so is placing or removing a thing.
"""

from __future__ import annotations

import copy
import os
import re
from dataclasses import dataclass

from core import generated, overworld_cells as cells
from core.data_loader import DATA_DIR, DataLoader
from settings import AssetPaths, OverworldSettings

# The tiles a brush can paint, in palette order, and what to call each.
TILE_ORDER: tuple[str, ...] = (
    OverworldSettings.FLOOR_CHAR,
    OverworldSettings.SAND_CHAR,
    OverworldSettings.WATER_CHAR,
    OverworldSettings.WALL_CHAR,
    OverworldSettings.SPRING_CHAR,
    OverworldSettings.STALL_CHAR,
)
TILE_NAMES: dict[str, str] = {
    OverworldSettings.FLOOR_CHAR: "GRASS",
    OverworldSettings.SAND_CHAR: "SAND",
    OverworldSettings.WATER_CHAR: "WATER",
    OverworldSettings.WALL_CHAR: "PALM",
    OverworldSettings.SPRING_CHAR: "POND",
    OverworldSettings.STALL_CHAR: "STALL",
}
WALKABLE: tuple[str, ...] = (OverworldSettings.FLOOR_CHAR, OverworldSettings.SAND_CHAR)

# A person turns through these, in this order, each time they are turned.
FACINGS: tuple[tuple[int, int], ...] = ((0, 1), (-1, 0), (0, -1), (1, 0))
FACING_NAMES: dict[tuple[int, int], str] = {
    (0, 1): "DOWN", (-1, 0): "LEFT", (0, -1): "UP", (1, 0): "RIGHT",
}

ROOM_NAME = re.compile(r"^[a-z0-9_]+$")
UNDO_DEPTH = 50


def generated_slots() -> set[tuple[int, int]]:
    """The map slots generated places fill (the woods, D-731).

    The Workshop is for the permanent rooms (Frankie, 10/21), so it makes
    no room there; the game builds those rooms fresh every new game.
    """
    slots: set[tuple[int, int]] = set()
    for place in generated.load_places():
        slots |= generated.area_slots(place)
    return slots


@dataclass(frozen=True)
class Brush:
    """What a click puts down."""

    kind: str   # "tile", "monster" or "person"
    key: str    # the tile character, the monster kind's id, or the person's sheet name
    label: str  # what the bar calls it


def _words(name: str) -> str:
    """``nuno_sa_punso`` and ``OldMan`` both become capital words."""
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", name).replace("_", " ")
    return spaced.upper()


def list_person_sheets(directory: str = AssetPaths.PEOPLE_DIR) -> list[str]:
    """The walk sheets people can be drawn from, by name, ``<Name>-Walk.png``."""
    if not os.path.isdir(directory):
        return []
    suffix = "-Walk.png"
    return sorted(
        name[: -len(suffix)] for name in os.listdir(directory) if name.endswith(suffix)
    )


class Workshop:
    """The rooms, one open for editing, with undo and save."""

    def __init__(self, directory: str = cells.CELLS_DIR, data_dir: str = DATA_DIR,
                 people_dir: str = AssetPaths.PEOPLE_DIR) -> None:
        """Load the rooms from ``directory`` and open the starting one."""
        self.directory = directory
        cells.load_cells(directory)
        self.monster_kinds: dict[str, dict] = DataLoader(data_dir).load("field_monsters")
        self.person_sheets: list[str] = list_person_sheets(people_dir)
        self.brushes: list[Brush] = (
            [Brush("tile", char, TILE_NAMES[char]) for char in TILE_ORDER]
            + [Brush("monster", kind, _words(kind)) for kind in sorted(self.monster_kinds)]
            + [Brush("person", sheet, _words(sheet)) for sheet in self.person_sheets]
        )
        self.brush: Brush = self.brushes[0]
        self.current: str | None = None
        self.dirty: set[str] = set()
        self._undo: dict[str, list[tuple]] = {}
        self._stroke_open = False
        self._stroke_snapped = False
        # Files to remove at the next save: rooms renamed or deleted.
        self._old_files: set[str] = set()
        start = cells.WORLD_LAYOUT.get(cells.START_CELL_POS)
        if start is None and cells.CELLS:
            start = sorted(cells.CELLS)[0]
        if start is not None:
            self.open(start)

    # ------------------------------------------------------------------
    # ROOMS
    # ------------------------------------------------------------------

    @property
    def names(self) -> list[str]:
        """Every room, by name."""
        return sorted(cells.CELLS)

    def pos_of(self, name: str) -> tuple[int, int] | None:
        """Where a room sits on the world grid."""
        for pos, who in cells.WORLD_LAYOUT.items():
            if who == name:
                return pos
        return None

    def room_at(self, pos: tuple[int, int]) -> str | None:
        """The room at a world position, if any."""
        return cells.WORLD_LAYOUT.get(tuple(pos))

    @property
    def pos(self) -> tuple[int, int]:
        """Where the open room sits."""
        return self.pos_of(self.current) or (0, 0)

    @property
    def grid(self) -> list[list[str]]:
        """The open room's tiles."""
        return cells.CELLS[self.current]

    @property
    def people(self) -> list[dict]:
        """Who stands in the open room."""
        return cells.PEOPLE.setdefault(self.current, [])

    @property
    def monsters(self) -> list[dict]:
        """The monsters in the open room."""
        return cells.FIELD_MONSTERS.setdefault(self.current, [])

    def bounds(self) -> tuple[int, int, int, int]:
        """``(min_cx, min_cy, max_cx, max_cy)`` of every room, or zeros."""
        if not cells.WORLD_LAYOUT:
            return (0, 0, 0, 0)
        xs = [pos[0] for pos in cells.WORLD_LAYOUT]
        ys = [pos[1] for pos in cells.WORLD_LAYOUT]
        return (min(xs), min(ys), max(xs), max(ys))

    def open(self, name: str) -> None:
        """Make ``name`` the room being edited."""
        if name not in cells.CELLS:
            raise KeyError(name)
        self._stroke_open = False
        self.current = name

    def open_at(self, pos: tuple[int, int]) -> bool:
        """Open the room at ``pos``; False when there is none."""
        name = self.room_at(pos)
        if name is None:
            return False
        self.open(name)
        return True

    def new_room(self, pos: tuple[int, int], name: str | None = None) -> str:
        """Make a room at ``pos`` and open it: a ring of palms around grass.

        Where a neighbor's touching edge is open, the new room's edge is
        opened at the same tiles, so the two already join.
        """
        pos = (int(pos[0]), int(pos[1]))
        if pos in cells.WORLD_LAYOUT:
            raise ValueError(f"A room already sits at {pos}.")
        if pos in generated_slots():
            raise ValueError(f"{pos} is in a generated place; its rooms are made fresh each game.")
        if name is None:
            name = f"room_{pos[0]}_{pos[1]}".replace("-", "n")
        self._check_name(name)
        cols, rows = OverworldSettings.COLS, OverworldSettings.ROWS
        floor, wall = OverworldSettings.FLOOR_CHAR, OverworldSettings.WALL_CHAR
        grid = [[wall if c in (0, cols - 1) or r in (0, rows - 1) else floor
                 for c in range(cols)] for r in range(rows)]
        cx, cy = pos
        north = cells.WORLD_LAYOUT.get((cx, cy - 1))
        south = cells.WORLD_LAYOUT.get((cx, cy + 1))
        west = cells.WORLD_LAYOUT.get((cx - 1, cy))
        east = cells.WORLD_LAYOUT.get((cx + 1, cy))
        for c in range(1, cols - 1):
            if north and cells.CELLS[north][rows - 1][c] in WALKABLE:
                grid[0][c] = cells.CELLS[north][rows - 1][c]
            if south and cells.CELLS[south][0][c] in WALKABLE:
                grid[rows - 1][c] = cells.CELLS[south][0][c]
        for r in range(1, rows - 1):
            if west and cells.CELLS[west][r][cols - 1] in WALKABLE:
                grid[r][0] = cells.CELLS[west][r][cols - 1]
            if east and cells.CELLS[east][r][0] in WALKABLE:
                grid[r][cols - 1] = cells.CELLS[east][r][0]
        cells.CELLS[name] = grid
        cells.PEOPLE[name] = []
        cells.FIELD_MONSTERS[name] = []
        cells.WORLD_LAYOUT[pos] = name
        self.dirty.add(name)
        self.open(name)
        return name

    def rename(self, new_name: str) -> bool:
        """Give the open room a new name; its old file goes at the next save."""
        old = self.current
        if new_name == old:
            return False
        self._check_name(new_name)
        pos = self.pos_of(old)
        for table in (cells.CELLS, cells.PEOPLE, cells.FIELD_MONSTERS):
            table[new_name] = table.pop(old)
        cells.WORLD_LAYOUT[pos] = new_name
        self._undo[new_name] = self._undo.pop(old, [])
        if old in self.dirty:
            self.dirty.remove(old)
        self.dirty.add(new_name)
        self._old_files.add(cells.cell_path(old, self.directory))
        self.current = new_name
        return True

    def delete_room(self) -> str | None:
        """Drop the open room; its file goes at the next save. Opens a neighbor, or any room."""
        name = self.current
        if name is None:
            return None
        pos = self.pos_of(name)
        for table in (cells.CELLS, cells.PEOPLE, cells.FIELD_MONSTERS):
            table.pop(name, None)
        cells.WORLD_LAYOUT.pop(pos, None)
        self._undo.pop(name, None)
        self.dirty.discard(name)
        self._old_files.add(cells.cell_path(name, self.directory))
        self.current = None
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            if self.open_at((pos[0] + dx, pos[1] + dy)):
                return name
        if cells.CELLS:
            self.open(self.names[0])
        return name

    def _check_name(self, name: str) -> None:
        if not ROOM_NAME.match(name):
            raise ValueError("A room name is lower case letters, digits and underscores.")
        if name in cells.CELLS:
            raise ValueError(f"A room named {name!r} already exists.")

    # ------------------------------------------------------------------
    # LOOKING
    # ------------------------------------------------------------------

    @staticmethod
    def inside(col: int, row: int) -> bool:
        """Whether a tile is on the room."""
        return 0 <= col < OverworldSettings.COLS and 0 <= row < OverworldSettings.ROWS

    def tile_at(self, col: int, row: int) -> str | None:
        """The tile character at a spot, or None off the room."""
        if not self.inside(col, row):
            return None
        return self.grid[row][col]

    def footprint(self, spot: dict) -> set[tuple[int, int]]:
        """Every tile a monster covers."""
        width, height = self.monster_kinds.get(spot["kind"], {}).get("tiles", (1, 1))
        return {(spot["col"] + dx, spot["row"] + dy)
                for dx in range(width) for dy in range(height)}

    def thing_at(self, col: int, row: int) -> tuple[str, dict] | None:
        """``("monster", spot)`` or ``("person", person)`` on a tile, else None."""
        for person in self.people:
            if (person["col"], person["row"]) == (col, row):
                return ("person", person)
        for spot in self.monsters:
            if (col, row) in self.footprint(spot):
                return ("monster", spot)
        return None

    def describe(self, col: int, row: int) -> str:
        """What is on a tile, for the bar: the thing if any, else the tile."""
        thing = self.thing_at(col, row)
        if thing is not None:
            kind, data = thing
            if kind == "person":
                facing = FACING_NAMES.get(tuple(data["facing"]), "")
                shop = " KEEPS " + _words(data["shop"]) if data.get("shop") else ""
                return f"{_words(data['sheet'])} FACING {facing}{shop}"
            note = " BOSS" if data.get("boss") else (" STILL" if data.get("still") else "")
            return f"{_words(data['kind'])}{note}"
        char = self.tile_at(col, row)
        return TILE_NAMES.get(char, char or "")

    def walkable(self, col: int, row: int) -> bool:
        """Whether the party could stand on a tile."""
        return self.tile_at(col, row) in WALKABLE and self.thing_at(col, row) is None

    def spawn_near(self, col: int, row: int) -> tuple[int, int]:
        """The nearest tile the party can stand on, for Play; the middle if none."""
        if self.walkable(col, row):
            return (col, row)
        best: tuple[int, int] | None = None
        best_distance = None
        for r in range(OverworldSettings.ROWS):
            for c in range(OverworldSettings.COLS):
                if self.walkable(c, r):
                    distance = abs(c - col) + abs(r - row)
                    if best_distance is None or distance < best_distance:
                        best, best_distance = (c, r), distance
        return best or (OverworldSettings.COLS // 2, OverworldSettings.ROWS // 2)

    # ------------------------------------------------------------------
    # CHANGING
    # ------------------------------------------------------------------

    def _snapshot(self) -> None:
        """Remember the open room before a change."""
        stack = self._undo.setdefault(self.current, [])
        stack.append((copy.deepcopy(self.grid), copy.deepcopy(self.people),
                      copy.deepcopy(self.monsters)))
        del stack[:-UNDO_DEPTH]

    def _changed(self) -> None:
        self.dirty.add(self.current)

    def begin_stroke(self) -> None:
        """A stroke of painting starts: one undo step until ``end_stroke``."""
        self._stroke_open = True
        self._stroke_snapped = False

    def end_stroke(self) -> None:
        """The stroke is over."""
        self._stroke_open = False
        self._stroke_snapped = False

    def paint(self, col: int, row: int, char: str) -> bool:
        """Put a tile down; False when off the room or already that tile."""
        if not self.inside(col, row) or self.grid[row][col] == char:
            return False
        if not self._stroke_open:
            self._snapshot()
        elif not self._stroke_snapped:
            self._snapshot()
            self._stroke_snapped = True
        self.grid[row][col] = char
        self._changed()
        return True

    def place(self, col: int, row: int, brush: Brush | None = None) -> bool:
        """Put the brush down on a tile: paint it, or stand a monster or person there."""
        brush = brush or self.brush
        if brush.kind == "tile":
            return self.paint(col, row, brush.key)
        if not self.inside(col, row):
            return False
        if brush.kind == "monster":
            kind = self.monster_kinds[brush.key]
            spot = {"col": col, "row": row, "kind": brush.key}
            if "encounter" in kind:
                spot["still"] = True
                spot["boss"] = True
            if any(not self.inside(c, r) for c, r in self.footprint(spot)):
                return False
            self._snapshot()
            for c, r in self.footprint(spot):
                self._remove_quietly(c, r)
            self.monsters.append(spot)
        else:
            self._snapshot()
            self._remove_quietly(col, row)
            self.people.append({"col": col, "row": row, "facing": [0, 1], "sheet": brush.key})
        self._changed()
        return True

    def _remove_quietly(self, col: int, row: int) -> bool:
        thing = self.thing_at(col, row)
        if thing is None:
            return False
        kind, data = thing
        (self.people if kind == "person" else self.monsters).remove(data)
        return True

    def remove(self, col: int, row: int) -> bool:
        """Take the thing on a tile away; False when there is none."""
        if self.thing_at(col, row) is None:
            return False
        self._snapshot()
        self._remove_quietly(col, row)
        self._changed()
        return True

    def turn(self, col: int, row: int) -> bool:
        """Turn the person on a tile to face the next way, or a monster the other way."""
        thing = self.thing_at(col, row)
        if thing is None:
            return False
        kind, data = thing
        self._snapshot()
        if kind == "person":
            index = FACINGS.index(tuple(data["facing"])) if tuple(data["facing"]) in FACINGS else 0
            data["facing"] = list(FACINGS[(index + 1) % len(FACINGS)])
        else:
            data["faces_left"] = not data.get("faces_left", False)
        self._changed()
        return True

    def toggle_still(self, col: int, row: int) -> bool:
        """Make the monster on a tile stand still, or wander again."""
        thing = self.thing_at(col, row)
        if thing is None or thing[0] != "monster":
            return False
        self._snapshot()
        spot = thing[1]
        if spot.get("still"):
            spot.pop("still", None)
        else:
            spot["still"] = True
        self._changed()
        return True

    def undo(self) -> bool:
        """Put the open room back the way it was before the last change."""
        stack = self._undo.get(self.current, [])
        if not stack:
            return False
        grid, people, monsters = stack.pop()
        self.grid[:] = grid
        self.people[:] = people
        self.monsters[:] = monsters
        self._changed()
        return True

    def can_undo(self) -> bool:
        """Whether there is a change to undo in the open room."""
        return bool(self._undo.get(self.current))

    # ------------------------------------------------------------------
    # SAVING
    # ------------------------------------------------------------------

    def save(self) -> list[str]:
        """Write every changed room to its file and drop the files of renamed or deleted ones."""
        written = []
        for name in sorted(self.dirty):
            if name in cells.CELLS:
                written.append(cells.save_cell(name, self.directory))
        for path in self._old_files:
            if os.path.exists(path):
                os.remove(path)
        self._old_files.clear()
        self.dirty.clear()
        return written

    @property
    def unsaved(self) -> bool:
        """Whether anything would be lost by closing now."""
        return bool(self.dirty or self._old_files)
