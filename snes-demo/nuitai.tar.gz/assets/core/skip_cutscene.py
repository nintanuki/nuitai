"""Skipping a cutscene from the pause (Frankie, 10/28).

While a long scripted scene plays (``core/story.py``: a part of one of
the few ``StorySettings.SKIPPABLE`` scenes, today the opening and the wake
up to its fight), START (or P)
does not pause: it opens the game's NO / YES box, ``StorySettings.SKIP_ASK``,
NO first and chosen, and nothing else (no "Paused"). NO closes it and the
scene goes on. YES plays the rest of the scene at once behind a black
screen, through the game's own code, so everything it sets is set as if it
had played out: flags, items, who joined, where Kailo stands, the music. A
fight is never skipped: a scene that runs into one stops where the fight
starts, and the fight plays; the part after it is a scene again. The words
before the prologue (the blurb and the place card) are a cutscene too:
YES there skips them and the taro patch scene, to the start of its fight.

Every other scene, and the wake after its fight (which ends the demo),
pauses as ever, and so does a fight and the field. A scene with a choice in it (the Great Boar's question, the
Kame's questions) is never skippable, even if it were put on the list.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from settings import StorySettings

if TYPE_CHECKING:
    from main import GameManager


def skippable(name: str, part: str, steps: list[dict]) -> bool:
    """A scene's part can be skipped if ``StorySettings.SKIPPABLE`` lists it and none of the scene's
    steps asks the player something (a safety net: a listed scene that gains a choice pauses)."""
    return (part in StorySettings.SKIPPABLE.get(name, ())
            and not any("choice" in step for step in steps))


def available(gm: "GameManager") -> Callable[[], None] | None:
    """What YES would do now, if a cutscene is playing; else None (START pauses)."""
    from core.scenes.blurb_scene import BlurbScene  # local: cycle
    from core.scenes.overworld_scene import OverworldScene

    top = gm.scene_stack.top
    world = gm.scene_stack.find(OverworldScene)
    if world is None or world.story is None or world.skipping:
        return None
    if not skippable(world.story.name, world.story.part, world.story.steps):
        return None
    if isinstance(top, BlurbScene):
        def past_blurb() -> None:
            while isinstance(gm.scene_stack.top, BlurbScene):
                gm.scene_stack.pop()
            world.skip_cutscene()
        return past_blurb
    if top is world:
        return world.skip_cutscene
    return None


def ask(gm: "GameManager") -> None:
    """The NO / YES box over the scene; YES skips it."""
    from core.scenes.confirm_scene import ConfirmScene  # local: cycle

    def yes() -> None:
        skip = available(gm)
        if skip is not None:
            skip()

    gm.scene_stack.push(ConfirmScene(gm, StorySettings.SKIP_ASK, on_yes=yes))
