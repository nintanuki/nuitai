"""Save / load with schema versioning.

A save is a JSON file under ``SaveSettings.SAVES_DIR``, one file per
slot. The file always contains a ``version`` key. The loader runs the
data through ``migrate`` before handing it to gameplay code so older
saves continue to load after schema changes.

Slots are integer ids:
- ``SaveSettings.AUTOSAVE_SLOT_ID`` (0): the autosave.
- 1..``SaveSettings.MAX_SAVE_SLOTS``: player-driven slots.

Beside them, ``config.json`` keeps the last Config settings set, so the
title screen has them before a save is loaded (Frankie, 10/26).

In the browser (pygbag) the files live in a filesystem that is gone when
the tab closes, so each slot is also mirrored to the page's
``localStorage`` and copied back into its file before it is read.
"""

from __future__ import annotations

import json
import os
import sys
import time
from typing import Any

from settings import SaveSettings


# Bump when the on-disk shape of a save changes. Add a migration step
# in ``migrate`` for every increment so older saves keep loading.
SAVE_SCHEMA_VERSION = 1


# ---------------------------------------------------------------------------
# PATHS
# ---------------------------------------------------------------------------

def slot_path(slot_id: int) -> str:
    """Return the absolute path of the save file for ``slot_id``."""
    return os.path.join(SaveSettings.SAVES_DIR, f"slot_{slot_id}.json")


def slot_exists(slot_id: int) -> bool:
    """Return True if a save file exists for ``slot_id``."""
    _restore_from_browser(slot_id)
    return os.path.isfile(slot_path(slot_id))


# ---------------------------------------------------------------------------
# BROWSER MIRROR
# ---------------------------------------------------------------------------

def _browser_storage():
    """Return the page's ``localStorage`` under pygbag, or None on the desktop."""
    if sys.platform != "emscripten":
        return None
    import platform  # pygbag's, which reaches the page as ``platform.window``.
    window = getattr(platform, "window", None)
    return getattr(window, "localStorage", None)


def _browser_key(slot_id: int) -> str:
    return f"nuitai.slot_{slot_id}"


def _mirror_to_browser(slot_id: int, text: str) -> None:
    """Copy a just-written slot into ``localStorage`` with its save time."""
    storage = _browser_storage()
    if storage is None:
        return
    storage.setItem(_browser_key(slot_id), text)
    storage.setItem(_browser_key(slot_id) + ".time", str(time.time()))


def _remove_from_browser(slot_id: int) -> None:
    storage = _browser_storage()
    if storage is None:
        return
    storage.removeItem(_browser_key(slot_id))
    storage.removeItem(_browser_key(slot_id) + ".time")


def _restore_from_browser(slot_id: int) -> None:
    """Write a slot kept in ``localStorage`` back to its file if the file is gone.

    The file gets the stored save time so ``newest_slot`` still picks the
    slot saved last after a reload.
    """
    storage = _browser_storage()
    path = slot_path(slot_id)
    if storage is None or os.path.isfile(path):
        return
    text = storage.getItem(_browser_key(slot_id))
    if not text:
        return
    os.makedirs(SaveSettings.SAVES_DIR, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(str(text))
    try:
        saved_at = float(storage.getItem(_browser_key(slot_id) + ".time"))
        os.utime(path, (saved_at, saved_at))
    except (TypeError, ValueError):
        pass


# ---------------------------------------------------------------------------
# READ / WRITE
# ---------------------------------------------------------------------------

def save(slot_id: int, payload: dict[str, Any]) -> None:
    """Write ``payload`` to ``slot_id``, stamping the current schema version.

    Args:
        slot_id: The save slot to write.
        payload: The gameplay state to persist. Must be JSON-serialisable.
    """
    os.makedirs(SaveSettings.SAVES_DIR, exist_ok=True)
    record = {"version": SAVE_SCHEMA_VERSION, "data": payload}
    text = json.dumps(record, indent=2)
    with open(slot_path(slot_id), "w", encoding="utf-8") as f:
        f.write(text)
    _mirror_to_browser(slot_id, text)


def delete(slot_id: int) -> None:
    """Remove the save in ``slot_id``, if there is one."""
    if slot_exists(slot_id):
        os.remove(slot_path(slot_id))
    _remove_from_browser(slot_id)


def load(slot_id: int) -> dict[str, Any]:
    """Load the save at ``slot_id``, applying any migrations.

    Args:
        slot_id: The save slot to read.

    Returns:
        The migrated ``data`` payload (the inner dict, not the wrapper).

    Raises:
        FileNotFoundError: If the slot does not exist.
        ValueError: If the file is malformed or fails to migrate.
    """
    path = slot_path(slot_id)
    _restore_from_browser(slot_id)
    with open(path, "r", encoding="utf-8") as f:
        record = json.load(f)
    if not isinstance(record, dict) or "version" not in record:
        raise ValueError(f"save {path} is missing a version stamp")
    return migrate(record)


# ---------------------------------------------------------------------------
# CONFIG, BESIDE THE SLOTS
# ---------------------------------------------------------------------------

_SETTINGS_FILE = "config.json"
_SETTINGS_KEY = "nuitai.config"


def write_settings(settings: dict[str, Any]) -> None:
    """Keep the Config settings just set, for the title screen next time."""
    text = json.dumps(settings)
    os.makedirs(SaveSettings.SAVES_DIR, exist_ok=True)
    with open(os.path.join(SaveSettings.SAVES_DIR, _SETTINGS_FILE), "w", encoding="utf-8") as f:
        f.write(text)
    storage = _browser_storage()
    if storage is not None:
        storage.setItem(_SETTINGS_KEY, text)


def read_settings() -> dict[str, Any]:
    """The Config settings last set, or {} when none were (the defaults then)."""
    path = os.path.join(SaveSettings.SAVES_DIR, _SETTINGS_FILE)
    text = None
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    else:
        storage = _browser_storage()
        text = storage.getItem(_SETTINGS_KEY) if storage is not None else None
    try:
        data = json.loads(str(text)) if text else {}
    except ValueError:
        return {}
    return data if isinstance(data, dict) else {}


# ---------------------------------------------------------------------------
# MIGRATIONS
# ---------------------------------------------------------------------------

def migrate(record: dict[str, Any]) -> dict[str, Any]:
    """Walk a save record forward to ``SAVE_SCHEMA_VERSION``.

    Each schema bump appends a step here. The function returns the
    inner ``data`` payload at the current version. Unknown future
    versions raise ``ValueError`` rather than silently corrupting state.

    Args:
        record: The full ``{"version": N, "data": ...}`` wrapper read
            from disk.

    Returns:
        The migrated ``data`` dict at ``SAVE_SCHEMA_VERSION``.
    """
    version = record.get("version", 0)
    data = record.get("data", {})
    if version > SAVE_SCHEMA_VERSION:
        raise ValueError(
            f"save was written with version {version}, "
            f"this build only understands up to {SAVE_SCHEMA_VERSION}"
        )
    # No migrations yet — this is the first version. Future steps go
    # here as ``if version < N: data = _migrate_to_N(data); version = N``.
    return data


# ---------------------------------------------------------------------------
# THE PLAYER'S THREE SLOTS
# ---------------------------------------------------------------------------

def player_slots() -> range:
    """The slots the player saves to and loads from, 1 to ``MAX_SAVE_SLOTS``."""
    return range(1, SaveSettings.MAX_SAVE_SLOTS + 1)


def peek(slot_id: int) -> dict[str, Any] | None:
    """Return a slot's data for the slot list, or None when it is empty or unreadable."""
    if not slot_exists(slot_id):
        return None
    try:
        return load(slot_id)
    except (OSError, ValueError):
        return None


def newest_slot() -> int | None:
    """Return the player slot saved most recently, or None when all are empty."""
    saved = [slot_id for slot_id in player_slots() if peek(slot_id) is not None]
    if not saved:
        return None
    return max(saved, key=lambda slot_id: os.path.getmtime(slot_path(slot_id)))


# ---------------------------------------------------------------------------
# CHECKPOINTS
# ---------------------------------------------------------------------------
# A checkpoint is a save kept for testing (Frankie, 10/25): the story up to
# some moment, so a change in the middle of the demo is tried from there
# instead of from the title. One file per checkpoint in
# ``SaveSettings.CHECKPOINTS_DIR``, the same shape as a slot, so the
# migrations above keep old ones loading. Checked in, unlike the saves.

def checkpoint_path(name: str) -> str:
    """Return the absolute path of checkpoint ``name``."""
    return os.path.join(SaveSettings.CHECKPOINTS_DIR, f"{name}.json")


def checkpoint_names() -> list[str]:
    """Every checkpoint on disk, in story order (each file's ``order``), then by name."""
    if not os.path.isdir(SaveSettings.CHECKPOINTS_DIR):
        return []
    names = [f[:-5] for f in os.listdir(SaveSettings.CHECKPOINTS_DIR) if f.endswith(".json")]

    def order(name: str) -> tuple[int, str]:
        try:
            return (int(load_checkpoint(name).get("order", 999)), name)
        except (OSError, ValueError):
            return (999, name)

    return sorted(names, key=order)


def save_checkpoint(name: str, payload: dict[str, Any]) -> None:
    """Write ``payload`` (what a slot holds, plus a ``note``) as checkpoint ``name``."""
    os.makedirs(SaveSettings.CHECKPOINTS_DIR, exist_ok=True)
    record = {"version": SAVE_SCHEMA_VERSION, "data": payload}
    with open(checkpoint_path(name), "w", encoding="utf-8") as f:
        json.dump(record, f, indent=2)
        f.write("\n")


def load_checkpoint(name: str) -> dict[str, Any]:
    """Load checkpoint ``name``, migrated like a slot."""
    with open(checkpoint_path(name), "r", encoding="utf-8") as f:
        record = json.load(f)
    if not isinstance(record, dict) or "version" not in record:
        raise ValueError(f"checkpoint {name} is missing a version stamp")
    return migrate(record)


def free_checkpoint_name(room: str) -> str:
    """A new checkpoint's name: the room, then the first number not taken (``chief_house_2``)."""
    number = 1
    while os.path.exists(checkpoint_path(f"{room}_{number}")):
        number += 1
    return f"{room}_{number}"
