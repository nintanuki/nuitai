"""Static overworld cell content.

The map: two beaches and, north of them, a rough draft of fourteen more
rooms laid out after a map Frankie gave to imitate (D-581). Neighbors
are joined by openings that line up on both edges. When Pass 2 brings real cells, this module migrates to
``data/cells/*.json`` and the ``DataLoader`` reads them like every
other content pack.

Tile alphabet — keep in sync with ``OverworldSettings.*_CHAR`` in
[settings.py](../settings.py):

* ``'.'`` — walkable floor (grass placeholder color).
* ``'#'`` — wall (rocky brown placeholder color).
* ``'~'`` — impassable water (ocean blue placeholder color).
* ``'_'`` — walkable sand (sandy beige placeholder color).
* ``'o'`` — the rest stop pond (D-525): blocks like water, and heals
  and revives the party when faced and confirmed.
* ``'m'`` — a market stall (D-571): blocks, and opens the shop when
  faced and confirmed.

``CELLS`` maps a cell name to its 14 by 16 char grid, one screen of 16
pixel tiles (D-444).
``WORLD_LAYOUT`` maps a world-space cell coordinate (cx, cy) — cx
grows east, cy grows south — to the cell name that lives there. The
player crosses cell edges by stepping past the screen's border;
``World.step_to_neighbor`` resolves the new coordinate against this
table.
"""

from __future__ import annotations


# The two Pass-1 test cells. Each row is exactly OverworldSettings.COLS
# characters wide; the module contains a smoke check at import time that
# enforces this so authoring typos fail loudly rather than silently
# misaligning the grid.

CELLS: dict[str, list[list[str]]] = {
    "beach_west": [
        list("#######..#######"),   # North edge opens at cols 7 and 8.
        list("#..............#"),
        list("#....oo........#"),
        list("#...oooo...m...#"),
        list("#....oo...___..#"),
        list("#..............#"),
        list("#..............."),   # East edge opens at col 15, row 6.
        list("#..............#"),
        list("#.._...........#"),
        list("#..__..........#"),
        list("#..............#"),
        list("#..............#"),
        list("#..............#"),
        list("################"),
    ],
    "beach_east": [
        list("#######..#######"),   # North edge opens at cols 7 and 8.
        list("#..............#"),
        list("#........~~....#"),
        list("#.......~~~~...#"),
        list("#........~~....#"),
        list("#..............#"),
        list("...............#"),   # West edge opens at col 0, row 6.
        list("#..............#"),
        list("#.........__...#"),
        list("#..........__..#"),
        list("#..............#"),
        list("#..............#"),
        list("#..............#"),
        list("################"),
    ],
    # The rough draft north of the beaches, laid out after a map Frankie
    # gave to imitate (10/19): openings two tiles wide, at cols 7 and 8 or
    # rows 6 and 7.
    "river_bank": [
        list("################"),
        list("#.._____.......#"),
        list("#.._____...##..#"),
        list("#~~~~~~~~~.##..#"),
        list("#~~~~~~~~~.##..#"),
        list("#......~~~.##..#"),
        list("#......~~~......"),
        list("#..##..~~~......"),
        list("#..##..........#"),
        list("#.....____.....#"),
        list("#.....____..##.#"),
        list("#...........##.#"),
        list("#..............#"),
        list("#######..#######"),
    ],
    "sand_garden": [
        list("#######..#######"),
        list("#______..______#"),
        list("#_####____####_#"),
        list("#_#__________#_#"),
        list("#_#_###__###_#_#"),
        list("#___#______#___#"),
        list("____#______#___#"),
        list("____#______#___#"),
        list("#_#_###__###_#_#"),
        list("#_#__________#_#"),
        list("#_####____####_#"),
        list("#______..______#"),
        list("#______..______#"),
        list("#######..#######"),
    ],
    "hedge_garden": [
        list("#######..#######"),
        list("#..............#"),
        list("#.######..####.#"),
        list("#..............#"),
        list("#.....######...#"),
        list("#..............#"),
        list("#.####.........."),
        list("#..............."),
        list("#.######..####.#"),
        list("#..............#"),
        list("#...#####......#"),
        list("#..............#"),
        list("#..............#"),
        list("#######..#######"),
    ],
    "island_hut": [
        list("~~~~~~~__~~~~~~~"),
        list("~~~~~~~__~~~~~~~"),
        list("~~~#___..___#~~~"),
        list("~~#..........#~~"),
        list("~#...######...#~"),
        list("~#...######...#~"),
        list("__...######...#~"),
        list("__............#~"),
        list("~#............#~"),
        list("~#............#~"),
        list("~~#..........#~~"),
        list("~~~#________#~~~"),
        list("~~~~~~~~~~~~~~~~"),
        list("~~~~~~~~~~~~~~~~"),
    ],
    "river_bend": [
        list("#~~~~~~__~~~~~~#"),
        list("#~~~~~~__~~~~~~#"),
        list("#...~~~__~~~...#"),
        list("#.....____~~...#"),
        list("#.....______...#"),
        list("#...~~~~__~~...#"),
        list("....~~~~__~~...#"),
        list("....______~~...#"),
        list("#...~~~__~~~...#"),
        list("#..~~~~__~~~~..#"),
        list("#..~~~~__~~~~..#"),
        list("#~~~~~~__~~~~~~#"),
        list("#~~~~~~__~~~~~~#"),
        list("#~~~~~~__~~~~~~#"),
    ],
    "hedge_maze": [
        list("#######__#######"),
        list("#......__......#"),
        list("#.####.##.####.#"),
        list("#.#..........#.#"),
        list("#.#.###..###.#.#"),
        list("#...#......#...#"),
        list("....#..##..#...."),
        list("....#..##..#...."),
        list("#.#.###..###.#.#"),
        list("#.#..........#.#"),
        list("#.####.##.####.#"),
        list("#..............#"),
        list("#..............#"),
        list("#######..#######"),
    ],
    "log_yard": [
        list("#######..#######"),
        list("#..............#"),
        list("#.##.##.##.##..#"),
        list("#..............#"),
        list("#.#########....#"),
        list("#..........#...#"),
        list("#..__......#...."),
        list("#..__..........."),
        list("#.#########....#"),
        list("#..............#"),
        list("#.##.##.##.##..#"),
        list("#..............#"),
        list("#..............#"),
        list("################"),
    ],
    "crossroads": [
        list("#######..#######"),
        list("#......__......#"),
        list("#......__..###.#"),
        list("#.###..__..#__.#"),
        list("#.###..__..#__.#"),
        list("#......__..#__.#"),
        list("_______________#"),
        list("_______________#"),
        list("#......__......#"),
        list("#..##..__..##..#"),
        list("#..##..__..##..#"),
        list("#......__......#"),
        list("#......__......#"),
        list("#######__#######"),
    ],
    "palm_grove": [
        list("#######..#######"),
        list("#..#......#....#"),
        list("#......#.....#.#"),
        list("#.#..#....#....#"),
        list("#.....#..#...#.#"),
        list("#..#.......#...#"),
        list("#......#........"),
        list("#.#.#.....#....."),
        list("#.....#.#...#..#"),
        list("#..#.......#...#"),
        list("#.....#..#.....#"),
        list("#.#..#.....#.#.#"),
        list("#..............#"),
        list("#######..#######"),
    ],
    "docks": [
        list("#######..#######"),
        list("#..............#"),
        list("#..............#"),
        list("#~~~~~~__~~~~~~#"),
        list("#~______~____~~#"),
        list("#~_~~~~~~~~~_~~#"),
        list("#~_~____~____~~#"),
        list("#~_~_~~~~~~~_~~#"),
        list("#~__________~~~#"),
        list("#~~~~~~~~~~_~~~#"),
        list("#~~~~~~______~~#"),
        list("#~~~~~~__~~~~~~#"),
        list("#~~~~~~__~~~~~~#"),
        list("#~~~~~~__~~~~~~#"),
    ],
    "key_room": [
        list("################"),
        list("#......##......#"),
        list("#.####.##.####.#"),
        list("#..............#"),
        list("#..#..####..#..#"),
        list("#..#........#..#"),
        list("#..#..____..#..#"),
        list("#.....____.....#"),
        list("#..####..####..#"),
        list("#..............#"),
        list("#.##........##.#"),
        list("#..............#"),
        list("#..............#"),
        list("#######..#######"),
    ],
    "blocks_room": [
        list("################"),
        list("#..............#"),
        list("#.###......###.#"),
        list("#.#..........#.#"),
        list("#.#..##..##..#.#"),
        list("#....##..##....#"),
        list("#..............#"),
        list("#..##......##..#"),
        list("#..##......##..#"),
        list("#..............#"),
        list("#.###..##..###.#"),
        list("#..............#"),
        list("#..............#"),
        list("#######..#######"),
    ],
    "gate_yard": [
        list("#######..#######"),
        list("#..............#"),
        list("#######..#######"),
        list("#..............#"),
        list("#.#####..#####.#"),
        list("#.#..........#.#"),
        list("#.#..##..##..#.#"),
        list("#....##..##....#"),
        list("#.#..........#.#"),
        list("#.#####..#####.#"),
        list("#..............#"),
        list("#..............#"),
        list("#..............#"),
        list("#######..#######"),
    ],
    "farm_field": [
        list("################"),
        list("#..............#"),
        list("#.__..__..__...#"),
        list("#..............#"),
        list("#...__..__..__.#"),
        list("#..............#"),
        list("#.__..__..__...#"),
        list("#..............#"),
        list("#...__..__..__.#"),
        list("#..............#"),
        list("#..............#"),
        list("#.##........##.#"),
        list("#..............#"),
        list("#######..#######"),
    ],
}


# The people standing in each cell: where, which way they face, the
# Ninja Adventure sheet they are drawn from (``AssetPaths.PEOPLE_DIR``)
# and, for a shopkeeper, the shop that talking to them opens. A person
# blocks like a wall.
PEOPLE: dict[str, list[dict]] = {
    "beach_west": [
        # The old man who keeps the beach stall (D-574).
        {"col": 12, "row": 3, "facing": (0, 1), "sheet": "OldMan", "shop": "beach_stall"},
    ],
}


# The monsters seen in each cell (D-576): where each starts and its kind
# in ``data/field_monsters/``. ``still`` stands without wandering; a
# ``boss`` is gone for good once beaten. Everything else comes back when
# the party walks into the cell again.
FIELD_MONSTERS: dict[str, list[dict]] = {
    "beach_west": [
        {"col": 3, "row": 11, "kind": "boar"},
        {"col": 12, "row": 10, "kind": "boar"},
    ],
    "beach_east": [
        # The Great Boar, Tandayag na Opon, four tiles by three.
        {"col": 10, "row": 6, "kind": "great_boar", "still": True, "boss": True,
         "faces_left": True},
    ],
    "river_bank": [{"col": 5, "row": 10, "kind": "boar"}],
    "sand_garden": [{"col": 7, "row": 6, "kind": "boar"}],
    "hedge_garden": [{"col": 10, "row": 9, "kind": "boar"}],
    "island_hut": [{"col": 8, "row": 9, "kind": "kaperosa"}],
    "river_bend": [{"col": 2, "row": 3, "kind": "kaperosa"}],
    "hedge_maze": [{"col": 7, "row": 5, "kind": "amaranhig"},
                   {"col": 2, "row": 11, "kind": "wicked_dwende"}],
    "log_yard": [{"col": 8, "row": 5, "kind": "nuno_sa_punso"}],
    "crossroads": [{"col": 4, "row": 8, "kind": "nuno_sa_punso"}],
    "palm_grove": [{"col": 4, "row": 6, "kind": "sigbin"},
                   {"col": 12, "row": 9, "kind": "sigbin"}],
    "docks": [{"col": 4, "row": 2, "kind": "sigbin"}],
    "key_room": [{"col": 7, "row": 3, "kind": "santelmo"}],
    "blocks_room": [{"col": 7, "row": 6, "kind": "amaranhig"}],
    "gate_yard": [{"col": 4, "row": 11, "kind": "santelmo"}],
    "farm_field": [{"col": 3, "row": 9, "kind": "wicked_dwende"},
                   {"col": 12, "row": 10, "kind": "wicked_dwende"}],
}


# Cell-coordinate layout. cx grows east, cy grows south.
WORLD_LAYOUT: dict[tuple[int, int], str] = {
    (0, 0): "beach_west",
    (1, 0): "beach_east",
    (0, -1): "river_bank",
    (1, -1): "sand_garden",
    (1, -2): "hedge_garden",
    (2, -2): "island_hut",
    (0, -3): "log_yard",
    (1, -3): "hedge_maze",
    (2, -3): "river_bend",
    (0, -4): "palm_grove",
    (1, -4): "crossroads",
    (2, -4): "docks",
    (0, -5): "gate_yard",
    (1, -5): "key_room",
    (2, -5): "blocks_room",
    (0, -6): "farm_field",
}


# Cell the player spawns into on a new game. ``OverworldPlayer.__init__``
# uses ``OverworldPlayerSettings.SPAWN_COL`` / ``SPAWN_ROW`` for the
# within-cell tile.
START_CELL_POS: tuple[int, int] = (0, 0)


def _validate_cells() -> None:
    """Fail loudly at import time if any cell is misshaped.

    Catches the easy authoring mistake of dropping or adding one
    character on a row, which would otherwise misalign the grid
    diagonally as soon as the player steps into that row.
    """
    # Local import: settings is the source of truth for the grid
    # dimensions, but we keep the import lazy so this module can be
    # introspected without forcing a settings import order.
    from settings import OverworldSettings

    for name, grid in CELLS.items():
        if len(grid) != OverworldSettings.ROWS:
            raise ValueError(
                f"Cell {name!r} has {len(grid)} rows; expected {OverworldSettings.ROWS}."
            )
        for row_index, row in enumerate(grid):
            if len(row) != OverworldSettings.COLS:
                raise ValueError(
                    f"Cell {name!r} row {row_index} has {len(row)} cols; "
                    f"expected {OverworldSettings.COLS}."
                )


_validate_cells()
