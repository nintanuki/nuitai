"""Lore, under Data: short spoiler-free pages that unlock silently (Frankie, 10/23).

The pages are ``game/shared/lore.md``, which the cartridge reads too
(``game/snes/tools/make_art.py``), so the words cannot disagree. Each page
says when it appears: ``start`` from New Game, ``stance <name>`` the first
time a member acts in that stance in a fight, ``event <name>`` at a moment
in the story. Several, joined by ``or``, mean whichever comes first. An
unlocked page is a party flag, so it saves with the game.
"""

from __future__ import annotations

import os
import re
from typing import TYPE_CHECKING

from core.shared import SHARED_DIR

if TYPE_CHECKING:
    from systems.party import Party

LORE_PATH = os.path.join(SHARED_DIR, "lore.md")


def read_pages(path: str = LORE_PATH) -> list[dict[str, str]]:
    """Every page in the file, in order: its title, when it unlocks, its words."""
    with open(path, encoding="utf-8") as f:
        text = f.read()
    pages = []
    # The pages start at the first title after the notes at the top.
    for block in re.split(r"^## ", text, flags=re.M)[1:]:
        title, _, rest = block.partition("\n")
        unlock = re.search(r"^\*\*Unlocks:\*\* *(.+)$", rest, re.M)
        words = [line for line in rest.splitlines() if line.strip() and not line.startswith("**")]
        pages.append({"title": title.strip(), "unlock": unlock.group(1).strip() if unlock else "start",
                      "text": " ".join(words)})
    return pages


PAGES = read_pages()


def _flag(page: dict[str, str]) -> str:
    return "lore:" + page["title"]


def unlocked(party: "Party") -> list[dict[str, str]]:
    """The pages the party has, in the file's order."""
    return [p for p in PAGES if p["unlock"] == "start" or party.flags.get(_flag(p))]


def unlock(party: "Party", when: str) -> None:
    """Unlock every page that appears ``when`` (``stance Lelua``, ``event hina_home``), silently."""
    for page in PAGES:
        if when in page["unlock"].split(" or "):
            party.flags[_flag(page)] = True
