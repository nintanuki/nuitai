"""Lore, under Data: short spoiler-free pages that unlock silently (Frankie, 10/23).

The pages are ``game/shared/lore.md``, which the cartridge reads too
(``game/snes/tools/make_art.py``), so the words cannot disagree. Each page
says when it appears: ``start`` from New Game, ``stance <name>`` the first
time a member acts in that stance in a fight, ``event <name>`` at a moment
in the story. Several, joined by ``or``, mean whichever comes first. An
unlocked page is a party flag, so it saves with the game. Each page is in
one of ``CATEGORIES``, a row of its own on Data (Frankie, 10/25).
"""

from __future__ import annotations

import os
import re
from typing import TYPE_CHECKING

from core.shared import SHARED_DIR

if TYPE_CHECKING:
    from systems.party import Party

LORE_PATH = os.path.join(SHARED_DIR, "lore.md")
# Data's rows for the pages, in order, each with its help line (30 letters
# at most, for the cartridge). Frankie named People, Places, Food and Gods
# (10/25); Faiths and Arts hold the rest.
CATEGORIES = (
    ("People", "The people you have met."),
    ("Places", "The islands and the seas."),
    ("Food", "What the islands eat."),
    ("Gods", "The Akua and the divine."),
    ("Faiths", "Faiths and holy orders."),
    ("Arts", "Fighting arts and dances."),
)


def read_pages(path: str = LORE_PATH) -> list[dict[str, str]]:
    """Every page in the file, in order: its title, when it unlocks, its words."""
    with open(path, encoding="utf-8") as f:
        text = f.read()
    pages = []
    # The pages start at the first title after the notes at the top.
    for block in re.split(r"^## ", text, flags=re.M)[1:]:
        title, _, rest = block.partition("\n")
        unlock = re.search(r"^\*\*Unlocks:\*\* *(.+)$", rest, re.M)
        category = re.search(r"^\*\*Category:\*\* *(.+)$", rest, re.M)
        words = [line for line in rest.splitlines() if line.strip() and not line.startswith("**")]
        pages.append({"title": title.strip(), "unlock": unlock.group(1).strip() if unlock else "start",
                      "category": category.group(1).strip() if category else "", "text": " ".join(words)})
    return pages


PAGES = read_pages()


def _flag(page: dict[str, str]) -> str:
    return "lore:" + page["title"]


def unlocked(party: "Party", category: str | None = None) -> list[dict[str, str]]:
    """The pages the party has, in the file's order; only ``category``'s when given."""
    return [p for p in PAGES if (p["unlock"] == "start" or party.flags.get(_flag(p)))
            and category in (None, p["category"])]


def in_category(category: str) -> list[dict[str, str]]:
    """Every page in ``category``, found or not."""
    return [p for p in PAGES if p["category"] == category]


def categories_found(party: "Party") -> list[tuple[str, str]]:
    """The categories with a page found, each with its help line: the others stay hidden."""
    return [(name, line) for name, line in CATEGORIES if unlocked(party, name)]


def unlock(party: "Party", when: str) -> None:
    """Unlock every page that appears ``when`` (``stance Lelua``, ``event hina_home``), silently."""
    for page in PAGES:
        if when in page["unlock"].split(" or "):
            party.flags[_flag(page)] = True
