"""The Workshop's lines window, its model: every line of dialogue, read and written back (Frankie, 10/31).

The game's words are in the story scripts, ``game/shared/story*.md``
(how to write one is at the top of ``story.md``), the lines said on the
field among them (``story-field.md``, ``core/field_lines.py``).
``Document`` is one file, kept as its lines exactly as
read, line endings and all, so a file saved with nothing changed is the
same to the byte, and an edited line is the only line written anew.

Saving is careful, because Frankie also edits these files by hand and
other sessions change them: ``Document.save`` reads the file again first.
If it is as it was opened, the edits are written. If it changed on disk,
the two sets of changes are merged (``merge``) when they touch different
lines; where they touch the same ones, nothing is written and the
conflicts come back for him to choose, his or the disk's, one at a time.
Nothing is ever overwritten without asking.

No pygame and no tkinter here: ``workshop_lines.py`` is the window.
"""

from __future__ import annotations

import difflib
import os
import re
import tempfile
from dataclasses import dataclass, field

from core import field_lines, story
from core.shared import SHARED_DIR

# A line someone says: ``**Hina:** text`` or ``**Hina** (if hina): text`` (``core/story.py``).
SAY = re.compile(r"^(?P<indent>\s*)\*\*(?P<who>[^*]+?)(?::\*\*|\*\*\s*\(if (?P<cond>[\w ]+?)\):)\s?(?P<rest>.*)$")
# How fast a line types, kept in front of the words it is edited with.
MARKERS = (story.FAST, story.QUICK, story.SLOW)
# Bold names that are not a speaker: the stage directions, the choice, the fight, the scene's notes.
NOT_SPEAKERS = set(story.STAGE_DIRECTIONS) | {"Choice", "Fight", "End", "Place", "Background", "Music", "Card"}
# Headings that are a part of a scene, not a scene of their own.
NOT_SCENES = ("Cast", "Foes")
PARTS = (story.WIN, story.LOSE)
# A placeholder the game fills in: ``{things}`` in a field line.
PLACEHOLDER = re.compile(r"\{(\w*)\}")


def _ending(line: str) -> str:
    return line[len(line.rstrip("\r\n")):]


def _body(line: str) -> str:
    return line.rstrip("\r\n")


# ----------------------------------------------------------------------
# ONE FILE
# ----------------------------------------------------------------------


class Document:
    """One file's lines: as opened (``base``) and as edited (``lines``)."""

    def __init__(self, path: str) -> None:
        self.path = path
        self.base = self._read()
        self.lines = list(self.base)
        self.newline = "\r\n" if any(line.endswith("\r\n") for line in self.base) else "\n"

    def _read(self) -> list[str]:
        with open(self.path, encoding="utf-8", newline="") as f:
            return f.read().splitlines(keepends=True)

    @property
    def unsaved(self) -> bool:
        return self.lines != self.base

    def set_line(self, index: int, text: str) -> None:
        """Line ``index`` becomes ``text``; its line ending is kept."""
        self.lines[index] = text + (_ending(self.lines[index]) or self.newline)

    def insert_after(self, index: int, text: str) -> None:
        if index >= 0 and not _ending(self.lines[index]):
            self.lines[index] += self.newline     # the file's last line had no ending
        self.lines.insert(index + 1, text + self.newline)

    def delete(self, index: int) -> None:
        del self.lines[index]

    def save(self, choices: dict[int, str] | None = None) -> list["Conflict"]:
        """Write the edits, merged with whatever changed on disk since opening.

        Returns the conflicts and writes nothing when the same lines were
        changed both here and on disk; call again with ``choices``, a
        conflict's number to ``"mine"`` or ``"disk"``, to write.
        """
        disk = self._read()
        merged, conflicts = merge(self.base, self.lines, disk, choices)
        if conflicts:
            return conflicts
        if merged != disk:
            self._store(merged)
        self.base, self.lines = list(merged), list(merged)
        return []

    def _store(self, merged: list[str]) -> None:
        """Put the merged lines in the file (a kind of document that is not text overrides this)."""
        _write(self.path, "".join(merged))


def _write(path: str, text: str) -> None:
    """Write through a file beside it, so a crash never leaves half a file."""
    folder = os.path.dirname(path)
    handle, temporary = tempfile.mkstemp(dir=folder, prefix=".lines-", suffix=".tmp")
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="") as f:
            f.write(text)
        os.replace(temporary, path)
    except BaseException:
        if os.path.exists(temporary):
            os.remove(temporary)
        raise


# ----------------------------------------------------------------------
# THE MERGE
# ----------------------------------------------------------------------


@dataclass
class Conflict:
    """Lines changed both here and on disk: what they were, and the two versions."""

    number: int
    base: list[str]
    mine: list[str]
    disk: list[str]


def _changes(base: list[str], other: list[str]) -> list[tuple[int, int, list[str]]]:
    """``other`` as changes to ``base``: replace ``base[start:stop]`` with these lines."""
    matcher = difflib.SequenceMatcher(None, base, other, autojunk=False)
    return [(i1, i2, other[j1:j2]) for tag, i1, i2, j1, j2 in matcher.get_opcodes() if tag != "equal"]


def _touch(a: tuple[int, int, list[str]], b: tuple[int, int, list[str]]) -> bool:
    """Whether two changes reach the same lines, or add lines at the same place."""
    if a[0] == b[0] or max(a[0], b[0]) < min(a[1], b[1]):
        return True
    # Lines added inside the lines the other side changed.
    return (a[0] == a[1] and b[0] < a[0] < b[1]) or (b[0] == b[1] and a[0] < b[0] < a[1])


def merge(base: list[str], mine: list[str], disk: list[str],
          choices: dict[int, str] | None = None) -> tuple[list[str], list[Conflict]]:
    """Both sets of changes to ``base`` in one; the conflicts where they meet.

    A change made the same way on both sides is no conflict. ``choices``
    settles conflicts by number: ``"mine"`` or ``"disk"``.
    """
    choices = choices or {}
    changes = sorted([(*c, "mine") for c in _changes(base, mine)] + [(*c, "disk") for c in _changes(base, disk)],
                     key=lambda c: (c[0], c[1]))
    # Group the changes that touch, so each group is applied, or chosen, as one.
    groups: list[list[tuple]] = []
    for change in changes:
        if groups and any(_touch(change[:3], other[:3]) for other in groups[-1]):
            groups[-1].append(change)
        else:
            groups.append([change])
    out: list[str] = []
    conflicts: list[Conflict] = []
    at = 0
    for group in groups:
        start = min(c[0] for c in group)
        stop = max(c[1] for c in group)
        out.extend(base[at:start])
        at = stop
        sides = {c[3] for c in group}
        versions = {side: _apply(base, start, stop, [c for c in group if c[3] == side]) for side in sides}
        if len(sides) == 1 or versions["mine"] == versions["disk"]:
            out.extend(next(iter(versions.values())))
            continue
        number = len(conflicts)
        choice = choices.get(number)
        conflicts.append(Conflict(number, base[start:stop], versions["mine"], versions["disk"]))
        out.extend(versions[choice] if choice in versions else versions["disk"])
    out.extend(base[at:])
    unsettled = [c for c in conflicts if c.number not in choices]
    return out, unsettled


def _apply(base: list[str], start: int, stop: int, changes: list[tuple]) -> list[str]:
    """``base[start:stop]`` with one side's changes in it."""
    out: list[str] = []
    at = start
    for c_start, c_stop, lines, _side in sorted(changes, key=lambda c: (c[0], c[1])):
        out.extend(base[at:c_start])
        out.extend(lines)
        at = c_stop
    out.extend(base[at:stop])
    return out


# ----------------------------------------------------------------------
# THE STORY SCRIPTS
# ----------------------------------------------------------------------


@dataclass
class Row:
    """One line of a scene as the window shows it.

    ``kind`` is ``"say"`` (someone talking), ``"narration"`` (a plain
    line), ``"part"`` (``If you win``), or ``"stage"`` (a direction, a
    choice, a fight, a note: shown dim, not edited here).
    """

    index: int
    kind: str
    text: str
    speaker: str = ""
    cond: str = ""
    marker: str = ""

    @property
    def editable(self) -> bool:
        return self.kind in ("say", "narration")


def read_row(index: int, line: str) -> Row | None:
    """What line ``index`` of a script is; None for a blank line."""
    body = _body(line).strip()
    if not body:
        return None
    if body.startswith("## "):
        return Row(index, "part", body[3:])
    match = SAY.match(_body(line))
    if match and match["who"] not in NOT_SPEAKERS:
        rest = match["rest"]
        marker = next((m for m in MARKERS if rest.startswith(m)), "")
        return Row(index, "say", rest[len(marker):].strip(), match["who"], match["cond"] or "", marker)
    if match or body.startswith("- "):
        return Row(index, "stage", body)
    return Row(index, "narration", body)


def write_row(speaker: str, text: str, cond: str = "", marker: str = "") -> str:
    """A line of a script from its parts, as ``read_row`` reads it back.

    Raises ValueError for what the game could not read: a narration line
    cannot have a condition, and a line cannot be empty or start like a
    heading or a list.
    """
    speaker, text, cond = speaker.strip(), " ".join(text.split()), " ".join(cond.split())
    if not text:
        raise ValueError("A line needs words. Delete it instead.")
    if "*" in speaker or ":" in speaker:
        raise ValueError("A name cannot have * or : in it.")
    if speaker in NOT_SPEAKERS:
        raise ValueError(f"{speaker} is a stage direction, not a speaker.")
    if cond and not re.fullmatch(r"[\w ]+", cond):
        raise ValueError("A condition is words only, like: hina, or maika along.")
    words = f"{marker} {text}" if marker else text
    if not speaker:
        if cond:
            raise ValueError("Narration cannot have a condition. Give it a speaker or clear the condition.")
        if words.startswith(("#", "- ", "**")):
            raise ValueError("Narration cannot start with #, - or **.")
        return words
    if cond:
        return f"**{speaker}** (if {cond}): {words}"
    return f"**{speaker}:** {words}"


def edit_row(document: Document, row: Row, speaker: str, text: str, cond: str) -> None:
    """Rewrite a row with new parts, keeping its indent and how fast it types.

    Raises ValueError, as ``write_row`` does, and if the words lose or gain
    a ``{placeholder}``, which the game fills in and would fail on.
    """
    if row.kind in ("say", "narration") and sorted(PLACEHOLDER.findall(text)) != sorted(PLACEHOLDER.findall(row.text)):
        names = ", ".join("{" + name + "}" for name in PLACEHOLDER.findall(row.text)) or "none"
        raise ValueError(f"Keep the words in curly brackets as they are ({names}); the game fills them in.")
    indent = re.match(r"\s*", document.lines[row.index])[0]
    document.set_line(row.index, indent + write_row(speaker, text, cond, row.marker))


def add_row(document: Document, after: int, speaker: str, text: str, cond: str = "") -> None:
    """A new line after line ``after`` of the file: after any row, a stage direction too,
    or before one by passing the line above it. The game plays it right there."""
    document.insert_after(after, write_row(speaker, text, cond))


FIELD_FILE = "story-field.md"


def field_problem(document: Document) -> str:
    """Why the game could not read ``story-field.md`` as edited, or "" (``core/field_lines.py``):
    a name ending in LINES needs at least one line, any other name exactly one."""
    for heading, names in field_lines.read("".join(document.lines)).items():
        for name, lines in names.items():
            several = name.endswith("LINES") and " " not in name
            if not lines or (len(lines) > 1 and not several):
                return (f"{name} needs exactly one line." if not several else f"{name} needs at least one line.")
    return ""


def cast_of(lines: list[str]) -> list[str]:
    """The names under a script's ``## Cast``, as ``core/story.py``'s ``cast`` reads them."""
    names, section = [], None
    for line in lines:
        body = _body(line).strip()
        if body.startswith("## "):
            section = body[3:].strip()
        elif section == "Cast" and body.startswith("- **"):
            names.append(body[4:].split("**")[0])
    return names


@dataclass
class Scene:
    """A scene in a script: from its heading to the next scene's."""

    title: str           # what the list shows
    file: str            # the script's file name, ``story-maika.md``
    heading: str         # ``Scene``, or its own heading, ``If you lied``
    start: int           # its heading's line
    stop: int            # the line after its last
    card: str = ""
    game_name: str = ""  # the game's name for it (``story.SCRIPTS``), for Play; "" if it has none


def script_files() -> list[str]:
    """The story scripts, in the game's order, then any it does not play yet."""
    order: list[str] = []
    for source in [*story.SCRIPTS.values(), *story.PYGAME_SCRIPTS.values()]:
        name = source.partition("#")[0]
        if name not in order:
            order.append(name)
    rest = sorted(f for f in os.listdir(SHARED_DIR) if f.startswith("story") and f.endswith(".md"))
    return [f for f in order if f in rest] + [f for f in rest if f not in order]


def game_names() -> dict[tuple[str, str], str]:
    """(file, heading) to the game's scene name; a file's plain entry is its ``## Scene``."""
    names = {}
    for name, source in [*story.SCRIPTS.items(), *story.PYGAME_SCRIPTS.items()]:
        file, _, heading = source.partition("#")
        names[(file, heading or "Scene")] = name
    return names


def scenes_of(file: str, lines: list[str]) -> list[Scene]:
    """The scenes in one script's lines; the file's title names its ``## Scene``."""
    title = next((_body(line)[2:].strip() for line in lines if _body(line).startswith("# ")), file)
    names = game_names()
    found: list[Scene] = []
    for index, line in enumerate(lines):
        body = _body(line).strip()
        if body.startswith("## "):
            heading = body[3:].strip()
            if found and found[-1].stop == -1 and heading not in PARTS:
                found[-1].stop = index
            if heading in NOT_SCENES or heading in PARTS:
                continue
            found.append(Scene(title if heading == "Scene" else heading, file, heading, index, -1,
                               game_name=names.get((file, heading), "")))
        elif body.startswith("**Card:**") and found and found[-1].stop == -1:
            found[-1].card = body[len("**Card:**"):].strip()
    if found and found[-1].stop == -1:
        found[-1].stop = len(lines)
    return found


def rows_of(document: Document, scene: Scene) -> list[Row]:
    """A scene's rows, its heading left out."""
    rows = []
    for index in range(scene.start + 1, scene.stop):
        row = read_row(index, document.lines[index])
        if row is not None:
            rows.append(row)
    return rows


def scenes_with_speaker(speaker: str, library: "Library | None" = None) -> list[Scene]:
    """Every story scene (the scripts and the field lines) where ``speaker`` has a line, in the
    game's order. The Workshop's right click on a person lists these (Frankie, 11/5)."""
    library = library or Library()
    found = []
    for file in script_files():
        document = library.script(file)
        for scene in scenes_of(file, document.lines):
            if any(row.kind == "say" and row.speaker == speaker for row in rows_of(document, scene)):
                found.append(scene)
    return found


def open_document(path: str) -> Document:
    """The right kind of document for a file: a script, or a room or menu of the villagers' lines."""
    from core import dialogue_villagers

    return dialogue_villagers.VillagerDocument(path) if path.endswith(".json") else Document(path)


@dataclass
class Library:
    """Every file the lines window has open, so edits in several wait for one Save."""

    documents: dict[str, Document] = field(default_factory=dict)

    def script(self, file: str) -> Document:
        """A story script by its file name, or a room or menu (``cells/chief_house.json``)."""
        from core import dialogue_villagers      # it builds on this module, so it is read when used

        if dialogue_villagers.is_villager_file(file):
            return self.open(dialogue_villagers.path_of(file))
        return self.open(os.path.join(SHARED_DIR, file))

    def open(self, path: str) -> Document:
        if path not in self.documents:
            self.documents[path] = open_document(path)
        return self.documents[path]

    @property
    def unsaved(self) -> list[Document]:
        return [d for d in self.documents.values() if d.unsaved]
