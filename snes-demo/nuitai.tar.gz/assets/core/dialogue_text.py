"""A person's words as plain text, for the Workshop's dialogue window (Frankie, 10/25).

A room file keeps what each person says as lists (``core/overworld_cells.py``).
The dialogue window shows them as text to type into, and this module turns
one into the other, both ways, so the window never touches the lists itself.

The text, one row per text box:

    Go get the Great Boar, big brother! Bring me back a tusk!
    talk:
      Keo: Can I come? I'll be really quiet.
      Kailo: Not this time, Keo.
    once melia_asked_dad:
      Melia: Do you think your dad's ever coming back?
      Kailo: ...
      Hina (with hina): Melia!
    I am doing my chores! I'm counting the pots.

Each talk the person says the next line, round and round (Frankie, 10/26).
A plain row is one line, said by the person. ``talk:`` starts an exchange
played whole as one line; its rows are indented and start with who says
them. ``once FLAG:`` is the same, played one time only, then never again.
``(with hina)`` plays that row only with Hina along. A first visit's words
(``talk``) are all ``Speaker: words`` rows. ``flag_lines`` (what someone says
once a flag is set, like the chief with no stew) get a box per flag.
"""

from __future__ import annotations

import re
from typing import Any

# The fields of a person the window edits: (where, its heading, rows say who speaks).
# ``first.talk`` is the ``talk`` inside ``first``; ``flag_lines.FLAG`` one flag's lines.
FIELDS = (
    ("lines", "What they say", False),
    ("night_lines", "At night", False),
    ("first.talk", "First visit, the scene", True),
    ("first.lines", "First visit, after the scene", False),
)

_EXCHANGE = re.compile(r"^(?:talk|once\s+(\w+))\s*:$")
_SPOKEN = re.compile(r"^([^:()]+?)\s*(?:\(with\s+(\w+)\))?\s*:\s*(.+)$")


def fields_of(person: dict) -> list[tuple[str, str, bool]]:
    """The fields the window shows for ``person``: what they say, and the rest only where they apply."""
    shown = []
    for key, heading, spoken in FIELDS:
        if key == "lines" or (key == "night_lines" and person.get("home")) or _get(person, key) is not None:
            shown.append((key, heading, spoken))
    shown[1:1] = [(f"flag_lines.{flag}", f"Once {flag} is set", False) for flag in person.get("flag_lines", {})]
    return shown


def _split(key: str) -> tuple[str, str]:
    """``first.talk`` as (``first``, ``talk``); a plain key as ("", key)."""
    outer, _, inner = key.rpartition(".")
    return outer, inner


def _get(person: dict, key: str) -> Any:
    outer, name = _split(key)
    return (person.get(outer) or {}).get(name) if outer else person.get(name)


def _row(row: list) -> str:
    speaker, said, *along = row
    return f"{speaker} (with {along[0]}): {said}" if along else f"{speaker}: {said}"


def to_text(person: dict, key: str) -> str:
    """One field of ``person`` as the window's text."""
    value = _get(person, key) or []
    if key == "first.talk":
        return "\n".join(_row(row) for row in value)
    out = []
    for line in value:
        if isinstance(line, dict):
            out.append(f"once {line['once']}:" if line.get("once") else "talk:")
            out.extend("  " + _row(row) for row in line["talk"])
        else:
            out.append(line)
    return "\n".join(out)


def _spoken(row: str, number: int) -> list[str]:
    match = _SPOKEN.match(row)
    if match is None:
        raise ValueError(f"Row {number}: start it with who says it, like  Kailo: words")
    speaker, along, said = match.groups()
    return [speaker, said, along] if along else [speaker, said]


def from_text(text: str, key: str) -> list:
    """The window's text for one field, back as the room file's list.

    Raises:
        ValueError: naming the row that cannot be read.
    """
    rows = [(number, row.rstrip()) for number, row in enumerate(text.splitlines(), 1) if row.strip()]
    if key == "first.talk":
        return [_spoken(row.strip(), number) for number, row in rows]
    out: list = []
    exchange: dict | None = None
    for number, row in rows:
        heading = _EXCHANGE.match(row.strip())
        if heading:
            exchange = {"once": heading.group(1), "talk": []} if heading.group(1) else {"talk": []}
            out.append(exchange)
        elif row[:1].isspace() and exchange is not None:
            exchange["talk"].append(_spoken(row.strip(), number))
        else:
            exchange = None
            out.append(row.strip())
    for line in out:
        if isinstance(line, dict) and not line["talk"]:
            start = f"once {line['once']}:" if line.get("once") else "talk:"
            raise ValueError(f"{start} give it indented rows, like    Kailo: words")
    return out


def apply(person: dict, key: str, value: list) -> None:
    """Put one field back on ``person``; an empty field is left out of the file, and so is an emptied ``flag_lines``."""
    outer, name = _split(key)
    target = person.setdefault(outer, {}) if outer else person
    if value:
        target[name] = value
    else:
        target.pop(name, None)
        if outer and not target:
            person.pop(outer)
