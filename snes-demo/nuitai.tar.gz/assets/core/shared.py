"""The shared battle file: one set of numbers for two games.

``game/shared/battle.json`` holds the battle's rules, stats rule,
characters, moves, monsters and encounters. This game reads it here,
once, at import. The cartridge's art build reads it too
(``game/snes/tools/make_art.py``).

Nothing in this module may import ``settings``: ``settings`` imports
this module to fill in its battle constants.
"""

from __future__ import annotations

import json
import os
from typing import Any

# core/ -> pygame/ -> game/, then across into shared/. The web build
# carries a copy inside the game's own folder, as shared/battle.json,
# since a browser gets nothing outside it (tools/web_build.py).
_GAME_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHARED_DIR = (
    os.path.join(_GAME_DIR, "shared")
    if os.path.exists(os.path.join(_GAME_DIR, "shared", "battle.json"))
    else os.path.join(os.path.dirname(_GAME_DIR), "shared")
)
SHARED_PATH = os.path.join(SHARED_DIR, "battle.json")


def _load() -> dict[str, Any]:
    """Read and parse the shared battle file."""
    with open(SHARED_PATH, encoding="utf-8") as f:
        return json.load(f)


SHARED: dict[str, Any] = _load()


def by_id(section: str) -> dict[str, dict[str, Any]]:
    """Return one list section of the shared file as a dict keyed by id.

    Args:
        section: "characters", "moves", "monsters" or "encounters".

    Returns:
        The entries in file order, so iterating the dict keeps the
        order the file lists them in (which is the menu order).
    """
    return {entry["id"]: entry for entry in SHARED[section]}


def short_name(member_id: str) -> str:
    """Return a character's first name from their id: "kailo" is "Kailo".

    The display names ("Kailo the Cook", "Holy Hina") are too long for
    the 8 pixel letters of the 256 pixel screen (D-445), so the battle
    window and the party roster use first names, the way Final Fantasy
    held every name to a few letters.
    """
    return member_id.replace("_", " ").split(" ")[0].capitalize()


def role(member_id: str) -> str:
    """Return a character's role, the title from their wiki article: "Cook" (Frankie, 10/23)."""
    return by_id("characters").get(member_id, {}).get("role", "")


def skills(member_id: str) -> list[dict[str, Any]]:
    """Every Skill ``member_id`` has, built or not (``off``), in file order.

    A Skill is a signature move (``"signature": true``); its ``owner``
    has it, and so does anyone in its ``also`` list (the staff Skill is
    Maika's and Tawiri's both).
    """
    return [m for m in by_id("moves").values() if m.get("signature")
            and (m.get("owner") == member_id or member_id in m.get("also", ()))]


def skill_for(member_id: str, weapon_type: str | None = None) -> dict[str, Any] | None:
    """The Skill ``member_id`` has with a ``weapon_type`` in hand, or None.

    Each character has three Skills, one per weapon type, and can use
    only the one for the type held (Frankie, 10/31). A character whose
    Skill has no ``weapon_type`` yet (everyone but the demo's four) has
    that one Skill whatever they hold.

    With no ``weapon_type`` it is their first built Skill: what the
    cartridge, which has no weapons yet, shows.
    """
    theirs = skills(member_id)
    if weapon_type is None:
        return next((m for m in theirs if not m.get("off")), None)
    return next((m for m in theirs if m.get("weapon_type") == weapon_type),
                next((m for m in theirs if "weapon_type" not in m), None))


def signature_name(member_id: str, weapon_type: str | None = None) -> str:
    """Return the name of a character's Skill, their signature command (D-692), or "".

    ``weapon_type`` is the type in hand, which picks the Skill (``skill_for``).
    """
    skill = skill_for(member_id, weapon_type)
    return skill["name"] if skill else ""
