"""The shared battle file: one set of numbers for two games.

``game/shared/battle.json`` holds the battle's rules, stats rule,
characters, moves, monsters and encounters. This game reads it here,
once, at import. The browser battle test carries a pasted copy of the
same file (see ``game/shared/build.py``), so a number changed there
changes in both.

Nothing in this module may import ``settings``: ``settings`` imports
this module to fill in its battle constants.
"""

from __future__ import annotations

import json
import os
from typing import Any

# core/ -> pygame/ -> game/, then across into shared/. The web build
# carries a copy inside the game's own folder, as shared/battle.json,
# since a browser gets nothing outside it (tools/web_build.py).
_GAME_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHARED_DIR = (
    os.path.join(_GAME_DIR, "shared")
    if os.path.exists(os.path.join(_GAME_DIR, "shared", "battle.json"))
    else os.path.join(os.path.dirname(_GAME_DIR), "shared")
)
SHARED_PATH = os.path.join(SHARED_DIR, "battle.json")


def _load() -> dict[str, Any]:
    """Read and parse the shared battle file."""
    with open(SHARED_PATH, encoding="utf-8") as f:
        return json.load(f)


SHARED: dict[str, Any] = _load()


def by_id(section: str) -> dict[str, dict[str, Any]]:
    """Return one list section of the shared file as a dict keyed by id.

    Args:
        section: "characters", "moves", "monsters" or "encounters".

    Returns:
        The entries in file order, so iterating the dict keeps the
        order the file lists them in (which is the menu order).
    """
    return {entry["id"]: entry for entry in SHARED[section]}


def short_name(member_id: str) -> str:
    """Return a character's first name from their id: "kailo" is "Kailo".

    The display names ("Kailo the Cook", "Holy Hina") are too long for
    the 8 pixel letters of the 256 pixel screen (D-445), so the battle
    window and the party roster use first names, the way Final Fantasy
    held every name to a few letters.
    """
    return member_id.replace("_", " ").split(" ")[0].capitalize()
