"""What a weapon and a relic do (game/answers.md, Relics and the weapon effects line; Frankie, 10/24).

A weapon has one benefit and one penalty. For now only stat ones work: the
benefit's stat times ``weapon_benefit`` and the penalty's times
``weapon_penalty`` in the shared file (x1.25 and x0.8), so no weapon is
better, only different. A relic is worn one at a time; its element, its
material's, adds that element stance's weakness on top of the wearer's
own, multiplied: an Ananá (water) relic takes fire at x0.5 and nature at x2.
"""

from __future__ import annotations

import json
import os
from fractions import Fraction
from typing import Any

from core.elements import Element, damage_multiplier, label
from core.shared import SHARED, SHARED_DIR, by_id
from core.stats import STAT_KEYS

BENEFIT = Fraction(str(SHARED["weapon_benefit"]))
PENALTY = Fraction(str(SHARED["weapon_penalty"]))


def weapon_multipliers(weapon_id: str | None) -> dict[str, Fraction]:
    """What the weapon ``weapon_id`` multiplies, stat key -> multiplier; empty for none."""
    weapon = by_id("weapons").get(weapon_id or "", {})
    times: dict[str, Fraction] = {}
    if weapon.get("benefit") in STAT_KEYS:
        times[weapon["benefit"]] = BENEFIT
    if weapon.get("penalty") in STAT_KEYS:
        times[weapon["penalty"]] = times.get(weapon["penalty"], Fraction(1)) * PENALTY
    return times


def relic(relic_id: str | None) -> dict[str, Any] | None:
    """The relic ``relic_id`` from the shared file, or None."""
    return by_id("relics").get(relic_id or "")


def relic_element(relic_id: str | None) -> Element | None:
    """The element a relic adds the stance weakness of, or None."""
    worn = relic(relic_id)
    return Element(worn["element"]) if worn else None


def relic_multiplier(attack: Element, relic_id: str | None) -> float:
    """What the relic does to an ``attack`` element hitting its wearer: x0.5, x1 or x2."""
    element = relic_element(relic_id)
    return damage_multiplier(attack, element) if element is not None else 1.0


def resists(relic_id: str | None) -> list[tuple[str, int]]:
    """A relic's elements, each with +1 for resisted or -1 for weak: the Equip screen's line."""
    element = relic_element(relic_id)
    if element is None:
        return []
    out = [(e.value, 1 if damage_multiplier(e, element) < 1 else -1)
           for e in Element if damage_multiplier(e, element) != 1]
    return sorted(out, key=lambda pair: -pair[1])


def relic_help(relic_id: str | None) -> str:
    """The help line for a relic: what it resists and what it is weak to."""
    words = {1: "Resists", -1: "Weak to"}
    return " ".join(f"{words[sign]} {label(e).lower()}." for e, sign in resists(relic_id))


with open(os.path.join(SHARED_DIR, "item-names.json"), encoding="utf-8") as _f:
    _NAMES: dict[str, Any] = json.load(_f)


def can_hold(member_id: str, item_id: str) -> bool:
    """Whether ``member_id`` can hold the weapon or wear the relic ``item_id``: three types each."""
    weapon = by_id("weapons").get(item_id)
    if weapon:
        return weapon["type"] in by_id("characters").get(member_id, {}).get("weapon_types", [])
    worn = relic(item_id)
    return bool(worn) and worn["type"] in _NAMES["relics"]["wearers"].get(member_id, [])


def slot_of(item_id: str) -> str | None:
    """Which slot an item goes in: "weapon", "relic", or None for anything else."""
    if item_id in by_id("weapons"):
        return "weapon"
    return "relic" if relic(item_id) else None
