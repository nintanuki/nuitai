"""Scene select (Frankie, 10/25): any beat of the demo, without playing up to it.

Every beat is one entry in ``BEATS`` below. A beat is reached by playing the
demo up to it through the game's own code, the way a player would: the
story scenes are paged through, their fights won, Hina visited, Maika's
shop bought from, the Great Boar beaten, the tusk handed over. Nothing is
set by hand, so a beat follows the story wherever the story changes. The
acts are played in ``ACTS`` order; a beat names the last one it needs
(``after``), any it leaves out (``without``: the wake without Maika) and
where Kailo then stands (``stand``: room, col, row, facing),
or is left where the last scene put him.

A new beat is one entry: a name, an ``after`` and a ``stand``. A beat that
needs a step the story does not play yet is one new act in ``ACTS`` too.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from settings import AudioSettings, StewSettings, StorySettings
from ui import input_map

if TYPE_CHECKING:
    from main import GameManager
    from core.scenes.overworld_scene import OverworldScene


# The demo's beats, in story order. ``new_game`` is the title's own New Game;
# ``after`` the last act played; ``stand`` where Kailo is put afterwards;
# ``without`` the acts left out; ``until_fight`` plays the wake to its fight, wins it
# and stops there. The wake plays differently without Maika (the plate, not Shaka and
# Lanu), so it and the kidnapping are here both ways (Frankie, 10/25).
BEATS: tuple[dict, ...] = (
    {"name": "The opening", "new_game": True},
    # Talking to her plays her scene.
    {"name": "Hina joins", "after": "taro_patch", "stand": ("hina_house", 10, 8, (0, -1))},
    {"name": "Free roaming by day", "after": "hina_joins"},
    {"name": "Before the Great Boar", "after": "maika_joins", "stand": ("farm_field", 7, 12, (0, -1))},
    {"name": "Night after the boar", "after": "great_boar"},
    # Talking to Melia hands over the tusk.
    {"name": "The tusk", "after": "great_boar", "stand": ("beach_west", 8, 6, (-1, 0))},
    # The tusk is hers: one step east, into the chief's room, and Hina asks about the wake (10/25).
    {"name": "The wake", "after": "tusk", "stand": ("beach_west", 15, 6, (1, 0))},
    {"name": "The wake, no Maika", "after": "tusk", "without": ("maika_joins",),
     "stand": ("beach_west", 15, 6, (1, 0))},
    # The wake's fight won: what comes after it, the kidnapping.
    {"name": "The kidnapping", "after": "wake", "until_fight": True},
    {"name": "The kidnapping, no Maika", "after": "wake", "without": ("maika_joins",), "until_fight": True},
)

# Frames the field may run to finish one act before giving up (a scene that never ends).
_FRAME_LIMIT = 20000


def beat_names() -> list[str]:
    """The beats' names, in story order, for the menu."""
    return [beat["name"] for beat in BEATS]


def start(gm: "GameManager", index: int) -> None:
    """Throw away the stack and begin the demo at beat ``index``."""
    beat = BEATS[index]
    if beat.get("new_game"):
        from core.scenes.title_scene import TitleScene  # local: cycle.

        TitleScene.new_game(gm)
        return
    # Quiet while it plays: every scene's sounds would come at once.
    muted, AudioSettings.MUTE = AudioSettings.MUTE, True
    try:
        scene = play_to(gm, beat)
    finally:
        AudioSettings.MUTE = muted
    stand = beat.get("stand")
    if stand is not None:
        put(scene, *stand)
    scene._room_sound()


def play_to(gm: "GameManager", beat: dict) -> "OverworldScene":
    """A new game played up to ``beat``'s last act; the field it ends on, on the stack alone."""
    from core.scenes.overworld_scene import OverworldScene  # local: cycle.
    from core.scenes.title_scene import build_default_party  # local: cycle.

    gm.party = build_default_party()
    scene = OverworldScene(gm)
    gm.scene_stack.clear()
    gm.scene_stack.push(scene)
    names = [name for name, _ in ACTS]
    last = names.index(beat["after"])
    for name, act in ACTS[:last + 1]:
        if name in beat.get("without", ()):
            continue
        act(gm, scene, beat.get("until_fight", False) and name == beat["after"])
    return scene


def put(scene: "OverworldScene", room: str, col: int, row: int, facing: tuple[int, int]) -> None:
    """Stand Kailo in ``room`` at ``col``, ``row``, facing ``facing``."""
    from core.overworld_cells import WORLD_LAYOUT  # local: as the rest of the field

    scene.world.go_to(next(pos for pos, name in WORLD_LAYOUT.items() if name == room))
    scene.player.from_dict({"col": col, "row": row, "facing": list(facing)})


# ---------------------------------------------------------------------------
# PLAYING: the field run a frame at a time, its text paged through
# ---------------------------------------------------------------------------

def _confirm():
    import pygame

    return pygame.event.Event(pygame.KEYDOWN, key=input_map.confirm_key(), mod=0, unicode="")


def _win(gm: "GameManager", battle) -> None:
    """Every foe down and the fight won, then left, as its last line closing does."""
    for foe in battle.battle.enemies:
        foe.hp = 0
    battle.battle._outcome = "victory"
    battle._sync_party_state_back()
    gm.scene_stack.pop()


def _play(gm: "GameManager", scene: "OverworldScene", until_fight: bool = False) -> None:
    """Run the field until the story is over and its text closed, winning its fights.

    Stops early when something else waits on top (a shop, a question), or,
    with ``until_fight``, just after a fight is won.
    """
    from core.scenes.battle_scene import BattleScene  # local: cycle.
    from core.scenes.choice_scene import ChoiceScene  # local: cycle.

    for _ in range(_FRAME_LIMIT):
        top = gm.scene_stack.top
        if isinstance(top, BattleScene):
            _win(gm, top)
            if until_fight:
                return
            continue
        if isinstance(top, ChoiceScene):
            top.handle_event(_confirm())   # the first answer
            continue
        if top is not scene:
            return
        if scene.text_box.is_done() and scene.story is None and scene.stage is None:
            return
        scene.text_box.update(10.0)
        scene.text_box.advance()
        scene.update(1 / 60)
    raise RuntimeError("scene select: the story did not finish")


def _talk(gm: "GameManager", scene: "OverworldScene", room: str, speaker: str) -> None:
    """Walk up to whoever in ``room`` is ``speaker`` (from below) and talk to them."""
    put(scene, room, 0, 0, (0, -1))
    person = next(p for p in scene.world.people if p.get("speaker", p.get("sheet")) == speaker)
    put(scene, room, person["col"], person["row"] + 1, (0, -1))
    scene.handle_event(_confirm())


# ---------------------------------------------------------------------------
# THE ACTS, in story order
# ---------------------------------------------------------------------------

def _taro_patch(gm, scene, until_fight=False) -> None:
    """The opening scene to its end: Hina goes home."""
    scene.begin_story("taro_patch")
    _play(gm, scene)


def _hina_joins(gm, scene, until_fight=False) -> None:
    """Her house: talking to her plays her scene, and she joins."""
    put(scene, "hina_house", 10, 8, (0, -1))
    scene.handle_event(_confirm())
    _play(gm, scene)


def _maika_joins(gm, scene, until_fight=False) -> None:
    """His sister's deal in the lodge, his scene and his plea at his stall, the lie to her, and he joins.

    Buying from him no longer makes him join (Frankie, 10/30); the first answer to
    his sister's question is the lie, which is the way to him.
    """
    from core.scenes.shop_scene import ShopScene  # local: cycle.

    _talk(gm, scene, "hunters_lodge", "Miki")
    _play(gm, scene)
    _talk(gm, scene, "blocks_room", "Maika")
    _play(gm, scene)
    if not isinstance(gm.scene_stack.top, ShopScene):
        raise RuntimeError("scene select: Maika's shop did not open")
    gm.scene_stack.pop()
    _play(gm, scene)
    _talk(gm, scene, "hunters_lodge", "Miki")
    _play(gm, scene)
    _talk(gm, scene, "blocks_room", "Maika")
    _play(gm, scene)


def _great_boar(gm, scene, until_fight=False) -> None:
    """His room, his fight won, and the scene after: it is night, the tusk in the bag."""
    # The stew gates the night (Frankie, 10/30): this scene starts with it made.
    gm.party.flags[StewSettings.MADE_FLAG] = True
    put(scene, StorySettings.SEED_ROOM, 7, 12, (0, -1))
    scene._place_monsters()
    boss = next(m for m in scene.monsters if m.spot.get("boss"))
    scene._start_fight(boss)
    _play(gm, scene)


def _tusk(gm, scene, until_fight=False) -> None:
    """Melia at night: Kailo gives her the tusk."""
    put(scene, "beach_west", 8, 6, (-1, 0))
    scene.handle_event(_confirm())
    _play(gm, scene)


def _wake(gm, scene, until_fight=False) -> None:
    """YES to Hina: the wake, to its end or, ``until_fight``, to its fight won."""
    put(scene, StorySettings.ASK_ROOM, 8, 7, (0, 1))
    scene.begin_story(StorySettings.WAKE_SCENE)
    _play(gm, scene, until_fight)


ACTS: tuple[tuple[str, Callable], ...] = (
    ("taro_patch", _taro_patch),
    ("hina_joins", _hina_joins),
    ("maika_joins", _maika_joins),
    ("great_boar", _great_boar),
    ("tusk", _tusk),
    ("wake", _wake),
)
