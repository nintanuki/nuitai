"""Build runtime gameplay objects from JSON content data.

This module is the single seam between content packs (the JSON dicts
returned by ``core.data_loader.DataLoader``) and the runtime objects
the simulation operates on (``PartyMember``, ``Combatant``).

Every "load X from data" path in the engine should land here so the
JSON-to-runtime mapping is never duplicated across scenes. When a new
kind of content needs a runtime form, add a factory here rather than
constructing the object inline in a scene.
"""

from __future__ import annotations

from typing import Any

from core.elements import Element
from core.shared import by_id, short_name
from core.stats import max_hp_for, stat_points
from settings import BattleSettings
from systems.battle import Combatant
from systems.loadout import checked, knows
from systems.party import PartyMember


def party_member_from_data(data: dict[str, Any]) -> PartyMember:
    """Construct a ``PartyMember`` from a character JSON dict.

    Args:
        data: A character entry from the shared battle file, with
            ``id``, ``name``, and a two-element ``elements`` list.
            Combat stats are derived from the elements, and battle
            moves are looked up by element through ``Battle.moves_for``,
            so neither is read from this dict.

    Returns:
        A fresh ``PartyMember`` ready to be added to a ``Party``.
    """
    elements = data["elements"]
    return PartyMember(
        member_id=data["id"],
        name=data["name"],
        elements=(elements[0], elements[1]),
        stats=dict(data.get("stats", {})),
        learnset=list(data.get("learnset", [])),
        weapon=data.get("weapon"),
    )


def combatant_from_party_member(member: PartyMember) -> Combatant:
    """Build the battle-time combatant for a party member.

    HP is read from ``member.current_hp`` so a member who walked into
    the encounter already injured starts the battle at that lower
    health.

    Args:
        member: The party member to drop into a battle.

    Returns:
        A ``Combatant`` carrying both of the member's elements.
    """
    # Floor current HP at 1 so a member who was knocked out last fight
    # still gets to participate; a proper "fainted" state will replace
    # this with a KO path.
    current_hp = max(1, min(member.current_hp, member.max_hp))
    return Combatant(
        combatant_id=member.id,
        # First names in a fight (D-445): "Kailo", not "Kailo the Cook".
        name=short_name(member.id),
        elements=(Element(element_id) for element_id in member.elements),
        is_party=True,
        max_hp=member.max_hp,
        hp=current_hp,
        stances=by_id("characters").get(member.id, {}).get("stances"),
        stance=member.stance,
        loadout=checked(member.loadout, known_moves(member.id, member.elements)),
    )


def known_moves(member_id: str, elements: tuple[str, ...]) -> list[dict[str, Any]]:
    """Return every technique a character knows, in both stances, in file order."""
    return [m for m in by_id("moves").values() if knows(m, member_id, elements)]


def combatant_from_monster_data(
    entry: dict[str, Any], monster: dict[str, Any]
) -> Combatant:
    """Build a battle-time combatant for one monster in an encounter.

    Args:
        entry: One item of an encounter's ``enemies`` list in the
            shared battle file: this monster's ``id``, ``name`` and
            ``element`` for this fight.
        monster: The matching entry from the shared file's
            ``monsters``: authored ``hp``, ``moves``, and the
            ``beast``, ``boss`` and ``immune`` facts shared by every
            monster of the kind.

    Returns:
        A ``Combatant`` ready to drop into a ``Battle`` as an opponent.
        A boss counts its element twice so its stats keep pace with
        the party's.
    """
    element = Element(entry["element"])
    return Combatant(
        combatant_id=entry["id"],
        name=entry["name"],
        elements=(element, element) if monster.get("boss") else (element,),
        is_party=False,
        max_hp=round(monster["hp"] * BattleSettings.MONSTER_HP_SCALE),
        moves=monster["moves"],
        beast=bool(monster.get("beast")),
        immune=monster.get("immune", ()),
        poison_rate=monster.get("poison_rate"),
    )


def stance_numbers(member: PartyMember) -> tuple[dict[str, int], int, int]:
    """Return ``member``'s stats, HP and max HP in the stance they start a fight in.

    The stance's element counts twice and the other not at all, HP
    keeping its share (D-365): what the fight will show.
    """
    stances = by_id("characters").get(member.id, {}).get("stances", [])
    stance = (
        Element(stances[member.stance if 0 <= member.stance < len(stances) else 0]["element"])
        if stances else None
    )
    points = stat_points((Element(e) for e in member.elements), stance)
    top = max_hp_for(points)
    return points, round(member.current_hp * top / max(1, member.max_hp)), top
