"""Build runtime gameplay objects from JSON content data.

This module is the single seam between content packs (the JSON dicts
returned by ``core.data_loader.DataLoader``) and the runtime objects
the simulation operates on (``PartyMember``, ``Combatant``).

Every "load X from data" path in the engine should land here so the
JSON-to-runtime mapping is never duplicated across scenes. When a new
kind of content needs a runtime form, add a factory here rather than
constructing the object inline in a scene.
"""

from __future__ import annotations

from typing import Any

from core.elements import Element
from core.equipment import weapon_multipliers
from core.shared import by_id, short_name
from core.stats import max_hp_for, monster_hp, stat_points
from systems.battle import Combatant

# A monster's own stats in the shared file use the browser's short keys.
_MONSTER_STAT_KEYS = {
    "hp": "hp", "str": "strength", "mag": "magic", "vit": "vitality",
    "spr": "spirit", "spd": "speed", "acc": "accuracy", "eva": "evasion",
}
from systems import mastery
from systems.loadout import checked, knows, open_slots
from systems.party import PartyMember
from settings import ItemSettings


def party_member_from_data(data: dict[str, Any]) -> PartyMember:
    """Construct a ``PartyMember`` from a character JSON dict.

    Args:
        data: A character entry from the shared battle file, with
            ``id``, ``name``, and a two-element ``elements`` list.
            Combat stats are derived from the elements, and battle
            moves are looked up by element through ``Battle.moves_for``,
            so neither is read from this dict.

    Returns:
        A fresh ``PartyMember`` ready to be added to a ``Party``.
    """
    elements = data["elements"]
    return PartyMember(
        member_id=data["id"],
        name=data["name"],
        elements=(elements[0], elements[1]),
        stats=dict(data.get("stats", {})),
        learnset=list(data.get("learnset", [])),
        weapon=data.get("weapon"),
        relic=data.get("relic"),
    )


def combatant_from_party_member(member: PartyMember,
                                flags: dict[str, bool] | None = None) -> Combatant:
    """Build the battle-time combatant for a party member.

    HP is read from ``member.current_hp`` so a member who walked into
    the encounter already injured starts the battle at that lower
    health, and one knocked out starts it fallen (Frankie, 10/26):
    only a totem, a revive or Hina's passive gets them up.

    Args:
        member: The party member to drop into a battle.
        flags: The party's story flags, for the demo's kit
            (``known_moves``); None for the full kit.

    Returns:
        A ``Combatant`` carrying both of the member's elements.
    """
    current_hp = max(0, min(member.current_hp, member.max_hp))
    return Combatant(
        combatant_id=member.id,
        # First names in a fight (D-445): "Kailo", not "Kailo the Cook".
        name=short_name(member.id),
        elements=(Element(element_id) for element_id in member.elements),
        is_party=True,
        max_hp=member.max_hp,
        hp=current_hp,
        stances=by_id("characters").get(member.id, {}).get("stances"),
        stance=member.stance,
        loadout=checked(member.loadout, known_moves(member.id, member.elements, flags),
                        first_loadout(member.id, flags), open_slots(flags)),
        growth=member.growth,
        meters=member.meters,
        mastery=member.mastery,
        weapon_type=mastery.type_held(member.id, member.weapon),
        multipliers=weapon_multipliers(member.weapon),
        relic=member.relic,
    )


def known_moves(member_id: str, elements: tuple[str, ...],
                flags: dict[str, bool] | None = None) -> list[dict[str, Any]]:
    """Return the techniques a character knows, in both stances, in file order.

    With the party's story ``flags``, the demo's kit (Frankie, 10/22): the
    character's ``demo_moves`` in the shared file, plus each of its
    ``demo_learns`` once ``<member>_learned_<move>`` is set. Without them,
    or for a character with no demo kit, the full kit, as Free Battle has.
    A signature move (Skill, D-692) is left out: it takes no slot.
    """
    character = by_id("characters").get(member_id, {})
    if flags is not None and "demo_moves" in character:
        # A lontar teaches its move whether or not the character's demo_learns lists it (Frankie, 11/4).
        learnable = set(character.get("demo_learns", ())) | {
            move_id for owner, move_id in ItemSettings.SHELLS.values() if owner == member_id}
        ids = set(character["demo_moves"]) | {
            move_id for move_id in learnable if flags.get(f"{member_id}_learned_{move_id}")
        }
        return [m for m in by_id("moves").values() if m["id"] in ids]
    return [m for m in by_id("moves").values()
            if knows(m, member_id, elements) and not m.get("signature")]


def first_loadout(member_id: str, flags: dict[str, bool] | None = None) -> dict[str, int] | None:
    """Return where a character's techniques start: the demo's rows with ``flags``, else the written loadout."""
    character = by_id("characters").get(member_id, {})
    if flags is not None and "demo_moves" in character:
        return {move_id: row for move_id, row in character["demo_moves"].items() if row}
    return character.get("loadout")


def combatant_from_monster_data(
    entry: dict[str, Any], monster: dict[str, Any]
) -> Combatant:
    """Build a battle-time combatant for one monster in an encounter.

    Args:
        entry: One item of an encounter's ``enemies`` list in the
            shared battle file: this monster's ``id``, ``name`` and
            ``element`` for this fight.
        monster: The matching entry from the shared file's
            ``monsters``: authored ``stats`` (its ``hp`` is its Vitality), ``moves``, and the
            ``beast``, ``boss`` and ``immune`` facts shared by every
            monster of the kind.

    Returns:
        A ``Combatant`` ready to drop into a ``Battle`` as an opponent.
        A boss counts its element twice so its stats keep pace with
        the party's.
    """
    element = Element(entry["element"])
    # A two-stance monster (D-591): the fight's element first, the other second,
    # each with its own moves and the pair moves of both.
    pools = None
    if monster.get("stances") and monster.get("moves_2"):
        other = next((Element(e) for e in monster["stances"] if Element(e) is not element),
                     Element(monster["stances"][1]))
        both = monster.get("moves_both", [])
        pools = [(element, monster["moves"] + both), (other, monster["moves_2"] + both)]
    combatant = Combatant(
        combatant_id=entry["id"],
        name=entry["name"],
        elements=(element, element) if monster.get("boss") else (element,),
        is_party=False,
        max_hp=monster_hp(monster),
        moves=pools[0][1] if pools else monster["moves"],
        beast=bool(monster.get("beast")),
        undead=bool(monster.get("undead")),
        immune=monster.get("immune", ()),
        poison_rate=monster.get("poison_rate"),
        pools=pools,
        switch=monster.get("switch"),
        kind=entry.get("monster"),
        loot=monster.get("steal"),
        # Monsters fight on the heroes' rules (Frankie, 10/22 and 10/23): their own
        # Strength and Magic, added as a hero's grown points are, power their blows.
        growth={_MONSTER_STAT_KEYS[k]: v for k, v in monster.get("stats", {}).items() if k != "hp"},
    )
    # Its Vitality is listed whole, not added to the base, and max HP is that times ten,
    # as a hero's (Frankie, 11/1).
    if "hp" in monster.get("stats", {}):
        combatant.points["hp"] = monster["stats"]["hp"]
    combatant.boss = bool(monster.get("boss"))
    # Its Skill, every monster's one signature move (the Great Boar's is Squeal),
    # and the Great Boar's anger (Frankie, 10/28; systems/battle.py).
    combatant.skill = monster.get("skill")
    combatant.angry_rule = monster.get("angry")
    combatant.picture = entry.get("sprite")
    return combatant


def stance_numbers(member: PartyMember) -> tuple[dict[str, int], int, int]:
    """Return ``member``'s stats, HP and max HP in the stance they start a fight in.

    The stance's element counts twice and the other not at all, HP
    keeping its share (D-365), plus what the member has grown (D-498):
    what the fight will show.
    """
    stances = by_id("characters").get(member.id, {}).get("stances", [])
    stance = (
        Element(stances[member.stance if 0 <= member.stance < len(stances) else 0]["element"])
        if stances else None
    )
    points = stat_points((Element(e) for e in member.elements), stance, member.growth,
                         weapon_multipliers(member.weapon))
    top = max_hp_for(points)
    return points, round(member.current_hp * top / max(1, member.max_hp)), top
