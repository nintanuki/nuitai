"""Active overworld state.

Owns which cell is currently loaded, exposes per-tile wall queries
against that cell, and handles cell-to-cell transitions when the player
crosses the action-window edge. Putting this in one place keeps the
renderer (which reads ``current_grid``) and the player (which calls
``is_wall`` / ``step_to_neighbor``) decoupled from how the cell layout
is stored.

When more than one layer exists (overworld + dungeons + house
interiors), this is the natural place to grow a ``current_layer`` field
plus an entrance-tile table. For Pass 1 there is only the overworld
layer, so it stays implicit.

The shape of this module — ``CELLS`` / ``WORLD_LAYOUT`` / ``current_pos``
+ ``step_to_neighbor`` — is lifted from the Adventure project; the
implementation is written fresh in Nuitai's conventions and routes wall
queries through ``OverworldSettings.WALL_CHAR`` so the tile alphabet
lives in one place (``settings.py``).
"""

from __future__ import annotations

import random

from core import generated
from core.overworld_cells import BUILDINGS, CELLS, PEOPLE, START_CELL_POS, WORLD_LAYOUT, building_tiles, warps
from settings import BackgroundSettings, OverworldSettings
from systems.garden import patches_in


# A removed room's old place on the map, to the room a save made there loads in.
_GONE_ROOMS: dict[tuple[int, int], str] = {(2, 40): "kailo_house"}
# A removed room's old place a new room stands on: a save made there stays, and steps off
# whatever is under it now. Kailo's yard, then the harbor (Frankie, 10/27).
_BUILT_OVER: set[tuple[int, int]] = {(-1, 0)}


def _in_village(name: str) -> bool:
    """Whether ``name`` is one of the town's rooms or the inside of a building in one."""
    return name in BackgroundSettings.TOWN_ROOMS or any(
        building.get("inside") == name
        for town in BackgroundSettings.TOWN_ROOMS for building in BUILDINGS.get(town, []))


class World:
    """Tracks the active cell and answers wall/transition questions about it."""

    def __init__(self, seed: int | None = None) -> None:
        """Initialize the world at ``START_CELL_POS``.

        The generated places (the woods, D-731) are built from ``seed``;
        with none, a new one is picked, so every new game walks a
        different woods.
        """
        self.cells = CELLS
        self.layout = WORLD_LAYOUT
        self.seed = random.randrange(2 ** 31) if seed is None else seed
        generated.install(self.seed)
        self.current_pos: tuple[int, int] = START_CELL_POS
        # Who has joined the party, so a person who joins leaves the map.
        self.joined: set[str] = set()
        # Night: the village is empty but for Melia, everyone else at Pono's
        # wake (Frankie, 10/23); whoever stays has a ``night`` question, or is
        # ``home``, Kailo's two other cousins (Claude's call, 10/25).
        self.night = False
        # The party's flags, so a person with a ``first`` form (Melia hiding, 10/25)
        # stands in it only until that visit's flag is set.
        self.flags: dict = {}
        # Where each person is in their round of lines, kept from visit to visit (Frankie, 10/26).
        self.turns: dict[int, dict] = {}
        # The rooms Kailo has walked into, for the area map on SELECT (Frankie, 10/26);
        # the field adds each room as he stands in it (``OverworldScene._frame``).
        self.seen: set[str] = set()
        self._refresh_active_cell()

    # ------------------------------------------------------------------
    # ACTIVE CELL
    # ------------------------------------------------------------------

    def _refresh_active_cell(self) -> None:
        """Re-bind ``current_cell_name`` and ``current_grid`` from ``current_pos``."""
        cell_name = self.layout[self.current_pos]
        self.current_cell_name: str = cell_name
        # A copy, so a tree felled this visit (the ko'i) stands again next visit.
        self.current_grid: list[list[str]] = [list(row) for row in self.cells[cell_name]]
        # Copies, so whoever turned to talk faces their own way again next visit.
        self.people: list[dict] = [
            self._visit_form(person) for person in PEOPLE.get(cell_name, [])
            if person.get("joins") not in self.joined
            # Gone once that party member has joined: Miki, who thinks her brother left the island.
            and person.get("leaves_with") not in self.joined
            and not (self.night and _in_village(cell_name) and not (person.get("night") or person.get("home")))
            # Melia hiding in the west room ``until`` she goes home, by the pots only ``after``;
            # at night she is home whatever the flags say (Frankie, 10/25).
            and not (person.get("until") and self.flags.get(person["until"]))
            # Gone for good once its flag is set, night or day: Melia taken, the morning after the jump.
            and not (person.get("gone") and self.flags.get(person["gone"]))
            and not (person.get("after") and not self.flags.get(person["after"]) and not self.night)
        ]
        # A ``night`` building stands only at night: the sign in the old man's place.
        self.buildings: list[dict] = [b for b in BUILDINGS.get(cell_name, []) if self.night or not b.get("night")]
        # Each tile a building blocks, to the building (a rug blocks nothing).
        self.building_tiles: dict[tuple[int, int], dict] = {
            tile: building for building in self.buildings for tile in building_tiles(building)
            if building["kind"] not in OverworldSettings.FLAT_BUILDINGS
        }
        # Hina's garden patches (systems/garden.py) stand in the way too.
        self.patch_tiles: dict[tuple[int, int], int] = {
            (patch["col"], patch["row"]): index for index, patch in enumerate(patches_in(cell_name))
        }

    def _visit_form(self, person: dict) -> dict:
        """A copy of ``person``, sharing their place in their round of lines; on the first
        visit by day, with their ``first`` form laid over it.

        Melia hides beside Hina's house until Kailo finds her (Frankie, 10/25).
        """
        first = person.get("first")
        turn = {"turn": self.turns.setdefault(id(person), {})}
        if not first or self.night or self.flags.get(first["flag"]):
            return {**person, **turn}
        return {**person, **{key: value for key, value in first.items() if key != "flag"}, **turn}

    def go_to(self, pos: tuple[int, int]) -> bool:
        """Jump to the room at ``pos``; False, and no move, when there is none."""
        pos = (int(pos[0]), int(pos[1]))
        if pos not in self.layout:
            return False
        self.current_pos = pos
        self._refresh_active_cell()
        return True

    def person_at(self, col: int, row: int) -> dict | None:
        """Return the person standing at ``(col, row)``, or None."""
        for person in self.people:
            if (person["col"], person["row"]) == (col, row):
                return person
        return None

    def warp(self, col: int, row: int, facing: tuple[int, int]) -> tuple[int, int] | None:
        """Through a door: if stepping ``facing`` from ``(col, row)`` goes through one,
        move into the room behind it and return where the party stands there."""
        target = warps().get((self.current_cell_name, col, row, tuple(facing)))
        if target is None:
            return None
        name, to_col, to_row = target
        self.go_to(next(pos for pos, who in self.layout.items() if who == name))
        return (to_col, to_row)

    def building_at(self, col: int, row: int) -> dict | None:
        """Return the building covering ``(col, row)``, or None."""
        return self.building_tiles.get((col, row))

    # ------------------------------------------------------------------
    # COLLISION QUERIES
    # ------------------------------------------------------------------

    def is_wall(self, col: int, row: int) -> bool:
        """Return whether the tile at ``(col, row)`` blocks movement.

        Tiles outside the cell's grid are reported as non-walls so the
        player can step into the cell-transition code in
        ``OverworldPlayer._begin_step`` rather than being clamped by
        collision.

        Args:
            col: Cell-local column index (0-based, east-positive).
            row: Cell-local row index (0-based, south-positive).

        Returns:
            ``True`` for wall tiles and impassable water; ``False`` for
            floor, sand, and out-of-bounds positions.
        """
        if not (0 <= row < OverworldSettings.ROWS and 0 <= col < OverworldSettings.COLS):
            return False
        if (self.person_at(col, row) is not None or (col, row) in self.building_tiles
                or (col, row) in self.patch_tiles):
            return True
        return self.current_grid[row][col] not in OverworldSettings.WALKABLE_CHARS

    def tile_at(self, col: int, row: int) -> str | None:
        """Return the cell char at ``(col, row)``, or None off the cell."""
        if not (0 <= row < OverworldSettings.ROWS and 0 <= col < OverworldSettings.COLS):
            return None
        return self.current_grid[row][col]

    # ------------------------------------------------------------------
    # CELL TRANSITIONS
    # ------------------------------------------------------------------

    def step_to_neighbor(self, dx_cells: int, dy_cells: int) -> bool:
        """Try to swap to the neighbor cell at the given world offset.

        Args:
            dx_cells: ``-1`` west, ``+1`` east, ``0`` no horizontal step.
            dy_cells: ``-1`` north, ``+1`` south, ``0`` no vertical step.

        Returns:
            ``True`` if the neighbor cell exists and was swapped in;
            ``False`` if no cell sits at that world coordinate (caller
            should treat the step as a bump).
        """
        cx, cy = self.current_pos
        new_pos = (cx + dx_cells, cy + dy_cells)
        if new_pos in self.layout:
            self.current_pos = new_pos
            self._refresh_active_cell()
            return True
        return False

    # ------------------------------------------------------------------
    # PERSISTENCE
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Serialise the active-cell pointer and the seed the generated places grew from."""
        return {"current_pos": list(self.current_pos), "seed": self.seed, "seen": sorted(self.seen)}

    def from_dict(self, data: dict) -> None:
        """Restore the generated places, the rooms found and the active-cell pointer from a saved dict."""
        seen = data.get("seen")
        if isinstance(seen, list):
            self.seen = {name for name in seen if isinstance(name, str)}
        seed = data.get("seed")
        if isinstance(seed, int) and seed != self.seed:
            self.seed = seed
            generated.install(seed)
            self._refresh_active_cell()
        pos = data.get("current_pos")
        if isinstance(pos, list) and len(pos) == 2:
            candidate = (int(pos[0]), int(pos[1]))
            # Rooms that are gone (Frankie, 10/26): Kailo's yard is scrapped and the
            # hut left of Hina's is his house again, so a save made in either loads
            # in the room that took its place.
            gone = _GONE_ROOMS.get(candidate)
            if gone is not None:
                candidate = next((p for p, name in self.layout.items() if name == gone), candidate)
                self.moved_from_gone_room = True
            elif candidate in _BUILT_OVER:
                self.moved_from_gone_room = True
            if candidate in self.layout:
                self.current_pos = candidate
                self._refresh_active_cell()
