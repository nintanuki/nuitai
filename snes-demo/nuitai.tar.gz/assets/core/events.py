"""Typed event records emitted by gameplay systems.

Gameplay systems (`systems/battle.py`, `systems/dialogue.py`, future world
events) **emit** these records. View modules (`ui/battle_view.py`,
`ui/text_box.py`, future overworld renderer) **consume** them. The
producer never knows which view, if any, is listening; the view never
calls back into the producer.

This separation is what allows the same gameplay engine to drive Layer
1's text-only presentation, Layer 3's Dragon-Quest-style sprites, and
Layer 5's full-art combat without rewrites.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from core.elements import Element


# ---------------------------------------------------------------------------
# BATTLE EVENTS
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class TurnStartEvent:
    """Emitted at the top of a combatant's turn."""

    combatant_id: str
    combatant_name: str


@dataclass(frozen=True)
class AttackEvent:
    """Emitted when a combatant declares an attack against a target.

    ``element`` is ``None`` for non-elemental swings — party members'
    basic attacks always sit here. Abilities and (for now) enemy basic
    attacks carry the element they were authored with.
    """

    attacker_id: str
    attacker_name: str
    target_id: str
    target_name: str
    element: Element | None
    # The named move behind the attack ("Gore"), or None for a plain swing.
    move_name: str | None = None


@dataclass(frozen=True)
class DamageEvent:
    """Emitted after damage is computed and applied.

    ``element`` is ``None`` for non-elemental damage. ``multiplier`` is
    the element-matchup scalar applied (1.0 for non-elemental or
    cross-triangle) — views key the "super effective" / "not very
    effective" narration off of this number rather than recomputing
    matchups themselves.
    """

    target_id: str
    target_name: str
    amount: int
    element: Element | None
    multiplier: float  # 2.0 / 1.0 / 0.5 — lets views narrate effectiveness.
    # True when a guarding ally took the hit at the guard rate, so the
    # multiplier is the guard's and says nothing about weakness.
    guarded: bool = False
    # True when the hit woke a sleeping target.
    woke: bool = False
    # "hit" for an attack, "poison" for a poison tick, "counter" for
    # a guard striking back, "stroke" for one stroke of an Attack,
    # "spell" for magic.
    cause: str = "hit"
    # True when the target blocked the blow for half damage.
    blocked: bool = False
    # For a stroke: who struck, and the stroke's name ("Light").
    attacker_name: str | None = None
    stroke: str | None = None


@dataclass(frozen=True)
class StatusAppliedEvent:
    """Emitted when a combatant gains or loses a status condition."""

    target_id: str
    target_name: str
    status: str
    applied: bool  # True = gained, False = removed.


@dataclass(frozen=True)
class CombatantDefeatedEvent:
    """Emitted when a combatant's HP drops to zero."""

    combatant_id: str
    combatant_name: str


@dataclass(frozen=True)
class DefendEvent:
    """Emitted when a combatant chooses to defend.

    Defending halves incoming damage until the combatant's next turn.
    The status itself lives on ``Combatant.is_defending``; this event is
    the narration hook.
    """

    combatant_id: str
    combatant_name: str


@dataclass(frozen=True)
class AbilityUsedEvent:
    """Emitted when a combatant invokes a named ability.

    Damage / heal numbers still ride on ``DamageEvent`` / ``HealEvent``;
    this event is the narration hook that names the move.
    """

    user_id: str
    user_name: str
    ability_id: str
    ability_name: str
    # Who it was aimed at, or None for a move with no target.
    target_name: str | None = None


@dataclass(frozen=True)
class HealEvent:
    """Emitted after HP is restored on a combatant."""

    target_id: str
    target_name: str
    amount: int


@dataclass(frozen=True)
class PotionUsedEvent:
    """Emitted when a party member spends a potion to heal.

    The accompanying ``HealEvent`` carries the actual HP restored.
    ``potions_remaining`` is included so the view can refresh its
    on-screen ``x{N}`` indicator from the same stream.
    """

    user_id: str
    user_name: str
    target_id: str
    target_name: str
    potions_remaining: int


@dataclass(frozen=True)
class MissEvent:
    """Emitted when a physical attack misses (the attacker is blind)."""

    attacker_id: str
    attacker_name: str
    target_id: str
    target_name: str


@dataclass(frozen=True)
class GuardRaisedEvent:
    """Emitted when a combatant takes up a guard stance.

    ``guard`` is the stance id from the move data ("sentinel",
    "counter"). The stance lasts until the combatant's next turn.
    """

    combatant_id: str
    combatant_name: str
    guard: str


@dataclass(frozen=True)
class GuardInterceptEvent:
    """Emitted when a guarding ally steps in front of a physical hit."""

    guard_id: str
    guard_name: str
    target_id: str
    target_name: str


@dataclass(frozen=True)
class WardBlockedEvent:
    """Emitted when Shaka's Light stops a shadow attack and is used up."""

    target_id: str
    target_name: str


@dataclass(frozen=True)
class StatusResistedEvent:
    """Emitted when a status fails to take hold.

    ``immune`` is True when the target can never have this status,
    False when it simply shook this attempt off.
    """

    target_id: str
    target_name: str
    status: str
    immune: bool


@dataclass(frozen=True)
class CleansedEvent:
    """Emitted when a combatant's bad statuses are removed."""

    target_id: str
    target_name: str


@dataclass(frozen=True)
class RevivedEvent:
    """Emitted when a fallen combatant gets back up (Revive)."""

    target_id: str
    target_name: str
    hp: int


@dataclass(frozen=True)
class TurnSkippedEvent:
    """Emitted when a combatant loses its turn to a status (sleep)."""

    combatant_id: str
    combatant_name: str
    status: str


@dataclass(frozen=True)
class BattleEndedEvent:
    """Emitted once the battle is fully resolved."""

    # "victory", "defeat", or "flee".
    outcome: str


# ---------------------------------------------------------------------------
# DIALOGUE / WORLD EVENTS
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class DialogueLineEvent:
    """One line of dialogue ready to be displayed."""

    speaker: Optional[str]   # None = narrator / no speaker tag.
    text: str


@dataclass(frozen=True)
class DialogueEndedEvent:
    """Emitted when a dialogue tree finishes."""

    dialogue_id: str


@dataclass(frozen=True)
class StrokeEvent:
    """Emitted as one stroke of an Attack is swung (D-213 to D-220).

    No narration of its own: the ``DamageEvent`` or ``DodgeEvent`` that
    follows says how it went. Views use it to move the striker.
    """
    attacker_id: str
    attacker_name: str
    target_id: str
    target_name: str
    stroke: str  # "Light", "Medium" or "Strong".


@dataclass(frozen=True)
class DodgeEvent:
    """Emitted when a physical blow is dodged, or a stroke misses."""
    attacker_id: str
    attacker_name: str
    target_id: str
    target_name: str
    # The stroke's name, or None for a technique or a monster's move.
    stroke: str | None = None


@dataclass(frozen=True)
class ManaEvent:
    """Emitted when a combatant's mana changes.

    ``total`` is the meter after the change, so a view can draw it from
    the event stream alone. No narration: the meter shows it.
    """
    combatant_id: str
    combatant_name: str
    change: int
    total: int


@dataclass(frozen=True)
class ChainEndedEvent:
    """Emitted when a monster's chain of strokes is over.

    The strokes themselves are told by floating numbers and sounds; this
    is the one line for the whole chain (Frankie, 10/17).
    """
    attacker_id: str
    attacker_name: str
    # The one it struck, or None when the chain moved on to another.
    target_name: str | None
    total: int


@dataclass(frozen=True)
class StanceEvent:
    """Emitted when a party member changes stance (D-257, D-285)."""
    combatant_id: str
    combatant_name: str
    stance_name: str
    element: Element



@dataclass(frozen=True)
class SwapEvent:
    """Emitted when a party member steps back and one from the bench takes their place (D-455)."""

    out_id: str
    out_name: str
    in_id: str
    in_name: str


@dataclass(frozen=True)
class EscapeEvent:
    """Emitted when a party member tries to run (D-455). A success also ends the battle."""

    combatant_id: str
    combatant_name: str
    escaped: bool


@dataclass(frozen=True)
class WeaponEvent:
    """Emitted when a party member changes the weapon they hold (D-455)."""

    combatant_id: str
    combatant_name: str
    weapon_name: str


@dataclass(frozen=True)
class ComboUsedEvent:
    """Emitted when two party members strike together."""

    user_id: str
    user_name: str
    partner_id: str
    partner_name: str
    combo_name: str
