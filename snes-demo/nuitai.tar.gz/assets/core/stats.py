"""Element-shaped stats: the single home for how elements become numbers.

Every combatant starts at ``StatSettings.BASE_POINTS`` in each of six
stats. Each element they carry then adds two bonuses:

* a small one to both stats of its triangle (material elements raise
  Strength and Vitality, spiritual ones raise Magic and Spirit), and
* a larger one to the two stats of its job (see ``_JOB_STATS``).

A party member carries two elements and so gets twice the bonus of an
ordinary monster, which carries one. A boss lists its one element
twice to keep pace with the party.

The same rule runs in the browser battle test
(``game/browser/ctb-battle.html``, ``statsFor``), and both read their
numbers and tables from ``game/shared/battle.json``. The design notes
are in ``game/browser/battle-moves.md`` under "Stats".
"""

from __future__ import annotations

from typing import Iterable

from core.elements import Element
from core.shared import SHARED
from settings import StatSettings


STAT_KEYS: tuple[str, ...] = (
    "hp", "strength", "magic", "vitality", "spirit", "speed",
    "accuracy", "evasion",
)

# Both tables come from the shared battle file.
_MATERIAL: frozenset[Element] = frozenset(
    Element(element_id) for element_id in SHARED["stats"]["material"]
)

# The two stats each element's job leans on.
_JOB_STATS: dict[Element, tuple[str, ...]] = {
    Element(element_id): tuple(stat_keys)
    for element_id, stat_keys in SHARED["stats"]["jobs"].items()
}


def stat_points(
    elements: Iterable[Element], stance: Element | None = None
) -> dict[str, int]:
    """Return the stat scores for a combatant with ``elements``.

    Args:
        elements: The combatant's elements. Repeats count each time.
        stance: The element of the stance a party member fights in, or
            None. With the shared file's ``stance_rule`` "move" (D-365),
            the stance's element counts twice and the other element not
            at all, HP included, so the total never changes.

    Returns:
        A dict keyed by ``STAT_KEYS``. ``hp`` is a score, not a hit
        point total; pass it through ``max_hp_for``.
    """
    points = {key: StatSettings.BASE_POINTS for key in STAT_KEYS}
    moving = stance is not None and StatSettings.STANCE_RULE == "move"
    for element in elements:
        times = (2 if element is stance else 0) if moving else 1
        triangle = (
            ("strength", "vitality") if element in _MATERIAL
            else ("magic", "spirit")
        )
        for key in triangle:
            points[key] += times * StatSettings.TRIANGLE_BONUS
        for key in _JOB_STATS[element]:
            points[key] += times * StatSettings.JOB_BONUS
    if stance is not None and not moving:
        # The older rule (D-257): the stance adds a little to its job, never HP.
        for key in _JOB_STATS[stance]:
            if key != "hp":
                points[key] += StatSettings.STANCE_BONUS
    return points


def max_hp_for(points: dict[str, int]) -> int:
    """Return the hit point total a party member's HP score is worth."""
    return points["hp"] * StatSettings.HP_PER_POINT


def offense_scale(score: int) -> float:
    """Return the damage scalar for an attacking Strength or Magic score.

    A score at the base is 1.0; every point above adds five percent.
    """
    base = StatSettings.BASE_POINTS
    return (base + score) / (2 * base)


def defense_scale(score: int) -> float:
    """Return the scalar a Vitality, Spirit or Speed score shrinks things by.

    A score at the base is 1.0; higher scores give smaller numbers, so
    damage taken (or time waited) goes down.
    """
    base = StatSettings.BASE_POINTS
    return (2 * base) / (base + score)
