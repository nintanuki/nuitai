"""Element-shaped stats: the single home for how elements become numbers.

How a stat is built (Frankie, 10/23):

* every stat starts at ``StatSettings.BASE_POINTS``, plus what has grown
  (rises in a fight and seeds; a monster's listed Strength and Magic go
  in the same way);
* each of the combatant's elements multiplies the two stats of its job
  (see ``_JOB_STATS``) by ``ELEMENT_MULTIPLIER``; an element listed twice
  (a boss), or two elements sharing a job stat, multiply it twice;
* the stance in play multiplies its element's two job stats by
  ``STANCE_MULTIPLIER``;
* the result is rounded once, half up.

Growth goes into the base, so every multiplier applies to it again.
The Super Nintendo cartridge (``game/snes/``) works the same rule from
the same numbers in ``game/shared/battle.json``.
"""

from __future__ import annotations

import math
from fractions import Fraction
from typing import Iterable

from core.elements import Element
from core.shared import SHARED
from settings import StatSettings


STAT_KEYS: tuple[str, ...] = (
    "hp", "strength", "magic", "vitality", "spirit", "speed",
    "accuracy", "evasion",
)

# The names that show, by key (D-499, D-501, D-502). The files keep the keys.
STAT_NAMES: dict[str, str] = {
    "hp": "Vitality",
    "strength": "Strength",
    "magic": "Intelligence",
    "vitality": "Endurance",
    "spirit": "Willpower",
    "speed": "Agility",
    "accuracy": "Perception",
    "evasion": "Luck",
}
# The same, three letters each, where a screen has room for no more (the
# Equip screen's two columns, 10/23). Claude's. In capitals, as short stat
# labels are (Frankie, 10/27).
STAT_SHORT: dict[str, str] = {
    "hp": "VIT", "strength": "STR", "magic": "INT", "vitality": "END",
    "spirit": "WIL", "speed": "AGI", "accuracy": "PER", "evasion": "LUK",
}

# The two stats each element's job leans on, from the shared battle file.
_JOB_STATS: dict[Element, tuple[str, ...]] = {
    Element(element_id): tuple(stat_keys)
    for element_id, stat_keys in SHARED["stats"]["jobs"].items()
}
# The multipliers as exact fractions, so every game rounds the same way.
_ELEMENT = Fraction(str(StatSettings.ELEMENT_MULTIPLIER))
_STANCE = Fraction(str(StatSettings.STANCE_MULTIPLIER))


def stat_points(
    elements: Iterable[Element],
    stance: Element | None = None,
    growth: dict[str, int] | None = None,
    multipliers: dict[str, Fraction] | None = None,
) -> dict[str, int]:
    """Return the stat scores for a combatant with ``elements``.

    Args:
        elements: The combatant's elements. Repeats count each time.
        stance: The element of the stance a party member fights in, or
            None for the stats outside a fight.
        growth: Points grown (rises in a fight, seeds), stat key ->
            points, added to the base before any multiplier. A
            monster's listed Strength and Magic come in here too.
        multipliers: What the weapon held does (core/equipment.py), stat
            key -> multiplier, applied with the stance's before rounding.

    Returns:
        A dict keyed by ``STAT_KEYS``. ``hp`` is a score, not a hit
        point total; pass it through ``max_hp_for``.
    """
    points = {key: Fraction(StatSettings.BASE_POINTS) for key in STAT_KEYS}
    for key, grown in (growth or {}).items():
        if key in points:
            points[key] += int(grown)
    for element in elements:
        for key in _JOB_STATS[element]:
            points[key] *= _ELEMENT
    if stance is not None:
        for key in _JOB_STATS[stance]:
            points[key] *= _STANCE
    for key, times in (multipliers or {}).items():
        if key in points:
            points[key] *= times
    return {key: math.floor(value + Fraction(1, 2)) for key, value in points.items()}


def job_stats(element: Element | None) -> tuple[str, ...]:
    """Return the two stats ``element``'s job leans on, or none for None."""
    return _JOB_STATS.get(element, ()) if element is not None else ()


def max_hp_for(points: dict[str, int]) -> int:
    """Return the hit point total a party member's HP score is worth."""
    return points["hp"] * StatSettings.HP_PER_POINT


def monster_hp(monster: dict) -> int:
    """Return a shared-file monster's max HP: its listed Vitality (``stats.hp``) times ten.

    A monster's HP is never a number set by hand (Frankie, 11/1); this is the
    one place the shared file's Vitality becomes hit points, as a hero's does.
    """
    return monster.get("stats", {}).get("hp", 0) * StatSettings.HP_PER_POINT


def offense_scale(score: int) -> float:
    """Return the damage scalar for an attacking Strength or Magic score.

    A score at the base is 1.0; every point above adds five percent.
    """
    base = StatSettings.BASE_POINTS
    return (base + score) / (2 * base)


def defense_scale(score: int) -> float:
    """Return the scalar a Vitality, Spirit or Speed score shrinks things by.

    A score at the base is 1.0; higher scores give smaller numbers, so
    damage taken (or time waited) goes down.
    """
    base = StatSettings.BASE_POINTS
    return (2 * base) / (base + score)
