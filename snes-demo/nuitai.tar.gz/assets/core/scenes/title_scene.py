"""The title screen — the first scene the player sees.

Offers NEW GAME and CONTINUE (Frankie, 10/23). No Quit, as on a Super Nintendo
title: the window's close button or L1 R1 START SELECT closes it.
Picking NEW GAME builds a default party and replaces the stack with
the overworld. CONTINUE lists the three save slots to pick one (D-523).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core import save
from core.factories import party_member_from_data
from core.scene import Scene
from core.shared import by_id
from settings import (
    BattleSettings,
    ColorSettings,
    FontSettings,
    RecordSettings,
    ScreenSettings,
    UISettings,
)
from systems import records
from systems.party import Party
from ui import input_map, text_renderer
from ui.menu import Menu, MenuItem
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager


# Order in which the default party is built. The ids are resolved
# against the characters in the shared battle file. The first three
# fight; the rest wait on the bench (D-196). The demo starts with Kailo
# and Hina; Maika joins in the woods and Tawiri at the wake (Frankie, 10/22).
_DEFAULT_PARTY_IDS: tuple[str, ...] = ("kailo", "hina")
# Everyone who can be in the demo's party, in the order they join.
DEMO_CAST: tuple[str, ...] = ("kailo", "hina", "maika", "tawiri")


def add_missing_members(party: Party) -> None:
    """Give a save from before someone joined the default party that member."""
    characters = by_id("characters")
    for member_id in _DEFAULT_PARTY_IDS:
        data = characters.get(member_id)
        if data is not None and party.find(member_id) is None:
            party.add(party_member_from_data(data))
    # Everyone holds their own weapon from the start (D-462).
    for member in party.members:
        if member.weapon is None:
            member.weapon = characters.get(member.id, {}).get("weapon")


def build_default_party() -> Party:
    """Construct a fresh party from the shared file's characters.

    Seeds the starting potion stack into ``Party.inventory`` so a new
    game's first battle has something to drink.

    Returns:
        A populated ``Party``. An id with no character entry is
        skipped rather than crashing.
    """
    characters = by_id("characters")
    party = Party()
    for member_id in _DEFAULT_PARTY_IDS:
        data = characters.get(member_id)
        if data is None:
            continue
        party.add(party_member_from_data(data))
    party.inventory["potion"] = BattleSettings.STARTING_POTIONS
    # The calendar starts in late summer (Frankie, 10/23; systems/records.py).
    party.flags[records.DATE_FLAG] = RecordSettings.START_DAY
    return party


class TitleScene(Scene):
    """The opening menu."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Construct the title screen menu."""
        super().__init__(gm)
        from core.scenes.overworld_scene import OverworldScene  # local: cycle.

        any_save_exists = save.newest_slot() is not None
        items = [
            MenuItem("New Game", self._new_game),
            # Continue lists the three slots, as Final Fantasy VI's does (Frankie, 10/23).
            MenuItem("Continue", self._load_game, enabled=any_save_exists),
        ]
        # The Workshop, the room editor, is its own program now
        # (``Workshop.pyw``), never on the game's title (Frankie, 10/23).
        self.menu = Menu(items=items)
        # Cached so ``_new_game`` doesn't re-import on
        # every menu pick.
        self._world_cls = OverworldScene

    def on_enter(self) -> None:
        """Frankie's Main Theme, with the surf under it (Frankie, 10/23).

        It plays on under the save slots, and ``play_screen`` leaves it
        playing when they close.
        """
        self.gm.audio.play_screen("title")

    def on_exit(self) -> None:
        """Stop the title's music when a game begins."""
        self.gm.audio.stop_music()

    # ------------------------------------------------------------------
    # ACTIONS
    # ------------------------------------------------------------------

    def _new_game(self) -> None:
        """A fresh overworld and a default party, opening on the taro patch scene."""
        self.gm.party = build_default_party()
        world = self._world_cls(self.gm)
        world.begin_story("taro_patch")
        self.gm.scene_stack.replace(world)

    def _load_game(self) -> None:
        """List the three slots to pick a game from."""
        from core.scenes.save_slot_scene import SaveSlotScene  # local: cycle.

        self.gm.scene_stack.push(SaveSlotScene(self.gm, loading=True))

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """
        Translate input into menu navigation.

        Args:
            event: The pygame event to handle.
        """
        if input_map.is_up(event):
            if self.menu.move_up():
                self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            if self.menu.move_down():
                self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            if self.menu.confirm():
                self.gm.audio.play("menu_select")

    def render(self, surface: pygame.Surface) -> None:
        """
        Draw the title text and the menu.

        Args:
            surface: The screen surface to draw on.
        """
        render_scene_background(self, surface)

        text_renderer.draw_text(
            surface,
            ScreenSettings.TITLE_SCREEN_HEADING,
            (UISettings.TITLE_SCREEN_HEADING_X, UISettings.TITLE_SCREEN_HEADING_Y),
            color=ColorSettings.WHITE,
            size=FontSettings.SIZE_TITLE_SCREEN_HEADING,
        )

        self.menu.render(
            surface,
            (UISettings.TITLE_SCREEN_MENU_X, UISettings.TITLE_SCREEN_MENU_TOP_Y),
            centered=False,
            item_spacing=UISettings.TITLE_SCREEN_MENU_ITEM_SPACING,
        )
