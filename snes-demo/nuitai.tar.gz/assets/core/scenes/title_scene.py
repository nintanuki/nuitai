"""The title screen — the first scene the player sees.

Offers NEW GAME, CONTINUE, LOAD GAME, and QUIT.
Picking NEW GAME builds a default party and replaces the stack with
the overworld. CONTINUE loads the newest of the three save slots and
LOAD GAME lists them to pick one (D-523).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core import save
from core.factories import party_member_from_data
from core.scene import Scene
from core.shared import by_id
from settings import (
    AssetPaths,
    BattleSettings,
    ColorSettings,
    FontSettings,
    ScreenSettings,
    UISettings,
)
from systems.party import Party
from ui import input_map, text_renderer
from ui.menu import Menu, MenuItem
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager


# Order in which the default party is built. The ids are resolved
# against the characters in the shared battle file. The first three
# fight; the rest wait on the bench (D-196). Maika joined 10/18 (D-460).
_DEFAULT_PARTY_IDS: tuple[str, ...] = ("kailo", "hina", "tawiri", "maika")


def add_missing_members(party: Party) -> None:
    """Give a save from before someone joined the default party that member."""
    characters = by_id("characters")
    for member_id in _DEFAULT_PARTY_IDS:
        data = characters.get(member_id)
        if data is not None and party.find(member_id) is None:
            party.add(party_member_from_data(data))
    # Everyone holds their own weapon from the start (D-462).
    for member in party.members:
        if member.weapon is None:
            member.weapon = characters.get(member.id, {}).get("weapon")


def build_default_party() -> Party:
    """Construct a fresh party from the shared file's characters.

    Seeds the starting potion stack into ``Party.inventory`` so a new
    game's first battle has something to drink.

    Returns:
        A populated ``Party``. An id with no character entry is
        skipped rather than crashing.
    """
    characters = by_id("characters")
    party = Party()
    for member_id in _DEFAULT_PARTY_IDS:
        data = characters.get(member_id)
        if data is None:
            continue
        party.add(party_member_from_data(data))
    party.inventory["potion"] = BattleSettings.STARTING_POTIONS
    return party


class TitleScene(Scene):
    """The opening menu."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Construct the title screen menu."""
        super().__init__(gm)
        from core.scenes.overworld_scene import OverworldScene  # local: cycle.

        any_save_exists = save.newest_slot() is not None
        self.menu = Menu(
            items=[
                MenuItem("New Game", self._new_game),
                MenuItem("Continue", self._continue, enabled=any_save_exists),
                MenuItem("Load Game", self._load_game, enabled=any_save_exists),
                MenuItem("Quit", self.gm.ask_to_quit),
            ],
        )
        # Cached so ``_new_game`` / ``_continue`` don't re-import on
        # every menu pick.
        self._world_cls = OverworldScene

    def on_enter(self) -> None:
        """Start looping ambient waves while the title screen is active.

        Answering NO to the quit box brings this scene back to the top
        while the waves are still playing; restarting them then would
        cut the loop off mid-wave, so they only start from silence.
        """
        audio = self.gm.audio
        if not pygame.mixer.get_init() or not pygame.mixer.music.get_busy() or audio.screen:
            audio.play_music_track(AssetPaths.WAVES_SOUND, loops=-1)

    def on_exit(self) -> None:
        """Stop title ambience when leaving this scene."""
        self.gm.audio.stop_music()

    # ------------------------------------------------------------------
    # ACTIONS
    # ------------------------------------------------------------------

    def _continue(self) -> None:
        """Walk on from the newest save, where the party stood."""
        from core.scenes.save_slot_scene import resume  # local: cycle.

        slot_id = save.newest_slot()
        if slot_id is not None:
            resume(self.gm, save.peek(slot_id) or {})

    def _new_game(self) -> None:
        """Replace the stack with a fresh overworld and a default party."""
        self.gm.party = build_default_party()
        self.gm.scene_stack.replace(self._world_cls(self.gm))

    def _load_game(self) -> None:
        """List the three slots to pick a game from."""
        from core.scenes.save_slot_scene import SaveSlotScene  # local: cycle.

        self.gm.scene_stack.push(SaveSlotScene(self.gm, loading=True))

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """
        Translate input into menu navigation.

        Args:
            event: The pygame event to handle.
        """
        if input_map.is_up(event):
            if self.menu.move_up():
                self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            if self.menu.move_down():
                self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            if self.menu.confirm():
                self.gm.audio.play("menu_select")

    def render(self, surface: pygame.Surface) -> None:
        """
        Draw the title text and the menu.

        Args:
            surface: The screen surface to draw on.
        """
        render_scene_background(self, surface)

        text_renderer.draw_text(
            surface,
            ScreenSettings.TITLE_SCREEN_HEADING,
            (UISettings.TITLE_SCREEN_HEADING_X, UISettings.TITLE_SCREEN_HEADING_Y),
            color=ColorSettings.WHITE,
            size=FontSettings.SIZE_TITLE_SCREEN_HEADING,
        )

        self.menu.render(
            surface,
            (UISettings.TITLE_SCREEN_MENU_X, UISettings.TITLE_SCREEN_MENU_TOP_Y),
            centered=False,
            item_spacing=UISettings.TITLE_SCREEN_MENU_ITEM_SPACING,
        )
