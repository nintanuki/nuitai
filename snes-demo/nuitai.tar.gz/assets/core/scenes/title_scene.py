"""The title screen — the first scene the player sees.

Offers NEW GAME and CONTINUE (Frankie, 10/23). No Quit, as on a Super Nintendo
title: the window's close button closes it, and L1 R1 START SELECT anywhere
resets back to it.
Picking NEW GAME builds a default party and replaces the stack with
the overworld. CONTINUE lists the three save slots to pick one (D-523).
SELECT on the menu opens SCENE SELECT (Frankie, 10/25): any beat of the
demo, played up to through the game's own code (``core/scene_select.py``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core import save
from core import scene_select
from core.factories import party_member_from_data
from core.scene import Scene
from core.scenes.choice_scene import ChoiceScene
from core.shared import by_id
from settings import (
    BattleSettings,
    InputSettings,
    PlaceSettings,
    RecordSettings,
    UISettings,
)
from systems import config, records
from systems.party import Party
from ui import input_map
from ui import title_dawn as dawn
from ui.menu import Menu, MenuItem
from ui.title_painter import DawnPainter

if TYPE_CHECKING:
    from main import GameManager


# Order in which the default party is built. The ids are resolved
# against the characters in the shared battle file. The first three
# fight; the rest wait on the bench (D-196). The demo starts with Kailo
# and Hina; Maika joins in the woods and Tawiri at the wake (Frankie, 10/22).
_DEFAULT_PARTY_IDS: tuple[str, ...] = ("kailo", "hina")
# Everyone who can be in the demo's party, in the order they join.
DEMO_CAST: tuple[str, ...] = ("kailo", "hina", "maika", "tawiri")


def add_missing_members(party: Party) -> None:
    """Give a save from before someone joined the default party that member."""
    characters = by_id("characters")
    for member_id in _DEFAULT_PARTY_IDS:
        data = characters.get(member_id)
        # Someone away (Hina at home after the taro patch) is not missing: she
        # waits there, not in the party (a reload put her back, 10/23).
        away = any(m.id == member_id for m in party.away)
        if data is not None and party.find(member_id) is None and not away:
            party.add(party_member_from_data(data))
    # Everyone holds their own weapon from the start (D-462).
    for member in party.members:
        if member.weapon is None:
            member.weapon = characters.get(member.id, {}).get("weapon")


def build_default_party() -> Party:
    """Construct a fresh party from the shared file's characters.

    Seeds the starting Noni into ``Party.inventory`` so a new
    game's first battle has something to heal with.

    Returns:
        A populated ``Party``. An id with no character entry is
        skipped rather than crashing.
    """
    characters = by_id("characters")
    party = Party()
    for member_id in _DEFAULT_PARTY_IDS:
        data = characters.get(member_id)
        if data is None:
            continue
        party.add(party_member_from_data(data))
    party.inventory["noni"] = BattleSettings.STARTING_NONI
    # The calendar starts on the last day of summer (Frankie, 10/25; systems/records.py).
    party.flags[records.DATE_FLAG] = RecordSettings.START_DAY
    return party


# The menu letters' shadow: the text palette's near black.
_MENU_SHADOW = (20, 20, 20, 255)


class TitleScene(Scene):
    """The opening menu."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Construct the title screen menu."""
        super().__init__(gm)

        any_save_exists = save.newest_slot() is not None
        items = [
            MenuItem("New Game", self._new_game),
            # Continue lists the three slots, as Final Fantasy VI's does (Frankie, 10/23).
            MenuItem("Continue", self._load_game, enabled=any_save_exists),
        ]
        # The Workshop, the room editor, is its own program now
        # (``Workshop.pyw``), never on the game's title (Frankie, 10/23).
        self.menu = Menu(items=items)
        # With a save, the cursor starts on Continue: one stray press on New Game
        # lost two Let's Play saves (Frankie, 10/31).
        if any_save_exists:
            self.menu.cursor = 1
        # The dawn: its frame (60 a second, as the cartridge counts), the
        # specks, the waves' frames since the sea came, and time not yet a frame.
        self.painter = DawnPainter()
        self.frame = 0
        self.specks = dawn.Specks()
        self.wave_ticks = 0
        self._time = 0.0
        self._menu_layer = pygame.Surface((dawn.WIDTH, dawn.HEIGHT), pygame.SRCALPHA)

    def on_enter(self) -> None:
        """Frankie's Main Theme, with the surf under it (Frankie, 10/23).

        It plays on under the save slots, and ``play_screen`` leaves it
        playing when they close.
        """
        self.gm.audio.play_screen("title")

    def on_exit(self) -> None:
        """Stop the title's music when a game begins."""
        self.gm.audio.stop_music()

    # ------------------------------------------------------------------
    # ACTIONS
    # ------------------------------------------------------------------

    def _new_game(self) -> None:
        self.new_game(self.gm)

    @staticmethod
    def new_game(gm: "GameManager") -> None:
        """A fresh overworld and a default party, opening on the words before the prologue and
        the card naming the place and the day, then the taro patch."""
        from core.scenes.blurb_scene import BlurbScene  # local: cycle.
        from core.scenes.overworld_scene import OverworldScene  # local: cycle.

        gm.party = build_default_party()
        # The title's Config settings carry into the new game; no one has a cursor to remember yet.
        config.current.cursors = {}
        config.current.element_cursors = {}
        world = OverworldScene(gm)
        world.begin_story("taro_patch")
        world.open_from_black()
        gm.scene_stack.replace(world)
        # The card goes under the blurb's four cards, so it shows once the blurb closes.
        gm.scene_stack.push(BlurbScene(gm, PlaceSettings.OPENING_CARD, centered=True))
        gm.scene_stack.push(BlurbScene(gm))

    def _load_game(self) -> None:
        """List the three slots to pick a game from."""
        from core.scenes.save_slot_scene import SaveSlotScene  # local: cycle.

        self.gm.scene_stack.push(SaveSlotScene(self.gm, loading=True))

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """
        Translate input into menu navigation; during the dawn, any button skips it.

        Args:
            event: The pygame event to handle.
        """
        if self.frame < dawn.DONE:
            if self._is_press(event):
                self._skip()
            return
        if input_map.is_up(event):
            if self.menu.move_up():
                self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            if self.menu.move_down():
                self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            if self.menu.confirm():
                self.gm.audio.play("menu_select")
        elif input_map.is_select(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.push(SceneSelect(self.gm))

    @staticmethod
    def _is_press(event: pygame.event.Event) -> bool:
        """Any key or button pressed but SELECT (START pauses, before the scene hears it)."""
        if event.type == pygame.KEYDOWN:
            return True
        if event.type == pygame.JOYBUTTONDOWN:
            return event.button != InputSettings.JOY_BUTTON_BACK
        return event.type == pygame.JOYHATMOTION and event.value != (0, 0)

    def _skip(self) -> None:
        """Straight to the menu, as the cartridge does: the waves and specks start again."""
        self.frame = dawn.DONE
        self.specks = dawn.Specks()
        self.wave_ticks = 0

    def update(self, dt: float) -> None:
        """Move the dawn on a frame at a time, 60 a second."""
        self._time += dt * 60
        while self._time >= 1:
            self._time -= 1
            self._step()

    def _step(self) -> None:
        self.specks.tick(self.frame)
        if self.frame >= dawn.SEA_START:
            self.wave_ticks += 1
        self.frame += 1

    def render(self, surface: pygame.Surface) -> None:
        """
        Paint the dawn as it stands, and the menu once it fades in.

        Args:
            surface: The screen surface to draw on.
        """
        self.painter.paint(surface, self.frame, self.specks, self.wave_ticks)
        step = dawn.menu_step(self.frame)
        if not step:
            return
        layer = self._menu_layer
        layer.fill((0, 0, 0, 0))
        self.menu.render(
            layer,
            (UISettings.TITLE_SCREEN_MENU_X, UISettings.TITLE_SCREEN_MENU_TOP_Y),
            centered=False,
            item_spacing=UISettings.TITLE_SCREEN_MENU_ITEM_SPACING,
        )
        # A shadow a pixel down and right, so the letters read over the
        # reflection, as the cartridge's letters have it.
        shadow = layer.copy()
        shadow.fill(_MENU_SHADOW, special_flags=pygame.BLEND_RGBA_MIN)
        layer.blit(shadow, (1, 1))
        self.menu.render(
            layer,
            (UISettings.TITLE_SCREEN_MENU_X, UISettings.TITLE_SCREEN_MENU_TOP_Y),
            centered=False,
            item_spacing=UISettings.TITLE_SCREEN_MENU_ITEM_SPACING,
        )
        if step < 16:
            layer.fill((255, 255, 255, step * 255 // 16), special_flags=pygame.BLEND_RGBA_MULT)
        surface.blit(layer, (0, 0))


class SceneSelect(ChoiceScene):
    """SCENE SELECT: the demo's beats; confirm starts one, cancel goes back to the title."""

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm, "Scene Select", scene_select.beat_names(),
                         lambda index: scene_select.start(gm, index))

    def handle_event(self, event: pygame.event.Event) -> None:
        if input_map.is_cancel(event) or input_map.is_select(event):
            self.gm.audio.play("menu_move")
            self.gm.scene_stack.pop()
            return
        super().handle_event(event)
