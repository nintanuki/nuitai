"""The overworld — sprite walks a tile grid, message box at the bottom.

The Layer-3 destination scene, kicked off early so it can advance in
parallel with the Layer-1 text demo / battle polish. Owns three
collaborators: a ``World`` (cell layout + active-cell pointer), an
``OverworldPlayer`` (logical position + sprite animation + held-input
polling), and a ``TextBox`` (the existing widget, reused unchanged for
the bottom message panel).

What is and is not here in Pass 1:

* **Walking, cell transitions, save/load round-trip** — yes.
* **System-menu push on Tab / START** — yes (re-uses ``MenuScene``).
* **The pond (D-525), a market stall (D-571) and its keeper (D-574)** — face them and confirm.
* **The town's buildings** stand over the tiles and block; walking up into
  a door goes inside. A nap in Kailo's bed heals the party, as the pond does,
  and moves the date on a day (Frankie, 10/25); neither wakes the knocked out
  (Frankie, 10/26).
* **The place pop-up** (Frankie, 10/25): walking from one place into another
  (``systems/places.py``) shows its name in a small box at the top for a
  moment; walking out of his house after a nap, the date under it.
* **People with lines** say them when talked to (Melia, the villagers).
  Two villagers spar in town; standing next to one, facing them, for 30
  seconds with nothing pressed makes Kailo stronger and faster, once.
* **Saving** is only at an Akua totem (Frankie, 10/26): the party prays,
  the fallen get back up, and the game asks to save; YES opens the three
  slots. The menu has no Save.
* **Monsters on the map** (D-576): touching one starts its fight; no
  random encounters.
* **The demo's story** (the demo line in ``game/answers.md``): a new game
  opens on the taro patch scene; the Great Boar beaten, it is night; at
  night Kailo gives Melia the tusk, and walking into the chief's room then,
  Hina asks if they are ready for the wake, which ends the demo on
  TO BE CONTINUED. The scenes play over the field (``core/story.py``), acted out by
  the walking sprites where the script has stage directions
  (``core/staging.py``), the speaker's face beside their words; a scene
  can fade the screen to black and back, and wait a moment.
* **NPCs, dialogue triggers, signs, warp tiles** — Pass 2.
* **Animated walk cycle, real sprite art** — Pass 2.

The cell area draws one 16 pixel picture per tile, chosen by the cell
char (``OverworldSettings.TILE_PICTURES``), from Mini World Sprites.
Without the pictures a flat colour per char stands in.

See [docs/design/overworld.md](../../docs/design/overworld.md) for the
full design rationale.
"""

from __future__ import annotations

import os
import random
from typing import TYPE_CHECKING

import pygame

from core import lore
from core.scene import Scene
from core.overworld_cells import BUILDINGS, FIELD_MONSTERS, INSIDE_ROW, PEOPLE, room_offset, warps
from core.shared import short_name
from core.staging import Stage
from core.story import LOSE, StoryRunner, cast, party_flag
from core.world import World
from systems import bounties, garden, places, records
from systems.passives import join_line
from entities.field_monster import FieldMonster
from entities.overworld_player import OverworldPlayer
from settings import (
    AssetPaths,
    AudioSettings,
    BackgroundSettings,
    ColorSettings,
    FieldMonsterSettings,
    FontSettings,
    GardenSettings,
    GridSettings,
    KaigaraSettings,
    OverworldPlayerSettings,
    OverworldSettings,
    PlaceSettings,
    StorySettings,
    TownSettings,
    TutorialSettings,
    UISettings,
)
from ui import input_map, shore, text_renderer, walls
from ui.text_box import TextBox
from ui.window import draw_window
from utils.backgrounds import render_scene_background
from utils.graphics import speaker_face

if TYPE_CHECKING:
    from main import GameManager


# Stand-in colour per cell char, used when the tile pictures are missing.
_TILE_COLORS: dict[str, tuple[int, int, int]] = {
    OverworldSettings.FLOOR_CHAR: ColorSettings.OVERWORLD_FLOOR,
    OverworldSettings.WALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.WATER_CHAR: ColorSettings.OVERWORLD_WATER,
    OverworldSettings.SPRING_CHAR: ColorSettings.OVERWORLD_WATER,
    OverworldSettings.SAND_CHAR: ColorSettings.OVERWORLD_SAND,
    OverworldSettings.STALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.MAT_CHAR: ColorSettings.OVERWORLD_SAND,
    OverworldSettings.INSIDE_WALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.VOID_CHAR: ColorSettings.BLACK,
}

# Tile pictures by cell char, loaded on first use. ``{}`` means the
# pictures were looked for and are missing.
_TILES: dict[str, list[pygame.Surface]] | None = None


def _tiles() -> dict[str, list[pygame.Surface]]:
    """Return the choices of 16 pixel picture for each cell char."""
    global _TILES
    if _TILES is not None:
        return _TILES
    _TILES = {}
    size = GridSettings.TILE_SIZE
    sheets: dict[str, pygame.Surface] = {}
    for char, choices in OverworldSettings.TILE_PICTURES.items():
        pictures = []
        for name, index in choices:
            if name not in sheets:
                path = os.path.join(AssetPaths.TILES_DIR, name)
                if not os.path.exists(path):
                    _TILES = {}
                    return _TILES
                sheets[name] = pygame.image.load(path).convert_alpha()
            sheet = sheets[name]
            pictures.append(sheet.subsurface(pygame.Rect(
                (index * size) % sheet.get_width(),
                (index * size) // sheet.get_width() * size,
                size, size,
            )))
        _TILES[char] = pictures
    return _TILES


# Each person's walk sheet by name, loaded on first use; None if missing.
_PEOPLE: dict[str, pygame.Surface | None] = {}


def _person_sheet(name: str, file: str = "{}-Walk.png") -> pygame.Surface | None:
    """Return the Ninja Adventure walk sheet ``<name>-Walk.png``, or another of
    theirs (``file``: the Kaigara Kame's sitting one), or None."""
    file = file.format(name)
    if file not in _PEOPLE:
        path = os.path.join(AssetPaths.PEOPLE_DIR, file)
        _PEOPLE[file] = pygame.image.load(path).convert_alpha() if os.path.exists(path) else None
    return _PEOPLE[file]


# Each building's picture by kind, loaded on first use; None if missing.
_BUILDINGS: dict[tuple[str, bool], pygame.Surface | None] = {}


def building_picture(kind: str, opened: bool = False) -> pygame.Surface | None:
    """Return the picture for a kind of building (``OverworldSettings.BUILDINGS``), or None.

    ``opened`` gives an opened chest's picture, ``OverworldSettings.CHEST_OPEN``.
    """
    key = (kind, opened)
    if key not in _BUILDINGS:
        name = OverworldSettings.CHEST_OPEN if opened else OverworldSettings.BUILDINGS[kind][0]
        path = os.path.join(AssetPaths.BUILDINGS_DIR, name)
        _BUILDINGS[key] = pygame.image.load(path).convert_alpha() if os.path.exists(path) else None
    return _BUILDINGS[key]


def chest_flag(cell_name: str, chest: dict) -> str:
    """The party flag that marks a chest as opened, kept in the save."""
    return f"chest:{cell_name}:{chest['col']}:{chest['row']}"


def chest_items(chest: dict) -> list[str]:
    """What a chest holds, picked now: its ``item``, its ``also`` list, then
    ``random`` from ``ItemSettings.CHEST_RANDOM``, once or as many times as
    ``picks`` (low, high) rolls. "pule" is ``ItemSettings.CHEST_PULE`` pule."""
    from settings import ItemSettings

    items = ([chest["item"]] if chest.get("item") else []) + list(chest.get("also", []))
    if chest.get("random"):
        low, high = chest.get("picks", (1, 1))
        items += [random.choice(ItemSettings.CHEST_RANDOM[chest["random"]]) for _ in range(random.randint(low, high))]
    return items


def draw_building(surface: pygame.Surface, building: dict, x0: int = 0, y0: int = 0,
                  opened: bool = False) -> None:
    """Draw a building at its own size on its tiles, standing on their bottom edge.

    ``opened`` draws a chest open (Frankie, 10/25).
    """
    tile_size = GridSettings.TILE_SIZE
    width, height = OverworldSettings.BUILDINGS[building["kind"]][1]
    picture = building_picture(building["kind"], opened and building["kind"] == "chest")
    left, bottom = x0 + building["col"] * tile_size, y0 + (building["row"] + height) * tile_size
    if picture is None:
        pygame.draw.rect(surface, ColorSettings.OVERWORLD_WALL,
                         (left, bottom - height * tile_size, width * tile_size, height * tile_size))
        return
    surface.blit(picture, (left, bottom - picture.get_height()))


# Each plant's four garden pictures, loaded on first use; None if missing.
_PATCH_SHEETS: dict = {}


def _patch_sheet(plant: str) -> pygame.Surface | None:
    """Return a plant's strip of four pictures (GardenSettings.PICTURES), or None."""
    if plant not in _PATCH_SHEETS:
        path = os.path.join(AssetPaths.TILES_DIR, GardenSettings.PICTURES.get(plant, ""))
        _PATCH_SHEETS[plant] = pygame.image.load(path).convert_alpha() if os.path.isfile(path) else None
    return _PATCH_SHEETS[plant]


def _speaker(person: dict) -> str:
    """The name a person who joins speaks under: their first name."""
    from core.shared import short_name

    return short_name(person["joins"])


def _boss_flag_for(cell_name: str, spot: dict) -> str:
    """The party flag that marks a boss on the map as beaten for good."""
    return f"field_boss:{cell_name}:{spot['kind']}"


def _boss_flag(monster: FieldMonster) -> str:
    """The flag for ``monster``, a boss, in the cell it stands in."""
    for cell_name, spots in FIELD_MONSTERS.items():
        if monster.spot in spots:
            return _boss_flag_for(cell_name, monster.spot)
    return f"field_boss::{monster.spot['kind']}"


def story_face(speaker: str | None) -> pygame.Surface | None:
    """The speaker's 48 by 48 face for the story's text box, or None (narration, or no face drawn)."""
    return speaker_face(speaker)


def _pick(pictures: list[pygame.Surface], col: int, row: int) -> pygame.Surface:
    """Pick one of ``pictures`` by tile position, the same every time."""
    return pictures[(col * 7 + row * 13 + col * row) % len(pictures)]


def start_in_room(gm: "GameManager", name: str | None, col: int | None = None,
                  row: int | None = None, checkpoint: str | None = None) -> bool:
    """Skip the title: a fresh party standing in room ``name``, on ``(col, row)``.

    How the Workshop's Play button starts the game (``main.py --room``).
    With ``checkpoint``, the party and the story are that checkpoint's
    (core/save.py) instead of a fresh party's, and without ``name`` it
    starts where the checkpoint stood. Returns False, leaving the title
    up, when there is no such room or checkpoint.
    """
    # Local import: the title imports this module.
    from core import save
    from core.overworld_cells import WORLD_LAYOUT
    from core.scenes.save_slot_scene import resume
    from core.scenes.title_scene import build_default_party

    pos = next((pos for pos, who in WORLD_LAYOUT.items() if who == name), None)
    if name is not None and pos is None:
        return False
    if checkpoint is not None:
        try:
            data = save.load_checkpoint(checkpoint)
        except (OSError, ValueError):
            return False
        resume(gm, data)
        scene = gm.scene_stack.top
    else:
        gm.party = build_default_party()
        scene = OverworldScene(gm)
        gm.scene_stack.replace(scene)
    if pos is not None:
        scene.world.go_to(pos)
    if col is not None and row is not None:
        scene.player.from_dict({"col": int(col), "row": int(row)})
    return True


class OverworldScene(Scene):
    """The screen-locked, cell-based overworld."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Construct the overworld with its world, player, and text box.

        Args:
            gm: The host game manager. Provides audio, save, and
                cross-scene navigation routing.
        """
        super().__init__(gm)
        self.world = World()
        self.player = OverworldPlayer(gm, self.world)
        # Cell area is narrower than the screen, so size the text box
        # to the full screen width but keep the existing 160-px height.
        self.text_box = TextBox(flippable=True)
        # The monsters in the cell (D-576), placed afresh on every entry.
        self.monsters: list[FieldMonster] = []
        self._monsters_cell: tuple[int, int] | None = None
        # The monster whose fight is on, and how long until a monster
        # left standing by a fight can start another.
        self._fighting: tuple[FieldMonster, object] | None = None
        self._grace = 0.0
        # The demo is over: the words on the black screen, and the title on confirm.
        self._card: str | None = None
        # The Great Boar asks before his fight (Frankie, 10/23): the one asking,
        # whether he has asked since the party walked up, and the steps back
        # still to walk after "Go back".
        self._asking: FieldMonster | None = None
        # Whether Hina has asked about the wake since the party walked into the chief's room.
        self._wake_asked = False
        self._asked = False
        # Where Kailo last bumped (room, tile, facing), so a dead end speaks once a walk-up.
        self._bumped_at: tuple | None = None
        self._walk_back: list[tuple[int, int]] = []
        # A shop pushed by a person who may join (Maika): who, and what the
        # bag held when it opened, so closing it can tell if anything was bought.
        self._joiner_shop: tuple[dict, dict] | None = None
        # What to open once the text box closes.
        self._after_text = None
        # The sparring villagers: how long nothing has been pressed.
        self._idle = 0.0
        # The story scene playing, the step it waits to show once the text
        # box closes, and the fight it started.
        self.story: StoryRunner | None = None
        self._story_next: dict | None = None
        self._story_fight = None
        # The scene acted out on the map, once its script names a Room.
        self.stage: Stage | None = None
        # The screen's darkness, 0 to 1, where a Fade is taking it, and a Wait's seconds left.
        self._dark = 0.0
        self._fade_to: float | None = None
        self._wait = 0.0
        # A new game opening: the field starts black and lights as the first line types.
        self._opening = False
        # Where the player stood last frame, to count the garden's steps.
        self._last_tile: tuple | None = None
        # What a room smaller than the screen is drawn on before it is moved to the middle.
        self._room_layer: pygame.Surface | None = None
        # The room this visit is in, so leaving it can send Melia home.
        self._visiting = self.world.current_cell_name
        # The room the place pop-up last looked at (None until the first frame,
        # which shows nothing), the place it was in, and the pop-up's lines and
        # seconds left.
        self._place_room: str | None = None
        self._place: str | None = None
        self.popup: list[str] | None = None
        self._popup_left = 0.0
        self._sync_joined()

    def on_enter(self) -> None:
        """Play the room's sound, and settle the fight just over, if one was.

        The sound carries on if it is already playing (back from the
        menu). A monster beaten in its fight leaves the map, a boss for
        good; one that was run from or lost to stays, and waits a moment
        before it can start another (D-576).
        """
        # The fight settled first, so a won fight's Song is over before the room's song comes back.
        if self._story_fight is not None:
            battle, self._story_fight = self._story_fight, None
            self.story.fought(battle.battle.outcome == "victory")
        self._room_sound()
        self._sync_joined()
        if self._joiner_shop is not None:
            person, before = self._joiner_shop
            self._joiner_shop = None
            self._after_joiner_shop(person, before)
        if self._fighting is None:
            return
        monster, battle = self._fighting
        self._fighting = None
        if battle.battle.outcome == "victory":
            if monster in self.monsters:
                self.monsters.remove(monster)
            if monster.spot.get("boss"):
                self.gm.party.flags[_boss_flag(monster)] = True
                # The Great Boar beaten, they talk, and it is night (the demo line, 10/23).
                self.gm.party.flags[StorySettings.NIGHT_FLAG] = True
                self._sync_joined()
                self.begin_story(StorySettings.FALL_SCENE)
        else:
            self._grace = FieldMonsterSettings.GRACE_SECONDS

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Route one event.

        When the text box has content, confirm advances it and other
        keys fall through silently (so a held direction won't queue
        steps that fire the instant the player closes a dialogue).
        Otherwise, Tab / Y pushes the field menu; movement is
        polled inside ``player.update`` and does not go through this
        handler.

        Args:
            event: The pygame event to route.
        """
        if event.type in (pygame.KEYDOWN, pygame.JOYBUTTONDOWN, pygame.JOYHATMOTION):
            self._idle = 0.0
        if self._card is not None:
            if input_map.is_confirm(event):
                self.gm.return_to_title()
            return
        if not self.text_box.is_done():
            if input_map.is_textbox_flip(event):
                TextBox.flip()
            elif input_map.is_confirm(event):
                self.text_box.advance()
            return
        # The story playing takes every key until its text box closes.
        if self.story is not None:
            return
        if input_map.is_confirm(event) and self._faced_patch() is not None:
            self._tend(self._faced_patch())
            return
        if input_map.is_confirm(event) and self._faced_building() == "pot":
            self._open_pot()
            return
        if input_map.is_confirm(event) and self._faced_look():
            self._look(self._faced_look())
            return
        if input_map.is_confirm(event) and self._faced_building() == KaigaraSettings.TABLE:
            self._talk_to_kame()
            return
        if input_map.is_confirm(event) and self._faced_building() == "chest":
            self._open_chest()
            return
        # An Akua totem: pray, the fallen get up, then save (Frankie, 10/26).
        if input_map.is_confirm(event) and self._faced_building() == "totem":
            self._pray()
            return
        if input_map.is_confirm(event) and self._facing_shut_door():
            self._say_shut_door()
            return
        # Kailo's bed in his house: a nap rests the party (Frankie, 10/23).
        # Anyone else's, Hina scolds (Frankie, 10/25).
        if input_map.is_confirm(event) and self._faced_building() == "bed":
            dx, dy = self.player.facing
            bed = self.world.building_at(self.player.col + dx, self.player.row + dy)
            if bed.get("owner") == TownSettings.OWN_BED:
                self._ask_nap()
            else:
                self._not_your_bed(bed)
            return
        # Facing the pond, confirm rests there; facing a stall, it opens
        # the shop; Enter opens the menu everywhere else.
        if input_map.is_confirm(event) and self._facing(OverworldSettings.SPRING_CHAR):
            self._rest()
            return
        if input_map.is_confirm(event) and (self._facing(OverworldSettings.STALL_CHAR)
                                            or self._faced_building() in OverworldSettings.SHOP_BUILDINGS
                                            or self._faced_building() == "sign"):
            # A stall is its keeper's: whoever in the room keeps a shop.
            keeper = next((p for p in self.world.people if p.get("shop")), None)
            away = next((p for p in PEOPLE.get(self.world.current_cell_name, [])
                         if p.get("shop") and not p.get("joins")), None)
            if keeper is None and away is not None and self.is_night():
                self._read_sign(away["shop"])
            elif keeper is not None and keeper.get("joins"):
                self._talk_to_joiner(keeper)
            elif keeper is not None:
                self._open_shop(keeper["shop"])
            else:
                self._joined_keeper_shop()
            return
        # Whoever Kailo talks to turns to face him (Frankie, 10/23).
        was_facing = None
        if input_map.is_confirm(event) and self._faced_person():
            was_facing = self._turn_to_player(self._faced_person())
        if input_map.is_confirm(event) and self._faced_person().get("night") and self.is_night():
            self._talk_at_night(self._faced_person())
            return
        # Hina at home: talking to her plays her scene, and she joins (Frankie, 10/23).
        if input_map.is_confirm(event) and self._faced_person().get("scene"):
            self.begin_story(self._faced_person()["scene"])
            return
        if input_map.is_confirm(event) and self._faced_person().get("joins"):
            self._talk_to_joiner(self._faced_person())
            return
        # A loremaster, or the boy who explains the game: his questions after his first line,
        # the one that offers them (Frankie, 10/25); his other lines take turns with it.
        if input_map.is_confirm(event) and self._faced_person().get("ask"):
            person = self._faced_person()
            if self._take_turn(person, "day", person["lines"]) == 0:
                self._after_text = lambda: self._ask_menu(person)
            return
        # Melia, hiding the first time: the three of them, then one line a talk (Frankie, 10/25).
        if input_map.is_confirm(event) and self._faced_person().get("talk") and not self._faced_person().get("talked"):
            person = self._faced_person()
            person["talked"] = True
            if person.get("first") and self.gm.party:
                self.gm.party.flags[person["first"]["flag"]] = True
            for speaker, line in person["talk"]:
                self.text_box.push(line, speaker=speaker)
            return
        # The Kame in the hunters' lodge: a game of Kaigara (Frankie, 10/26).
        if input_map.is_confirm(event) and self._faced_person().get("kaigara"):
            self._talk_to_kame()
            return
        if input_map.is_confirm(event) and self._faced_person().get("lines"):
            person = self._faced_person()
            # Someone home at night says their ``night_lines`` (Kailo's cousins, 10/25);
            # by day, the ``flag_lines`` of the first party flag set, if any
            # (the chief with no stew, Frankie, 10/26). One of them a talk (Frankie, 10/26).
            flags = self.gm.party.flags if self.gm.party else {}
            which, lines = next(((flag, said) for flag, said in person.get("flag_lines", {}).items()
                                 if flags.get(flag)), ("day", person["lines"]))
            if self.is_night() and person.get("night_lines"):
                which, lines = "night", person["night_lines"]
            self._take_turn(person, which, lines)
            if person.get("spar"):
                # A sparring villager goes back to the fight once done talking.
                self._after_text = lambda: person.__setitem__("facing", was_facing)
            return
        # The hunters' lodge's keeper: a bounty to pay out first, then the shop or the bounty board.
        if input_map.is_confirm(event) and self._faced_person().get("bounties"):
            self._lodge_keeper(self._faced_person())
            return
        if input_map.is_confirm(event) and self._faced_person().get("shop"):
            self._open_shop(self._faced_person()["shop"])
            return
        if input_map.is_menu(event):
            self._open_menu()

    def _facing(self, char: str) -> bool:
        """Whether the tile the player faces is ``char``: the pond (D-525), a stall (D-571)."""
        dx, dy = self.player.facing
        return self.world.tile_at(self.player.col + dx, self.player.row + dy) == char

    def at_save_point(self) -> bool:
        """Whether the party stands on a tile next to an Akua totem (Frankie, 10/26)."""
        for dx, dy in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            building = self.world.building_at(self.player.col + dx, self.player.row + dy)
            if building and building["kind"] == "totem":
                return True
        return False

    def _faced_look(self) -> list:
        """The ``look`` lines of the building the player faces (a lore hint), or none."""
        dx, dy = self.player.facing
        building = self.world.building_at(self.player.col + dx, self.player.row + dy)
        return building.get("look", []) if building else []

    def _look(self, lines: list) -> None:
        """Say a lore hint's lines (Frankie, 10/25): each ``[speaker, line]``, or with a third,
        ``with hina`` or ``without hina``, said only with that member along or away."""
        for speaker, line, *when in lines:
            if when:
                need, member = when[0].split()
                if (self.gm.party.find(member) is not None) != (need == "with"):
                    continue
            self.text_box.push(line, speaker=speaker)

    def _faced_building(self) -> str | None:
        """The kind of building on the tile the player faces, or None."""
        dx, dy = self.player.facing
        building = self.world.building_at(self.player.col + dx, self.player.row + dy)
        return building["kind"] if building else None

    def _facing_shut_door(self) -> bool:
        """Whether the player stands below a house's door, facing up, with no room behind it."""
        dx, dy = self.player.facing
        col, row = self.player.col + dx, self.player.row + dy
        building = self.world.building_at(col, row)
        door = OverworldSettings.DOORS.get(building["kind"]) if building else None
        return ((dx, dy) == (0, -1) and door is not None
                and (col - building["col"], row - building["row"]) == door
                and (self.world.current_cell_name, self.player.col, self.player.row, (0, -1)) not in warps())

    def _say_shut_door(self) -> None:
        """A house nobody can go into: Kailo says nobody is home (Frankie, 10/26)."""
        line = TownSettings.SHUT_DOOR_NIGHT if self.is_night() else TownSettings.SHUT_DOOR
        self.text_box.push(line, speaker=StorySettings.PLAYER)

    def _dead_end(self) -> bool:
        """Kailo walking into a shut door or off an edge with no room past it says
        one line, once each time he walks up to it (Frankie, 10/26). True if he spoke."""
        player = self.player
        if not player.bumped or player._step_active:
            self._bumped_at = None
            return False
        at = (self.world.current_cell_name, player.col, player.row, tuple(player.facing))
        if at == self._bumped_at:
            return False
        self._bumped_at = at
        if self._facing_shut_door():
            self._say_shut_door()
            return True
        dx, dy = player.facing
        edge = TownSettings.EDGE_LINES.get(self.world.current_cell_name)
        if edge and self.world.tile_at(player.col + dx, player.row + dy) is None:
            self.text_box.push(edge, speaker=StorySettings.PLAYER)
            return True
        return False

    def _turn_to_player(self, person: dict) -> list:
        """Turn ``person`` to face the player, who is facing them; return the way they faced."""
        was_facing = person["facing"]
        dx, dy = self.player.facing
        person["facing"] = [-dx, -dy]
        return was_facing

    def _faced_person(self) -> dict:
        """The person on the tile the player faces, or an empty dict."""
        dx, dy = self.player.facing
        return self.world.person_at(self.player.col + dx, self.player.row + dy) or {}

    def _open_shop(self, shop_id: str) -> None:
        """Push a shop on top of this scene (D-571). No keeper talks up
        Counter any more (Frankie, 10/26)."""
        # Local import, as with the menu and the battle below.
        from core.scenes.shop_scene import ShopScene

        self._push_shop(ShopScene(self.gm, shop_id))

    def _push_shop(self, shop) -> None:
        self.gm.audio.play("menu_select")
        self.gm.scene_stack.push(shop)

    # ------------------------------------------------------------------
    # THE HUNTERS' LODGE: its bounties (Frankie, 10/26; systems/bounties.py)
    # ------------------------------------------------------------------

    def _lodge_keeper(self, keeper: dict) -> None:
        """A finished bounty is paid first; then Buy and sell, Bounty or Leave."""
        board = self.gm.data.load("bounties")[keeper["bounties"]]
        lines, speaker = board["lines"], keeper["speaker"]
        if bounties.done(self.gm.party, board):
            post = bounties.pay(self.gm.party, board)
            words = {"pule": post["pule"], "prize": self._item_name(post["prize"])}
            self.text_box.push(lines["paid"].format(**words), speaker=speaker)
            self.text_box.push(lines["got"].format(**words))
            self.gm.audio.play("hit_sparkle_1")
            self._after_text = lambda: self._lodge_menu(keeper, board)
            return
        self._lodge_menu(keeper, board)

    def _lodge_menu(self, keeper: dict, board: dict) -> None:
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        lines = board["lines"]

        def pick(index: int) -> None:
            if index == 0:
                self._open_shop(keeper["shop"])
            elif index == 1:
                self._lodge_bounty(keeper, board)

        self.gm.scene_stack.push(ChoiceScene(self.gm, lines["ask"], lines["choices"], pick))

    def _lodge_bounty(self, keeper: dict, board: dict) -> None:
        """How far the taken bounty is; or the posted one, to take or leave."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        party, lines, speaker = self.gm.party, board["lines"], keeper["speaker"]
        post = bounties.posted(party, board)
        if bounties.taken(party):
            self.text_box.push(lines["progress"].format(done=bounties.count(party), count=post["count"]),
                               speaker=speaker)
            return
        self.text_box.push(lines["post"].format(what=post["what"], pule=post["pule"],
                                                prize=self._item_name(post["prize"])), speaker=speaker)

        def pick(index: int) -> None:
            if index == 0:
                bounties.take(party)
                self.text_box.push(lines["taken"], speaker=speaker)

        self._after_text = lambda: self.gm.scene_stack.push(
            ChoiceScene(self.gm, lines["take"], lines["take_choices"], pick))

    @staticmethod
    def _item_name(item_id: str) -> str:
        from core.scenes.shop_scene import item_name  # local, as in _open_shop

        return item_name(item_id)

    # ------------------------------------------------------------------
    # MAIKA: a seller who joins (the demo plan, Frankie 10/22)
    # ------------------------------------------------------------------

    def _sync_joined(self) -> None:
        """Tell the world who is in the party and whether it is night, so whoever
        joined, or is at the wake, is gone from the map."""
        self.world.flags = self.gm.party.flags if self.gm.party else {}
        joined = {member.id for member in self.gm.party.members} if self.gm.party else set()
        night = bool(self.gm.party) and self.is_night()
        if (joined, night) != (self.world.joined, self.world.night):
            self.world.joined, self.world.night = joined, night
            self.world.go_to(self.world.current_pos)

    def _talk_to_joiner(self, person: dict) -> None:
        """The first time, his scene and then his shop; after that, straight to the shop."""
        flag = f"met_{person['joins']}"
        if self.gm.party.flags.get(flag):
            self._open_joiner_shop(person)
            return
        self.gm.party.flags[flag] = True
        self.begin_story(StorySettings.JOINER_MEETS)

    def _ask_menu(self, person: dict) -> None:
        """Someone's questions (``data/asks``), asked as often as the player likes; the last walks away.

        Each answer is said, unlocks its Lore page if it has one, and the
        questions come back (Frankie, 10/25).
        """
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        questions = self.gm.data.load("asks")[person["ask"]]["questions"]

        def pick(index: int) -> None:
            question = questions[index]
            for speaker, line in question["lines"]:
                self.text_box.push(line, speaker=speaker)
            if question.get("unlock"):
                lore.unlock(self.gm.party, question["unlock"])
            if index < len(questions) - 1:
                self._after_text = lambda: self._ask_menu(person)

        self.gm.scene_stack.push(ChoiceScene(self.gm, person["speaker"], [q["ask"] for q in questions], pick))

    def _read_sign(self, shop_id: str) -> None:
        """The old man at the wake (Frankie, 10/25): Kailo stares at his sign, Hina reads it, and the shop opens."""
        for line in TownSettings.SIGN_STARE:
            self.text_box.push(line, speaker=StorySettings.PLAYER)
        hina = TownSettings.SCOLD_SPEAKER
        if self.gm.party.find(hina.lower()) is not None:
            for line in TownSettings.SIGN_READ:
                self.text_box.push(line, speaker=hina)
        # Straight to the shop.
        from core.scenes.shop_scene import ShopScene  # local, as in _open_shop

        self._after_text = lambda: self._push_shop(ShopScene(self.gm, shop_id))

    def _joined_keeper_shop(self) -> None:
        """A stall whose keeper has joined stays open (Frankie, 10/24): he asks, then his shop."""
        keeper = next((p for p in PEOPLE.get(self.world.current_cell_name, [])
                       if p.get("shop") and p.get("joins") and self.gm.party.find(p["joins"])), None)
        if keeper is None:
            return
        speaker = short_name(keeper["joins"])
        self.text_box.push(StorySettings.JOINED_SHOP_LINE, speaker=speaker)
        self._after_text = lambda: self._open_shop(keeper["shop"])

    def _joiner(self) -> dict | None:
        """The person in this room who may join (Maika), or None."""
        return next((p for p in self.world.people if p.get("joins")), None)

    def _open_joiner_shop(self, person: dict) -> None:
        self._joiner_shop = (person, dict(self.gm.party.inventory))
        self._open_shop(person["shop"])

    def _after_joiner_shop(self, person: dict, before: dict) -> None:
        """The shop closed: something bought, he asks what they are doing and joins; else he says to come back."""
        bought = any(count > before.get(item, 0) for item, count in self.gm.party.inventory.items())
        self.begin_story(StorySettings.JOINER_JOINS if bought else StorySettings.JOINER_LEAVES)

    def _joiner_joins(self) -> None:
        """His scene is over: he joins, with his pop-up, and is gone from the map."""
        from core.factories import party_member_from_data
        from core.shared import by_id

        self.gm.party.add(party_member_from_data(by_id("characters")[StorySettings.JOINER]))
        self.text_box.push(join_line(StorySettings.JOINER))
        self.gm.audio.play("hit_sparkle_1")
        self._sync_joined()

    def _asker_in_reach(self) -> FieldMonster | None:
        """The Great Boar, if the party has walked up to him, facing him; he asks before he fights."""
        dx, dy = self.player.facing
        ahead = (self.player.col + dx, self.player.row + dy)
        return next((m for m in self.monsters if m.spot.get("kind") == StorySettings.ASK_KIND
                     and ahead in m.tiles()), None)

    def _seed_lesson_due(self) -> bool:
        """Maika and Hina both along and Seed not taught yet: the first planting teaches it."""
        party = self.gm.party
        return (not party.flags.get(StorySettings.SEED_FLAG)
                and party.find(StorySettings.JOINER) is not None
                and party.find(StorySettings.HOME_MEMBER) is not None)

    # ------------------------------------------------------------------
    # THE STORY: the taro patch, night, Melia's tusk, Hina's question, the wake
    # ------------------------------------------------------------------

    def begin_story(self, name: str) -> None:
        """Play the scene ``name`` (``core/story.py``) over the field."""
        self.story = StoryRunner(name)
        # The Kaigara Kame's talk finds the Lore pages it names (Frankie, 10/27).
        lore.naming = name.startswith("kaigara_")
        self.story.choose(party_flag(self.gm.party))
        # "(if maika along)" plays whenever he is in the party (story-boar.md);
        # "(if maika)" only when he leads, Hina away.
        self.story.flags.update(f"{member.id} along" for member in self.gm.party.members)
        # Whether the gulls got the stew at the taro patch (Frankie, 10/26); a
        # save from before it, or a scene picked from the title, has it saved.
        lost = self.gm.party.flags.get(StorySettings.STEW_LOST_FLAG)
        self.story.choose(StorySettings.STEW_LOST if lost else StorySettings.STEW_SAVED)
        self._story_next = None
        self.stage = None

    def open_from_black(self) -> None:
        """Start the field black, the blurb's black, to fade in as the story's first line
        slowly types; lit just as it finishes (Frankie, 10/25)."""
        self._dark, self._opening = 1.0, True

    def _tick_opening(self) -> None:
        """Light the opening as far as its first line has typed; over once it has."""
        if not self._opening or self.text_box.is_done():
            return
        if self.text_box.has_own_speed() and self.text_box.typed() < 1:
            self._dark = 1.0 - self.text_box.typed()
        else:
            self._dark, self._opening = 0.0, False

    def is_night(self) -> bool:
        """Whether the Great Boar is beaten, so it is night."""
        return bool(self.gm.party.flags.get(StorySettings.NIGHT_FLAG))

    def _talk_at_night(self, person: dict) -> None:
        """Melia at night: with the Great Boar's tusk in the bag, Kailo gives it to her,
        once (10/25); otherwise her ``night_lines``."""
        party = self.gm.party
        if (person["night"] == StorySettings.TUSK_SCENE and party.inventory.get(StorySettings.TUSK)
                and not party.flags.get(StorySettings.TUSK_FLAG)):
            self.begin_story(StorySettings.TUSK_SCENE)
            return
        self._take_turn(person, "night", person.get("night_lines", []))

    def _wake_ask_due(self) -> bool:
        """The tusk given and the party just in the chief's room: Hina asks, once a visit (Frankie, 10/25)."""
        if self.world.current_cell_name != StorySettings.ASK_ROOM:
            self._wake_asked = False
            return False
        due = (not self._wake_asked and not self.player._step_active
               and self.is_night() and bool(self.gm.party.flags.get(StorySettings.TUSK_FLAG)))
        if due:
            self._wake_asked = True
        return due

    def _ask_wake(self) -> None:
        """Hina: is the party ready for the wake? YES starts it; NO, nothing more this visit."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        self.text_box.push(StorySettings.ASK_LINE, speaker=StorySettings.ASK_SPEAKER)
        self._after_text = lambda: self.gm.scene_stack.push(ConfirmScene(
            self.gm, StorySettings.ASK_BOX, on_yes=lambda: self.begin_story(StorySettings.WAKE_SCENE),
        ))

    def _not_your_bed(self, bed: dict) -> None:
        """Someone else's bed: Hina scolds, flustered at her own; with her away, Kailo knows it is not his."""
        hina = TownSettings.SCOLD_SPEAKER
        if bed.get("owner") == hina.lower():
            self.text_box.push(TownSettings.HINA_BED, speaker=hina)
        elif self.gm.party.find(hina.lower()) is not None:
            self.text_box.push(TownSettings.NOT_YOUR_BED, speaker=hina)
        else:
            self.text_box.push(TownSettings.NOT_MY_BED, speaker=StorySettings.PLAYER)

    def _ask_nap(self) -> None:
        """Kailo's bed: take a nap? YES rests the party; NO, nothing."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        self.gm.scene_stack.push(ConfirmScene(
            self.gm, TownSettings.NAP_BOX, on_yes=self._nap,
        ))

    def _nap(self) -> None:
        """A nap in Kailo's bed: rested, and the next day (Frankie, 10/25)."""
        records.sleep(self.gm.party)
        self._rest(TownSettings.NAP_LINE)

    def _watch_place(self, dt: float) -> None:
        """Name the place on walking into a new one, and the date on walking out of the
        house after a nap; count the pop-up down (Frankie, 10/25)."""
        self._popup_left = max(0.0, self._popup_left - dt)
        if self._popup_left <= 0:
            self.popup = None
        room = self.world.current_cell_name
        if room == self._place_room:
            return
        was, self._place_room = self._place_room, room
        place = places.place_of(room)
        flags = self.gm.party.flags if self.gm.party else {}
        if was is None or self.story is not None:
            pass
        elif was == places.HOME and flags.pop(records.SLEPT_FLAG, False) and place is not None:
            self._show_popup([place, records.date_text(self.gm.party)])
        elif place is not None and place != self._place:
            self._show_popup([place])
        if place is not None:
            self._place = place

    def _show_popup(self, lines: list[str]) -> None:
        self.popup = lines
        self._popup_left = PlaceSettings.SECONDS

    def _render_popup(self, surface: pygame.Surface) -> None:
        """The place, and the date in the speaker's yellow, in a box at the top center."""
        if not self.popup:
            return
        size = FontSettings.SIZE_BODY
        pad = UISettings.TEXT_BOX_PADDING
        lines = list(self.popup)
        width = max(text_renderer.text_width(line, size) for line in lines) + 2 * pad
        width = -(-width // 8) * 8
        row = text_renderer.line_height(size)
        top = PlaceSettings.TOP
        if TextBox.at_top and not self.text_box.is_done():
            # The dialogue box is up there; the pop-up waits under it.
            top += self.text_box.height
        rect = pygame.Rect((surface.get_width() - width) // 16 * 8, top, width, len(lines) * row + 2 * pad)
        draw_window(surface, rect)
        for index, line in enumerate(lines):
            x = rect.left + (rect.width - text_renderer.text_width(line, size)) // 2
            text_renderer.draw_text(surface, line, (x, rect.top + pad + index * row), size=size,
                                    color=ColorSettings.YELLOW if index else ColorSettings.WHITE)

    def _play_story(self) -> None:
        """Called with the text box closed: show the lines up to the next choice, fight or stage direction, then it."""
        if (self.stage is not None and self.stage.busy()) or self._fade_to is not None or self._wait > 0:
            return
        if self._story_next is None:
            while True:
                step = self.story.next_step()
                if step is None:
                    self._story_next = {"over": True}
                    break
                if "say" in step or "text" in step:
                    slow = self._opening and self.text_box.is_done()
                    self.text_box.push(step["text"], speaker=step.get("say"), fast=step.get("fast", False),
                                       speed=UISettings.OPENING_CHARS_PER_SECOND if slow else step.get("speed"),
                                       hold=step.get("hold", False))
                    if step.get("say") == StorySettings.WAKE_GIFT_FROM and step.get("if") == StorySettings.STEW_SAVED:
                        self._wake_gift()
                    continue
                self._story_next = step
                break
            if "fight" in self._story_next and self.story.name == "wake":
                self._join_at_wake()
            if not self.text_box.is_done():
                return
        step, self._story_next = self._story_next, None
        if "room" in step:
            # The scene moves to a room: the stage starts empty there, but
            # for Kailo where he stands if he is in that room already.
            from core.overworld_cells import WORLD_LAYOUT  # local: as start_in_room

            here = self.world.current_cell_name == step["room"]
            self.world.go_to(next(pos for pos, name in WORLD_LAYOUT.items() if name == step["room"]))
            kinds = self.gm.data.load("field_monsters")
            # A foe stands as its monster's kind on the map, or its sprite's (the wake's dwende).
            foes = {foe["name"]: kinds.get(foe["monster"]) or kinds[foe["sprite"]] for s in self.story.steps
                    for foe in s.get("fight", []) if foe["monster"] in kinds or foe["sprite"] in kinds}
            self.stage = Stage(cast(self.story.name), foes)
            if here:
                self.stage.do({"stand": [{"who": StorySettings.PLAYER, "col": self.player.col,
                                          "row": self.player.row, "facing": tuple(self.player.facing)}]})
        elif any(key in step for key in ("stand", "move", "turn", "fall")):
            if self.stage is not None:
                self.stage.do(step)
        elif "fade" in step:
            self._fade_to = 1.0 if step["fade"] == "out" else 0.0
        elif "wait" in step:
            self._wait = step["wait"]
        elif "song" in step:
            self.story.song = step["song"]
        elif "choice" in step:
            from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

            options = step["options"]
            self.gm.scene_stack.push(ChoiceScene(
                self.gm, step["choice"], [label for label, _ in options],
                lambda index: self.story.choose(options[index][1]),
            ))
        elif "fight" in step:
            from core.scenes.battle_scene import BattleScene  # local, as _start_fight

            # The taro patch's fight has Hina's tutorial (Frankie, 10/26).
            self._story_fight = BattleScene(self.gm, enemies=step["fight"], can_escape=False,
                                            in_town=self._in_town(), story=True,
                                            tutorial=self.story.name == TutorialSettings.SCENE,
                                            music=self.story.song, swap_lesson=self._swap_lesson())
            self.gm.scene_stack.push(self._story_fight)
        else:
            self._story_over()

    def _swap_lesson(self) -> str | None:
        """At the wake, whoever came along and sits on the bench: Hina shows the player Swap."""
        if self.story.name != StorySettings.WAKE_SCENE:
            return None
        return StorySettings.WAKE_BENCH if self.gm.party.find(StorySettings.WAKE_BENCH) is not None else None

    def _wake_gift(self) -> None:
        """The stew saved, the chief thanks Kailo at the wake with a rare drop or relic (Frankie, 10/26)."""
        from settings import ItemSettings

        item = random.choice(ItemSettings.EQUIP_DROPS + StorySettings.WAKE_GIFT_EXTRA)
        inventory = self.gm.party.inventory
        inventory[item] = inventory.get(item, 0) + 1
        self.gm.audio.play("chest_open")
        self.text_box.push(StorySettings.WAKE_GIFT_LINE.format(item=ItemSettings.NAMES.get(item, item)))

    def _join_at_wake(self) -> None:
        """Before the fight Tawiri joins fourth, with her pop-up; whoever else came sits on the bench."""
        from core.factories import party_member_from_data
        from core.shared import by_id

        party = self.gm.party
        if party.find(StorySettings.WAKE_JOINS) is not None:
            return
        party.add(party_member_from_data(by_id("characters")[StorySettings.WAKE_JOINS]))
        lore.unlock(party, "event tawiri_joins")
        bench = party.find(StorySettings.WAKE_BENCH)
        if bench is not None:
            party.members.remove(bench)
            party.members.append(bench)
        self.gm.audio.play("hit_sparkle_1")
        self.text_box.push(StorySettings.WAKE_JOIN_LINE)

    def _story_over(self) -> None:
        """A scene's part is over: a lost story fight again, but for the taro patch's; else on with the demo.

        Losing the taro patch goes on with the game (Frankie, 10/26); the save
        keeps that the gulls got the stew.
        """
        if self.story.part == LOSE and self.story.name != "taro_patch":
            self.story.retry()
            return
        part = self.story.part
        name, flags, ended, self.story = self.story.name, self.story.flags, self.story.ended, None
        lore.naming = False
        self._leave_stage()
        party = self.gm.party
        if name == "taro_patch":
            party.flags[StorySettings.TARO_FLAG] = True
            party.flags[StorySettings.STEW_LOST_FLAG] = part == LOSE
            # Hina goes home, out of the party until Kailo comes to her (Frankie, 10/23).
            party.leave(StorySettings.HOME_MEMBER)
            self._sync_joined()
        elif name in (StorySettings.HOME_SCENE, StorySettings.WOODS_SCENE):
            if party.rejoin(StorySettings.HOME_MEMBER) is None:
                from core.factories import party_member_from_data
                from core.shared import by_id

                party.add(party_member_from_data(by_id("characters")[StorySettings.HOME_MEMBER]))
            first = not party.flags.get(StorySettings.HOME_FLAG)
            party.flags[StorySettings.HOME_FLAG] = True
            self._sync_joined()
            if first:
                # Her pop-up, as Maika's (Frankie, 10/27).
                self.text_box.push(join_line(StorySettings.HOME_MEMBER))
                self.gm.audio.play("hit_sparkle_1")
            lore.unlock(party, "event hina_home")
        elif name == StorySettings.JOINER_MEETS:
            person = self._joiner()
            if person is not None:
                lore.unlock(party, f"event met_{person['joins']}")
                self._open_joiner_shop(person)
        elif name == StorySettings.JOINER_JOINS:
            self._joiner_joins()
        elif name == StorySettings.ASK_SCENE:
            # Fight now, or a few steps back the way they came, to heal and save first.
            if StorySettings.ASK_FIGHT in flags and self._asking in self.monsters:
                self._start_fight(self._asking)
            else:
                dx, dy = self.player.facing
                self._walk_back = [(-dx, -dy)] * StorySettings.BACK_STEPS
        elif name in (StorySettings.VILLAGE_MAIKA, StorySettings.VILLAGE_STALL):
            # Back out of the opening, west, the way in (the village cannot be entered).
            self._walk_back = [(-1, 0)] * StorySettings.VILLAGE_BACK_STEPS
        elif name in (StorySettings.DEEP_HINA, StorySettings.DEEP_MAIKA):
            # Either names Lanu's beasts, which finds her page (Frankie, 10/25).
            party.flags[f"story_{name}"] = True
            lore.unlock(party, "event deep_woods")
        elif name == StorySettings.TUSK_SCENE:
            # The tusk is hers now; the wake waits in the chief's room.
            party.inventory.pop(StorySettings.TUSK, None)
            party.flags[StorySettings.TUSK_FLAG] = True
        elif name == StorySettings.SEED_SCENE:
            party.flags[StorySettings.SEED_FLAG] = True
            self.gm.audio.play("learned")
        elif name.startswith("kaigara_"):
            self._kaigara_over(name, flags)
        elif name == "wake":
            # The wake ends the demo (Frankie, 10/23): it faded out on its last line, and
            # its End is on the black screen until confirm goes to the title. Hina named
            # Shaka there, and Maika, if he came, Lanu.
            lore.unlock(party, "event wake_shaka")
            if f"{StorySettings.WAKE_BENCH} along" in flags:
                lore.unlock(party, "event wake_lanu")
            self._dark, self._card = 1.0, ended

    def _talk_to_kame(self) -> None:
        """The Kame, or his table: meeting him the first time, which finds his Lore page; then his questions."""
        if self.gm.party.flags.get(KaigaraSettings.MET_FLAG):
            self.begin_story(KaigaraSettings.MENU_SCENE)
            return
        lore.unlock(self.gm.party, KaigaraSettings.MET_EVENT)
        self.begin_story(KaigaraSettings.MEET_SCENE)

    def _kaigara_over(self, name: str, flags: set) -> None:
        """One of the Kame's scenes is over: on to his questions, a game, or an answer."""
        if name == KaigaraSettings.MEET_SCENE:
            self.gm.party.flags[KaigaraSettings.MET_FLAG] = True
            self.begin_story(KaigaraSettings.MENU_SCENE)
        elif name == KaigaraSettings.MENU_SCENE:
            asked = next((q for q in KaigaraSettings.QUESTIONS if q in flags), None)
            if KaigaraSettings.PLAY in flags:
                self._play_kaigara()
            elif asked is not None:
                lore.unlock(self.gm.party, f"event kaigara_{asked}")
                self.begin_story(f"kaigara_{asked}")
        elif name.removeprefix("kaigara_") in KaigaraSettings.QUESTIONS:
            self.begin_story(KaigaraSettings.MENU_SCENE)

    def _play_kaigara(self) -> None:
        """A game against the Kame; when it is over, the Lore pages, the prize and his line after."""
        from core.scenes.kaigara_scene import KaigaraScene  # local, as the battle
        from systems import kaigara

        def done(winner: str | None) -> None:
            first = kaigara.settle(self.gm.party, winner)
            if first:
                self.gm.audio.play("hit_sparkle_1")
            self.begin_story(KaigaraSettings.FIRST_WIN_SCENE if first
                             else KaigaraSettings.WIN_SCENE if winner == kaigara.BLACK
                             else KaigaraSettings.DRAW_SCENE if winner is None
                             else KaigaraSettings.LOSE_SCENE)

        self.gm.scene_stack.push(KaigaraScene(self.gm, on_done=done))

    def _leave_stage(self) -> None:
        """The scene is over: Kailo stays where the stage left him; everyone else is gone.

        Left on a doorway facing out, he goes through the door (Hina's scene).
        """
        if self.stage is None:
            return
        kailo = self.stage.actors.get(StorySettings.PLAYER)
        if kailo is not None and not kailo.off():
            self.player.from_dict({"col": kailo.col, "row": kailo.row, "facing": list(kailo.facing)})
            arrived = self.world.warp(kailo.col, kailo.row, kailo.facing)
            if arrived is not None:
                self.player.from_dict({"col": arrived[0], "row": arrived[1], "facing": list(kailo.facing)})
        self.stage = None

    def _hina_catches_up(self) -> bool:
        """Kailo in the room before the Great Boar's without having been to Hina's house: she runs after him."""
        party = self.gm.party
        return (self.world.current_cell_name == StorySettings.WOODS_ROOM and not self.player._step_active
                and party.flags.get(StorySettings.TARO_FLAG) and not party.flags.get(StorySettings.HOME_FLAG)
                and party.find(StorySettings.HOME_MEMBER) is None)

    def _deep_woods_warning(self) -> str | None:
        """On the log yard's west edge, walking west: Maika's warning if he is along, else Hina's, each once (Frankie, 10/25)."""
        party = self.gm.party
        if (self.world.current_cell_name != StorySettings.DEEP_ROOM or self.player._step_active
                or self.player.col != StorySettings.DEEP_COL or tuple(self.player.facing) != (-1, 0)):
            return None
        if party.find(StorySettings.JOINER) is not None:
            scene = StorySettings.DEEP_MAIKA
        elif party.find(StorySettings.HOME_MEMBER) is not None:
            scene = StorySettings.DEEP_HINA
        else:
            return None
        return None if party.flags.get(f"story_{scene}") else scene

    def _sage_village_turn(self) -> str | None:
        """In the opening east of Maika's room: his lines turning the party back, along or from his stall (Frankie, 10/26)."""
        if (self.world.current_cell_name != StorySettings.VILLAGE_ROOM or self.player._step_active
                or self._walk_back or self.player.col != StorySettings.VILLAGE_COL):
            return None
        if self.gm.party.find(StorySettings.JOINER) is not None:
            return StorySettings.VILLAGE_MAIKA
        return StorySettings.VILLAGE_STALL if self._joiner() is not None else None

    def _render_night(self, surface: pygame.Surface) -> None:
        """Night outside: the Super Nintendo's color math, a fixed color taken from every pixel."""
        if not self.is_night() or self.world.current_pos[1] >= INSIDE_ROW:
            return
        surface.fill(
            tuple(amount * 8 for amount in StorySettings.NIGHT_SUBTRACT),
            pygame.Rect(OverworldSettings.X, OverworldSettings.Y,
                        OverworldSettings.PIXEL_W, OverworldSettings.PIXEL_H),
            special_flags=pygame.BLEND_RGB_SUB,
        )
    # THE GARDEN AND THE POT: Hina plants, Maika grows, Kailo cooks
    # (Frankie, 10/22; systems/garden.py, core/scenes/craft_scene.py)
    # ------------------------------------------------------------------

    def _faced_patch(self) -> int | None:
        """The garden patch on the tile the player faces, by its index in the room, or None."""
        dx, dy = self.player.facing
        return self.world.patch_tiles.get((self.player.col + dx, self.player.row + dy))

    def _tend(self, index: int) -> None:
        """One press, one thing (Frankie, 10/23): pick the patch, or ask to replant it or grow it faster."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        pressed = garden.press(self.gm.party, self.world.current_cell_name, index)
        if pressed.line is not None:
            if pressed.line.startswith("Picked"):
                self.gm.audio.play("hit_sparkle_1")
            self.text_box.push(pressed.line)
        if pressed.offer is not None:
            speaker, line = pressed.offer
            self.text_box.push(line, speaker=speaker)
        if pressed.question is None:
            return

        def yes() -> None:
            self.gm.audio.play("hit_sparkle_1")
            for line in pressed.yes():
                self.text_box.push(line)
            # The first planting with Maika and Hina along, he teaches her Seed (Frankie, 10/24).
            if pressed.question.startswith(GardenSettings.REPLANT_BOX.split("{")[0]) and self._seed_lesson_due():
                self.begin_story(StorySettings.SEED_SCENE)

        def ask() -> None:
            self.gm.scene_stack.push(ConfirmScene(self.gm, pressed.question, on_yes=yes))
        if self.text_box.is_done():
            ask()
        else:
            self._after_text = ask

    def _open_chest(self) -> None:
        """A chest (Frankie, 10/24): its item in the bag the first time, then it is empty.

        A chest with ``random`` instead holds one of ``ItemSettings.CHEST_RANDOM``,
        picked when it is opened (Frankie, 10/25): a weapon or relic, or a
        goodie, which may be pule. His dad's chest (Frankie, 10/26) holds
        several: its ``item``, the ``also`` list, and ``random`` picked a
        number of times in the ``picks`` range; Kailo says its ``before``
        line, then it opens.
        """
        dx, dy = self.player.facing
        chest = self.world.building_at(self.player.col + dx, self.player.row + dy)
        flag = chest_flag(self.world.current_cell_name, chest)
        items = chest_items(chest)
        if self.gm.party.flags.get(flag) or not items:
            self.text_box.push(StorySettings.CHEST_EMPTY)
            return
        self.gm.party.flags[flag] = True
        if chest.get("before"):
            self.text_box.push(chest["before"], speaker="Kailo")
            self._after_text = lambda: self._take_from_chest(chest, items)
        else:
            self._take_from_chest(chest, items)

    def _take_from_chest(self, chest: dict, items: list[str]) -> None:
        """The chest opens: ``items`` go in the bag (pule in the purse), each said, then its ``line``."""
        from settings import ItemSettings

        self.gm.audio.play("chest_open")
        for item in items:
            if item == "pule":
                self.gm.party.pule += ItemSettings.CHEST_PULE
                self.text_box.push(StorySettings.CHEST_FOUND.format(item=f"{ItemSettings.CHEST_PULE} pule"))
            else:
                self.gm.party.inventory[item] = self.gm.party.inventory.get(item, 0) + 1
                self.text_box.push(StorySettings.CHEST_FOUND.format(item=ItemSettings.NAMES.get(item, item)))
        if chest.get("line"):
            self.text_box.push(chest["line"], speaker="Kailo")

    def _open_pot(self) -> None:
        """The pot inside Kailo's house opens the crafting pot, the only place to craft (Frankie, 10/24)."""
        from core.scenes.craft_scene import CraftScene  # local: cycle.

        self.gm.audio.play("menu_select")
        self.gm.scene_stack.push(CraftScene(self.gm))

    def _count_steps(self) -> None:
        """Count a step for the garden each time the player stands on a new tile."""
        here = (self.world.current_pos, self.player.col, self.player.row)
        if self._last_tile is not None and here != self._last_tile:
            garden.walked(self.gm.party)
        self._last_tile = here

    def _render_patches(self, surface: pygame.Surface) -> None:
        """Draw each patch in the room by how far it has grown."""
        tile_size = GridSettings.TILE_SIZE
        for index, patch in enumerate(garden.patches_in(self.world.current_cell_name)):
            sheet = _patch_sheet(patch["plant"])
            x = OverworldSettings.X + patch["col"] * tile_size
            y = OverworldSettings.Y + patch["row"] * tile_size
            stage = garden.stage(self.gm.party, self.world.current_cell_name, index)
            if sheet is None:
                pygame.draw.rect(surface, ColorSettings.OVERWORLD_SAND, (x, y, tile_size, tile_size))
                continue
            surface.blit(sheet, (x, y), (stage * tile_size, 0, tile_size, tile_size))

    def _rest(self, line: str = TownSettings.POND_LINE) -> None:
        """Drink from the pond, or nap in Kailo's bed: everyone standing back to full HP (D-525).

        The knocked out stay down, and neither saves (Frankie, 10/26): only a totem does both.
        """
        for member in self.gm.party.members:
            if member.current_hp > 0:
                member.current_hp = member.max_hp
        self.gm.audio.play("hit_sparkle_1")
        self.text_box.push(line)
        if any(member.current_hp <= 0 for member in self.gm.party.members):
            self.text_box.push(TownSettings.STILL_DOWN)

    def _pray(self) -> None:
        """Pray at an Akua totem (Frankie, 10/26): tell the Akua all that has happened,
        as Dragon Quest's confession, the fallen get back up at full HP, then save.

        The first time Hina explains, or Kailo with her away. No status outlasts a
        fight yet, so there is no zombie or curse here to lift.
        """
        flags = self.gm.party.flags
        if not flags.get(TownSettings.TOTEM_FLAG):
            flags[TownSettings.TOTEM_FLAG] = True
            speaker = "Hina" if self.gm.party.find("hina") is not None else StorySettings.PLAYER
            for line in TownSettings.TOTEM_FIRST[speaker]:
                self.text_box.push(line, speaker=speaker)
        self.text_box.push(TownSettings.PRAY_LINE)
        fallen = [m for m in self.gm.party.members if m.current_hp <= 0]
        for member in fallen:
            member.current_hp = member.max_hp
        self.gm.audio.play("hit_sparkle_1")
        if fallen:
            self.text_box.push(TownSettings.REVIVE_LINE)
        self._after_text = self._ask_save

    def _ask_save(self) -> None:
        """After praying at a totem, the save point: YES opens the three slots; NO, nothing."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below
        from core.scenes.save_slot_scene import SaveSlotScene

        self.gm.scene_stack.push(ConfirmScene(
            self.gm, TownSettings.SAVE_BOX,
            on_yes=lambda: self.gm.scene_stack.push(SaveSlotScene(self.gm, loading=False)),
        ))

    def update(self, dt: float) -> None:
        """Tick the text box, then advance the player if no text is showing.

        After advancing the player, any newly-completed steps roll for
        a random encounter; on a hit a ``BattleScene`` is pushed on
        top of this scene. The overworld resumes automatically when
        the battle pops, since this scene was never destroyed.

        Args:
            dt: Frame time in seconds.
        """
        self._room_sound()
        self._end_visit()
        self._watch_place(dt)
        self.text_box.update(dt)
        self._tick_opening()
        if self.stage is not None:
            self.stage.update(dt)
        self._tick_fade(dt)
        if self._card is not None or not self.text_box.is_done():
            return
        if self._after_text is not None:
            action, self._after_text = self._after_text, None
            action()
            return
        if self.story is not None:
            self._play_story()
            return
        self._watch_sparring(dt)
        if not self.text_box.is_done():
            return
        self._place_monsters()
        if self._walk_back and not self.player._step_active:
            self.player._begin_step(*self._walk_back.pop())
        else:
            self.player.update(dt)
        self._count_steps()
        self._wander_people(dt)
        if self._dead_end():
            return
        if self._hina_catches_up():
            self.begin_story(StorySettings.WOODS_SCENE)
            return
        if self._wake_ask_due():
            self._ask_wake()
            return
        warning = self._deep_woods_warning()
        if warning is not None:
            self.begin_story(warning)
            return
        turned = self._sage_village_turn()
        if turned is not None:
            self.begin_story(turned)
            return
        # Walking into the Great Boar: are you ready? Once each time they walk up.
        boss = self._asker_in_reach()
        if boss is None:
            self._asked = False
        elif not self._asked and not self.player._step_active and not self._walk_back:
            self._asked = True
            self._asking = boss
            self.begin_story(StorySettings.ASK_SCENE)
            return
        self._place_monsters()
        self._grace = max(0.0, self._grace - dt)
        for monster in self.monsters:
            taken = set().union(*(m.tiles() for m in self.monsters if m is not monster))
            if self._grace > 0:
                # The monster left standing waits for the party to walk off.
                taken.add((self.player.col, self.player.row))
            chase = None if self._grace > 0 else (self.player.col, self.player.row)
            monster.update(dt, self.world, taken, chase)
        # Started from the Workshop with fights off, the monsters walk
        # but never start one, so a room can be looked over in peace.
        if self._grace <= 0 and not getattr(self.gm, "no_fights", False):
            for monster in self.monsters:
                if monster.spot.get("kind") == StorySettings.ASK_KIND:
                    continue
                if (self.player.col, self.player.row) in monster.tiles():
                    self._start_fight(monster)
                    return

    def _tick_fade(self, dt: float) -> None:
        """Take the screen's darkness toward where a Fade sends it, and count down a Wait."""
        self._wait = max(0.0, self._wait - dt)
        if self._fade_to is None:
            return
        step = dt / StorySettings.FADE_SECONDS
        if self._fade_to > self._dark:
            self._dark = min(self._fade_to, self._dark + step)
        else:
            self._dark = max(self._fade_to, self._dark - step)
        if self._dark == self._fade_to:
            self._fade_to = None

    def _render_dark(self, surface: pygame.Surface) -> None:
        """The fade, as the Super Nintendo's master brightness in its sixteen steps; and on
        black at the end, the demo's last words."""
        level = round(self._dark * StorySettings.FADE_STEPS) / StorySettings.FADE_STEPS
        if level > 0:
            veil = pygame.Surface(surface.get_size())
            veil.set_alpha(round(level * 255))
            surface.blit(veil, (0, 0))
        if self._card:
            from ui import text_renderer  # local: only the end needs it

            size = StorySettings.CARD_SIZE
            width = text_renderer.text_width(self._card, size)
            text_renderer.draw_text(surface, self._card, ((surface.get_width() - width) // 2,
                                    (surface.get_height() - text_renderer.line_height(size)) // 2), size=size)

    def _take_turn(self, person: dict, which: str, lines: list) -> int | None:
        """The next of a person's ``lines``, one a talk, round and round, never all in a row
        (Frankie, 10/26). ``which`` names the set, by day, at night or a flag's, each with its
        own place in the round, so a new set starts at its first line. Returns the index said.

        A line can be a ``talk`` exchange, one thought over several boxes or a back-and-forth
        with Kailo, played whole as one turn. With ``once`` too, it plays the first time, and
        its flag drops it from the round for good (Melia asking about Kailo's dad, Frankie, 10/25).
        """
        flags = self.gm.party.flags if self.gm.party else {}
        turn = person.setdefault("turn", {}).get(which, 0)
        for step in range(len(lines)):
            index = (turn + step) % len(lines)
            line = lines[index]
            if not (isinstance(line, dict) and flags.get(line.get("once"))):
                break
        else:
            return None
        person["turn"][which] = index + 1
        if isinstance(line, dict) and line.get("once") and self.gm.party:
            self.gm.party.flags[line["once"]] = True
        self._say(person, line)
        return index

    def _say(self, person: dict, line) -> None:
        """One of a person's lines: a plain line under their ``speaker``, or a ``talk``
        exchange, a row with a third word only with that member along (Kailo
        answering Keo, Frankie, 10/26)."""
        if not isinstance(line, dict):
            self.text_box.push(line, speaker=person["speaker"])
            return
        for speaker, said, *along in line["talk"]:
            if not along or (self.gm.party and self.gm.party.find(along[0]) is not None):
                self.text_box.push(said, speaker=speaker)

    def _end_visit(self) -> None:
        """Leaving a room by one of a found person's ``leaves_by`` sides sends them home:
        Melia, found, goes back to the pots by Kailo's house once he walks off north or east
        (Frankie, 10/25)."""
        here = self.world.current_cell_name
        if here == self._visiting:
            return
        rooms = {name: pos for pos, name in self.world.layout.items()}
        was, now = rooms.get(self._visiting), rooms.get(here)
        side = [now[0] - was[0], now[1] - was[1]] if was and now else None
        flags = self.gm.party.flags if self.gm.party else {}
        for person in PEOPLE.get(self._visiting, []):
            if side in person.get("leaves_by", []) and flags.get(person["first"]["flag"]):
                flags[person["until"]] = True
        self._visiting = here

    def _room_sound(self) -> None:
        """Each room's song, going on unbroken from room to room while it is the same
        (Frankie, 10/23; as the cartridge's room_sound): all through the town, its buildings
        too, the surf alone, day and night (Frankie, 10/24); quiet everywhere else at night
        (the Great Boar beaten); by day The Big Bad in his room and the woods' song in the
        rest; Regrets all through Pono's wake, but for a scene's Song (Tawiri's theme), and
        nothing from its Song: none to its End's words (Frankie, 10/27)."""
        if self._card is not None:
            self.gm.audio.play_screen(AudioSettings.SILENT)
        elif self.story is not None and self.story.song:
            self.gm.audio.play_screen(self.story.song)
        else:
            self.gm.audio.play_screen(self._room_screen())

    def _room_screen(self) -> str:
        """The room's song (``_room_sound``) with no Song over it."""
        name = self.world.current_cell_name
        town = AudioSettings.BEACH_ROOMS
        if self.story is not None and self.story.name == "wake":
            screen = "wake"
        elif name in town or any(b.get("inside") == name for room in town for b in BUILDINGS.get(room, [])):
            screen = "beach"
        elif self.world.current_pos[1] >= INSIDE_ROW or self.is_night():
            screen = "quiet"
        elif name == StorySettings.SEED_ROOM:
            screen = "great_boar"
        else:
            screen = "woods"
        return screen

    def _watch_sparring(self, dt: float) -> None:
        """The villagers' sparring, silent (Frankie, 10/23): 30 seconds watching, once, teaches Kailo.

        Watching is standing next to one of them, facing them, with nothing
        pressed; a step or a turn away starts the count again.
        """
        if not any(person.get("spar") for person in self.world.people):
            self._idle = 0.0
            return
        if self.player._step_active or not self._faced_person().get("spar"):
            self._idle = 0.0
            return
        self._idle += dt
        if self._idle < TownSettings.WATCH_SECONDS or self.gm.party.flags.get(TownSettings.WATCH_FLAG):
            return
        member = self.gm.party.find(TownSettings.WATCH_MEMBER)
        if member is None:
            return
        self.gm.party.flags[TownSettings.WATCH_FLAG] = True
        for stat, points in TownSettings.WATCH_GROWTH.items():
            member.growth[stat] = member.growth.get(stat, 0) + points
        member.refresh_stats()
        self.gm.audio.play("learned")
        for line in TownSettings.WATCH_LINES:
            self.text_box.push(line)

    def _place_monsters(self) -> None:
        """Put the cell's monsters out when the party arrives in a cell (D-576)."""
        if self._monsters_cell == self.world.current_pos:
            return
        self._monsters_cell = self.world.current_pos
        self._grace = 0.0
        kinds = self.gm.data.load("field_monsters")
        self.monsters = [
            FieldMonster(spot, kinds[spot["kind"]])
            for spot in FIELD_MONSTERS.get(self.world.current_cell_name, [])
            if not (spot.get("boss") and self.gm.party.flags.get(
                _boss_flag_for(self.world.current_cell_name, spot)
            ))
        ]

    def _in_town(self) -> bool:
        """Whether the party stands in one of the town's rooms, where a fight is on the beach."""
        return self.world.current_cell_name in BackgroundSettings.TOWN_ROOMS

    def _start_fight(self, monster: FieldMonster) -> None:
        """Push the fight ``monster`` brings, and remember whose it is."""
        # Local import: ``BattleScene`` lives in a sibling scene file
        # and importing it at the top would risk a cycle the moment a
        # battle ever needs to read overworld state on the way out.
        from core.scenes.battle_scene import BattleScene, compose_fight

        battle = BattleScene(self.gm, enemies=compose_fight(monster.kind), in_town=self._in_town())
        self._fighting = (monster, battle)
        self.gm.scene_stack.push(battle)

    def render(self, surface: pygame.Surface) -> None:
        """Paint background, cell tiles, player, and message box in that order.

        Args:
            surface: The screen surface to draw onto.
        """
        render_scene_background(self, surface)
        offset = room_offset(self.world.current_grid)
        room = surface
        if offset != (0, 0):
            # A room smaller than the screen is drawn whole and then moved to the middle.
            if self._room_layer is None or self._room_layer.get_size() != surface.get_size():
                self._room_layer = pygame.Surface(surface.get_size())
            room = self._room_layer
        self._render_cell(room)
        self._render_patches(room)
        cell_name = self.world.current_cell_name
        for building in self.world.buildings:
            opened = (building["kind"] == "chest"
                      and bool(self.gm.party.flags.get(chest_flag(cell_name, building))))
            draw_building(room, building, OverworldSettings.X, OverworldSettings.Y, opened)
        self._render_people(room)
        for monster in self.monsters:
            monster.render(room)
        # While a scene is on the stage, Kailo is only where it puts him: in a
        # room he is not staged in (the wake's cutaway to Melia) he is not there.
        if self.stage is not None:
            self.stage.render(room)
        else:
            self.player.render(room)
        if room is not surface:
            surface.fill(walls.DARK)
            surface.blit(room, offset)
        self._render_night(surface)
        # The opening's words stay lit as the beach fades in under them.
        if not self._opening:
            self.text_box.render(surface)
        self._render_popup(surface)
        self._render_dark(surface)
        if self._opening:
            self.text_box.render(surface)

    # ------------------------------------------------------------------
    # INTERNAL HELPERS
    # ------------------------------------------------------------------

    def _render_cell(self, surface: pygame.Surface) -> None:
        """Draw the active cell's tile grid, one picture per tile.

        Args:
            surface: The screen surface to draw onto.
        """
        grid = self.world.current_grid
        tile_size = GridSettings.TILE_SIZE
        tiles = _tiles()
        floor = OverworldSettings.FLOOR_CHAR
        for row in range(OverworldSettings.ROWS):
            row_cells = grid[row]
            for col in range(OverworldSettings.COLS):
                char = row_cells[col]
                x = OverworldSettings.X + col * tile_size
                y = OverworldSettings.Y + row * tile_size
                if not tiles:
                    color = _TILE_COLORS.get(char, ColorSettings.OVERWORLD_FLOOR)
                    pygame.draw.rect(surface, color, (x, y, tile_size, tile_size))
                    continue
                if char in shore.WATER:
                    coast = shore.water_tile(grid, col, row)
                    if coast is not None:
                        surface.blit(coast, (x, y))
                        continue
                if char in walls.CHARS:
                    surface.blit(walls.tile(grid, col, row), (x, y))
                    continue
                under = OverworldSettings.TILE_UNDER.get(char)
                if under is not None:
                    surface.blit(_pick(tiles[under], col, row), (x, y))
                surface.blit(_pick(tiles.get(char, tiles[floor]), col, row), (x, y))

    def _wander_people(self, dt: float) -> None:
        """Villagers with ``wander`` stroll a few tiles from their spot (Frankie, 10/26).

        Each rests a while, then tries one step in a random direction: never off
        the room, onto a wall, a building, someone else, the party or the tile
        Kailo faces, and never further from where the room file puts them than
        ``wander`` tiles. Beside Kailo they hold still, so he can talk to them
        (Frankie, 10/26); talking, they turn to him and nobody walks.
        """
        dx, dy = self.player.facing
        kailo = (self.player.col, self.player.row)
        faced = (kailo[0] + dx, kailo[1] + dy)
        for person in self.world.people:
            reach = person.get("wander")
            if not reach:
                continue
            person.setdefault("_home", (person["col"], person["row"]))
            if person.get("_t", 1.0) < 1.0:
                person["_t"] = min(1.0, person["_t"] + dt * 1000 / TownSettings.WANDER_STEP_MS)
                continue
            if abs(person["col"] - kailo[0]) + abs(person["row"] - kailo[1]) == 1:
                continue
            person["_wait"] = person.get("_wait", random.uniform(*TownSettings.WANDER_WAIT_RANGE)) - dt
            if person["_wait"] > 0:
                continue
            person["_wait"] = random.uniform(*TownSettings.WANDER_WAIT_RANGE)
            dc, dr = random.choice(((1, 0), (-1, 0), (0, 1), (0, -1)))
            col, row = person["col"] + dc, person["row"] + dr
            home = person["_home"]
            if (not (0 <= col < OverworldSettings.COLS and 0 <= row < OverworldSettings.ROWS)
                    or self.world.is_wall(col, row) or (col, row) in (kailo, faced)
                    or abs(col - home[0]) + abs(row - home[1]) > reach):
                continue
            person["_from"] = (person["col"], person["row"])
            person["col"], person["row"], person["facing"] = col, row, [dc, dr]
            person["_t"] = 0.0

    def _render_people(self, surface: pygame.Surface) -> None:
        """Draw everyone in the cell: standing, or part way along a wandering step."""
        tile_size = GridSettings.TILE_SIZE
        column = OverworldPlayerSettings.SHEET_COLUMNS
        for person in self.world.people:
            if self.stage is not None and self.stage.hides(person):
                continue
            if person.get("sits"):
                self._render_sitter(surface, person)
                continue
            sheet = _person_sheet(person["sheet"])
            if sheet is None:
                continue
            t = person.get("_t", 1.0)
            # The feet move while they step; standing is the first frame.
            step = int(t * OverworldPlayerSettings.WALK_FRAMES) if t < 1.0 else 0
            frame = sheet.subsurface(pygame.Rect(
                column.get(tuple(person["facing"]), 0) * tile_size,
                min(step, sheet.get_height() // tile_size - 1) * tile_size, tile_size, tile_size,
            ))
            from_col, from_row = person.get("_from", (person["col"], person["row"]))
            surface.blit(frame, (
                OverworldSettings.X + round((from_col + (person["col"] - from_col) * t) * tile_size),
                OverworldSettings.Y + round((from_row + (person["row"] - from_row) * t) * tile_size),
            ))

    @staticmethod
    def _render_sitter(surface: pygame.Surface, person: dict) -> None:
        """Someone sitting, who never walks (the Kaigara Kame): their picture, now and then a blink."""
        sheet = _person_sheet(person["sheet"], KaigaraSettings.SIT_SHEET)
        if sheet is None:
            return
        tile_size = GridSettings.TILE_SIZE
        blink = pygame.time.get_ticks() / 1000 % KaigaraSettings.BLINK_EVERY < KaigaraSettings.BLINK_SECONDS
        frame = sheet.subsurface(pygame.Rect(tile_size if blink else 0, 0, tile_size, tile_size))
        surface.blit(frame, (OverworldSettings.X + person["col"] * tile_size,
                             OverworldSettings.Y + person["row"] * tile_size))

    def _open_menu(self) -> None:
        """Push the translucent system menu on top of this scene."""
        # Local import: ``MenuScene`` lives in a sibling scene module
        # and importing it at top of file would risk a cycle if the
        # menu ever pushes overworld-aware actions later.
        from core.scenes.menu_scene import MenuScene

        self.gm.scene_stack.push(MenuScene(self.gm))

    # ------------------------------------------------------------------
    # PERSISTENCE
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Serialise the active cell pointer and the player's tile state."""
        base = super().to_dict()
        base["world"] = self.world.to_dict()
        base["player"] = self.player.to_dict()
        return base

    @classmethod
    def from_dict(cls, gm: "GameManager", data: dict) -> "OverworldScene":
        """Rebuild a scene from a previously-saved dict.

        Args:
            gm: The host game manager.
            data: The dict previously returned by ``to_dict``.

        Returns:
            A fully-restored ``OverworldScene``.
        """
        scene = cls(gm)
        if isinstance(data, dict):
            world_data = data.get("world")
            if isinstance(world_data, dict):
                scene.world.from_dict(world_data)
            player_data = data.get("player")
            if isinstance(player_data, dict):
                scene.player.from_dict(player_data)
            if getattr(scene.world, "moved_from_gone_room", False):
                scene._step_off_things()
        return scene

    def _step_off_things(self) -> None:
        """If the party stands on something (a save from a room since rearranged),
        move it to the nearest open tile."""
        start = (self.player.col, self.player.row)
        seen, queue = {start}, [start]
        while queue:
            col, row = queue.pop(0)
            inside = 0 <= col < OverworldSettings.COLS and 0 <= row < OverworldSettings.ROWS
            if inside and not self.world.is_wall(col, row):
                if (col, row) != start:
                    self.player.from_dict({"col": col, "row": row})
                return
            for dc, dr in ((0, 1), (0, -1), (1, 0), (-1, 0)):
                nxt = (col + dc, row + dr)
                if nxt not in seen and 0 <= nxt[0] < OverworldSettings.COLS and 0 <= nxt[1] < OverworldSettings.ROWS:
                    seen.add(nxt)
                    queue.append(nxt)
