"""The overworld — sprite walks a tile grid, message box at the bottom.

The Layer-3 destination scene, kicked off early so it can advance in
parallel with the Layer-1 text demo / battle polish. Owns three
collaborators: a ``World`` (cell layout + active-cell pointer), an
``OverworldPlayer`` (logical position + sprite animation + held-input
polling), and a ``TextBox`` (the existing widget, reused unchanged for
the bottom message panel).

What is and is not here in Pass 1:

* **Walking, cell transitions, save/load round-trip** — yes.
* **System-menu push on Tab / START** — yes (re-uses ``MenuScene``).
* **The pond (D-525), a market stall (D-571) and its keeper (D-574)** — face them and confirm.
* **Monsters on the map** (D-576): touching one starts its fight; no
  random encounters.
* **NPCs, dialogue triggers, signs, warp tiles** — Pass 2.
* **Animated walk cycle, real sprite art** — Pass 2.

The cell area draws one 16 pixel picture per tile, chosen by the cell
char (``OverworldSettings.TILE_PICTURES``), from Mini World Sprites.
Without the pictures a flat colour per char stands in.

See [docs/design/overworld.md](../../docs/design/overworld.md) for the
full design rationale.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from core.overworld_cells import FIELD_MONSTERS
from core.world import World
from entities.field_monster import FieldMonster
from entities.overworld_player import OverworldPlayer
from settings import (
    AssetPaths,
    ColorSettings,
    FieldMonsterSettings,
    GridSettings,
    OverworldPlayerSettings,
    OverworldSettings,
)
from ui import input_map
from ui.text_box import TextBox
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager


# Stand-in colour per cell char, used when the tile pictures are missing.
_TILE_COLORS: dict[str, tuple[int, int, int]] = {
    OverworldSettings.FLOOR_CHAR: ColorSettings.OVERWORLD_FLOOR,
    OverworldSettings.WALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.WATER_CHAR: ColorSettings.OVERWORLD_WATER,
    OverworldSettings.SPRING_CHAR: ColorSettings.OVERWORLD_WATER,
    OverworldSettings.SAND_CHAR: ColorSettings.OVERWORLD_SAND,
    OverworldSettings.STALL_CHAR: ColorSettings.OVERWORLD_WALL,
}

# Tile pictures by cell char, loaded on first use. ``{}`` means the
# pictures were looked for and are missing.
_TILES: dict[str, list[pygame.Surface]] | None = None


def _tiles() -> dict[str, list[pygame.Surface]]:
    """Return the choices of 16 pixel picture for each cell char."""
    global _TILES
    if _TILES is not None:
        return _TILES
    _TILES = {}
    size = GridSettings.TILE_SIZE
    sheets: dict[str, pygame.Surface] = {}
    for char, choices in OverworldSettings.TILE_PICTURES.items():
        pictures = []
        for name, index in choices:
            if name not in sheets:
                path = os.path.join(AssetPaths.TILES_DIR, name)
                if not os.path.exists(path):
                    _TILES = {}
                    return _TILES
                sheets[name] = pygame.image.load(path).convert_alpha()
            sheet = sheets[name]
            pictures.append(sheet.subsurface(pygame.Rect(
                (index * size) % sheet.get_width(),
                (index * size) // sheet.get_width() * size,
                size, size,
            )))
        _TILES[char] = pictures
    return _TILES


# Each person's walk sheet by name, loaded on first use; None if missing.
_PEOPLE: dict[str, pygame.Surface | None] = {}


def _person_sheet(name: str) -> pygame.Surface | None:
    """Return the Ninja Adventure walk sheet ``<name>-Walk.png``, or None."""
    if name not in _PEOPLE:
        path = os.path.join(AssetPaths.PEOPLE_DIR, f"{name}-Walk.png")
        _PEOPLE[name] = pygame.image.load(path).convert_alpha() if os.path.exists(path) else None
    return _PEOPLE[name]


def _boss_flag_for(cell_name: str, spot: dict) -> str:
    """The party flag that marks a boss on the map as beaten for good."""
    return f"field_boss:{cell_name}:{spot['kind']}"


def _boss_flag(monster: FieldMonster) -> str:
    """The flag for ``monster``, a boss, in the cell it stands in."""
    for cell_name, spots in FIELD_MONSTERS.items():
        if monster.spot in spots:
            return _boss_flag_for(cell_name, monster.spot)
    return f"field_boss::{monster.spot['kind']}"


def _pick(pictures: list[pygame.Surface], col: int, row: int) -> pygame.Surface:
    """Pick one of ``pictures`` by tile position, the same every time."""
    return pictures[(col * 7 + row * 13 + col * row) % len(pictures)]


class OverworldScene(Scene):
    """The screen-locked, cell-based overworld."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Construct the overworld with its world, player, and text box.

        Args:
            gm: The host game manager. Provides audio, save, and
                cross-scene navigation routing.
        """
        super().__init__(gm)
        self.world = World()
        self.player = OverworldPlayer(gm, self.world)
        # Cell area is narrower than the screen, so size the text box
        # to the full screen width but keep the existing 160-px height.
        self.text_box = TextBox()
        # The monsters in the cell (D-576), placed afresh on every entry.
        self.monsters: list[FieldMonster] = []
        self._monsters_cell: tuple[int, int] | None = None
        # The monster whose fight is on, and how long until a monster
        # left standing by a fight can start another.
        self._fighting: tuple[FieldMonster, object] | None = None
        self._grace = 0.0

    def on_enter(self) -> None:
        """Play the field's music, and settle the fight just over, if one was.

        The song carries on if it is already playing (back from the
        menu). A monster beaten in its fight leaves the map, a boss for
        good; one that was run from or lost to stays, and waits a moment
        before it can start another (D-576).
        """
        self.gm.audio.play_screen("field")
        if self._fighting is None:
            return
        monster, battle = self._fighting
        self._fighting = None
        if battle.battle.outcome == "victory":
            if monster in self.monsters:
                self.monsters.remove(monster)
            if monster.spot.get("boss"):
                self.gm.party.flags[_boss_flag(monster)] = True
        else:
            self._grace = FieldMonsterSettings.GRACE_SECONDS

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Route one event.

        When the text box has content, confirm advances it and other
        keys fall through silently (so a held direction won't queue
        steps that fire the instant the player closes a dialogue).
        Otherwise, Tab / START pushes the system menu; movement is
        polled inside ``player.update`` and does not go through this
        handler.

        Args:
            event: The pygame event to route.
        """
        if not self.text_box.is_done():
            if input_map.is_confirm(event):
                self.text_box.advance()
            return
        # Facing the pond, confirm rests there; facing a stall, it opens
        # the shop; Enter opens the menu everywhere else.
        if input_map.is_confirm(event) and self._facing(OverworldSettings.SPRING_CHAR):
            self._rest()
            return
        if input_map.is_confirm(event) and self._facing(OverworldSettings.STALL_CHAR):
            self._open_shop("beach_stall")
            return
        if input_map.is_confirm(event) and self._faced_person().get("shop"):
            self._open_shop(self._faced_person()["shop"])
            return
        if input_map.is_menu(event):
            self._open_menu()

    def _facing(self, char: str) -> bool:
        """Whether the tile the player faces is ``char``: the pond (D-525), a stall (D-571)."""
        dx, dy = self.player.facing
        return self.world.tile_at(self.player.col + dx, self.player.row + dy) == char

    def _faced_person(self) -> dict:
        """The person on the tile the player faces, or an empty dict."""
        dx, dy = self.player.facing
        return self.world.person_at(self.player.col + dx, self.player.row + dy) or {}

    def _open_shop(self, shop_id: str) -> None:
        """Push a shop on top of this scene (D-571)."""
        # Local import, as with the menu and the battle below.
        from core.scenes.shop_scene import ShopScene

        self.gm.audio.play("menu_select")
        self.gm.scene_stack.push(ShopScene(self.gm, shop_id))

    def _rest(self) -> None:
        """Drink from the pond: everyone back to full HP, the fallen back up (D-525)."""
        for member in self.gm.party.members:
            member.current_hp = member.max_hp
        self.gm.audio.play("hit_sparkle_1")
        self.text_box.push("The party drinks from the cool pond. Everyone is rested.")

    def update(self, dt: float) -> None:
        """Tick the text box, then advance the player if no text is showing.

        After advancing the player, any newly-completed steps roll for
        a random encounter; on a hit a ``BattleScene`` is pushed on
        top of this scene. The overworld resumes automatically when
        the battle pops, since this scene was never destroyed.

        Args:
            dt: Frame time in seconds.
        """
        self.text_box.update(dt)
        if not self.text_box.is_done():
            return
        self._place_monsters()
        self.player.update(dt)
        self._place_monsters()
        self._grace = max(0.0, self._grace - dt)
        for monster in self.monsters:
            taken = set().union(*(m.tiles() for m in self.monsters if m is not monster))
            if self._grace > 0:
                # The monster left standing waits for the party to walk off.
                taken.add((self.player.col, self.player.row))
            monster.update(dt, self.world, taken)
        if self._grace <= 0:
            for monster in self.monsters:
                if (self.player.col, self.player.row) in monster.tiles():
                    self._start_fight(monster)
                    return

    def _place_monsters(self) -> None:
        """Put the cell's monsters out when the party arrives in a cell (D-576)."""
        if self._monsters_cell == self.world.current_pos:
            return
        self._monsters_cell = self.world.current_pos
        self._grace = 0.0
        kinds = self.gm.data.load("field_monsters")
        self.monsters = [
            FieldMonster(spot, kinds[spot["kind"]])
            for spot in FIELD_MONSTERS.get(self.world.current_cell_name, [])
            if not (spot.get("boss") and self.gm.party.flags.get(
                _boss_flag_for(self.world.current_cell_name, spot)
            ))
        ]

    def _start_fight(self, monster: FieldMonster) -> None:
        """Push the fight ``monster`` brings, and remember whose it is."""
        # Local import: ``BattleScene`` lives in a sibling scene file
        # and importing it at the top would risk a cycle the moment a
        # battle ever needs to read overworld state on the way out.
        from core.scenes.battle_scene import BattleScene, compose_fight

        battle = BattleScene(self.gm, enemies=compose_fight(monster.kind))
        self._fighting = (monster, battle)
        self.gm.scene_stack.push(battle)

    def render(self, surface: pygame.Surface) -> None:
        """Paint background, cell tiles, player, and message box in that order.

        Args:
            surface: The screen surface to draw onto.
        """
        render_scene_background(self, surface)
        self._render_cell(surface)
        self._render_people(surface)
        for monster in self.monsters:
            monster.render(surface)
        self.player.render(surface)
        self.text_box.render(surface)

    # ------------------------------------------------------------------
    # INTERNAL HELPERS
    # ------------------------------------------------------------------

    def _render_cell(self, surface: pygame.Surface) -> None:
        """Draw the active cell's tile grid, one picture per tile.

        Args:
            surface: The screen surface to draw onto.
        """
        grid = self.world.current_grid
        tile_size = GridSettings.TILE_SIZE
        tiles = _tiles()
        floor = OverworldSettings.FLOOR_CHAR
        for row in range(OverworldSettings.ROWS):
            row_cells = grid[row]
            for col in range(OverworldSettings.COLS):
                char = row_cells[col]
                x = OverworldSettings.X + col * tile_size
                y = OverworldSettings.Y + row * tile_size
                if not tiles:
                    color = _TILE_COLORS.get(char, ColorSettings.OVERWORLD_FLOOR)
                    pygame.draw.rect(surface, color, (x, y, tile_size, tile_size))
                    continue
                under = OverworldSettings.TILE_UNDER.get(char)
                if under is not None:
                    surface.blit(_pick(tiles[under], col, row), (x, y))
                surface.blit(_pick(tiles.get(char, tiles[floor]), col, row), (x, y))

    def _render_people(self, surface: pygame.Surface) -> None:
        """Draw everyone standing in the cell, in their standing frame."""
        tile_size = GridSettings.TILE_SIZE
        column = OverworldPlayerSettings.SHEET_COLUMNS
        for person in self.world.people:
            sheet = _person_sheet(person["sheet"])
            if sheet is None:
                continue
            frame = sheet.subsurface(pygame.Rect(
                column.get(tuple(person["facing"]), 0) * tile_size, 0, tile_size, tile_size,
            ))
            surface.blit(frame, (
                OverworldSettings.X + person["col"] * tile_size,
                OverworldSettings.Y + person["row"] * tile_size,
            ))

    def _open_menu(self) -> None:
        """Push the translucent system menu on top of this scene."""
        # Local import: ``MenuScene`` lives in a sibling scene module
        # and importing it at top of file would risk a cycle if the
        # menu ever pushes overworld-aware actions later.
        from core.scenes.menu_scene import MenuScene

        self.gm.scene_stack.push(MenuScene(self.gm))

    # ------------------------------------------------------------------
    # PERSISTENCE
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Serialise the active cell pointer and the player's tile state."""
        base = super().to_dict()
        base["world"] = self.world.to_dict()
        base["player"] = self.player.to_dict()
        return base

    @classmethod
    def from_dict(cls, gm: "GameManager", data: dict) -> "OverworldScene":
        """Rebuild a scene from a previously-saved dict.

        Args:
            gm: The host game manager.
            data: The dict previously returned by ``to_dict``.

        Returns:
            A fully-restored ``OverworldScene``.
        """
        scene = cls(gm)
        if isinstance(data, dict):
            world_data = data.get("world")
            if isinstance(world_data, dict):
                scene.world.from_dict(world_data)
            player_data = data.get("player")
            if isinstance(player_data, dict):
                scene.player.from_dict(player_data)
        return scene
