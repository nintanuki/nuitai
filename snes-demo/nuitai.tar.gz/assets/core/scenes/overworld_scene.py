"""The overworld — sprite walks a tile grid, message box at the bottom.

The Layer-3 destination scene, kicked off early so it can advance in
parallel with the Layer-1 text demo / battle polish. Owns three
collaborators: a ``World`` (cell layout + active-cell pointer), an
``OverworldPlayer`` (logical position + sprite animation + held-input
polling), and a ``TextBox`` (the existing widget, reused unchanged for
the bottom message panel).

What is and is not here in Pass 1:

* **Walking, cell transitions, save/load round-trip** — yes.
* **System-menu push on Tab / START** — yes (re-uses ``MenuScene``).
* **The pond (D-525), a market stall (D-571) and its keeper (D-574)** — face them and confirm.
* **The town's buildings** stand over the tiles and block; walking up into
  a door goes inside. A nap in Kailo's bed heals the party, as the pond does,
  and moves the date on a day (Frankie, 10/25); neither wakes the knocked out
  (Frankie, 10/26).
* **The place pop-up** (Frankie, 10/25): walking from one place into another
  (``systems/places.py``) shows its name in a small box at the top for a
  moment; walking out of his house after a nap, the date under it.
* **People with lines** say them when talked to (Melia, the villagers).
  Two villagers spar in town; standing next to one, facing them, for 30
  seconds with nothing pressed makes Kailo stronger and faster, once.
* **Saving** is only at an Akua totem (Frankie, 10/26): the party prays,
  the fallen get back up, and the game asks to save; YES opens the three
  slots. The menu has no Save.
* **Monsters on the map** (D-576): touching one starts its fight; no
  random encounters.
* **The field tools on Y** (Frankie, 10/26 to 10/28): a tap uses the tool
  set, holding Y opens the tool wheel (``ui/tool_wheel.py``). The ko'i chops
  a tree in the woods: ten chops fell it for ten wood and leave a stump, five
  more clear the stump for five more; not a border tree holding the room's
  edge, nor any in town. Each chop is a swing he stands still through, and
  the tree shakes. Y on anything a tool cannot work plays the "can't" sound.
  Monsters keep coming while he chops.
* **The demo's story** (the demo line in ``game/answers.md``): a new game
  opens on the taro patch scene; the Great Boar beaten, it is night; at
  night Kailo gives Melia the tusk, and walking into the chief's room then,
  Hina asks if they are ready for the wake, which ends the demo on
  TO BE CONTINUED. The scenes play over the field (``core/story.py``), acted out by
  the walking sprites where the script has stage directions
  (``core/staging.py``), the speaker's face beside their words; a scene
  can fade the screen to black and back, and wait a moment.
* **NPCs, dialogue triggers, signs, warp tiles** — Pass 2.
* **Animated walk cycle, real sprite art** — Pass 2.

The cell area draws one 16 pixel picture per tile, chosen by the cell
char (``OverworldSettings.TILE_PICTURES``), from Mini World Sprites.
Without the pictures a flat colour per char stands in.

See [docs/design/overworld.md](../../docs/design/overworld.md) for the
full design rationale.
"""

from __future__ import annotations

import os
import random
from typing import TYPE_CHECKING

import pygame

from core import generated, lore
from core.scene import Scene
from core.overworld_cells import BUILDINGS, FIELD_MONSTERS, INSIDE_ROW, PEOPLE, room_offset, warps
from core.shared import short_name
from core.staging import Stage
from core.story import LOSE, StoryRunner, cast, party_flag
from core.world import World, _in_village
from systems import bounties, dig, field_respawn, fishing, garden, hens, meal_orders, places, records, sailing, seaweed, stew, tools
from systems.passives import join_line
from entities.field_monster import FieldMonster
from entities.overworld_player import OverworldPlayer
from settings import (
    AssetPaths,
    AudioSettings,
    LanuSettings,
    BackgroundSettings,
    ColorSettings,
    CraftSettings,
    DigSettings,
    FieldMonsterSettings,
    FishingSettings,
    FontSettings,
    GardenSettings,
    GridSettings,
    HenSettings,
    ItemSettings,
    KaigaraSettings,
    MapSettings,
    OrderSettings,
    OverworldPlayerSettings,
    OverworldSettings,
    PlaceSettings,
    SailingSettings,
    ShopSettings,
    StewSettings,
    StorySettings,
    ToolSettings,
    TownSettings,
    TutorialSettings,
    UISettings,
)
from ui import edges, input_map, pier, shore, text_renderer, walls
from ui.text_box import TextBox, draw_continue_marker
from ui.reel_meter import render_reel
from ui.tool_wheel import ToolWheel, render_corner
from ui.window import draw_window
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager


# Stand-in colour per cell char, used when the tile pictures are missing.
_TILE_COLORS: dict[str, tuple[int, int, int]] = {
    OverworldSettings.FLOOR_CHAR: ColorSettings.OVERWORLD_FLOOR,
    OverworldSettings.WALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.STUMP_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.WATER_CHAR: ColorSettings.OVERWORLD_WATER,
    OverworldSettings.SPRING_CHAR: ColorSettings.OVERWORLD_WATER,
    OverworldSettings.SAND_CHAR: ColorSettings.OVERWORLD_SAND,
    OverworldSettings.STALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.MAT_CHAR: ColorSettings.OVERWORLD_SAND,
    OverworldSettings.INSIDE_WALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.VOID_CHAR: ColorSettings.BLACK,
    OverworldSettings.PIER_CHAR: ColorSettings.OVERWORLD_WALL,
}

# Tile pictures by cell char, loaded on first use. ``{}`` means the
# pictures were looked for and are missing.
_TILES: dict[str, list[pygame.Surface]] | None = None
_HOLE: pygame.Surface | bool | None = None


def _hole_picture() -> pygame.Surface | None:
    """The hole a dig leaves on sand, or None when its picture is missing."""
    global _HOLE
    if _HOLE is None:
        path = os.path.join(AssetPaths.TILES_DIR, DigSettings.HOLE_PICTURE)
        _HOLE = pygame.image.load(path).convert_alpha() if os.path.exists(path) else False
    return _HOLE or None


def _tiles() -> dict[str, list[pygame.Surface]]:
    """Return the choices of 16 pixel picture for each cell char."""
    global _TILES
    if _TILES is not None:
        return _TILES
    _TILES = {}
    size = GridSettings.TILE_SIZE
    sheets: dict[str, pygame.Surface] = {}
    for char, choices in OverworldSettings.TILE_PICTURES.items():
        pictures = []
        for name, index in choices:
            if name not in sheets:
                path = os.path.join(AssetPaths.TILES_DIR, name)
                if not os.path.exists(path):
                    _TILES = {}
                    return _TILES
                sheets[name] = pygame.image.load(path).convert_alpha()
            sheet = sheets[name]
            pictures.append(sheet.subsurface(pygame.Rect(
                (index * size) % sheet.get_width(),
                (index * size) // sheet.get_width() * size,
                size, size,
            )))
        _TILES[char] = pictures
    return _TILES


# Each person's walk sheet by name, loaded on first use; None if missing.
_PEOPLE: dict[str, pygame.Surface | None] = {}


def _person_sheet(name: str, file: str = "{}-Walk.png") -> pygame.Surface | None:
    """Return the Ninja Adventure walk sheet ``<name>-Walk.png``, or another of
    theirs (``file``: the Kaigara Kame's sitting one), or None."""
    file = file.format(name)
    if file not in _PEOPLE:
        path = os.path.join(AssetPaths.PEOPLE_DIR, file)
        _PEOPLE[file] = pygame.image.load(path).convert_alpha() if os.path.exists(path) else None
    return _PEOPLE[file]


# Each building's picture by kind, loaded on first use; None if missing.
_BUILDINGS: dict[tuple[str, bool], pygame.Surface | None] = {}


def building_picture(kind: str, opened: bool = False) -> pygame.Surface | None:
    """Return the picture for a kind of building (``OverworldSettings.BUILDINGS``), or None.

    ``opened`` gives an opened chest's picture, ``OverworldSettings.CHEST_OPEN``.
    """
    key = (kind, opened)
    if key not in _BUILDINGS:
        name = OverworldSettings.CHEST_OPEN if opened else OverworldSettings.BUILDINGS[kind][0]
        path = os.path.join(AssetPaths.BUILDINGS_DIR, name)
        _BUILDINGS[key] = pygame.image.load(path).convert_alpha() if os.path.exists(path) else None
    return _BUILDINGS[key]


def chest_flag(cell_name: str, chest: dict) -> str:
    """The party flag that marks a chest as opened, kept in the save."""
    return f"chest:{cell_name}:{chest['col']}:{chest['row']}"


def chest_items(chest: dict) -> list[str]:
    """What a chest holds, picked now: its ``item``, its ``also`` list, then
    ``random`` from ``ItemSettings.CHEST_RANDOM``, once or as many times as
    ``picks`` (low, high) rolls. "pule" is ``ItemSettings.CHEST_PULE`` pule."""
    from settings import ItemSettings

    items = ([chest["item"]] if chest.get("item") else []) + list(chest.get("also", []))
    if chest.get("random"):
        low, high = chest.get("picks", (1, 1))
        items += [random.choice(ItemSettings.CHEST_RANDOM[chest["random"]]) for _ in range(random.randint(low, high))]
    return items


def draw_tile(surface: pygame.Surface, grid, col: int, row: int, at: tuple[int, int],
              tiles: dict[str, list[pygame.Surface]]) -> None:
    """Draw one tile's picture at ``at``: water with its shore, an inside wall,
    the pier over the water, or the tile's own picture over what is under it."""
    char = grid[row][col]
    if char in shore.WATER:
        surface.blit(_pick(tiles.get(char, tiles[OverworldSettings.FLOOR_CHAR]), col, row), at)
        edges.draw_shallows(surface, grid, col, row, at)
        under_pier = pier.front(grid, col, row)
        if under_pier is not None:
            surface.blit(under_pier, at)
        return
    if char in walls.CHARS:
        surface.blit(walls.tile(grid, col, row), at)
        return
    if char == pier.CHAR:
        surface.blit(_pick(tiles[OverworldSettings.WATER_CHAR], col, row), at)
        edges.draw_shallows(surface, grid, col, row, at)
        surface.blit(pier.tile(grid, col, row), at)
        return
    under = OverworldSettings.TILE_UNDER.get(char)
    if under is not None:
        surface.blit(_pick(tiles[under], col, row), at)
        edges.draw_bank(surface, grid, col, row, at)
    surface.blit(_pick(tiles.get(char, tiles[OverworldSettings.FLOOR_CHAR]), col, row), at)
    if char == OverworldSettings.FLOOR_CHAR:
        edges.draw_bank(surface, grid, col, row, at)
    edges.draw(surface, grid, col, row, at)


def draw_rising(surface: pygame.Surface, building: dict, x0: int = 0, y0: int = 0) -> None:
    """Draw again the part of a building's picture above its own tiles, over
    whoever stands behind it: the Meialana's sail, a totem's top (10/27)."""
    picture = building_picture(building["kind"])
    if picture is None:
        return
    tile_size = GridSettings.TILE_SIZE
    height = OverworldSettings.BUILDINGS[building["kind"]][1][1]
    sink = OverworldSettings.SINK.get(building["kind"], 0)
    rising = picture.get_height() - height * tile_size - sink
    if rising > 0:
        top = y0 + (building["row"] + height) * tile_size + sink - picture.get_height()
        surface.blit(picture, (x0 + building["col"] * tile_size, top), pygame.Rect(0, 0, picture.get_width(), rising))


def draw_sunk(surface: pygame.Surface, grid, building: dict, x0: int = 0, y0: int = 0) -> None:
    """Draw again the pier's planks over the bottom of a building sunk below its tiles
    (``OverworldSettings.SINK``), so it is tucked behind them."""
    if not OverworldSettings.SINK.get(building["kind"]):
        return
    tile_size = GridSettings.TILE_SIZE
    width, height = OverworldSettings.BUILDINGS[building["kind"]][1]
    row = building["row"] + height
    if row >= len(grid):
        return
    for col in range(building["col"], building["col"] + width):
        if grid[row][col] == pier.CHAR:
            surface.blit(pier.tile(grid, col, row), (x0 + col * tile_size, y0 + row * tile_size))


def draw_building(surface: pygame.Surface, building: dict, x0: int = 0, y0: int = 0,
                  opened: bool = False) -> None:
    """Draw a building at its own size on its tiles, standing on their bottom edge.

    ``opened`` draws a chest open (Frankie, 10/25).
    """
    tile_size = GridSettings.TILE_SIZE
    width, height = OverworldSettings.BUILDINGS[building["kind"]][1]
    picture = building_picture(building["kind"], opened and building["kind"] == "chest")
    left, bottom = x0 + building["col"] * tile_size, y0 + (building["row"] + height) * tile_size
    if picture is None:
        pygame.draw.rect(surface, ColorSettings.OVERWORLD_WALL,
                         (left, bottom - height * tile_size, width * tile_size, height * tile_size))
        return
    surface.blit(picture, (left, bottom + OverworldSettings.SINK.get(building["kind"], 0) - picture.get_height()))


# Each plant's four garden pictures, loaded on first use; None if missing.
_PATCH_SHEETS: dict = {}


def _patch_sheet(plant: str) -> pygame.Surface | None:
    """Return a plant's strip of four pictures (GardenSettings.PICTURES), or None."""
    if plant not in _PATCH_SHEETS:
        path = os.path.join(AssetPaths.TILES_DIR, GardenSettings.PICTURES.get(plant, ""))
        _PATCH_SHEETS[plant] = pygame.image.load(path).convert_alpha() if os.path.isfile(path) else None
    return _PATCH_SHEETS[plant]


def _boss_flag_for(cell_name: str, spot: dict) -> str:
    """The party flag that marks a boss on the map as beaten for good."""
    return f"field_boss:{cell_name}:{spot['kind']}"


def _boss_flag(monster: FieldMonster) -> str:
    """The flag for ``monster``, a boss, in the cell it stands in."""
    for cell_name, spots in FIELD_MONSTERS.items():
        if monster.spot in spots:
            return _boss_flag_for(cell_name, monster.spot)
    return f"field_boss::{monster.spot['kind']}"


def _pick(pictures: list[pygame.Surface], col: int, row: int) -> pygame.Surface:
    """Pick one of ``pictures`` by tile position, the same every time."""
    return pictures[(col * 7 + row * 13 + col * row) % len(pictures)]


def start_in_room(gm: "GameManager", name: str | None, col: int | None = None,
                  row: int | None = None, checkpoint: str | None = None) -> bool:
    """Skip the title: a fresh party standing in room ``name``, on ``(col, row)``.

    How the Workshop's Play button starts the game (``main.py --room``).
    With ``checkpoint``, the party and the story are that checkpoint's
    (core/save.py) instead of a fresh party's, and without ``name`` it
    starts where the checkpoint stood. Returns False, leaving the title
    up, when there is no such room or checkpoint.
    """
    # Local import: the title imports this module.
    from core import save
    from core.overworld_cells import WORLD_LAYOUT
    from core.scenes.save_slot_scene import resume
    from core.scenes.title_scene import build_default_party

    pos = next((pos for pos, who in WORLD_LAYOUT.items() if who == name), None)
    if name is not None and pos is None:
        return False
    if checkpoint is not None:
        try:
            data = save.load_checkpoint(checkpoint)
        except (OSError, ValueError):
            return False
        resume(gm, data)
        scene = gm.scene_stack.top
    else:
        gm.party = build_default_party()
        scene = OverworldScene(gm)
        gm.scene_stack.replace(scene)
    if pos is not None:
        scene.world.go_to(pos)
    if col is not None and row is not None:
        scene.player.from_dict({"col": int(col), "row": int(row)})
    return True


class OverworldScene(Scene):
    """The screen-locked, cell-based overworld."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Construct the overworld with its world, player, and text box.

        Args:
            gm: The host game manager. Provides audio, save, and
                cross-scene navigation routing.
        """
        super().__init__(gm)
        self.world = World()
        self.player = OverworldPlayer(gm, self.world)
        # Cell area is narrower than the screen, so size the text box
        # to the full screen width but keep the existing 160-px height.
        self.text_box = TextBox(flippable=True)
        # The monsters in the cell (D-576), placed afresh on every entry.
        self.monsters: list[FieldMonster] = []
        self._monsters_cell: tuple[int, int] | None = None
        # The monster whose fight is on, and how long until a monster
        # left standing by a fight can start another.
        self._fighting: tuple[FieldMonster, object] | None = None
        self._grace = 0.0
        # The demo is over: the words on the black screen, and the title on confirm.
        self._card: str | None = None
        # The Great Boar asks before his fight (Frankie, 10/23): the one asking,
        # whether he has asked since the party walked up, and the steps back
        # still to walk after "Go back".
        self._asking: FieldMonster | None = None
        # Whether Hina has asked about the wake since the party walked into the chief's room.
        self._wake_asked = False
        self._asked = False
        # Where Kailo last bumped (room, tile, facing), so a dead end speaks once a walk-up.
        self._bumped_at: tuple | None = None
        self._walk_back: list[tuple[int, int]] = []
        # A shop pushed by a person who may join (Maika): who, and what the
        # bag held when it opened, so closing it can tell if anything was bought.
        self._joiner_shop: tuple[dict, dict] | None = None
        # What to open once the text box closes.
        self._after_text = None
        # The sparring villagers: how long nothing has been pressed.
        self._idle = 0.0
        # The story scene playing, the step it waits to show once the text
        # box closes, and the fight it started.
        self.story: StoryRunner | None = None
        self._story_next: dict | None = None
        self._story_fight = None
        # The scene acted out on the map, once its script names a Room.
        self.stage: Stage | None = None
        # The screen's darkness, 0 to 1, where a Fade is taking it, and a Wait's seconds left.
        self._dark = 0.0
        self._fade_to: float | None = None
        self._wait = 0.0
        # A new game opening: the field starts black and lights as the first line types.
        self._opening = False
        # The scene being skipped from the pause (skip_cutscene), None while none is.
        self.skipping: StoryRunner | None = None
        # Where the player stood last frame, to count the garden's steps.
        self._last_tile: tuple | None = None
        # What a room smaller than the screen is drawn on before it is moved to the middle.
        self._room_layer: pygame.Surface | None = None
        # The room this visit is in, so leaving it can send Melia home.
        self._visiting = self.world.current_cell_name
        # The room the place pop-up last looked at (None until the first frame,
        # which shows nothing), the place it was in, and the pop-up's lines and
        # seconds left.
        self._place_room: str | None = None
        self._place: str | None = None
        self.popup: list[str] | None = None
        self._popup_left = 0.0
        # Y: the tool wheel, the tree or stump being chopped (room, col, row)
        # and its chops so far, the seconds left of the swing Kailo is in, and
        # the tile shaking from the last chop with its seconds left.
        self.tool_wheel = ToolWheel()
        self._chop_at: tuple | None = None
        self._chops = 0
        self._swing = 0.0
        self._shake: tuple | None = None
        self._shake_left = 0.0
        # Fishing (Frankie, 10/28; built small for the stew, 10/30): the line out, as
        # [where Kailo stands, seconds to the bite, seconds the bite lasts, baited], or None.
        self._line: list | None = None
        # A hooked fish being reeled in (Frankie, 11/2; ``fishing.Reel``), or None.
        self._reel: fishing.Reel | None = None
        # Digging (Frankie, 10/30): the tiles dug in this room, gone when he leaves it.
        self._dug: set = set()
        self._dug_room: str | None = None
        # Water drawn in a row, and the seconds since the last draw (Frankie, 10/28).
        self._draws = 0
        self._since_draw = 0.0
        self._sync_joined()

    def on_enter(self) -> None:
        """Play the room's sound, and settle the fight just over, if one was.

        The sound carries on if it is already playing (back from the
        menu). A monster beaten in its fight leaves the map, a boss for
        good, any other until ``RESPAWN_STEPS`` steps are walked or the
        party naps or drinks from a spring (Frankie, 10/28); one that was run from or lost to stays, and waits a moment
        before it can start another (D-576).
        """
        # Y let go on the screen just closed never reached here: the wheel starts shut.
        self.tool_wheel.cancel()
        # The fight settled first, so a won fight's Song is over before the room's song comes back.
        if self._story_fight is not None:
            battle, self._story_fight = self._story_fight, None
            self.story.fought(battle.battle.outcome == "victory")
        self._room_sound()
        self._sync_joined()
        if self._joiner_shop is not None:
            person, before = self._joiner_shop
            self._joiner_shop = None
            self._after_joiner_shop(person, before)
        if self._fighting is None:
            return
        monster, battle = self._fighting
        self._fighting = None
        if battle.battle.outcome == "victory":
            if monster in self.monsters:
                self.monsters.remove(monster)
            if not monster.spot.get("boss"):
                # Back after RESPAWN_STEPS steps, or a nap or a spring (Frankie, 10/28).
                spots = FIELD_MONSTERS.get(self.world.current_cell_name, [])
                index = next((i for i, spot in enumerate(spots) if spot is monster.spot), None)
                if index is not None:
                    field_respawn.beat(self.gm.party, self.world.current_cell_name, index)
            if monster.spot.get("boss"):
                self.gm.party.flags[_boss_flag(monster)] = True
                # The Great Boar beaten, they talk, and it is night once the stew is made too
                # (the demo line, 10/23; the stew gates the night, Frankie, 10/30).
                self.gm.party.flags[StorySettings.BOAR_BEATEN_FLAG] = True
                if stew.made(self.gm.party):
                    self.gm.party.flags[StorySettings.NIGHT_FLAG] = True
                self._sync_joined()
                self.begin_story(StorySettings.FALL_SCENE)
        # A breather after any fight, won too (Frankie, 10/27): the next monster
        # waits, and presses meant for the victory screen start nothing.
        self._grace = FieldMonsterSettings.GRACE_SECONDS

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Route one event.

        When the text box has content, confirm advances it and other
        keys fall through silently (so a held direction won't queue
        steps that fire the instant the player closes a dialogue).
        Otherwise, X (Tab) pushes the field menu; movement is
        polled inside ``player.update`` and does not go through this
        handler.

        Args:
            event: The pygame event to route.
        """
        if event.type in (pygame.KEYDOWN, pygame.JOYBUTTONDOWN, pygame.JOYHATMOTION):
            self._idle = 0.0
        # Reeling a fish in, the d-pad is the reel and nothing else answers.
        if self._reel is not None:
            self.tool_wheel.cancel()
            return
        # Mid-swing, Y does nothing: no mashing (Frankie, 10/28).
        if self._swing > 0 and (input_map.is_tool(event) or input_map.is_tool_up(event)):
            self.tool_wheel.cancel()
            return
        # Letting go of Y: a tap uses the set tool, a hold sets the one picked on the wheel.
        if input_map.is_tool_up(event):
            if self._card is not None or not self.text_box.is_done() or self.story is not None:
                self.tool_wheel.cancel()
            elif self.tool_wheel.release(self.gm.party) == "use":
                self._use_tool()
            return
        if self.tool_wheel.open:
            return
        if self._card is not None:
            if input_map.is_confirm(event):
                self.gm.return_to_title()
            return
        if not self.text_box.is_done():
            if input_map.is_textbox_flip(event):
                TextBox.flip()
            elif input_map.is_confirm(event):
                self.text_box.advance()
            return
        # The story playing takes every key until its text box closes.
        if self.story is not None:
            return
        if input_map.is_l1(event) or input_map.is_r1(event):
            self._swap_walker(-1 if input_map.is_l1(event) else 1)
            return
        if input_map.is_tool(event):
            self.tool_wheel.press(self.gm.party)
            return
        if input_map.is_confirm(event) and self._faced_patch() is not None:
            self._tend(self._faced_patch())
            return
        if input_map.is_confirm(event) and self._faced_building() == "pot":
            self._open_pot()
            return
        if input_map.is_confirm(event) and self._faced_look():
            self._look(self._faced_look())
            # The log yard's Pōhaku does not wake on the first talk, only its lines, and Kailo can walk away;
            # touching it again (A on it) plays the lines and then wakes it (Frankie, 10/28). The warning is a
            # party flag, so it is in the save, and like a chest's flag it never resets.
            dx, dy = self.player.facing
            stone = self.world.building_at(self.player.col + dx, self.player.row + dy)
            if stone and stone.get("wakes"):
                warned = f"warned:{self.world.current_cell_name}:{stone['col']}:{stone['row']}"
                if self.gm.party.flags.get(warned):
                    self._after_text = lambda: self._wake_stone(stone)
                else:
                    self.gm.party.flags[warned] = True
            # The Meialana: after Kailo's line, cook or nap aboard (Frankie, 10/28).
            if stone and stone.get("galley"):
                self._after_text = self._boat_menu
            # Lanu's post in the grove: with water in the bag, leave her a cup (Frankie, 11/3).
            if stone and stone.get("offering") and self.gm.party.inventory.get(ItemSettings.WATER) \
                    and self.gm.party.flags.get(LanuSettings.CUPS_FLAG, 0) < LanuSettings.CUPS:
                from core.scenes.confirm_scene import ConfirmScene  # local, as the menus nearby
                self._after_text = lambda: self.gm.scene_stack.push(
                    ConfirmScene(self.gm, LanuSettings.ASK, on_yes=self._offer_water))
            return
        if input_map.is_confirm(event) and self._faced_building() == KaigaraSettings.TABLE:
            self._talk_to_kame()
            return
        if input_map.is_confirm(event) and self._faced_building() == "chest":
            self._open_chest()
            return
        # An Akua totem: pray, the fallen get up, then save (Frankie, 10/26).
        if input_map.is_confirm(event) and self._faced_building() == "totem":
            self._pray()
            return
        if input_map.is_confirm(event) and self._facing_shut_door():
            self._say_shut_door()
            return
        # Kailo's bed in his house: a nap rests the party (Frankie, 10/23).
        # Anyone else's, Hina scolds (Frankie, 10/25).
        if input_map.is_confirm(event) and self._faced_building() == "bed":
            dx, dy = self.player.facing
            bed = self.world.building_at(self.player.col + dx, self.player.row + dy)
            if bed.get("inn"):
                self._ask_inn()
            elif bed.get("owner") == TownSettings.OWN_BED:
                self._ask_nap()
            else:
                self._not_your_bed(bed)
            return
        # Facing the pond, confirm rests there; facing a stall, it opens
        # the shop; on empty ground it does nothing (X opens the menu).
        if input_map.is_confirm(event) and self._facing(OverworldSettings.SPRING_CHAR):
            self._rest()
            return
        # Fresh water, from the river or a pool, goes in the bag: poi is taro and water (Frankie, 10/28).
        if input_map.is_confirm(event) and self._facing_fresh_water():
            self._scoop_water()
            return
        if input_map.is_confirm(event) and (self._facing(OverworldSettings.STALL_CHAR)
                                            or self._faced_building() in OverworldSettings.SHOP_BUILDINGS
                                            or self._faced_building() == "sign"):
            # A stall is its keeper's: whoever in the room keeps a shop.
            keeper = next((p for p in self.world.people if p.get("shop")), None)
            away = next((p for p in PEOPLE.get(self.world.current_cell_name, [])
                         if p.get("shop") and not p.get("joins")), None)
            if keeper is None and away is not None and self.is_night():
                self._read_sign(away["shop"])
            elif keeper is not None and keeper.get("joins"):
                self._talk_to_joiner(keeper)
            elif keeper is not None:
                self._open_shop(keeper["shop"])
            else:
                self._joined_keeper_shop()
            return
        # The sea: now and then seaweed washes up (Frankie, 10/29).
        if input_map.is_confirm(event) and self._facing(OverworldSettings.WATER_CHAR) \
                and self.world.current_cell_name in CraftSettings.SALT_ROOMS:
            self.text_box.push(seaweed.search(self.gm.party))
            return
        # A hen: her egg, if she has one (Frankie, 10/28).
        if input_map.is_confirm(event) and self._faced_person().get("hen"):
            self.text_box.push(hens.collect(self.gm.party, self._person_key(self._faced_person())))
            return
        # Whoever Kailo talks to turns to face him (Frankie, 10/23).
        was_facing = None
        if input_map.is_confirm(event) and self._faced_person():
            was_facing = self._turn_to_player(self._faced_person())
        if input_map.is_confirm(event) and self._faced_person().get("night") and self.is_night():
            self._talk_at_night(self._faced_person())
            return
        # An innkeeper: her line, then the night's price (Kupulau's inn, Frankie, 11/3).
        if input_map.is_confirm(event) and self._faced_person().get("inn"):
            person = self._faced_person()
            self._take_turn(person, "day", person["lines"])
            self._after_text = lambda: self._ask_inn(person)
            return
        # Ama gives Kailo the Old Rod, once (Frankie, 10/28: she gives it in a scene at the harbor;
        # the scene is not built, so this is Claude's stand-in, 10/30).
        gift = self._faced_person().get("gift") if input_map.is_confirm(event) else None
        # It comes on the second talk (``when``, the flag the first sets, Frankie's draft 11/2), once the
        # stew is a quest (``needs``; the opening is over), so the fish can be caught. After the jump
        # there is no first talk any more, so that counts as having talked.
        flags = self.gm.party.flags if self.gm.party else {}
        if gift and (flags.get(gift["when"]) or flags.get(StorySettings.AFTER_JUMP_FLAG))                 and flags.get(gift.get("needs", gift["when"])) and not flags.get(gift["flag"]):
            self.gm.party.flags[gift["flag"]] = True
            tools.take(self.gm.party, gift["item"])
            for line in gift["lines"]:
                self.text_box.push(line, speaker=self._faced_person()["speaker"])
            self.gm.audio.play("chest_open")
            self.text_box.push(f"Kailo received {ItemSettings.NAMES[gift['item']]}.")
            return
        # A keeper who does more than sell (Frankie, 11/3): Ama in his Bait & Tackle, the
        # priest in Kulaiwi's temple. Their ``menu`` asks what Kailo wants, each row an action.
        if input_map.is_confirm(event) and self._faced_person().get("menu"):
            self._keeper_menu(self._faced_person())
            return
        # Ama and the boat, the morning after the jump (Frankie, 10/28 and 10/31).
        if (input_map.is_confirm(event) and self._faced_person().get("boat") and self.gm.party
                and self.gm.party.flags.get(StorySettings.AFTER_JUMP_FLAG)):
            self._talk_ama_boat(self._faced_person()["speaker"])
            return
        # Someone who asks for a dish and gives something for it (the widow, Frankie, 10/30).
        request = self._faced_person().get("request") if input_map.is_confirm(event) else None
        if request and self.gm.party:
            self._talk_requester(self._faced_person(), request)
            return
        # Noelani, while the stew is wanted: the quest (Frankie, 10/30).
        if input_map.is_confirm(event) and self._faced_person().get("stew") and self.gm.party                 and self.gm.party.flags.get(StewSettings.QUEST_FLAG) and not self.is_night() \
                and not self.gm.party.flags.get(StorySettings.AFTER_JUMP_FLAG):
            self._talk_noelani(self._faced_person())
            return
        # Hina at home: talking to her plays her scene, and she joins (Frankie, 10/23).
        if input_map.is_confirm(event) and self._faced_person().get("scene"):
            self.begin_story(self._faced_person()["scene"])
            return
        if input_map.is_confirm(event) and self._faced_person().get("joins"):
            self._talk_to_joiner(self._faced_person())
            return
        if input_map.is_confirm(event) and self._faced_person().get("sister"):
            self._talk_to_sister(self._faced_person())
            return
        # The Lanu sage, once Kailo has left her enough cups: Hina's Revive (Frankie, 11/3).
        if input_map.is_confirm(event) and self._faced_person().get("blessing") \
                and self.gm.party.flags.get(LanuSettings.CUPS_FLAG, 0) >= LanuSettings.CUPS \
                and not self.gm.party.flags.get(LanuSettings.BLESSED_FLAG):
            person = self._faced_person()
            self.gm.party.flags[LanuSettings.BLESSED_FLAG] = True
            for line in LanuSettings.BLESSING:
                self.text_box.push(line, speaker=person["speaker"])
            self.gm.party.inventory[LanuSettings.GIFT] = 1
            self.gm.audio.play("chest_open")
            self.text_box.push(f"Kailo received {ItemSettings.NAMES[LanuSettings.GIFT]}.")
            return
        # A loremaster, or the boy who explains the game: his questions after his first line,
        # the one that offers them (Frankie, 10/25); his other lines take turns with it.
        if input_map.is_confirm(event) and self._faced_person().get("ask"):
            person = self._faced_person()
            # The menu follows the first line said (the intro before it, played once, counts as one).
            first = next((i for i, line in enumerate(person["lines"]) if not isinstance(line, dict)), 0)
            if self._take_turn(person, "day", person["lines"]) in (0, first):
                self._after_text = lambda: self._ask_menu(person)
            return
        # Melia, hiding the first time: the three of them, then one line a talk (Frankie, 10/25).
        if input_map.is_confirm(event) and self._faced_person().get("talk") and not self._faced_person().get("talked"):
            person = self._faced_person()
            person["talked"] = True
            if person.get("first") and self.gm.party:
                self.gm.party.flags[person["first"]["flag"]] = True
            for speaker, line in person["talk"]:
                self.text_box.push(line, speaker=speaker)
            return
        # The Kame in the hunters' lodge: a game of Kaigara (Frankie, 10/26).
        if input_map.is_confirm(event) and self._faced_person().get("kaigara"):
            self._talk_to_kame()
            return
        if input_map.is_confirm(event) and self._faced_person().get("lines"):
            person = self._faced_person()
            self._say_lines(person)
            if person.get("spar"):
                # A sparring villager goes back to the fight once done talking.
                self._after_text = lambda: person.__setitem__("facing", was_facing)
            return
        # The hunters' lodge's keeper: a bounty to pay out first, then the shop or the bounty board.
        if input_map.is_confirm(event) and self._faced_person().get("bounties"):
            self._lodge_keeper(self._faced_person())
            return
        if input_map.is_confirm(event) and self._faced_person().get("shop"):
            self._open_shop(self._faced_person()["shop"])
            return
        if input_map.is_menu(event):
            self._open_menu()
        elif input_map.is_select(event):
            self._open_map()

    def _use_tool(self) -> None:
        """A tap of Y: the set tool works what Kailo faces, or the "can't" sound (Frankie, 10/26)."""
        if tools.current(self.gm.party) == "chop" and self._sacred_tree() is not None:
            self._scold_chop(self._sacred_tree())
            return
        if tools.current(self.gm.party) == "chop" and self._faced_tree() is not None:
            self._chop(self._faced_tree())
            return
        if tools.current(self.gm.party) == "fish" and self._facing(OverworldSettings.WATER_CHAR):
            self._fish()
            return
        if tools.current(self.gm.party) == "dig":
            self._dig()
            return
        self._chop_at, self._chops = None, 0
        self.gm.audio.play("cant")

    def _dig(self) -> None:
        """A tap of Y with the 'O'o (Frankie, 10/27 and 10/30): dig the sand he faces; a spot
        gives 'awapuhi, anywhere else a random goodie; the village yells instead; never grass."""
        cell = self.world.current_cell_name
        dx, dy = self.player.facing
        col, row = self.player.col + dx, self.player.row + dy
        tile = self.world.tile_at(col, row)
        if tile not in (OverworldSettings.SAND_CHAR, OverworldSettings.FLOOR_CHAR)                 or self.world.building_at(col, row) is not None or self.world.person_at(col, row):
            self.gm.audio.play("cant")
            return
        if _in_village(cell):
            self.text_box.push(DigSettings.VILLAGE_LINE)
            return
        if tile == OverworldSettings.FLOOR_CHAR:
            self.text_box.push(DigSettings.GRASS_LINE)
            return
        if cell != self._dug_room:
            self._dug, self._dug_room = set(), cell
        self._swing = DigSettings.SWING_SECONDS
        if (col, row) in self._dug:
            self.text_box.push(DigSettings.AGAIN_LINE)
            return
        self._dug.add((col, row))
        had = self.gm.party.inventory.get(DigSettings.BURIED, 0)
        line, found = dig.dig(self.gm.party, cell, col, row)
        self.gm.audio.play("dig")
        if dig.found_important(self.gm.party, had):
            self.gm.audio.play(DigSettings.FOUND_SOUND)
        self.text_box.push(line)

    def _fish(self) -> None:
        """A tap of Y with the rod, facing water (Frankie, 10/28): the first casts the line, baited
        while Kailo carries any bait (Frankie, 11/2); a tap while something is biting hooks
        it, and one before reels the line in, no fish. A hooked fish starts the reel."""
        if self._line is None:
            baited = fishing.has_bait(self.gm.party)
            wait = random.uniform(*(FishingSettings.BITE_WAIT if baited else FishingSettings.BITE_WAIT_NO_BAIT))
            self._line = [(self.world.current_pos, self.player.col, self.player.row), wait, 0.0, baited]
            self.gm.audio.play("menu_select")
            return
        if self._line[2] > 0:
            kind = fishing.roll(self._line[3])
            if kind in ("fish", "rare"):
                self._reel = fishing.Reel(fishing.hook(kind, self.gm.party))
                self.gm.audio.play("blip")
                return
            self._line = None
            line = fishing.land(self.gm.party, kind)
            self.gm.audio.play("cant" if line == FishingSettings.MISS_LINE else "hit_sparkle_1")
            self.text_box.push(line)
            return
        self._line = None
        self.gm.audio.play("cant")

    def _tick_reel(self, dt: float) -> None:
        """Reeling (Frankie, 11/2): each quarter turn of the d-pad the same way fills the meter;
        full lands the catch, and a fish eats one bait if the hook was baited; drained or out of time
        and it gets away, the bait still on (Frankie, 11/2)."""
        held = input_map.read_held_direction(self.gm.connected_joysticks)
        if self._reel.press(held):
            self.gm.audio.play("menu_move")
        result = self._reel.tick(dt)
        if result is None:
            return
        item, baited = self._reel.item, self._line[3]
        self._reel, self._line = None, None
        self.gm.party.flags[FishingSettings.REEL_HINT_FLAG] = True
        if result == "caught":
            self.gm.audio.play("hit_sparkle_1")
            if baited and item in ItemSettings.FISH:
                fishing.spend_bait(self.gm.party)
            self.text_box.push(fishing.catch(self.gm.party, item))
        else:
            self.gm.audio.play("cant")
            self.text_box.push(FishingSettings.ESCAPED_LINE)

    def _tick_fishing(self, dt: float) -> None:
        """The line out: the bite comes after its wait and lasts a moment, then the fish is gone.
        Walking off reels it in."""
        if self._reel is not None:
            self._tick_reel(dt)
            return
        if self._line is None:
            return
        here = (self.world.current_pos, self.player.col, self.player.row)
        if here != self._line[0]:
            self._line = None
        elif self._line[1] > 0:
            self._line[1] -= dt
            if self._line[1] <= 0:
                self._line[2] = FishingSettings.BITE_WINDOW
                self.gm.audio.play("blip")
        elif self._line[2] > 0:
            self._line[2] -= dt
            if self._line[2] <= 0:
                self._line = None
                self.text_box.push(FishingSettings.MISS_LINE)

    def _faced_tree(self) -> tuple | None:
        """The tree or stump Kailo faces, as (room, col, row), if the ko'i can chop it, else None.

        Any tree in the woods (Frankie, 10/26): not one along the room's edge,
        which holds the map in, and none in town.
        """
        cell = self.world.current_cell_name
        dx, dy = self.player.facing
        col, row = self.player.col + dx, self.player.row + dy
        grid = self.world.current_grid
        if (self.world.tile_at(col, row) not in (OverworldSettings.WALL_CHAR, OverworldSettings.STUMP_CHAR)
                or self.world.building_at(col, row) is not None
                or _in_village(cell)
                or not (0 < row < len(grid) - 1 and 0 < col < len(grid[row]) - 1)):
            return None
        return (cell, col, row)

    def _sacred_tree(self) -> str | None:
        """What makes the tree Kailo faces off limits (Frankie, 11/3): "banyan" for a banyan
        anywhere, "grove" for any tree or stump in Lanu's grove, else None."""
        dx, dy = self.player.facing
        col, row = self.player.col + dx, self.player.row + dy
        building = self.world.building_at(col, row)
        if building is not None and building["kind"] == "banyan":
            return "banyan"
        if self.world.current_cell_name == ToolSettings.GROVE and building is None \
                and self.world.tile_at(col, row) in (OverworldSettings.WALL_CHAR, OverworldSettings.STUMP_CHAR):
            return "grove"
        return None

    def _scold_chop(self, why: str) -> None:
        """Hina scolds Kailo for raising the ko'i at a sacred tree; Maika with her away; alone,
        Kailo thinks better of it (Frankie, 11/3)."""
        party = self.gm.party
        speaker = next((name for name in ("Hina", "Maika") if party.find(name.lower()) is not None),
                       StorySettings.PLAYER)
        grove, banyan = ToolSettings.SACRED_SCOLD[speaker]
        self._chop_at, self._chops = None, 0
        self.text_box.push(grove if why == "grove" else banyan, speaker=speaker)

    def _chop(self, tree: tuple) -> None:
        """One chop at ``tree`` (Frankie, 10/28): a swing Kailo is stuck in, and the tree shakes.

        The tenth in a row fells a tree to its stump, the fifth clears the
        stump to grass, each for its wood.
        """
        if tree != self._chop_at:
            self._chop_at, self._chops = tree, 0
        _, col, row = tree
        self._chops += 1
        self._swing = ToolSettings.SWING_SECONDS[tools.best(self.gm.party, "chop")]
        self._shake, self._shake_left = (col, row), ToolSettings.SHAKE_SECONDS
        self.gm.audio.play("chop")
        stump = self.world.tile_at(col, row) == OverworldSettings.STUMP_CHAR
        if self._chops < (ToolSettings.STUMP_CHOPS if stump else ToolSettings.CHOPS):
            return
        # Felled: the tree is a stump, the stump grass, until Kailo leaves the room.
        self._chops, self._shake = 0, None
        self.world.current_grid[row][col] = OverworldSettings.FLOOR_CHAR if stump else OverworldSettings.STUMP_CHAR
        wood = ToolSettings.WOOD_PER_STUMP if stump else ToolSettings.WOOD_PER_TREE
        bag = self.gm.party.inventory
        bag["wood"] = bag.get("wood", 0) + wood
        self.text_box.push(ToolSettings.WOOD_LINE.format(count=wood))
        # Niu only comes from chopping trees (Frankie, 10/30): its own chance on a felled trunk.
        if not stump and random.random() < ItemSettings.NIU_DROP_CHANCE:
            bag[ItemSettings.NIU] = bag.get(ItemSettings.NIU, 0) + 1
            self.text_box.push(ToolSettings.FRUIT_LINE.format(item=ItemSettings.NAMES[ItemSettings.NIU]))
        if not stump and random.random() < ItemSettings.TREE_DROP_CHANCE:
            fruit = random.choice(ItemSettings.TREE_DROPS)
            bag[fruit] = bag.get(fruit, 0) + 1
            line = ToolSettings.ROOT_LINE if fruit == "awa_root" else ToolSettings.FRUIT_LINE
            self.text_box.push(line.format(item=ItemSettings.NAMES[fruit]))

    def _facing_fresh_water(self) -> bool:
        """Whether the player faces water that is not the sea: the river or a pool (Frankie, 10/28)."""
        return (self._facing(OverworldSettings.WATER_CHAR)
                and self.world.current_cell_name not in CraftSettings.SALT_ROOMS)

    def _scoop_water(self) -> None:
        """One water in the bag, free (Frankie, 10/28); after ten in a row the canteens
        are heavy and he rests a little before the next (Frankie, 10/28)."""
        bag = self.gm.party.inventory
        if self._since_draw >= CraftSettings.WATER_REST:
            self._draws = 0
        if bag.get(ItemSettings.WATER, 0) >= CraftSettings.WATER_MAX:
            self.text_box.push(CraftSettings.FULL_LINE)
            return
        if self._draws >= CraftSettings.WATER_STREAK:
            self.text_box.push(CraftSettings.REST_LINE, speaker=StorySettings.PLAYER)
            return
        self._draws += 1
        self._since_draw = 0.0
        bag[ItemSettings.WATER] = bag.get(ItemSettings.WATER, 0) + 1
        self.gm.audio.play("menu_select")
        self.text_box.push(CraftSettings.WATER_LINE)
        if self._draws == CraftSettings.WATER_STREAK:
            self.text_box.push(CraftSettings.HEAVY_LINE, speaker=StorySettings.PLAYER)

    def _person_key(self, person: dict) -> str:
        """A name for ``person`` that lasts across visits and saves: their room and place in its file."""
        cell = self.world.current_cell_name
        for index, original in enumerate(PEOPLE.get(cell, [])):
            if self.world.turns.get(id(original)) is person.get("turn"):
                return f"{cell}:{index}"
        return f"{cell}:{person.get('speaker')}"

    def _facing(self, char: str) -> bool:
        """Whether the tile the player faces is ``char``: the pond (D-525), a stall (D-571)."""
        dx, dy = self.player.facing
        return self.world.tile_at(self.player.col + dx, self.player.row + dy) == char

    def at_save_point(self) -> bool:
        """Whether the party stands on a tile next to an Akua totem (Frankie, 10/26)."""
        for dx, dy in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            building = self.world.building_at(self.player.col + dx, self.player.row + dy)
            if building and building["kind"] == "totem":
                return True
        return False

    def _faced_look(self) -> list:
        """The ``look`` lines of the building the player faces (a lore hint), or none."""
        dx, dy = self.player.facing
        building = self.world.building_at(self.player.col + dx, self.player.row + dy)
        return building.get("look", []) if building else []

    def _look(self, lines: list) -> None:
        """Say a lore hint's lines (Frankie, 10/25): each ``[speaker, line]``, or with a third,
        ``with hina`` or ``without hina``, said only with that member along or away."""
        for speaker, line, *when in lines:
            if when:
                need, member = when[0].split()
                if (self.gm.party.find(member) is not None) != (need == "with"):
                    continue
            self.text_box.push(line, speaker=speaker)

    def _wake_stone(self, stone: dict) -> None:
        """A sleeping stone wakes and fights, alone (the log yard's Pōhaku, Frankie 10/28).

        It stays a stone on the map whatever comes of the fight, so Kailo
        can talk to it, and fight it, again.
        """
        kinds = self.gm.data.load("field_monsters")
        spot = {"col": stone["col"], "row": stone["row"], "kind": stone["wakes"], "still": True}
        self._start_fight(FieldMonster(spot, kinds[stone["wakes"]]))

    def _faced_building(self) -> str | None:
        """The kind of building on the tile the player faces, or None."""
        dx, dy = self.player.facing
        building = self.world.building_at(self.player.col + dx, self.player.row + dy)
        return building["kind"] if building else None

    def _facing_shut_door(self) -> bool:
        """Whether the player stands below a house's door, facing up, with no room behind it."""
        dx, dy = self.player.facing
        col, row = self.player.col + dx, self.player.row + dy
        building = self.world.building_at(col, row)
        door = OverworldSettings.DOORS.get(building["kind"]) if building else None
        return ((dx, dy) == (0, -1) and door is not None
                and (col - building["col"], row - building["row"]) == door
                and (self.world.current_cell_name, self.player.col, self.player.row, (0, -1)) not in warps())

    def _say_shut_door(self) -> None:
        """A house nobody can go into: Kailo says nobody is home (Frankie, 10/26)."""
        line = TownSettings.SHUT_DOOR_NIGHT if self.is_night() else TownSettings.SHUT_DOOR
        self.text_box.push(line, speaker=StorySettings.PLAYER)

    def _dead_end(self) -> bool:
        """Kailo walking into a shut door or off an edge with no room past it says
        one line, once each time he walks up to it (Frankie, 10/26). True if he spoke."""
        player = self.player
        if not player.bumped or player._step_active:
            self._bumped_at = None
            return False
        at = (self.world.current_cell_name, player.col, player.row, tuple(player.facing))
        if at == self._bumped_at:
            return False
        self._bumped_at = at
        if self._facing_shut_door():
            self._say_shut_door()
            return True
        dx, dy = player.facing
        edge = TownSettings.EDGE_LINES.get(self.world.current_cell_name)
        if edge and self.world.tile_at(player.col + dx, player.row + dy) is None:
            self.text_box.push(edge, speaker=StorySettings.PLAYER)
            return True
        return False

    def _turn_to_player(self, person: dict) -> list:
        """Turn ``person`` to face the player, who is facing them; return the way they faced."""
        was_facing = person["facing"]
        dx, dy = self.player.facing
        person["facing"] = [-dx, -dy]
        return was_facing

    def _faced_person(self) -> dict:
        """The person on the tile the player faces, or an empty dict."""
        dx, dy = self.player.facing
        return self.world.person_at(self.player.col + dx, self.player.row + dy) or {}

    def _open_shop(self, shop_id: str) -> None:
        """Push a shop on top of this scene (D-571). No keeper talks up
        Counter any more (Frankie, 10/26)."""
        # Local import, as with the menu and the battle below.
        from core.scenes.shop_scene import ShopScene

        self._push_shop(ShopScene(self.gm, shop_id))

    def _push_shop(self, shop) -> None:
        self.gm.audio.play("menu_select")
        self.gm.scene_stack.push(shop)

    # ------------------------------------------------------------------
    # THE HUNTERS' LODGE: its bounties (Frankie, 10/26; systems/bounties.py)
    # ------------------------------------------------------------------

    def _lodge_keeper(self, keeper: dict) -> None:
        """A finished bounty is paid first; then Buy and sell, Bounty or Leave."""
        board = self.gm.data.load("bounties")[keeper["bounties"]]
        lines, speaker = board["lines"], keeper["speaker"]
        if bounties.done(self.gm.party, board):
            from settings import ShopSettings
            # A purse too full for the pay: the keeper says so (Frankie, 11/1).
            overflow = self.gm.party.pule + bounties.posted(self.gm.party, board)["pule"] > ShopSettings.PULE_MAX
            post = bounties.pay(self.gm.party, board)
            prize = post.get("prize")
            words = {"pule": post["pule"], "prize": self._item_name(prize) if prize else ""}
            self.text_box.push(lines["paid" if prize else "paid_pule"].format(**words), speaker=speaker)
            self.text_box.push(lines["got" if prize else "got_pule"].format(**words))
            if overflow:
                self.text_box.push(lines["purse_full"], speaker=speaker)
            self.gm.audio.play("hit_sparkle_1")
            self._after_text = lambda: self._lodge_menu(keeper, board)
            return
        self._lodge_menu(keeper, board)

    def _lodge_menu(self, keeper: dict, board: dict) -> None:
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        lines = board["lines"]

        def pick(index: int) -> None:
            if index == 0:
                self._open_shop(keeper["shop"])
            elif index == 1:
                self._lodge_bounty(keeper, board)

        self.gm.scene_stack.push(ChoiceScene(self.gm, lines["ask"], lines["choices"], pick))

    def _lodge_bounty(self, keeper: dict, board: dict) -> None:
        """How far the taken bounty is; or the posted one, to take or leave."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        party, lines, speaker = self.gm.party, board["lines"], keeper["speaker"]
        post = bounties.posted(party, board)
        if bounties.taken(party):
            self.text_box.push(lines["progress"].format(tally=bounties.tally(party, board)), speaker=speaker)
            return
        prize = post.get("prize")
        self.text_box.push(lines["post" if prize else "post_pule"].format(
            what=post["what"], pule=post["pule"], prize=self._item_name(prize) if prize else ""), speaker=speaker)

        def pick(index: int) -> None:
            if index == 0:
                bounties.take(party)
                self.text_box.push(lines["taken"], speaker=speaker)

        self._after_text = lambda: self.gm.scene_stack.push(
            ChoiceScene(self.gm, lines["take"], lines["take_choices"], pick))

    @staticmethod
    def _item_name(item_id: str) -> str:
        from core.scenes.shop_scene import item_name  # local, as in _open_shop

        return item_name(item_id)

    # ------------------------------------------------------------------
    # MAIKA: a seller who joins (the demo plan, Frankie 10/22)
    # ------------------------------------------------------------------

    def _sync_joined(self) -> None:
        """Tell the world who is in the party and whether it is night, so whoever
        joined, or is at the wake, is gone from the map."""
        self.world.flags = self.gm.party.flags if self.gm.party else {}
        joined = {member.id for member in self.gm.party.members} if self.gm.party else set()
        night = bool(self.gm.party) and self.is_night()
        if (joined, night) != (self.world.joined, self.world.night):
            self.world.joined, self.world.night = joined, night
            self.world.go_to(self.world.current_pos)

    def _talk_to_joiner(self, person: dict) -> None:
        """The first time, his scene and then his shop; after that, what his sister's errand left.

        Buying no longer makes him join (Frankie, 10/30). In order: once Kailo has
        agreed to find him for his sister, Maika asks Kailo not to tell her
        (the next talk, whether he was met before the sister or after); once
        Kailo has lied to her, he joins; once Kailo has told her the truth, he
        sulks, once, and stays; every other talk is his shop.
        """
        flags = self.gm.party.flags
        flag = f"met_{person['joins']}"
        if not flags.get(flag):
            flags[flag] = True
            self.begin_story(StorySettings.JOINER_MEETS)
        elif flags.get(StorySettings.SISTER_DEAL_FLAG) and not flags.get(StorySettings.JOINER_ASKED_FLAG):
            self.begin_story(StorySettings.JOINER_ASKS)
        elif flags.get(StorySettings.SISTER_LIED_FLAG):
            late = flags.get(StorySettings.BOAR_BEATEN_FLAG)
            self.begin_story(StorySettings.JOINER_JOINS_LATE if late else StorySettings.JOINER_JOINS)
        elif flags.get(StorySettings.SISTER_TOLD_FLAG) and not flags.get(StorySettings.JOINER_CROSS_FLAG):
            flags[StorySettings.JOINER_CROSS_FLAG] = True
            self.begin_story(StorySettings.JOINER_CROSS)
        else:
            self._open_joiner_shop(person)

    def _talk_to_sister(self, person: dict) -> None:
        """Maika's sister in the lodge (Frankie, 10/30): the deal, then once Maika has asked
        Kailo not to tell her, the report with its choice; either way, one line after."""
        flags = self.gm.party.flags
        if not flags.get(StorySettings.SISTER_DEAL_FLAG):
            self.begin_story(StorySettings.SISTER_ASKS)
        elif flags.get(StorySettings.SISTER_LIED_FLAG):
            self.text_box.push(StorySettings.SISTER_AFTER_LIE, speaker=person["speaker"])
        elif flags.get(StorySettings.SISTER_TOLD_FLAG):
            self.text_box.push(StorySettings.SISTER_AFTER_TRUTH, speaker=person["speaker"])
        elif flags.get(StorySettings.JOINER_ASKED_FLAG) or flags.get(f"met_{StorySettings.JOINER}"):
            # Maika met before her deal: Kailo can tell her right away (Frankie, 11/1).
            self.begin_story(StorySettings.SISTER_REPORT)
        else:
            self.text_box.push(StorySettings.SISTER_WAITING, speaker=person["speaker"])

    def _ask_menu(self, person: dict, start: int = 0) -> None:
        """Someone's questions (``data/asks``), asked as often as the player likes; the last walks away.

        Each answer is said, unlocks its Lore page if it has one, and the
        questions come back (Frankie, 10/25).
        """
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        questions = self.gm.data.load("asks")[person["ask"]]["questions"]

        def pick(index: int) -> None:
            question = questions[index]
            for speaker, line in question["lines"]:
                self.text_box.push(line, speaker=speaker)
            if question.get("unlock"):
                lore.unlock(self.gm.party, question["unlock"])
            if index < len(questions) - 1:
                # Back on the question just asked, never the top: confirm replayed the
                # first speech (Frankie, 11/3, Mark's playtest).
                self._after_text = lambda: self._ask_menu(person, index)

        menu = ChoiceScene(self.gm, person["speaker"], [q["ask"] for q in questions], pick)
        menu.cursor = start
        self.gm.scene_stack.push(menu)

    def _say_lines(self, person: dict) -> None:
        """Someone's next line. Someone home at night says their ``night_lines`` (Kailo's
        cousins, 10/25); by day, the ``flag_lines`` of the first party flag set, if any (the
        chief with no stew, Frankie, 10/26). One of them a talk (Frankie, 10/26)."""
        flags = self.gm.party.flags if self.gm.party else {}
        which, lines = next(((flag, said) for flag, said in person.get("flag_lines", {}).items()
                             if flags.get(flag)), ("day", person["lines"]))
        if self.is_night() and person.get("night_lines"):
            which, lines = "night", person["night_lines"]
        self._take_turn(person, which, lines)
        if self.gm.party and not self.is_night() and self.gm.party.flags.get(StorySettings.AFTER_JUMP_FLAG):
            self._craving(person)

    def _keeper_menu(self, person: dict) -> None:
        """A keeper's menu (Frankie, 11/3): ``menu`` holds the question and its rows, each
        [words, action]. "shop" opens their shop, "talk" says their next line (Ama's boat job
        after the jump), "ask" opens their questions, "raise" gets the fallen up, "leave" closes."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        menu = person["menu"]

        def pick(index: int) -> None:
            action = menu["choices"][index][1]
            if action == "shop":
                self._open_shop(person["shop"])
            elif action == "talk" and person.get("boat") and self.gm.party \
                    and self.gm.party.flags.get(StorySettings.AFTER_JUMP_FLAG):
                self._talk_ama_boat(person["speaker"])
            elif action == "talk":
                self._say_lines(person)
            elif action == "ask":
                self._ask_menu(person)
            elif action == "raise":
                self._raise_fallen(person)

        self.gm.scene_stack.push(ChoiceScene(self.gm, menu["ask"], [row[0] for row in menu["choices"]], pick))

    def _offer_water(self) -> None:
        """Leave Lanu a cup of water: one water from the bag, one cup counted (Frankie, 11/3)."""
        party = self.gm.party
        party.inventory[ItemSettings.WATER] -= 1
        if party.inventory[ItemSettings.WATER] <= 0:
            del party.inventory[ItemSettings.WATER]
        cups = party.flags.get(LanuSettings.CUPS_FLAG, 0) + 1
        party.flags[LanuSettings.CUPS_FLAG] = cups
        self.gm.audio.play("hit_sparkle_1")
        self.text_box.push(LanuSettings.POURED)
        if cups >= LanuSettings.CUPS:
            self.text_box.push(LanuSettings.ENOUGH)

    def _raise_fallen(self, person: dict) -> None:
        """The temple's priest raises every fallen member at full HP, free, as a totem does
        (Frankie, 11/3; free and full are Claude's calls). ``raise`` holds his two lines."""
        said = person["raise"]
        fallen = [m for m in self.gm.party.members if m.current_hp <= 0]
        if not fallen:
            self.text_box.push(said["none"], speaker=person["speaker"])
            return
        for member in fallen:
            member.current_hp = member.max_hp
        self.text_box.push(said["prays"], speaker=person["speaker"])
        self.gm.audio.play("hit_sparkle_1")
        for member in fallen:
            self.text_box.push(f"{short_name(member.id)} got back up.")

    def _read_sign(self, shop_id: str) -> None:
        """The old man at the wake (Frankie, 10/25): Kailo stares at his sign, Hina reads it, and the shop opens."""
        for line in TownSettings.SIGN_STARE:
            self.text_box.push(line, speaker=StorySettings.PLAYER)
        hina = TownSettings.SCOLD_SPEAKER
        if self.gm.party.find(hina.lower()) is not None:
            for line in TownSettings.SIGN_READ:
                self.text_box.push(line, speaker=hina)
        # Straight to the shop.
        from core.scenes.shop_scene import ShopScene  # local, as in _open_shop

        self._after_text = lambda: self._push_shop(ShopScene(self.gm, shop_id))

    def _joined_keeper_shop(self) -> None:
        """A stall whose keeper has joined stays open (Frankie, 10/24): he asks, then his shop."""
        keeper = next((p for p in PEOPLE.get(self.world.current_cell_name, [])
                       if p.get("shop") and p.get("joins") and self.gm.party.find(p["joins"])), None)
        if keeper is None:
            return
        speaker = short_name(keeper["joins"])
        self.text_box.push(StorySettings.JOINED_SHOP_LINE, speaker=speaker)
        self._after_text = lambda: self._open_shop(keeper["shop"])

    def _joiner(self) -> dict | None:
        """The person in this room who may join (Maika), or None."""
        return next((p for p in self.world.people if p.get("joins")), None)

    def _open_joiner_shop(self, person: dict) -> None:
        self._joiner_shop = (person, dict(self.gm.party.inventory))
        self._open_shop(person["shop"])

    def _after_joiner_shop(self, person: dict, before: dict) -> None:
        """The shop closed, bought or not: he says to come back (buying no longer makes him join)."""
        self.begin_story(StorySettings.JOINER_LEAVES)

    def _joiner_joins(self) -> None:
        """His scene is over: he joins, with his pop-up, and is gone from the map."""
        from core.factories import party_member_from_data
        from core.shared import by_id

        self.gm.party.add(party_member_from_data(by_id("characters")[StorySettings.JOINER]))
        # He holds a doll from the start so he can Charm at once; his Ko'oko'o waits in the bag (Frankie, 11/1).
        bag = self.gm.party.inventory
        bag[StorySettings.JOINER_STAFF] = bag.get(StorySettings.JOINER_STAFF, 0) + 1
        self.text_box.push(join_line(StorySettings.JOINER))
        self.gm.audio.play("hit_sparkle_1")
        self._sync_joined()

    def _asker_in_reach(self) -> FieldMonster | None:
        """The Great Boar, if the party has walked up to him, facing him; he asks before he fights."""
        dx, dy = self.player.facing
        ahead = (self.player.col + dx, self.player.row + dy)
        return next((m for m in self.monsters if m.spot.get("kind") == StorySettings.ASK_KIND
                     and ahead in m.tiles()), None)

    def _slot_learned(self, member_id: str, move_id: str) -> None:
        """Put a move just learned in a scene into the member's lowest free slot, as a lontar does."""
        from core.factories import first_loadout
        from core.shared import by_id
        from systems.loadout import learn, open_slots
        member = self.gm.party.find(member_id)
        if member is not None:
            member.loadout = learn(member.loadout, by_id("moves")[move_id],
                                   first_loadout(member_id, self.gm.party.flags),
                                   open_slots(self.gm.party.flags))

    def _seed_lesson_due(self) -> bool:
        """Maika and Hina both along and Seed not taught yet: the first planting teaches it."""
        party = self.gm.party
        return (not party.flags.get(StorySettings.SEED_FLAG)
                and party.find(StorySettings.JOINER) is not None
                and party.find(StorySettings.HOME_MEMBER) is not None)

    # ------------------------------------------------------------------
    # THE STORY: the taro patch, night, Melia's tusk, Hina's question, the wake
    # ------------------------------------------------------------------

    def begin_story(self, name: str) -> None:
        """Play the scene ``name`` (``core/story.py``) over the field."""
        self.story = StoryRunner(name)
        # The Kaigara Kame's talk finds the Lore pages it names (Frankie, 10/27).
        lore.naming = name.startswith("kaigara_")
        self.story.choose(party_flag(self.gm.party))
        # "(if maika along)" plays whenever he is in the party (story-boar.md);
        # "(if maika)" only when he leads, Hina away.
        self.story.flags.update(f"{member.id} along" for member in self.gm.party.members)
        # Whether the gulls got the stew at the taro patch (Frankie, 10/26); a
        # save from before it, or a scene picked from the title, has it saved.
        lost = self.gm.party.flags.get(StorySettings.STEW_LOST_FLAG)
        self.story.choose(StorySettings.STEW_LOST if lost else StorySettings.STEW_SAVED)
        # Whether Kailo has cooked the new stew, Noelani helping, for the Great Boar's nightfall (Frankie, 10/30).
        if stew.made(self.gm.party):
            self.story.choose("stew made")
        self._story_next = None
        self.stage = None

    def open_from_black(self) -> None:
        """Start the field black, the blurb's black, to fade in as the story's first line
        slowly types; lit just as it finishes (Frankie, 10/25)."""
        self._dark, self._opening = 1.0, True

    def _tick_opening(self) -> None:
        """Light the opening as far as its first line has typed; over once it has."""
        if not self._opening or self.text_box.is_done():
            return
        if self.text_box.has_own_speed() and self.text_box.typed() < 1:
            self._dark = 1.0 - self.text_box.typed()
        else:
            self._dark, self._opening = 0.0, False

    def is_night(self) -> bool:
        """Whether the Great Boar is beaten, so it is night, until the morning after the jump."""
        flags = self.gm.party.flags
        return bool(flags.get(StorySettings.NIGHT_FLAG)) and not flags.get(StorySettings.AFTER_JUMP_FLAG)

    def _talk_at_night(self, person: dict) -> None:
        """Melia at night: with the Great Boar's tusk in the bag, Kailo gives it to her,
        once (10/25); otherwise her ``night_lines``."""
        party = self.gm.party
        if (person["night"] == StorySettings.TUSK_SCENE and party.inventory.get(StorySettings.TUSK)
                and not party.flags.get(StorySettings.TUSK_FLAG)):
            self.begin_story(StorySettings.TUSK_SCENE)
            return
        self._take_turn(person, "night", person.get("night_lines", []))

    def _wake_ask_due(self) -> bool:
        """The tusk given and the party just in the chief's room: Hina asks, once a visit (Frankie, 10/25)."""
        if self.world.current_cell_name != StorySettings.ASK_ROOM:
            self._wake_asked = False
            return False
        due = (not self._wake_asked and not self.player._step_active
               and self.is_night() and bool(self.gm.party.flags.get(StorySettings.TUSK_FLAG)))
        if due:
            self._wake_asked = True
        return due

    def _ask_wake(self) -> None:
        """Hina: is the party ready for the wake? YES starts it; NO, nothing more this visit."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        self.text_box.push(StorySettings.ASK_LINE, speaker=StorySettings.ASK_SPEAKER)
        self._after_text = lambda: self.gm.scene_stack.push(ConfirmScene(
            self.gm, StorySettings.ASK_BOX, on_yes=lambda: self.begin_story(StorySettings.WAKE_SCENE),
        ))

    def _not_your_bed(self, bed: dict) -> None:
        """Someone else's bed: Hina scolds, flustered at her own; with her away, Kailo knows it is not his."""
        hina = TownSettings.SCOLD_SPEAKER
        if bed.get("owner") == hina.lower():
            self.text_box.push(TownSettings.HINA_BED, speaker=hina)
        elif self.gm.party.find(hina.lower()) is not None:
            self.text_box.push(TownSettings.NOT_YOUR_BED, speaker=hina)
        else:
            self.text_box.push(TownSettings.NOT_MY_BED, speaker=StorySettings.PLAYER)

    def _ask_nap(self) -> None:
        """Kailo's bed: take a nap? YES rests the party; NO, nothing."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        self.gm.scene_stack.push(ConfirmScene(
            self.gm, TownSettings.NAP_BOX, on_yes=self._nap,
        ))

    def _ask_inn(self, keeper: dict | None = None) -> None:
        """Kupulau's inn (Frankie, 11/3): pay the keeper's price in pule to sleep the night. A bed
        asks too, the price from the keeper in the room; short of pule, she says so."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        keeper = keeper or next((p for p in self.world.people if p.get("inn")), None)
        if keeper is None:
            return
        price = keeper["inn"]
        if self.gm.party.pule < price:
            self.text_box.push(TownSettings.INN_SHORT.format(price=price), speaker=keeper["speaker"])
            return
        self.gm.scene_stack.push(ConfirmScene(
            self.gm, TownSettings.INN_ASK.format(price=price), on_yes=lambda: self._sleep_at_inn(keeper),
        ))

    def _sleep_at_inn(self, keeper: dict) -> None:
        """The night at the inn: the price paid, the party rested and the next day (the nap's own rest)."""
        self.gm.party.pule -= keeper["inn"]
        self.text_box.push(TownSettings.INN_THANKS, speaker=keeper["speaker"])
        records.sleep(self.gm.party)
        self._rest(TownSettings.INN_LINE)

    def _nap(self) -> None:
        """A nap in Kailo's bed: rested, and the next day (Frankie, 10/25)."""
        records.sleep(self.gm.party)
        self._rest(TownSettings.NAP_LINE)

    def _craving(self, person: dict) -> None:
        """At the end of a named villager's usual line (Frankie, 11/1): a hint that they are in the
        mood for a dish, or, with it in the bag, the ask; yes, and they give a random gift."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menus nearby

        party = self.gm.party
        said = meal_orders.talk(party, person)
        if said is None:
            return
        kind, meal = said
        words = meal_orders.name(meal)
        speaker = person["speaker"]
        if kind == "hint":
            self.text_box.push(random.choice(OrderSettings.HINT_LINES).format(meal=words), speaker=speaker)
            return
        self.text_box.push(OrderSettings.ASK_LINE.format(meal=words), speaker=speaker)

        def give() -> None:
            got = meal_orders.gift(party, meal)
            self.gm.audio.play("chest_open")
            self.text_box.push(OrderSettings.THANKS_LINE, speaker=speaker)
            self.text_box.push(OrderSettings.GAVE_LINE.format(meal=words))
            self.text_box.push(OrderSettings.RECEIVED_LINE.format(item=got))

        self._after_text = lambda: self.gm.scene_stack.push(
            ConfirmScene(self.gm, OrderSettings.ASK_BOX.format(meal=words), on_yes=give))

    def _check_orders(self) -> None:
        """The Meialana's orders (Frankie, 11/1): who ordered what, and Prices; picking one
        delivers it, if the dish is in the bag."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        party = self.gm.party
        found = meal_orders.orders(party)
        if not found:
            self.text_box.push(OrderSettings.NONE_LINE)
            return
        choices = [OrderSettings.ENTRY.format(who=who, meal=meal_orders.name(meal)) for who, meal in found]
        choices += [OrderSettings.PRICES_LABEL, OrderSettings.BACK_LABEL]

        def pick(index: int) -> None:
            if index < len(found):
                who, meal = found[index]
                price = meal_orders.deliver(party, index)
                if price is None:
                    self.text_box.push(OrderSettings.MISSING_LINE.format(meal=meal_orders.name(meal)))
                else:
                    self.gm.audio.play("chest_open")
                    self.text_box.push(OrderSettings.SOLD_LINE.format(
                        meal=meal_orders.name(meal), who=who, price=price))
                    self._after_text = self._check_orders if meal_orders.orders(party) else None
            elif choices[index] == OrderSettings.PRICES_LABEL:
                self._show_prices(self._check_orders)

        self.gm.scene_stack.push(ChoiceScene(self.gm, OrderSettings.ORDERS_ASK, choices, pick))

    def _show_prices(self, back, page: int = 0) -> None:
        """What each dish pays, hardest first, PRICES_PAGE a page (the screen is 224 high); More
        turns the page, round and round, Back goes back."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu above

        ranked = sorted(meal_orders.meals(), key=lambda meal: (-meal_orders.pay(meal), meal_orders.name(meal)))
        size = OrderSettings.PRICES_PAGE
        pages = (len(ranked) + size - 1) // size
        rows = [OrderSettings.PRICE_ENTRY.format(meal=meal_orders.name(meal), price=meal_orders.pay(meal))
                for meal in ranked[page * size:(page + 1) * size]]
        extras = ([OrderSettings.MORE_LABEL] if pages > 1 else []) + [OrderSettings.BACK_LABEL]

        def pick(index: int) -> None:
            if index < len(rows) or extras[index - len(rows)] == OrderSettings.MORE_LABEL:
                self._show_prices(back, (page + 1) % pages if index >= len(rows) else page)
            else:
                back()

        self.gm.scene_stack.push(ChoiceScene(self.gm, OrderSettings.PRICES_ASK.format(page=page + 1, pages=pages),
                                             rows + extras, pick))

    def _boat_menu(self) -> None:
        """The Meialana, its cabin Kailo's kitchen and his bed (Frankie, 10/28): Cook opens
        the pot, Nap rests the party as his bed at home does, Leave does nothing."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        choices = list(TownSettings.BOAT_CHOICES)
        party = self.gm.party
        if party.flags.get(StorySettings.AFTER_JUMP_FLAG):
            meal_orders.roll_orders(party)
            if meal_orders.orders(party):
                choices.insert(2, OrderSettings.CHECK_LABEL)
        # A save mended before the ready flag existed has only BOAT_FIXED.
        if party.flags.get(SailingSettings.READY_FLAG) or party.flags.get(StorySettings.BOAT_FIXED):
            choices.insert(choices.index("Leave"), "Sail")

        def pick(index: int) -> None:
            if index == 0:
                self._open_pot()
            elif index == 1:
                self._boat_nap()
            elif choices[index] == OrderSettings.CHECK_LABEL:
                self._check_orders()
            elif choices[index] == "Sail":
                self._ask_sail()

        self.gm.scene_stack.push(ChoiceScene(self.gm, TownSettings.BOAT_ASK, choices, pick))

    def _ask_sail(self) -> None:
        """Sail (Frankie, 10/31): the first time, one last "are you sure", Ama marks
        Lanuloa on the map and explains the food on the dock; then the open sea."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu above

        party = self.gm.party
        if party.flags.get(SailingSettings.LEAVE_FLAG):
            self._set_sail()
            return

        def pick(index: int) -> None:
            if index == 0:
                party.flags[SailingSettings.LEAVE_FLAG] = True
                party.flags[MapSettings.HAS_MAP_FLAG] = True   # Ama gives him the map (Frankie, 10/26 and 10/31)
                sailing.know(party, "Kupulau")   # Ama marks the first island
                self._set_sail(SailingSettings.AMA_LINES)

        self.gm.scene_stack.push(ChoiceScene(self.gm, SailingSettings.LEAVE_ASK, ["Yes", "No"], pick))

    def _set_sail(self, lines: tuple[str, ...] = ()) -> None:
        """Push the sea, leaving from the port the boat is moored at (Kulāiwi, or Kupulau,
        Frankie, 11/1); ashore at any port, Kailo is on its pier below the Meialana."""
        from core.scenes.sea_scene import SeaScene  # local: cycle

        def ashore(place: str) -> None:
            from core.overworld_cells import WORLD_LAYOUT  # local, as the rest of the field

            room, (col, row) = SailingSettings.LANDINGS[place]
            self.world.go_to(next(pos for pos, name in WORLD_LAYOUT.items() if name == room))
            self.player.from_dict({"col": col, "row": row, "facing": [0, -1]})
            self._room_sound()
            party = self.gm.party   # the browser demo ends at Kupulau, once a save (Frankie, 11/2)
            if (SailingSettings.BROWSER and place == SailingSettings.DEMO_END_PORT
                    and not party.flags.get(SailingSettings.DEMO_END_FLAG)):
                party.flags[SailingSettings.DEMO_END_FLAG] = True
                self.text_box.push(SailingSettings.DEMO_END_LINE)

        here = next((port for port, (room, _) in SailingSettings.LANDINGS.items()
                     if room == self.world.current_cell_name), "Kulāiwi")
        self.gm.scene_stack.push(SeaScene(self.gm, here, ashore, lines))

    def _boat_nap(self) -> None:
        """A nap aboard: as in the bed, and the date shown at once, since there is no door to walk out of."""
        self._nap()
        if self.gm.party.flags.pop(records.SLEPT_FLAG, False):
            self._show_popup([place for place in (self._place,) if place] + [records.date_text(self.gm.party)])

    def _watch_place(self, dt: float) -> None:
        """Name the place on walking into a new one, and the date on walking out of the
        house after a nap; count the pop-up down (Frankie, 10/25)."""
        self._popup_left = max(0.0, self._popup_left - dt)
        if self._popup_left <= 0:
            self.popup = None
        room = self.world.current_cell_name
        if room == self._place_room:
            return
        was, self._place_room = self._place_room, room
        place = places.name_of(room)
        flags = self.gm.party.flags if self.gm.party else {}
        if was is None or self.story is not None:
            pass
        elif was == places.HOME and flags.pop(records.SLEPT_FLAG, False) and place is not None:
            self._show_popup([place, records.date_text(self.gm.party)])
        elif place is not None and place != self._place:
            self._show_popup([place])
        if place is not None:
            self._place = place

    def _show_popup(self, lines: list[str]) -> None:
        self.popup = lines
        self._popup_left = PlaceSettings.SECONDS

    def _render_popup(self, surface: pygame.Surface) -> None:
        """The place, and the date in the speaker's yellow, in a box at the top center."""
        if not self.popup:
            return
        size = FontSettings.SIZE_BODY
        pad = UISettings.TEXT_BOX_PADDING
        lines = list(self.popup)
        width = max(text_renderer.text_width(line, size) for line in lines) + 2 * pad
        width = -(-width // 8) * 8
        row = text_renderer.line_height(size)
        top = PlaceSettings.TOP
        if TextBox.at_top and not self.text_box.is_done():
            # The dialogue box is up there; the pop-up waits under it.
            top += self.text_box.height
        rect = pygame.Rect((surface.get_width() - width) // 16 * 8, top, width, len(lines) * row + 2 * pad)
        draw_window(surface, rect)
        for index, line in enumerate(lines):
            x = rect.left + (rect.width - text_renderer.text_width(line, size)) // 2
            text_renderer.draw_text(surface, line, (x, rect.top + pad + index * row), size=size,
                                    color=ColorSettings.YELLOW if index else ColorSettings.WHITE)

    def _play_story(self) -> None:
        """Called with the text box closed: show the lines up to the next choice, fight or stage direction, then it."""
        if (self.stage is not None and self.stage.busy()) or self._fade_to is not None or self._wait > 0:
            return
        if self._story_next is None:
            while True:
                step = self.story.next_step()
                if step is None:
                    self._story_next = {"over": True}
                    break
                if "say" in step or "text" in step:
                    slow = self._opening and self.text_box.is_done()
                    self.text_box.push(step["text"], speaker=step.get("say"), fast=step.get("fast", False),
                                       speed=UISettings.OPENING_CHARS_PER_SECOND if slow else step.get("speed"),
                                       hold=step.get("hold", False))
                    if step.get("say") == StorySettings.WAKE_GIFT_FROM and step.get("if") == StorySettings.STEW_SAVED:
                        self._wake_gift()
                    continue
                self._story_next = step
                break
            if "fight" in self._story_next and self.story.name == "wake":
                self._join_at_wake()
            if not self.text_box.is_done():
                return
        step, self._story_next = self._story_next, None
        if "room" in step:
            # The scene moves to a room: the stage starts empty there, but
            # for Kailo where he stands if he is in that room already.
            from core.overworld_cells import WORLD_LAYOUT  # local: as start_in_room

            here = self.world.current_cell_name == step["room"]
            self.world.go_to(next(pos for pos, name in WORLD_LAYOUT.items() if name == step["room"]))
            # The room's own monsters, not the last room's (none walk the rooms scenes play in today).
            self._place_monsters()
            kinds = self.gm.data.load("field_monsters")
            # A foe stands as its monster's kind on the map, or its sprite's (the wake's dwende).
            foes = {foe["name"]: kinds.get(foe["monster"]) or kinds[foe["sprite"]] for s in self.story.steps
                    for foe in s.get("fight", []) if foe["monster"] in kinds or foe["sprite"] in kinds}
            self.stage = Stage(cast(self.story.name), foes)
            if here:
                self.stage.do({"stand": [{"who": StorySettings.PLAYER, "col": self.player.col,
                                          "row": self.player.row, "facing": tuple(self.player.facing)}]})
        elif any(key in step for key in ("stand", "move", "turn", "fall")):
            if self.stage is not None:
                self.stage.do(step)
        elif "fade" in step:
            self._fade_to = 1.0 if step["fade"] == "out" else 0.0
        elif "wait" in step:
            self._wait = step["wait"]
        elif "song" in step:
            self.story.song = step["song"]
        elif "choice" in step:
            from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

            options = step["options"]
            self.gm.scene_stack.push(ChoiceScene(
                self.gm, step["choice"], [label for label, _ in options],
                lambda index: self.story.choose(options[index][1]),
            ))
        elif "fight" in step:
            from core.scenes.battle_scene import BattleScene  # local, as _start_fight

            # The taro patch's fight has Hina's tutorial (Frankie, 10/26).
            self._story_fight = BattleScene(self.gm, enemies=step["fight"], can_escape=False,
                                            in_town=self._in_town(), story=True,
                                            tutorial=self.story.name == TutorialSettings.SCENE,
                                            music=self.story.song, swap_lesson=self._swap_lesson(),
                                            opening=step.get("opening"))
            self.gm.scene_stack.push(self._story_fight)
        else:
            self._story_over()

    def skip_cutscene(self) -> None:
        """Play the rest of the scene at once, behind black (Frankie, 10/28; ``core/skip_cutscene.py``).

        It runs through the game's own steps, a frame's worth of them at a
        time, so whatever the scene sets is set; it stops when the scene
        ends, or where a fight (or anything else) comes up on top.
        """
        self.skipping = self.story

    def _skip_ahead(self) -> None:
        """Up to ``StorySettings.SKIP_STEPS`` frames of the scene, text paged at once."""
        for _ in range(StorySettings.SKIP_STEPS):
            if self.story is not self.skipping or self.gm.scene_stack.top is not self or self._card is not None:
                self.skipping = None
                return
            self.text_box.update(10.0)
            self.text_box.advance()
            self._frame(1 / 60)

    def _swap_lesson(self) -> str | None:
        """At the wake, whoever came along and sits on the bench: Hina shows the player Swap."""
        if self.story.name != StorySettings.WAKE_SCENE:
            return None
        return StorySettings.WAKE_BENCH if self.gm.party.find(StorySettings.WAKE_BENCH) is not None else None

    def _wake_gift(self) -> None:
        """The stew saved, the chief thanks Kailo at the wake with a rare drop or relic (Frankie, 10/26)."""
        from settings import ItemSettings

        item = random.choice(ItemSettings.EQUIP_DROPS + StorySettings.WAKE_GIFT_EXTRA)
        inventory = self.gm.party.inventory
        inventory[item] = inventory.get(item, 0) + 1
        self.gm.audio.play("chest_open")
        self.text_box.push(StorySettings.WAKE_GIFT_LINE.format(item=ItemSettings.NAMES.get(item, item)))

    def _join_at_wake(self) -> None:
        """Before the fight Tawiri joins fourth, with her pop-up; whoever else came sits on the bench."""
        from core.factories import party_member_from_data
        from core.shared import by_id

        party = self.gm.party
        if party.find(StorySettings.WAKE_JOINS) is not None:
            return
        party.add(party_member_from_data(by_id("characters")[StorySettings.WAKE_JOINS]))
        lore.unlock(party, "event tawiri_joins")
        bench = party.find(StorySettings.WAKE_BENCH)
        if bench is not None:
            party.members.remove(bench)
            party.members.append(bench)
        self.gm.audio.play("hit_sparkle_1")
        self.text_box.push(StorySettings.WAKE_JOIN_LINE)

    def _story_over(self) -> None:
        """A scene's part is over: a lost story fight again, but for the taro patch's; else on with the demo.

        Losing the taro patch goes on with the game (Frankie, 10/26); the save
        keeps that the gulls got the stew.
        """
        if self.story.part == LOSE and self.story.name != "taro_patch":
            self.story.retry()
            return
        part = self.story.part
        name, flags, ended, self.story = self.story.name, self.story.flags, self.story.ended, None
        lore.naming = False
        self._leave_stage()
        party = self.gm.party
        if name == "taro_patch":
            party.flags[StorySettings.TARO_FLAG] = True
            party.flags[StorySettings.STEW_LOST_FLAG] = part == LOSE
            # The boars knocked the pot over: the stew is a quest now (Frankie, 10/30).
            party.flags[StewSettings.QUEST_FLAG] = True
            # Hina goes home, out of the party until Kailo comes to her (Frankie, 10/23).
            party.leave(StorySettings.HOME_MEMBER)
            self._sync_joined()
        elif name in (StorySettings.HOME_SCENE, StorySettings.WOODS_SCENE):
            if party.rejoin(StorySettings.HOME_MEMBER) is None:
                from core.factories import party_member_from_data
                from core.shared import by_id

                party.add(party_member_from_data(by_id("characters")[StorySettings.HOME_MEMBER]))
            first = not party.flags.get(StorySettings.HOME_FLAG)
            party.flags[StorySettings.HOME_FLAG] = True
            self._sync_joined()
            if first:
                # Her pop-up, as Maika's (Frankie, 10/27).
                self.text_box.push(join_line(StorySettings.HOME_MEMBER))
                self.gm.audio.play("hit_sparkle_1")
            lore.unlock(party, "event hina_home")
        elif name == StorySettings.JOINER_MEETS:
            person = self._joiner()
            if person is not None:
                lore.unlock(party, f"event met_{person['joins']}")
                # Sent by his sister already: he asks first, then his shop opens.
                if party.flags.get(StorySettings.SISTER_DEAL_FLAG):
                    self.begin_story(StorySettings.JOINER_ASKS)
                else:
                    self._open_joiner_shop(person)
        elif name == StorySettings.JOINER_ASKS:
            party.flags[StorySettings.JOINER_ASKED_FLAG] = True
            person = self._joiner()
            if person is not None:
                self._open_joiner_shop(person)
        elif name == StorySettings.JOINER_CROSS:
            # He stays; his shop is as it was.
            pass
        elif name in (StorySettings.JOINER_JOINS, StorySettings.JOINER_JOINS_LATE):
            self._joiner_joins()
        elif name == StorySettings.SISTER_ASKS:
            party.flags[StorySettings.SISTER_DEAL_FLAG] = True
        elif name == StorySettings.SISTER_REPORT:
            # The lie: Maika joins on his next talk, no soy sauce. The truth: the soy sauce now,
            # and Maika, his stall and Miki are gone from their rooms (Frankie, 11/1).
            party.flags[StorySettings.JOINER_ASKED_FLAG] = True  # no asking-not-to-tell scene after the telling
            if StorySettings.SISTER_TRUTH in flags:
                party.flags[StorySettings.SISTER_TOLD_FLAG] = True
                party.inventory[StorySettings.SOY_SAUCE] = (party.inventory.get(StorySettings.SOY_SAUCE, 0)
                                                           + StorySettings.SISTER_SOY_COUNT)
                self.text_box.push(StorySettings.SISTER_SOY_LINE)
                self.gm.audio.play("learned")
            else:
                party.flags[StorySettings.SISTER_LIED_FLAG] = True
        elif name == StorySettings.ASK_SCENE:
            # Fight now, or a few steps back the way they came, to heal and save first.
            if StorySettings.ASK_FIGHT in flags and self._asking in self.monsters:
                self._start_fight(self._asking)
            else:
                dx, dy = self.player.facing
                self._walk_back = [(-dx, -dy)] * StorySettings.BACK_STEPS
        elif name in (StorySettings.VILLAGE_MAIKA, StorySettings.VILLAGE_STALL):
            # Back out of the opening, west, the way in (the village cannot be entered).
            self._walk_back = [(-1, 0)] * StorySettings.VILLAGE_BACK_STEPS
        elif name in (StorySettings.DEEP_HINA, StorySettings.DEEP_MAIKA):
            # Either names Lanu's beasts, which finds her page (Frankie, 10/25).
            party.flags[f"story_{name}"] = True
            lore.unlock(party, "event deep_woods")
        elif name == StorySettings.TUSK_SCENE:
            # The tusk is hers now; the wake waits in the chief's room.
            party.inventory.pop(StorySettings.TUSK, None)
            party.flags[StorySettings.TUSK_FLAG] = True
        elif name == StewSettings.SCENE:
            # The stew is a key item now (Frankie, 10/30); if the Great Boar is already
            # beaten, the night falls.
            party.inventory[StewSettings.KEY_ITEM] = 1
            if stew.night_falls(party):
                party.flags[StorySettings.NIGHT_FLAG] = True
                self.text_box.push(StewSettings.DUSK_LINE)
        elif name == StorySettings.SEED_SCENE:
            party.flags[StorySettings.SEED_FLAG] = True
            self._slot_learned(StorySettings.HOME_MEMBER, "seed")
            self.gm.audio.play("learned")
            self._hina_says_wait()
        elif name.startswith("kaigara_"):
            self._kaigara_over(name, flags)
        elif name == "wake":
            # The wake ends the demo (Frankie, 10/23): it faded out on its last line, and
            # its End is on the black screen until confirm goes to the title. Hina named
            # Shaka there, and Maika, if he came, Lanu.
            lore.unlock(party, "event wake_shaka")
            if f"{StorySettings.WAKE_BENCH} along" in flags:
                lore.unlock(party, "event wake_lanu")
            if StorySettings.DEMO_ONLY:
                self._dark, self._card = 1.0, ended
            else:
                # The game goes on past the demo (Frankie, 10/31): Ama pulls Kailo out.
                self._dark = 1.0
                self.begin_story(StorySettings.AFTER_JUMP_SCENE)
        elif name == StorySettings.AFTER_JUMP_SCENE:
            self._next_morning(ended)

    def _swap_walker(self, step: int) -> None:
        """L and R: the next or last party member walks the map (Frankie, 11/1). Only the
        sprite changes; the people here still talk to Kailo."""
        ids = [member.id for member in self.gm.party.members]
        if len(ids) < 2 or self.player._step_active:
            return
        here = ids.index(self.player.walker) if self.player.walker in ids else 0
        self.player.walker = ids[(here + step) % len(ids)]

    def _next_morning(self, words: str) -> None:
        """After the meeting in the chief's hut: the night is over, Kailo wakes by his bed.

        The scene faded out on its last line; its End's words ("The next morning.")
        show on black, and the room fades in once they are read.
        """
        from core.overworld_cells import WORLD_LAYOUT  # local: as the stage's Room

        party = self.gm.party
        # The night flag stays, so whatever came after it stays; is_night() reads this one too.
        party.flags[StorySettings.AFTER_JUMP_FLAG] = True
        room, col, row, facing = StorySettings.AFTER_JUMP_WAKE
        self._sync_joined()
        self.world.go_to(next(pos for pos, name in WORLD_LAYOUT.items() if name == room))
        self.player.from_dict({"col": col, "row": row, "facing": list(facing)})
        self._dark = 1.0
        if words:
            self.text_box.push(words)
        self._after_text = lambda: setattr(self, "_fade_to", 0.0)

    def _talk_to_kame(self) -> None:
        """The Kame, or his table: meeting him the first time, which finds his Lore page; then his questions."""
        player = next((p for p in self.world.people if p.get("kaigara") and p.get("bets")), None)
        if player is not None:
            self._talk_to_bettor(player)
            return
        if self.gm.party.flags.get(KaigaraSettings.MET_FLAG):
            self.begin_story(KaigaraSettings.MENU_SCENE)
            return
        lore.unlock(self.gm.party, KaigaraSettings.MET_EVENT)
        self.begin_story(KaigaraSettings.MEET_SCENE)

    def _talk_to_bettor(self, person: dict) -> None:
        """Kupulau's Bandari (Frankie, 11/1): he plays Kaigara for kupang, up to ``bets``, and the
        player picks the stake; with no kupang he says so, and No leaves it."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menus above

        party, name = self.gm.party, person["speaker"]
        if party.kupang <= 0:
            self.text_box.push(KaigaraSettings.STAKE_NONE, speaker=name)
            return
        top = min(person["bets"], party.kupang)
        stakes = list(range(1, top + 1))

        def pick(index: int) -> None:
            if index >= len(stakes):
                self.text_box.push(KaigaraSettings.STAKE_NO_LINE, speaker=name)
                return
            self._play_for_kupang(person, stakes[index])

        def ask() -> None:
            self.gm.scene_stack.push(ChoiceScene(
                self.gm, KaigaraSettings.STAKE_ASK, [str(n) for n in stakes] + [KaigaraSettings.STAKE_NO], pick))

        self.text_box.push(KaigaraSettings.STAKE_INTRO.format(max=person["bets"]), speaker=name)
        self._after_text = ask

    def _play_for_kupang(self, person: dict, stake: int) -> None:
        """One game against the Bandari for ``stake`` kupang: the winner has it, a draw pays nobody."""
        from core.scenes.kaigara_scene import KaigaraScene  # local, as the battle
        from systems import kaigara

        party, name = self.gm.party, person["speaker"]

        def done(winner: str | None) -> None:
            lore.unlock(party, kaigara.PLAYED_EVENT)
            if winner == kaigara.BLACK:
                party.kupang += stake
                self.gm.audio.play("hit_sparkle_1")
                line = KaigaraSettings.STAKE_WIN
            elif winner is None:
                line = KaigaraSettings.STAKE_DRAW
            else:
                party.kupang = max(0, party.kupang - stake)
                line = KaigaraSettings.STAKE_LOSE
            self.text_box.push(line.format(stake=stake), speaker=name)

        self.gm.scene_stack.push(KaigaraScene(self.gm, on_done=done, opponent=name, smart=True, stake=stake))

    def _kaigara_over(self, name: str, flags: set) -> None:
        """One of the Kame's scenes is over: on to his questions, a game, or an answer."""
        if name == KaigaraSettings.MEET_SCENE:
            self.gm.party.flags[KaigaraSettings.MET_FLAG] = True
            self.begin_story(KaigaraSettings.MENU_SCENE)
        elif name == KaigaraSettings.MENU_SCENE:
            asked = next((q for q in KaigaraSettings.QUESTIONS if q in flags), None)
            if KaigaraSettings.PLAY in flags:
                self._play_kaigara()
            elif asked is not None:
                lore.unlock(self.gm.party, f"event kaigara_{asked}")
                self.begin_story(f"kaigara_{asked}")
        elif name.removeprefix("kaigara_") in KaigaraSettings.QUESTIONS:
            self.begin_story(KaigaraSettings.MENU_SCENE)

    def _play_kaigara(self) -> None:
        """A game against the Kame; when it is over, the Lore pages, the prize and his line after."""
        from core.scenes.kaigara_scene import KaigaraScene  # local, as the battle
        from systems import kaigara

        def done(winner: str | None) -> None:
            first = kaigara.settle(self.gm.party, winner)
            if first:
                self.gm.audio.play("hit_sparkle_1")
            self.begin_story(KaigaraSettings.FIRST_WIN_SCENE if first
                             else KaigaraSettings.WIN_SCENE if winner == kaigara.BLACK
                             else KaigaraSettings.DRAW_SCENE if winner is None
                             else KaigaraSettings.LOSE_SCENE)

        self.gm.scene_stack.push(KaigaraScene(self.gm, on_done=done))

    def _leave_stage(self) -> None:
        """The scene is over: Kailo stays where the stage left him; everyone else is gone.

        Left on a doorway facing out, he goes through the door (Hina's scene).
        """
        if self.stage is None:
            return
        kailo = self.stage.actors.get(StorySettings.PLAYER)
        if kailo is not None and not kailo.off():
            self.player.from_dict({"col": kailo.col, "row": kailo.row, "facing": list(kailo.facing)})
            arrived = self.world.warp(kailo.col, kailo.row, kailo.facing)
            if arrived is not None:
                self.player.from_dict({"col": arrived[0], "row": arrived[1], "facing": list(kailo.facing)})
        self.stage = None

    def _hina_catches_up(self) -> bool:
        """Kailo in the room before the Great Boar's without having been to Hina's house: she runs after him."""
        party = self.gm.party
        return (self.world.current_cell_name == StorySettings.WOODS_ROOM and not self.player._step_active
                and party.flags.get(StorySettings.TARO_FLAG) and not party.flags.get(StorySettings.HOME_FLAG)
                and party.find(StorySettings.HOME_MEMBER) is None)

    def _deep_woods_warning(self) -> str | None:
        """On the log yard's west edge, walking west: Maika's warning if he is along, else Hina's, each once (Frankie, 10/25)."""
        party = self.gm.party
        if (self.world.current_cell_name != StorySettings.DEEP_ROOM or self.player._step_active
                or self.player.col != StorySettings.DEEP_COL or tuple(self.player.facing) != (-1, 0)):
            return None
        if party.find(StorySettings.JOINER) is not None:
            scene = StorySettings.DEEP_MAIKA
        elif party.find(StorySettings.HOME_MEMBER) is not None:
            scene = StorySettings.DEEP_HINA
        else:
            return None
        return None if party.flags.get(f"story_{scene}") else scene

    def _sage_village_turn(self) -> str | None:
        """In the opening east of Maika's room: his lines turning the party back, along or from his stall (Frankie, 10/26)."""
        if (self.world.current_cell_name != StorySettings.VILLAGE_ROOM or self.player._step_active
                or self._walk_back or self.player.col != StorySettings.VILLAGE_COL):
            return None
        if self.gm.party.find(StorySettings.JOINER) is not None:
            return StorySettings.VILLAGE_MAIKA
        return StorySettings.VILLAGE_STALL if self._joiner() is not None else None

    def _render_night(self, surface: pygame.Surface) -> None:
        """Night outside: the Super Nintendo's color math, a fixed color taken from every pixel."""
        if not self.is_night() or self.world.current_pos[1] >= INSIDE_ROW:
            return
        surface.fill(
            tuple(amount * 8 for amount in StorySettings.NIGHT_SUBTRACT),
            pygame.Rect(OverworldSettings.X, OverworldSettings.Y,
                        OverworldSettings.PIXEL_W, OverworldSettings.PIXEL_H),
            special_flags=pygame.BLEND_RGB_SUB,
        )
    # THE GARDEN AND THE POT: Hina plants, Maika grows, Kailo cooks
    # (Frankie, 10/22; systems/garden.py, core/scenes/craft_scene.py)
    # ------------------------------------------------------------------

    def _talk_requester(self, person: dict, request: dict) -> None:
        """Pono's widow (Frankie, 10/30): she hints at a dish; with it in the bag Kailo gives it,
        and she gives him the 'O'o, once."""
        party = self.gm.party
        speaker = person["speaker"]
        if party.flags.get(request["flag"]):
            if request.get("after_wake") and party.flags.get(StorySettings.AFTER_JUMP_FLAG):
                self._take_turn(person, "after_wake", request["after_wake"])  # the morning after the wake, one a talk
                return
            self.text_box.push(request["after"], speaker=speaker)
            return
        if party.inventory.get(request["wants"], 0) > 0:
            party.inventory[request["wants"]] -= 1
            if party.inventory[request["wants"]] <= 0:
                del party.inventory[request["wants"]]
            party.flags[request["flag"]] = True
            tools.take(party, request["gives"])
            for line in request["thanks"]:
                self.text_box.push(line, speaker=speaker)
            self.gm.audio.play("chest_open")
            self.text_box.push(f"Kailo received {ItemSettings.NAMES[request['gives']]}.")
            return
        for line in request["asks"]:
            self.text_box.push(line, speaker=speaker)

    def _talk_ama_boat(self, speaker: str) -> None:
        """Ama mends the Meialana: first the wood, which he takes, then the pule, which he gives back."""
        party, bag = self.gm.party, self.gm.party.inventory
        if party.flags.get(StorySettings.BOAT_FIXED):
            self.text_box.push(StorySettings.BOAT_DONE, speaker=speaker)
            return
        if not party.flags.get(StorySettings.BOAT_ASKED):
            party.flags[StorySettings.BOAT_ASKED] = True
            for line in StorySettings.BOAT_ASK_LINES:
                self.text_box.push(line, speaker=speaker)
            return
        if not party.flags.get(StorySettings.BOAT_WOOD_FLAG):
            have = bag.get("wood", 0)
            if have < StorySettings.BOAT_WOOD:
                self.text_box.push(StorySettings.BOAT_MORE_WOOD.format(have=have), speaker=speaker)
                return
            bag["wood"] = have - StorySettings.BOAT_WOOD
            if not bag["wood"]:
                del bag["wood"]
            party.flags[StorySettings.BOAT_WOOD_FLAG] = True
            self.gm.audio.play("chest_open")
            self.text_box.push(f"Kailo gave Ama {StorySettings.BOAT_WOOD} {ItemSettings.NAMES['wood']}.")
            self.text_box.push(StorySettings.BOAT_TAKES_WOOD, speaker=speaker)
        # A full purse is as near a thousand as it holds (StorySettings, the boat quest).
        if party.pule < min(StorySettings.BOAT_PULE, ShopSettings.PULE_MAX):
            self.text_box.push(StorySettings.BOAT_MORE_PULE, speaker=speaker)
            return
        party.flags[StorySettings.BOAT_FIXED] = True
        party.flags[SailingSettings.READY_FLAG] = True
        for who, line in StorySettings.BOAT_PULE_TALK:
            self.text_box.push(line, speaker=who)

    def _talk_noelani(self, person: dict) -> None:
        """Noelani and the stew (Frankie, 10/30): the first talk she offers and lists what she
        needs. From the second on (Frankie's draft, 11/2) she says one of her own lines, and the
        first time offers to keep what Kailo does not need; then she asks what it is and he picks:
        what the stew still needs (or, with it all in the bag, they cook; with it made, the stew),
        the pule she holds for him, or never mind."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menus below
        from settings import BankSettings
        from systems import bank

        party = self.gm.party
        speaker = StewSettings.SPEAKER
        if not party.flags.get("stew_offered"):
            if stew.cook(party):
                self.gm.audio.play("hit_sparkle_1")
                self.begin_story(StewSettings.SCENE)
                return
            lacking = stew.missing(party)
            party.flags["stew_offered"] = True
            for line in StewSettings.OFFER_LINES:
                self.text_box.push(line, speaker=speaker)
            self.text_box.push(StewSettings.LIST_LINE.format(things=stew.things(lacking)),
                               speaker=StewSettings.LIST_SPEAKER)
            for line in StewSettings.SEND_LINES:
                self.text_box.push(line, speaker=speaker)
            return
        self._take_turn(person, "day", person["lines"])
        if not party.flags.get(bank.OFFERED_FLAG):
            party.flags[bank.OFFERED_FLAG] = True
            self.text_box.push(BankSettings.LEAD_LINE, speaker=speaker)
        self.text_box.push(BankSettings.WHAT_LINE, speaker=speaker)
        asked = bool(party.flags.get(bank.ASKED_FLAG))

        def say(line: str) -> None:
            self.text_box.push(line.format(held=bank.held(party)), speaker=speaker)

        def stew_pick() -> None:
            if stew.made(party):
                say(StewSettings.AFTER_LINE)
            elif stew.cook(party):
                self.gm.audio.play("hit_sparkle_1")
                self.begin_story(StewSettings.SCENE)
            else:
                say(StewSettings.MISSING_LINE.format(things=stew.things(stew.missing(party))))

        def pick(index: int) -> None:
            if index == 0:
                stew_pick()
            elif index == 1:
                party.flags[bank.ASKED_FLAG] = True
                say(BankSettings.ASK)
                self._after_text = self._noelani_bank
            else:
                say(BankSettings.NEVER_LINE)

        def menu() -> None:
            if stew.made(party):
                stew_choice = BankSettings.STEW_CHOICE
            elif stew.missing(party):
                stew_choice = BankSettings.INGREDIENTS_CHOICE
            else:
                stew_choice = BankSettings.STEW_READY_CHOICE
            pule_choice = BankSettings.PULE_CHOICE if asked else BankSettings.PULE_FIRST_CHOICE
            self.gm.scene_stack.push(ChoiceScene(
                self.gm, speaker, [stew_choice, pule_choice, BankSettings.NEVER_CHOICE], pick))
        self._after_text = menu

    def _noelani_bank(self) -> None:
        """Noelani holds pule for Kailo (Frankie, 11/1; ``systems/bank.py``): leave some, take some back."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menus below
        from settings import BankSettings
        from systems import bank

        party, speaker = self.gm.party, StewSettings.SPEAKER

        def say(line: str) -> None:
            self.text_box.push(line.format(held=bank.held(party)), speaker=speaker)

        def amounts(ask: str, choices: list, act, done: str, empty: str, can) -> None:
            if not can():
                say(empty)
                return

            def pick(index: int) -> None:
                amount = choices[index][1]
                if amount == 0:
                    return
                if act(party, amount):
                    self.gm.audio.play("hit_sparkle_1")
                say(done)
            self.gm.scene_stack.push(ChoiceScene(self.gm, ask, [c[0] for c in choices], pick))

        def pick(index: int) -> None:
            if index == 0:
                amounts(BankSettings.LEAVE_ASK, BankSettings.LEAVE_CHOICES, bank.leave, BankSettings.LEFT,
                        BankSettings.NONE_LEFT, lambda: party.pule > 0)
            elif index == 1:
                from settings import ShopSettings
                if bank.held(party) and party.pule >= ShopSettings.PULE_MAX:
                    say(BankSettings.FULL)
                    return
                amounts(BankSettings.TAKE_ASK, BankSettings.TAKE_CHOICES, bank.take, BankSettings.TOOK,
                        BankSettings.NONE_HELD, lambda: bank.held(party) > 0)

        self.gm.scene_stack.push(ChoiceScene(self.gm, speaker, BankSettings.CHOICES, pick))

    def _hina_says_wait(self) -> None:
        """The first planting, Hina says they can go do something else while it grows (Frankie, 10/30)."""
        lesson = garden.wait_lesson(self.gm.party)
        if lesson is not None:
            speaker, line = lesson
            self.text_box.push(line, speaker=speaker)

    def _faced_patch(self) -> int | None:
        """The garden patch on the tile the player faces, by its index in the room, or None."""
        dx, dy = self.player.facing
        return self.world.patch_tiles.get((self.player.col + dx, self.player.row + dy))

    def _tend(self, index: int) -> None:
        """One press, one thing (Frankie, 10/23): pick the patch, or ask to replant it or grow it faster."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        pressed = garden.press(self.gm.party, self.world.current_cell_name, index)
        if pressed.line is not None:
            if pressed.line.startswith("Picked"):
                self.gm.audio.play("hit_sparkle_1")
            self.text_box.push(pressed.line)
        if pressed.offer is not None:
            speaker, line = pressed.offer
            self.text_box.push(line, speaker=speaker)
        if pressed.question is None:
            return

        def yes() -> None:
            self.gm.audio.play("hit_sparkle_1")
            for line in pressed.yes():
                self.text_box.push(line)
            replanted = pressed.question.startswith(GardenSettings.REPLANT_BOX.split("{")[0])
            # The first planting with Maika and Hina along, he teaches her Seed (Frankie, 10/24),
            # and only then does Hina say it takes a while.
            if replanted and self._seed_lesson_due():
                self.begin_story(StorySettings.SEED_SCENE)
            elif replanted:
                self._hina_says_wait()

        def choose(answer: int) -> None:
            """A farm patch's crop (Frankie, 10/29)."""
            planted = answer < len(pressed.choices) - 1
            for line in pressed.pick(answer):
                self.text_box.push(line)
            if planted:
                self.gm.audio.play("hit_sparkle_1")
                if self._seed_lesson_due():
                    self.begin_story(StorySettings.SEED_SCENE)
                else:
                    self._hina_says_wait()

        def ask() -> None:
            if pressed.choices is not None:
                from core.scenes.choice_scene import ChoiceScene
                self.gm.scene_stack.push(ChoiceScene(self.gm, pressed.question, pressed.choices, choose))
                return
            self.gm.scene_stack.push(ConfirmScene(self.gm, pressed.question, on_yes=yes))
        if self.text_box.is_done():
            ask()
        else:
            self._after_text = ask

    def _open_chest(self) -> None:
        """A chest (Frankie, 10/24): its item in the bag the first time, then it is empty.

        A chest with ``random`` instead holds one of ``ItemSettings.CHEST_RANDOM``,
        picked when it is opened (Frankie, 10/25): a weapon or relic, or a
        goodie, which may be pule. His dad's chest (Frankie, 10/26) holds
        several: its ``item``, the ``also`` list, and ``random`` picked a
        number of times in the ``picks`` range; Kailo says its ``before``
        line, then it opens.
        """
        dx, dy = self.player.facing
        chest = self.world.building_at(self.player.col + dx, self.player.row + dy)
        flag = chest_flag(self.world.current_cell_name, chest)
        items = chest_items(chest)
        if self.gm.party.flags.get(flag) or not items:
            self.text_box.push(StorySettings.CHEST_EMPTY)
            return
        self.gm.party.flags[flag] = True
        if chest.get("before"):
            self.text_box.push(chest["before"], speaker="Kailo")
            self._after_text = lambda: self._take_from_chest(chest, items)
        else:
            self._take_from_chest(chest, items)

    def _take_from_chest(self, chest: dict, items: list[str]) -> None:
        """The chest opens: ``items`` go in the bag (pule in the purse), each said, then its ``line``."""
        from settings import ItemSettings

        self.gm.audio.play("chest_open")
        for item in items:
            if item == "pule":
                self.gm.party.pule += ItemSettings.CHEST_PULE
                self.text_box.push(StorySettings.CHEST_FOUND.format(item=f"{ItemSettings.CHEST_PULE} pule"))
            elif tools.is_tool(item):
                # A tool is a key item; an upgrade replaces the one before it (Frankie, 10/28).
                tools.take(self.gm.party, item)
                self.text_box.push(StorySettings.CHEST_FOUND.format(item=ItemSettings.NAMES.get(item, item)))
            else:
                self.gm.party.inventory[item] = self.gm.party.inventory.get(item, 0) + 1
                self.text_box.push(StorySettings.CHEST_FOUND.format(item=ItemSettings.NAMES.get(item, item)))
        if chest.get("line"):
            self.text_box.push(chest["line"], speaker="Kailo")

    def _open_pot(self) -> None:
        """The pot inside Kailo's house opens the crafting pot, the only place to craft (Frankie, 10/24)."""
        from core.scenes.craft_scene import CraftScene  # local: cycle.

        self.gm.audio.play("menu_select")
        self.gm.scene_stack.push(CraftScene(self.gm))

    def _count_steps(self) -> None:
        """Count a step for the garden each time the player stands on a new tile."""
        here = (self.world.current_pos, self.player.col, self.player.row)
        if self._last_tile is not None and here != self._last_tile:
            garden.walked(self.gm.party)
        self._last_tile = here

    def _render_patches(self, surface: pygame.Surface) -> None:
        """Draw each patch in the room by how far it has grown."""
        tile_size = GridSettings.TILE_SIZE
        for index, patch in enumerate(garden.patches_in(self.world.current_cell_name)):
            sheet = _patch_sheet(garden.plant_of(self.world.current_cell_name, index, self.gm.party))
            x = OverworldSettings.X + patch["col"] * tile_size
            y = OverworldSettings.Y + patch["row"] * tile_size
            stage = garden.stage(self.gm.party, self.world.current_cell_name, index)
            if sheet is None:
                pygame.draw.rect(surface, ColorSettings.OVERWORLD_SAND, (x, y, tile_size, tile_size))
                continue
            surface.blit(sheet, (x, y), (stage * tile_size, 0, tile_size, tile_size))

    def _rest(self, line: str = TownSettings.POND_LINE) -> None:
        """Drink from the pond, or nap in Kailo's bed: everyone standing back to full HP (D-525).

        The knocked out stay down, and neither saves (Frankie, 10/26): only a totem does both.
        Every beaten monster comes back (Frankie, 10/28).
        """
        field_respawn.bring_back_all(self.gm.party)
        for member in self.gm.party.members:
            if member.current_hp > 0:
                member.current_hp = member.max_hp
        self.gm.audio.play("hit_sparkle_1")
        self.text_box.push(line)

    def _pray(self) -> None:
        """Pray at an Akua totem (Frankie, 10/26): tell the Akua all that has happened,
        as Dragon Quest's confession, the fallen get back up at full HP, then save.

        The first time Hina explains, or Kailo with her away. No status outlasts a
        fight yet, so there is no zombie or curse here to lift.
        """
        flags = self.gm.party.flags
        if not flags.get(TownSettings.TOTEM_FLAG):
            flags[TownSettings.TOTEM_FLAG] = True
            speaker = "Hina" if self.gm.party.find("hina") is not None else StorySettings.PLAYER
            for line in TownSettings.TOTEM_FIRST[speaker]:
                self.text_box.push(line, speaker=speaker)
        self.text_box.push(TownSettings.PRAY_LINE)
        fallen = [m for m in self.gm.party.members if m.current_hp <= 0]
        for member in fallen:
            member.current_hp = member.max_hp
        self.gm.audio.play("hit_sparkle_1")
        if fallen:
            self.text_box.push(TownSettings.REVIVE_LINE)
        self._after_text = self._ask_save

    def _ask_save(self) -> None:
        """After praying at a totem, the save point: YES opens the three slots; NO, nothing."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below
        from core.scenes.save_slot_scene import SaveSlotScene

        self.gm.scene_stack.push(ConfirmScene(
            self.gm, TownSettings.SAVE_BOX,
            on_yes=lambda: self.gm.scene_stack.push(SaveSlotScene(self.gm, loading=False)),
        ))

    def update(self, dt: float) -> None:
        """A frame of the field, or of a scene being skipped (``skip_cutscene``)."""
        if self.skipping is not None:
            self._skip_ahead()
            return
        self._frame(dt)

    def _frame(self, dt: float) -> None:
        """Tick the text box, then advance the player if no text is showing.

        After advancing the player, any newly-completed steps roll for
        a random encounter; on a hit a ``BattleScene`` is pushed on
        top of this scene. The overworld resumes automatically when
        the battle pops, since this scene was never destroyed.

        Args:
            dt: Frame time in seconds.
        """
        self._room_sound()
        self._end_visit()
        self._swing = max(0.0, self._swing - dt)
        if self._dug and self.world.current_cell_name != self._dug_room:
            self._dug = set()  # the holes fill in when Kailo leaves the room
        self._shake_left = max(0.0, self._shake_left - dt)
        if self._chop_at is not None and self._faced_tree() != self._chop_at:
            self._chop_at, self._chops = None, 0  # walked off mid-chop: the count starts over (Frankie, 10/29)
        self._since_draw += dt
        self._watch_place(dt)
        # A room is found once Kailo stands in it, not while a scene is acted out (the area map).
        if self.stage is None:
            self.world.seen.add(self.world.current_cell_name)
        self.text_box.update(dt)
        ids = [member.id for member in self.gm.party.members]
        if ids and self.player.walker not in ids:
            self.player.walker = ids[0]   # whoever walked has left the party
        self._tick_opening()
        if self.stage is not None:
            self.stage.update(dt)
        self._tick_fade(dt)
        if self._card is not None or not self.text_box.is_done():
            return
        if self._after_text is not None:
            action, self._after_text = self._after_text, None
            action()
            return
        if self.story is not None:
            self._play_story()
            return
        self._watch_sparring(dt)
        if not self.text_box.is_done():
            return
        self._place_monsters()
        self.tool_wheel.update(dt, input_map.read_held_direction(self.gm.connected_joysticks), self.gm.party)
        if self._walk_back and not self.player._step_active:
            self.player._begin_step(*self._walk_back.pop())
        elif not self.tool_wheel.open and self._swing <= 0 and self._reel is None:
            # The d-pad picks on the open wheel, and mid-swing he is stuck in
            # the chop; either way Kailo stands still, the monsters do not.
            self.player.update(dt)
        self._count_steps()
        self._tick_fishing(dt)
        lore.unlock_items(self.gm.party)
        self._wander_people(dt)
        if self._dead_end():
            return
        if self._hina_catches_up():
            self.begin_story(StorySettings.WOODS_SCENE)
            return
        if self._wake_ask_due():
            self._ask_wake()
            return
        warning = self._deep_woods_warning()
        if warning is not None:
            self.begin_story(warning)
            return
        turned = self._sage_village_turn()
        if turned is not None:
            self.begin_story(turned)
            return
        # Walking into the Great Boar: are you ready? Once each time they walk up.
        boss = self._asker_in_reach()
        if boss is None:
            self._asked = False
        elif not self._asked and not self.player._step_active and not self._walk_back:
            self._asked = True
            self._asking = boss
            self.begin_story(StorySettings.ASK_SCENE)
            return
        self._place_monsters()
        self._grace = max(0.0, self._grace - dt)
        for monster in self.monsters:
            taken = set().union(*(m.tiles() for m in self.monsters if m is not monster))
            if self._grace > 0:
                # The monster left standing waits for the party to walk off.
                taken.add((self.player.col, self.player.row))
            chase = None if self._grace > 0 else (self.player.col, self.player.row)
            monster.update(dt, self.world, taken, chase)
        # Started from the Workshop with fights off, the monsters walk
        # but never start one, so a room can be looked over in peace.
        if self._grace <= 0 and not getattr(self.gm, "no_fights", False):
            for monster in self.monsters:
                if monster.spot.get("kind") == StorySettings.ASK_KIND:
                    continue
                if (self.player.col, self.player.row) in monster.tiles():
                    self._start_fight(monster)
                    return

    def _tick_fade(self, dt: float) -> None:
        """Take the screen's darkness toward where a Fade sends it, and count down a Wait."""
        self._wait = max(0.0, self._wait - dt)
        if self._fade_to is None:
            return
        step = dt / StorySettings.FADE_SECONDS
        if self._fade_to > self._dark:
            self._dark = min(self._fade_to, self._dark + step)
        else:
            self._dark = max(self._fade_to, self._dark - step)
        if self._dark == self._fade_to:
            self._fade_to = None

    def _render_dark(self, surface: pygame.Surface) -> None:
        """The fade, as the Super Nintendo's master brightness in its sixteen steps; and on
        black at the end, the demo's last words."""
        level = round(self._dark * StorySettings.FADE_STEPS) / StorySettings.FADE_STEPS
        if level > 0:
            veil = pygame.Surface(surface.get_size())
            veil.set_alpha(round(level * 255))
            surface.blit(veil, (0, 0))
        if self._card:
            from ui import text_renderer  # local: only the end needs it

            size = StorySettings.CARD_SIZE
            width = text_renderer.text_width(self._card, size)
            text_renderer.draw_text(surface, self._card, ((surface.get_width() - width) // 2,
                                    (surface.get_height() - text_renderer.line_height(size)) // 2), size=size)
            # The card waits for a press to go to the title: the marker says so.
            draw_continue_marker(surface, (surface.get_width() // 2, surface.get_height() - 12))

    def _take_turn(self, person: dict, which: str, lines: list) -> int | None:
        """The next of a person's ``lines``, one a talk, round and round, never all in a row
        (Frankie, 10/26). ``which`` names the set, by day, at night or a flag's, each with its
        own place in the round, so a new set starts at its first line. Returns the index said.

        A line can be a ``talk`` exchange, one thought over several boxes or a back-and-forth
        with Kailo, played whole as one turn. With ``once`` too, it plays the first time, and
        its flag drops it from the round for good (Melia asking about Kailo's dad, Frankie, 10/25).
        """
        flags = self.gm.party.flags if self.gm.party else {}
        turn = person.setdefault("turn", {}).get(which, 0)
        for step in range(len(lines)):
            index = (turn + step) % len(lines)
            line = lines[index]
            if not (isinstance(line, dict) and flags.get(line.get("once"))):
                break
        else:
            return None
        person["turn"][which] = index + 1
        if isinstance(line, dict) and line.get("once") and self.gm.party:
            self.gm.party.flags[line["once"]] = True
        self._say(person, line)
        return index

    def _say(self, person: dict, line) -> None:
        """One of a person's lines: a plain line under their ``speaker``, or a ``talk``
        exchange, a row with a third word only with that member along (Kailo
        answering Keo, Frankie, 10/26)."""
        if not isinstance(line, dict):
            self.text_box.push(line, speaker=person["speaker"])
            return
        for speaker, said, *along in line["talk"]:
            if not along or (self.gm.party and self.gm.party.find(along[0]) is not None):
                self.text_box.push(said, speaker=speaker)

    def _end_visit(self) -> None:
        """Leaving a room by one of a found person's ``leaves_by`` sides sends them home:
        Melia, found, goes back to the pots by Kailo's house once he walks off north or east
        (Frankie, 10/25)."""
        here = self.world.current_cell_name
        if here == self._visiting:
            return
        rooms = {name: pos for pos, name in self.world.layout.items()}
        was, now = rooms.get(self._visiting), rooms.get(here)
        side = [now[0] - was[0], now[1] - was[1]] if was and now else None
        flags = self.gm.party.flags if self.gm.party else {}
        for person in PEOPLE.get(self._visiting, []):
            if side in person.get("leaves_by", []) and flags.get(person["first"]["flag"]):
                flags[person["until"]] = True
        self._visiting = here

    def _room_sound(self) -> None:
        """Each room's song, going on unbroken from room to room while it is the same
        (Frankie, 10/23; as the cartridge's room_sound): all through the town, its buildings
        too, and the harbor, Kulāiwi with the surf under it by day once the taro patch is over,
        else the surf alone (Frankie, 10/27); quiet everywhere else at night
        (the Great Boar beaten); by day The Big Bad in his room, The Forgotten Wilds in the
        generated deep forest (Frankie, 10/26) and the woods' song in the rest; Regrets all through Pono's wake, but for a scene's Song (Tawiri's theme), and
        nothing from its Song: none to its End's words (Frankie, 10/27)."""
        if self._card is not None:
            self.gm.audio.play_screen(AudioSettings.SILENT)
        elif self.story is not None and self.story.song:
            self.gm.audio.play_screen(self.story.song)
        else:
            self.gm.audio.play_screen(self._room_screen())

    def _room_screen(self) -> str:
        """The room's song (``_room_sound``) with no Song over it."""
        name = self.world.current_cell_name
        within = lambda rooms: name in rooms or any(
            b.get("inside") == name for room in rooms for b in BUILDINGS.get(room, []))
        if self.story is not None and self.story.name == "wake":
            screen = "wake"
        elif name in AudioSettings.ROOM_SONGS and not self.is_night():
            # Frankie's own song for the grove and the temple (11/3).
            screen = AudioSettings.ROOM_SONGS[name]
        elif within(AudioSettings.BEACH_ROOMS + AudioSettings.HARBOR_ROOMS):
            taro = self.gm.party and self.gm.party.flags.get(StorySettings.TARO_FLAG)
            screen = "village" if taro and not self.is_night() else "beach"
        elif name in AudioSettings.LODGE_ROOMS and not self.is_night():
            # The hunters' lodge keeps the woods' song going (Frankie, 11/1), not the silence of a house.
            screen = "woods"
        elif self.world.current_pos[1] >= INSIDE_ROW or self.is_night():
            screen = "quiet"
        elif name == StorySettings.SEED_ROOM:
            screen = "great_boar"
        elif name in generated.INSTALLED:
            screen = "deep_woods"
        else:
            screen = "woods"
        return screen

    def _watch_sparring(self, dt: float) -> None:
        """The villagers' sparring, silent (Frankie, 10/23): 30 seconds watching, once, teaches Kailo.

        Watching is standing next to one of them, facing them, with nothing
        pressed; a step or a turn away starts the count again.
        """
        if not any(person.get("spar") for person in self.world.people):
            self._idle = 0.0
            return
        if self.player._step_active or not self._faced_person().get("spar"):
            self._idle = 0.0
            return
        self._idle += dt
        if self._idle < TownSettings.WATCH_SECONDS or self.gm.party.flags.get(TownSettings.WATCH_FLAG):
            return
        member = self.gm.party.find(TownSettings.WATCH_MEMBER)
        if member is None:
            return
        self.gm.party.flags[TownSettings.WATCH_FLAG] = True
        for stat, points in TownSettings.WATCH_GROWTH.items():
            member.growth[stat] = member.growth.get(stat, 0) + points
        member.refresh_stats()
        self.gm.audio.play("learned")
        for line in TownSettings.WATCH_LINES:
            self.text_box.push(line)

    def _place_monsters(self) -> None:
        """Put the cell's monsters out when the party arrives in a cell (D-576)."""
        if self._monsters_cell == self.world.current_pos:
            return
        self._monsters_cell = self.world.current_pos
        self._grace = 0.0
        kinds = self.gm.data.load("field_monsters")
        cell_name = self.world.current_cell_name
        self.monsters = [
            FieldMonster(spot, kinds[spot["kind"]])
            for index, spot in enumerate(FIELD_MONSTERS.get(cell_name, []))
            if not (spot.get("boss") and self.gm.party.flags.get(_boss_flag_for(cell_name, spot)))
            and not field_respawn.is_gone(self.gm.party, cell_name, index)
            # A night monster walks only at night (the Sigbin, Frankie, 10/28).
            and (not spot.get("night") or self.is_night())
        ]

    def _in_town(self) -> bool:
        """Whether the party stands in one of the town's rooms, where a fight is on the beach."""
        return self.world.current_cell_name in BackgroundSettings.TOWN_ROOMS

    def _who_caught(self, monster: FieldMonster) -> str | None:
        """Who caught whom (Frankie, 10/27): walking into a monster's back or side is a
        preemptive strike, one stepping into Kailo's back an ambush, anything else a plain fight
        (ambushes from the side too came in nearly every forest fight of the 10/27 Let's Play,
        a chasing monster most often turning in at his side; Frankie, 10/27: back only).

        A monster faces only left or right, so above and below are its sides. Both
        stepping at once, or neither, is a plain fight.
        """
        kailo_stepped = self.player._step_active
        it_stepped = monster._progress < 1.0
        if kailo_stepped == it_stepped:
            return None
        if kailo_stepped:
            dx, dy = self.player.facing
            front = (-1, 0) if monster.facing_left else (1, 0)
            return None if (-dx, -dy) == front else "preemptive"
        mx, my = monster.col - monster._from[0], monster.row - monster._from[1]
        came_from = (-(mx > 0) + (mx < 0), -(my > 0) + (my < 0))
        behind = tuple(-d for d in self.player.facing)
        return "ambush" if came_from == behind else None

    def _start_fight(self, monster: FieldMonster) -> None:
        """Push the fight ``monster`` brings, and remember whose it is."""
        # Local import: ``BattleScene`` lives in a sibling scene file
        # and importing it at the top would risk a cycle the moment a
        # battle ever needs to read overworld state on the way out.
        from core.scenes.battle_scene import BattleScene, compose_fight

        battle = BattleScene(self.gm, enemies=compose_fight(monster.kind), in_town=self._in_town(),
                             opening=self._who_caught(monster))
        self._fighting = (monster, battle)
        self.gm.scene_stack.push(battle)

    def render(self, surface: pygame.Surface) -> None:
        """Paint background, cell tiles, player, and message box in that order.

        Args:
            surface: The screen surface to draw onto.
        """
        if self.skipping is not None:
            # A scene being skipped plays behind black.
            surface.fill(ColorSettings.BLACK)
            return
        render_scene_background(self, surface)
        offset = room_offset(self.world.current_grid)
        room = surface
        if offset != (0, 0):
            # A room smaller than the screen is drawn whole and then moved to the middle.
            if self._room_layer is None or self._room_layer.get_size() != surface.get_size():
                self._room_layer = pygame.Surface(surface.get_size())
            room = self._room_layer
        self._render_cell(room)
        self._render_patches(room)
        cell_name = self.world.current_cell_name
        for building in self.world.buildings:
            opened = (building["kind"] == "chest"
                      and bool(self.gm.party.flags.get(chest_flag(cell_name, building))))
            draw_building(room, building, OverworldSettings.X, OverworldSettings.Y, opened)
            draw_sunk(room, self.world.current_grid, building, OverworldSettings.X, OverworldSettings.Y)
        self._render_people(room)
        for monster in self.monsters:
            monster.render(room)
        # While a scene is on the stage, Kailo is only where it puts him: in a
        # room he is not staged in (the wake's cutaway to Melia) he is not there.
        if self.stage is not None:
            self.stage.render(room)
        elif self._line is None or not self.player.render_fishing(
                room, self._reel.left if self._reel is not None else max(0.0, self._line[2])):
            self.player.render(room)
        for building in self.world.buildings:
            draw_rising(room, building, OverworldSettings.X, OverworldSettings.Y)
        if room is not surface:
            surface.fill(walls.DARK)
            surface.blit(room, offset)
        self._render_night(surface)
        if self.stage is None and self.story is None and self._card is None and not self._opening:
            render_corner(surface, self.gm.party, self.tool_wheel)
            tile = GridSettings.TILE_SIZE
            middle = (OverworldSettings.X + self.player.col * tile + tile // 2 + offset[0],
                      OverworldSettings.Y + self.player.row * tile + tile // 2 + offset[1])
            self.tool_wheel.render(surface, middle, self.gm.party)
        # The opening's words stay lit as the beach fades in under them, and words on a
        # black screen ("The next morning.") are read on it, not under it (Frankie, 11/1).
        lit = self._opening or self._dark >= 1.0
        if not lit:
            self.text_box.render(surface)
        self._render_popup(surface)
        if self._reel is not None:
            below = OverworldSettings.Y + self.player.row * GridSettings.TILE_SIZE + offset[1] > surface.get_height() // 2
            render_reel(surface, self._reel, not self.gm.party.flags.get(FishingSettings.REEL_HINT_FLAG), below)
        self._render_dark(surface)
        if lit:
            self.text_box.render(surface)

    # ------------------------------------------------------------------
    # INTERNAL HELPERS
    # ------------------------------------------------------------------

    def _render_cell(self, surface: pygame.Surface) -> None:
        """Draw the active cell's tile grid, one picture per tile.

        Args:
            surface: The screen surface to draw onto.
        """
        grid = self.world.current_grid
        tile_size = GridSettings.TILE_SIZE
        tiles = _tiles()
        for row in range(OverworldSettings.ROWS):
            row_cells = grid[row]
            for col in range(OverworldSettings.COLS):
                char = row_cells[col]
                x = OverworldSettings.X + col * tile_size
                y = OverworldSettings.Y + row * tile_size
                if not tiles:
                    color = _TILE_COLORS.get(char, ColorSettings.OVERWORLD_FLOOR)
                    pygame.draw.rect(surface, color, (x, y, tile_size, tile_size))
                    continue
                if self._shake == (col, row) and self._shake_left > 0:
                    # The chopped tree shakes: its picture steps side to side over the grass.
                    steps = ToolSettings.SHAKE_PIXELS
                    done = 1 - self._shake_left / ToolSettings.SHAKE_SECONDS
                    nudge = steps[min(len(steps) - 1, int(done * len(steps)))]
                    surface.blit(_pick(tiles[OverworldSettings.FLOOR_CHAR], col, row), (x, y))
                    surface.blit(_pick(tiles[char], col, row), (x + nudge, y))
                    continue
                draw_tile(surface, grid, col, row, (x, y), tiles)
                if (col, row) in self._dug and self._dug_room == self.world.current_cell_name:
                    hole = _hole_picture()
                    if hole is not None:
                        surface.blit(hole, (x, y))

    def _wander_people(self, dt: float) -> None:
        """Villagers with ``wander`` stroll a few tiles from their spot (Frankie, 10/26).

        Each rests a while, then tries one step in a random direction: never off
        the room, onto a wall, a building, someone else, the party or the tile
        Kailo faces, and never further from where the room file puts them than
        ``wander`` tiles. Beside Kailo they hold still, so he can talk to them
        (Frankie, 10/26); talking, they turn to him and nobody walks.
        """
        dx, dy = self.player.facing
        kailo = (self.player.col, self.player.row)
        faced = (kailo[0] + dx, kailo[1] + dy)
        for person in self.world.people:
            reach = person.get("wander")
            if not reach:
                continue
            person.setdefault("_home", (person["col"], person["row"]))
            if person.get("_t", 1.0) < 1.0:
                person["_t"] = min(1.0, person["_t"] + dt * 1000 / TownSettings.WANDER_STEP_MS)
                continue
            if abs(person["col"] - kailo[0]) + abs(person["row"] - kailo[1]) == 1:
                continue
            person["_wait"] = person.get("_wait", random.uniform(*TownSettings.WANDER_WAIT_RANGE)) - dt
            if person["_wait"] > 0:
                continue
            person["_wait"] = random.uniform(*TownSettings.WANDER_WAIT_RANGE)
            dc, dr = random.choice(((1, 0), (-1, 0), (0, 1), (0, -1)))
            col, row = person["col"] + dc, person["row"] + dr
            home = person["_home"]
            if (not (0 <= col < OverworldSettings.COLS and 0 <= row < OverworldSettings.ROWS)
                    or self.world.is_wall(col, row) or (col, row) in (kailo, faced)
                    or abs(col - home[0]) + abs(row - home[1]) > reach):
                continue
            person["_from"] = (person["col"], person["row"])
            person["col"], person["row"], person["facing"] = col, row, [dc, dr]
            person["_t"] = 0.0

    def _render_people(self, surface: pygame.Surface) -> None:
        """Draw everyone in the cell: standing, or part way along a wandering step."""
        tile_size = GridSettings.TILE_SIZE
        column = OverworldPlayerSettings.SHEET_COLUMNS
        for person in self.world.people:
            if self.stage is not None and self.stage.hides(person):
                continue
            if person.get("sits"):
                self._render_sitter(surface, person)
                continue
            if person.get("hen"):
                self._render_hen(surface, person)
                continue
            sheet = _person_sheet(person["sheet"])
            if sheet is None:
                continue
            t = person.get("_t", 1.0)
            # The feet move while they step; standing is the first frame.
            step = int(t * OverworldPlayerSettings.WALK_FRAMES) if t < 1.0 else 0
            frame = sheet.subsurface(pygame.Rect(
                column.get(tuple(person["facing"]), 0) * tile_size,
                min(step, sheet.get_height() // tile_size - 1) * tile_size, tile_size, tile_size,
            ))
            from_col, from_row = person.get("_from", (person["col"], person["row"]))
            surface.blit(frame, (
                OverworldSettings.X + round((from_col + (person["col"] - from_col) * t) * tile_size),
                OverworldSettings.Y + round((from_row + (person["row"] - from_row) * t) * tile_size),
            ))

    @staticmethod
    def _render_hen(surface: pygame.Surface, person: dict) -> None:
        """A hen (Frankie, 10/28): her two frames by turns, flipped when she faces right."""
        sheet = _person_sheet(person["sheet"], HenSettings.SHEET)
        if sheet is None:
            return
        tile_size = GridSettings.TILE_SIZE
        frame = int(pygame.time.get_ticks() / 1000 / HenSettings.FRAME_SECONDS) % 2
        picture = sheet.subsurface(pygame.Rect(frame * tile_size, 0, tile_size, tile_size))
        if person["facing"][0] > 0:
            picture = pygame.transform.flip(picture, True, False)
        t = person.get("_t", 1.0)
        from_col, from_row = person.get("_from", (person["col"], person["row"]))
        surface.blit(picture, (
            OverworldSettings.X + round((from_col + (person["col"] - from_col) * t) * tile_size),
            OverworldSettings.Y + round((from_row + (person["row"] - from_row) * t) * tile_size),
        ))

    @staticmethod
    def _render_sitter(surface: pygame.Surface, person: dict) -> None:
        """Someone sitting, who never walks (the Kaigara Kame): their picture, now and then a blink."""
        sheet = _person_sheet(person["sheet"], KaigaraSettings.SIT_SHEET)
        if sheet is None:
            return
        tile_size = GridSettings.TILE_SIZE
        blink = pygame.time.get_ticks() / 1000 % KaigaraSettings.BLINK_EVERY < KaigaraSettings.BLINK_SECONDS
        frame = sheet.subsurface(pygame.Rect(tile_size if blink else 0, 0, tile_size, tile_size))
        surface.blit(frame, (OverworldSettings.X + person["col"] * tile_size,
                             OverworldSettings.Y + person["row"] * tile_size))

    def _open_menu(self) -> None:
        """Push the translucent system menu on top of this scene."""
        # Local import: ``MenuScene`` lives in a sibling scene module
        # and importing it at top of file would risk a cycle if the
        # menu ever pushes overworld-aware actions later.
        from core.scenes.menu_scene import MenuScene

        self.gm.scene_stack.push(MenuScene(self.gm))

    def _open_map(self) -> None:
        """SELECT: the area map, of the rooms found, with Kailo where he stands (Frankie, 10/26)."""
        from core.scenes.map_scene import MapScene  # local: as the menu

        self.world.seen.add(self.world.current_cell_name)
        self.gm.scene_stack.push(MapScene(self.gm, self.world.seen, self.world.current_cell_name,
                                          self.player.col, self.player.row))

    # ------------------------------------------------------------------
    # PERSISTENCE
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Serialise the active cell pointer and the player's tile state."""
        base = super().to_dict()
        base["world"] = self.world.to_dict()
        base["player"] = self.player.to_dict()
        return base

    @classmethod
    def from_dict(cls, gm: "GameManager", data: dict) -> "OverworldScene":
        """Rebuild a scene from a previously-saved dict.

        Args:
            gm: The host game manager.
            data: The dict previously returned by ``to_dict``.

        Returns:
            A fully-restored ``OverworldScene``.
        """
        scene = cls(gm)
        if isinstance(data, dict):
            world_data = data.get("world")
            if isinstance(world_data, dict):
                scene.world.from_dict(world_data)
            player_data = data.get("player")
            if isinstance(player_data, dict):
                scene.player.from_dict(player_data)
            if getattr(scene.world, "moved_from_gone_room", False):
                scene._step_off_things()
        return scene

    def _step_off_things(self) -> None:
        """If the party stands on something (a save from a room since rearranged),
        move it to the nearest open tile."""
        start = (self.player.col, self.player.row)
        seen, queue = {start}, [start]
        while queue:
            col, row = queue.pop(0)
            inside = 0 <= col < OverworldSettings.COLS and 0 <= row < OverworldSettings.ROWS
            if inside and not self.world.is_wall(col, row):
                if (col, row) != start:
                    self.player.from_dict({"col": col, "row": row})
                return
            for dc, dr in ((0, 1), (0, -1), (1, 0), (-1, 0)):
                nxt = (col + dc, row + dr)
                if nxt not in seen and 0 <= nxt[0] < OverworldSettings.COLS and 0 <= nxt[1] < OverworldSettings.ROWS:
                    seen.add(nxt)
                    queue.append(nxt)
