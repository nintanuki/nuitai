"""The overworld — sprite walks a tile grid, message box at the bottom.

The Layer-3 destination scene, kicked off early so it can advance in
parallel with the Layer-1 text demo / battle polish. Owns three
collaborators: a ``World`` (cell layout + active-cell pointer), an
``OverworldPlayer`` (logical position + sprite animation + held-input
polling), and a ``TextBox`` (the existing widget, reused unchanged for
the bottom message panel).

What is and is not here in Pass 1:

* **Walking, cell transitions, save/load round-trip** — yes.
* **System-menu push on Tab / START** — yes (re-uses ``MenuScene``).
* **NPCs, dialogue triggers, signs, warp tiles, encounters** — Pass 2.
* **Animated walk cycle, real sprite art** — Pass 2.

The cell area draws one 16 pixel picture per tile, chosen by the cell
char (``OverworldSettings.TILE_PICTURES``), from Mini World Sprites.
Without the pictures a flat colour per char stands in.

See [docs/design/overworld.md](../../docs/design/overworld.md) for the
full design rationale.
"""

from __future__ import annotations

import os
import random
from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from core.world import World
from entities.overworld_player import OverworldPlayer
from settings import (
    AssetPaths,
    ColorSettings,
    EncounterSettings,
    GridSettings,
    OverworldSettings,
)
from ui import input_map
from ui.text_box import TextBox
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager


# Stand-in colour per cell char, used when the tile pictures are missing.
_TILE_COLORS: dict[str, tuple[int, int, int]] = {
    OverworldSettings.FLOOR_CHAR: ColorSettings.OVERWORLD_FLOOR,
    OverworldSettings.WALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.WATER_CHAR: ColorSettings.OVERWORLD_WATER,
    OverworldSettings.SAND_CHAR: ColorSettings.OVERWORLD_SAND,
}

# Tile pictures by cell char, loaded on first use. ``{}`` means the
# pictures were looked for and are missing.
_TILES: dict[str, list[pygame.Surface]] | None = None


def _tiles() -> dict[str, list[pygame.Surface]]:
    """Return the choices of 16 pixel picture for each cell char."""
    global _TILES
    if _TILES is not None:
        return _TILES
    _TILES = {}
    size = GridSettings.TILE_SIZE
    sheets: dict[str, pygame.Surface] = {}
    for char, choices in OverworldSettings.TILE_PICTURES.items():
        pictures = []
        for name, index in choices:
            if name not in sheets:
                path = os.path.join(AssetPaths.TILES_DIR, name)
                if not os.path.exists(path):
                    _TILES = {}
                    return _TILES
                sheets[name] = pygame.image.load(path).convert_alpha()
            sheet = sheets[name]
            pictures.append(sheet.subsurface(pygame.Rect(
                (index * size) % sheet.get_width(),
                (index * size) // sheet.get_width() * size,
                size, size,
            )))
        _TILES[char] = pictures
    return _TILES


def _pick(pictures: list[pygame.Surface], col: int, row: int) -> pygame.Surface:
    """Pick one of ``pictures`` by tile position, the same every time."""
    return pictures[(col * 7 + row * 13 + col * row) % len(pictures)]


class OverworldScene(Scene):
    """The screen-locked, cell-based overworld."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Construct the overworld with its world, player, and text box.

        Args:
            gm: The host game manager. Provides audio, save, and
                cross-scene navigation routing.
        """
        super().__init__(gm)
        self.world = World()
        self.player = OverworldPlayer(gm, self.world)
        # Cell area is narrower than the screen, so size the text box
        # to the full screen width but keep the existing 160-px height.
        self.text_box = TextBox()
        # Encounter pacing. ``_last_seen_step_count`` tracks how many
        # of the player's steps we've already rolled against; the
        # difference between it and ``player.step_count`` each frame
        # is "new steps this update". ``_quiet_steps`` is the running
        # count of consecutive non-encounter steps — it reaches the
        # eligibility threshold and then every subsequent step is a
        # random check against ``EncounterSettings.RATE_PER_STEP``.
        # Reset to zero whenever an encounter pushes a battle so the
        # player gets a guaranteed quiet window when they return.
        self._last_seen_step_count: int = 0
        self._quiet_steps: int = 0

    def on_enter(self) -> None:
        """Play the field's music; the song carries on if it is already playing (back from the menu)."""
        self.gm.audio.play_screen("field")

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Route one event.

        When the text box has content, confirm advances it and other
        keys fall through silently (so a held direction won't queue
        steps that fire the instant the player closes a dialogue).
        Otherwise, Tab / START pushes the system menu; movement is
        polled inside ``player.update`` and does not go through this
        handler.

        Args:
            event: The pygame event to route.
        """
        if not self.text_box.is_done():
            if input_map.is_confirm(event):
                self.text_box.advance()
            return
        if input_map.is_menu(event):
            self._open_menu()

    def update(self, dt: float) -> None:
        """Tick the text box, then advance the player if no text is showing.

        After advancing the player, any newly-completed steps roll for
        a random encounter; on a hit a ``BattleScene`` is pushed on
        top of this scene. The overworld resumes automatically when
        the battle pops, since this scene was never destroyed.

        Args:
            dt: Frame time in seconds.
        """
        self.text_box.update(dt)
        if not self.text_box.is_done():
            return
        self.player.update(dt)
        self._update_encounter_rolls()

    def _update_encounter_rolls(self) -> None:
        """Roll a random encounter once per newly-completed step.

        The player exposes a monotonic ``step_count`` that increments
        each time a step animation finishes; subtracting our last-seen
        value gives the number of new steps to roll against this
        frame. Each new step adds one to ``_quiet_steps``; once the
        running quiet count meets ``EncounterSettings.MIN_QUIET_STEPS``,
        every subsequent step is a Bernoulli trial against
        ``RATE_PER_STEP``. On the first hit, the encounter pushes a
        battle and the quiet counter resets so the player gets a fresh
        eligibility window after the fight.
        """
        new_steps = self.player.step_count - self._last_seen_step_count
        if new_steps <= 0:
            return
        self._last_seen_step_count = self.player.step_count
        for _ in range(new_steps):
            self._quiet_steps += 1
            if self._quiet_steps < EncounterSettings.MIN_QUIET_STEPS:
                continue
            if random.random() < EncounterSettings.RATE_PER_STEP:
                self._trigger_encounter()
                return

    def _trigger_encounter(self) -> None:
        """Push a ``BattleScene`` on top of this scene and reset pacing.

        Pass-2 first cut uses ``BattleScene``'s own random enemy roll
        (the ``_DEMO_ENEMY_IDS`` pool). The encounter table will move
        to per-cell data once cell content migrates to JSON.
        """
        # Local import: ``BattleScene`` lives in a sibling scene file
        # and importing it at the top would risk a cycle the moment a
        # battle ever needs to read overworld state on the way out.
        from core.scenes.battle_scene import BattleScene

        self._quiet_steps = 0
        self.gm.scene_stack.push(BattleScene(self.gm))

    def render(self, surface: pygame.Surface) -> None:
        """Paint background, cell tiles, player, and message box in that order.

        Args:
            surface: The screen surface to draw onto.
        """
        render_scene_background(self, surface)
        self._render_cell(surface)
        self.player.render(surface)
        self.text_box.render(surface)

    # ------------------------------------------------------------------
    # INTERNAL HELPERS
    # ------------------------------------------------------------------

    def _render_cell(self, surface: pygame.Surface) -> None:
        """Draw the active cell's tile grid, one picture per tile.

        Args:
            surface: The screen surface to draw onto.
        """
        grid = self.world.current_grid
        tile_size = GridSettings.TILE_SIZE
        tiles = _tiles()
        floor = OverworldSettings.FLOOR_CHAR
        for row in range(OverworldSettings.ROWS):
            row_cells = grid[row]
            for col in range(OverworldSettings.COLS):
                char = row_cells[col]
                x = OverworldSettings.X + col * tile_size
                y = OverworldSettings.Y + row * tile_size
                if not tiles:
                    color = _TILE_COLORS.get(char, ColorSettings.OVERWORLD_FLOOR)
                    pygame.draw.rect(surface, color, (x, y, tile_size, tile_size))
                    continue
                under = OverworldSettings.TILE_UNDER.get(char)
                if under is not None:
                    surface.blit(_pick(tiles[under], col, row), (x, y))
                surface.blit(_pick(tiles.get(char, tiles[floor]), col, row), (x, y))

    def _open_menu(self) -> None:
        """Push the translucent system menu on top of this scene."""
        # Local import: ``MenuScene`` lives in a sibling scene module
        # and importing it at top of file would risk a cycle if the
        # menu ever pushes overworld-aware actions later.
        from core.scenes.menu_scene import MenuScene

        self.gm.scene_stack.push(MenuScene(self.gm))

    # ------------------------------------------------------------------
    # PERSISTENCE
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Serialise the active cell pointer and the player's tile state."""
        base = super().to_dict()
        base["world"] = self.world.to_dict()
        base["player"] = self.player.to_dict()
        return base

    @classmethod
    def from_dict(cls, gm: "GameManager", data: dict) -> "OverworldScene":
        """Rebuild a scene from a previously-saved dict.

        Args:
            gm: The host game manager.
            data: The dict previously returned by ``to_dict``.

        Returns:
            A fully-restored ``OverworldScene``.
        """
        scene = cls(gm)
        if isinstance(data, dict):
            world_data = data.get("world")
            if isinstance(world_data, dict):
                scene.world.from_dict(world_data)
            player_data = data.get("player")
            if isinstance(player_data, dict):
                scene.player.from_dict(player_data)
        return scene
