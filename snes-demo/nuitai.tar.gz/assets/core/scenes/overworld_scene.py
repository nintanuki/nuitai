"""The overworld — sprite walks a tile grid, message box at the bottom.

The Layer-3 destination scene, kicked off early so it can advance in
parallel with the Layer-1 text demo / battle polish. Owns three
collaborators: a ``World`` (cell layout + active-cell pointer), an
``OverworldPlayer`` (logical position + sprite animation + held-input
polling), and a ``TextBox`` (the existing widget, reused unchanged for
the bottom message panel).

What is and is not here in Pass 1:

* **Walking, cell transitions, save/load round-trip** — yes.
* **System-menu push on Tab / START** — yes (re-uses ``MenuScene``).
* **The pond (D-525), a market stall (D-571) and its keeper (D-574)** — face them and confirm.
* **The town's buildings** stand over the tiles and block; walking up into
  a door goes inside. A nap in Kailo's bed rests the party, as the pond does.
* **People with lines** say them when talked to (Melia, the villagers).
  Two villagers spar in town; standing next to one, facing them, for 30
  seconds with nothing pressed makes Kailo stronger and faster, once.
* **Saving** is only at save points (Frankie, 10/23): after the nap or the
  pond the game asks to save, and YES opens the three slots. Save on the
  menu works only standing next to the bed or the pond.
* **Monsters on the map** (D-576): touching one starts its fight; no
  random encounters.
* **The demo's story** (the demo line in ``game/answers.md``): a new game
  opens on the taro patch scene; the Great Boar beaten, it is night; at
  night Melia asks if they are ready for the wake, whose fight ends the
  demo. The scenes play over the field (``core/story.py``).
* **NPCs, dialogue triggers, signs, warp tiles** — Pass 2.
* **Animated walk cycle, real sprite art** — Pass 2.

The cell area draws one 16 pixel picture per tile, chosen by the cell
char (``OverworldSettings.TILE_PICTURES``), from Mini World Sprites.
Without the pictures a flat colour per char stands in.

See [docs/design/overworld.md](../../docs/design/overworld.md) for the
full design rationale.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from core.overworld_cells import FIELD_MONSTERS, INSIDE_ROW
from core.story import LOSE, StoryRunner
from core.world import World
from systems import garden
from systems.passives import join_line
from entities.field_monster import FieldMonster
from entities.overworld_player import OverworldPlayer
from settings import (
    AssetPaths,
    ColorSettings,
    FieldMonsterSettings,
    GardenSettings,
    GridSettings,
    OverworldPlayerSettings,
    OverworldSettings,
    StorySettings,
    TownSettings,
)
from ui import input_map, shore, walls
from ui.text_box import TextBox
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager


# Stand-in colour per cell char, used when the tile pictures are missing.
_TILE_COLORS: dict[str, tuple[int, int, int]] = {
    OverworldSettings.FLOOR_CHAR: ColorSettings.OVERWORLD_FLOOR,
    OverworldSettings.WALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.WATER_CHAR: ColorSettings.OVERWORLD_WATER,
    OverworldSettings.SPRING_CHAR: ColorSettings.OVERWORLD_WATER,
    OverworldSettings.SAND_CHAR: ColorSettings.OVERWORLD_SAND,
    OverworldSettings.STALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.MAT_CHAR: ColorSettings.OVERWORLD_SAND,
    OverworldSettings.INSIDE_WALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.VOID_CHAR: ColorSettings.BLACK,
}

# Tile pictures by cell char, loaded on first use. ``{}`` means the
# pictures were looked for and are missing.
_TILES: dict[str, list[pygame.Surface]] | None = None


def _tiles() -> dict[str, list[pygame.Surface]]:
    """Return the choices of 16 pixel picture for each cell char."""
    global _TILES
    if _TILES is not None:
        return _TILES
    _TILES = {}
    size = GridSettings.TILE_SIZE
    sheets: dict[str, pygame.Surface] = {}
    for char, choices in OverworldSettings.TILE_PICTURES.items():
        pictures = []
        for name, index in choices:
            if name not in sheets:
                path = os.path.join(AssetPaths.TILES_DIR, name)
                if not os.path.exists(path):
                    _TILES = {}
                    return _TILES
                sheets[name] = pygame.image.load(path).convert_alpha()
            sheet = sheets[name]
            pictures.append(sheet.subsurface(pygame.Rect(
                (index * size) % sheet.get_width(),
                (index * size) // sheet.get_width() * size,
                size, size,
            )))
        _TILES[char] = pictures
    return _TILES


# Each person's walk sheet by name, loaded on first use; None if missing.
_PEOPLE: dict[str, pygame.Surface | None] = {}


def _person_sheet(name: str) -> pygame.Surface | None:
    """Return the Ninja Adventure walk sheet ``<name>-Walk.png``, or None."""
    if name not in _PEOPLE:
        path = os.path.join(AssetPaths.PEOPLE_DIR, f"{name}-Walk.png")
        _PEOPLE[name] = pygame.image.load(path).convert_alpha() if os.path.exists(path) else None
    return _PEOPLE[name]


# Each building's picture by kind, loaded on first use; None if missing.
_BUILDINGS: dict[str, pygame.Surface | None] = {}


def building_picture(kind: str) -> pygame.Surface | None:
    """Return the picture for a kind of building (``OverworldSettings.BUILDINGS``), or None."""
    if kind not in _BUILDINGS:
        path = os.path.join(AssetPaths.BUILDINGS_DIR, OverworldSettings.BUILDINGS[kind][0])
        _BUILDINGS[kind] = pygame.image.load(path).convert_alpha() if os.path.exists(path) else None
    return _BUILDINGS[kind]


def draw_building(surface: pygame.Surface, building: dict, x0: int = 0, y0: int = 0) -> None:
    """Draw a building at its own size on its tiles, standing on their bottom edge."""
    tile_size = GridSettings.TILE_SIZE
    width, height = OverworldSettings.BUILDINGS[building["kind"]][1]
    picture = building_picture(building["kind"])
    left, bottom = x0 + building["col"] * tile_size, y0 + (building["row"] + height) * tile_size
    if picture is None:
        pygame.draw.rect(surface, ColorSettings.OVERWORLD_WALL,
                         (left, bottom - height * tile_size, width * tile_size, height * tile_size))
        return
    surface.blit(picture, (left, bottom - picture.get_height()))


# Each plant's four garden pictures, loaded on first use; None if missing.
_PATCH_SHEETS: dict = {}


def _patch_sheet(plant: str) -> pygame.Surface | None:
    """Return a plant's strip of four pictures (GardenSettings.PICTURES), or None."""
    if plant not in _PATCH_SHEETS:
        path = os.path.join(AssetPaths.TILES_DIR, GardenSettings.PICTURES.get(plant, ""))
        _PATCH_SHEETS[plant] = pygame.image.load(path).convert_alpha() if os.path.isfile(path) else None
    return _PATCH_SHEETS[plant]


def _speaker(person: dict) -> str:
    """The name a person who joins speaks under: their first name."""
    from core.shared import short_name

    return short_name(person["joins"])


def _boss_flag_for(cell_name: str, spot: dict) -> str:
    """The party flag that marks a boss on the map as beaten for good."""
    return f"field_boss:{cell_name}:{spot['kind']}"


def _boss_flag(monster: FieldMonster) -> str:
    """The flag for ``monster``, a boss, in the cell it stands in."""
    for cell_name, spots in FIELD_MONSTERS.items():
        if monster.spot in spots:
            return _boss_flag_for(cell_name, monster.spot)
    return f"field_boss::{monster.spot['kind']}"


def _pick(pictures: list[pygame.Surface], col: int, row: int) -> pygame.Surface:
    """Pick one of ``pictures`` by tile position, the same every time."""
    return pictures[(col * 7 + row * 13 + col * row) % len(pictures)]


def start_in_room(gm: "GameManager", name: str, col: int | None = None,
                  row: int | None = None) -> bool:
    """Skip the title: a fresh party standing in room ``name``, on ``(col, row)``.

    How the Workshop's Play button starts the game (``main.py --room``).
    Returns False, leaving the title up, when there is no such room.
    """
    # Local import: the title imports this module.
    from core.overworld_cells import WORLD_LAYOUT
    from core.scenes.title_scene import build_default_party

    pos = next((pos for pos, who in WORLD_LAYOUT.items() if who == name), None)
    if pos is None:
        return False
    gm.party = build_default_party()
    scene = OverworldScene(gm)
    scene.world.go_to(pos)
    if col is not None and row is not None:
        scene.player.from_dict({"col": int(col), "row": int(row)})
    gm.scene_stack.replace(scene)
    return True


class OverworldScene(Scene):
    """The screen-locked, cell-based overworld."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Construct the overworld with its world, player, and text box.

        Args:
            gm: The host game manager. Provides audio, save, and
                cross-scene navigation routing.
        """
        super().__init__(gm)
        self.world = World()
        self.player = OverworldPlayer(gm, self.world)
        # Cell area is narrower than the screen, so size the text box
        # to the full screen width but keep the existing 160-px height.
        self.text_box = TextBox()
        # The monsters in the cell (D-576), placed afresh on every entry.
        self.monsters: list[FieldMonster] = []
        self._monsters_cell: tuple[int, int] | None = None
        # The monster whose fight is on, and how long until a monster
        # left standing by a fight can start another.
        self._fighting: tuple[FieldMonster, object] | None = None
        self._grace = 0.0
        self._ending = False   # the boss is beaten: the title once the last line closes
        # A shop pushed by a person who may join (Maika): who, and what the
        # bag held when it opened, so closing it can tell if anything was bought.
        self._joiner_shop: tuple[dict, dict] | None = None
        # What to open once the text box closes.
        self._after_text = None
        # The sparring villagers: until the next blow, and how long nothing has been pressed.
        self._spar_left = 0.0
        self._spar_blow = 0
        self._idle = 0.0
        # The story scene playing, the step it waits to show once the text
        # box closes, and the fight it started.
        self.story: StoryRunner | None = None
        self._story_next: dict | None = None
        self._story_fight = None
        # Where the player stood last frame, to count the garden's steps.
        self._last_tile: tuple | None = None
        self._sync_joined()

    def on_enter(self) -> None:
        """Play the field's music, and settle the fight just over, if one was.

        The song carries on if it is already playing (back from the
        menu). A monster beaten in its fight leaves the map, a boss for
        good; one that was run from or lost to stays, and waits a moment
        before it can start another (D-576).
        """
        self.gm.audio.play_screen("field")
        self._sync_joined()
        if self._joiner_shop is not None:
            person, before = self._joiner_shop
            self._joiner_shop = None
            self._after_joiner_shop(person, before)
        if self._story_fight is not None:
            battle, self._story_fight = self._story_fight, None
            self.story.fought(battle.battle.outcome == "victory")
        if self._fighting is None:
            return
        monster, battle = self._fighting
        self._fighting = None
        if battle.battle.outcome == "victory":
            if monster in self.monsters:
                self.monsters.remove(monster)
            if monster.spot.get("boss"):
                self.gm.party.flags[_boss_flag(monster)] = True
                # The Great Boar beaten, it is night (the demo line, 10/22).
                self.gm.party.flags[StorySettings.NIGHT_FLAG] = True
                for line in StorySettings.NIGHT_LINES:
                    self.text_box.push(line)
        else:
            self._grace = FieldMonsterSettings.GRACE_SECONDS

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Route one event.

        When the text box has content, confirm advances it and other
        keys fall through silently (so a held direction won't queue
        steps that fire the instant the player closes a dialogue).
        Otherwise, Tab / START pushes the system menu; movement is
        polled inside ``player.update`` and does not go through this
        handler.

        Args:
            event: The pygame event to route.
        """
        if event.type in (pygame.KEYDOWN, pygame.JOYBUTTONDOWN, pygame.JOYHATMOTION):
            self._idle = 0.0
        if not self.text_box.is_done():
            if input_map.is_confirm(event):
                self.text_box.advance()
            return
        # The story playing takes every key until its text box closes.
        if self.story is not None:
            return
        if input_map.is_confirm(event) and self._faced_patch() is not None:
            self._tend(self._faced_patch())
            return
        if input_map.is_confirm(event) and self._faced_building() == "pot":
            self._open_pot()
            return
        # Kailo's bed in his house: a nap rests the party (Frankie, 10/23).
        if input_map.is_confirm(event) and self._faced_building() == "bed":
            self._ask_nap()
            return
        # Facing the pond, confirm rests there; facing a stall, it opens
        # the shop; Enter opens the menu everywhere else.
        if input_map.is_confirm(event) and self._facing(OverworldSettings.SPRING_CHAR):
            self._rest()
            return
        if input_map.is_confirm(event) and (self._facing(OverworldSettings.STALL_CHAR)
                                            or self._faced_building() in OverworldSettings.SHOP_BUILDINGS):
            # A stall is its keeper's: whoever in the room keeps a shop.
            keeper = next((p for p in self.world.people if p.get("shop")), None)
            if keeper is not None and keeper.get("joins"):
                self._talk_to_joiner(keeper)
            elif keeper is not None:
                self._open_shop(keeper["shop"])
            return
        if input_map.is_confirm(event) and self._faced_person().get("night") and self.is_night():
            self._ask_at_night(self._faced_person())
            return
        if input_map.is_confirm(event) and self._faced_person().get("joins"):
            self._talk_to_joiner(self._faced_person())
            return
        if input_map.is_confirm(event) and self._faced_person().get("lines"):
            person = self._faced_person()
            for line in person["lines"]:
                self.text_box.push(line, speaker=person["speaker"])
            return
        if input_map.is_confirm(event) and self._faced_person().get("shop"):
            self._open_shop(self._faced_person()["shop"])
            return
        if input_map.is_menu(event):
            self._open_menu()

    def _facing(self, char: str) -> bool:
        """Whether the tile the player faces is ``char``: the pond (D-525), a stall (D-571)."""
        dx, dy = self.player.facing
        return self.world.tile_at(self.player.col + dx, self.player.row + dy) == char

    def at_save_point(self) -> bool:
        """Whether the party stands on a tile next to Kailo's bed or the healing pond."""
        for dx, dy in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            col, row = self.player.col + dx, self.player.row + dy
            building = self.world.building_at(col, row)
            if self.world.tile_at(col, row) == OverworldSettings.SPRING_CHAR or (building and building["kind"] == "bed"):
                return True
        return False

    def _faced_building(self) -> str | None:
        """The kind of building on the tile the player faces, or None."""
        dx, dy = self.player.facing
        building = self.world.building_at(self.player.col + dx, self.player.row + dy)
        return building["kind"] if building else None

    def _faced_person(self) -> dict:
        """The person on the tile the player faces, or an empty dict."""
        dx, dy = self.player.facing
        return self.world.person_at(self.player.col + dx, self.player.row + dy) or {}

    def _open_shop(self, shop_id: str) -> None:
        """Push a shop on top of this scene (D-571).

        While a row sold only once is still there, the keeper mentions it
        first (the old man's memory shell, Frankie 10/22).
        """
        # Local import, as with the menu and the battle below.
        from core.scenes.shop_scene import ShopScene, sold_out

        shop = self.gm.data.load("shops")[shop_id]
        mention = shop.get("mention")
        if mention and any(row.get("once") and not sold_out(self.gm.party, row) for row in shop["stock"]):
            self.text_box.push(mention["line"], speaker=mention["speaker"])
            self._after_text = lambda: self._push_shop(ShopScene(self.gm, shop_id))
            return
        self._push_shop(ShopScene(self.gm, shop_id))

    def _push_shop(self, shop) -> None:
        self.gm.audio.play("menu_select")
        self.gm.scene_stack.push(shop)

    # ------------------------------------------------------------------
    # MAIKA: a seller who joins (the demo plan, Frankie 10/22)
    # ------------------------------------------------------------------

    def _sync_joined(self) -> None:
        """Tell the world who is in the party, so whoever joined is gone from the map."""
        joined = {member.id for member in self.gm.party.members} if self.gm.party else set()
        if joined != self.world.joined:
            self.world.joined = joined
            self.world.go_to(self.world.current_pos)

    def _talk_to_joiner(self, person: dict) -> None:
        """Open the seller's shop; after a first visit with nothing bought, he says so first."""
        flag = f"met_{person['joins']}"
        if self.gm.party.flags.get(flag):
            self.text_box.push("Come back when you get hurt. You will.", speaker=_speaker(person))
            self._after_text = lambda: self._open_joiner_shop(person)
            return
        self.gm.party.flags[flag] = True
        self._open_joiner_shop(person)

    def _open_joiner_shop(self, person: dict) -> None:
        self._joiner_shop = (person, dict(self.gm.party.inventory))
        self._open_shop(person["shop"])

    def _after_joiner_shop(self, person: dict, before: dict) -> None:
        """Something bought: he asks what they are doing, and joins (demo-script.md)."""
        bought = any(count > before.get(item, 0) for item, count in self.gm.party.inventory.items())
        if not bought:
            return
        from core.factories import party_member_from_data
        from core.shared import by_id

        who = _speaker(person)
        self.text_box.push("So what brings you all the way out here?", speaker=who)
        self.text_box.push("We're going after the Great Boar.", speaker="Kailo")
        self.text_box.push("The Great Boar? He's the other way. You went the wrong way.", speaker=who)
        self.text_box.push("A wise man never lets a good customer get lost. I'll come with you.", speaker=who)
        self.gm.party.add(party_member_from_data(by_id("characters")[person["joins"]]))
        self.text_box.push(join_line(person["joins"]))
        self.text_box.push("Hina, you garden? Here. Plant this on a friend.", speaker=who)
        self.text_box.push("Hina learned Seed!")
        self.gm.party.flags["hina_learned_seed"] = True
        self.gm.audio.play("hit_sparkle_1")
        self._sync_joined()

    # ------------------------------------------------------------------
    # THE STORY: the taro patch, night, Melia's question, the wake
    # ------------------------------------------------------------------

    def begin_story(self, name: str) -> None:
        """Play the scene ``name`` (``core/story.py``) over the field."""
        self.story = StoryRunner(name, skip=self._story_skips)
        self._story_next = None

    def is_night(self) -> bool:
        """Whether the Great Boar is beaten, so it is night."""
        return bool(self.gm.party.flags.get(StorySettings.NIGHT_FLAG))

    def _ask_at_night(self, person: dict) -> None:
        """Melia at night: is the party ready for the wake? YES starts it; NO, she waits."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        self.text_box.push(StorySettings.ASK_LINE, speaker=person["speaker"])
        self._after_text = lambda: self.gm.scene_stack.push(ConfirmScene(
            self.gm, StorySettings.ASK_BOX, on_yes=lambda: self.begin_story(person["night"]),
        ))

    def _ask_nap(self) -> None:
        """Kailo's bed: take a nap? YES rests the party; NO, nothing."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        self.gm.scene_stack.push(ConfirmScene(
            self.gm, TownSettings.NAP_BOX, on_yes=lambda: self._rest(TownSettings.NAP_LINE),
        ))

    def _story_skips(self, step: dict) -> bool:
        """Maika's line about the bench plays only if he came along."""
        speaker, member, start = StorySettings.BENCH_LINE
        return (step.get("say") == speaker and step["text"].startswith(start)
                and self.gm.party.find(member) is None)

    def _play_story(self) -> None:
        """Called with the text box closed: show the lines up to the next choice or fight, then it."""
        if self._story_next is None:
            while True:
                step = self.story.next_step()
                if step is None:
                    self._story_next = {"over": True}
                    break
                if "say" in step or "text" in step:
                    self.text_box.push(step["text"], speaker=step.get("say"))
                    continue
                self._story_next = step
                break
            if "choice" in self._story_next and self.story.name == "wake":
                self._join_at_wake()
            if not self.text_box.is_done():
                return
        step, self._story_next = self._story_next, None
        if "choice" in step:
            from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

            options = step["options"]
            self.gm.scene_stack.push(ChoiceScene(
                self.gm, step["choice"], [label for label, _ in options],
                lambda index: self.story.choose(options[index][1]),
            ))
        elif "fight" in step:
            from core.scenes.battle_scene import BattleScene  # local, as _start_fight

            self._story_fight = BattleScene(self.gm, enemies=step["fight"], can_escape=False)
            self.gm.scene_stack.push(self._story_fight)
        else:
            self._story_over()

    def _join_at_wake(self) -> None:
        """Tawiri joins fourth, with her pop-up; whoever else came sits on the bench."""
        from core.factories import party_member_from_data
        from core.shared import by_id

        party = self.gm.party
        if party.find(StorySettings.WAKE_JOINS) is not None:
            return
        party.add(party_member_from_data(by_id("characters")[StorySettings.WAKE_JOINS]))
        bench = party.find(StorySettings.WAKE_BENCH)
        if bench is not None:
            party.members.remove(bench)
            party.members.append(bench)
        self.gm.audio.play("hit_sparkle_1")
        self.text_box.push(StorySettings.WAKE_JOIN_LINE)

    def _story_over(self) -> None:
        """A scene's part is over: lost, the fight again; else on with the demo."""
        if self.story.part == LOSE:
            self.story.retry()
            return
        name, self.story = self.story.name, None
        if name == "taro_patch":
            self.gm.party.flags[StorySettings.TARO_FLAG] = True
        elif name == "wake":
            # The wake's fight ends the demo: one line, then the title.
            self.text_box.push(StorySettings.END_LINE)
            self._ending = True

    def _render_night(self, surface: pygame.Surface) -> None:
        """Night outside: the Super Nintendo's color math, a fixed color taken from every pixel."""
        if not self.is_night() or self.world.current_pos[1] >= INSIDE_ROW:
            return
        surface.fill(
            tuple(amount * 8 for amount in StorySettings.NIGHT_SUBTRACT),
            pygame.Rect(OverworldSettings.X, OverworldSettings.Y,
                        OverworldSettings.PIXEL_W, OverworldSettings.PIXEL_H),
            special_flags=pygame.BLEND_RGB_SUB,
        )
    # THE GARDEN AND THE POT: Hina plants, Maika grows, Kailo cooks
    # (Frankie, 10/22; systems/garden.py, core/scenes/craft_scene.py)
    # ------------------------------------------------------------------

    def _faced_patch(self) -> int | None:
        """The garden patch on the tile the player faces, by its index in the room, or None."""
        dx, dy = self.player.facing
        return self.world.patch_tiles.get((self.player.col + dx, self.player.row + dy))

    def _tend(self, index: int) -> None:
        """One press, one thing (Frankie, 10/23): pick the patch, or ask to replant it or grow it faster."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        pressed = garden.press(self.gm.party, self.world.current_cell_name, index)
        if pressed.question is None:
            if pressed.line.startswith("Picked"):
                self.gm.audio.play("hit_sparkle_1")
            self.text_box.push(pressed.line)
            return

        def yes() -> None:
            self.gm.audio.play("hit_sparkle_1")
            line = pressed.yes()
            if line:
                self.text_box.push(line)
        self.gm.scene_stack.push(ConfirmScene(self.gm, pressed.question, on_yes=yes))

    def _open_pot(self) -> None:
        """The pot outside Kailo's house opens the crafting pot, as Craft on the menu does."""
        from core.scenes.craft_scene import CraftScene  # local: cycle.

        self.gm.audio.play("menu_select")
        self.gm.scene_stack.push(CraftScene(self.gm))

    def _count_steps(self) -> None:
        """Count a step for the garden each time the player stands on a new tile."""
        here = (self.world.current_pos, self.player.col, self.player.row)
        if self._last_tile is not None and here != self._last_tile:
            garden.walked(self.gm.party)
        self._last_tile = here

    def _render_patches(self, surface: pygame.Surface) -> None:
        """Draw each patch in the room by how far it has grown."""
        tile_size = GridSettings.TILE_SIZE
        for index, patch in enumerate(garden.patches_in(self.world.current_cell_name)):
            sheet = _patch_sheet(patch["plant"])
            x = OverworldSettings.X + patch["col"] * tile_size
            y = OverworldSettings.Y + patch["row"] * tile_size
            stage = garden.stage(self.gm.party, self.world.current_cell_name, index)
            if sheet is None:
                pygame.draw.rect(surface, ColorSettings.OVERWORLD_SAND, (x, y, tile_size, tile_size))
                continue
            surface.blit(sheet, (x, y), (stage * tile_size, 0, tile_size, tile_size))

    def _rest(self, line: str = "The party drinks from the cool pond. Everyone is rested.") -> None:
        """Drink from the pond, or nap in Kailo's bed: everyone back to full HP, the fallen back up (D-525)."""
        for member in self.gm.party.members:
            member.current_hp = member.max_hp
        self.gm.audio.play("hit_sparkle_1")
        self.text_box.push(line)
        self._after_text = self._ask_save

    def _ask_save(self) -> None:
        """After a rest, the save point (Frankie, 10/23): YES opens the three slots; NO, nothing."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below
        from core.scenes.save_slot_scene import SaveSlotScene

        self.gm.scene_stack.push(ConfirmScene(
            self.gm, TownSettings.SAVE_BOX,
            on_yes=lambda: self.gm.scene_stack.push(SaveSlotScene(self.gm, loading=False)),
        ))

    def update(self, dt: float) -> None:
        """Tick the text box, then advance the player if no text is showing.

        After advancing the player, any newly-completed steps roll for
        a random encounter; on a hit a ``BattleScene`` is pushed on
        top of this scene. The overworld resumes automatically when
        the battle pops, since this scene was never destroyed.

        Args:
            dt: Frame time in seconds.
        """
        self.text_box.update(dt)
        if not self.text_box.is_done():
            return
        if self._after_text is not None:
            action, self._after_text = self._after_text, None
            action()
            return
        if self._ending:
            self._ending = False
            self.gm.return_to_title()
            return
        if self.story is not None:
            self._play_story()
            return
        self._watch_sparring(dt)
        if not self.text_box.is_done():
            return
        self._place_monsters()
        self.player.update(dt)
        self._count_steps()
        self._place_monsters()
        self._grace = max(0.0, self._grace - dt)
        for monster in self.monsters:
            taken = set().union(*(m.tiles() for m in self.monsters if m is not monster))
            if self._grace > 0:
                # The monster left standing waits for the party to walk off.
                taken.add((self.player.col, self.player.row))
            chase = None if self._grace > 0 else (self.player.col, self.player.row)
            monster.update(dt, self.world, taken, chase)
        # Started from the Workshop with fights off, the monsters walk
        # but never start one, so a room can be looked over in peace.
        if self._grace <= 0 and not getattr(self.gm, "no_fights", False):
            for monster in self.monsters:
                if (self.player.col, self.player.row) in monster.tiles():
                    self._start_fight(monster)
                    return

    def _watch_sparring(self, dt: float) -> None:
        """The villagers' sparring: a blow now and then; 30 seconds watching, once, teaches Kailo.

        Watching is standing next to one of them, facing them, with nothing
        pressed; a step or a turn away starts the count again.
        """
        if not any(person.get("spar") for person in self.world.people):
            self._idle = 0.0
            return
        self._spar_left -= dt
        if self._spar_left <= 0:
            self._spar_left = TownSettings.SPAR_SECONDS
            self._spar_blow = self._spar_blow % 3 + 1
            self.gm.audio.play(f"hit_punch_{self._spar_blow}")
        if self.player._step_active or not self._faced_person().get("spar"):
            self._idle = 0.0
            return
        self._idle += dt
        if self._idle < TownSettings.WATCH_SECONDS or self.gm.party.flags.get(TownSettings.WATCH_FLAG):
            return
        member = self.gm.party.find(TownSettings.WATCH_MEMBER)
        if member is None:
            return
        self.gm.party.flags[TownSettings.WATCH_FLAG] = True
        for stat, points in TownSettings.WATCH_GROWTH.items():
            member.growth[stat] = member.growth.get(stat, 0) + points
        member.refresh_stats()
        self.gm.audio.play("learned")
        for line in TownSettings.WATCH_LINES:
            self.text_box.push(line)

    def _place_monsters(self) -> None:
        """Put the cell's monsters out when the party arrives in a cell (D-576)."""
        if self._monsters_cell == self.world.current_pos:
            return
        self._monsters_cell = self.world.current_pos
        self._grace = 0.0
        kinds = self.gm.data.load("field_monsters")
        self.monsters = [
            FieldMonster(spot, kinds[spot["kind"]])
            for spot in FIELD_MONSTERS.get(self.world.current_cell_name, [])
            if not (spot.get("boss") and self.gm.party.flags.get(
                _boss_flag_for(self.world.current_cell_name, spot)
            ))
        ]

    def _start_fight(self, monster: FieldMonster) -> None:
        """Push the fight ``monster`` brings, and remember whose it is."""
        # Local import: ``BattleScene`` lives in a sibling scene file
        # and importing it at the top would risk a cycle the moment a
        # battle ever needs to read overworld state on the way out.
        from core.scenes.battle_scene import BattleScene, compose_fight

        battle = BattleScene(self.gm, enemies=compose_fight(monster.kind))
        self._fighting = (monster, battle)
        self.gm.scene_stack.push(battle)

    def render(self, surface: pygame.Surface) -> None:
        """Paint background, cell tiles, player, and message box in that order.

        Args:
            surface: The screen surface to draw onto.
        """
        render_scene_background(self, surface)
        self._render_cell(surface)
        self._render_patches(surface)
        for building in self.world.buildings:
            draw_building(surface, building, OverworldSettings.X, OverworldSettings.Y)
        self._render_people(surface)
        for monster in self.monsters:
            monster.render(surface)
        self.player.render(surface)
        self._render_night(surface)
        self.text_box.render(surface)

    # ------------------------------------------------------------------
    # INTERNAL HELPERS
    # ------------------------------------------------------------------

    def _render_cell(self, surface: pygame.Surface) -> None:
        """Draw the active cell's tile grid, one picture per tile.

        Args:
            surface: The screen surface to draw onto.
        """
        grid = self.world.current_grid
        tile_size = GridSettings.TILE_SIZE
        tiles = _tiles()
        floor = OverworldSettings.FLOOR_CHAR
        for row in range(OverworldSettings.ROWS):
            row_cells = grid[row]
            for col in range(OverworldSettings.COLS):
                char = row_cells[col]
                x = OverworldSettings.X + col * tile_size
                y = OverworldSettings.Y + row * tile_size
                if not tiles:
                    color = _TILE_COLORS.get(char, ColorSettings.OVERWORLD_FLOOR)
                    pygame.draw.rect(surface, color, (x, y, tile_size, tile_size))
                    continue
                if char in shore.WATER:
                    coast = shore.water_tile(grid, col, row)
                    if coast is not None:
                        surface.blit(coast, (x, y))
                        continue
                if char in walls.CHARS:
                    surface.blit(walls.tile(grid, col, row), (x, y))
                    continue
                under = OverworldSettings.TILE_UNDER.get(char)
                if under is not None:
                    surface.blit(_pick(tiles[under], col, row), (x, y))
                surface.blit(_pick(tiles.get(char, tiles[floor]), col, row), (x, y))

    def _render_people(self, surface: pygame.Surface) -> None:
        """Draw everyone standing in the cell, in their standing frame."""
        tile_size = GridSettings.TILE_SIZE
        column = OverworldPlayerSettings.SHEET_COLUMNS
        for person in self.world.people:
            sheet = _person_sheet(person["sheet"])
            if sheet is None:
                continue
            frame = sheet.subsurface(pygame.Rect(
                column.get(tuple(person["facing"]), 0) * tile_size, 0, tile_size, tile_size,
            ))
            surface.blit(frame, (
                OverworldSettings.X + person["col"] * tile_size,
                OverworldSettings.Y + person["row"] * tile_size,
            ))

    def _open_menu(self) -> None:
        """Push the translucent system menu on top of this scene."""
        # Local import: ``MenuScene`` lives in a sibling scene module
        # and importing it at top of file would risk a cycle if the
        # menu ever pushes overworld-aware actions later.
        from core.scenes.menu_scene import MenuScene

        self.gm.scene_stack.push(MenuScene(self.gm))

    # ------------------------------------------------------------------
    # PERSISTENCE
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Serialise the active cell pointer and the player's tile state."""
        base = super().to_dict()
        base["world"] = self.world.to_dict()
        base["player"] = self.player.to_dict()
        return base

    @classmethod
    def from_dict(cls, gm: "GameManager", data: dict) -> "OverworldScene":
        """Rebuild a scene from a previously-saved dict.

        Args:
            gm: The host game manager.
            data: The dict previously returned by ``to_dict``.

        Returns:
            A fully-restored ``OverworldScene``.
        """
        scene = cls(gm)
        if isinstance(data, dict):
            world_data = data.get("world")
            if isinstance(world_data, dict):
                scene.world.from_dict(world_data)
            player_data = data.get("player")
            if isinstance(player_data, dict):
                scene.player.from_dict(player_data)
        return scene
