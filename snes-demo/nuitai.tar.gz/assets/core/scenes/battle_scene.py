"""Battle scene: hosts a ``Battle`` and a ``BattleView``.

The scene owns no rules. It builds a ``Battle`` from content data,
asks it to advance, and plays the events it gets back one at a time so
that each line of narration appears together with the change it
describes (an HP number dropping, a status appearing).

What the fighters look like and how they move is ``ui.battle_stage``.
The scene hands it each event as that event's line comes up, so a
monster shakes at the moment the text says it was hit.

Each frame:

* Narration on screen holds for a moment and then advances on its own;
  confirm advances it at once.
* When nothing is left to narrate and a party member's turn is waiting,
  the bottom HUD becomes a command panel: Attack / Skill / Element /
  Item on the left, the party's rows with their mana on the right. Skill
  is the member's signature command, labeled by its name (D-692); only
  Kailo's Cook works yet, the rest grey. Left turns to a page with
  Weapon, Escape and Defend, right to one with Team Up (only while a
  Team Up is open) and Swap (D-455, the battle menu line in
  ``game/answers.md``).
  Cook (Frankie, 10/25) spends the turn cooking for the party; what it is
  is set then (``Battle.submit_cook``), and it is served at the start of
  his next turn.
  Attack picks an enemy and opens the stroke menu: Light, Medium and
  Strong strokes (1, 2 and 3 of the turn's 7 points, shown top right),
  and Element. Each stroke that lands builds mana, which Element spends
  (D-213 to D-220). After a stroke, cancel goes back to the commands
  with the points left (D-578): Attack strikes on, and Element, Defend or
  Item ends the turn; Swap is grey until the next turn. Ability and Item open submenus;
  anything aimed at someone enters target selection with a pulsing
  arrow on the fighter. There is no help line (D-450).
* Otherwise ``battle.start_turn()`` is called to move to the next turn.

The strip across the top shows who acts next. While the player moves
through the menus it previews the order as it would be if they took
the highlighted action: the wait is the turn's fatigue (D-328), so a
long chain of strokes brings the next turn later.
"""

from __future__ import annotations

import random
import time
from collections import deque
from typing import TYPE_CHECKING, Any

import pygame

from core.events import (
    AbilityUsedEvent,
    BattleEndedEvent,
    BlockStartEvent,
    DamageEvent,
    DodgeEvent,
    HealEvent,
    RevivedEvent,
    MissEvent,
    StanceEvent,
    SummonEvent,
    StrokeEvent,
    SwapEvent,
)
from core import lore
from core.elements import Element
from core.battle_tutorial import HinaTutorial
from core.factories import (
    combatant_from_monster_data,
    combatant_from_party_member,
    stance_numbers,
)
from core.scene import Scene
from core.scenes.inventory_scene import item_help
from core.scenes.game_over_scene import game_over
from core.scenes.victory_scene import Fighter, VictoryReport, VictoryScene
from core.shared import by_id, short_name, skill_for
from core.stats import monster_hp
from settings import (
    AudioSettings,
    BattleSettings,
    BattleStageSettings,
    BlockSettings,
    LoadoutSettings,
    MinigameSettings,
    ColorSettings,
    FontSettings,
    InputSettings,
    ItemSettings,
    ScreenSettings,
    StorySettings,
    TutorialSettings,
    UISettings,
    VictorySettings,
)
from systems import bounties, config, diet, mastery, stew
from systems.battle import Battle, Combatant
from systems.timed_block import BlockMeter
from systems.passives import after_victory, growth_step
from ui import input_map, text_renderer
from ui.battle_stage import BattleStage
from ui.battle_view import BattleView
from ui.block_meter import BlockMeterView
from ui.paddle_meter import PaddleMeter
from ui.spin_meter import SpinMeter
from ui.banish_meter import BanishMeter
from ui.pound_meter import PoundMeter
from ui.rhythm_meter import RhythmMeter
from ui.dance_meter import DanceMeter
from ui.simon_meter import SimonMeter, button_of
from ui.stir_meter import StirMeter
from ui.vine_meter import VineMeter
from ui.sun_meter import PunchMeter
from ui.banish_meter import TapMeter
from ui.grid_menu import GridCell, GridMenu, GridRow, short_move_name
from ui.item_icon import item_icon
from ui.stance_icon import pair_icons, stance_icons, switch_icon
from ui.menu import Menu, MenuItem
from ui.notice_bar import NoticeBar
from ui.text_box import TextBox
from ui.window import draw_window
from utils.backgrounds import render_template

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


# Encounters a fight with no named encounter rolls, for the tools (the
# map's fights come from field monsters, D-576). Every fight whose
# monsters use only rules this game has. The Dwende and Amaranhig fight
# needs zombie and the Kaperosa needs doom, so they wait.
_DEMO_ENCOUNTER_IDS: tuple[str, ...] = (
    "beast_pack", "mages", "shades", "great_boar",
)

# Index of each row in the top-level command menu.
_ATTACK_ROW, _TECH_ROW, _ABILITY_ROW, _ITEM_ROW = range(4)
# The Skills built in this game, by move id; the rest are on paper and grey.
# Which one a member has is the weapon type in hand (Frankie, 10/31).
_SKILLS_BUILT: tuple[str, ...] = ("cook", "scold", "charm", "call_the_dead", "paddle", "pound", "banish", "dance",
                                  "vault", "wili", "moepapa")

# The stroke menu's rows: the three strokes, then Element (D-455). Cancel ends the
# chain once a stroke has been swung (Frankie, 10/18).
_STROKE_KINDS: tuple[str, ...] = ("light", "medium", "strong")
# The bag item whose help line says what each of Cook's dishes is.
_DISH_ITEMS = {"heal": "fish_stew", "cure": "ginger_tea", "rest": "coconut_water"}
_STROKE_ABILITY_ROW = 3
# What Memory notes when the stance switch was the last pick on the grid.
_SWITCH = "switch"


def compose_fight(kind: dict[str, Any]) -> list[dict[str, Any]]:
    """The enemies a field monster brings into its fight (D-576).

    A boss names its fight (``encounter``). An ordinary monster always
    brings its ``lead``; each of its ``extra_slots`` is then filled one
    time in ``join_chance`` by a companion picked by weight. Repeats are
    lettered, Wild Boar A and Wild Boar B, the way the shared fights name them.

    Args:
        kind: The monster's ``data/field_monsters`` entry.

    Returns:
        Enemy entries shaped like the shared file's, ready for
        ``BattleScene(enemies=...)``.
    """
    templates = {
        entry["id"]: entry
        for encounter in by_id("encounters").values()
        for entry in encounter["enemies"]
    }
    if "encounter" in kind:
        return list(by_id("encounters")[kind["encounter"]]["enemies"])
    picks = [kind["lead"]]
    companions = kind.get("companions", {})
    for _ in range(kind.get("extra_slots", 0)):
        if companions and random.random() < kind.get("join_chance", 0.0):
            picks += random.choices(list(companions), weights=list(companions.values()))
    # The shared names end in " A" where a fight holds several; strip it,
    # then letter again only what repeats here.
    bases = [templates[pick]["name"].removesuffix(" A") for pick in picks]
    entries = []
    for index, (pick, base) in enumerate(zip(picks, bases)):
        entry = dict(templates[pick])
        if bases.count(base) > 1:
            letter = "ABCDEFGH"[bases[:index].count(base)]
            entry["name"] = f"{base} {letter}"
        else:
            entry["name"] = base
        entry["id"] = f"{pick}_{index}"
        entries.append(entry)
    return entries


def _build_enemies(
    encounter_id: str | None = None, entries: list[dict[str, Any]] | None = None,
) -> tuple[list[Combatant], dict[str, str | None], set[str], list[dict[str, Any]]]:
    """Build the monsters for one encounter.

    Args:
        encounter_id: Which fight. None rolls one of the demo fights.
        entries: The enemies themselves, from ``compose_fight``; when
            given, ``encounter_id`` is not used.

    Returns:
        The monsters, each one's picture name keyed by its id, the ids
        of those that float (ghosts and flyers), and each monster's
        entry in the shared file, in the same order, for what it drops.
    """
    if entries is None:
        entries = by_id("encounters")[
            encounter_id or random.choice(_DEMO_ENCOUNTER_IDS)
        ]["enemies"]
    monsters = by_id("monsters")
    combatants = [
        combatant_from_monster_data(entry, monsters[entry["monster"]])
        for entry in entries
    ]
    sprites = {entry["id"]: entry.get("sprite") for entry in entries}
    floating = {entry["id"] for entry in entries if entry.get("floats")}
    kinds = [monsters[entry["monster"]] for entry in entries]
    return combatants, sprites, floating, kinds


def roll_drops(
    kinds: list[dict[str, Any]], rng: random.Random | None = None,
) -> tuple[int, dict[str, int]]:
    """What the beaten monsters leave behind (D-524).

    Every monster drops pule, the islanders' shells, by how tough it was;
    some drop the item they carry (``steal`` in the shared file), and a
    boss always does; the Great Boar always leaves his tusk too
    (``ItemSettings.KEY_DROPS``). Besides, now and then, an everyday item (a Noni,
    a Seer's Shell) and, rarely, a seed, some monsters' favorite more
    often (Frankie, 10/22; ``ItemSettings``), and more rarely a weapon or
    relic (Frankie, 10/24).

    Returns:
        The pule, and the items found by id with their counts.
    """
    rng = rng or random.Random()
    pule = 0
    items: dict[str, int] = {}

    def found(item: str) -> None:
        items[item] = items.get(item, 0) + 1

    for kind in kinds:
        pule += max(1, round(monster_hp(kind) * BattleSettings.DROP_PULE_PER_HP))
        item = kind.get("steal")
        if item and (kind.get("boss") or rng.random() < BattleSettings.DROP_ITEM_CHANCE):
            found(item)
        # A key item, always (the Great Boar's tusk, 10/25).
        if kind.get("id") in ItemSettings.KEY_DROPS:
            found(ItemSettings.KEY_DROPS[kind["id"]])
        # Its own ingredient, now and then: the Papanok's egg (Frankie, 10/28).
        chance = ItemSettings.MONSTER_DROP_CHANCES.get(kind.get("id"), ItemSettings.MONSTER_DROP_CHANCE)
        if kind.get("id") in ItemSettings.MONSTER_DROPS and rng.random() < chance:
            found(ItemSettings.MONSTER_DROPS[kind["id"]])
        # The Life Totem, never sold (Frankie, 11/1): a monster's chance, a boss's a good deal better.
        if rng.random() < (ItemSettings.TOTEM_BOSS_CHANCE if kind.get("boss") else ItemSettings.TOTEM_CHANCE):
            found("life_totem")
        if rng.random() < ItemSettings.EVERYDAY_CHANCE:
            everyday = ItemSettings.EVERYDAY
            found(rng.choices(list(everyday), weights=list(everyday.values()))[0])
        if rng.random() < ItemSettings.SEED_CHANCE:
            favorite = ItemSettings.SEED_FAVORITES.get(kind.get("id", ""))
            if favorite and rng.random() < ItemSettings.SEED_FAVORITE_SHARE:
                found(favorite)
            else:
                found(rng.choice(list(ItemSettings.SEEDS)))
        # Taro or wheat, so the garden can always be replanted (Frankie, 10/24).
        if rng.random() < ItemSettings.INGREDIENT_CHANCE:
            found(rng.choice(ItemSettings.INGREDIENT_DROPS))
        # Rarer still, a piece of the demo's equipment (Frankie, 10/24).
        if rng.random() < ItemSettings.EQUIP_CHANCE:
            found(rng.choice(ItemSettings.EQUIP_DROPS))
    return pule, items



def _pound_button(event: pygame.event.Event, hat_before: tuple[int, int], wanted: str) -> str | None:
    """The button a press is for Pound, or None (Frankie, 10/31).

    The stick counts too: some pads send their D-pad as a stick, and a held
    tilt is passed on only once (``ui.gamepads``), so it cannot repeat. On
    the D-pad only a newly pressed direction counts, so rolling onto a corner
    does not press the held one again; a corner pressed from the middle is
    the direction the move wants next, if it is one of the two.
    """
    if event.type == pygame.JOYHATMOTION:
        (x, y), (bx, by) = event.value, hat_before
        new = []
        if x and x != bx:
            new.append("LEFT" if x < 0 else "RIGHT")
        if y and y != by:
            new.append("UP" if y > 0 else "DOWN")
        if not new:
            return None
        return wanted if wanted in new else new[0]
    for test, name in ((input_map.is_up, "UP"), (input_map.is_down, "DOWN"), (input_map.is_left, "LEFT"),
                       (input_map.is_right, "RIGHT"), (input_map.is_confirm, "A"), (input_map.is_cancel, "B")):
        if test(event):
            return name
    return None


class BattleScene(Scene):
    """A turn-based encounter scene."""

    OPAQUE = True

    def __init__(
        self, gm: "GameManager", encounter_id: str | None = None,
        enemies: list[dict[str, Any]] | None = None, can_escape: bool = True,
        in_town: bool = False, story: bool = False, tutorial: bool = False,
        music: str | None = None, swap_lesson: str | None = None,
        opening: str | None = None, timed_blocks: bool | None = None,
        at_sea: bool = False,
    ) -> None:
        """Build the battle from the party and an encounter.

        Args:
            gm: The game manager.
            encounter_id: A fight from the shared battle file. None
                rolls one of the demo fights at random.
            enemies: The enemies themselves, from ``compose_fight``,
                for a fight a field monster starts (D-576).
            can_escape: False for a story fight: Escape is gray (D-041).
            in_town: True for a fight in town, which stands on the beach;
                anywhere else it stands in the jungle (Frankie, 10/23).
            at_sea: True for a fight started at sea, which stands on the open
                ocean (Frankie, 11/1).
            story: True for a story fight. Losing one plays it again;
                losing any other is game over (D-148).
            tutorial: True for the taro patch fight: Hina asks if Kailo
                remembers how to fight, and reminds him (core/battle_tutorial.py).
            music: The scene's Song, played instead of the fight's (Tawiri's
                theme at the wake, Frankie 10/26). A win still plays the
                victory theme, and the field's song comes back once the
                victory screen closes (Frankie, 10/27).
            swap_lesson: Who on the bench Hina and they talk the player
                through swapping in, on the first turn, then the swap forced:
                the player picks who sits out; swapped in, they grumble (Maika
                at the wake, Frankie 10/30). Whoever ``StorySettings.SWAP_LOCKED``
                names cannot be swapped out of that fight.
            opening: "preemptive" or "ambush": who was caught from behind
                or the side, and starts with full fatigue (Frankie, 10/27).
            timed_blocks: Whether a monster's plain strokes open the timed
                block meter. None follows ``BlockSettings.ENABLED``, off in
                headless runs.
        """
        super().__init__(gm)
        self.can_escape = can_escape
        self.story = story
        self.backdrop = "sea" if at_sea else "beach" if in_town else "jungle"
        # Once the Great Boar is beaten it is night, until the morning after the jump (Frankie, 11/1).
        flags = gm.party.flags
        if self.backdrop != "sea" and flags.get(StorySettings.NIGHT_FLAG) and not flags.get(StorySettings.AFTER_JUMP_FLAG):
            self.backdrop += "_night"
        self.moves = by_id("moves")
        # Noni is a Party-level resource that persists across
        # battles. If the inventory entry is missing entirely (old
        # save, never been to a battle), fall back to the new-game
        # starter count so the player isn't silently emptied out.
        starting_noni = gm.party.inventory.get(
            "noni", BattleSettings.STARTING_NONI
        )
        enemies, sprites, floating, self._kinds = _build_enemies(encounter_id, enemies)
        # A won fight's victory screen (Frankie, 10/26): what it shows, built
        # as the fight ends, the hold before it opens, and whether it has.
        self.victory: VictoryReport | None = None
        self._victory_hold = 0.0
        self._victory_shown = False
        # A fight with a boss in it plays the boss songs (music.json); a
        # boss is the monster that counts its element twice.
        self._music = music or ("boss" if any(len(foe.elements) > 1 for foe in enemies) else "battle")
        self._won_music = "victory"
        self._swap_lesson = swap_lesson
        # At the wake Tawiri stays in (Frankie, 10/30).
        self._swap_locked = StorySettings.SWAP_LOCKED if swap_lesson else None
        # The first three fight; the rest wait on the bench (D-196).
        everyone = [combatant_from_party_member(m, self.gm.party.flags) for m in self.gm.party.members]
        weapons = by_id("weapons")
        for member, combatant in zip(self.gm.party.members, everyone):
            held = weapons.get(member.weapon or "")
            combatant.weapon = held["name"] if held else None
        # The knocked out stay down between fights (Frankie, 10/26); with the
        # first three all down, the first standing one on the bench steps in.
        if not any(c.alive for c in everyone[:BattleSettings.FIGHTERS]):
            standing = next((c for c in everyone if c.alive), None)
            if standing is not None:
                at = everyone.index(standing)
                everyone[0], everyone[at] = standing, everyone[0]
        self.battle = Battle(
            party_combatants=everyone[:BattleSettings.FIGHTERS],
            enemy_combatants=enemies,
            moves=self.moves,
            noni=starting_noni,
            bench=everyone[BattleSettings.FIGHTERS:],
            combos=by_id("combos"),
            opening=opening,
        )
        # Pono's Corpse is fought at night, however the scene was reached (Frankie, 11/1).
        if any(c.id == "ponos_corpse" for c in enemies) and not self.backdrop.endswith("_night") and self.backdrop != "sea":
            self.backdrop += "_night"
        # Tawiri's party passive: stats grow faster (systems/passives.py).
        self.battle.growth["step"] = growth_step(self.gm.party)
        # Timed blocks (Frankie, 10/30): off in headless runs (BlockSettings.ENABLED).
        self.battle.timed_blocks = BlockSettings.ENABLED if timed_blocks is None else timed_blocks
        self.meter: BlockMeterView | None = None
        # Kailo's Paddle while A is being mashed (Frankie, 10/31).
        self.paddle: PaddleMeter | None = None
        # Hina's Banish while the bow is drawn (Frankie, 10/31).
        self.banish: BanishMeter | None = None
        # Maika's and Tawiri's Wili while the pad is spun (Frankie, 11/1).
        self.spin: SpinMeter | None = None
        # Kailo's Pound while its buttons are being pressed (Frankie, 10/31).
        self.pound: PoundMeter | None = None
        # The minigames of 11/1 (Frankie): Cook's stir, Scold's mash, Charm's Simon, Vault's
        # jump, Call's beat and Moepapa's tap; what each hands the battle when it is done.
        self.minigame: Any = None
        self._minigame_done: Any = None
        self._skill_listing = False  # True while the list menu holds Cook's dishes or Pound's moves.
        self._team_up_listing = False  # True while the list menu holds the Team Ups.
        self._pound_hat = (0, 0)     # The D-pad as last seen, so Pound counts only new presses.
        self._block_attacker = ""
        self._block_target = ("", "")
        # Narration goes in the left part of the window; the party's
        # rows stay visible on the right while it plays.
        self.text_box = TextBox(
            width=UISettings.COMMAND_PANEL_WIDTH
        )
        # "Went up!" lines show along the top without stopping the fight (D-526).
        self.notices = NoticeBar(pygame.Rect(UISettings.NOTICE_RECT))
        if opening in BattleSettings.OPENING_WORDS:
            self.notices.push(BattleSettings.OPENING_WORDS[opening])
        self.view = BattleView(self.text_box, self.notices)
        self.stage = BattleStage(
            self.battle.party, self.battle.enemies, sprites, floating,
            bench=self.battle.bench,
        )
        # Events the battle has produced but the screen has not shown yet.
        self._events: deque[Any] = deque()
        # HP as currently shown. It trails the battle's real HP until
        # the damage or heal event that changed it has been narrated.
        self._shown_hp: dict[str, int] = {
            c.id: c.hp
            for c in self.battle.party + self.battle.bench + self.battle.enemies
        }
        # Seconds the current finished line has been on screen.
        self._narration_held = 0.0
        # Seconds left before the next event plays: each stroke gets a
        # beat of its own, since strokes have no line to wait on.
        self._beat = 0.0
        # True once the counter at the head of the queue has had its beat.
        self._counter_held = False
        # Seconds the meter stays up after a kick back on it, so its number reads (Frankie, 11/2).
        self._kick_hold = 0.0
        # Seconds the fight's first commands stay deaf once up, so a press
        # still meant for walking (up wraps Attack round to Item, left opens
        # the drawer) does not pick for the player (playtest, 10/28).
        self._settle = BattleSettings.FIRST_COMMANDS_SETTLE
        self._battle_finished = False
        self.command_menu = Menu(
            items=[
                MenuItem("Attack", self._on_attack),
                MenuItem("", self._on_tech),
                MenuItem("Element", self._on_open_abilities),
                MenuItem("Item", self._on_open_items),
            ],
        )
        # Which page of commands shows: -1 Weapon and Escape, 0 the four
        # commands, 1 Team Up and Swap (D-455). Built when turned to.
        self._page = 0
        self._select_held = False      # Select held over a command: the window saying what it does.
        self.side_menu: Menu | None = None
        # Weapon, Team Up and Swap open a list that takes the window.
        self.list_menu: Menu | None = None
        # The Attack's stroke menu, open from the first target pick until
        # the turn ends.
        self.stroke_menu: Menu | None = None
        self._chain_target_id: str | None = None
        self.ability_menu: GridMenu | None = None
        # The stance switch's sign colors, (to, from), while its row is on the grid,
        # and whether the window over its name, asking to switch, is open.
        self._switch_pair: tuple[str, str] | None = None
        self._switch_open = False
        # The held stance's move rows, put aside while the window previews the other's.
        self._held_rows: list[GridRow] | None = None
        self.item_menu: Menu | None = None
        self._pending_command: dict[str, Any] | None = None
        self._target_pool: list[Combatant] = []
        self._target_cursor: int = 0
        self.tutorial = HinaTutorial(self) if tutorial else None
        both = {"kailo", "hina"} <= {c.id for c in self.battle.party}
        escape = (can_escape and not story and self._music != "boss"
                  and not self.gm.party.flags.get(TutorialSettings.ESCAPE_FLAG))
        if self.tutorial is None and both and (escape or self.gm.party.flags.get(TutorialSettings.LESSONS_LEFT_FLAG)):
            # A later fight: the lessons the taro patch never reached, and escape
            # (game/answers.md, Frankie 10/26).
            self.tutorial = HinaTutorial(self, later=True, escape=escape)
        # Who grumbles once swapped in, after the swap lesson.
        self._swap_complaint: str | None = None
        # A line someone says in the fight takes a box across the bottom, the
        # field's size, until it is closed with confirm (Frankie, 10/27); each
        # waits for the narration before it to finish.
        self.talk_box = TextBox()
        self._sayings: deque[tuple[str, str]] = deque()

    def on_enter(self) -> None:
        """Play the fight's music, the boss songs if a boss is here; victory keeps its own."""
        if self.gm.audio.screen != self._won_music:
            self.gm.audio.play_screen(self._music)

    # ------------------------------------------------------------------
    # COMMAND HANDLERS
    # ------------------------------------------------------------------

    def _on_attack(self) -> None:
        """Choose the enemy to strike, then open the stroke menu; mid-chain, strike on."""
        if self.battle.chaining:
            self._open_stroke_menu()
            return
        standing = [c for c in self.battle.enemies if c.alive]
        if len(standing) == 1:
            # One enemy: no pointer, straight to the strokes (Frankie, 11/3, Mark's playtest).
            self._chain_target_id = standing[0].id
            self._open_stroke_menu()
            return
        self._begin_targeting({"kind": "chain"}, pool="foe")

    def _open_stroke_menu(self) -> None:
        """Open the stroke menu: three strokes, then Element.

        The strokes' labels, with their chance to land, are written each
        frame by ``_refresh_command_labels``.
        """
        items = [
            MenuItem("", lambda kind=kind: self._on_stroke(kind))
            for kind in _STROKE_KINDS
        ]
        items += [
            MenuItem("Element", self._on_open_abilities, help=BattleSettings.HELP["Element"]),
        ]
        self.stroke_menu = Menu(items=items, on_cancel=self._cancel_stroke_menu)

    def _on_stroke(self, kind: str) -> None:
        """Swing a stroke at the chosen enemy, or pick a new one if it fell."""
        target = self.battle.chain_target()
        if target is None:
            target = next(
                (c for c in self.battle.enemies
                 if c.id == self._chain_target_id and c.alive),
                None,
            )
        if target is None:
            standing = [c for c in self.battle.enemies if c.alive]
            if len(standing) == 1:
                # One enemy left: the stroke goes to it, no pointer in between, so the
                # press meant for the stroke never lands on a target step (Frankie, 11/3,
                # Mark's playtest wasted a stroke there).
                self._chain_target_id = standing[0].id
                self._dispatch(self.battle.submit_stroke(kind, standing[0].id))
                return
            self._begin_targeting({"kind": "stroke", "stroke": kind}, pool="foe")
            return
        self._dispatch(self.battle.submit_stroke(kind, target.id))

    def _cancel_stroke_menu(self) -> None:
        """Back out to the commands. Mid-chain the target is kept for Attack (D-578)."""
        self.stroke_menu = None
        if not self.battle.chaining:
            self._chain_target_id = None

    def _on_defend(self) -> None:
        """Defend at once; it has no target."""
        self._back_to_commands()
        self._dispatch(self.battle.submit_defend())

    # ------------------------------------------------------------------
    # Skill: KAILO'S COOK
    # ------------------------------------------------------------------

    def _held_skill(self, actor: Any) -> dict[str, Any] | None:
        """The Skill ``actor`` has with the weapon type in hand, or None.

        Each character has three, one per weapon type, and only the one
        for the type held works (Frankie, 10/31). Holding nothing they can
        use, they have none.
        """
        if actor is None or actor.weapon_type is None:
            return None
        return skill_for(actor.id, actor.weapon_type)

    def _on_tech(self) -> None:
        """The signature command, the Skill of the weapon type in hand.

        Scold, Charm, Paddle and Banish pick an enemy; Call ends the turn at once;
        Cook lists the dishes Kailo has learned, Pound his moves.
        """
        skill = self._held_skill(self.battle.current_actor)
        if skill is None or skill["id"] not in _SKILLS_BUILT:
            return
        if skill["id"] in ("scold", "charm", "paddle", "banish", "vault"):
            self._begin_targeting({"kind": skill["id"]}, pool="foe")
        elif skill["id"] == "wili":
            # No target to pick: the time starts, each turn of the pad is a cast at a random enemy (_run_wili, Frankie, 11/1).
            self.spin = SpinMeter(self.battle.current_actor.mana, self._ease("wili"))
        elif skill["id"] == "pound":
            self._on_open_pound()
        elif skill["id"] == "dance":
            self._on_open_dance()
        elif skill["id"] == "call_the_dead":
            if self.battle.spirit_out:
                return
            # Alternate A and B in her own rhythm; the tighter, the stronger the spirit (Frankie, 11/1).
            self._start_minigame(RhythmMeter(self._ease("call_the_dead")),
                                 lambda m: self.battle.submit_call(m.quality))
        elif skill["id"] == "moepapa":
            # One tap on the shrinking circle, drawn on the middle enemy; the curse reaches them all (Frankie, 11/1).
            standing = [c for c in self.battle.enemies if c.alive]
            if not standing:
                return
            middle = standing[len(standing) // 2].id
            self._start_minigame(TapMeter(middle, self._ease("moepapa")),
                                 lambda m: self.battle.submit_moepapa(m.share or 0.0))
        else:
            self._on_open_cook()

    def _on_open_cook(self) -> None:
        """List the dishes Kailo has learned by his tool level; the player picks one (Frankie, 10/31).

        A dish he lacks the ingredients for shows grey but can still be opened, so he
        learns what it is made of and what to go get.
        """
        dishes = self.battle.cook_dishes(self.battle.current_actor)
        bag = self.gm.party.inventory
        self.list_menu = Menu(
            items=[MenuItem(BattleSettings.COOK_DISHES[d], lambda d=d: self._on_open_ingredients(d),
                            color=None if all(stew.have(self.gm.party, i) > 0 for i in BattleSettings.COOK_RECIPES[d])
                            else ColorSettings.GRAY,
                            help=item_help(_DISH_ITEMS[d]))
                   for d in dishes],
            on_cancel=self._close_list_menu,
        )
        self._skill_listing = True

    def _on_open_ingredients(self, dish: str, picked: frozenset[str] = frozenset()) -> None:
        """Show only the ingredients ``dish`` needs; the player picks each, and the last one cooks it (Frankie, 10/31).

        One he lacks shows grey and cannot be picked; B goes back to the dishes.
        """
        bag = self.gm.party.inventory
        rows = []
        for item in BattleSettings.COOK_RECIPES[dish]:
            have = stew.have(self.gm.party, item) > 0   # "fish" is any kind of fish (Frankie, 11/2)
            rows.append(MenuItem(
                ItemSettings.NAMES.get(item, item),
                lambda item=item: self._on_ingredient_picked(dish, picked | {item}),
                enabled=have and item not in picked,
                color=ColorSettings.YELLOW if item in picked else None,
                help=item_help(item) or None,
            ))
        self.list_menu = Menu(items=rows, on_cancel=lambda: (self._close_list_menu(), self._on_open_cook()))
        self._skill_listing = True

    def _on_ingredient_picked(self, dish: str, picked: frozenset[str]) -> None:
        """Cook once every ingredient is picked, else show the list again with this one marked."""
        if picked >= set(BattleSettings.COOK_RECIPES[dish]):
            self._on_cook_chosen(dish)
        else:
            self._on_open_ingredients(dish, picked)

    def _on_cook_chosen(self, dish: str) -> None:
        """Start cooking ``dish``, its ingredients taken from the bag (Frankie, 10/31); the turn ends."""
        self._close_list_menu()
        bag = self.gm.party.inventory
        for item in BattleSettings.COOK_RECIPES[dish]:
            stew.spend(bag, item, 1)
        # Stir the pot, steady, not fast (Frankie, 11/1); the dish goes on when the time is up.
        self._start_minigame(StirMeter(dish, self._ease("cook")),
                             lambda m: self.battle.submit_cook(dish, m.quality))

    def _on_open_pound(self) -> None:
        """List the Pound moves Kailo has learned by his handwraps level (Frankie, 10/31)."""
        moves = self.battle.pound_moves(self.battle.current_actor)
        self.list_menu = Menu(
            items=[MenuItem(m["name"], lambda m=m: self._on_pound_chosen(m), help=m.get("description")) for m in moves],
            on_cancel=self._close_list_menu,
        )
        self._skill_listing = True

    def _luck_share(self, target: Any) -> float:
        """The share of Paddle's or Pound's clock a lucky enemy leaves, or the luckiest enemy standing
        for one that hits them all (Frankie, 11/1, in place of the dodge roll)."""
        if target is None:
            luck = max((c.points["evasion"] for c in self.battle.enemies if c.alive), default=0)
        else:
            luck = target.points["evasion"]
        return BattleSettings.skill_seconds(1.0, luck)

    def _on_pound_chosen(self, move: dict[str, Any]) -> None:
        """Pick the enemy, or start the buttons at once for a move that hits them all."""
        self._close_list_menu()
        if move["target"] == "all":
            self.pound = PoundMeter(move, None, ease=self._ease("pound") * self._luck_share(None))
        else:
            self._begin_targeting({"kind": "pound", "move": move}, pool="foe")

    def _on_open_dance(self) -> None:
        """List the Dance moves Hina has learned by her fan level (Frankie, 10/31)."""
        moves = self.battle.dance_moves(self.battle.current_actor)
        self.list_menu = Menu(
            items=[MenuItem(m["name"], lambda m=m: self._on_dance_chosen(m), help=m.get("description")) for m in moves],
            on_cancel=self._close_list_menu,
        )
        self._skill_listing = True

    def _on_dance_chosen(self, move: dict[str, Any]) -> None:
        """Pick the ally, or start the buttons at once for a move that reaches them all."""
        self._close_list_menu()
        if move["target"] == "all":
            # A rhythm game on four rows (Frankie, 11/1).
            self._start_dance(move, None)
        else:
            self._begin_targeting({"kind": "dance", "move": move}, pool="ally")

    def _on_open_abilities(self) -> None:
        """Open the active member's techniques as a grid (D-450).

        On top, the switch: the stance the member is in, in its element's
        colour, after the two-color recycle sign and before the member's
        element icons, the stance's boxed (Frankie, 10/26; it builds a mana, D-285).
        A on it opens a window over the name asking for the other stance.
        Under it one row per mana cost that has something in this stance,
        three slots across, greyed while the meter is short of the row.
        Revive is greyed while nobody is down. The cursor opens on the
        cheapest move, or with Memory on the last thing picked here.
        """
        actor = self.battle.current_actor
        if actor is None:
            return
        rows: list[GridRow] = []
        other = self.battle.other_stance(actor)
        self._switch_open = False
        self._switch_pair = None
        self._held_rows = None
        if other is not None:
            held = actor.stances[actor.stance]
            style = ColorSettings.ELEMENT_TEXT_STYLES.get(held["element"], {})
            self._switch_pair = (other["element"], held["element"])
            rows.append(GridRow("", [GridCell(
                held["name"],
                self._open_switch_window,
                color=style.get("color"), glow=style.get("glow"),
                glow_radius=style.get("glow_radius", 3),
                glow_alpha=style.get("glow_alpha", 90),
                tag=switch_icon(*self._switch_pair),
                after=stance_icons(actor.elements, actor.stance_element),
                help=held.get("about"),
            )]))
        rows += self._move_rows(actor)
        if not rows:
            return
        grid = GridMenu(rows, on_cancel=self._close_ability_menu)
        grid.row, grid.col = (1 if other is not None and len(rows) > 1 else 0), 0
        if config.current.cursor == "Memory":
            picked = config.current.element_cursors.get(actor.id)
            for r, row in enumerate(rows):
                for c, cell in enumerate(row.cells):
                    if cell is not None and picked == (cell.data["id"] if cell.data is not None else _SWITCH):
                        grid.row, grid.col = r, c
        self.ability_menu = grid

    def _remember_element(self, picked: str) -> None:
        """Note the move (or the switch) the one acting picked from the grid, for Memory."""
        actor = self.battle.current_actor
        if actor is not None:
            config.current.element_cursors[actor.id] = picked

    def _open_switch_window(self) -> None:
        """A on the switch: the window over the stance's name, asking for the other one."""
        self._switch_open = True
        self._preview_stance(True)

    def _preview_stance(self, on: bool) -> None:
        """While the window flashes, the moves below are the other stance's; B puts them back (Frankie, 10/26)."""
        actor = self.battle.current_actor
        grid = self.ability_menu
        if actor is None or grid is None or self._switch_pair is None:
            return
        if on:
            self._held_rows = grid.rows[1:]
            grid.rows[1:] = self._move_rows(actor, 1 - actor.stance)
        elif self._held_rows is not None:
            grid.rows[1:] = self._held_rows
            self._held_rows = None

    def _move_rows(self, actor: Combatant, stance: int | None = None) -> list[GridRow]:
        """One grid row per mana cost with something in the stance (the one held, or ``stance``).

        Three slots across, each move in its element's colour, greyed
        while the meter is short of it; Revive greyed while nobody is down.
        """
        rows: list[GridRow] = []
        moves = self.battle.moves_for(actor, stance)
        for row in range(1, LoadoutSettings.ROWS + 1):
            here = [m for m in moves if self.battle.row_of(actor, m) == row]
            if not here:
                continue
            cells: list[GridCell | None] = []
            for move in here:
                style = ColorSettings.ELEMENT_TEXT_STYLES.get(move["element"], {})
                cells.append(GridCell(
                    short_move_name(move),
                    lambda move=move: self._on_ability_chosen(move),
                    # A raising element can be aimed at an enemy too (Frankie, 11/3), so it is never greyed for want of the fallen.
                    enabled=self.battle.can_afford(actor, move),
                    color=style.get("color"), glow=style.get("glow"),
                    glow_radius=style.get("glow_radius", 3),
                    glow_alpha=style.get("glow_alpha", 90),
                    data=move,
                    help=move.get("description"),
                ))
            cells += [None] * (LoadoutSettings.PER_ROW - len(cells))
            rows.append(GridRow(
                str(row), cells,
                BattleStageSettings.COLOR_MANA if actor.mana >= row else ColorSettings.GRAY,
            ))
        return rows

    def _on_stance_chosen(self) -> None:
        """Switch stance; it ends the turn."""
        self._remember_element(_SWITCH)
        self._switch_open = False
        self.ability_menu = None
        self._dispatch(self.battle.submit_stance())

    def _on_ability_chosen(self, move: dict[str, Any]) -> None:
        """Use a move with no target at once; otherwise choose a target."""
        self._remember_element(move["id"])
        self.ability_menu = None
        if move["target"] == "none":
            self._dispatch(self.battle.submit_move(move["id"]))
            return
        # Any element can aim at either side (Frankie, 11/3): its own side first, then the other.
        self._begin_targeting(
            {"kind": "move", "move_id": move["id"]}, pool=move["target"], either=True
        )

    def _close_ability_menu(self) -> None:
        """Back out of the ability submenu to the command menu."""
        self._switch_open = False
        self.ability_menu = None

    def _on_open_items(self) -> None:
        """Open the item submenu: Noni, the other plants and dishes, and the Seer's Shell."""
        items = []
        if self.battle.noni > 0:
            items.append(MenuItem(f"Noni x{self.battle.noni}", self._on_noni_chosen, help=item_help("noni")))
        for item_id in ItemSettings.HEALS:
            count = self.gm.party.inventory.get(item_id, 0)
            if item_id != "noni" and count > 0:
                items.append(MenuItem(f"{ItemSettings.NAMES[item_id]} x{count}",
                                      lambda item_id=item_id: self._on_dish_chosen(item_id),
                                      help=item_help(item_id) or None))
        for item_id in ItemSettings.CURES:
            count = self.gm.party.inventory.get(item_id, 0)
            if count > 0:
                items.append(MenuItem(f"{ItemSettings.NAMES[item_id]} x{count}",
                                      lambda item_id=item_id: self._on_cure_chosen(item_id),
                                      help=item_help(item_id) or None))
        for item_id in ItemSettings.REVIVES:
            count = self.gm.party.inventory.get(item_id, 0)
            # Usable on a fallen ally or on any enemy (Frankie, 11/3), so it shows whenever it is in the bag.
            if count > 0:
                items.append(MenuItem(f"{ItemSettings.NAMES[item_id]} x{count}",
                                      lambda item_id=item_id: self._on_revive_chosen(item_id),
                                      help=item_help(item_id) or None))
        shells = self.gm.party.inventory.get(ItemSettings.SEER_SHELL, 0)
        if shells > 0:
            items.append(MenuItem(f"Seer's Shell x{shells}", self._on_seer_shell_chosen,
                                  help=item_help(ItemSettings.SEER_SHELL) or None))
        if not items:
            return
        self.item_menu = Menu(items=items, on_cancel=self._close_item_menu)

    def _on_dish_chosen(self, item_id: str) -> None:
        """Start choosing who gets the dish from the bag."""
        self.item_menu = None
        self._begin_targeting({"kind": "dish", "item": item_id}, pool="ally_or_foe")

    def _on_cure_chosen(self, item_id: str) -> None:
        """Start choosing who gets the plant that cures."""
        self.item_menu = None
        self._begin_targeting({"kind": "cure", "item": item_id}, pool="ally_or_foe")

    def _on_revive_chosen(self, item_id: str) -> None:
        """Start choosing which fallen ally gets the item that raises them."""
        self.item_menu = None
        self._begin_targeting({"kind": "revive", "item": item_id}, pool="fallen_or_foe")

    def _on_seer_shell_chosen(self) -> None:
        """Start choosing which enemy to look at through the shell."""
        self.item_menu = None
        self._begin_targeting({"kind": "seer_shell"}, pool="foe")

    def _on_noni_chosen(self) -> None:
        """Start choosing who gets the Noni."""
        self.item_menu = None
        self._begin_targeting({"kind": "noni"}, pool="ally_or_foe")

    def _close_item_menu(self) -> None:
        """Back out of the item submenu to the command menu."""
        self.item_menu = None

    # ------------------------------------------------------------------
    # THE SIDE PAGES (D-455)
    # ------------------------------------------------------------------

    def _turn_page(self, step: int) -> bool:
        """Turn to the page left (-1) or right (+1) of this one, if there is one."""
        page = self._page + step
        if page not in (-1, 0, 1):
            return False
        self._page = page
        self.side_menu = None
        if page == -1:
            self.side_menu = Menu(items=[
                MenuItem("Weapon", self._on_open_weapons, enabled=bool(self._spare_weapons())),
                MenuItem("Escape", self._on_escape, enabled=self.can_escape),
                MenuItem("Defend", self._on_defend),
            ], on_cancel=self._back_to_commands)
            # The page opens on Defend, never Escape: one press left and confirm
            # ran from a fight meant to be defended (Frankie, 11/3, from Mark's playtest).
            self.side_menu.cursor = 2
        elif page == 1:
            items = []
            if self.battle.combos_for(self.battle.current_actor):
                items.append(MenuItem("Team Up", self._on_open_combos))
            items.append(MenuItem(
                "Swap", self._on_open_swap,
                # No swapping once a stroke is swung (D-578).
                enabled=(any(c.alive for c in self.battle.bench) and not self.battle.chaining
                         and self.battle.current_actor.id != self._swap_locked),
            ))
            self.side_menu = Menu(items=items, on_cancel=self._back_to_commands)
        return True

    def _back_to_commands(self) -> None:
        """Back to the page of four commands."""
        self._page = 0
        self.side_menu = None

    def _spare_weapons(self) -> list[dict[str, Any]]:
        """Return the weapons the one acting could take up instead of their own.

        Only what the party carries that they can use, the Equip screen's
        pool (Frankie, 10/24; it was every weapon of their types, the
        browser's Free Battle list).
        """
        from core.scenes.equip_scene import candidates

        actor = self.battle.current_actor
        member = self.gm.party.find(actor.id) if actor is not None and self.gm.party else None
        if member is None:
            return []
        weapons = by_id("weapons")
        return [weapons[w] for w in candidates(self.gm.party, member, "weapon") if w != member.weapon]

    def _on_open_weapons(self) -> None:
        """List the weapons to change to, each with its icon."""
        self.list_menu = Menu(
            items=[
                MenuItem(w["name"], lambda w=w: self._on_weapon_chosen(w), tag=item_icon(w["id"]),
                         help=item_help(w["id"]) or None)
                for w in self._spare_weapons()
            ],
            on_cancel=self._close_list_menu,
        )

    def _on_weapon_chosen(self, weapon: dict[str, Any]) -> None:
        """Change weapons: the new one from the bag, the old one into it. It ends the turn."""
        from core.equipment import weapon_multipliers
        from core.scenes.equip_scene import put_on

        self._close_list_menu()
        self._back_to_commands()
        member = self.gm.party.find(self.battle.current_actor.id)
        put_on(self.gm.party, member, "weapon", weapon["id"])
        self._dispatch(self.battle.submit_weapon(
            weapon["name"], weapon_multipliers(weapon["id"]), mastery.type_held(member.id, weapon["id"])))

    def _on_escape(self) -> None:
        """Try to run."""
        self._back_to_commands()
        self._dispatch(self.battle.submit_escape())

    def _on_open_combos(self) -> None:
        """List the Team Ups open now (Frankie, 11/1: once "combos"), each with its cost and partner."""
        actor = self.battle.current_actor
        items = []
        for combo, partner in self.battle.combos_for(actor):
            label = f"{combo['name']:<13}{short_name(partner.id)}"
            enabled = self.battle.can_pay_combo(actor, partner)
            items.append(MenuItem(
                label, lambda combo=combo, partner=partner: self._on_combo_chosen(combo, partner),
                enabled=enabled,
                tag=self._cost_and_icons(BattleSettings.COMBO_MANA, combo["elements"], enabled),
                help=combo.get("description"),
                help_icon=pair_icons(combo["elements"]),
            ))
        self.list_menu = Menu(items=items, on_cancel=self._close_list_menu)
        self._team_up_listing = True

    @staticmethod
    def _cost_and_icons(cost: int, element_ids, enabled: bool) -> pygame.Surface:
        """A Team Up's cost, then its two element icons, before the name, as the element grid puts
        the cost first (Frankie, 11/3)."""
        size = FontSettings.SIZE_BODY
        text = f"{cost} "
        icons = pair_icons(element_ids)
        width = text_renderer.text_width(text, size)
        surface = pygame.Surface((width + icons.get_width(), max(size, icons.get_height()) + 2), pygame.SRCALPHA)
        text_renderer.draw_text(surface, text, (0, 0), ColorSettings.WHITE if enabled else ColorSettings.GRAY, size=size)
        surface.blit(icons, (width, 0))
        return surface

    def _on_combo_chosen(self, combo: dict[str, Any], partner: Combatant) -> None:
        """Strike at once if the combo hits everyone; otherwise choose the enemy."""
        self._close_list_menu()
        if combo["target"] == "none":
            self._back_to_commands()
            self._dispatch(self.battle.submit_combo(combo["id"], partner.id))
            return
        self._begin_targeting(
            {"kind": "combo", "combo_id": combo["id"], "partner_id": partner.id},
            pool="foe",
        )

    def _on_open_swap(self) -> None:
        """List who waits on the bench."""
        self.list_menu = Menu(
            items=[
                MenuItem(short_name(c.id), lambda c=c: self._on_swap_chosen(c.id), enabled=c.alive)
                for c in self.battle.bench
            ],
            on_cancel=self._close_list_menu,
        )

    def _on_swap_chosen(self, bench_id: str) -> None:
        """Bring the bench member in; the turn is theirs."""
        self._close_list_menu()
        self._back_to_commands()
        self._dispatch(self.battle.submit_swap(bench_id))

    def _close_list_menu(self) -> None:
        """Back out of the Weapon, Team Up, Swap, Cook or Pound list to its page."""
        self.list_menu = None
        self._team_up_listing = False
        self._skill_listing = False

    def _dispatch(self, events: list[Any]) -> None:
        """Queue the battle's events to be played back one at a time."""
        self._events.extend(events)
        if self.tutorial is not None:
            self.tutorial.saw(events)
        # A member acting in a stance unlocks its art's Lore page (Frankie, 10/23).
        members = {c.id: c for c in self.battle.party + self.battle.bench}
        for ev in events:
            who = ev.attacker_id if isinstance(ev, StrokeEvent) else ev.user_id if isinstance(ev, AbilityUsedEvent) else None
            if who in members and members[who].stances:
                lore.unlock(self.gm.party, "stance " + members[who].stances[members[who].stance]["name"])
        if not self.battle.is_awaiting_command():
            # The turn is over: the next one opens on the commands.
            self.stroke_menu = None
            self.ability_menu = None
            self.list_menu = None
            self._back_to_commands()
            self._chain_target_id = None
        if any(isinstance(ev, BattleEndedEvent) for ev in events):
            self._sync_party_state_back()

    def _sync_party_state_back(self) -> None:
        """Write battle-mutated state back onto the persistent ``Party``.

        Called once, when the battle produces its ``BattleEndedEvent``.
        Pushes each party combatant's HP back onto the matching
        ``PartyMember`` so damage carries into the overworld and the
        next save, and writes the Noni left back onto
        ``Party.inventory``.

        A lost fight is the exception: the party walks away at full
        HP, so a lost story fight can be fought again, and the lost
        taro patch goes on with the game rested, Melia having driven
        the boars off (Frankie, 10/26). Any other lost fight is game
        over, which throws all of this away.
        """
        lost = self.battle.outcome == "defeat"
        won = self.battle.outcome == "victory"
        fighters: list[Fighter] = []
        for combatant in self.battle.party + self.battle.bench:
            member = self.gm.party.find(combatant.id)
            if member is None:
                continue
            # What grew in the fight stays grown (D-498), so the member's
            # stats, max HP included, are worked out again first.
            member.growth = dict(combatant.growth)
            member.meters = dict(combatant.meters)
            member.mastery = dict(combatant.mastery)
            member.refresh_stats()
            # The stance is whatever was last set, a fight's switch included;
            # there is no default (Frankie, 10/28).
            if combatant.stances:
                member.stance = combatant.stance
            # The fight's max HP follows the stance (D-365); the share of
            # it is what carries back out.
            share = combatant.hp / max(1, combatant.max_hp)
            member.current_hp = (
                member.max_hp if lost
                else max(0, min(round(share * member.max_hp), member.max_hp))
            )
            if won and combatant in self.battle.party:
                fighters.append(self._fighter(member, combatant))
        self.gm.party.inventory["noni"] = max(0, int(self.battle.noni))
        # What a scolded monster gave away is the party's, won or lost.
        for item in self.battle.gifts:
            self.gm.party.inventory[item] = self.gm.party.inventory.get(item, 0) + 1
        if won:
            party = self.gm.party
            pule = party.pule
            items = self._collect_drops()
            # Hina's and Kailo's party passives (systems/passives.py).
            lines = after_victory(party)
            # A weapon type that rose a level (Frankie, 10/30): one short line each.
            for combatant in self.battle.party + self.battle.bench:
                for type_id, level in combatant.mastery_ups.items():
                    lines.append((None, f"{short_name(combatant.id)}: {mastery.type_name(type_id)} mastery Lv {level}!"))
            # A fight won with nobody left standing (a last blow that cost the
            # striker too): the first gets up with 1 HP, so the map is never
            # walked by a party all knocked out.
            if all(m.current_hp <= 0 for m in party.members):
                party.members[0].current_hp = 1
                lines.append((None, f"{short_name(party.members[0].id)} gets back up."))
            for fighter in fighters:
                fighter.hp_after = stance_numbers(party.find(fighter.member_id))[1]
            self.victory = VictoryReport(
                fighters=fighters, items=items, pule=(pule, party.pule),
                kupang=(party.kupang, party.kupang), lines=lines,
            )
        # A weapon changed in the fight stays changed (D-462).
        by_name = {w["name"]: w["id"] for w in by_id("weapons").values()}
        for combatant in self.battle.party + self.battle.bench:
            member = self.gm.party.find(combatant.id)
            if member is not None and combatant.weapon in by_name:
                member.weapon = by_name[combatant.weapon]
        # A swap in the fight carries over: whoever ended it fighting
        # stays in the first three.
        order = [c.id for c in self.battle.party + self.battle.bench]
        self.gm.party.members.sort(
            key=lambda m: order.index(m.id) if m.id in order else len(order)
        )
        # Every monster beaten gets its bestiary page (D-458).
        from core.scenes.bestiary_scene import beaten_flag  # local: cycle.
        from systems.loadout import open_slots

        slots_before = open_slots(self.gm.party.flags)
        for enemy in self.battle.enemies:
            if not enemy.alive and not enemy.gone:
                self.gm.party.flags[beaten_flag(enemy.name)] = True
        # A boss beaten opens one more element slot for the whole party (Frankie, 11/1).
        slots_after = open_slots(self.gm.party.flags)
        if self.victory is not None and slots_after != slots_before:
            self.victory.opened = (slots_after, [now - was for was, now in zip(slots_before, slots_after)])
        # And counts toward a hunters' lodge bounty, if one is taken (Frankie, 10/26).
        if self.battle.outcome == "victory":
            beaten = [kind["id"] for enemy, kind in zip(self.battle.enemies, self._kinds)
                      if not enemy.alive and not enemy.gone]
            for board in self.gm.data.load("bounties").values():
                # The count shows on the victory screen, so the player never forgets the hunt (Frankie, 10/28).
                told = bounties.record(self.gm.party, board, beaten)
                if told and self.victory is not None:
                    self.victory.lines.append((None, told))

    def _collect_drops(self) -> dict[str, int]:
        """Add what the monsters left to the party; return the items, for the victory screen."""
        pule, items = roll_drops(self._kinds)
        self.gm.party.pule += pule
        for item_id, count in items.items():
            self.gm.party.inventory[item_id] = self.gm.party.inventory.get(item_id, 0) + count
        return items

    @staticmethod
    def _fighter(member: "PartyMember", combatant: Combatant) -> Fighter:
        """One who fought, for the victory screen: their stats before what grew in the fight, and after.

        Both in the stance they start a fight in, as the field menu shows them.
        """
        after, hp, top = stance_numbers(member)
        grown = dict(combatant.grown)
        kept = member.growth
        member.growth = {key: points - grown.get(key, 0) for key, points in kept.items()}
        try:
            before = stance_numbers(member)[0]
        finally:
            member.growth = kept
        return Fighter(member.id, before, after, hp, top, hp, grown)

    # ------------------------------------------------------------------
    # TARGETING
    # ------------------------------------------------------------------

    def _begin_targeting(self, pending: dict[str, Any], pool: str, either: bool = False) -> None:
        """Enter target selection over the living foes or allies, or the fallen ones.

        With ``either`` the other side's living follow (Frankie, 11/3: elements aim at either side).
        """
        side = self.battle.enemies if pool == "foe" else self.battle.party
        # Items can be used on enemies too (Frankie, 11/3): the allies first, then the living foes.
        foes = [c for c in self.battle.enemies if c.alive] if pool.endswith("_or_foe") or (
            either and pool != "foe") else []
        if either and pool == "foe":
            foes = [c for c in self.battle.party if c.alive and not c.aloft]
        if pool in ("fallen", "fallen_or_foe"):
            candidates = [c for c in side if not c.alive] + foes
        elif pool == "other":
            # Another ally, not the one acting (Nectar).
            actor = self.battle.current_actor
            candidates = [c for c in side if c.alive and not c.aloft and c is not actor]
        else:
            # Maika up on his Vault cannot be picked (Frankie, 11/2).
            candidates = [c for c in side if c.alive and not c.aloft] + foes
        if not candidates:
            return
        self._pending_command = pending
        self._target_pool = candidates
        self._target_cursor = 0
        if self._heals(pending):
            # A heal's pointer starts on the first who is hurt, not on a full-HP leader.
            self._target_cursor = next(
                (n for n, c in enumerate(candidates) if c.hp < c.max_hp), 0)

    def _heals(self, pending: dict[str, Any]) -> bool:
        """True for a command that restores HP: a dish, Noni, or a move with a heal."""
        if pending["kind"] in ("dish", "noni"):
            return True
        return pending["kind"] == "move" and bool(self.battle.move(pending["move_id"]).get("heal"))

    def _on_target_confirmed(self) -> None:
        """Submit the pending command against the highlighted target."""
        if not self._pending_command or not self._target_pool:
            return
        target = self._target_pool[self._target_cursor]
        cmd = self._pending_command
        said: list[tuple[str, str]] = []
        if cmd["kind"] == "dish" and target.is_party:
            outcome, said = diet.respond(target.id, cmd["item"], [c.id for c in self.battle.party if c.alive])
            if outcome == "refuse":
                # They will not eat it (Frankie, 11/2): they say so, nothing is spent, pick again.
                self.gm.audio.play("cant")
                for speaker, line in said:
                    self._say(short_name(speaker), line)
                return
        self._clear_targeting()
        for speaker, line in said:
            self._say(short_name(speaker), line)
        if cmd["kind"] == "chain":
            self._chain_target_id = target.id
            self._open_stroke_menu()
        elif cmd["kind"] == "stroke":
            self._chain_target_id = target.id
            self._dispatch(self.battle.submit_stroke(cmd["stroke"], target.id))
        elif cmd["kind"] == "move":
            # A move that takes from an enemy and gives to someone (Drain,
            # Osmose, Borrowed Life) asks for the second one next.
            give_to = self.battle.move(cmd["move_id"]).get("give_to")
            if give_to and "from_id" not in cmd:
                self._begin_targeting({**cmd, "from_id": target.id}, pool=give_to)
                if self._pending_command is not None:
                    return
                self._dispatch(self.battle.submit_move(cmd["move_id"], target.id))
                return
            if "from_id" in cmd:
                self._dispatch(self.battle.submit_move(cmd["move_id"], cmd["from_id"], target.id))
            else:
                self._dispatch(self.battle.submit_move(cmd["move_id"], target.id))
        elif cmd["kind"] == "noni":
            self._dispatch(self.battle.submit_noni(target.id))
        elif cmd["kind"] == "dish":
            bag = self.gm.party.inventory
            bag[cmd["item"]] -= 1
            if bag[cmd["item"]] <= 0:
                del bag[cmd["item"]]
            if target.is_party and diet.sickens(target.id, cmd["item"]):
                self._dispatch(self.battle.submit_bag_sick(ItemSettings.NAMES[cmd["item"]], target.id))
                return
            self._dispatch(self.battle.submit_bag_heal(
                ItemSettings.NAMES[cmd["item"]], ItemSettings.HEALS[cmd["item"]], target.id))
        elif cmd["kind"] == "cure":
            bag = self.gm.party.inventory
            bag[cmd["item"]] -= 1
            if bag[cmd["item"]] <= 0:
                del bag[cmd["item"]]
            self._dispatch(self.battle.submit_bag_cure(
                ItemSettings.NAMES[cmd["item"]], ItemSettings.CURES[cmd["item"]], target.id))
        elif cmd["kind"] == "revive":
            bag = self.gm.party.inventory
            bag[cmd["item"]] -= 1
            if bag[cmd["item"]] <= 0:
                del bag[cmd["item"]]
            self._dispatch(self.battle.submit_bag_revive(
                ItemSettings.NAMES[cmd["item"]], ItemSettings.REVIVES[cmd["item"]], target.id))
        elif cmd["kind"] == "scold":
            # Mash A; the presses for the full sulk come from Willpower against the monster's (Frankie, 11/1).
            needed = max(MinigameSettings.SCOLD_PRESSES_LEAST, min(MinigameSettings.SCOLD_PRESSES_MOST, round(
                MinigameSettings.SCOLD_PRESSES / self._ease("scold", target.id))))
            self._start_minigame(
                PaddleMeter(target.id, seconds=MinigameSettings.SCOLD_SECONDS, most=2 * needed,
                            label="Scold!", needed=needed, done_label="Told off!"),
                lambda m, t=target.id, n=needed: self.battle.submit_scold(t, m.presses, n))
        elif cmd["kind"] == "charm":
            # Simon on A, B, X and Y; every round right charms longer (Frankie, 11/1).
            self._start_minigame(SimonMeter(target.id, self._ease("charm", target.id), play=self.gm.audio.play),
                                 lambda m, t=target.id: self.battle.submit_charm(t, m.rounds))
        elif cmd["kind"] == "vault":
            # Banish's circles, one try: held too long, he misses (Frankie, 11/1).
            self._start_minigame(
                BanishMeter(target.id, self._ease("vault", target.id), seconds=MinigameSettings.VAULT_SECONDS,
                            draw_seconds=MinigameSettings.VAULT_DRAW_SECONDS, one_shot=True),
                lambda m, t=target.id: self.battle.submit_vault(t, 0.0 if m.failed else (m.share or 0.0)))
        elif cmd["kind"] == "paddle":
            # The clock starts; each A until it runs out is a hit (_run_paddle). Strength sets the time and
            # a lucky enemy takes some off (both Frankie, 11/1).
            self.paddle = PaddleMeter(target.id, seconds=BattleSettings.PADDLE_SECONDS
                                      * self._ease("paddle", target.id) * self._luck_share(target))
        elif cmd["kind"] == "banish":
            # The time starts; hold A to draw, let go to shoot (_run_banish, Frankie, 10/31).
            # Intelligence against the monster's sets how fast the circle shrinks (Frankie, 11/1).
            self.banish = BanishMeter(target.id, self._ease("banish", target.id))
        elif cmd["kind"] == "pound":
            # The clock starts; the buttons are pressed against it (_run_pound).
            self.pound = PoundMeter(cmd["move"], target.id,
                                    ease=self._ease("pound", target.id) * self._luck_share(target))
        elif cmd["kind"] == "dance":
            # Hina's Dance, a rhythm game on four rows (Frankie, 11/1).
            self._start_dance(cmd["move"], target.id)
        elif cmd["kind"] == "seer_shell":
            bag = self.gm.party.inventory
            bag[ItemSettings.SEER_SHELL] -= 1
            if bag[ItemSettings.SEER_SHELL] <= 0:
                del bag[ItemSettings.SEER_SHELL]
            self._dispatch(self.battle.submit_seer_shell(target.id))
        elif cmd["kind"] == "combo" and cmd["combo_id"] == "vine_whip":
            # Pōhuehue, two games in a row (Frankie, 11/3): the dance grows the vine, the spin cracks it.
            self._back_to_commands()
            self._start_pohuehue(cmd["partner_id"], target.id)
        elif cmd["kind"] == "combo" and cmd["combo_id"] == "solar_fist":
            # Tinju Surya, two games in a row (Frankie, 11/3): the seals light the fist, the tap throws it.
            self._back_to_commands()
            self._start_tinju_surya(cmd["partner_id"], target.id)
        elif cmd["kind"] == "combo":
            self._back_to_commands()
            self._dispatch(self.battle.submit_combo(
                cmd["combo_id"], cmd["partner_id"], target.id
            ))

    def _cancel_targeting(self) -> None:
        """Leave target selection and reopen the menu it came from."""
        cmd = self._pending_command
        self._clear_targeting()
        if cmd is None:
            return
        if cmd["kind"] == "move":
            self._on_open_abilities()
        elif cmd["kind"] in ("noni", "seer_shell", "dish", "cure"):
            self._on_open_items()
        elif cmd["kind"] == "combo":
            self._on_open_combos()

    def _clear_targeting(self) -> None:
        """Forget the pending command and its target list."""
        self._pending_command = None
        self._target_pool = []
        self._target_cursor = 0

    def _move_target_cursor(self, direction: int) -> None:
        """Step the target cursor, wrapping at either end."""
        if not self._target_pool:
            return
        self._target_cursor = (
            self._target_cursor + direction
        ) % len(self._target_pool)

    # ------------------------------------------------------------------
    # PLAYBACK
    # ------------------------------------------------------------------

    def _can_command(self) -> bool:
        """Return True when the player may pick a command right now."""
        return self._commands_up() and self._settle <= 0

    def _commands_up(self) -> bool:
        """Return True when the commands are on screen, waiting on the player."""
        return (
            self.battle.is_awaiting_command()
            and not self._events
            and self._beat <= 0
            and self.text_box.is_done()
            and not self._talking()
            and self.paddle is None
            and self.pound is None
            and self.banish is None
            and self.spin is None
            and self.minigame is None
        )

    def _play_events(self) -> None:
        """Show queued events until one puts a line on screen or a stroke swings."""
        while self._events and self.text_box.is_done() and self._beat <= 0 and not self._talking():
            # A counter waits a beat after the blow it answers (Frankie, 10/28).
            ahead = self._events[0]
            if (isinstance(ahead, DamageEvent) and ahead.cause == "counter"
                    and not self._counter_held):
                self._counter_held = True
                self._beat = BattleSettings.COUNTER_BEAT_SECONDS
                break
            event = self._events.popleft()
            if isinstance(event, DamageEvent) and event.cause == "counter":
                self._counter_held = False
                if self.meter is not None:
                    self._kick_hold = BlockSettings.LINGER_SECONDS
            if isinstance(event, BlockStartEvent):
                # The meter takes the commands' place until the strokes are caught or missed.
                self.meter = BlockMeterView(BlockMeter(event.strokes, event.zone, event.speed, event.perfect))
                self._block_attacker = event.attacker_id
                self._block_target = (event.target_id, event.target_name)
                if self.tutorial is not None:
                    self.tutorial.block_started()
                break
            if isinstance(event, DamageEvent):
                self._shown_hp[event.target_id] -= event.amount
                if event.timed != "perfect":
                    self._hit_sound("hit_magic" if event.cause == "spell" else "hit_punch")
            elif isinstance(event, HealEvent):
                self._shown_hp[event.target_id] += event.amount
                self._hit_sound("hit_sparkle")
                self._hint_nature_heals(event)
            elif isinstance(event, SummonEvent):
                # A monster the Great Boar's Squeal called takes its place in the line (Frankie, 10/28).
                called = next((c for c in self.battle.enemies if c.id == event.combatant_id), None)
                if called is not None:
                    self._shown_hp[called.id] = called.hp
                    self.stage.join(called)
                else:
                    # Tawiri's spirit takes a fourth row, or leaves it (Frankie, 10/25).
                    spirit = next((c for c in self.battle.party if c.id == event.combatant_id), None)
                    if event.joined and spirit is not None:
                        self._shown_hp[spirit.id] = spirit.hp
                    self.stage.summon(spirit if event.joined else None, event.combatant_id)
            elif isinstance(event, RevivedEvent):
                self._shown_hp[event.target_id] = event.hp
                self._hit_sound("hit_sparkle")
            elif isinstance(event, (DodgeEvent, MissEvent)):
                self._hit_sound("hit_miss")
            elif isinstance(event, StanceEvent):
                # A new stance moves max HP and keeps the share (D-365).
                for c in self.battle.party:
                    if c.id == event.combatant_id:
                        self._shown_hp[c.id] = c.hp
            elif isinstance(event, BattleEndedEvent):
                self._battle_finished = True
                if self.battle.outcome == "victory":
                    self.gm.audio.play_screen(self._won_music)
            # A win says nothing here: the victory screen tells it (Frankie, 10/26).
            if not (isinstance(event, BattleEndedEvent) and self.victory is not None):
                self.view.consume(event)
            self.stage.consume(event)
            if isinstance(event, SwapEvent) and event.in_id == self._swap_complaint:
                self._swap_complaint = None
                for speaker, line in StorySettings.SWAP_GRUMBLE:
                    self._say(speaker, line)
            if isinstance(event, StrokeEvent):
                # Paddle's hits come rapidfire (Frankie, 10/31), Wili's at half that speed (Frankie, 11/1).
                self._beat = (BattleSettings.PADDLE_BEAT_SECONDS if event.stroke == "Paddle"
                              else BattleSettings.WILI_BEAT_SECONDS if event.stroke == "Wili"
                              else BattleSettings.STROKE_BEAT_SECONDS)

    def _run_meter(self, dt: float) -> None:
        """Slide the bars, and let each stroke swing and land as its bar does (Frankie, 10/30).

        A bar reaching the zone starts the monster's swing; the stroke lands when the
        press decides it, or as the bar leaves the zone if there was none. If the
        character falls the battle drops the other strokes and the meter goes at once.
        """
        meter = self.meter.meter
        meter.update(dt)
        self.meter.update(dt)
        for _ in meter.entries():
            target_id, target_name = self._block_target
            self.stage.consume(StrokeEvent(self._block_attacker, "", target_id, target_name, ""))
        for index, result in meter.landings():
            events = [e for e in self.battle.block_stroke(result) if not isinstance(e, StrokeEvent)]
            self._dispatch(events)
            if not self.battle.is_awaiting_block():
                # The battle has done with the strokes: a fall ends the meter early.
                if not all(b.landed for b in meter.bars):
                    self.meter = None
                    return
        # The last stroke's kick back lands while its bar is still up (Frankie, 11/2).
        self._kick_hold = max(0.0, self._kick_hold - dt)
        if (meter.done and self._kick_hold <= 0
                and not any(isinstance(e, DamageEvent) and e.cause == "counter" for e in self._events)):
            self.meter = None

    def _ease(self, skill_id: str, target_id: str | None = None) -> float:
        """How easy the acting member's game for ``skill_id`` is, by the stats (Frankie, 11/1)."""
        return self.battle.skill_ease(self.battle.current_actor, skill_id, target_id)

    def _start_dance(self, move: dict[str, Any], target_id: str | None) -> None:
        """Hina's Dance: the move's steps on four rows, and it heals by how much was got (Frankie, 11/1)."""
        self._start_minigame(DanceMeter(move, target_id, self._ease("dance")),
                             lambda m: self.battle.submit_dance(m.move["id"], m.target_id, m.share))

    def _start_pohuehue(self, partner_id: str, target_id: str) -> None:
        """Pōhuehue: the vine danced up, then spun and cracked; it hits by how both went (Frankie, 11/3)."""
        dance = DanceMeter({"id": "pohuehue", "name": "Grow the vine!"}, target_id)

        def spin(danced: DanceMeter) -> list[Any]:
            self._start_minigame(VineMeter("vine_whip", partner_id, target_id, danced.share),
                                 lambda m: self.battle.submit_combo(m.combo_id, m.partner_id, m.target_id, m.quality))
            return []

        self._start_minigame(dance, spin)

    def _start_tinju_surya(self, partner_id: str, target_id: str) -> None:
        """Tinju Surya: the hand seals, then the punch; it hits by how both went (Frankie, 11/3)."""
        seals = SimonMeter(target_id, play=self.gm.audio.play)

        def punch(sealed: SimonMeter) -> list[Any]:
            self._start_minigame(PunchMeter("solar_fist", partner_id, target_id, sealed.rounds),
                                 lambda m: self.battle.submit_combo(m.combo_id, m.partner_id, m.target_id, m.quality))
            return []

        self._start_minigame(seals, punch)

    def _start_minigame(self, meter: Any, done: Any) -> None:
        """Put ``meter`` in the commands' window; ``done(meter)`` gives the battle its result when it ends."""
        self.minigame, self._minigame_done = meter, done

    def _run_minigame(self, dt: float) -> None:
        """Run the minigame's clock; when it is done, the Skill lands by how it went."""
        meter = self.minigame
        meter.update(dt)
        if meter.done:
            done, self.minigame, self._minigame_done = self._minigame_done, None, None
            self._dispatch(done(meter))

    def _minigame_input(self, event: pygame.event.Event) -> None:
        """Pass a press to the minigame up, with its sound."""
        meter = self.minigame
        audio = self.gm.audio
        if isinstance(meter, VineMeter):
            if input_map.is_confirm(event):
                audio.play("perfect" if meter.crack() else "menu_select")
            elif meter.handle(event):
                audio.play("menu_move")
        elif isinstance(meter, StirMeter):
            if meter.handle(event):
                audio.play("menu_move")
        elif isinstance(meter, PaddleMeter):
            if input_map.is_confirm(event) and meter.press():
                audio.play("menu_move")
        elif isinstance(meter, SimonMeter):
            button = button_of(event)
            if button is not None:
                meter.press(button)    # It plays its own sounds.
        elif isinstance(meter, BanishMeter):
            if input_map.is_confirm(event):
                meter.hold()
            elif input_map.is_confirm_up(event):
                meter.release()
        elif isinstance(meter, RhythmMeter):
            button = "A" if input_map.is_confirm(event) else "B" if input_map.is_cancel(event) else None
            if button is not None:
                audio.play("menu_move" if meter.press(button) else "cant")
        elif isinstance(meter, DanceMeter):
            button = button_of(event) or _pound_button(event, self._pound_hat, meter.wanted())
            if event.type == pygame.JOYHATMOTION:
                self._pound_hat = event.value
            if button is not None:
                result = meter.press(button)
                audio.play("perfect" if result == "perfect" else "menu_move" if result == "good" else "cant")
        elif isinstance(meter, TapMeter):
            if input_map.is_confirm(event):
                meter.tap()
                audio.play("menu_select" if meter.share else "cant")

    def _run_paddle(self, dt: float) -> None:
        """Run Paddle's clock; when it is up, every press is swung at once."""
        self.paddle.update(dt)
        if self.paddle.done:
            meter, self.paddle = self.paddle, None
            self._dispatch(self.battle.submit_paddle(meter.target_id, meter.presses))

    def _run_wili(self, dt: float) -> None:
        """Run Wili's clock; when it is up, every turn of the pad is cast at once."""
        self.spin.update(dt)
        if self.spin.done:
            meter, self.spin = self.spin, None
            self._dispatch(self.battle.submit_wili(meter.rotations))

    def _run_banish(self, dt: float) -> None:
        """Run Banish's time and draw; when the arrow flies or the time is up, it lands."""
        self.banish.update(dt)
        if self.banish.done:
            meter, self.banish = self.banish, None
            self._dispatch(self.battle.submit_banish(meter.target_id, meter.share or 0.0))

    def _run_pound(self, dt: float) -> None:
        """Run Pound's clock; when the buttons are done or the time is up, the move lands."""
        self.pound.update(dt)
        if self.pound.done:
            pound, self.pound = self.pound, None
            submit = self.battle.submit_dance if pound.skill == "dance" else self.battle.submit_pound
            self._dispatch(submit(pound.move["id"], pound.target_id, pound.share))

    def _press_block(self) -> None:
        """Confirm on the meter: the sound and word for how it landed."""
        result = self.meter.meter.press()
        if result == "perfect":
            self.gm.audio.play("perfect")
            self.meter.perfect()
        elif result == "catch":
            self.gm.audio.play("menu_select")
        elif result == "miss":
            self.gm.audio.play("cant")

    def _hit_sound(self, kind: str) -> None:
        """Play one of the three takes of a hit sound."""
        take = random.randint(1, AudioSettings.HIT_TAKES)
        self.gm.audio.play(f"{kind}_{take}")

    def _hint_nature_heals(self, event: HealEvent) -> None:
        """Hina's one boar hint, the first time a nature monster heals (Frankie, 11/3)."""
        flags = self.gm.party.flags
        if event.amount <= 0 or flags.get(TutorialSettings.NATURE_HEALS_FLAG):
            return
        healed = next((c for c in self.battle.enemies if c.id == event.target_id), None)
        if healed is None or Element.LAU not in (healed.element, getattr(healed, "stance_element", None), *healed.elements):
            return
        if not any(c.id == "hina" and c.alive for c in self.battle.party):
            return
        flags[TutorialSettings.NATURE_HEALS_FLAG] = True
        self._say("Hina", TutorialSettings.NATURE_HEALS)

    def _teach_team_up(self) -> None:
        """Hina's Team Up lesson, the first time one is open with her in it, once ever
        (Frankie, 11/3, after Mark's playtest: nothing in the game taught it)."""
        flags = self.gm.party.flags
        if flags.get(TutorialSettings.TEAM_UP_FLAG) or self._battle_finished or not self._commands_up():
            return
        if self.stroke_menu is not None or self.list_menu is not None or self._pending_command is not None:
            return
        if self.tutorial is not None and (not self.tutorial.later or self.tutorial.step is not None):
            # Never in the taro patch, which has lessons enough, nor over another lesson.
            return
        actor = self.battle.current_actor
        if actor is None or not actor.is_party:
            return
        partners = [p for _, p in self.battle.combos_for(actor) if self.battle.can_pay_combo(actor, p)]
        if not any("hina" in (actor.id, p.id) for p in partners):
            return
        flags[TutorialSettings.TEAM_UP_FLAG] = True
        for line in TutorialSettings.TEAM_UP:
            self._say("Hina", line)

    def _say(self, speaker: str, line: str) -> None:
        """Have ``speaker`` say ``line`` in the full-width box, once the narration before it is done."""
        self._sayings.append((speaker, line))

    def _talking(self) -> bool:
        """Return True while a said line is up or waiting its turn."""
        return bool(self._sayings) or not self.talk_box.is_done()

    def _hold_narration(self, dt: float) -> None:
        """Advance a finished line by itself after a short hold."""
        if self.text_box.is_done() or not self.text_box.is_page_complete():
            self._narration_held = 0.0
            return
        self._narration_held += dt
        if self._narration_held >= BattleSettings.NARRATION_HOLD_SECONDS:
            self._narration_held = 0.0
            self.text_box.advance()

    def _track_select(self, event: pygame.event.Event) -> None:
        """Note Select going down and up, for the help window (Frankie, 11/1)."""
        if input_map.is_select(event):
            self._select_held = True
        elif (event.type == pygame.KEYUP and event.key in input_map.SELECT_KEYS) or (
                event.type == pygame.JOYBUTTONUP and event.button == InputSettings.JOY_BUTTON_BACK):
            self._select_held = False

    def _help_text(self) -> str | None:
        """What the highlighted row does, or None when it has no words (and while a target is picked).

        On the command pages that is ``BattleSettings.HELP`` (the Skill row, its Skill's words); in a sub menu the
        row's own ``help``: an element's description, the stance's ``about``, an item's field help line.
        """
        if self._pending_command is not None:
            return None
        sub = self.list_menu or self.item_menu or self.ability_menu or self.stroke_menu
        if sub is not None:
            if self._switch_open:
                return None
            row = sub.current if isinstance(sub, GridMenu) else sub.items[sub.cursor] if sub.items else None
            return row.help if row is not None else None
        menu = self.side_menu or self.command_menu
        label = menu.items[menu.cursor].label
        if menu is self.command_menu and menu.cursor == _TECH_ROW:
            skill = self._held_skill(self.battle.current_actor)
            if skill is None:
                return BattleSettings.HELP["No Skill"]
            return f"{skill['name']}: {skill.get('description', '')} {BattleSettings.HELP['Skill']}"
        return BattleSettings.HELP.get(label)

    def _help_icon(self) -> pygame.Surface | None:
        """The picture before Select's words: a Team Up row's two element icons, else None."""
        if self._pending_command is not None or self.list_menu is None or not self.list_menu.items:
            return None
        return self.list_menu.items[self.list_menu.cursor].help_icon

    def _render_help(self, surface: pygame.Surface) -> None:
        """While Select is held, a window over the fight saying what the highlighted command does."""
        text = self._help_text()
        if text is None:
            return
        icon = self._help_icon()
        indent = icon.get_width() + 4 if icon is not None else 0
        edge = UISettings.TEXT_BOX_BORDER_THICKNESS + 4
        width = ScreenSettings.WIDTH - 16
        lines = text_renderer.wrap(text, text_renderer.get_font(FontSettings.SIZE_BODY), width - 2 * edge - indent)
        step = text_renderer.line_height(FontSettings.SIZE_BODY)
        window = pygame.Rect(8, 0, width, len(lines) * step + 2 * edge)
        window.bottom = self._hud_rect(surface).top - 4
        draw_window(surface, window)
        if icon is not None:
            surface.blit(icon, (window.left + edge, window.top + edge))
        for n, line in enumerate(lines):
            text_renderer.draw_text(surface, line, (window.left + edge + indent, window.top + edge + n * step),
                                    color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY)

    def _render_team_up_sign(self, surface: pygame.Surface) -> None:
        """On the four commands, flash a sign to the right when a Team Up is open (Frankie, 11/1).

        Open means both partners can pay for it too, not just that their
        stances make one; any two different stances make one (Frankie, 11/2).
        """
        actor = self.battle.current_actor
        if actor is None or not any(self.battle.can_pay_combo(actor, partner)
                                    for _, partner in self.battle.combos_for(actor)):
            return
        if int(time.monotonic() * UISettings.SWITCH_FLASH_HZ * 2) % 2:
            return
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        size = FontSettings.SIZE_BODY
        sign = BattleSettings.TEAM_UP_SIGN
        x = rect.left + UISettings.COMMAND_PANEL_WIDTH - pad - text_renderer.text_width(sign, size)
        y = self._menu_top(surface, self.command_menu) + _ITEM_ROW * UISettings.COMMAND_MENU_ROW_HEIGHT
        text_renderer.draw_text(surface, sign, (x, y), color=ColorSettings.YELLOW, size=size)

    def _preview_wait(self) -> float | None:
        """Return the wait the highlighted action would cost, for the strip.

        None means nothing specific is highlighted yet (the cursor is on
        Attack or Ability before the choice), and the strip guesses.
        """
        battle = self.battle
        if self._pending_command is not None:
            kind = self._pending_command["kind"]
            if kind in ("chain", "stroke"):
                return None
            if kind == "combo":
                return battle.preview_wait("combo")
            if kind in ("scold", "charm", "paddle", "banish", "pound", "dance", "vault"):
                return battle.preview_wait("tech")
            if kind == "move" and self.moves[self._pending_command["move_id"]].get("signature"):
                return battle.preview_wait("tech")
            return battle.preview_wait("item" if kind in ("noni", "seer_shell", "dish", "cure") else "move")
        if self.ability_menu is not None:
            return battle.preview_wait("move")
        if self.item_menu is not None:
            return battle.preview_wait("item")
        if self.list_menu is not None:
            if self._skill_listing:
                return battle.preview_wait("tech")
            return battle.preview_wait("move" if self._page == 1 else "defend")
        if self.side_menu is not None:
            label = self.side_menu.items[self.side_menu.cursor].label
            if label in ("Weapon", "Escape", "Defend"):
                return battle.preview_wait("defend")
            return battle.preview_wait("combo") if label == "Team Up" else None
        if self.stroke_menu is not None:
            row = self.stroke_menu.cursor
            if row < len(_STROKE_KINDS):
                points = BattleSettings.STROKES[_STROKE_KINDS[row]]["points"]
                return battle.preview_wait("attack") + points * BattleSettings.STROKE_WAIT
            return None
        row = self.command_menu.cursor
        if row == _TECH_ROW and self.command_menu.items[_TECH_ROW].enabled:
            return battle.preview_wait("tech")
        if row == _ITEM_ROW:
            return battle.preview_wait("item")
        return None

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Advance narration, or drive the menus and target cursor."""
        self._track_select(event)
        # Hina's box, and what her lesson locks, come first.
        if self.tutorial is not None and self.tutorial.handle_event(event):
            return
        if self.meter is not None:
            if input_map.is_confirm(event):
                self._press_block()
            return
        if self.minigame is not None:
            self._minigame_input(event)
            return
        if self.paddle is not None:
            if input_map.is_confirm(event) and self.paddle.press():
                self.gm.audio.play("menu_move")
            return
        if self.spin is not None:
            if self.spin.handle(event):
                self.gm.audio.play("menu_move")
            return
        if self.banish is not None:
            if input_map.is_confirm(event):
                self.banish.hold()
            elif input_map.is_confirm_up(event):
                self.banish.release()
            return
        if self.pound is not None:
            button = _pound_button(event, self._pound_hat, self.pound.buttons[self.pound.pressed])
            if event.type == pygame.JOYHATMOTION:
                self._pound_hat = event.value
            if button is not None:
                self.gm.audio.play("menu_move" if self.pound.press(button) else "cant")
            return
        if not self.talk_box.is_done():
            if input_map.is_confirm(event):
                self.talk_box.advance()
            return
        if not self.text_box.is_done():
            if input_map.is_confirm(event):
                self._narration_held = 0.0
                self.text_box.advance()
            return
        if self._battle_finished or not self._can_command():
            return
        if self._pending_command is not None:
            if input_map.is_cancel(event):
                self._cancel_targeting()
                self.gm.audio.play("menu_move")
            elif input_map.is_up(event) or input_map.is_left(event):
                self._move_target_cursor(-1)
                self.gm.audio.play("menu_move")
            elif input_map.is_down(event) or input_map.is_right(event):
                self._move_target_cursor(1)
                self.gm.audio.play("menu_move")
            elif input_map.is_confirm(event):
                self.gm.audio.play("menu_select")
                self._on_target_confirmed()
            return
        if self._switch_open and self.ability_menu is not None:
            # The window over the stance's name: A switches, B backs out to the row.
            if input_map.is_confirm(event):
                self.gm.audio.play("menu_select")
                self._on_stance_chosen()
            elif input_map.is_cancel(event):
                self._switch_open = False
                self._preview_stance(False)
                self.gm.audio.play("menu_move")
            return
        if input_map.is_cancel(event):
            if self.list_menu is not None:
                self.list_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.side_menu is not None:
                self.side_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.item_menu is not None:
                self.item_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.ability_menu is not None:
                self.ability_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.stroke_menu is not None:
                self.stroke_menu.cancel()
                self.gm.audio.play("menu_move")
            return
        on_pages = (
            self.list_menu is None and self.item_menu is None
            and self.ability_menu is None and self.stroke_menu is None
        )
        if on_pages and (input_map.is_left(event) or input_map.is_right(event)):
            if self._turn_page(-1 if input_map.is_left(event) else 1):
                self.gm.audio.play("menu_move")
            return
        active_menu = (
            self.list_menu or self.item_menu or self.ability_menu
            or self.stroke_menu or self.side_menu or self.command_menu
        )
        if input_map.is_up(event):
            if active_menu.move_up():
                self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            if active_menu.move_down():
                self.gm.audio.play("menu_move")
        elif isinstance(active_menu, GridMenu) and input_map.is_left(event):
            if active_menu.move_left():
                self.gm.audio.play("menu_move")
        elif isinstance(active_menu, GridMenu) and input_map.is_right(event):
            if active_menu.move_right():
                self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            if active_menu is self.command_menu or active_menu is self.side_menu:
                self._remember_commands(active_menu)
            if active_menu.confirm():
                self.gm.audio.play("menu_select")

    # ------------------------------------------------------------------
    # CONFIG'S CURSOR (Frankie, 10/26)
    # ------------------------------------------------------------------

    def _open_commands(self) -> None:
        """A turn starts: the commands open on Attack, or with Memory where this one left them."""
        actor = self.battle.current_actor
        self._refresh_command_labels()
        page, row = (0, 0)
        if config.current.cursor == "Memory" and actor is not None:
            page, row = config.current.cursors.get(actor.id, (0, 0))
        self._back_to_commands()
        if page != 0:
            self._turn_page(page)
        menu = self.side_menu if page != 0 else self.command_menu
        if menu is None or not 0 <= row < len(menu.items) or not menu.items[row].enabled:
            # Gone or grayed since (no Noni left, no spare weapon): the page's first row it can.
            menu = menu or self.command_menu
            row = next((i for i, item in enumerate(menu.items) if item.enabled), 0)
        menu.cursor = row
        self._teach_swap()

    def _teach_swap(self) -> None:
        """Once, on the first turn with them on the bench: Hina and they talk, then the swap is forced.

        The page with Swap opens and a list of who sits out takes the window,
        everyone fighting but the one locked in, the cursor on Hina; it cannot
        be backed out of (Frankie, 10/30).
        """
        who = self._swap_lesson
        if who is None or not any(c.id == who and c.alive for c in self.battle.bench):
            return
        self._swap_lesson = None
        self._swap_complaint = who
        for speaker, line in StorySettings.SWAP_TALK:
            self._say(speaker, line)
        self._back_to_commands()
        self._turn_page(1)
        swap = next((i for i, item in enumerate(self.side_menu.items) if item.label == "Swap"), 0)
        self.side_menu.cursor = swap
        out = [c for c in self.battle.party if c.alive and c.id != self._swap_locked]
        self.list_menu = Menu(
            items=[MenuItem(short_name(c.id), lambda c=c: self._on_forced_swap(who, c.id)) for c in out],
            on_cancel=lambda: None,
        )
        self.list_menu.cursor = next(
            (i for i, c in enumerate(out) if c.id == StorySettings.SWAP_OUT_CURSOR), 0)

    def _on_forced_swap(self, bench_id: str, out_id: str) -> None:
        """The swap lesson's pick: ``bench_id`` comes in for ``out_id``."""
        self._close_list_menu()
        self._back_to_commands()
        self._dispatch(self.battle.submit_swap(bench_id, out_id))

    def _remember_commands(self, menu: Menu) -> None:
        """Note the page and row the one acting picked from, for Memory."""
        actor = self.battle.current_actor
        if actor is not None:
            config.current.cursors[actor.id] = (self._page, menu.cursor)

    # ------------------------------------------------------------------
    # RENDER
    # ------------------------------------------------------------------

    def render(self, surface: pygame.Surface) -> None:
        """Draw the fighters, the turn strip, and the bottom window.

        The window is split: commands or narration on the left, the
        party's rows on the right. The Ability and Item submenus take
        the whole window while they are open.
        """
        render_template(self.backdrop, surface)
        actor = self.battle.current_actor
        active_id = actor.id if actor is not None else None
        target = (
            self._target_pool[self._target_cursor]
            if self._pending_command is not None and self._target_pool
            else None
        )
        self.stage.render_enemies(
            surface, self._shown_hp, active_id, target,
        )
        self._render_turn_strip(surface, target)
        commanding = not self._battle_finished and self._commands_up()
        submenu = (
            (self.list_menu or self.item_menu or self.ability_menu)
            if commanding else None
        )
        self._render_hud_frame(surface, split=submenu is None)
        picking = commanding and target is not None and target.is_party
        if submenu is None:
            self.stage.render_party(
                surface, self._shown_hp, active_id, target, picking=picking,
            )
        aiming = (
            commanding and submenu is None and target is not None
            and not target.is_party
        )
        if aiming:
            self._render_target_name(surface, target)
        elif picking:
            self._render_pending_name(surface)
        elif commanding:
            self._render_menu(
                surface,
                submenu or self.stroke_menu or self.side_menu or self.command_menu,
            )
            if submenu is None and self.stroke_menu is not None:
                self._render_points(surface)
            if (submenu is None and self.stroke_menu is None and self.side_menu is None
                    and self.battle.current_actor is not None):
                self._render_team_up_sign(surface)
            if self._select_held:
                self._render_help(surface)

        elif self.meter is not None:
            self.meter.render(surface, pygame.Rect(
                0, self._hud_rect(surface).top, UISettings.COMMAND_PANEL_WIDTH, UISettings.TEXT_BOX_HEIGHT))
        elif self.paddle is not None:
            # The A button and the time, in the window the commands were in (Frankie, 10/31).
            self.paddle.render(surface, pygame.Rect(
                0, self._hud_rect(surface).top, UISettings.COMMAND_PANEL_WIDTH, UISettings.TEXT_BOX_HEIGHT))
        elif self.spin is not None:
            # The pad going round and the time, in the window the commands were in (Frankie, 11/1).
            self.spin.render(surface, pygame.Rect(
                0, self._hud_rect(surface).top, UISettings.COMMAND_PANEL_WIDTH, UISettings.TEXT_BOX_HEIGHT))
        elif self.banish is not None:
            # The A button and the time below; the two circles on the enemy (Frankie, 10/31).
            self.banish.render(surface, pygame.Rect(
                0, self._hud_rect(surface).top, UISettings.COMMAND_PANEL_WIDTH, UISettings.TEXT_BOX_HEIGHT))
            center = self.stage.enemy_center(self.banish.target_id)
            if center is not None:
                self.banish.render_rings(surface, center)
        elif self.pound is not None:
            # The buttons and the time, in the same window (Frankie, 10/31).
            self.pound.render(surface, pygame.Rect(
                0, self._hud_rect(surface).top, UISettings.COMMAND_PANEL_WIDTH, UISettings.TEXT_BOX_HEIGHT))
        elif self.minigame is not None:
            # The 11/1 minigames, in the same window; the circles on the enemy for Vault and Moepapa.
            self.minigame.render(surface, pygame.Rect(
                0, self._hud_rect(surface).top, UISettings.COMMAND_PANEL_WIDTH, UISettings.TEXT_BOX_HEIGHT))
            if hasattr(self.minigame, "render_rings"):
                center = self.stage.enemy_center(self.minigame.target_id)
                if center is not None:
                    self.minigame.render_rings(surface, center)
        else:
            self.text_box.render(surface)
        self.stage.render_floaters(surface)
        self.notices.render(surface)
        if not self.talk_box.is_done():
            height = self.talk_box.height
            self.talk_box.render(surface.subsurface(
                pygame.Rect(0, surface.get_height() - height, ScreenSettings.WIDTH, height)))
        if self.tutorial is not None:
            self.tutorial.render(surface)

    def _render_target_name(self, surface: pygame.Surface, target: Combatant) -> None:
        """While a monster is aimed at, the left window shows its name (Frankie, 10/18)."""
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        text_renderer.draw_text(
            surface, target.name,
            (rect.left + pad + UISettings.MENU_LABEL_OFFSET + UISettings.MENU_HOOK_ROOM, rect.top + pad),
            color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
            max_width=UISettings.COMMAND_PANEL_WIDTH - 2 * pad - UISettings.MENU_LABEL_OFFSET,
        )

    def _pending_name(self) -> str:
        """Return what the one acting is about to use on an ally, with the count left of an item."""
        cmd = self._pending_command or {}
        kind = cmd.get("kind")
        if kind == "noni":
            return f"Noni x{self.battle.noni}"
        if kind in ("dish", "cure"):
            return f"{ItemSettings.NAMES[cmd['item']]} x{self.gm.party.inventory.get(cmd['item'], 0)}"
        if kind == "move":
            return short_move_name(self.battle.move(cmd["move_id"]))
        if kind == "combo":
            return by_id("combos").get(cmd["combo_id"], {}).get("name", "")
        return ""

    def _render_pending_name(self, surface: pygame.Surface) -> None:
        """While an ally is picked, the left window shows what they get, its cursor grey.

        Like the field menu's Items, where the item's cursor greys while the
        member's cursor is yellow, so it cannot pass for the commands
        (the 10/26 Let's Play pressed confirm on it, thinking it was them).
        """
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        x = rect.left + pad + UISettings.MENU_LABEL_OFFSET + UISettings.MENU_HOOK_ROOM
        text_renderer.draw_pointer(
            surface, (x - UISettings.MENU_LABEL_OFFSET, rect.top + pad + FontSettings.SIZE_BODY // 2),
            ColorSettings.GRAY,
        )
        text_renderer.draw_text(
            surface, self._pending_name(), (x, rect.top + pad),
            color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
            max_width=UISettings.COMMAND_PANEL_WIDTH - 2 * pad - UISettings.MENU_LABEL_OFFSET,
        )

    def _render_turn_strip(
        self, surface: pygame.Surface, target: Combatant | None = None
    ) -> None:
        """Draw who acts now and who acts next, as a column of small pictures (D-453).

        While a monster is aimed at, its pictures there get the target arrow too.
        """
        actor = self.battle.current_actor
        if actor is None or self.battle.is_over:
            return
        wait = self._preview_wait() if self._commands_up() else None
        upcoming = self.battle.upcoming(BattleSettings.TURN_ORDER_LENGTH, wait)
        self.stage.render_turn_order(surface, [actor] + upcoming)
        if target is not None and not target.is_party:
            self.stage.render_turn_target(surface, [actor] + upcoming, target)

    def _hud_rect(self, surface: pygame.Surface) -> pygame.Rect:
        """Return the bottom window's rectangle."""
        return pygame.Rect(
            0,
            surface.get_height() - UISettings.TEXT_BOX_HEIGHT,
            ScreenSettings.WIDTH,
            UISettings.TEXT_BOX_HEIGHT,
        )

    def _render_hud_frame(self, surface: pygame.Surface, split: bool) -> None:
        """Draw the bottom window, or two side by side when split (D-457)."""
        rect = self._hud_rect(surface)
        if not split:
            draw_window(surface, rect)
            return
        left = rect.copy()
        left.width = UISettings.COMMAND_PANEL_WIDTH
        right = rect.copy()
        right.left = left.right
        right.width = rect.right - left.right
        draw_window(surface, left)
        draw_window(surface, right)

    def _render_menu(self, surface: pygame.Surface, menu: Menu | GridMenu) -> None:
        """Draw ``menu`` in the window, from its top-left corner."""
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        self._refresh_command_labels()
        if isinstance(menu, GridMenu):
            row_height = UISettings.ABILITY_MENU_ROW_HEIGHT
            if menu is self.ability_menu and self._switch_pair is not None:
                # The sign turns only while the cursor is on its row.
                turns = int(time.monotonic() * UISettings.SWITCH_SPIN_HZ) if menu.row == 0 else 0
                menu.rows[0].cells[0].tag = switch_icon(*self._switch_pair, turns)
            menu.render(
                surface,
                (rect.left + pad + UISettings.MENU_LABEL_OFFSET, rect.top + pad),
                row_height=row_height,
                max_rows=(rect.height - 2 * pad) // row_height,
                label_width=UISettings.ABILITY_LABEL_WIDTH,
                col_width=UISettings.ABILITY_COL_WIDTH,
                font_size=FontSettings.SIZE_BODY,
            )
            if menu is self.ability_menu and self._switch_open:
                self._render_switch_window(surface)
            return
        row_height = UISettings.COMMAND_MENU_ROW_HEIGHT
        # Rows with an icon (the Weapon list's) draw it before the name and the cursor
        # before the icon, so the list moves right by the widest icon to keep both in the window.
        tags = max((item.tag.get_width() for item in menu.items if item.tag is not None), default=0)
        menu.render(
            surface,
            (rect.left + pad + UISettings.MENU_LABEL_OFFSET + UISettings.MENU_HOOK_ROOM + tags,
             self._menu_top(surface, menu)),
            font_size=FontSettings.SIZE_BODY,
            row_height=row_height,
            max_rows=(rect.height - 2 * pad) // row_height,
        )
        if menu is self.list_menu and self._team_up_listing:
            self._render_team_up_mana(surface, rect)

    def _render_team_up_mana(self, surface: pygame.Surface, rect: pygame.Rect) -> None:
        """Under the Team Up list, each fighter's mana now, so a grey row shows who is short
        without words (Frankie, 11/3, after Mark's Episode 3)."""
        pad = UISettings.TEXT_BOX_PADDING
        size = FontSettings.SIZE_BODY
        need = BattleSettings.COMBO_MANA
        x = rect.left + pad + UISettings.MENU_LABEL_OFFSET
        y = rect.bottom - pad - size
        for member in self.battle.party:
            if not member.alive:
                continue
            text = f"{short_name(member.id)} {member.mana}/{BattleSettings.MANA_CAP}  "
            color = BattleStageSettings.COLOR_MANA if member.mana >= need else ColorSettings.GRAY
            text_renderer.draw_text(surface, text, (x, y), color, size=size)
            x += text_renderer.text_width(text, size)

    def _switch_window_rect(self, surface: pygame.Surface) -> pygame.Rect:
        """Return the small window just over the stance's name on the grid's top row."""
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        edge = UISettings.TEXT_BOX_BORDER_THICKNESS + 2
        cell_x = rect.left + pad + UISettings.MENU_LABEL_OFFSET + UISettings.ABILITY_LABEL_WIDTH
        actor = self.battle.current_actor
        names = [stance["name"] for stance in actor.stances] if actor is not None else []
        width = max((text_renderer.text_width(name, FontSettings.SIZE_BODY) for name in names), default=0)
        return pygame.Rect(cell_x - edge, rect.top + pad - edge,
                           width + 2 * edge, FontSettings.SIZE_BODY + 2 * edge)

    def _render_switch_window(self, surface: pygame.Surface) -> None:
        """Draw the window over the stance's name, the other stance's name flashing in its colour."""
        actor = self.battle.current_actor
        other = self.battle.other_stance(actor) if actor is not None else None
        if other is None:
            return
        window = self._switch_window_rect(surface)
        draw_window(surface, window)
        if int(time.monotonic() * UISettings.SWITCH_FLASH_HZ * 2) % 2 == 0:
            style = ColorSettings.ELEMENT_TEXT_STYLES.get(other["element"], {})
            edge = UISettings.TEXT_BOX_BORDER_THICKNESS + 2
            text_renderer.draw_text(
                surface, other["name"], (window.left + edge, window.top + edge),
                style.get("color") or ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
                glow=style.get("glow"), glow_radius=style.get("glow_radius", 3),
                glow_alpha=style.get("glow_alpha", 90),
            )

    def _menu_top(self, surface: pygame.Surface, menu: Menu) -> int:
        """Return the y of a list menu's first row in the window.

        A menu that fits sits centred top to bottom (Frankie, 10/18);
        a longer one starts at the top and scrolls.
        """
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        row_height = UISettings.COMMAND_MENU_ROW_HEIGHT
        border = UISettings.TEXT_BOX_BORDER_THICKNESS
        inner = rect.height - 2 * border
        block = (len(menu.items) - 1) * row_height + FontSettings.LETTER_WIDTH
        return (
            rect.top + border + (inner - block) // 2
            if len(menu.items) * row_height <= rect.height - 2 * pad
            else rect.top + pad
        )

    def _menu_row_rect(self, menu: Menu, index: int, surface: pygame.Surface | None = None) -> pygame.Rect:
        """Return the area of a list menu's row in the left window, its cursor included (Hina's highlight)."""
        surface = surface or self.gm.screen
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        y = self._menu_top(surface, menu) + index * UISettings.COMMAND_MENU_ROW_HEIGHT
        width = UISettings.COMMAND_PANEL_WIDTH - 2 * pad - UISettings.POINTS_BAR_WIDTH - 2
        return pygame.Rect(rect.left + pad - 2, y - 4, width, UISettings.COMMAND_MENU_ROW_HEIGHT)

    def _grid_cell_rect(self, grid: GridMenu, row: int, col: int) -> pygame.Rect:
        """Return the area of one cell of the technique grid, its cursor included (Hina's highlight)."""
        rect = self._hud_rect(self.gm.screen)
        pad = UISettings.TEXT_BOX_PADDING
        x = (rect.left + pad + UISettings.MENU_LABEL_OFFSET + UISettings.ABILITY_LABEL_WIDTH
             + col * UISettings.ABILITY_COL_WIDTH)
        y = rect.top + pad + (row - grid._first_shown) * UISettings.ABILITY_MENU_ROW_HEIGHT
        return pygame.Rect(x - UISettings.MENU_LABEL_OFFSET - 3, y - 4,
                           UISettings.ABILITY_COL_WIDTH - 3, UISettings.ABILITY_MENU_ROW_HEIGHT)

    def _grid_row_rect(self, grid: GridMenu, row: int) -> pygame.Rect:
        """Return the area of a whole row of the technique grid (Hina's highlight)."""
        rect = self._hud_rect(self.gm.screen)
        pad = UISettings.TEXT_BOX_PADDING
        y = rect.top + pad + (row - grid._first_shown) * UISettings.ABILITY_MENU_ROW_HEIGHT
        return pygame.Rect(rect.left + pad - 2, y - 4, rect.width - 2 * pad + 4, UISettings.ABILITY_MENU_ROW_HEIGHT)

    def _points_rect(self) -> pygame.Rect:
        """Return the area of the stroke points' standing bar (Hina's highlight)."""
        rect = self._hud_rect(self.gm.screen)
        pad = UISettings.TEXT_BOX_PADDING
        x = rect.left + UISettings.COMMAND_PANEL_WIDTH - pad - UISettings.POINTS_BAR_WIDTH + 2
        return pygame.Rect(x - 2, rect.top + pad - 2, UISettings.POINTS_BAR_WIDTH + 4, rect.height - 2 * pad + 4)

    def _render_points(self, surface: pygame.Surface) -> None:
        """Draw the stroke points left this turn as a standing bar at the panel's right edge.

        One segment a point, filled from the bottom, yellow while unspent.
        """
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        total = BattleSettings.STROKE_POINTS
        left = self.battle.chain_points_left
        gap = UISettings.POINTS_BAR_GAP
        segment = (rect.height - 2 * pad + gap) // total - gap
        x = rect.left + UISettings.COMMAND_PANEL_WIDTH - pad - UISettings.POINTS_BAR_WIDTH + 2
        bottom = rect.bottom - pad
        for index in range(total):
            top = bottom - (index + 1) * segment - index * gap
            color = ColorSettings.YELLOW if index < left else UISettings.POINTS_BAR_SPENT
            pygame.draw.rect(
                surface, color,
                pygame.Rect(x, top, UISettings.POINTS_BAR_WIDTH, segment),
            )

    def _refresh_command_labels(self) -> None:
        """Grey out Item when nothing is left to use, and write the stroke rows.

        Each stroke reads "1 LIGHT  95%": its points, its name, its chance
        to land on the target. A stroke that no longer fits is grey; one
        that spends the last points, ending the turn, is yellow
        (Frankie, 10/18).
        """
        bag = self.gm.party.inventory
        self.command_menu.items[_ITEM_ROW].enabled = self.battle.noni > 0 or any(
            bag.get(item, 0) > 0 for item in [*ItemSettings.HEALS, *ItemSettings.CURES, *ItemSettings.REVIVES, ItemSettings.SEER_SHELL] if item != "noni"
        )
        # Skill by its name (D-692), the one for the weapon type in hand
        # (Frankie, 10/31); a Skill still on paper shows grey.
        skill = self._held_skill(self.battle.current_actor)
        tech = self.command_menu.items[_TECH_ROW]
        tech.label = skill["name"] if skill else "Skill"
        # In mana debt, no Skill until it is built back to 0 (Frankie, 11/1 late).
        tech.enabled = (skill is not None and skill["id"] in _SKILLS_BUILT
                        and self.battle.can_use_skill(self.battle.current_actor)
                        # One spirit at a time: Call waits until it is gone (Frankie, 11/2).
                        and not (skill["id"] == "call_the_dead" and self.battle.spirit_out))
        if self.stroke_menu is not None:
            left = self.battle.chain_points_left
            lightest = BattleSettings.STROKES["light"]["points"]
            target = self.battle.chain_target() or next(
                (c for c in self.battle.enemies
                 if c.id == self._chain_target_id and c.alive),
                None,
            )
            for row, kind in enumerate(_STROKE_KINDS):
                stroke = BattleSettings.STROKES[kind]
                item = self.stroke_menu.items[row]
                item.enabled = stroke["points"] <= left
                item.color = (
                    ColorSettings.YELLOW if left - stroke["points"] < lightest else None
                )
                chance = (
                    f"{round(100 * self.battle.stroke_chance(kind, target)):>3}%"
                    if target is not None else ""
                )
                item.label = f"{stroke['points']} {stroke['name']:<6}{chance}"
            # A cursor left on a stroke that no longer fits drops to the
            # heaviest that does, so confirm never lands on grey (the 10/26
            # Let's Play sat on Strong with 1 point left and thought it froze).
            cursor = self.stroke_menu.cursor
            if cursor < len(_STROKE_KINDS) and not self.stroke_menu.items[cursor].enabled:
                fits = [row for row in range(len(_STROKE_KINDS)) if self.stroke_menu.items[row].enabled]
                if fits:
                    self.stroke_menu.cursor = fits[-1]

    # ------------------------------------------------------------------
    # UPDATE
    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        """Play narration, start the next turn, and leave when done."""
        self.text_box.update(dt)
        if self._sayings and self.text_box.is_done() and self.talk_box.is_done():
            speaker, line = self._sayings.popleft()
            self.talk_box.push(line, speaker=speaker)
        self.talk_box.update(dt)
        self.notices.update(dt)
        self.stage.update(dt, self._shown_hp)
        self._beat = max(0.0, self._beat - dt)
        if self._settle > 0 and self._commands_up():
            self._settle -= dt
        self._hold_narration(dt)
        if self.tutorial is not None and self.tutorial.holds():
            # The fight waits while Hina asks or talks.
            self.tutorial.update(dt)
            return
        self._play_events()
        if self.meter is not None:
            self._run_meter(dt)
            return
        if self.paddle is not None:
            self._run_paddle(dt)
        if self.spin is not None:
            self._run_wili(dt)
        if self.banish is not None:
            self._run_banish(dt)
        if self.pound is not None:
            self._run_pound(dt)
            return
        if self.minigame is not None:
            self._run_minigame(dt)
            return
        if self.tutorial is not None:
            # Before the next turn starts, so a word between turns comes first.
            self.tutorial.update(dt)
            if self.tutorial.holds():
                return
        self._teach_team_up()
        if (
            not self.battle.is_over
            and not self.battle.is_awaiting_command()
            and not self.battle.is_awaiting_block()
            and not self._events
            and self._beat <= 0
            and self.text_box.is_done()
        ):
            self._dispatch(self.battle.start_turn())
            if self.battle.is_awaiting_command():
                self._open_commands()
            self._play_events()
        if self._battle_finished and self.victory is not None and self.text_box.is_done():
            # Won: a moment on the fallen field, then the victory screen;
            # once it closes, back to the field.
            if self._victory_shown:
                self.gm.scene_stack.pop()
                return
            self._victory_hold += dt
            if self._victory_hold >= VictorySettings.HOLD_SECONDS:
                self._victory_shown = True
                self.gm.scene_stack.push(VictoryScene(self.gm, self.victory))
            return
        if self._battle_finished and self.text_box.is_done() and self.notices.is_done():
            if self.battle.outcome == "defeat" and not self.story:
                # After "The party has fallen.": GAME OVER, then the title (D-148).
                game_over(self.gm)
                return
            self.gm.scene_stack.pop()
