"""Battle scene: hosts a ``Battle`` and a ``BattleView``.

The scene owns no rules. It builds a ``Battle`` from content data,
asks it to advance, and plays the events it gets back one at a time so
that each line of narration appears together with the change it
describes (an HP number dropping, a status appearing).

What the fighters look like and how they move is ``ui.battle_stage``.
The scene hands it each event as that event's line comes up, so a
monster shakes at the moment the text says it was hit.

Each frame:

* Narration on screen holds for a moment and then advances on its own;
  confirm advances it at once.
* When nothing is left to narrate and a party member's turn is waiting,
  the bottom HUD becomes a command panel: Attack / TECH / Element /
  Item on the left, the party's rows with their mana on the right. TECH
  is the member's signature command, labeled by its name (D-692); only
  Kailo's Cook works yet, the rest grey. Left turns to a page with
  Weapon, Escape and Defend, right to one with Combo (only while a
  combo is open) and Swap (D-455, the battle menu line in
  ``game/answers.md``).
  Cook (Frankie, 10/25) spends the turn cooking for the party; what it is
  is set then (``Battle.submit_cook``), and it is served at the start of
  his next turn.
  Attack picks an enemy and opens the stroke menu: Light, Medium and
  Strong strokes (1, 2 and 3 of the turn's 7 points, shown top right),
  and Element. Each stroke that lands builds mana, which Element spends
  (D-213 to D-220). After a stroke, cancel goes back to the commands
  with the points left (D-578): Attack strikes on, and Element, Defend or
  Item ends the turn; Swap is grey until the next turn. Ability and Item open submenus;
  anything aimed at someone enters target selection with a pulsing
  arrow on the fighter. There is no help line (D-450).
* Otherwise ``battle.start_turn()`` is called to move to the next turn.

The strip across the top shows who acts next. While the player moves
through the menus it previews the order as it would be if they took
the highlighted action: the wait is the turn's fatigue (D-328), so a
long chain of strokes brings the next turn later.
"""

from __future__ import annotations

import random
from collections import deque
from typing import TYPE_CHECKING, Any

import pygame

from core.events import (
    AbilityUsedEvent,
    BattleEndedEvent,
    DamageEvent,
    DodgeEvent,
    HealEvent,
    RevivedEvent,
    MissEvent,
    StanceEvent,
    SummonEvent,
    StrokeEvent,
)
from core import lore
from core.battle_tutorial import HinaTutorial
from core.factories import (
    combatant_from_monster_data,
    combatant_from_party_member,
)
from core.scene import Scene
from core.scenes.game_over_scene import game_over
from core.shared import by_id, short_name, signature_name
from settings import (
    AudioSettings,
    BattleSettings,
    BattleStageSettings,
    LoadoutSettings,
    ColorSettings,
    FontSettings,
    ItemSettings,
    ScreenSettings,
    UISettings,
)
from systems import config
from systems.battle import Battle, Combatant
from systems.passives import after_victory, growth_chance
from ui import input_map, text_renderer
from ui.battle_stage import BattleStage
from ui.battle_view import BattleView
from ui.layout import DebugOverlay
from ui.grid_menu import GridCell, GridMenu, GridRow, short_move_name
from ui.item_icon import item_icon
from ui.stance_icon import stance_icons, switch_icon
from ui.menu import Menu, MenuItem
from ui.notice_bar import NoticeBar
from ui.text_box import TextBox
from ui.window import draw_window
from utils.backgrounds import render_template

if TYPE_CHECKING:
    from main import GameManager


# Encounters a fight with no named encounter rolls, for the tools (the
# map's fights come from field monsters, D-576). Every fight whose
# monsters use only rules this game has. The Dwende and Amaranhig fight
# needs zombie and the Kaperosa needs doom, so they wait.
_DEMO_ENCOUNTER_IDS: tuple[str, ...] = (
    "beast_pack", "mages", "shades", "great_boar",
)

# Index of each row in the top-level command menu.
_ATTACK_ROW, _TECH_ROW, _ABILITY_ROW, _ITEM_ROW = range(4)
# The members whose TECH works in this fight; the others' are grey.
_TECHS_BUILT: tuple[str, ...] = ("kailo", "hina", "maika", "tawiri")

# The stroke menu's rows: the three strokes, then Element (D-455). Cancel ends the
# chain once a stroke has been swung (Frankie, 10/18).
_STROKE_KINDS: tuple[str, ...] = ("light", "medium", "strong")
_STROKE_ABILITY_ROW = 3


def compose_fight(kind: dict[str, Any]) -> list[dict[str, Any]]:
    """The enemies a field monster brings into its fight (D-576).

    A boss names its fight (``encounter``). An ordinary monster always
    brings its ``lead``; each of its ``extra_slots`` is then filled one
    time in ``join_chance`` by a companion picked by weight. Repeats are
    lettered, Wild Boar A and Wild Boar B, the way the shared fights name them.

    Args:
        kind: The monster's ``data/field_monsters`` entry.

    Returns:
        Enemy entries shaped like the shared file's, ready for
        ``BattleScene(enemies=...)``.
    """
    templates = {
        entry["id"]: entry
        for encounter in by_id("encounters").values()
        for entry in encounter["enemies"]
    }
    if "encounter" in kind:
        return list(by_id("encounters")[kind["encounter"]]["enemies"])
    picks = [kind["lead"]]
    companions = kind.get("companions", {})
    for _ in range(kind.get("extra_slots", 0)):
        if companions and random.random() < kind.get("join_chance", 0.0):
            picks += random.choices(list(companions), weights=list(companions.values()))
    # The shared names end in " A" where a fight holds several; strip it,
    # then letter again only what repeats here.
    bases = [templates[pick]["name"].removesuffix(" A") for pick in picks]
    entries = []
    for index, (pick, base) in enumerate(zip(picks, bases)):
        entry = dict(templates[pick])
        if bases.count(base) > 1:
            letter = "ABCDEFGH"[bases[:index].count(base)]
            entry["name"] = f"{base} {letter}"
        else:
            entry["name"] = base
        entry["id"] = f"{pick}_{index}"
        entries.append(entry)
    return entries


def _build_enemies(
    encounter_id: str | None = None, entries: list[dict[str, Any]] | None = None,
) -> tuple[list[Combatant], dict[str, str | None], set[str], list[dict[str, Any]]]:
    """Build the monsters for one encounter.

    Args:
        encounter_id: Which fight. None rolls one of the demo fights.
        entries: The enemies themselves, from ``compose_fight``; when
            given, ``encounter_id`` is not used.

    Returns:
        The monsters, each one's picture name keyed by its id, the ids
        of those that float (ghosts and flyers), and each monster's
        entry in the shared file, in the same order, for what it drops.
    """
    if entries is None:
        entries = by_id("encounters")[
            encounter_id or random.choice(_DEMO_ENCOUNTER_IDS)
        ]["enemies"]
    monsters = by_id("monsters")
    combatants = [
        combatant_from_monster_data(entry, monsters[entry["monster"]])
        for entry in entries
    ]
    sprites = {entry["id"]: entry.get("sprite") for entry in entries}
    floating = {entry["id"] for entry in entries if entry.get("floats")}
    kinds = [monsters[entry["monster"]] for entry in entries]
    return combatants, sprites, floating, kinds


def roll_drops(
    kinds: list[dict[str, Any]], rng: random.Random | None = None,
) -> tuple[int, dict[str, int]]:
    """What the beaten monsters leave behind (D-524).

    Every monster drops pule, the islanders' shells, by how tough it was;
    some drop the item they carry (``steal`` in the shared file), and a
    boss always does; the Great Boar always leaves his tusk too
    (``ItemSettings.KEY_DROPS``). Besides, now and then, an everyday item (a Noni,
    a Seer's Shell) and, rarely, a seed, some monsters' favorite more
    often (Frankie, 10/22; ``ItemSettings``), and more rarely a weapon or
    relic (Frankie, 10/24).

    Returns:
        The pule, and the items found by id with their counts.
    """
    rng = rng or random.Random()
    pule = 0
    items: dict[str, int] = {}

    def found(item: str) -> None:
        items[item] = items.get(item, 0) + 1

    for kind in kinds:
        pule += max(1, round(kind.get("hp", 0) * BattleSettings.DROP_PULE_PER_HP))
        item = kind.get("steal")
        if item and (kind.get("boss") or rng.random() < BattleSettings.DROP_ITEM_CHANCE):
            found(item)
        # A key item, always (the Great Boar's tusk, 10/25).
        if kind.get("id") in ItemSettings.KEY_DROPS:
            found(ItemSettings.KEY_DROPS[kind["id"]])
        if rng.random() < ItemSettings.EVERYDAY_CHANCE:
            everyday = ItemSettings.EVERYDAY
            found(rng.choices(list(everyday), weights=list(everyday.values()))[0])
        if rng.random() < ItemSettings.SEED_CHANCE:
            favorite = ItemSettings.SEED_FAVORITES.get(kind.get("id", ""))
            if favorite and rng.random() < ItemSettings.SEED_FAVORITE_SHARE:
                found(favorite)
            else:
                found(rng.choice(list(ItemSettings.SEEDS)))
        # Taro or wheat, so the garden can always be replanted (Frankie, 10/24).
        if rng.random() < ItemSettings.INGREDIENT_CHANCE:
            found(rng.choice(ItemSettings.INGREDIENT_DROPS))
        # Rarer still, a piece of the demo's equipment (Frankie, 10/24).
        if rng.random() < ItemSettings.EQUIP_CHANCE:
            found(rng.choice(ItemSettings.EQUIP_DROPS))
    return pule, items


class BattleScene(Scene):
    """A turn-based encounter scene."""

    OPAQUE = True

    def __init__(
        self, gm: "GameManager", encounter_id: str | None = None,
        enemies: list[dict[str, Any]] | None = None, can_escape: bool = True,
        in_town: bool = False, story: bool = False, tutorial: bool = False,
    ) -> None:
        """Build the battle from the party and an encounter.

        Args:
            gm: The game manager.
            encounter_id: A fight from the shared battle file. None
                rolls one of the demo fights at random.
            enemies: The enemies themselves, from ``compose_fight``,
                for a fight a field monster starts (D-576).
            can_escape: False for a story fight: Escape is gray (D-041).
            in_town: True for a fight in town, which stands on the beach;
                anywhere else it stands in the jungle (Frankie, 10/23).
            story: True for a story fight. Losing one plays it again;
                losing any other is game over (D-148).
            tutorial: True for the taro patch fight: Hina asks if Kailo
                remembers how to fight, and reminds him (core/battle_tutorial.py).
        """
        super().__init__(gm)
        self.can_escape = can_escape
        self.story = story
        self.backdrop = "beach" if in_town else "jungle"
        self.moves = by_id("moves")
        # Noni is a Party-level resource that persists across
        # battles. If the inventory entry is missing entirely (old
        # save, never been to a battle), fall back to the new-game
        # starter count so the player isn't silently emptied out.
        starting_noni = gm.party.inventory.get(
            "noni", BattleSettings.STARTING_NONI
        )
        enemies, sprites, floating, self._kinds = _build_enemies(encounter_id, enemies)
        # What the monsters left, said after "Victory." (D-524).
        self._loot_lines: list = []  # a line, or (speaker, line)
        # A fight with a boss in it plays the boss songs (music.json); a
        # boss is the monster that counts its element twice.
        self._music = "boss" if any(len(foe.elements) > 1 for foe in enemies) else "battle"
        # The first three fight; the rest wait on the bench (D-196).
        everyone = [combatant_from_party_member(m, self.gm.party.flags) for m in self.gm.party.members]
        weapons = by_id("weapons")
        for member, combatant in zip(self.gm.party.members, everyone):
            held = weapons.get(member.weapon or "")
            combatant.weapon = held["name"] if held else None
        self.battle = Battle(
            party_combatants=everyone[:BattleSettings.FIGHTERS],
            enemy_combatants=enemies,
            moves=self.moves,
            noni=starting_noni,
            bench=everyone[BattleSettings.FIGHTERS:],
            combos=by_id("combos"),
        )
        # Tawiri's party passive: skills grow faster (systems/passives.py).
        self.battle.growth["chance"] = growth_chance(self.gm.party, self.battle.growth["chance"])
        # Narration goes in the left part of the window; the party's
        # rows stay visible on the right while it plays.
        self.text_box = TextBox(
            width=UISettings.COMMAND_PANEL_WIDTH
        )
        # "Went up!" lines show along the top without stopping the fight (D-526).
        self.notices = NoticeBar(pygame.Rect(UISettings.NOTICE_RECT))
        self.view = BattleView(self.text_box, self.notices)
        self.stage = BattleStage(
            self.battle.party, self.battle.enemies, sprites, floating,
            bench=self.battle.bench,
        )
        # Events the battle has produced but the screen has not shown yet.
        self._events: deque[Any] = deque()
        # HP as currently shown. It trails the battle's real HP until
        # the damage or heal event that changed it has been narrated.
        self._shown_hp: dict[str, int] = {
            c.id: c.hp
            for c in self.battle.party + self.battle.bench + self.battle.enemies
        }
        # Seconds the current finished line has been on screen.
        self._narration_held = 0.0
        # Seconds left before the next event plays: each stroke gets a
        # beat of its own, since strokes have no line to wait on.
        self._beat = 0.0
        self._battle_finished = False
        self.command_menu = Menu(
            items=[
                MenuItem("Attack", self._on_attack),
                MenuItem("", self._on_tech),
                MenuItem("Element", self._on_open_abilities),
                MenuItem("Item", self._on_open_items),
            ],
        )
        # Which page of commands shows: -1 Weapon and Escape, 0 the four
        # commands, 1 Combo and Swap (D-455). Built when turned to.
        self._page = 0
        self.side_menu: Menu | None = None
        # Weapon, Combo and Swap open a list that takes the window.
        self.list_menu: Menu | None = None
        # The Attack's stroke menu, open from the first target pick until
        # the turn ends.
        self.stroke_menu: Menu | None = None
        self._chain_target_id: str | None = None
        self.ability_menu: GridMenu | None = None
        self.item_menu: Menu | None = None
        self._pending_command: dict[str, Any] | None = None
        self._target_pool: list[Combatant] = []
        self._target_cursor: int = 0
        self.tutorial = HinaTutorial(self) if tutorial else None

    def on_enter(self) -> None:
        """Play the fight's music, the boss songs if a boss is here; victory keeps its own."""
        if self.gm.audio.screen != "victory":
            self.gm.audio.play_screen(self._music)

    # ------------------------------------------------------------------
    # COMMAND HANDLERS
    # ------------------------------------------------------------------

    def _on_attack(self) -> None:
        """Choose the enemy to strike, then open the stroke menu; mid-chain, strike on."""
        if self.battle.chaining:
            self._open_stroke_menu()
            return
        self._begin_targeting({"kind": "chain"}, pool="foe")

    def _open_stroke_menu(self) -> None:
        """Open the stroke menu: three strokes, then Element.

        The strokes' labels, with their chance to land, are written each
        frame by ``_refresh_command_labels``.
        """
        items = [
            MenuItem("", lambda kind=kind: self._on_stroke(kind))
            for kind in _STROKE_KINDS
        ]
        items += [
            MenuItem("Element", self._on_open_abilities),
        ]
        self.stroke_menu = Menu(items=items, on_cancel=self._cancel_stroke_menu)

    def _on_stroke(self, kind: str) -> None:
        """Swing a stroke at the chosen enemy, or pick a new one if it fell."""
        target = self.battle.chain_target()
        if target is None:
            target = next(
                (c for c in self.battle.enemies
                 if c.id == self._chain_target_id and c.alive),
                None,
            )
        if target is None:
            self._begin_targeting({"kind": "stroke", "stroke": kind}, pool="foe")
            return
        self._dispatch(self.battle.submit_stroke(kind, target.id))

    def _cancel_stroke_menu(self) -> None:
        """Back out to the commands. Mid-chain the target is kept for Attack (D-578)."""
        self.stroke_menu = None
        if not self.battle.chaining:
            self._chain_target_id = None

    def _on_defend(self) -> None:
        """Defend at once; it has no target."""
        self._back_to_commands()
        self._dispatch(self.battle.submit_defend())

    # ------------------------------------------------------------------
    # TECH: KAILO'S COOK
    # ------------------------------------------------------------------

    def _on_tech(self) -> None:
        """The signature command: Hina's Scold, Maika's Charm, or Kailo's Cook and Tawiri's Call, which end the turn at once."""
        actor = self.battle.current_actor
        if actor is None:
            return
        if actor.id == "hina":
            self._begin_targeting({"kind": "scold"}, pool="foe")
            return
        if actor.id == "maika":
            self._begin_targeting({"kind": "charm"}, pool="foe")
            return
        if actor.id == "tawiri":
            self._dispatch(self.battle.submit_call())
            return
        self._dispatch(self.battle.submit_cook())

    def _on_open_abilities(self) -> None:
        """Open the active member's techniques as a grid (D-450).

        On top, the switch to the other stance, in its element's colour,
        after the two-color recycle sign and before the member's element
        icons, the stance's boxed (Frankie, 10/26; it builds a mana, D-285). Under it one row per mana cost
        that has something in this stance, three slots across, greyed
        while the meter is short of the row. Revive is greyed while
        nobody is down.
        """
        actor = self.battle.current_actor
        if actor is None:
            return
        rows: list[GridRow] = []
        other = self.battle.other_stance(actor)
        if other is not None:
            style = ColorSettings.ELEMENT_TEXT_STYLES.get(other["element"], {})
            rows.append(GridRow("", [GridCell(
                other["name"],
                self._on_stance_chosen,
                color=style.get("color"), glow=style.get("glow"),
                glow_radius=style.get("glow_radius", 3),
                glow_alpha=style.get("glow_alpha", 90),
                tag=switch_icon(other["element"], actor.stance_element.value),
                after=stance_icons(actor.elements, actor.stance_element),
            )]))
        moves = self.battle.moves_for(actor)
        for row in range(1, LoadoutSettings.ROWS + 1):
            here = [m for m in moves if self.battle.row_of(actor, m) == row]
            if not here:
                continue
            cells: list[GridCell | None] = []
            for move in here:
                style = ColorSettings.ELEMENT_TEXT_STYLES.get(move["element"], {})
                cells.append(GridCell(
                    short_move_name(move),
                    lambda move=move: self._on_ability_chosen(move),
                    enabled=actor.mana >= self.battle.cost_of(actor, move) and (
                        move["target"] != "fallen"
                        or any(not c.alive for c in self.battle.party)
                    ),
                    color=style.get("color"), glow=style.get("glow"),
                    glow_radius=style.get("glow_radius", 3),
                    glow_alpha=style.get("glow_alpha", 90),
                    data=move,
                ))
            cells += [None] * (LoadoutSettings.PER_ROW - len(cells))
            rows.append(GridRow(
                str(row), cells,
                BattleStageSettings.COLOR_MANA if actor.mana >= row else ColorSettings.GRAY,
            ))
        if not rows:
            return
        self.ability_menu = GridMenu(rows, on_cancel=self._close_ability_menu)

    def _on_stance_chosen(self) -> None:
        """Switch stance; it ends the turn."""
        self.ability_menu = None
        self._dispatch(self.battle.submit_stance())

    def _on_ability_chosen(self, move: dict[str, Any]) -> None:
        """Use a move with no target at once; otherwise choose a target."""
        self.ability_menu = None
        if move["target"] == "none":
            self._dispatch(self.battle.submit_move(move["id"]))
            return
        self._begin_targeting(
            {"kind": "move", "move_id": move["id"]}, pool=move["target"]
        )

    def _close_ability_menu(self) -> None:
        """Back out of the ability submenu to the command menu."""
        self.ability_menu = None

    def _on_open_items(self) -> None:
        """Open the item submenu: Noni, the other plants and dishes, and the Seer's Shell."""
        items = []
        if self.battle.noni > 0:
            items.append(MenuItem(f"Noni x{self.battle.noni}", self._on_noni_chosen))
        for item_id in ItemSettings.HEALS:
            count = self.gm.party.inventory.get(item_id, 0)
            if item_id != "noni" and count > 0:
                items.append(MenuItem(f"{ItemSettings.NAMES[item_id]} x{count}",
                                      lambda item_id=item_id: self._on_dish_chosen(item_id)))
        for item_id in ItemSettings.CURES:
            count = self.gm.party.inventory.get(item_id, 0)
            if count > 0:
                items.append(MenuItem(f"{ItemSettings.NAMES[item_id]} x{count}",
                                      lambda item_id=item_id: self._on_cure_chosen(item_id)))
        shells = self.gm.party.inventory.get(ItemSettings.SEER_SHELL, 0)
        if shells > 0:
            items.append(MenuItem(f"Seer's Shell x{shells}", self._on_seer_shell_chosen))
        if not items:
            return
        self.item_menu = Menu(items=items, on_cancel=self._close_item_menu)

    def _on_dish_chosen(self, item_id: str) -> None:
        """Start choosing who gets the dish from the bag."""
        self.item_menu = None
        self._begin_targeting({"kind": "dish", "item": item_id}, pool="ally")

    def _on_cure_chosen(self, item_id: str) -> None:
        """Start choosing who gets the plant that cures."""
        self.item_menu = None
        self._begin_targeting({"kind": "cure", "item": item_id}, pool="ally")

    def _on_seer_shell_chosen(self) -> None:
        """Start choosing which enemy to look at through the shell."""
        self.item_menu = None
        self._begin_targeting({"kind": "seer_shell"}, pool="foe")

    def _on_noni_chosen(self) -> None:
        """Start choosing who gets the Noni."""
        self.item_menu = None
        self._begin_targeting({"kind": "noni"}, pool="ally")

    def _close_item_menu(self) -> None:
        """Back out of the item submenu to the command menu."""
        self.item_menu = None

    # ------------------------------------------------------------------
    # THE SIDE PAGES (D-455)
    # ------------------------------------------------------------------

    def _turn_page(self, step: int) -> bool:
        """Turn to the page left (-1) or right (+1) of this one, if there is one."""
        page = self._page + step
        if page not in (-1, 0, 1):
            return False
        self._page = page
        self.side_menu = None
        if page == -1:
            self.side_menu = Menu(items=[
                MenuItem("Weapon", self._on_open_weapons, enabled=bool(self._spare_weapons())),
                MenuItem("Escape", self._on_escape, enabled=self.can_escape),
                MenuItem("Defend", self._on_defend),
            ], on_cancel=self._back_to_commands)
        elif page == 1:
            items = []
            if self.battle.combos_for(self.battle.current_actor):
                items.append(MenuItem("Combo", self._on_open_combos))
            items.append(MenuItem(
                "Swap", self._on_open_swap,
                # No swapping once a stroke is swung (D-578).
                enabled=any(c.alive for c in self.battle.bench) and not self.battle.chaining,
            ))
            self.side_menu = Menu(items=items, on_cancel=self._back_to_commands)
        return True

    def _back_to_commands(self) -> None:
        """Back to the page of four commands."""
        self._page = 0
        self.side_menu = None

    def _spare_weapons(self) -> list[dict[str, Any]]:
        """Return the weapons the one acting could take up instead of their own.

        Only what the party carries that they can use, the Equip screen's
        pool (Frankie, 10/24; it was every weapon of their types, the
        browser's Free Battle list).
        """
        from core.scenes.equip_scene import candidates

        actor = self.battle.current_actor
        member = self.gm.party.find(actor.id) if actor is not None and self.gm.party else None
        if member is None:
            return []
        weapons = by_id("weapons")
        return [weapons[w] for w in candidates(self.gm.party, member, "weapon") if w != member.weapon]

    def _on_open_weapons(self) -> None:
        """List the weapons to change to, each with its icon."""
        self.list_menu = Menu(
            items=[
                MenuItem(w["name"], lambda w=w: self._on_weapon_chosen(w), tag=item_icon(w["id"]))
                for w in self._spare_weapons()
            ],
            on_cancel=self._close_list_menu,
        )

    def _on_weapon_chosen(self, weapon: dict[str, Any]) -> None:
        """Change weapons: the new one from the bag, the old one into it. It ends the turn."""
        from core.equipment import weapon_multipliers
        from core.scenes.equip_scene import put_on

        self._close_list_menu()
        self._back_to_commands()
        member = self.gm.party.find(self.battle.current_actor.id)
        put_on(self.gm.party, member, "weapon", weapon["id"])
        self._dispatch(self.battle.submit_weapon(weapon["name"], weapon_multipliers(weapon["id"])))

    def _on_escape(self) -> None:
        """Try to run."""
        self._back_to_commands()
        self._dispatch(self.battle.submit_escape())

    def _on_open_combos(self) -> None:
        """List the combos open now, each with its cost and partner."""
        actor = self.battle.current_actor
        items = []
        for combo, partner in self.battle.combos_for(actor):
            label = f"{BattleSettings.COMBO_MANA} {combo['name']:<13}{short_name(partner.id)}"
            items.append(MenuItem(
                label, lambda combo=combo, partner=partner: self._on_combo_chosen(combo, partner),
                enabled=self.battle.can_pay_combo(actor, partner),
            ))
        self.list_menu = Menu(items=items, on_cancel=self._close_list_menu)

    def _on_combo_chosen(self, combo: dict[str, Any], partner: Combatant) -> None:
        """Strike at once if the combo hits everyone; otherwise choose the enemy."""
        self._close_list_menu()
        if combo["target"] == "none":
            self._back_to_commands()
            self._dispatch(self.battle.submit_combo(combo["id"], partner.id))
            return
        self._begin_targeting(
            {"kind": "combo", "combo_id": combo["id"], "partner_id": partner.id},
            pool="foe",
        )

    def _on_open_swap(self) -> None:
        """List who waits on the bench."""
        self.list_menu = Menu(
            items=[
                MenuItem(short_name(c.id), lambda c=c: self._on_swap_chosen(c.id), enabled=c.alive)
                for c in self.battle.bench
            ],
            on_cancel=self._close_list_menu,
        )

    def _on_swap_chosen(self, bench_id: str) -> None:
        """Bring the bench member in; the turn is theirs."""
        self._close_list_menu()
        self._back_to_commands()
        self._dispatch(self.battle.submit_swap(bench_id))

    def _close_list_menu(self) -> None:
        """Back out of the Weapon, Combo or Swap list to its page."""
        self.list_menu = None

    def _dispatch(self, events: list[Any]) -> None:
        """Queue the battle's events to be played back one at a time."""
        self._events.extend(events)
        if self.tutorial is not None:
            self.tutorial.saw(events)
        # A member acting in a stance unlocks its art's Lore page (Frankie, 10/23).
        members = {c.id: c for c in self.battle.party + self.battle.bench}
        for ev in events:
            who = ev.attacker_id if isinstance(ev, StrokeEvent) else ev.user_id if isinstance(ev, AbilityUsedEvent) else None
            if who in members and members[who].stances:
                lore.unlock(self.gm.party, "stance " + members[who].stances[members[who].stance]["name"])
        if not self.battle.is_awaiting_command():
            # The turn is over: the next one opens on the commands.
            self.stroke_menu = None
            self.ability_menu = None
            self.list_menu = None
            self._back_to_commands()
            self._chain_target_id = None
        if any(isinstance(ev, BattleEndedEvent) for ev in events):
            self._sync_party_state_back()

    def _sync_party_state_back(self) -> None:
        """Write battle-mutated state back onto the persistent ``Party``.

        Called once, when the battle produces its ``BattleEndedEvent``.
        Pushes each party combatant's HP back onto the matching
        ``PartyMember`` so damage carries into the overworld and the
        next save, and writes the Noni left back onto
        ``Party.inventory``.

        A lost fight is the exception: the party walks away at full
        HP, so a lost story fight can be fought again, and the lost
        taro patch goes on with the game rested, Melia having driven
        the boars off (Frankie, 10/26). Any other lost fight is game
        over, which throws all of this away.
        """
        lost = self.battle.outcome == "defeat"
        for combatant in self.battle.party + self.battle.bench:
            member = self.gm.party.find(combatant.id)
            if member is None:
                continue
            # What grew in the fight stays grown (D-498), so the member's
            # stats, max HP included, are worked out again first.
            member.growth = dict(combatant.growth)
            member.refresh_stats()
            # The fight's max HP follows the stance (D-365); the share of
            # it is what carries back out.
            share = combatant.hp / max(1, combatant.max_hp)
            member.current_hp = (
                member.max_hp if lost
                else max(0, min(round(share * member.max_hp), member.max_hp))
            )
        self.gm.party.inventory["noni"] = max(0, int(self.battle.noni))
        # What a scolded monster gave away is the party's, won or lost.
        for item in self.battle.gifts:
            self.gm.party.inventory[item] = self.gm.party.inventory.get(item, 0) + 1
        if self.battle.outcome == "victory":
            self._collect_drops()
            # Hina's and Kailo's party passives (systems/passives.py).
            self._loot_lines += after_victory(self.gm.party)
        # A weapon changed in the fight stays changed (D-462).
        by_name = {w["name"]: w["id"] for w in by_id("weapons").values()}
        for combatant in self.battle.party + self.battle.bench:
            member = self.gm.party.find(combatant.id)
            if member is not None and combatant.weapon in by_name:
                member.weapon = by_name[combatant.weapon]
        # A swap in the fight carries over: whoever ended it fighting
        # stays in the first three.
        order = [c.id for c in self.battle.party + self.battle.bench]
        self.gm.party.members.sort(
            key=lambda m: order.index(m.id) if m.id in order else len(order)
        )
        # Every monster beaten gets its bestiary page (D-458).
        from core.scenes.bestiary_scene import beaten_flag  # local: cycle.

        for enemy in self.battle.enemies:
            if not enemy.alive and not enemy.gone:
                self.gm.party.flags[beaten_flag(enemy.name)] = True

    def _collect_drops(self) -> None:
        """Add what the monsters left to the party, and write the lines that say so."""
        pule, items = roll_drops(self._kinds)
        self.gm.party.pule += pule
        self._loot_lines = [f"Found {pule} pule."]
        names = {item["id"]: item["name"] for item in by_id("items").values()}
        names.update(ItemSettings.NAMES)
        for item_id, count in items.items():
            self.gm.party.inventory[item_id] = self.gm.party.inventory.get(item_id, 0) + count
            name = names.get(item_id, item_id)
            self._loot_lines.append(f"Found {name}." if count == 1 else f"Found {name} x{count}.")

    # ------------------------------------------------------------------
    # TARGETING
    # ------------------------------------------------------------------

    def _begin_targeting(self, pending: dict[str, Any], pool: str) -> None:
        """Enter target selection over the living foes or allies, or the fallen ones."""
        side = self.battle.enemies if pool == "foe" else self.battle.party
        if pool == "fallen":
            candidates = [c for c in side if not c.alive]
        elif pool == "other":
            # Another ally, not the one acting (Nectar).
            actor = self.battle.current_actor
            candidates = [c for c in side if c.alive and c is not actor]
        else:
            candidates = [c for c in side if c.alive]
        if not candidates:
            return
        self._pending_command = pending
        self._target_pool = candidates
        self._target_cursor = 0

    def _on_target_confirmed(self) -> None:
        """Submit the pending command against the highlighted target."""
        if not self._pending_command or not self._target_pool:
            return
        target = self._target_pool[self._target_cursor]
        cmd = self._pending_command
        self._clear_targeting()
        if cmd["kind"] == "chain":
            self._chain_target_id = target.id
            self._open_stroke_menu()
        elif cmd["kind"] == "stroke":
            self._chain_target_id = target.id
            self._dispatch(self.battle.submit_stroke(cmd["stroke"], target.id))
        elif cmd["kind"] == "move":
            # A move that takes from an enemy and gives to someone (Drain,
            # Osmose, Borrowed Life) asks for the second one next.
            give_to = self.battle.move(cmd["move_id"]).get("give_to")
            if give_to and "from_id" not in cmd:
                self._begin_targeting({**cmd, "from_id": target.id}, pool=give_to)
                if self._pending_command is not None:
                    return
                self._dispatch(self.battle.submit_move(cmd["move_id"], target.id))
                return
            if "from_id" in cmd:
                self._dispatch(self.battle.submit_move(cmd["move_id"], cmd["from_id"], target.id))
            else:
                self._dispatch(self.battle.submit_move(cmd["move_id"], target.id))
        elif cmd["kind"] == "noni":
            self._dispatch(self.battle.submit_noni(target.id))
        elif cmd["kind"] == "dish":
            bag = self.gm.party.inventory
            bag[cmd["item"]] -= 1
            if bag[cmd["item"]] <= 0:
                del bag[cmd["item"]]
            self._dispatch(self.battle.submit_bag_heal(
                ItemSettings.NAMES[cmd["item"]], ItemSettings.HEALS[cmd["item"]], target.id))
        elif cmd["kind"] == "cure":
            bag = self.gm.party.inventory
            bag[cmd["item"]] -= 1
            if bag[cmd["item"]] <= 0:
                del bag[cmd["item"]]
            self._dispatch(self.battle.submit_bag_cure(
                ItemSettings.NAMES[cmd["item"]], ItemSettings.CURES[cmd["item"]], target.id))
        elif cmd["kind"] == "scold":
            self._dispatch(self.battle.submit_scold(target.id))
        elif cmd["kind"] == "charm":
            self._dispatch(self.battle.submit_charm(target.id))
        elif cmd["kind"] == "seer_shell":
            bag = self.gm.party.inventory
            bag[ItemSettings.SEER_SHELL] -= 1
            if bag[ItemSettings.SEER_SHELL] <= 0:
                del bag[ItemSettings.SEER_SHELL]
            self._dispatch(self.battle.submit_seer_shell(target.id))
        elif cmd["kind"] == "combo":
            self._back_to_commands()
            self._dispatch(self.battle.submit_combo(
                cmd["combo_id"], cmd["partner_id"], target.id
            ))

    def _cancel_targeting(self) -> None:
        """Leave target selection and reopen the menu it came from."""
        cmd = self._pending_command
        self._clear_targeting()
        if cmd is None:
            return
        if cmd["kind"] == "move":
            self._on_open_abilities()
        elif cmd["kind"] in ("noni", "seer_shell", "dish", "cure"):
            self._on_open_items()
        elif cmd["kind"] == "combo":
            self._on_open_combos()

    def _clear_targeting(self) -> None:
        """Forget the pending command and its target list."""
        self._pending_command = None
        self._target_pool = []
        self._target_cursor = 0

    def _move_target_cursor(self, direction: int) -> None:
        """Step the target cursor, wrapping at either end."""
        if not self._target_pool:
            return
        self._target_cursor = (
            self._target_cursor + direction
        ) % len(self._target_pool)

    # ------------------------------------------------------------------
    # PLAYBACK
    # ------------------------------------------------------------------

    def _can_command(self) -> bool:
        """Return True when the player may pick a command right now."""
        return (
            self.battle.is_awaiting_command()
            and not self._events
            and self._beat <= 0
            and self.text_box.is_done()
        )

    def _play_events(self) -> None:
        """Show queued events until one puts a line on screen or a stroke swings."""
        while self._events and self.text_box.is_done() and self._beat <= 0:
            event = self._events.popleft()
            if isinstance(event, DamageEvent):
                self._shown_hp[event.target_id] -= event.amount
                self._hit_sound("hit_magic" if event.cause == "spell" else "hit_punch")
            elif isinstance(event, HealEvent):
                self._shown_hp[event.target_id] += event.amount
                self._hit_sound("hit_sparkle")
            elif isinstance(event, SummonEvent):
                # Tawiri's spirit takes a fourth row, or leaves it (Frankie, 10/25).
                spirit = next((c for c in self.battle.party if c.id == event.combatant_id), None)
                if event.joined and spirit is not None:
                    self._shown_hp[spirit.id] = spirit.hp
                self.stage.summon(spirit if event.joined else None, event.combatant_id)
            elif isinstance(event, RevivedEvent):
                self._shown_hp[event.target_id] = event.hp
                self._hit_sound("hit_sparkle")
            elif isinstance(event, (DodgeEvent, MissEvent)):
                self._hit_sound("hit_miss")
            elif isinstance(event, StanceEvent):
                # A new stance moves max HP and keeps the share (D-365).
                for c in self.battle.party:
                    if c.id == event.combatant_id:
                        self._shown_hp[c.id] = c.hp
            elif isinstance(event, BattleEndedEvent):
                self._battle_finished = True
                if self.battle.outcome == "victory":
                    self.gm.audio.play_screen("victory")
            self.view.consume(event)
            if isinstance(event, BattleEndedEvent):
                for line in self._loot_lines:
                    if isinstance(line, tuple):
                        self.text_box.push(line[1], speaker=line[0])
                    else:
                        self.text_box.push(line)
            self.stage.consume(event)
            if isinstance(event, StrokeEvent):
                self._beat = BattleSettings.STROKE_BEAT_SECONDS

    def _hit_sound(self, kind: str) -> None:
        """Play one of the three takes of a hit sound."""
        take = random.randint(1, AudioSettings.HIT_TAKES)
        self.gm.audio.play(f"{kind}_{take}")

    def _hold_narration(self, dt: float) -> None:
        """Advance a finished line by itself after a short hold."""
        if self.text_box.is_done() or not self.text_box.is_page_complete():
            self._narration_held = 0.0
            return
        self._narration_held += dt
        if self._narration_held >= BattleSettings.NARRATION_HOLD_SECONDS:
            self._narration_held = 0.0
            self.text_box.advance()

    def _preview_wait(self) -> float | None:
        """Return the wait the highlighted action would cost, for the strip.

        None means nothing specific is highlighted yet (the cursor is on
        Attack or Ability before the choice), and the strip guesses.
        """
        battle = self.battle
        if self._pending_command is not None:
            kind = self._pending_command["kind"]
            if kind in ("chain", "stroke"):
                return None
            if kind in ("scold", "charm"):
                return battle.preview_wait("tech")
            if kind == "move" and self.moves[self._pending_command["move_id"]].get("signature"):
                return battle.preview_wait("tech")
            return battle.preview_wait("item" if kind in ("noni", "seer_shell", "dish", "cure") else "move")
        if self.ability_menu is not None:
            return battle.preview_wait("move")
        if self.item_menu is not None:
            return battle.preview_wait("item")
        if self.list_menu is not None:
            return battle.preview_wait("move" if self._page == 1 else "defend")
        if self.side_menu is not None:
            label = self.side_menu.items[self.side_menu.cursor].label
            if label in ("Weapon", "Escape", "Defend"):
                return battle.preview_wait("defend")
            return battle.preview_wait("move") if label == "Combo" else None
        if self.stroke_menu is not None:
            row = self.stroke_menu.cursor
            if row < len(_STROKE_KINDS):
                points = BattleSettings.STROKES[_STROKE_KINDS[row]]["points"]
                return battle.preview_wait("attack") + points * BattleSettings.STROKE_WAIT
            return None
        row = self.command_menu.cursor
        if row == _TECH_ROW and self.command_menu.items[_TECH_ROW].enabled:
            return battle.preview_wait("tech")
        if row == _ITEM_ROW:
            return battle.preview_wait("item")
        return None

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Advance narration, or drive the menus and target cursor."""
        # Hina's box, and what her lesson locks, come first.
        if self.tutorial is not None and self.tutorial.handle_event(event):
            return
        if not self.text_box.is_done():
            if input_map.is_confirm(event):
                self._narration_held = 0.0
                self.text_box.advance()
            return
        if self._battle_finished or not self._can_command():
            return
        if self._pending_command is not None:
            if input_map.is_cancel(event):
                self._cancel_targeting()
                self.gm.audio.play("menu_move")
            elif input_map.is_up(event) or input_map.is_left(event):
                self._move_target_cursor(-1)
                self.gm.audio.play("menu_move")
            elif input_map.is_down(event) or input_map.is_right(event):
                self._move_target_cursor(1)
                self.gm.audio.play("menu_move")
            elif input_map.is_confirm(event):
                self.gm.audio.play("menu_select")
                self._on_target_confirmed()
            return
        if input_map.is_cancel(event):
            if self.list_menu is not None:
                self.list_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.side_menu is not None:
                self.side_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.item_menu is not None:
                self.item_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.ability_menu is not None:
                self.ability_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.stroke_menu is not None:
                self.stroke_menu.cancel()
                self.gm.audio.play("menu_move")
            return
        on_pages = (
            self.list_menu is None and self.item_menu is None
            and self.ability_menu is None and self.stroke_menu is None
        )
        if on_pages and (input_map.is_left(event) or input_map.is_right(event)):
            if self._turn_page(-1 if input_map.is_left(event) else 1):
                self.gm.audio.play("menu_move")
            return
        active_menu = (
            self.list_menu or self.item_menu or self.ability_menu
            or self.stroke_menu or self.side_menu or self.command_menu
        )
        if input_map.is_up(event):
            if active_menu.move_up():
                self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            if active_menu.move_down():
                self.gm.audio.play("menu_move")
        elif isinstance(active_menu, GridMenu) and input_map.is_left(event):
            if active_menu.move_left():
                self.gm.audio.play("menu_move")
        elif isinstance(active_menu, GridMenu) and input_map.is_right(event):
            if active_menu.move_right():
                self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            if active_menu is self.command_menu or active_menu is self.side_menu:
                self._remember_commands(active_menu)
            if active_menu.confirm():
                self.gm.audio.play("menu_select")

    # ------------------------------------------------------------------
    # CONFIG'S CURSOR (Frankie, 10/26)
    # ------------------------------------------------------------------

    def _open_commands(self) -> None:
        """A turn starts: the commands open on Attack, or with Memory where this one left them."""
        actor = self.battle.current_actor
        self._refresh_command_labels()
        page, row = (0, 0)
        if config.current.cursor == "Memory" and actor is not None:
            page, row = config.current.cursors.get(actor.id, (0, 0))
        self._back_to_commands()
        if page != 0:
            self._turn_page(page)
        menu = self.side_menu if page != 0 else self.command_menu
        if menu is None or not 0 <= row < len(menu.items) or not menu.items[row].enabled:
            # Gone or grayed since (no Noni left, no spare weapon): the page's first row it can.
            menu = menu or self.command_menu
            row = next((i for i, item in enumerate(menu.items) if item.enabled), 0)
        menu.cursor = row

    def _remember_commands(self, menu: Menu) -> None:
        """Note the page and row the one acting picked from, for Memory."""
        actor = self.battle.current_actor
        if actor is not None:
            config.current.cursors[actor.id] = (self._page, menu.cursor)

    # ------------------------------------------------------------------
    # RENDER
    # ------------------------------------------------------------------

    def render(self, surface: pygame.Surface) -> None:
        """Draw the fighters, the turn strip, and the bottom window.

        The window is split: commands or narration on the left, the
        party's rows on the right. The Ability and Item submenus take
        the whole window while they are open.
        """
        render_template(self.backdrop, surface)
        actor = self.battle.current_actor
        active_id = actor.id if actor is not None else None
        target = (
            self._target_pool[self._target_cursor]
            if self._pending_command is not None and self._target_pool
            else None
        )
        self.stage.render_enemies(
            surface, self._shown_hp, active_id, target,
        )
        self._render_turn_strip(surface)
        commanding = not self._battle_finished and self._can_command()
        submenu = (
            (self.list_menu or self.item_menu or self.ability_menu)
            if commanding else None
        )
        self._render_hud_frame(surface, split=submenu is None)
        picking = commanding and target is not None and target.is_party
        if submenu is None:
            self.stage.render_party(
                surface, self._shown_hp, active_id, target, picking=picking,
            )
        aiming = (
            commanding and submenu is None and target is not None
            and not target.is_party
        )
        if aiming:
            self._render_target_name(surface, target)
        elif picking:
            self._render_pending_name(surface)
        elif commanding:
            self._render_menu(
                surface,
                submenu or self.stroke_menu or self.side_menu or self.command_menu,
            )
            if submenu is None and self.stroke_menu is not None:
                self._render_points(surface)
        else:
            self.text_box.render(surface)
        self.stage.render_floaters(surface)
        self.notices.render(surface)
        if self.tutorial is not None:
            self.tutorial.render(surface)

    def _render_target_name(self, surface: pygame.Surface, target: Combatant) -> None:
        """While a monster is aimed at, the left window shows its name (Frankie, 10/18)."""
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        text_renderer.draw_text(
            surface, target.name,
            (rect.left + pad + UISettings.MENU_LABEL_OFFSET, rect.top + pad),
            color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
            max_width=UISettings.COMMAND_PANEL_WIDTH - 2 * pad - UISettings.MENU_LABEL_OFFSET,
        )

    def _pending_name(self) -> str:
        """Return what the one acting is about to use on an ally, with the count left of an item."""
        cmd = self._pending_command or {}
        kind = cmd.get("kind")
        if kind == "noni":
            return f"Noni x{self.battle.noni}"
        if kind in ("dish", "cure"):
            return f"{ItemSettings.NAMES[cmd['item']]} x{self.gm.party.inventory.get(cmd['item'], 0)}"
        if kind == "move":
            return short_move_name(self.battle.move(cmd["move_id"]))
        if kind == "combo":
            return by_id("combos").get(cmd["combo_id"], {}).get("name", "")
        return ""

    def _render_pending_name(self, surface: pygame.Surface) -> None:
        """While an ally is picked, the left window shows what they get, its cursor grey.

        Like the field menu's Items, where the item's cursor greys while the
        member's cursor is yellow, so it cannot pass for the commands
        (the 10/26 Let's Play pressed confirm on it, thinking it was them).
        """
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        x = rect.left + pad + UISettings.MENU_LABEL_OFFSET
        text_renderer.draw_pointer(
            surface, (x - UISettings.MENU_LABEL_OFFSET, rect.top + pad + FontSettings.SIZE_BODY // 2),
            ColorSettings.GRAY,
        )
        text_renderer.draw_text(
            surface, self._pending_name(), (x, rect.top + pad),
            color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
            max_width=UISettings.COMMAND_PANEL_WIDTH - 2 * pad - UISettings.MENU_LABEL_OFFSET,
        )

    def _render_turn_strip(self, surface: pygame.Surface) -> None:
        """Draw who acts now and who acts next, as a column of small pictures (D-453)."""
        actor = self.battle.current_actor
        if actor is None or self.battle.is_over:
            return
        wait = self._preview_wait() if self._can_command() else None
        upcoming = self.battle.upcoming(BattleSettings.TURN_ORDER_LENGTH, wait)
        self.stage.render_turn_order(surface, [actor] + upcoming)

    def _hud_rect(self, surface: pygame.Surface) -> pygame.Rect:
        """Return the bottom window's rectangle."""
        return pygame.Rect(
            0,
            surface.get_height() - UISettings.TEXT_BOX_HEIGHT,
            ScreenSettings.WIDTH,
            UISettings.TEXT_BOX_HEIGHT,
        )

    def _render_hud_frame(self, surface: pygame.Surface, split: bool) -> None:
        """Draw the bottom window, or two side by side when split (D-457)."""
        rect = self._hud_rect(surface)
        if not split:
            draw_window(surface, rect)
            return
        left = rect.copy()
        left.width = UISettings.COMMAND_PANEL_WIDTH
        right = rect.copy()
        right.left = left.right
        right.width = rect.right - left.right
        draw_window(surface, left)
        draw_window(surface, right)

    def _render_menu(self, surface: pygame.Surface, menu: Menu | GridMenu) -> None:
        """Draw ``menu`` in the window, from its top-left corner."""
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        self._refresh_command_labels()
        if isinstance(menu, GridMenu):
            row_height = UISettings.ABILITY_MENU_ROW_HEIGHT
            menu.render(
                surface,
                (rect.left + pad + UISettings.MENU_LABEL_OFFSET, rect.top + pad),
                row_height=row_height,
                max_rows=(rect.height - 2 * pad) // row_height,
                label_width=UISettings.ABILITY_LABEL_WIDTH,
                col_width=UISettings.ABILITY_COL_WIDTH,
                font_size=FontSettings.SIZE_BODY,
            )
            return
        row_height = UISettings.COMMAND_MENU_ROW_HEIGHT
        menu.render(
            surface,
            (rect.left + pad + UISettings.MENU_LABEL_OFFSET, self._menu_top(surface, menu)),
            font_size=FontSettings.SIZE_BODY,
            row_height=row_height,
            max_rows=(rect.height - 2 * pad) // row_height,
        )

    def _menu_top(self, surface: pygame.Surface, menu: Menu) -> int:
        """Return the y of a list menu's first row in the window.

        A menu that fits sits centred top to bottom (Frankie, 10/18);
        a longer one starts at the top and scrolls.
        """
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        row_height = UISettings.COMMAND_MENU_ROW_HEIGHT
        border = UISettings.TEXT_BOX_BORDER_THICKNESS
        inner = rect.height - 2 * border
        block = (len(menu.items) - 1) * row_height + FontSettings.LETTER_WIDTH
        return (
            rect.top + border + (inner - block) // 2
            if len(menu.items) * row_height <= rect.height - 2 * pad
            else rect.top + pad
        )

    def _menu_row_rect(self, menu: Menu, index: int, surface: pygame.Surface | None = None) -> pygame.Rect:
        """Return the area of a list menu's row in the left window, its cursor included (Hina's highlight)."""
        surface = surface or self.gm.screen
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        y = self._menu_top(surface, menu) + index * UISettings.COMMAND_MENU_ROW_HEIGHT
        width = UISettings.COMMAND_PANEL_WIDTH - 2 * pad - UISettings.POINTS_BAR_WIDTH - 2
        return pygame.Rect(rect.left + pad - 2, y - 4, width, UISettings.COMMAND_MENU_ROW_HEIGHT)

    def _grid_cell_rect(self, grid: GridMenu, row: int, col: int) -> pygame.Rect:
        """Return the area of one cell of the technique grid, its cursor included (Hina's highlight)."""
        rect = self._hud_rect(self.gm.screen)
        pad = UISettings.TEXT_BOX_PADDING
        x = (rect.left + pad + UISettings.MENU_LABEL_OFFSET + UISettings.ABILITY_LABEL_WIDTH
             + col * UISettings.ABILITY_COL_WIDTH)
        y = rect.top + pad + (row - grid._first_shown) * UISettings.ABILITY_MENU_ROW_HEIGHT
        return pygame.Rect(x - UISettings.MENU_LABEL_OFFSET - 3, y - 4,
                           UISettings.ABILITY_COL_WIDTH - 3, UISettings.ABILITY_MENU_ROW_HEIGHT)

    def _grid_row_rect(self, grid: GridMenu, row: int) -> pygame.Rect:
        """Return the area of a whole row of the technique grid (Hina's highlight)."""
        rect = self._hud_rect(self.gm.screen)
        pad = UISettings.TEXT_BOX_PADDING
        y = rect.top + pad + (row - grid._first_shown) * UISettings.ABILITY_MENU_ROW_HEIGHT
        return pygame.Rect(rect.left + pad - 2, y - 4, rect.width - 2 * pad + 4, UISettings.ABILITY_MENU_ROW_HEIGHT)

    def _points_rect(self) -> pygame.Rect:
        """Return the area of the stroke points' standing bar (Hina's highlight)."""
        rect = self._hud_rect(self.gm.screen)
        pad = UISettings.TEXT_BOX_PADDING
        x = rect.left + UISettings.COMMAND_PANEL_WIDTH - pad - UISettings.POINTS_BAR_WIDTH + 2
        return pygame.Rect(x - 2, rect.top + pad - 2, UISettings.POINTS_BAR_WIDTH + 4, rect.height - 2 * pad + 4)

    def _render_points(self, surface: pygame.Surface) -> None:
        """Draw the stroke points left this turn as a standing bar at the panel's right edge.

        One segment a point, filled from the bottom, yellow while unspent.
        """
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        total = BattleSettings.STROKE_POINTS
        left = self.battle.chain_points_left
        gap = UISettings.POINTS_BAR_GAP
        segment = (rect.height - 2 * pad + gap) // total - gap
        x = rect.left + UISettings.COMMAND_PANEL_WIDTH - pad - UISettings.POINTS_BAR_WIDTH + 2
        bottom = rect.bottom - pad
        for index in range(total):
            top = bottom - (index + 1) * segment - index * gap
            color = ColorSettings.YELLOW if index < left else UISettings.POINTS_BAR_SPENT
            pygame.draw.rect(
                surface, color,
                pygame.Rect(x, top, UISettings.POINTS_BAR_WIDTH, segment),
            )

    def _refresh_command_labels(self) -> None:
        """Grey out Item when nothing is left to use, and write the stroke rows.

        Each stroke reads "1 LIGHT  95%": its points, its name, its chance
        to land on the target. A stroke that no longer fits is grey; one
        that spends the last points, ending the turn, is yellow
        (Frankie, 10/18).
        """
        bag = self.gm.party.inventory
        self.command_menu.items[_ITEM_ROW].enabled = self.battle.noni > 0 or any(
            bag.get(item, 0) > 0 for item in [*ItemSettings.HEALS, *ItemSettings.CURES, ItemSettings.SEER_SHELL] if item != "noni"
        )
        # TECH by its name (D-692).
        actor = self.battle.current_actor
        tech = self.command_menu.items[_TECH_ROW]
        tech.label = signature_name(actor.id) if actor is not None else ""
        tech.enabled = actor is not None and actor.id in _TECHS_BUILT
        if self.stroke_menu is not None:
            left = self.battle.chain_points_left
            lightest = BattleSettings.STROKES["light"]["points"]
            target = self.battle.chain_target() or next(
                (c for c in self.battle.enemies
                 if c.id == self._chain_target_id and c.alive),
                None,
            )
            for row, kind in enumerate(_STROKE_KINDS):
                stroke = BattleSettings.STROKES[kind]
                item = self.stroke_menu.items[row]
                item.enabled = stroke["points"] <= left
                item.color = (
                    ColorSettings.YELLOW if left - stroke["points"] < lightest else None
                )
                chance = (
                    f"{round(100 * self.battle.stroke_chance(kind, target)):>3}%"
                    if target is not None else ""
                )
                item.label = f"{stroke['points']} {stroke['name']:<6}{chance}"
            # A cursor left on a stroke that no longer fits drops to the
            # heaviest that does, so confirm never lands on grey (the 10/26
            # Let's Play sat on Strong with 1 point left and thought it froze).
            cursor = self.stroke_menu.cursor
            if cursor < len(_STROKE_KINDS) and not self.stroke_menu.items[cursor].enabled:
                fits = [row for row in range(len(_STROKE_KINDS)) if self.stroke_menu.items[row].enabled]
                if fits:
                    self.stroke_menu.cursor = fits[-1]

    # ------------------------------------------------------------------
    # UPDATE
    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        """Play narration, start the next turn, and leave when done."""
        self.text_box.update(dt)
        self.notices.update(dt)
        self.stage.update(dt, self._shown_hp)
        self._beat = max(0.0, self._beat - dt)
        self._hold_narration(dt)
        if self.tutorial is not None and self.tutorial.holds():
            # The fight waits while Hina asks or talks.
            self.tutorial.update(dt)
            return
        self._play_events()
        if self.tutorial is not None:
            # Before the next turn starts, so a word between turns comes first.
            self.tutorial.update(dt)
            if self.tutorial.holds():
                return
        if (
            not self.battle.is_over
            and not self.battle.is_awaiting_command()
            and not self._events
            and self._beat <= 0
            and self.text_box.is_done()
        ):
            self._dispatch(self.battle.start_turn())
            if self.battle.is_awaiting_command():
                self._open_commands()
            self._play_events()
        if self._battle_finished and self.text_box.is_done() and self.notices.is_done():
            if self.battle.outcome == "defeat" and not self.story:
                # After "The party has fallen.": GAME OVER, then the title (D-148).
                game_over(self.gm)
                return
            self.gm.scene_stack.pop()
