"""Battle scene: hosts a ``Battle`` and a ``BattleView``.

The scene owns no rules. It builds a ``Battle`` from content data,
asks it to advance, and plays the events it gets back one at a time so
that each line of narration appears together with the change it
describes (an HP number dropping, a status appearing).

What the fighters look like and how they move is ``ui.battle_stage``.
The scene hands it each event as that event's line comes up, so a
monster shakes at the moment the text says it was hit.

Each frame:

* Narration on screen holds for a moment and then advances on its own;
  confirm advances it at once.
* When nothing is left to narrate and a party member's turn is waiting,
  the bottom HUD becomes a command panel: Attack / Tech / Defend /
  Item on the left, the party's rows with their mana on the right.
  Left turns to a page with Weapon and Escape, right to one with Combo
  (only while a combo is open) and Swap (D-455).
  Attack picks an enemy and opens the stroke menu: Light, Medium and
  Strong strokes (1, 2 and 3 of the turn's 7 points, shown top right),
  Done, Ability and Defend. Each stroke that lands builds mana, which
  Ability spends (D-213 to D-220). Ability and Item open submenus;
  anything aimed at someone enters target selection with a blinking
  arrow on the fighter. There is no help line (D-450).
* Otherwise ``battle.start_turn()`` is called to move to the next turn.

The strip across the top shows who acts next. While the player moves
through the menus it previews the order as it would be if they took
the highlighted action: the wait is the turn's fatigue (D-328), so a
long chain of strokes brings the next turn later.
"""

from __future__ import annotations

import random
import time
from collections import deque
from typing import TYPE_CHECKING, Any

import pygame

from core.events import (
    BattleEndedEvent,
    DamageEvent,
    DodgeEvent,
    HealEvent,
    RevivedEvent,
    MissEvent,
    StanceEvent,
    StrokeEvent,
)
from core.factories import (
    combatant_from_monster_data,
    combatant_from_party_member,
)
from core.scene import Scene
from core.shared import by_id, short_name
from settings import (
    AudioSettings,
    BattleSettings,
    BattleStageSettings,
    LoadoutSettings,
    ColorSettings,
    FontSettings,
    ScreenSettings,
    UISettings,
)
from systems.battle import Battle, Combatant
from ui import input_map, text_renderer
from ui.battle_stage import BattleStage
from ui.battle_view import BattleView
from ui.layout import DebugOverlay
from ui.grid_menu import GridCell, GridMenu, GridRow, short_move_name
from ui.menu import Menu, MenuItem
from ui.text_box import TextBox
from ui.window import draw_window
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager


# Encounters a random battle can roll. Every fight whose monsters use
# only rules this game has. The Dwende and Amaranhig fight needs
# zombie and the Kaperosa needs doom, so they wait. This moves to
# per-cell tables with the overworld.
_DEMO_ENCOUNTER_IDS: tuple[str, ...] = (
    "beast_pack", "mages", "shades", "great_boar",
)

# Index of each row in the top-level command menu.
_ATTACK_ROW, _ABILITY_ROW, _DEFEND_ROW, _ITEM_ROW = range(4)

# The stroke menu's rows: the three strokes, then Tech. Cancel ends the
# chain once a stroke has been swung (Frankie, 10/18).
_STROKE_KINDS: tuple[str, ...] = ("light", "medium", "strong")
_STROKE_ABILITY_ROW = 3


def _build_enemies(
    encounter_id: str | None = None,
) -> tuple[list[Combatant], dict[str, str | None], set[str]]:
    """Build the monsters for one encounter.

    Args:
        encounter_id: Which fight. None rolls one of the demo fights.

    Returns:
        The monsters, each one's picture name keyed by its id, and the
        ids of those that float (ghosts and flyers).
    """
    encounter = by_id("encounters")[
        encounter_id or random.choice(_DEMO_ENCOUNTER_IDS)
    ]
    monsters = by_id("monsters")
    combatants = [
        combatant_from_monster_data(entry, monsters[entry["monster"]])
        for entry in encounter["enemies"]
    ]
    sprites = {entry["id"]: entry.get("sprite") for entry in encounter["enemies"]}
    floating = {entry["id"] for entry in encounter["enemies"] if entry.get("floats")}
    return combatants, sprites, floating


class BattleScene(Scene):
    """A turn-based encounter scene."""

    OPAQUE = True

    def __init__(
        self, gm: "GameManager", encounter_id: str | None = None
    ) -> None:
        """Build the battle from the party and an encounter.

        Args:
            gm: The game manager.
            encounter_id: A fight from the shared battle file. None
                rolls one of the demo fights at random.
        """
        super().__init__(gm)
        self.moves = by_id("moves")
        # Potions are a Party-level resource that persists across
        # battles. If the inventory entry is missing entirely (old
        # save, never been to a battle), fall back to the new-game
        # starter count so the player isn't silently emptied out.
        starting_potions = gm.party.inventory.get(
            "potion", BattleSettings.STARTING_POTIONS
        )
        enemies, sprites, floating = _build_enemies(encounter_id)
        # A fight with a boss in it plays the boss songs (music.json); a
        # boss is the monster that counts its element twice.
        self._music = "boss" if any(len(foe.elements) > 1 for foe in enemies) else "battle"
        # The first three fight; the rest wait on the bench (D-196).
        everyone = [combatant_from_party_member(m) for m in self.gm.party.members]
        weapons = by_id("weapons")
        for member, combatant in zip(self.gm.party.members, everyone):
            held = weapons.get(member.weapon or "")
            combatant.weapon = held["name"] if held else None
        self.battle = Battle(
            party_combatants=everyone[:BattleSettings.FIGHTERS],
            enemy_combatants=enemies,
            moves=self.moves,
            potions=starting_potions,
            bench=everyone[BattleSettings.FIGHTERS:],
            combos=by_id("combos"),
        )
        # Narration goes in the left part of the window; the party's
        # rows stay visible on the right while it plays.
        self.text_box = TextBox(
            width=UISettings.COMMAND_PANEL_WIDTH
        )
        self.view = BattleView(self.text_box)
        self.stage = BattleStage(
            self.battle.party, self.battle.enemies, sprites, floating,
            bench=self.battle.bench,
        )
        # Events the battle has produced but the screen has not shown yet.
        self._events: deque[Any] = deque()
        # HP as currently shown. It trails the battle's real HP until
        # the damage or heal event that changed it has been narrated.
        self._shown_hp: dict[str, int] = {
            c.id: c.hp
            for c in self.battle.party + self.battle.bench + self.battle.enemies
        }
        # Seconds the current finished line has been on screen.
        self._narration_held = 0.0
        # Seconds left before the next event plays: each stroke gets a
        # beat of its own, since strokes have no line to wait on.
        self._beat = 0.0
        self._battle_finished = False
        self.command_menu = Menu(
            items=[
                MenuItem("Attack", self._on_attack),
                MenuItem("Tech", self._on_open_abilities),
                MenuItem("Defend", self._on_defend),
                MenuItem("Item", self._on_open_items),
            ],
        )
        # Which page of commands shows: -1 Weapon and Escape, 0 the four
        # commands, 1 Combo and Swap (D-455). Built when turned to.
        self._page = 0
        self.side_menu: Menu | None = None
        # Weapon, Combo and Swap open a list that takes the window.
        self.list_menu: Menu | None = None
        # The Attack's stroke menu, open from the first target pick until
        # the turn ends.
        self.stroke_menu: Menu | None = None
        self._chain_target_id: str | None = None
        self.ability_menu: GridMenu | None = None
        self.item_menu: Menu | None = None
        self._pending_command: dict[str, Any] | None = None
        self._target_pool: list[Combatant] = []
        self._target_cursor: int = 0

    def on_enter(self) -> None:
        """Play the fight's music, the boss songs if a boss is here; victory keeps its own."""
        if self.gm.audio.screen != "victory":
            self.gm.audio.play_screen(self._music)

    # ------------------------------------------------------------------
    # COMMAND HANDLERS
    # ------------------------------------------------------------------

    def _on_attack(self) -> None:
        """Choose the enemy to strike, then open the stroke menu."""
        self._begin_targeting({"kind": "chain"}, pool="foe")

    def _open_stroke_menu(self) -> None:
        """Open the stroke menu: three strokes, then Tech.

        The strokes' labels, with their chance to land, are written each
        frame by ``_refresh_command_labels``.
        """
        items = [
            MenuItem("", lambda kind=kind: self._on_stroke(kind))
            for kind in _STROKE_KINDS
        ]
        items += [
            MenuItem("Tech", self._on_open_abilities),
        ]
        self.stroke_menu = Menu(items=items, on_cancel=self._cancel_stroke_menu)

    def _on_stroke(self, kind: str) -> None:
        """Swing a stroke at the chosen enemy, or pick a new one if it fell."""
        target = self.battle.chain_target()
        if target is None:
            target = next(
                (c for c in self.battle.enemies
                 if c.id == self._chain_target_id and c.alive),
                None,
            )
        if target is None:
            self._begin_targeting({"kind": "stroke", "stroke": kind}, pool="foe")
            return
        self._dispatch(self.battle.submit_stroke(kind, target.id))

    def _on_end_chain(self) -> None:
        """End the turn after the strokes swung so far."""
        self._dispatch(self.battle.submit_end_chain())

    def _cancel_stroke_menu(self) -> None:
        """Back out to the commands, or end the turn once a stroke has been swung."""
        if self.battle.chaining:
            self._on_end_chain()
            return
        self.stroke_menu = None
        self._chain_target_id = None

    def _on_defend(self) -> None:
        """Defend at once; it has no target."""
        self._dispatch(self.battle.submit_defend())

    def _on_open_abilities(self) -> None:
        """Open the active member's techniques as a grid (D-450).

        On top, the switch to the other stance, in its element's colour,
        with the mana it builds (D-285). Under it one row per mana cost
        that has something in this stance, three slots across, greyed
        while the meter is short of the row. Revive is greyed while
        nobody is down.
        """
        actor = self.battle.current_actor
        if actor is None:
            return
        rows: list[GridRow] = []
        other = self.battle.other_stance(actor)
        if other is not None:
            style = ColorSettings.ELEMENT_TEXT_STYLES.get(other["element"], {})
            rows.append(GridRow("", [GridCell(
                f"{other['name']} +{BattleSettings.STANCE_MANA}",
                self._on_stance_chosen,
                color=style.get("color"), glow=style.get("glow"),
                glow_radius=style.get("glow_radius", 3),
                glow_alpha=style.get("glow_alpha", 90),
            )]))
        moves = self.battle.moves_for(actor)
        for row in range(1, LoadoutSettings.ROWS + 1):
            here = [m for m in moves if self.battle.row_of(actor, m) == row]
            if not here:
                continue
            cells: list[GridCell | None] = []
            for move in here:
                style = ColorSettings.ELEMENT_TEXT_STYLES.get(move["element"], {})
                cells.append(GridCell(
                    short_move_name(move),
                    lambda move=move: self._on_ability_chosen(move),
                    enabled=actor.mana >= row and (
                        move["target"] != "fallen"
                        or any(not c.alive for c in self.battle.party)
                    ),
                    color=style.get("color"), glow=style.get("glow"),
                    glow_radius=style.get("glow_radius", 3),
                    glow_alpha=style.get("glow_alpha", 90),
                    data=move,
                ))
            cells += [None] * (LoadoutSettings.PER_ROW - len(cells))
            rows.append(GridRow(
                str(row), cells,
                BattleStageSettings.COLOR_MANA if actor.mana >= row else ColorSettings.GRAY,
            ))
        if not rows:
            return
        self.ability_menu = GridMenu(rows, on_cancel=self._close_ability_menu)

    def _on_stance_chosen(self) -> None:
        """Switch stance; it ends the turn."""
        self.ability_menu = None
        self._dispatch(self.battle.submit_stance())

    def _on_ability_chosen(self, move: dict[str, Any]) -> None:
        """Use a move with no target at once; otherwise choose a target."""
        self.ability_menu = None
        if move["target"] == "none":
            self._dispatch(self.battle.submit_move(move["id"]))
            return
        self._begin_targeting(
            {"kind": "move", "move_id": move["id"]}, pool=move["target"]
        )

    def _close_ability_menu(self) -> None:
        """Back out of the ability submenu to the command menu."""
        self.ability_menu = None

    def _on_open_items(self) -> None:
        """Open the item submenu (potions only, for now)."""
        if self.battle.potions <= 0:
            return
        self.item_menu = Menu(
            items=[
                MenuItem(
                    f"Potion x{self.battle.potions}", self._on_potion_chosen
                )
            ],
            on_cancel=self._close_item_menu,
        )

    def _on_potion_chosen(self) -> None:
        """Start choosing who drinks the potion."""
        self.item_menu = None
        self._begin_targeting({"kind": "potion"}, pool="ally")

    def _close_item_menu(self) -> None:
        """Back out of the item submenu to the command menu."""
        self.item_menu = None

    # ------------------------------------------------------------------
    # THE SIDE PAGES (D-455)
    # ------------------------------------------------------------------

    def _turn_page(self, step: int) -> bool:
        """Turn to the page left (-1) or right (+1) of this one, if there is one."""
        page = self._page + step
        if page not in (-1, 0, 1):
            return False
        self._page = page
        self.side_menu = None
        if page == -1:
            self.side_menu = Menu(items=[
                MenuItem("Weapon", self._on_open_weapons, enabled=bool(self._spare_weapons())),
                MenuItem("Escape", self._on_escape),
            ], on_cancel=self._back_to_commands)
        elif page == 1:
            items = []
            if self.battle.combos_for(self.battle.current_actor):
                items.append(MenuItem("Combo", self._on_open_combos))
            items.append(MenuItem(
                "Swap", self._on_open_swap,
                enabled=any(c.alive for c in self.battle.bench),
            ))
            self.side_menu = Menu(items=items, on_cancel=self._back_to_commands)
        return True

    def _back_to_commands(self) -> None:
        """Back to the page of four commands."""
        self._page = 0
        self.side_menu = None

    def _spare_weapons(self) -> list[dict[str, Any]]:
        """Return the weapons the one acting could take up instead of their own.

        Every weapon of a type they use, as the browser's Equip tab offers.
        """
        actor = self.battle.current_actor
        if actor is None:
            return []
        types = by_id("characters").get(actor.id, {}).get("weapon_types", [])
        return [
            w for w in by_id("weapons").values()
            if w["type"] in types and w["name"] != actor.weapon
        ]

    def _on_open_weapons(self) -> None:
        """List the weapons to change to."""
        self.list_menu = Menu(
            items=[
                MenuItem(w["name"], lambda w=w: self._on_weapon_chosen(w["name"]))
                for w in self._spare_weapons()
            ],
            on_cancel=self._close_list_menu,
        )

    def _on_weapon_chosen(self, name: str) -> None:
        """Change weapons; it ends the turn."""
        self._close_list_menu()
        self._back_to_commands()
        self._dispatch(self.battle.submit_weapon(name))

    def _on_escape(self) -> None:
        """Try to run."""
        self._back_to_commands()
        self._dispatch(self.battle.submit_escape())

    def _on_open_combos(self) -> None:
        """List the combos open now, each with its cost and partner."""
        actor = self.battle.current_actor
        items = []
        for combo, partner in self.battle.combos_for(actor):
            label = f"{BattleSettings.COMBO_MANA} {combo['name']:<13}{short_name(partner.id)}"
            items.append(MenuItem(
                label, lambda combo=combo, partner=partner: self._on_combo_chosen(combo, partner),
                enabled=self.battle.can_pay_combo(actor, partner),
            ))
        self.list_menu = Menu(items=items, on_cancel=self._close_list_menu)

    def _on_combo_chosen(self, combo: dict[str, Any], partner: Combatant) -> None:
        """Strike at once if the combo hits everyone; otherwise choose the enemy."""
        self._close_list_menu()
        if combo["target"] == "none":
            self._back_to_commands()
            self._dispatch(self.battle.submit_combo(combo["id"], partner.id))
            return
        self._begin_targeting(
            {"kind": "combo", "combo_id": combo["id"], "partner_id": partner.id},
            pool="foe",
        )

    def _on_open_swap(self) -> None:
        """List who waits on the bench."""
        self.list_menu = Menu(
            items=[
                MenuItem(short_name(c.id), lambda c=c: self._on_swap_chosen(c.id), enabled=c.alive)
                for c in self.battle.bench
            ],
            on_cancel=self._close_list_menu,
        )

    def _on_swap_chosen(self, bench_id: str) -> None:
        """Bring the bench member in; the turn is theirs."""
        self._close_list_menu()
        self._back_to_commands()
        self._dispatch(self.battle.submit_swap(bench_id))

    def _close_list_menu(self) -> None:
        """Back out of the Weapon, Combo or Swap list to its page."""
        self.list_menu = None

    def _dispatch(self, events: list[Any]) -> None:
        """Queue the battle's events to be played back one at a time."""
        self._events.extend(events)
        if not self.battle.is_awaiting_command():
            # The turn is over: the next one opens on the commands.
            self.stroke_menu = None
            self.ability_menu = None
            self.list_menu = None
            self._back_to_commands()
            self._chain_target_id = None
        if any(isinstance(ev, BattleEndedEvent) for ev in events):
            self._sync_party_state_back()

    def _sync_party_state_back(self) -> None:
        """Write battle-mutated state back onto the persistent ``Party``.

        Called once, when the battle produces its ``BattleEndedEvent``.
        Pushes each party combatant's HP back onto the matching
        ``PartyMember`` so damage carries into the overworld and the
        next save, and writes the surviving potion count back onto
        ``Party.inventory``.

        A lost fight is the exception: the party walks away at full
        HP. That is a placeholder until there is a real game-over or
        knocked-out state, so that losing does not leave the next
        fight unwinnable.
        """
        lost = self.battle.outcome == "defeat"
        for combatant in self.battle.party + self.battle.bench:
            member = self.gm.party.find(combatant.id)
            if member is None:
                continue
            # What grew in the fight stays grown (D-498), so the member's
            # stats, max HP included, are worked out again first.
            member.growth = dict(combatant.growth)
            member.refresh_stats()
            # The fight's max HP follows the stance (D-365); the share of
            # it is what carries back out.
            share = combatant.hp / max(1, combatant.max_hp)
            member.current_hp = (
                member.max_hp if lost
                else max(0, min(round(share * member.max_hp), member.max_hp))
            )
        self.gm.party.inventory["potion"] = max(0, int(self.battle.potions))
        # A weapon changed in the fight stays changed (D-462).
        by_name = {w["name"]: w["id"] for w in by_id("weapons").values()}
        for combatant in self.battle.party + self.battle.bench:
            member = self.gm.party.find(combatant.id)
            if member is not None and combatant.weapon in by_name:
                member.weapon = by_name[combatant.weapon]
        # A swap in the fight carries over: whoever ended it fighting
        # stays in the first three.
        order = [c.id for c in self.battle.party + self.battle.bench]
        self.gm.party.members.sort(
            key=lambda m: order.index(m.id) if m.id in order else len(order)
        )
        # Every monster beaten gets its bestiary page (D-458).
        from core.scenes.bestiary_scene import beaten_flag  # local: cycle.

        for enemy in self.battle.enemies:
            if not enemy.alive:
                self.gm.party.flags[beaten_flag(enemy.name)] = True

    # ------------------------------------------------------------------
    # TARGETING
    # ------------------------------------------------------------------

    def _begin_targeting(self, pending: dict[str, Any], pool: str) -> None:
        """Enter target selection over the living foes or allies, or the fallen ones."""
        side = self.battle.enemies if pool == "foe" else self.battle.party
        if pool == "fallen":
            candidates = [c for c in side if not c.alive]
        else:
            candidates = [c for c in side if c.alive]
        if not candidates:
            return
        self._pending_command = pending
        self._target_pool = candidates
        self._target_cursor = 0

    def _on_target_confirmed(self) -> None:
        """Submit the pending command against the highlighted target."""
        if not self._pending_command or not self._target_pool:
            return
        target = self._target_pool[self._target_cursor]
        cmd = self._pending_command
        self._clear_targeting()
        if cmd["kind"] == "chain":
            self._chain_target_id = target.id
            self._open_stroke_menu()
        elif cmd["kind"] == "stroke":
            self._chain_target_id = target.id
            self._dispatch(self.battle.submit_stroke(cmd["stroke"], target.id))
        elif cmd["kind"] == "move":
            self._dispatch(self.battle.submit_move(cmd["move_id"], target.id))
        elif cmd["kind"] == "potion":
            self._dispatch(self.battle.submit_potion(target.id))
        elif cmd["kind"] == "combo":
            self._back_to_commands()
            self._dispatch(self.battle.submit_combo(
                cmd["combo_id"], cmd["partner_id"], target.id
            ))

    def _cancel_targeting(self) -> None:
        """Leave target selection and reopen the menu it came from."""
        cmd = self._pending_command
        self._clear_targeting()
        if cmd is None:
            return
        if cmd["kind"] == "move":
            self._on_open_abilities()
        elif cmd["kind"] == "potion":
            self._on_open_items()
        elif cmd["kind"] == "combo":
            self._on_open_combos()

    def _clear_targeting(self) -> None:
        """Forget the pending command and its target list."""
        self._pending_command = None
        self._target_pool = []
        self._target_cursor = 0

    def _move_target_cursor(self, direction: int) -> None:
        """Step the target cursor, wrapping at either end."""
        if not self._target_pool:
            return
        self._target_cursor = (
            self._target_cursor + direction
        ) % len(self._target_pool)

    # ------------------------------------------------------------------
    # PLAYBACK
    # ------------------------------------------------------------------

    def _can_command(self) -> bool:
        """Return True when the player may pick a command right now."""
        return (
            self.battle.is_awaiting_command()
            and not self._events
            and self._beat <= 0
            and self.text_box.is_done()
        )

    def _play_events(self) -> None:
        """Show queued events until one puts a line on screen or a stroke swings."""
        while self._events and self.text_box.is_done() and self._beat <= 0:
            event = self._events.popleft()
            if isinstance(event, DamageEvent):
                self._shown_hp[event.target_id] -= event.amount
                self._hit_sound("hit_magic" if event.cause == "spell" else "hit_punch")
            elif isinstance(event, HealEvent):
                self._shown_hp[event.target_id] += event.amount
                self._hit_sound("hit_sparkle")
            elif isinstance(event, RevivedEvent):
                self._shown_hp[event.target_id] = event.hp
                self._hit_sound("hit_sparkle")
            elif isinstance(event, (DodgeEvent, MissEvent)):
                self._hit_sound("hit_miss")
            elif isinstance(event, StanceEvent):
                # A new stance moves max HP and keeps the share (D-365).
                for c in self.battle.party:
                    if c.id == event.combatant_id:
                        self._shown_hp[c.id] = c.hp
            elif isinstance(event, BattleEndedEvent):
                self._battle_finished = True
                if self.battle.outcome == "victory":
                    self.gm.audio.play_screen("victory")
            self.view.consume(event)
            self.stage.consume(event)
            if isinstance(event, StrokeEvent):
                self._beat = BattleSettings.STROKE_BEAT_SECONDS

    def _hit_sound(self, kind: str) -> None:
        """Play one of the three takes of a hit sound."""
        take = random.randint(1, AudioSettings.HIT_TAKES)
        self.gm.audio.play(f"{kind}_{take}")

    def _hold_narration(self, dt: float) -> None:
        """Advance a finished line by itself after a short hold."""
        if self.text_box.is_done() or not self.text_box.is_page_complete():
            self._narration_held = 0.0
            return
        self._narration_held += dt
        if self._narration_held >= BattleSettings.NARRATION_HOLD_SECONDS:
            self._narration_held = 0.0
            self.text_box.advance()

    def _preview_wait(self) -> float | None:
        """Return the wait the highlighted action would cost, for the strip.

        None means nothing specific is highlighted yet (the cursor is on
        Attack or Ability before the choice), and the strip guesses.
        """
        battle = self.battle
        if self._pending_command is not None:
            kind = self._pending_command["kind"]
            if kind in ("chain", "stroke"):
                return None
            return battle.preview_wait("item" if kind == "potion" else "move")
        if self.ability_menu is not None:
            return battle.preview_wait("move")
        if self.item_menu is not None:
            return battle.preview_wait("item")
        if self.list_menu is not None:
            return battle.preview_wait("move" if self._page == 1 else "defend")
        if self.side_menu is not None:
            label = self.side_menu.items[self.side_menu.cursor].label
            if label in ("Weapon", "Escape"):
                return battle.preview_wait("defend")
            return battle.preview_wait("move") if label == "Combo" else None
        if self.stroke_menu is not None:
            row = self.stroke_menu.cursor
            if row < len(_STROKE_KINDS):
                points = BattleSettings.STROKES[_STROKE_KINDS[row]]["points"]
                return battle.preview_wait("attack") + points * BattleSettings.STROKE_WAIT
            return None
        row = self.command_menu.cursor
        if row == _DEFEND_ROW:
            return battle.preview_wait("defend")
        if row == _ITEM_ROW:
            return battle.preview_wait("item")
        return None

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Advance narration, or drive the menus and target cursor."""
        if not self.text_box.is_done():
            if input_map.is_confirm(event):
                self._narration_held = 0.0
                self.text_box.advance()
            return
        if self._battle_finished or not self._can_command():
            return
        if self._pending_command is not None:
            if input_map.is_cancel(event):
                self._cancel_targeting()
                self.gm.audio.play("menu_move")
            elif input_map.is_up(event) or input_map.is_left(event):
                self._move_target_cursor(-1)
                self.gm.audio.play("menu_move")
            elif input_map.is_down(event) or input_map.is_right(event):
                self._move_target_cursor(1)
                self.gm.audio.play("menu_move")
            elif input_map.is_confirm(event):
                self.gm.audio.play("menu_select")
                self._on_target_confirmed()
            return
        if input_map.is_cancel(event):
            if self.list_menu is not None:
                self.list_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.side_menu is not None:
                self.side_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.item_menu is not None:
                self.item_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.ability_menu is not None:
                self.ability_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.stroke_menu is not None:
                if not self.battle.chaining:
                    self.stroke_menu.cancel()
                    self.gm.audio.play("menu_move")
            return
        on_pages = (
            self.list_menu is None and self.item_menu is None
            and self.ability_menu is None and self.stroke_menu is None
        )
        if on_pages and (input_map.is_left(event) or input_map.is_right(event)):
            if self._turn_page(-1 if input_map.is_left(event) else 1):
                self.gm.audio.play("menu_move")
            return
        active_menu = (
            self.list_menu or self.item_menu or self.ability_menu
            or self.stroke_menu or self.side_menu or self.command_menu
        )
        if input_map.is_up(event):
            if active_menu.move_up():
                self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            if active_menu.move_down():
                self.gm.audio.play("menu_move")
        elif isinstance(active_menu, GridMenu) and input_map.is_left(event):
            if active_menu.move_left():
                self.gm.audio.play("menu_move")
        elif isinstance(active_menu, GridMenu) and input_map.is_right(event):
            if active_menu.move_right():
                self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            if active_menu.confirm():
                self.gm.audio.play("menu_select")

    # ------------------------------------------------------------------
    # RENDER
    # ------------------------------------------------------------------

    def render(self, surface: pygame.Surface) -> None:
        """Draw the fighters, the turn strip, and the bottom window.

        The window is split: commands or narration on the left, the
        party's rows on the right. The Ability and Item submenus take
        the whole window while they are open.
        """
        render_scene_background(self, surface)
        actor = self.battle.current_actor
        active_id = actor.id if actor is not None else None
        cursor_visible = (
            int(time.monotonic() * UISettings.MENU_CURSOR_BLINK_HZ * 2) % 2 == 0
        )
        target = (
            self._target_pool[self._target_cursor]
            if self._pending_command is not None and self._target_pool
            else None
        )
        self.stage.render_enemies(
            surface, self._shown_hp, active_id, target, cursor_visible,
        )
        self._render_turn_strip(surface)
        commanding = not self._battle_finished and self._can_command()
        submenu = (
            (self.list_menu or self.item_menu or self.ability_menu)
            if commanding else None
        )
        self._render_hud_frame(surface, split=submenu is None)
        if submenu is None:
            self.stage.render_party(
                surface, self._shown_hp, active_id, target, cursor_visible,
            )
        aiming = (
            commanding and submenu is None and target is not None
            and not target.is_party
        )
        if aiming:
            self._render_target_name(surface, target)
        elif commanding:
            self._render_menu(
                surface,
                submenu or self.stroke_menu or self.side_menu or self.command_menu,
            )
            if submenu is None and self.stroke_menu is not None:
                self._render_points(surface)
        else:
            self.text_box.render(surface)
        self.stage.render_floaters(surface)

    def _render_target_name(self, surface: pygame.Surface, target: Combatant) -> None:
        """While a monster is aimed at, the left window shows its name (Frankie, 10/18)."""
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        text_renderer.draw_text(
            surface, target.name,
            (rect.left + pad + UISettings.MENU_LABEL_OFFSET, rect.top + pad),
            color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
            max_width=UISettings.COMMAND_PANEL_WIDTH - 2 * pad - UISettings.MENU_LABEL_OFFSET,
        )

    def _render_turn_strip(self, surface: pygame.Surface) -> None:
        """Draw who acts now and who acts next, as a column of small pictures (D-453)."""
        actor = self.battle.current_actor
        if actor is None or self.battle.is_over:
            return
        wait = self._preview_wait() if self._can_command() else None
        upcoming = self.battle.upcoming(BattleSettings.TURN_ORDER_LENGTH, wait)
        self.stage.render_turn_order(surface, [actor] + upcoming)

    def _hud_rect(self, surface: pygame.Surface) -> pygame.Rect:
        """Return the bottom window's rectangle."""
        return pygame.Rect(
            0,
            surface.get_height() - UISettings.TEXT_BOX_HEIGHT,
            ScreenSettings.WIDTH,
            UISettings.TEXT_BOX_HEIGHT,
        )

    def _render_hud_frame(self, surface: pygame.Surface, split: bool) -> None:
        """Draw the bottom window, or two side by side when split (D-457)."""
        rect = self._hud_rect(surface)
        if not split:
            draw_window(surface, rect)
            return
        left = rect.copy()
        left.width = UISettings.COMMAND_PANEL_WIDTH
        right = rect.copy()
        right.left = left.right
        right.width = rect.right - left.right
        draw_window(surface, left)
        draw_window(surface, right)

    def _render_menu(self, surface: pygame.Surface, menu: Menu | GridMenu) -> None:
        """Draw ``menu`` in the window, from its top-left corner."""
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        self._refresh_command_labels()
        if isinstance(menu, GridMenu):
            row_height = UISettings.ABILITY_MENU_ROW_HEIGHT
            menu.render(
                surface,
                (rect.left + pad + UISettings.MENU_LABEL_OFFSET, rect.top + pad),
                row_height=row_height,
                max_rows=(rect.height - 2 * pad) // row_height,
                label_width=UISettings.ABILITY_LABEL_WIDTH,
                col_width=UISettings.ABILITY_COL_WIDTH,
                font_size=FontSettings.SIZE_BODY,
            )
            return
        row_height = UISettings.COMMAND_MENU_ROW_HEIGHT
        # A menu that fits sits centred top to bottom (Frankie, 10/18);
        # a longer one starts at the top and scrolls.
        border = UISettings.TEXT_BOX_BORDER_THICKNESS
        inner = rect.height - 2 * border
        block = (len(menu.items) - 1) * row_height + FontSettings.LETTER_WIDTH
        top = (
            rect.top + border + (inner - block) // 2
            if len(menu.items) * row_height <= rect.height - 2 * pad
            else rect.top + pad
        )
        menu.render(
            surface,
            (rect.left + pad + UISettings.MENU_LABEL_OFFSET, top),
            font_size=FontSettings.SIZE_BODY,
            row_height=row_height,
            max_rows=(rect.height - 2 * pad) // row_height,
        )

    def _render_points(self, surface: pygame.Surface) -> None:
        """Draw the stroke points left this turn as a standing bar at the panel's right edge.

        One segment a point, filled from the bottom, yellow while unspent.
        """
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        total = BattleSettings.STROKE_POINTS
        left = self.battle.chain_points_left
        gap = UISettings.POINTS_BAR_GAP
        segment = (rect.height - 2 * pad + gap) // total - gap
        x = rect.left + UISettings.COMMAND_PANEL_WIDTH - pad - UISettings.POINTS_BAR_WIDTH + 2
        bottom = rect.bottom - pad
        for index in range(total):
            top = bottom - (index + 1) * segment - index * gap
            color = ColorSettings.YELLOW if index < left else UISettings.POINTS_BAR_SPENT
            pygame.draw.rect(
                surface, color,
                pygame.Rect(x, top, UISettings.POINTS_BAR_WIDTH, segment),
            )

    def _refresh_command_labels(self) -> None:
        """Grey out Item when the potions have run out, and write the stroke rows.

        Each stroke reads "1 LIGHT  95%": its points, its name, its chance
        to land on the target. A stroke that no longer fits is grey; one
        that spends the last points, ending the turn, is yellow
        (Frankie, 10/18).
        """
        self.command_menu.items[_ITEM_ROW].enabled = self.battle.potions > 0
        if self.stroke_menu is not None:
            left = self.battle.chain_points_left
            lightest = BattleSettings.STROKES["light"]["points"]
            target = self.battle.chain_target() or next(
                (c for c in self.battle.enemies
                 if c.id == self._chain_target_id and c.alive),
                None,
            )
            for row, kind in enumerate(_STROKE_KINDS):
                stroke = BattleSettings.STROKES[kind]
                item = self.stroke_menu.items[row]
                item.enabled = stroke["points"] <= left
                item.color = (
                    ColorSettings.YELLOW if left - stroke["points"] < lightest else None
                )
                chance = (
                    f"{round(100 * self.battle.stroke_chance(kind, target)):>3}%"
                    if target is not None else ""
                )
                item.label = f"{stroke['points']} {stroke['name']:<6}{chance}"

    # ------------------------------------------------------------------
    # UPDATE
    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        """Play narration, start the next turn, and leave when done."""
        self.text_box.update(dt)
        self.stage.update(dt, self._shown_hp)
        self._beat = max(0.0, self._beat - dt)
        self._hold_narration(dt)
        self._play_events()
        if (
            not self.battle.is_over
            and not self.battle.is_awaiting_command()
            and not self._events
            and self._beat <= 0
            and self.text_box.is_done()
        ):
            self._dispatch(self.battle.start_turn())
            self._play_events()
        if self._battle_finished and self.text_box.is_done():
            self.gm.scene_stack.pop()
