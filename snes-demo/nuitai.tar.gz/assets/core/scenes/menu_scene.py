"""The field menu, Final Fantasy style (D-460).

The three who fight down the left, each with a portrait, current HP, the stance
they start a fight in and anything wrong with them; the commands in a
window on the right; the time played and the steps walked, each a yellow label with its number
tucked under it on the right, then the money, kupang and pule (D-476), each by its icon; the time
and the steps in one box, the money in a second (Frankie, 10/25 and 10/27; the date went to the place pop-up). Element, Equip and Status ask which member first, as
Final Fantasy VI does: the cursor moves to the party, confirm opens that
member's page, cancel goes back to the commands.

Kept short, like Final Fantasy VI (Frankie, 10/23): no Quit (a Super
Nintendo is turned off or reset), no Order, no Save: the game saves only
at a save point, Kailo's bed or the healing pond, and asks there (Frankie,
10/25). Data replaces Bestiary (Frankie, 10/23): the bestiary
and the lore pages (``data_scene.py``). Config opens the settings
(``config_scene.py``, Frankie 10/26). Left from the
commands moves the cursor onto the portraits to put the three in order: pick
one, pick another, and they swap; cancel drops the first pick, then goes
back to the commands. Party opens the screen that swaps who fights with
who waits (``bench_scene.py``, Frankie 10/23).

Pushed by gameplay scenes and drawn over them (``OPAQUE`` is False).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

import pygame

from core.scene import Scene
from core.factories import stance_numbers
from core.shared import by_id, short_name
from settings import (
    BattleSettings, ColorSettings, FontSettings, ScreenSettings, UISettings,
)
from systems import records
from ui import input_map, text_renderer
from ui.menu import Menu, MenuItem
from ui.window import draw_window
from utils.graphics import load_element_icon, load_portrait

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


_OVERLAY_ALPHA = 200  # Out of 255; high enough to dim the world clearly.

# The three windows on the 256 by 224 screen.
_PARTY_RECT = pygame.Rect(0, 0, 168, 224)
_COMMAND_RECT = pygame.Rect(168, 0, 88, 130)
# Under the commands: the time played and the steps walked in one box, then the money
# in a second (Frankie, 10/27). Each box and the rows it holds.
_RECORD_BOXES = (
    (pygame.Rect(168, 130, 88, 54), ("time", "steps")),
    (pygame.Rect(168, 184, 88, 40), ("kupang", "pule")),
)
# The seven commands spread evenly down the column (Frankie, 10/27).
_COMMAND_ROW = 18
# A number sits tucked just under its label, as Final Fantasy VI's Time and Steps (Frankie, 10/27).
_VALUE_DROP = 9
_RECORD_GAP = 12  # From a number to the next label.
_MONEY_ROW = 16  # The pitch of the money's lines, a 16 pixel icon each.

# A member's row: the 48 pixel portrait, then name, HP and stance beside it.
_ROW_TOP = 6
_ROW_HEIGHT = 56  # A whole number of 8 pixel text rows, so every row's words sit on the grid (10/22).
_PORTRAIT_X = 10
_TEXT_X = 64
_PORTRAIT = UISettings.PORTRAIT_SIZE
_BENCH_COLOR = ColorSettings.GRAY


class MenuScene(Scene):
    """The field menu: the party on the left, the commands on the right."""

    OPAQUE = False  # Render the scene below us first; we sit on top.

    def __init__(self, gm: "GameManager") -> None:
        """Build the commands."""
        super().__init__(gm)
        self.menu = Menu(
            items=[
                MenuItem("Items", self._open_inventory),
                MenuItem("Element", lambda: self._pick_member(self._open_tech)),
                MenuItem("Equip", lambda: self._pick_member(self._open_equip)),
                MenuItem("Status", lambda: self._pick_member(self._open_status)),
                MenuItem("Party", self._open_party),
                MenuItem("Info", self._open_data),
                MenuItem("Config", self._open_config),
            ],
            on_cancel=self._resume,
        )
        # While a command waits for a member, what to do with them.
        self._picking: Callable[[int], None] | None = None
        # The first portrait picked to swap, waiting for the second.
        self._order_from: int | None = None
        self._member_cursor = 0
        # Cached overlay surface so we don't allocate every frame.
        self._overlay = pygame.Surface(ScreenSettings.RESOLUTION).convert_alpha()
        self._overlay.fill((0, 0, 0, _OVERLAY_ALPHA))

    # ------------------------------------------------------------------
    # ACTIONS
    # ------------------------------------------------------------------

    def _pick_member(self, then: Callable[[int], None]) -> None:
        """Move the cursor to the party; confirm calls ``then`` with the member's place."""
        if self.gm.party.members:
            self._picking = then

    def _swap_first(self, index: int) -> None:
        """Remember the first portrait picked, and pick again."""
        self._order_from = index
        self._picking = self._swap_second

    def _swap_second(self, index: int) -> None:
        """Swap the two picked members' places, and stay on the party. The first three fight (D-196)."""
        members = self.gm.party.members
        first, self._order_from = self._order_from, None
        if first is not None and first != index:
            members[first], members[index] = members[index], members[first]
        self._picking = self._swap_first

    def _open_tech(self, index: int) -> None:
        """Push a member's techniques and starting stance."""
        from core.scenes.loadout_scene import LoadoutScene  # local: cycle.

        self.gm.scene_stack.push(LoadoutScene(self.gm, self.gm.party.members[index]))

    def _open_equip(self, index: int) -> None:
        """Push a member's weapons to choose from."""
        from core.scenes.equip_scene import EquipScene  # local: cycle.

        self.gm.scene_stack.push(EquipScene(self.gm, self.gm.party.members[index]))

    def _open_status(self, index: int) -> None:
        """Push the party's stats, open on the chosen member."""
        from core.scenes.party_scene import PartyScene  # local: cycle.

        self.gm.scene_stack.push(PartyScene(self.gm, cursor=index))

    def _open_inventory(self) -> None:
        """Push the inventory list."""
        from core.scenes.inventory_scene import InventoryScene  # local: cycle.

        self.gm.scene_stack.push(InventoryScene(self.gm))

    def _open_party(self) -> None:
        """Push the screen that swaps who fights with who waits."""
        from core.scenes.bench_scene import BenchScene  # local: cycle.

        self.gm.scene_stack.push(BenchScene(self.gm))

    def _fighters(self) -> list:
        """The three who fight, the only ones the menu shows (Frankie, 10/23)."""
        return self.gm.party.members[:BattleSettings.FIGHTERS]

    def _open_data(self) -> None:
        """Push Data: the bestiary and the records (Frankie, 10/23)."""
        from core.scenes.data_scene import DataScene  # local: cycle.

        self.gm.scene_stack.push(DataScene(self.gm))

    def _open_config(self) -> None:
        """Push Config: the cursor, message speed, window color, sound and buttons (Frankie, 10/26)."""
        from core.scenes.config_scene import ConfigScene  # local: cycle.

        self.gm.scene_stack.push(ConfigScene(self.gm))

    def _resume(self) -> None:
        """Pop this overlay so the underlying scene resumes."""
        self.gm.scene_stack.pop()

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Drive the commands, or the party cursor while a command waits on a member."""
        if self._picking is not None:
            count = len(self._fighters())
            if input_map.is_cancel(event):
                if self._order_from is not None:
                    self._order_from = None
                    self._picking = self._swap_first
                else:
                    self._picking = None
                self.gm.audio.play("menu_move")
            elif input_map.is_right(event) and self._picking in (self._swap_first, self._swap_second):
                self._picking = None
                self._order_from = None
                self.gm.audio.play("menu_move")
            elif input_map.is_up(event):
                self._member_cursor = (self._member_cursor - 1) % count
                self.gm.audio.play("menu_move")
            elif input_map.is_down(event):
                self._member_cursor = (self._member_cursor + 1) % count
                self.gm.audio.play("menu_move")
            elif input_map.is_confirm(event):
                then, self._picking = self._picking, None
                self.gm.audio.play("menu_select")
                then(self._member_cursor)
            return
        if input_map.is_left(event) and self.gm.party.members:
            self._picking = self._swap_first
            self.gm.audio.play("menu_move")
        elif input_map.is_up(event):
            if self.menu.move_up():
                self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            if self.menu.move_down():
                self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            if self.menu.confirm():
                self.gm.audio.play("menu_select")
        elif input_map.is_cancel(event):
            if self.menu.cancel():
                self.gm.audio.play("menu_select")

    def render(self, surface: pygame.Surface) -> None:
        """Dim the world, then draw the party, the commands, the money and the records."""
        surface.blit(self._overlay, (0, 0))
        draw_window(surface, _PARTY_RECT)
        for index, member in enumerate(self._fighters()):
            self._render_member(surface, member, index)
        draw_window(surface, _COMMAND_RECT)
        span = (len(self.menu.items) - 1) * _COMMAND_ROW + FontSettings.SIZE_BODY
        self.menu.render(
            surface,
            (_COMMAND_RECT.left + UISettings.TEXT_BOX_PADDING + UISettings.MENU_LABEL_OFFSET,
             _COMMAND_RECT.top + (_COMMAND_RECT.height - span) // 2),
            font_size=FontSettings.SIZE_BODY,
            row_height=_COMMAND_ROW,
        )
        for rect, rows in _RECORD_BOXES:
            draw_window(surface, rect)
            self._render_records(surface, rect, rows)

    def _render_records(self, surface: pygame.Surface, rect: pygame.Rect, rows: tuple[str, ...]) -> None:
        """One box of records: the time played and the steps walked, a yellow label with its
        number tucked under it on the right; the money, kupang, the coin, and pule, the shells
        (D-476), each by its icon (Frankie, 10/25).
        """
        pad = UISettings.TEXT_BOX_PADDING
        party = self.gm.party
        records_text = {"time": ("Time", records.time_text(party)),
                        "steps": ("Steps", str(records.steps(party)))}
        money_text = {"kupang": str(party.kupang), "pule": str(party.pule)}
        y = rect.top + pad

        def number(text: str) -> None:
            text_renderer.draw_text(
                surface, text,
                (rect.right - pad - text_renderer.text_width(text, FontSettings.SIZE_BODY), y),
                color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
            )

        after_record = False
        for row in rows:
            if row in records_text:
                label, text = records_text[row]
                text_renderer.draw_text(
                    surface, label, (rect.left + pad, y),
                    color=ColorSettings.YELLOW, size=FontSettings.SIZE_BODY,
                )
                y += _VALUE_DROP
                number(text)
                y += _RECORD_GAP
                after_record = True
                continue
            if after_record:
                # The coin's icon reaches 4 pixels above its number; keep 2 pixels clear of the steps.
                y += 2
                after_record = False
            icon = load_element_icon(row)
            if icon is not None:
                surface.blit(icon, (rect.left + pad, y - 4))
            number(money_text[row])
            y += _MONEY_ROW

    def _render_member(
        self, surface: pygame.Surface, member: "PartyMember", index: int
    ) -> None:
        """One member: portrait, first name, HP, their elements with the stance boxed, any trouble.

        Those past the first three wait on the bench (D-196), their names
        in grey.
        """
        top = _ROW_TOP + index * _ROW_HEIGHT
        picking_here = self._picking is not None and index == self._member_cursor
        frame = pygame.Rect(_PORTRAIT_X, top, _PORTRAIT, _PORTRAIT)
        portrait = load_portrait(member.id)
        clip = surface.get_clip()
        surface.set_clip(frame)
        surface.blit(portrait, (
            frame.centerx - portrait.get_width() // 2,
            frame.centery - portrait.get_height() // 2,
        ))
        surface.set_clip(clip)
        benched = index >= BattleSettings.FIGHTERS
        if benched:
            # Bench members are dimmed: only three fight (D-196). No line
            # above them (Frankie, 10/20); D-614 takes them out of this window.
            shade = pygame.Surface(frame.size, pygame.SRCALPHA)
            shade.fill((0, 0, 0, 120))
            surface.blit(shade, frame.topleft)
        chosen = picking_here or index == self._order_from
        pygame.draw.rect(
            surface, ColorSettings.YELLOW if chosen else ColorSettings.WHITE,
            frame.inflate(2, 2), 1,
        )
        if picking_here:
            tip = (_PORTRAIT_X - 4, top + _PORTRAIT // 2)
            pygame.draw.polygon(surface, ColorSettings.YELLOW, [
                tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 5, tip[1] + 5),
            ])
        size = FontSettings.SIZE_BODY
        down = member.current_hp <= 0
        name_color = (
            ColorSettings.RED if down
            else _BENCH_COLOR if benched else ColorSettings.WHITE
        )
        text_renderer.draw_text(
            surface, short_name(member.id), (_TEXT_X, top + 2),
            color=name_color, size=size,
        )
        text_renderer.draw_text(
            surface, "HP {1}/{2}".format(*stance_numbers(member)), (_TEXT_X, top + 18),
            color=ColorSettings.WHITE, size=size,
        )
        # The two elements as icons, the stance they start in boxed in
        # thick yellow (D-461).
        stance_element = None
        stances = by_id("characters").get(member.id, {}).get("stances", [])
        if stances:
            stance_element = stances[member.stance if 0 <= member.stance < len(stances) else 0]["element"]
        icon_y = top + 31
        for slot, element in enumerate(member.elements):
            icon = load_element_icon(element)
            x = _TEXT_X + 2 + slot * (UISettings.ELEMENT_ICON_SIZE + 8)
            if icon is not None:
                surface.blit(icon, (x, icon_y))
            if element == stance_element:
                pygame.draw.rect(
                    surface, ColorSettings.YELLOW,
                    pygame.Rect(x - 2, icon_y - 2,
                                UISettings.ELEMENT_ICON_SIZE + 4, UISettings.ELEMENT_ICON_SIZE + 4),
                    2, border_radius=2,
                )
        if down:
            text_renderer.draw_text(
                surface, "KO", (_PARTY_RECT.right - 26, top + 2),
                color=ColorSettings.RED, size=size,
            )
