"""The field menu, Final Fantasy style (D-460).

The party down the left, each with a portrait, current HP, the stance
they start a fight in and anything wrong with them; the commands in a
window on the right; the money, kupang and pule (D-476), in a small window under them, where the
date will go too. Tech and Status ask which member first, as Final
Fantasy VI does: the cursor moves to the party, confirm opens that
member's page, cancel goes back to the commands.

Pushed by gameplay scenes and drawn over them (``OPAQUE`` is False).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

import pygame

from core import save
from core.scene import Scene
from core.scenes.confirm_scene import ConfirmScene
from core.factories import stance_numbers
from core.shared import by_id, short_name
from settings import (
    BattleSettings, ColorSettings, ConfirmSettings, FontSettings, ScreenSettings, UISettings,
)
from ui import input_map, text_renderer
from ui.menu import Menu, MenuItem
from ui.window import draw_window
from utils.graphics import load_element_icon, load_portrait

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


_OVERLAY_ALPHA = 200  # Out of 255; high enough to dim the world clearly.

# The three windows on the 256 by 224 screen.
_PARTY_RECT = pygame.Rect(0, 0, 168, 224)
_COMMAND_RECT = pygame.Rect(168, 0, 88, 160)
_MONEY_RECT = pygame.Rect(168, 160, 88, 64)

# A member's row: the 48 pixel portrait, then name, HP and stance beside it.
_ROW_TOP = 6
_ROW_HEIGHT = 54
_PORTRAIT_X = 10
_TEXT_X = 64
_PORTRAIT = UISettings.PORTRAIT_SIZE
_BENCH_COLOR = ColorSettings.GRAY


class MenuScene(Scene):
    """The field menu: the party on the left, the commands on the right."""

    OPAQUE = False  # Render the scene below us first; we sit on top.

    def __init__(self, gm: "GameManager") -> None:
        """Build the commands."""
        super().__init__(gm)
        self.menu = Menu(
            items=[
                MenuItem("Items", self._open_inventory),
                MenuItem("Tech", lambda: self._pick_member(self._open_tech)),
                MenuItem("Equip", lambda: self._pick_member(self._open_equip)),
                MenuItem("Status", lambda: self._pick_member(self._open_status)),
                MenuItem("Order", lambda: self._pick_member(self._order_first)),
                MenuItem("Bestiary", self._open_bestiary),
                MenuItem("Save", self._save),
                MenuItem("Options", self._noop, enabled=False),
                MenuItem("Quit", self._quit_to_title),
            ],
            on_cancel=self._resume,
        )
        # While a command waits for a member, what to do with them.
        self._picking: Callable[[int], None] | None = None
        # Order's first pick, waiting for the second.
        self._order_from: int | None = None
        self._member_cursor = 0
        # Cached overlay surface so we don't allocate every frame.
        self._overlay = pygame.Surface(ScreenSettings.RESOLUTION).convert_alpha()
        self._overlay.fill((0, 0, 0, _OVERLAY_ALPHA))

    # ------------------------------------------------------------------
    # ACTIONS
    # ------------------------------------------------------------------

    def _noop(self) -> None:
        """Placeholder for commands not built yet."""

    def _pick_member(self, then: Callable[[int], None]) -> None:
        """Move the cursor to the party; confirm calls ``then`` with the member's place."""
        if self.gm.party.members:
            self._picking = then

    def _order_first(self, index: int) -> None:
        """Remember the first member picked for Order, and pick again."""
        self._order_from = index
        self._picking = self._order_second

    def _order_second(self, index: int) -> None:
        """Swap the two picked members' places. The first three fight (D-196)."""
        members = self.gm.party.members
        first, self._order_from = self._order_from, None
        if first is not None and first != index:
            members[first], members[index] = members[index], members[first]

    def _open_tech(self, index: int) -> None:
        """Push a member's techniques and starting stance."""
        from core.scenes.loadout_scene import LoadoutScene  # local: cycle.

        self.gm.scene_stack.push(LoadoutScene(self.gm, self.gm.party.members[index]))

    def _open_equip(self, index: int) -> None:
        """Push a member's weapons to choose from."""
        from core.scenes.equip_scene import EquipScene  # local: cycle.

        self.gm.scene_stack.push(EquipScene(self.gm, self.gm.party.members[index]))

    def _open_status(self, index: int) -> None:
        """Push the party's stats, open on the chosen member."""
        from core.scenes.party_scene import PartyScene  # local: cycle.

        self.gm.scene_stack.push(PartyScene(self.gm, cursor=index))

    def _open_inventory(self) -> None:
        """Push the inventory list."""
        from core.scenes.inventory_scene import InventoryScene  # local: cycle.

        self.gm.scene_stack.push(InventoryScene(self.gm))

    def _open_bestiary(self) -> None:
        """Push the bestiary: a page per creature the party has beaten."""
        from core.scenes.bestiary_scene import BestiaryScene  # local: cycle.

        self.gm.scene_stack.push(BestiaryScene(self.gm))

    def _save(self) -> None:
        """Persist the current party to slot 1."""
        save.save(1, {"party": self.gm.party.to_dict()})

    def _resume(self) -> None:
        """Pop this overlay so the underlying scene resumes."""
        self.gm.scene_stack.pop()

    def _quit_to_title(self) -> None:
        """Ask first, then throw away the stack and go back to the title."""
        self.gm.scene_stack.push(ConfirmScene(
            self.gm, ConfirmSettings.TITLE_QUIT_TO_TITLE,
            ConfirmSettings.BODY_UNSAVED, on_yes=self.gm.return_to_title,
        ))

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Drive the commands, or the party cursor while a command waits on a member."""
        if self._picking is not None:
            count = len(self.gm.party.members)
            if input_map.is_cancel(event):
                self._picking = None
                self._order_from = None
                self.gm.audio.play("menu_move")
            elif input_map.is_up(event):
                self._member_cursor = (self._member_cursor - 1) % count
                self.gm.audio.play("menu_move")
            elif input_map.is_down(event):
                self._member_cursor = (self._member_cursor + 1) % count
                self.gm.audio.play("menu_move")
            elif input_map.is_confirm(event):
                then, self._picking = self._picking, None
                self.gm.audio.play("menu_select")
                then(self._member_cursor)
            return
        if input_map.is_up(event):
            if self.menu.move_up():
                self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            if self.menu.move_down():
                self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            if self.menu.confirm():
                self.gm.audio.play("menu_select")
        elif input_map.is_cancel(event):
            if self.menu.cancel():
                self.gm.audio.play("menu_select")

    def render(self, surface: pygame.Surface) -> None:
        """Dim the world, then draw the party, the commands and the money."""
        surface.blit(self._overlay, (0, 0))
        draw_window(surface, _PARTY_RECT)
        for index, member in enumerate(self.gm.party.members):
            self._render_member(surface, member, index)
        draw_window(surface, _COMMAND_RECT)
        self.menu.render(
            surface,
            (_COMMAND_RECT.left + UISettings.TEXT_BOX_PADDING + UISettings.MENU_LABEL_OFFSET,
             _COMMAND_RECT.top + 12),
            font_size=FontSettings.SIZE_BODY,
            row_height=UISettings.COMMAND_MENU_ROW_HEIGHT,
        )
        draw_window(surface, _MONEY_RECT)
        # The money: kupang, the coin, and pule, the shells, each by its
        # icon (D-476). The date joins them later.
        pad = UISettings.TEXT_BOX_PADDING
        for row, (icon_id, amount) in enumerate(
            (("kupang", self.gm.party.kupang), ("pule", self.gm.party.pule))
        ):
            y = _MONEY_RECT.top + pad + 6 + row * 22
            icon = load_element_icon(icon_id)
            if icon is not None:
                surface.blit(icon, (_MONEY_RECT.left + pad, y - 4))
            text = str(amount)
            text_renderer.draw_text(
                surface, text,
                (_MONEY_RECT.right - pad - text_renderer.text_width(text, FontSettings.SIZE_BODY), y),
                color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
            )

    def _render_member(
        self, surface: pygame.Surface, member: "PartyMember", index: int
    ) -> None:
        """One member: portrait, first name, HP, their elements with the stance boxed, any trouble.

        Those past the first three wait on the bench (D-196), their names
        in grey.
        """
        top = _ROW_TOP + index * _ROW_HEIGHT
        picking_here = self._picking is not None and index == self._member_cursor
        frame = pygame.Rect(_PORTRAIT_X, top, _PORTRAIT, _PORTRAIT)
        portrait = load_portrait(member.id)
        clip = surface.get_clip()
        surface.set_clip(frame)
        surface.blit(portrait, (
            frame.centerx - portrait.get_width() // 2,
            frame.centery - portrait.get_height() // 2,
        ))
        surface.set_clip(clip)
        benched = index >= BattleSettings.FIGHTERS
        if benched:
            # Bench members are dimmed, under a line: only three fight (D-196).
            shade = pygame.Surface(frame.size, pygame.SRCALPHA)
            shade.fill((0, 0, 0, 120))
            surface.blit(shade, frame.topleft)
            if index == BattleSettings.FIGHTERS:
                pygame.draw.line(
                    surface, ColorSettings.GRAY,
                    (_PARTY_RECT.left + 6, top - 4), (_PARTY_RECT.right - 7, top - 4),
                )
        chosen = picking_here or index == self._order_from
        pygame.draw.rect(
            surface, ColorSettings.YELLOW if chosen else ColorSettings.WHITE,
            frame.inflate(2, 2), 1,
        )
        if picking_here:
            tip = (_PORTRAIT_X - 4, top + _PORTRAIT // 2)
            pygame.draw.polygon(surface, ColorSettings.YELLOW, [
                tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 5, tip[1] + 5),
            ])
        size = FontSettings.SIZE_BODY
        down = member.current_hp <= 0
        name_color = (
            ColorSettings.RED if down
            else _BENCH_COLOR if benched else ColorSettings.WHITE
        )
        text_renderer.draw_text(
            surface, short_name(member.id), (_TEXT_X, top + 2),
            color=name_color, size=size,
        )
        text_renderer.draw_text(
            surface, "HP {1}/{2}".format(*stance_numbers(member)), (_TEXT_X, top + 18),
            color=ColorSettings.WHITE, size=size,
        )
        # The two elements as icons, the stance they start in boxed in
        # thick yellow (D-461).
        stance_element = None
        stances = by_id("characters").get(member.id, {}).get("stances", [])
        if stances:
            stance_element = stances[member.stance if 0 <= member.stance < len(stances) else 0]["element"]
        icon_y = top + 31
        for slot, element in enumerate(member.elements):
            icon = load_element_icon(element)
            x = _TEXT_X + 2 + slot * (UISettings.ELEMENT_ICON_SIZE + 8)
            if icon is not None:
                surface.blit(icon, (x, icon_y))
            if element == stance_element:
                pygame.draw.rect(
                    surface, ColorSettings.YELLOW,
                    pygame.Rect(x - 2, icon_y - 2,
                                UISettings.ELEMENT_ICON_SIZE + 4, UISettings.ELEMENT_ICON_SIZE + 4),
                    2, border_radius=2,
                )
        if down:
            text_renderer.draw_text(
                surface, "KO", (_PARTY_RECT.right - 26, top + 2),
                color=ColorSettings.RED, size=size,
            )
