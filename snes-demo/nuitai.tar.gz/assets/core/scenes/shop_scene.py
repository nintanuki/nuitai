"""The SHOP screen: a stall's stock, bought with pule (D-571).

Pushed by [core/scenes/overworld_scene.py](overworld_scene.py) when the
player faces a market stall and presses confirm. The stall's greeting
sits at the top, its stock in the middle with each price in pule, and
the party's pule and how many of the picked item they carry along the
bottom. Confirm buys one; a price the party cannot pay is a quiet bump.
Cancel walks away.

What a shop sells is in ``data/shops/<id>.json``. Prices are in pule,
since the fights are in the islands and the shells are the money there
(D-476, D-524).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from settings import ColorSettings, FontSettings, UISettings
from ui import input_map, text_renderer
from ui.window import draw_window
from utils.backgrounds import render_scene_background
from utils.graphics import load_element_icon

if TYPE_CHECKING:
    from main import GameManager


_HEADING_POSITION = (8, 8)
_GREETING_POSITION = (8, 28)
_LIST_TOP_Y = 56
_LIST_LEFT_X = 16
_LIST_ROW_HEIGHT = 16
_PRICE_RIGHT_X = 240

# Along the bottom: the party's pule, and how many of the picked item they carry.
_PURSE_RECT = pygame.Rect(0, 176, 256, 48)


class ShopScene(Scene):
    """A stall's stock; confirm buys one of the picked item."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", shop_id: str) -> None:
        """Bind this scene to the host game manager and one shop.

        Args:
            gm: The host game manager. ``gm.party`` pays and carries.
            shop_id: The shop's id in ``data/shops/``.
        """
        super().__init__(gm)
        self.shop = gm.data.load("shops")[shop_id]
        self._cursor = 0

    def _stock(self) -> list[dict]:
        """The stall's rows, in the order the shop file lists them."""
        return self.shop.get("stock", [])

    def _buy(self, row: dict) -> bool:
        """Buy one of ``row``'s item if the party can pay; say whether it did."""
        party = self.gm.party
        if party.pule < row["price"]:
            return False
        party.pule -= row["price"]
        party.inventory[row["item"]] = party.inventory.get(row["item"], 0) + 1
        return True

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move the cursor, buy, or walk away."""
        stock = self._stock()
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif stock and input_map.is_up(event):
            self._cursor = (self._cursor - 1) % len(stock)
            self.gm.audio.play("menu_move")
        elif stock and input_map.is_down(event):
            self._cursor = (self._cursor + 1) % len(stock)
            self.gm.audio.play("menu_move")
        elif stock and input_map.is_confirm(event):
            bought = self._buy(stock[self._cursor])
            self.gm.audio.play("menu_select" if bought else "menu_move")

    def render(self, surface: pygame.Surface) -> None:
        """Paint the name, the greeting, the stock with prices, and the purse.

        Args:
            surface: The screen surface to draw onto.
        """
        render_scene_background(self, surface)
        draw_window(surface, surface.get_rect())
        text_renderer.draw_text(
            surface, self.shop.get("name", "Shop"), _HEADING_POSITION,
            color=ColorSettings.WHITE, size=FontSettings.SIZE_HEADING,
        )
        text_renderer.draw_text(
            surface, self.shop.get("greeting", ""), _GREETING_POSITION,
            color=ColorSettings.GRAY, size=FontSettings.SIZE_BODY,
        )
        pule = self.gm.party.pule
        stock = self._stock()
        for index, row in enumerate(stock):
            y = _LIST_TOP_Y + index * _LIST_ROW_HEIGHT
            color = ColorSettings.WHITE if pule >= row["price"] else ColorSettings.GRAY
            text_renderer.draw_text(
                surface, row["item"], (_LIST_LEFT_X, y), color=color, size=FontSettings.SIZE_BODY,
            )
            _draw_pule(surface, row["price"], _PRICE_RIGHT_X, y, color)
            if index == self._cursor:
                _draw_pointer(surface, (_LIST_LEFT_X - 4, y + 3))
        self._render_purse(surface, stock)

    def _render_purse(self, surface: pygame.Surface, stock: list[dict]) -> None:
        """The party's pule, and how many of the picked item they already carry."""
        draw_window(surface, _PURSE_RECT)
        y = _PURSE_RECT.top + UISettings.TEXT_BOX_PADDING + 10
        if stock:
            item = stock[self._cursor]["item"]
            text_renderer.draw_text(
                surface, f"Have x{self.gm.party.inventory.get(item, 0)}",
                (_LIST_LEFT_X, y), color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
            )
        _draw_pule(surface, self.gm.party.pule, _PRICE_RIGHT_X, y, ColorSettings.WHITE)


def _draw_pule(surface: pygame.Surface, amount: int, right: int, y: int, color) -> None:
    """``amount`` right-aligned at ``right``, the shell icon before it (D-476)."""
    text = str(amount)
    left = right - text_renderer.text_width(text, FontSettings.SIZE_BODY)
    text_renderer.draw_text(surface, text, (left, y), color=color, size=FontSettings.SIZE_BODY)
    icon = load_element_icon("pule")
    if icon is not None:
        surface.blit(icon, (left - icon.get_width() - 4, y - 4))


def _draw_pointer(surface: pygame.Surface, tip: tuple[int, int]) -> None:
    """The yellow cursor arrow, pointing right at ``tip``."""
    pygame.draw.polygon(surface, ColorSettings.YELLOW, [
        tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 5, tip[1] + 5),
    ])
