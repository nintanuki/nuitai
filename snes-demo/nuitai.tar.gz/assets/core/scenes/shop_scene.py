"""The SHOP screen, Final Fantasy VI's (Frankie, 10/24; it was a big title, D-571).

Pushed by [core/scenes/overworld_scene.py](overworld_scene.py) when the
player faces a market stall and presses confirm. On top, the seller's
name and their line; under it Buy, Sell and Exit with the party's pule;
along the bottom the party's portraits, lit if they can use the item
under the cursor and faded if not, L1 and R1 sliding to the rest when
there are more than fit.

Buy lists the stall's stock with its prices (less while Maika is along,
his party passive), and at the right the pule, how many the party owns
and how many are worn. While buying, the seller's line box grows to two
lines and says what the item under the cursor does, as Final Fantasy
VI's help line does (Frankie, 10/24). Confirm asks how many, as the booklet
says and Final Fantasy VI does: up and down count one at a time, as many as
the pule pays for, the total under Owned; confirm buys them, cancel goes back
to the list (playtest, 10/28). A price the party cannot pay is a quiet bump. Sell lists the bag across the whole width (the longest
names need it), each with how many and what one fetches; what the demo
gives only once is gray with no price (``sell_price``), and so is what this
shop does not buy: each shop buys only its own kind (Frankie, 10/28), its
``buys`` in the shop file, the kinds ``sell_kind`` names. No shop buys a
meal. Cancel goes back to Buy, Sell and Exit, and from there walks away.

What a shop sells is in ``data/shops/<id>.json``: its ``seller``, its
``greeting``, and its rows. A row marked ``once`` (Kailo's lontar, the
Ananá relics) is sold only one time: bought, it is gone from the stall
for good (the party flag ``sold:<item>``). Prices are in pule, since the
fights are in the islands and the shells are the money there (D-476,
D-524). Rows are 12 pixels apart, as on the Equip screen.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core import lore
from core.data_loader import DataLoader
from core.equipment import can_hold, slot_of
from core.scene import Scene
from systems.passives import standing
from settings import ColorSettings, FontSettings, ItemSettings, ShopSettings, UISettings
from ui import input_map, text_renderer
from ui.element_tag import CELL
from ui.item_icon import item_icon
from ui.scroll_mark import draw_list_marks
from ui.text_box import TextBox
from ui.window import draw_window, help_wrap
from utils.backgrounds import render_scene_background
from utils.graphics import load_element_icon, load_portrait

if TYPE_CHECKING:
    from main import GameManager


SIZE = FontSettings.SIZE_BODY
ROW = 12
COMMANDS = ("Buy", "Sell", "Exit")
_COMMAND_X = (24, 72, 128)
_NAME_RECT = pygame.Rect(0, 0, 80, 24)
_LINE_RECT = pygame.Rect(80, 0, 176, 24)
_COMMAND_RECT = pygame.Rect(0, 24, 168, 24)
_MONEY_RECT = pygame.Rect(168, 24, 88, 24)
_EMPTY_RECT = pygame.Rect(0, 48, 256, 120)
# Walking up, the top two boxes are a line taller too, for a greeting in two lines ("E komo mai!" and the keeper's own question).
_TALK_NAME_RECT = pygame.Rect(0, 0, 80, 32)
_TALK_LINE_RECT = pygame.Rect(80, 0, 176, 32)
_TALK_COMMAND_RECT = pygame.Rect(0, 32, 168, 24)
_TALK_MONEY_RECT = pygame.Rect(168, 32, 88, 24)
_TALK_EMPTY_RECT = pygame.Rect(0, 56, 256, 112)
_LIST_RECT = pygame.Rect(0, 24, 256, 144)
_PARTY_RECT = pygame.Rect(0, 168, 256, 56)
_ROWS_TOP = 36
# Buying, the top two boxes are a line taller for the help's second line, and the list starts lower.
_BUY_NAME_RECT = pygame.Rect(0, 0, 80, 32)
_BUY_LINE_RECT = pygame.Rect(80, 0, 176, 32)
_BUY_LIST_RECT = pygame.Rect(0, 32, 256, 136)
_BUY_ROWS_TOP = 44
_HELP_X = 88                 # The help's words, on the 8 pixel grid for the cartridge; lines a row apart.
_HELP_WIDTH = 160
_ITEM_X = 32                 # Room for the fishhook cursor (11/2). A name; its icon a letter before.
_BUY_PRICE_RIGHT = 160
_PANEL_X = 176               # Buy's right side: the pule, Owned and Equipped.
_RIGHT = 248
_SELL_COUNT_RIGHT = 208
_BUY_ROWS = 10
_SELL_ROWS = 10
_BUY_MARK_X = 168            # The scroll arrows: past Buy's prices (Frankie, 10/24),
_SELL_MARK_X = 216           # and in Sell between the count and the price, past the longest name.
_PORTRAITS = 4               # Faces that fit along the bottom.
_PORTRAIT_X, _PORTRAIT_STEP, _PORTRAIT_Y = 12, 60, 172

# The cartridge still draws the old layout from these (snes/tools/make_art.py) until it catches
# up with this one (the TODO's shop item); nothing in pygame uses them.
_HEADING_POSITION = (8, 8)
_GREETING_POSITION = (8, 28)
_LIST_TOP_Y = 56
_LIST_LEFT_X = 24  # Room for the fishhook cursor (11/2).
_PRICE_RIGHT_X = 240
_PURSE_RECT = pygame.Rect(0, 176, 256, 48)


class ShopScene(Scene):
    """A stall: buy from its stock or sell from the bag."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", shop_id: str) -> None:
        """Bind this scene to the host game manager and one shop.

        Args:
            gm: The host game manager. ``gm.party`` pays and carries.
            shop_id: The shop's id in ``data/shops/``.
        """
        super().__init__(gm)
        self.shop = gm.data.load("shops")[shop_id]
        self.state = "command"     # "command", "buy" or "sell".
        self._count = 0            # How many to buy while choosing; 0 while not.
        self._command = 0
        self._cursor = 0
        self._first_face = 0
        self.text_box = TextBox()  # a talk over the shop: Kailo's hint, the haggling

    def _stock(self) -> list[dict]:
        """The stall's rows, in the order the shop file lists them, without what was sold once."""
        return [row for row in self.shop.get("stock", []) if not sold_out(self.gm.party, row)]

    def _bag(self) -> list[str]:
        """What the party carries, by name, for selling."""
        return sorted((item for item, count in self.gm.party.inventory.items() if count > 0), key=item_name)

    def _rows(self) -> list:
        return self._stock() if self.state == "buy" else self._bag()

    def price(self, row: dict) -> int:
        """What ``row`` costs this party: less while Maika is with them (his party passive)."""
        return row_price(self.gm.party, row)

    def most(self, row: dict) -> int:
        """How many of ``row`` the party could buy now: what the pule pays for, one of a ``once`` row."""
        can = self.gm.party.pule // self.price(row)
        return min(can, 1 if row.get("once") else ShopSettings.MOST_AT_ONCE)

    def _buy(self, row: dict, count: int = 1) -> bool:
        """Buy ``count`` of ``row``'s item if the party can pay; say whether it did."""
        party = self.gm.party
        if count < 1 or party.pule < self.price(row) * count:
            return False
        party.pule -= self.price(row) * count
        party.inventory[row["item"]] = party.inventory.get(row["item"], 0) + count
        if row.get("once"):
            party.flags[f"sold:{row['item']}"] = True
            self._cursor = min(self._cursor, max(0, len(self._stock()) - 1))
        return True

    def _talk(self, lines) -> None:
        """Play ``lines`` (speaker, text) in the text box; the list waits until they are read."""
        for speaker, text in lines:
            self.text_box.push(text, speaker=speaker)

    def _on_row(self) -> None:
        """The cursor is on a row (Frankie, 10/30): soy sauce talks the first time it is.

        Without Maika Kailo says he cannot pay it; with him along he and the
        grocer haggle, once, and the price drops to the row's ``talked_price``.
        """
        party = self.gm.party
        rows = self._rows() if self.state == "buy" else []
        if not rows or rows[min(self._cursor, len(rows) - 1)].get("talks_down") is None:
            return
        row = rows[min(self._cursor, len(rows) - 1)]
        if standing(party, row["talks_down"]):
            if not party.flags.get(ShopSettings.SOY_HAGGLE_FLAG):
                party.flags[ShopSettings.SOY_HAGGLE_FLAG] = True
                self._talk(ShopSettings.SOY_HAGGLE)
        elif not party.flags.get(ShopSettings.SOY_HINT_FLAG):
            party.flags[ShopSettings.SOY_HINT_FLAG] = True
            self._talk(ShopSettings.SOY_HINT)

    def _highlighted(self) -> str | None:
        """The item under the cursor, in the Buy or Sell list."""
        rows = self._rows() if self.state != "command" else []
        if not rows:
            return None
        row = rows[min(self._cursor, len(rows) - 1)]
        return row["item"] if isinstance(row, dict) else row

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Pick Buy, Sell or Exit; in a list, move, buy or sell, or go back."""
        if not self.text_box.is_done():
            if input_map.is_confirm(event):
                self.text_box.advance()
            return
        if input_map.is_l1(event) or input_map.is_r1(event):
            last = max(0, len(self.gm.party.members) - _PORTRAITS)
            step = -1 if input_map.is_l1(event) else 1
            if 0 <= self._first_face + step <= last:
                self._first_face += step
                self.gm.audio.play("menu_move")
        elif self.state == "command":
            self._handle_command(event)
        else:
            self._handle_list(event)

    def _handle_command(self, event: pygame.event.Event) -> None:
        if input_map.is_left(event) or input_map.is_right(event):
            step = -1 if input_map.is_left(event) else 1
            self._command = (self._command + step) % len(COMMANDS)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            self.gm.audio.play("menu_select")
            if COMMANDS[self._command] == "Exit":
                self.gm.scene_stack.pop()
            else:
                self.state, self._cursor = COMMANDS[self._command].lower(), 0
                if self.state == "buy":
                    lore.hear(self.gm.party, ShopSettings.BUY_LINE)
                    self._on_row()
        elif input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()

    def _handle_list(self, event: pygame.event.Event) -> None:
        rows = self._rows()
        if self._count:
            self._handle_count(event, rows[min(self._cursor, len(rows) - 1)])
            return
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.state = "command"
        elif rows and (input_map.is_up(event) or input_map.is_down(event)):
            step = -1 if input_map.is_up(event) else 1
            self._cursor = (self._cursor + step) % len(rows)
            self.gm.audio.play("menu_move")
            self._on_row()
        elif rows and input_map.is_confirm(event):
            row = rows[min(self._cursor, len(rows) - 1)]
            if self.state == "buy":
                done = self.most(row) > 0
                self._count = 1 if done else 0
            else:
                done = sell(self.gm.party, row, self.shop)
                self._cursor = min(self._cursor, max(0, len(self._bag()) - 1))
            self.gm.audio.play("menu_select" if done else "menu_move")

    def _handle_count(self, event: pygame.event.Event, row: dict) -> None:
        """Choosing how many: up and down count, confirm buys them, cancel goes back to the list."""
        if input_map.is_cancel(event):
            self._count = 0
            self.gm.audio.play("menu_move")
        elif input_map.is_up(event) or input_map.is_down(event):
            count = self._count + (1 if input_map.is_up(event) else -1)
            if 1 <= count <= self.most(row):
                self._count = count
                self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            self._buy(row, self._count)
            self._count = 0
            self.gm.audio.play("menu_select")

    def update(self, dt: float) -> None:
        """Type out a talk."""
        self.text_box.update(dt)

    def render(self, surface: pygame.Surface) -> None:
        """The seller and their line, then Buy, Sell and Exit or a list, then the party."""
        render_scene_background(self, surface)
        surface.fill(ColorSettings.BLACK)
        lines = {"command": self.shop.get("greeting", ""), "buy": ShopSettings.BUY_LINE, "sell": ShopSettings.SELL_LINE}
        buying = self.state == "buy"
        talking = self.state == "command"
        draw_window(surface, _BUY_NAME_RECT if buying else _TALK_NAME_RECT if talking else _NAME_RECT)
        _text(surface, self.shop.get("seller", ""), _NAME_RECT.x + 12, 8, ColorSettings.LABEL_CYAN)
        draw_window(surface, _BUY_LINE_RECT if buying else _TALK_LINE_RECT if talking else _LINE_RECT)
        helps = shop_help(self._highlighted()) if buying else help_wrap(lines["command"], _HELP_WIDTH) if talking else []
        for row, words in enumerate(helps):
            _text(surface, words, _HELP_X, 8 + row * ROW)
        if not helps:
            _text(surface, lines[self.state], _LINE_RECT.x + 12, 8)
        if self.state == "command":
            draw_window(surface, _TALK_COMMAND_RECT)
            for x, word in zip(_COMMAND_X, COMMANDS):
                _text(surface, word, x, 40)
            _draw_pointer(surface, (_COMMAND_X[self._command] - 4, 40 + 3))
            draw_window(surface, _TALK_MONEY_RECT)
            _draw_pule(surface, self.gm.party.pule, _RIGHT, 40, ColorSettings.WHITE)
            draw_window(surface, _TALK_EMPTY_RECT)
        elif self.state == "buy":
            self._render_buy(surface)
        else:
            self._render_sell(surface)
        self._render_party(surface)
        if not self.text_box.is_done():
            self.text_box.render(surface)

    def _first_row(self, shown: int) -> int:
        return max(0, self._cursor - shown + 1)

    def _render_buy(self, surface: pygame.Surface) -> None:
        """The stock and prices at the left; the pule, Owned and Equipped at the right."""
        draw_window(surface, _BUY_LIST_RECT)
        stock = self._stock()
        first = self._first_row(_BUY_ROWS)
        for index, row in enumerate(stock[first:first + _BUY_ROWS], start=first):
            y = _BUY_ROWS_TOP + (index - first) * ROW
            color = ColorSettings.WHITE if self.gm.party.pule >= self.price(row) else ColorSettings.GRAY
            draw_item_name(surface, row["item"], _ITEM_X - CELL, y, color)
            _text(surface, str(self.price(row)), _BUY_PRICE_RIGHT, y, color, right=True)
            if index == self._cursor:
                _draw_pointer(surface, (_ITEM_X - CELL - 4, y + 3))
        draw_list_marks(surface, _BUY_MARK_X, _BUY_ROWS_TOP, ROW, first, _BUY_ROWS, len(stock))
        _draw_pule(surface, self.gm.party.pule, _RIGHT, _BUY_ROWS_TOP, ColorSettings.WHITE)
        item = self._highlighted()
        if item is None:
            return
        _text(surface, "Owned", _PANEL_X, _BUY_ROWS_TOP + 2 * ROW, ColorSettings.LABEL_CYAN)
        _text(surface, str(self.gm.party.inventory.get(item, 0)), _RIGHT, _BUY_ROWS_TOP + 3 * ROW, right=True)
        slot = slot_of(item)
        if slot:
            worn = sum(getattr(member, slot) == item for member in self.gm.party.members)
            _text(surface, "Equipped", _PANEL_X, _BUY_ROWS_TOP + 4 * ROW, ColorSettings.LABEL_CYAN)
            _text(surface, str(worn), _RIGHT, _BUY_ROWS_TOP + 5 * ROW, right=True)
        if self._count:
            row = self._stock()[min(self._cursor, len(self._stock()) - 1)]
            _text(surface, "How many", _PANEL_X, _BUY_ROWS_TOP + 7 * ROW, ColorSettings.LABEL_CYAN)
            _text(surface, f"x{self._count}", _PANEL_X, _BUY_ROWS_TOP + 8 * ROW, ColorSettings.YELLOW)
            _draw_pule(surface, self.price(row) * self._count, _RIGHT, _BUY_ROWS_TOP + 9 * ROW, ColorSettings.WHITE)

    def _render_sell(self, surface: pygame.Surface) -> None:
        """The bag across the whole width: name, how many, what one fetches; the pule at the bottom."""
        draw_window(surface, _LIST_RECT)
        bag = self._bag()
        first = self._first_row(_SELL_ROWS)
        for index, item in enumerate(bag[first:first + _SELL_ROWS], start=first):
            y = _ROWS_TOP + (index - first) * ROW
            price = sell_price(item, self.shop)
            color = ColorSettings.WHITE if price is not None else ColorSettings.GRAY
            draw_item_name(surface, item, _ITEM_X - CELL, y, color)
            _text(surface, f"x{self.gm.party.inventory[item]}", _SELL_COUNT_RIGHT, y, color, right=True)
            _text(surface, str(price) if price is not None else "-", _RIGHT, y, color, right=True)
            if index == self._cursor:
                _draw_pointer(surface, (_ITEM_X - CELL - 4, y + 3))
        draw_list_marks(surface, _SELL_MARK_X, _ROWS_TOP, ROW, first, _SELL_ROWS, len(bag))
        _draw_pule(surface, self.gm.party.pule, _RIGHT, _LIST_RECT.bottom - 16, ColorSettings.WHITE)

    def _render_party(self, surface: pygame.Surface) -> None:
        """The faces along the bottom: lit if they can use the item under the cursor, faded if not."""
        draw_window(surface, _PARTY_RECT)
        item = self._highlighted()
        members = self.gm.party.members
        for slot, member in enumerate(members[self._first_face:self._first_face + _PORTRAITS]):
            x = _PORTRAIT_X + slot * _PORTRAIT_STEP
            surface.blit(load_portrait(member.id), (x, _PORTRAIT_Y))
            if item is not None and slot_of(item) and not can_hold(member.id, item):
                shade = pygame.Surface((UISettings.PORTRAIT_SIZE, UISettings.PORTRAIT_SIZE), pygame.SRCALPHA)
                shade.fill((0, 0, 0, 150))
                surface.blit(shade, (x, _PORTRAIT_Y))
        # More along the row than fit: small arrows at the ends, L1 and R1 slide.
        if self._first_face > 0:
            pygame.draw.polygon(surface, ColorSettings.WHITE, [(4, 196), (8, 192), (8, 200)])
        if self._first_face + _PORTRAITS < len(members):
            pygame.draw.polygon(surface, ColorSettings.WHITE, [(252, 196), (248, 192), (248, 200)])


def _text(surface: pygame.Surface, words: str, x: int, y: int,
          color=ColorSettings.WHITE, right: bool = False) -> None:
    """Words at ``x``, or ending at ``x`` when ``right``."""
    if right:
        x -= text_renderer.text_width(words, SIZE)
    text_renderer.draw_text(surface, words, (x, y), color=color, size=SIZE)


def shop_help(item_id: str | None) -> list[str]:
    """What ``item_id`` does, wrapped to the seller's line box: two lines, the Items screen's words."""
    from core.scenes.inventory_scene import item_help

    if not item_id:
        return []
    short = _weapon_trade(item_id)
    if short:
        # The seller's box is narrow, so "Raises Willpower but lowers Vitality." never fit
        # after the English word and the shop said only "Fan." (Frankie, 11/3, Mark's playtest).
        return help_wrap(short, _HELP_WIDTH)
    return help_wrap(item_help(item_id), _HELP_WIDTH)


def _weapon_trade(item_id: str) -> str:
    """A weapon's English word and its trade in the fewest words, "Fan. Willpower up, Vitality down."; else ""."""
    from core.equipment import with_english
    from core.shared import by_id
    from core.stats import STAT_NAMES

    weapon = by_id("weapons").get(item_id)
    if not weapon:
        return ""
    up, down = STAT_NAMES.get(weapon.get("benefit", "")), STAT_NAMES.get(weapon.get("penalty", ""))
    trade = ", ".join(filter(None, [f"{up} up" if up else "", f"{down} down" if down else ""]))
    return with_english(item_id, f"{trade}.") if trade else ""


def item_name(item_id: str) -> str:
    """What an item is called in the bag and the shops (``ItemSettings.NAMES``)."""
    return ItemSettings.NAMES.get(item_id, item_id)


def draw_item_name(surface: pygame.Surface, item_id: str, x: int, y: int, color) -> None:
    """``item_id``'s icon in the letter space at ``x``, its name after it (Frankie, 10/24)."""
    icon = item_icon(item_id)
    if icon is not None:
        surface.blit(icon, (x, y))
    text_renderer.draw_text(surface, item_name(item_id), (x + CELL, y), color=color, size=FontSettings.SIZE_BODY)


_SHOPS = DataLoader()


def sell_kind(item_id: str) -> str:
    """Which kind of thing ``item_id`` is to a buyer (Frankie, 10/28): "weapon", "relic",
    "loot" (what monsters drop), "meal", "medicine", "ingredient" (fish among them),
    "lontar", or "goods" for the rest (seeds, a Seer's Shell)."""
    from core.shared import by_id
    from ui.item_icon import FOOD, MEDICINE

    if item_id in ItemSettings.SHELLS:
        return "lontar"
    if item_id in by_id("weapons"):
        return "weapon"
    if item_id in by_id("relics"):
        return "relic"
    if item_id in ItemSettings.LOOT:
        return "loot"
    if item_id in FOOD:
        return "meal"
    if item_id in MEDICINE:
        return "medicine"
    if item_id in ItemSettings.INGREDIENTS or item_id in ItemSettings.FISH or item_id == ItemSettings.WATER:
        return "ingredient"
    return "goods"


def buys(shop: dict | None, item_id: str) -> bool:
    """Whether ``shop`` buys ``item_id``: only its own kind (its ``buys``), never a meal."""
    if sell_kind(item_id) == "meal":
        return False
    return shop is None or "buys" not in shop or sell_kind(item_id) in shop["buys"]


def sell_price(item_id: str, shop: dict | None = None) -> int | None:
    """What a shop pays for one ``item_id`` (Frankie, 10/24), or None when it cannot be sold.

    Anything the demo gives again sells: a shop's item for a share of its
    lowest price, a seed or a dropped weapon or relic for its own price. A
    row sold ``once``, the starting gear, a chest's item and a meal never do,
    and with ``shop`` given, only what that shop buys (``buys``).
    """
    from settings import ShopSettings

    if not buys(shop, item_id) or item_id in ItemSettings.KEY_ITEMS:  # a key item is never sold
        return None

    rows = [row for shop in _SHOPS.load("shops").values() for row in shop["stock"] if row["item"] == item_id]
    if any(row.get("once") or row.get("talks_down") for row in rows):  # soy sauce is no one's to resell
        return None
    if rows:
        return int(min(row["price"] for row in rows) * ShopSettings.SELL_SHARE)
    return ShopSettings.SELL_PRICES.get(item_id)


def sell(party, item_id: str, shop: dict | None = None) -> bool:
    """Sell one ``item_id`` from the bag, to ``shop`` if given; say whether it was sold."""
    price = sell_price(item_id, shop)
    if price is None or party.inventory.get(item_id, 0) < 1:
        return False
    party.inventory[item_id] -= 1
    if party.inventory[item_id] <= 0:
        del party.inventory[item_id]
    party.pule += price
    return True


def sold_out(party, row: dict) -> bool:
    """Whether ``row`` is sold only once and already was."""
    return bool(row.get("once")) and bool(party.flags.get(f"sold:{row['item']}"))


def shop_price(party, price: int) -> int:
    """A price in pule, less while Maika is in the party and standing (ShopSettings.CHARM_DISCOUNT)."""
    from settings import ShopSettings
    from systems.passives import standing

    if not standing(party, "maika"):
        return price
    return max(1, round(price * (1 - ShopSettings.CHARM_DISCOUNT)))


def row_price(party, row: dict) -> int:
    """What a stall row costs this party.

    A row with ``talks_down`` (soy sauce, Frankie 10/30) has a scripted price:
    its own ``price`` (1000, more than the purse holds) until that member is
    standing in the party and the haggle has been played, then its
    ``talked_price`` (500), charm discount or not.
    """
    member = row.get("talks_down")
    if member is None:
        return shop_price(party, row["price"])
    haggled = party.flags.get(ShopSettings.SOY_HAGGLE_FLAG) and standing(party, member)
    return row["talked_price"] if haggled else row["price"]


def _draw_pule(surface: pygame.Surface, amount: int, right: int, y: int, color) -> None:
    """``amount`` right-aligned at ``right``, the shell icon before it (D-476)."""
    text = str(amount)
    left = right - text_renderer.text_width(text, FontSettings.SIZE_BODY)
    text_renderer.draw_text(surface, text, (left, y), color=color, size=FontSettings.SIZE_BODY)
    icon = load_element_icon("pule")
    if icon is not None:
        surface.blit(icon, (left - icon.get_width() - 4, y - 4))


def _draw_pointer(surface: pygame.Surface, tip: tuple[int, int]) -> None:
    """The cursor, the fishhook, at ``tip``."""
    text_renderer.draw_pointer(surface, tip)
