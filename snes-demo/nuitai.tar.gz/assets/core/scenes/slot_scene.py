"""Element slot unlocked (Frankie, 11/1): the party's element grid, the new slot flashing.

A boss won opens a slot for the whole party. The victory screen, once it is read,
shows this: the words ``LoadoutSettings.OPENED`` over the grid of open slots, one
row of boxes per mana row, empty ones grey, and the newly opened ones flashing.
A press closes it and goes on to ``then``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

import pygame

from core.scene import Scene
from settings import ColorSettings, FontSettings, LoadoutSettings, ScreenSettings, UISettings
from ui import input_map, text_renderer
from ui.text_box import draw_continue_marker
from ui.window import draw_window

if TYPE_CHECKING:
    from main import GameManager

_BOX_W, _BOX_H, _BOX_GAP = 22, 10, 4
_ROW_H = 16
_LABEL_W = 14
_EMPTY = (120, 124, 132)
_EDGE = (200, 208, 230)
_FLASH = (ColorSettings.YELLOW, (255, 255, 255))
_FLASH_MS = 220


class SlotUnlockScene(Scene):
    """The grid of open slots with the new ones flashing; any confirm closes it."""

    OPAQUE = False

    def __init__(self, gm: "GameManager", slots: list[int], gained: list[int],
                 then: Callable[[], None]) -> None:
        """``slots`` is how many are open in each row now, ``gained`` how many of those are new."""
        super().__init__(gm)
        self.slots = slots
        self.gained = gained
        self.then = then
        self._age = 0.0

    def on_enter(self) -> None:
        self.gm.audio.play("learned")

    def update(self, dt: float) -> None:
        self._age += dt

    def handle_event(self, event: pygame.event.Event) -> None:
        """Confirm closes it, once it has been seen for a moment."""
        if input_map.is_confirm(event) and self._age > 0.4:
            self.gm.scene_stack.pop()
            self.then()

    def _rows(self) -> list[int]:
        return [row for row in range(1, LoadoutSettings.ROWS + 1) if self.slots[row - 1] > 0]

    def render(self, surface: pygame.Surface) -> None:
        rows = self._rows()
        size = FontSettings.SIZE_BODY
        grid = _LABEL_W + LoadoutSettings.PER_ROW * (_BOX_W + _BOX_GAP)
        width = 2 * UISettings.TEXT_BOX_PADDING + max(grid, text_renderer.text_width(LoadoutSettings.OPENED, size))
        height = 2 * UISettings.TEXT_BOX_PADDING + 22 + len(rows) * _ROW_H + 8
        rect = pygame.Rect((ScreenSettings.WIDTH - width) // 2, (surface.get_height() - height) // 2, width, height)
        draw_window(surface, rect)
        title = LoadoutSettings.OPENED
        text_renderer.draw_text(surface, title, (rect.centerx - text_renderer.text_width(title, size) // 2,
                                                 rect.top + UISettings.TEXT_BOX_PADDING),
                                color=ColorSettings.YELLOW, size=size)
        lit = (pygame.time.get_ticks() // _FLASH_MS) % 2
        top = rect.top + UISettings.TEXT_BOX_PADDING + 22
        for line, row in enumerate(rows):
            y = top + line * _ROW_H
            text_renderer.draw_text(surface, str(row), (rect.centerx - grid // 2, y - 2),
                                    color=ColorSettings.GRAY, size=size)
            for col in range(self.slots[row - 1]):
                box = pygame.Rect(rect.centerx - grid // 2 + _LABEL_W + col * (_BOX_W + _BOX_GAP),
                                  y, _BOX_W, _BOX_H)
                fresh = col >= self.slots[row - 1] - self.gained[row - 1]
                pygame.draw.rect(surface, _FLASH[lit] if fresh else _EMPTY, box)
                pygame.draw.rect(surface, _EDGE, box, 1)
        draw_continue_marker(surface, (rect.right - UISettings.TEXT_BOX_PADDING, rect.bottom - 4))
