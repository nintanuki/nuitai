"""A NO / YES question drawn over whatever is running.

One scene serves every "are you sure?" in the game: a nap, the save
point, saving over or deleting a slot, and running away from a fight.
There is no quit box (Frankie, 10/23). It follows Dungeon Digger, the arcade
cabinet game with saves (Frankie, 10/9): NO is selected first, cancel
means NO, and Esc does nothing while the box is up, so a second press
or a hasty Enter never throws progress away.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable, Optional

import pygame

from core.scene import Scene
from settings import (
    ColorSettings,
    ConfirmSettings,
    FontSettings,
    ScreenSettings,
    UISettings,
)
from ui import input_map, text_renderer
from ui.window import draw_window

if TYPE_CHECKING:
    from main import GameManager


class ConfirmScene(Scene):
    """A modal NO / YES box. Pops itself, then runs the chosen callback."""

    OPAQUE = False  # The scene underneath stays visible, dimmed.

    def __init__(
        self,
        gm: "GameManager",
        title: str,
        body: str = "",
        on_yes: Optional[Callable[[], None]] = None,
        on_no: Optional[Callable[[], None]] = None,
    ) -> None:
        """Build the box.

        Args:
            gm: The host game manager.
            title: The question, e.g. "Save your game?".
            body: An optional line under it saying what is lost.
            on_yes: Called after the box has popped, if YES is chosen.
            on_no: Called after the box has popped, if NO is chosen.
        """
        super().__init__(gm)
        self.title = title
        self.body = body
        self.on_yes = on_yes
        self.on_no = on_no
        self.cursor = ConfirmSettings.NO_INDEX
        # Cached so the dimming layer is not rebuilt every frame.
        self._overlay = pygame.Surface(ScreenSettings.RESOLUTION).convert_alpha()
        self._overlay.fill((0, 0, 0, ConfirmSettings.DIM_ALPHA))

    # ------------------------------------------------------------------
    # CHOICE
    # ------------------------------------------------------------------

    def _choose(self, index: int) -> None:
        """Leave the box and run the callback for ``index``.

        The pop comes first so a callback that rebuilds the stack (quit
        to title) or ends the program finds this box already gone.
        """
        self.gm.audio.play("menu_select")
        self.gm.scene_stack.pop()
        callback = self.on_yes if index == ConfirmSettings.YES_INDEX else self.on_no
        if callback is not None:
            callback()

    def _set_cursor(self, index: int) -> None:
        """Move the cursor to ``index``, with a sound only when it moves.

        Directions set the cursor outright instead of toggling it, so
        a held analog stick, which sends an event every frame, cannot
        flip the answer back and forth.
        """
        if index != self.cursor:
            self.cursor = index
            self.gm.audio.play("menu_move")

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Left or up means NO, right or down means YES; confirm picks.

        Cancel answers NO, as B does on the cartridge. Esc is
        not listed on purpose: while the box is up it does nothing.
        """
        if input_map.is_confirm(event):
            self._choose(self.cursor)
        elif input_map.is_cancel(event):
            self._choose(ConfirmSettings.NO_INDEX)
        elif input_map.is_left(event) or input_map.is_up(event):
            self._set_cursor(ConfirmSettings.NO_INDEX)
        elif input_map.is_right(event) or input_map.is_down(event):
            self._set_cursor(ConfirmSettings.YES_INDEX)

    def render(self, surface: pygame.Surface) -> None:
        """Dim the scene below, then draw the box in the middle."""
        surface.blit(self._overlay, (0, 0))

        row_height = text_renderer.line_height(FontSettings.SIZE_BODY)
        # The box is as tall as its rows: the question, the warning
        # wrapped to the box when there is one, and the NO / YES row.
        font = text_renderer.get_font(FontSettings.SIZE_BODY)
        inner = ConfirmSettings.BOX_WIDTH - 2 * ConfirmSettings.PADDING
        title_rows = text_renderer.wrap(self.title, font, inner)
        body_rows = (
            text_renderer.wrap(
                self.body,
                text_renderer.get_font(FontSettings.SIZE_BODY),
                ConfirmSettings.BOX_WIDTH - 2 * ConfirmSettings.PADDING,
            )
            if self.body else []
        )
        height = ConfirmSettings.PADDING * 2 + row_height * (1 + len(title_rows) + len(body_rows))
        box = pygame.Rect(0, 0, ConfirmSettings.BOX_WIDTH, height)
        box.center = (ScreenSettings.WIDTH // 2, ScreenSettings.HEIGHT // 2)
        draw_window(surface, box, thickness=ConfirmSettings.BORDER_THICKNESS)

        y = box.top + ConfirmSettings.PADDING
        for line in title_rows:
            self._draw_centered(
                surface, line, box.centerx, y,
                ColorSettings.WHITE, FontSettings.SIZE_BODY,
            )
            y += row_height
        for line in body_rows:
            self._draw_centered(
                surface, line, box.centerx, y,
                ConfirmSettings.COLOR_WARNING, FontSettings.SIZE_BODY,
            )
            y += row_height

        labels = (ConfirmSettings.LABEL_NO, ConfirmSettings.LABEL_YES)
        for index, label in enumerate(labels):
            selected = index == self.cursor
            color = ColorSettings.YELLOW if selected else ColorSettings.WHITE
            center_x = (
                box.centerx - ConfirmSettings.OPTION_GAP // 2
                + index * ConfirmSettings.OPTION_GAP
            )
            left = self._draw_centered(
                surface, label, center_x, y, color, FontSettings.SIZE_BODY,
            )
            if selected:
                text_renderer.draw_pointer(
                    surface,
                    (left - UISettings.MENU_LABEL_OFFSET, y + FontSettings.SIZE_BODY // 2),
                    ColorSettings.YELLOW,
                )

    @staticmethod
    def _draw_centered(
        surface: pygame.Surface,
        text: str,
        center_x: int,
        y: int,
        color: tuple[int, int, int],
        size: int,
    ) -> int:
        """Draw one line centred on ``center_x``; return its left edge."""
        width = text_renderer.text_width(text, size)
        left = center_x - width // 2
        text_renderer.draw_text(surface, text, (left, y), color, size=size)
        return left
