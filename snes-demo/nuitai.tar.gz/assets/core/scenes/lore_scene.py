"""Lore, under Data: the list of pages found, and one page at a time (Frankie, 10/23).

The pages and when each unlocks are ``core/lore.py``'s, from
``game/shared/lore.md``. Each of Data's lore rows opens it on one category
(Frankie, 10/25): the list is Data's layout, a box saying the category and
the help line, with the titles in two columns; confirm opens a page. A
page is one window, as the bestiary's: the title and the page count on
top, the words under them, scrolling when they are longer than the
window. Left and right turn the page; cancel goes back to the list.

The cartridge draws both from the numbers here (``tools/make_art.py``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core import lore
from core.scene import Scene
from settings import ColorSettings, FontSettings, UISettings
from ui import input_map, text_renderer
from ui.scroll_mark import draw_scroll_mark
from ui.window import draw_header, draw_window
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager

# The list: two columns of titles, on the 8 pixel grid.
_LIST_TOP_Y = UISettings.HEADER_LIST_TOP
_COLUMN_X = (16, 136)
_ROW_HEIGHT = 16
LIST_ROWS = 9
# A page: the title and count on the top row, the words below.
_NAME_POS = (8, 8)
_COUNT_RIGHT_X = 248
PANEL_X = 8
PANEL_WIDTH = 240          # 30 letters.
TEXT_TOP_Y = 32
TEXT_ROWS = 11
_SCROLL_MARK_X = 248
COLOR_BODY_TEXT = (215, 215, 215)


def page_lines(page: dict[str, str]) -> list[str]:
    """The page's words, wrapped to the window: the cartridge cuts them the same way."""
    font = text_renderer.get_font(FontSettings.SIZE_BODY)
    return text_renderer.wrap(page["text"], font, PANEL_WIDTH)


def help_line(found: int, category: str | None = None) -> str:
    """The list's help line: how many of the category's pages have been found."""
    total = len(lore.in_category(category)) if category else len(lore.PAGES)
    return f"{found} of {total} pages found."


class LoreScene(Scene):
    """The list of pages found; confirm opens one."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", category: str | None = None) -> None:
        super().__init__(gm)
        self.category = category
        self.pages = lore.unlocked(gm.party, category)
        self.cursor = 0
        self.reading = False
        self.scroll = 0

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move in the list or open a page; on a page, turn it, scroll it or go back."""
        count = len(self.pages)
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            if self.reading:
                self.reading = False
            else:
                self.gm.scene_stack.pop()
        elif not count:
            return
        elif self.reading:
            if input_map.is_left(event) or input_map.is_right(event):
                self.cursor = (self.cursor + (-1 if input_map.is_left(event) else 1)) % count
                self.scroll = 0
                self.gm.audio.play("menu_move")
            elif input_map.is_up(event) and self.scroll > 0:
                self.scroll -= 1
                self.gm.audio.play("menu_move")
            elif input_map.is_down(event) and self.scroll + TEXT_ROWS < len(page_lines(self.pages[self.cursor])):
                self.scroll += 1
                self.gm.audio.play("menu_move")
        elif input_map.is_up(event) or input_map.is_down(event):
            self.cursor = (self.cursor + (-1 if input_map.is_up(event) else 1)) % count
            self.gm.audio.play("menu_move")
        elif input_map.is_left(event) or input_map.is_right(event):
            # Across to the other column, on the same row when it has one.
            other = (self.cursor + LIST_ROWS) % (2 * LIST_ROWS)
            if other < count:
                self.cursor = other
                self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            self.reading = True
            self.scroll = 0
            self.gm.audio.play("menu_select")

    def render(self, surface: pygame.Surface) -> None:
        render_scene_background(self, surface)
        if self.reading:
            self._render_page(surface)
            return
        draw_header(surface, self.category or "Lore", [help_line(len(self.pages), self.category)])
        size = FontSettings.SIZE_BODY
        for index, page in enumerate(self.pages):
            x = _COLUMN_X[index // LIST_ROWS]
            y = _LIST_TOP_Y + (index % LIST_ROWS) * _ROW_HEIGHT
            text_renderer.draw_text(surface, page["title"], (x, y), color=ColorSettings.WHITE, size=size)
            if index == self.cursor:
                tip = (x - 4, y + 3)
                pygame.draw.polygon(surface, ColorSettings.YELLOW, [
                    tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 5, tip[1] + 5),
                ])

    def _render_page(self, surface: pygame.Surface) -> None:
        """One page: its title and count, and the words."""
        size = FontSettings.SIZE_BODY
        draw_window(surface, surface.get_rect())
        page = self.pages[self.cursor]
        text_renderer.draw_text(surface, page["title"], _NAME_POS, color=ColorSettings.WHITE, size=size)
        count = f"{self.cursor + 1}/{len(self.pages)}"
        text_renderer.draw_text(surface, count, (_COUNT_RIGHT_X - text_renderer.text_width(count, size), _NAME_POS[1]),
                                color=ColorSettings.GRAY, size=size)
        lines = page_lines(page)
        self.scroll = max(0, min(self.scroll, len(lines) - TEXT_ROWS))
        pitch = text_renderer.line_height(size)
        for index, line in enumerate(lines[self.scroll:self.scroll + TEXT_ROWS]):
            text_renderer.draw_text(surface, line, (PANEL_X, TEXT_TOP_Y + index * pitch), color=COLOR_BODY_TEXT,
                                    size=size)
        if self.scroll > 0:
            draw_scroll_mark(surface, _SCROLL_MARK_X, TEXT_TOP_Y - 4, up=True)
        if self.scroll + TEXT_ROWS < len(lines):
            draw_scroll_mark(surface, _SCROLL_MARK_X, TEXT_TOP_Y + TEXT_ROWS * pitch - 4, up=False)
