"""Config, Final Fantasy VI's (Frankie, 10/26): one row per setting, left and right to change it.

The settings and what each does are ``systems/config.py``. A change takes
hold at once, the windows of this screen tinting as the sliders move, but
for the Buttons: a swap made here holds when the screen closes, so the
press after it still does what the hand expects here and no one is left
unable to leave (``input_map.held``). Confirm on a row steps it on as right
does, and on Default color puts the windows back to their own blue.

Final Fantasy VI's layout: a small box saying Config, the help line for
the row the cursor is on, the list below.
"""

from __future__ import annotations

import copy
from typing import TYPE_CHECKING

import pygame

from core import save
from core.scene import Scene
from settings import ColorSettings, FontSettings, UISettings
from systems import config
from ui import input_map, text_renderer
from ui.window import draw_header, help_wrap
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager

_LIST_TOP_Y = UISettings.HEADER_LIST_TOP
_LIST_LEFT_X = 16
_VALUE_X = 128
_ROW_HEIGHT = 16
# The sliders: two pixels a step, 0 empty and 31 full.
_BAR_STEP = 2
_BAR_HEIGHT = 6
_NUMBER_RIGHT_X = 240
# Each slider in its own color, light enough to show on any window.
_BAR_COLORS = ((255, 90, 90), (60, 230, 90), (110, 160, 255))
# Held left or right, a slider moves on by itself after this long, then each step.
_REPEAT_WAIT = 0.35
_REPEAT_STEP = 0.05

CURSOR, SPEED, RED, GREEN, BLUE, DEFAULT, SOUND, AB, XY = range(9)
NAMES = ("Cursor", "Message speed", "Window red", "Window green", "Window blue",
         "Default color", "Sound", "A and B", "X and Y")
_HELP = {
    ("cursor", "Reset"): "Each turn, battle commands start on Attack.",
    ("cursor", "Memory"): "Each turn, commands start where that fighter left them.",
    SPEED: "How fast the words type.",
    RED: "The windows' color. Left and right change it.",
    DEFAULT: "Confirm puts the windows back to their blue.",
    ("sound", "Stereo"): "Sound comes from both sides.",
    ("sound", "Mono"): "Music and sounds come from the middle.",
    AB: "Swaps confirm and cancel. Holds once you leave Config.",
    XY: "Swaps X and Y. Holds once you leave Config.",
}


class ConfigScene(Scene):
    """The settings, a row each; left and right change the one the cursor is on."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        self._cursor = 0
        # Left or right held on a slider: which way, and how long.
        self._held = 0
        self._held_for = 0.0

    def on_enter(self) -> None:
        """Keep the buttons as they are until the screen closes."""
        if input_map.held is None:
            input_map.held = copy.copy(config.current)

    def on_exit(self) -> None:
        """The buttons as set here from now on, and the settings kept for the title."""
        input_map.held = None
        save.write_settings(config.current.to_dict())

    # ------------------------------------------------------------------
    # THE ROWS
    # ------------------------------------------------------------------

    def value(self, row: int) -> str:
        """What a row shows: its setting's value, or a slider's number."""
        settings = config.current
        if row == CURSOR:
            return settings.cursor
        if row == SPEED:
            return settings.message_speed
        if row in (RED, GREEN, BLUE):
            return str(settings.window[row - RED])
        if row == SOUND:
            return settings.sound
        if row == AB:
            return "Swapped" if settings.swap_ab else "Normal"
        if row == XY:
            return "Swapped" if settings.swap_xy else "Normal"
        return ""

    def help_line(self) -> str:
        """The help line for the row the cursor is on."""
        row = self._cursor
        if row == CURSOR:
            return _HELP[("cursor", config.current.cursor)]
        if row == SOUND:
            return _HELP[("sound", config.current.sound)]
        return _HELP[RED if row in (GREEN, BLUE) else row]

    def change(self, row: int, step: int) -> bool:
        """Step ``row``'s setting by ``step`` (one left or right); False if it was already at its end."""
        settings = config.current

        def turn(choices: tuple[str, ...], now: str) -> str:
            return choices[(choices.index(now) + step) % len(choices)]

        if row == CURSOR:
            settings.cursor = turn(config.CURSORS, settings.cursor)
        elif row == SPEED:
            # Slow to Instant, stopping at either end like a slider.
            at = config.SPEEDS.index(settings.message_speed) + step
            if not 0 <= at < len(config.SPEEDS):
                return False
            settings.message_speed = config.SPEEDS[at]
        elif row in (RED, GREEN, BLUE):
            color = list(settings.window)
            at = color[row - RED] + step
            if not 0 <= at < config.STEPS:
                return False
            color[row - RED] = at
            settings.window = tuple(color)
        elif row == DEFAULT:
            return False
        elif row == SOUND:
            settings.sound = turn(config.SOUNDS, settings.sound)
            config.apply(self.gm)
        elif row == AB:
            settings.swap_ab = not settings.swap_ab
        elif row == XY:
            settings.swap_xy = not settings.swap_xy
        return True

    def _default_color(self) -> bool:
        """Put the windows back to their own color; False if they already were."""
        if config.current.window == config.WINDOW_DEFAULT:
            return False
        config.current.window = config.WINDOW_DEFAULT
        return True

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move the cursor, change a setting, or go back to the menu."""
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif input_map.is_up(event) or input_map.is_down(event):
            self._cursor = (self._cursor + (-1 if input_map.is_up(event) else 1)) % len(NAMES)
            self._held = 0
            self.gm.audio.play("menu_move")
        elif input_map.is_left(event) or input_map.is_right(event):
            step = -1 if input_map.is_left(event) else 1
            if self.change(self._cursor, step):
                self.gm.audio.play("menu_move")
            if self._cursor in (RED, GREEN, BLUE):
                self._held, self._held_for = step, 0.0
        elif input_map.is_confirm(event):
            done = self._default_color() if self._cursor == DEFAULT else self.change(self._cursor, 1)
            if done:
                self.gm.audio.play("menu_select")

    def update(self, dt: float) -> None:
        """A slider held left or right keeps moving, as Final Fantasy VI's does."""
        if not self._held:
            return
        dx, _ = input_map.read_held_direction(getattr(self.gm, "connected_joysticks", []))
        if dx != self._held or self._cursor not in (RED, GREEN, BLUE):
            self._held = 0
            return
        self._held_for += dt
        while self._held_for >= _REPEAT_WAIT:
            self._held_for -= _REPEAT_STEP
            if not self.change(self._cursor, self._held):
                self._held = 0
                return

    def render(self, surface: pygame.Surface) -> None:
        """The top boxes with the help line, and a row per setting."""
        render_scene_background(self, surface)
        draw_header(surface, "Config", help_wrap(self.help_line()))
        size = FontSettings.SIZE_BODY
        for row, name in enumerate(NAMES):
            y = _LIST_TOP_Y + row * _ROW_HEIGHT
            text_renderer.draw_text(surface, name, (_LIST_LEFT_X, y), color=ColorSettings.WHITE, size=size)
            if row in (RED, GREEN, BLUE):
                self._render_slider(surface, row, y)
            else:
                text_renderer.draw_text(surface, self.value(row), (_VALUE_X, y),
                                        color=ColorSettings.WHITE, size=size)
            if row == self._cursor:
                text_renderer.draw_pointer(surface, (_LIST_LEFT_X - 4, y + size // 2), ColorSettings.YELLOW)

    def _render_slider(self, surface: pygame.Surface, row: int, y: int) -> None:
        """A slider: its 32 steps as a bar in its color, filled to the step set, the number after."""
        step = config.current.window[row - RED]
        track = pygame.Rect(_VALUE_X, y + 1, (config.STEPS - 1) * _BAR_STEP, _BAR_HEIGHT)
        pygame.draw.rect(surface, ColorSettings.DARK_GRAY, track)
        pygame.draw.rect(surface, _BAR_COLORS[row - RED],
                         pygame.Rect(track.left, track.top, step * _BAR_STEP, track.height))
        number = self.value(row)
        text_renderer.draw_text(
            surface, number,
            (_NUMBER_RIGHT_X - text_renderer.text_width(number, FontSettings.SIZE_BODY), y),
            color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
        )
