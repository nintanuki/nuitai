"""The BESTIARY screen: one page per creature the party can meet.

Pushed by ``core/scenes/menu_scene.py``. Only creatures the party has
beaten have a page (D-458). One creature fills the screen
at a time: its name and the page count on top, its picture, a row of
facts (elements, HP, boss or beast), then a block of text rows holding
its description, where it is found and its moves with how often it uses
each. The block scrolls when it is longer than the five rows it has.

Everything shown is read from the shared battle file, so the words and
numbers match the Bestiary tab of the browser game:

* ``bestiary``    the name, picture and description
* ``encounters``  which fights it appears in, and with which element
* ``monsters``    its HP and moves

Left and right turn the page, up and down scroll the block. Cancel
goes back.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

import pygame

from core.scene import Scene
from core.shared import SHARED, by_id
from settings import (
    BattleSettings,
    BestiarySettings as Page,
    ColorSettings,
    FontSettings,
    UISettings,
)
from ui import input_map, text_renderer
from ui.window import draw_window
from utils.backgrounds import render_scene_background
from utils.graphics import load_element_icon, load_monster_sprite

if TYPE_CHECKING:
    from main import GameManager


# One piece of a text row: the letter column it starts in, its words,
# its colour.
_Piece = tuple[int, str, tuple[int, int, int]]


def beaten_flag(name: str) -> str:
    """Return the party flag set once a creature called ``name`` is beaten.

    "Boar A" and "Boar" share one: the letter only tells apart several
    of one kind in a fight.
    """
    return "beaten:" + re.sub(r" [A-Z]$", "", name)


def _entries() -> list[dict[str, Any]]:
    """Join the three shared sections into one record per creature.

    An enemy called "Boar A" belongs to the entry "Boar": a trailing
    single letter only tells apart several of one kind in a fight.
    """
    monsters = by_id("monsters")
    entries: list[dict[str, Any]] = []
    for page in SHARED["bestiary"]:
        elements: list[str] = []
        fights: list[str] = []
        monster: dict[str, Any] | None = None
        for encounter in SHARED["encounters"]:
            for enemy in encounter["enemies"]:
                if re.sub(r" [A-Z]$", "", enemy["name"]) != page["name"]:
                    continue
                monster = monsters[enemy["monster"]]
                if enemy["element"] not in elements:
                    elements.append(enemy["element"])
                # "Beast pack (physical)" -> "Beast pack"
                fight = re.sub(r" \(.*\)$", "", encounter["name"])
                if fight not in fights:
                    fights.append(fight)
        if monster is not None:
            # A two-stance boss shows both its elements, the one it starts in first (D-591).
            for element in monster.get("stances", []):
                if element not in elements:
                    elements.append(element)
            entries.append(
                {**page, "elements": elements, "fights": fights, "monster": monster}
            )
    return entries


def _element_color(element_id: str) -> tuple[int, int, int]:
    """Return the colour an element's word is written in."""
    if element_id == "ata":
        return Page.COLOR_ATA_WORD
    return ColorSettings.ELEMENT_COLORS.get(element_id, ColorSettings.WHITE)


class BestiaryScene(Scene):
    """Read-only pages for the creatures in the shared battle file."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Load the pages and start on the first."""
        super().__init__(gm)
        # Only what the party has beaten (D-458).
        self.entries = [
            e for e in _entries() if gm.party.flags.get(beaten_flag(e["name"]))
        ]
        self.cursor = 0
        self.scroll = 0

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Turn the page, scroll the words, or go back."""
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif not self.entries:
            return
        elif input_map.is_left(event):
            self.cursor = (self.cursor - 1) % len(self.entries)
            self.scroll = 0
            self.gm.audio.play("menu_move")
        elif input_map.is_right(event):
            self.cursor = (self.cursor + 1) % len(self.entries)
            self.scroll = 0
            self.gm.audio.play("menu_move")
        elif input_map.is_up(event) and self.scroll > 0:
            self.scroll -= 1
            self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            rows = self._rows(self.entries[self.cursor])
            if self.scroll + Page.TEXT_ROWS < len(rows):
                self.scroll += 1
                self.gm.audio.play("menu_move")

    # ------------------------------------------------------------------
    # THE WORDS
    # ------------------------------------------------------------------

    def _rows(self, entry: dict[str, Any]) -> list[list[_Piece]]:
        """Return the text block for ``entry``: rows of coloured pieces.

        The description wrapped to the panel, where the creature is
        found, then a table of its moves, one row each in fixed letter
        columns (the font is one letter per cell, so columns line up by
        counting letters). A move's statuses take a row of their own
        under it.
        """
        monster = entry["monster"]
        font = text_renderer.get_font(FontSettings.SIZE_BODY)
        rows: list[list[_Piece]] = []
        for line in text_renderer.wrap(
            entry["description"].upper(), font, Page.PANEL_WIDTH
        ):
            rows.append([(0, line, Page.COLOR_BODY_TEXT)])
        for line in text_renderer.wrap(
            "FOUND IN: " + ", ".join(entry["fights"]).upper(), font, Page.PANEL_WIDTH
        ):
            rows.append([(0, line, ColorSettings.GRAY)])
        rows.append([
            (0, "Move", ColorSettings.GRAY),
            (Page.MOVE_KIND_COL, "Kind", ColorSettings.GRAY),
            (Page.MOVE_ELEMENT_COL, "Elem", ColorSettings.GRAY),
            (Page.MOVE_EFFECT_COL, "Power", ColorSettings.GRAY),
            (Page.MOVE_USED_COL, "Use", ColorSettings.GRAY),
        ])
        both = monster.get("moves_both", [])
        if not (monster.get("stances") and monster.get("moves_2")):
            rows += self._move_rows(monster["moves"])
            return rows
        # A two-stance boss (D-591): each stance's moves under its element,
        # then why it changes stance (D-601), so a player can learn it.
        for element, moves in zip(entry["elements"], (monster["moves"], monster["moves_2"])):
            rows.append([(0, "In " + element, _element_color(element))])
            rows += self._move_rows(moves + both)
        rows.append([(0, "Changes stance:", ColorSettings.GRAY)])
        for reason in monster.get("switch", []):
            for line in text_renderer.wrap(
                (reason["about"] + ".").upper(), font, Page.PANEL_WIDTH
            ):
                rows.append([(0, line, Page.COLOR_BODY_TEXT)])
        return rows

    def _move_rows(self, moves: list[dict[str, Any]]) -> list[list[_Piece]]:
        """Return one table row per move, and a row under it for what else it does."""
        rows: list[list[_Piece]] = []
        total = sum(move["weight"] for move in moves) or 1
        for move in moves:
            effect = str(move["power"]) if move["power"] else ""
            if move.get("heal"):
                effect = "Heal"
            if move["all"]:
                effect = (effect + " all").strip()
            # Damage is physical or magic; everything else looks after
            # its side (D-598) or, for Puppet Strings, turns the party.
            kind = {"physical": "Phys", "magic": "Mag", "puppet": "Hex"}.get(move["kind"], "Aid")
            # A name too long for its column, with a space after, gets a row of its own.
            row: list[_Piece] = [(Page.MOVE_KIND_COL, kind, ColorSettings.GRAY)]
            if len(move["name"]) < Page.MOVE_NAME_CHARS:
                row.insert(0, (0, move["name"], ColorSettings.WHITE))
            else:
                rows.append([(0, move["name"], ColorSettings.WHITE)])
            if move["element"]:
                row.append((
                    Page.MOVE_ELEMENT_COL, move["element"],
                    _element_color(move["element"]),
                ))
            if effect:
                row.append((Page.MOVE_EFFECT_COL, effect, Page.COLOR_BODY_TEXT))
            # How often it picks this move. The share is a fraction so
            # it fits; the font has no percent sign anyway.
            row.append((Page.MOVE_USED_COL, f"{move['weight']}/{total}", ColorSettings.GRAY))
            rows.append(row)
            extra = list(move["statuses"]) + list(move.get("buffs", ()))
            if move.get("cure"):
                extra.append("cure")
            if move.get("defend"):
                extra.append("brace")
            if extra:
                rows.append([
                    (Page.MOVE_EFFECT_COL, " ".join(extra), Page.COLOR_BODY_TEXT),
                ])
        return rows

    # ------------------------------------------------------------------
    # DRAWING
    # ------------------------------------------------------------------

    def _text(
        self,
        surface: pygame.Surface,
        text: str,
        pos: tuple[int, int],
        color: tuple[int, int, int] = ColorSettings.WHITE,
        size: int = FontSettings.SIZE_SMALL,
    ) -> int:
        """Draw one line with the top of its letters at ``pos``.

        Returns:
            The X position just past the text.
        """
        text_renderer.draw_text(surface, text, pos, color=color, size=size)
        return pos[0] + text_renderer.text_width(text, size)

    def render(self, surface: pygame.Surface) -> None:
        """Draw the current creature's page."""
        render_scene_background(self, surface)
        # The whole screen is one ocean-blue window (D-461).
        draw_window(surface, surface.get_rect())
        if not self.entries:
            self._text(surface, "Bestiary", Page.NAME_POS)
            return
        entry = self.entries[self.cursor]
        monster = entry["monster"]

        # The top row: the name on the left, the page count on the right.
        self._text(surface, entry["name"], Page.NAME_POS)
        count = f"{self.cursor + 1}/{len(self.entries)}"
        self._text(
            surface, count,
            (Page.COUNT_RIGHT_X - text_renderer.text_width(count), Page.NAME_POS[1]),
            ColorSettings.GRAY,
        )

        loaded = load_monster_sprite(entry.get("sprite"))
        if loaded is not None:
            picture = loaded[0]
            surface.blit(
                picture,
                (Page.PICTURE_CENTER_X - picture.get_width() // 2,
                 Page.PICTURE_GROUND_Y - picture.get_height()),
            )

        # One row of facts: elements, HP, and what kind of thing it is.
        x = Page.PANEL_X
        for element_id in entry["elements"]:
            icon = load_element_icon(element_id)
            if icon is not None:
                surface.blit(icon, (x, Page.FACTS_Y + UISettings.ELEMENT_ICON_Y_OFFSET))
                x += icon.get_width() + UISettings.ELEMENT_ICON_GAP
            else:
                x = self._text(
                    surface, element_id, (x, Page.FACTS_Y), _element_color(element_id)
                ) + Page.FACT_GAP
        x += Page.FACT_GAP // 2
        hp = round(monster["hp"] * BattleSettings.MONSTER_HP_SCALE)
        x = self._text(surface, f"HP {hp}", (x, Page.FACTS_Y)) + Page.FACT_GAP
        if monster.get("boss"):
            x = self._text(surface, "Boss", (x, Page.FACTS_Y), ColorSettings.YELLOW) + Page.FACT_GAP
        if monster.get("beast"):
            self._text(surface, "Beast", (x, Page.FACTS_Y), Page.COLOR_BEAST)

        # The scrolling block.
        rows = self._rows(entry)
        self.scroll = max(0, min(self.scroll, len(rows) - Page.TEXT_ROWS))
        pitch = text_renderer.line_height(FontSettings.SIZE_BODY)
        shown = rows[self.scroll:self.scroll + Page.TEXT_ROWS]
        for index, row in enumerate(shown):
            y = Page.TEXT_TOP_Y + index * pitch
            for col, words, color in row:
                self._text(surface, words, (Page.PANEL_X + col * FontSettings.LETTER_WIDTH, y), color)
        if self.scroll > 0:
            self._scroll_mark(surface, Page.TEXT_TOP_Y - 4, up=True)
        if self.scroll + Page.TEXT_ROWS < len(rows):
            self._scroll_mark(surface, Page.TEXT_TOP_Y + Page.TEXT_ROWS * pitch - 4, up=False)

    @staticmethod
    def _scroll_mark(surface: pygame.Surface, y: int, up: bool) -> None:
        """Draw the small triangle that says the block goes on past its edge."""
        x = Page.SCROLL_MARK_X
        points = (
            [(x, y - 3), (x - 3, y + 1), (x + 3, y + 1)] if up
            else [(x, y + 3), (x - 3, y - 1), (x + 3, y - 1)]
        )
        pygame.draw.polygon(surface, ColorSettings.GRAY, points)
