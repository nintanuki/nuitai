"""The crafting pot: two things in, one out (Frankie, 10/22).

One pot for every craft, like Dragon Quest VIII's alchemy pot. Who is in
the party decides what it can make: each recipe in
``data/crafting/pot.json`` belongs to a crafter, and only those whose
crafter travels with the party show. In the demo that is Kailo's
cooking: what Hina grows goes in, food comes out.

Pushed by Craft on the field menu, or by facing the pot outside Kailo's
house. Each row is a recipe: what it makes, then its two ingredients,
grey while the bag lacks them. Confirm makes one. Final Fantasy VI's
layout (Frankie, 10/23): a small box saying Craft, and the help line under
it says how many of each ingredient the bag holds, or what was made.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from core.scenes.shop_scene import item_name
from settings import ColorSettings, FontSettings, UISettings
from ui import input_map, text_renderer
from ui.window import draw_header
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager

_LIST_TOP_Y = UISettings.HEADER_LIST_TOP
_LIST_LEFT_X = 16
_FROM_X = 104
_ROW_HEIGHT = 16


def recipes(gm: "GameManager") -> list[dict]:
    """The recipes the party can make now: those whose crafter is along."""
    pot = gm.data.load("crafting")["pot"]
    return [r for r in pot["recipes"] if gm.party.find(r["crafter"]) is not None]


def can_make(bag: dict[str, int], recipe: dict) -> bool:
    """Whether the bag holds both ingredients (two of one, when both are the same)."""
    need: dict[str, int] = {}
    for item in recipe["from"]:
        need[item] = need.get(item, 0) + 1
    return all(bag.get(item, 0) >= count for item, count in need.items())


def make(bag: dict[str, int], recipe: dict) -> None:
    """Take the ingredients out of the bag and put the result in."""
    for item in recipe["from"]:
        bag[item] -= 1
        if bag[item] <= 0:
            del bag[item]
    bag[recipe["id"]] = bag.get(recipe["id"], 0) + 1


class CraftScene(Scene):
    """The pot's recipes; confirm makes one."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        self._cursor = 0
        self._message: str | None = None

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move the cursor, make something, or close the pot."""
        rows = recipes(self.gm)
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
            return
        if not rows:
            return
        if input_map.is_up(event) or input_map.is_down(event):
            self._cursor = (self._cursor + (-1 if input_map.is_up(event) else 1)) % len(rows)
            self._message = None
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            recipe = rows[self._cursor]
            bag = self.gm.party.inventory
            if not can_make(bag, recipe):
                self.gm.audio.play("menu_move")
                return
            make(bag, recipe)
            self.gm.audio.play("hit_sparkle_1")
            self._message = f"Made {item_name(recipe['id'])}."

    def render(self, surface: pygame.Surface) -> None:
        """The top boxes with the help line, and a row per recipe."""
        render_scene_background(self, surface)
        rows = recipes(self.gm)
        bag = self.gm.party.inventory
        if self._message is not None:
            line = self._message
        elif rows:
            held = dict.fromkeys(rows[self._cursor % len(rows)]["from"])
            line = "  ".join(f"{item_name(item)} x{bag.get(item, 0)}" for item in held)
        else:
            line = ""
        draw_header(surface, "Craft", [line] if line else [])
        if not rows:
            text_renderer.draw_text(surface, "Nobody here can craft.", (_LIST_LEFT_X, _LIST_TOP_Y),
                                    color=ColorSettings.GRAY, size=FontSettings.SIZE_BODY)
            return
        for index, recipe in enumerate(rows):
            y = _LIST_TOP_Y + index * _ROW_HEIGHT
            color = ColorSettings.WHITE if can_make(bag, recipe) else ColorSettings.GRAY
            text_renderer.draw_text(surface, item_name(recipe["id"]), (_LIST_LEFT_X, y),
                                    color=color, size=FontSettings.SIZE_BODY)
            first, second = (item_name(item) for item in recipe["from"])
            text_renderer.draw_text(surface, f"{first} + {second}", (_FROM_X, y),
                                    color=color, size=FontSettings.SIZE_BODY)
            if index == self._cursor % len(rows):
                tip = (_LIST_LEFT_X - 4, y + 3)
                pygame.draw.polygon(surface, ColorSettings.YELLOW, [
                    tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 5, tip[1] + 5),
                ])
