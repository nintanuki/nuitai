"""The crafting pot: two things in, one out (Frankie, 10/22), with a list as in Skyrim (10/28).

One pot for every craft, like Dragon Quest VIII's alchemy pot; for now
only Kailo's cooking, so the screen is called Cook. Crafting is by
experiment first, then a list (Frankie, 10/28):

* On the left, Ingredients at the top, a line, then every recipe already
  found, in ``data/crafting/pot.json``'s order. Nothing is on the list until
  it has been made once (the party flag ``recipe:<id>``). A recipe the party
  lacks the ingredients for is gray.
* On the right, what goes in the pot: with Ingredients picked, everything
  the bag holds that is food, an ingredient or medicine, with how many;
  with a recipe picked, only that recipe's ingredients.
* Confirm on the left moves to the right; there the player picks one, then
  a second, even for a recipe. A recipe is always two different ingredients
  (Frankie, 10/28), so confirm on the one already picked puts it back, as B
  does: pressing it again to unselect once cooked it with itself.
* If the pair is a recipe and its crafter travels with the party, both are
  used and the dish goes in the bag; the first time, the recipe joins the
  list. If the two do not mix, both are used up and lost (Frankie, 10/28).
  A right pair with the crafter away uses nothing and says he would know.
* A pair that did not mix is remembered (the party flag ``nomix:<a>+<b>``,
  either way round): once one is picked, the other is gray and cannot be
  picked (Frankie, 10/28). The cartridge needs a bit per pair of its pantry.
* The help line says what the cursor's recipe is and what it does, as
  "Taro root pounded with water. Heals 40 HP." (Frankie, 10/28), or what to
  do, or what happened.

Pushed by facing the pot inside Kailo's house (Frankie, 10/24: Craft is off
the field menu). The look is Frankie's preview, ``outbox/crafting-menu-preview.png``.
B puts the first pick back, then goes back to the left, then closes the pot.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from core.scenes.shop_scene import item_name
from settings import ColorSettings, CraftSettings, FontSettings, ItemSettings, UISettings
from ui import input_map, text_renderer
from ui.scroll_mark import draw_list_marks
from ui.window import draw_header, draw_window, help_wrap
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager

SIZE = FontSettings.SIZE_BODY
ROW = 16
_TOP = UISettings.HEADER_LIST_TOP          # The first row's letters.
_LEFT_RECT = pygame.Rect(0, 64, 120, 160)  # Ingredients and the recipes found.
_RIGHT_RECT = pygame.Rect(120, 64, 136, 160)  # What goes in the pot, with how many.
_LEFT_X = 16
_RIGHT_X = 136
_COUNT_RIGHT = 240
_LINE_Y = _TOP + 19                        # The line under Ingredients.
_RECIPES_TOP = _TOP + 24
_RIGHT_ROWS = 9                            # Rows that fit on the right; it scrolls past them.
_MARK_X = 248
_HELP_WIDTH = 232                          # The help's two lines, out to the window's edge.
_FOOD_KINDS = ("ingredient", "food", "medicine")

# The cartridge still draws the old one-list pot from these (snes/tools/make_art.py) until it
# catches up with this one (the TODO's cooking item); nothing in pygame uses them.
_LIST_TOP_Y = UISettings.HEADER_LIST_TOP
_LIST_LEFT_X = 16
_COUNT_X = 104
_ROW_HEIGHT = 16


def all_recipes(gm: "GameManager") -> list[dict]:
    """Every recipe the pot knows, whoever's craft it is."""
    return gm.data.load("crafting")["pot"]["recipes"]


def found(gm: "GameManager") -> list[dict]:
    """The recipes already made once, in the pot file's order."""
    return [r for r in all_recipes(gm) if gm.party.flags.get(f"recipe:{r['id']}")]


def ingredients(gm: "GameManager") -> list[str]:
    """What the bag holds that goes in the pot, in the bag's order: food, ingredients, medicine."""
    from ui.item_icon import item_kind

    return [item for item, count in gm.party.inventory.items() if count > 0 and item_kind(item) in _FOOD_KINDS]


def parts(recipe: dict) -> list[str]:
    """A recipe's ingredients, in its order."""
    return list(dict.fromkeys(recipe["from"]))


def can_make(gm: "GameManager", recipe: dict) -> bool:
    """Whether the bag holds both of ``recipe``'s ingredients."""
    bag = gm.party.inventory
    return all(bag.get(item, 0) >= recipe["from"].count(item) for item in parts(recipe))


def recipe_help(recipe: dict) -> str:
    """What a recipe is and what it does (Frankie, 10/28): its ``about``, then its heal."""
    heals = ItemSettings.HEALS.get(recipe["id"])
    does = f" Heals {heals} HP." if heals else ""
    return recipe.get("about", "") + does


def recipe_for(gm: "GameManager", first: str, second: str) -> dict | None:
    """The recipe these two make, either way round, or None."""
    for recipe in all_recipes(gm):
        if sorted(recipe["from"]) == sorted((first, second)):
            return recipe
    return None


def _nomix_flag(first: str, second: str) -> str:
    a, b = sorted((first, second))
    return f"nomix:{a}+{b}"


def known_bad(gm: "GameManager", first: str, second: str) -> bool:
    """Whether these two, either way round, have already failed in the pot."""
    return bool(gm.party.flags.get(_nomix_flag(first, second)))


def _take(bag: dict[str, int], item: str) -> None:
    bag[item] -= 1
    if bag[item] <= 0:
        del bag[item]


def make(bag: dict[str, int], recipe: dict) -> None:
    """Take the ingredients out of the bag and put the result in."""
    for item in recipe["from"]:
        _take(bag, item)
    bag[recipe["id"]] = bag.get(recipe["id"], 0) + 1


def mix(gm: "GameManager", first: str, second: str) -> list[str]:
    """Put two different things in the pot: makes what they make, or loses both, and says what happened."""
    bag = gm.party.inventory
    recipe = recipe_for(gm, first, second)
    if recipe is None:
        _take(bag, first)
        _take(bag, second)
        gm.party.flags[_nomix_flag(first, second)] = True
        return list(CraftSettings.NO_MIX_LINES)
    if gm.party.find(recipe["crafter"]) is None:
        return [CraftSettings.AWAY_LINE.format(crafter=recipe["crafter"].title())]
    make(bag, recipe)
    made = CraftSettings.MADE_LINE.format(item=item_name(recipe["id"]))
    flag = f"recipe:{recipe['id']}"
    if gm.party.flags.get(flag):
        return [made]
    gm.party.flags[flag] = True
    return [made, CraftSettings.NEW_RECIPE_LINE]


class CraftScene(Scene):
    """The Cook screen: the list on the left, what goes in the pot on the right."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        self.side = "left"         # "left" (Ingredients and recipes) or "right" (what goes in).
        self._left = 0             # 0 is Ingredients, then each recipe found.
        self._right = 0
        self._first: str | None = None
        self._message: list[str] | None = None

    # ------------------------------------------------------------------
    # WHAT IS SHOWN
    # ------------------------------------------------------------------

    def recipe(self) -> dict | None:
        """The recipe under the left cursor, or None on Ingredients."""
        recipes = found(self.gm)
        if self._left == 0 or not recipes:
            return None
        return recipes[min(self._left, len(recipes)) - 1]

    def right_rows(self) -> list[str]:
        """The right side: everything that goes in, or only the picked recipe's ingredients."""
        recipe = self.recipe()
        return parts(recipe) if recipe is not None else ingredients(self.gm)

    def gray(self, item: str) -> bool:
        """Whether ``item`` cannot be picked: none in the bag, or known not to go with the first pick."""
        if self.gm.party.inventory.get(item, 0) < 1:
            return True
        return self._first is not None and known_bad(self.gm, self._first, item)

    def help_lines(self) -> list[str]:
        """The help window's two lines."""
        if self._message is not None:
            return self._message
        recipe = self.recipe()
        if recipe is not None:
            return help_wrap(recipe_help(recipe), _HELP_WIDTH)
        if self._first is not None:
            return [CraftSettings.WITH_LINE.format(item=item_name(self._first)), CraftSettings.PUT_BACK_LINE]
        if not ingredients(self.gm):
            return [CraftSettings.EMPTY_LINE]
        return list(CraftSettings.FIND_LINES)

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move, pick, put one back, go back to the list, or close the pot."""
        if self.side == "left":
            self._handle_left(event)
        else:
            self._handle_right(event)

    def _handle_left(self, event: pygame.event.Event) -> None:
        count = 1 + len(found(self.gm))
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif input_map.is_up(event) or input_map.is_down(event):
            self._left = (self._left + (-1 if input_map.is_up(event) else 1)) % count
            self._message = None
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            recipe = self.recipe()
            self._message = None
            if not self.right_rows() or (recipe is not None and not can_make(self.gm, recipe)):
                self.gm.audio.play("menu_move")      # Gray: a quiet bump.
                return
            self.side, self._right, self._first = "right", 0, None
            self.gm.audio.play("menu_select")

    def _handle_right(self, event: pygame.event.Event) -> None:
        rows = self.right_rows()
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self._message = None
            if self._first is not None:
                self._first = None
            else:
                self.side = "left"
            return
        if not rows:
            return
        if input_map.is_up(event) or input_map.is_down(event):
            self._right = (self._right + (-1 if input_map.is_up(event) else 1)) % len(rows)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            item = rows[self._right % len(rows)]
            self._message = None
            if item == self._first:                  # Again on the picked one: put it back, as B.
                self.gm.audio.play("menu_select")
                self._first = None
                return
            if self.gray(item):
                self.gm.audio.play("menu_move")      # Gray: a quiet bump.
                return
            if self._first is None:
                self._first = item
                self.gm.audio.play("menu_select")
                return
            before = dict(self.gm.party.inventory)
            self._message = mix(self.gm, self._first, item)
            self._first = None
            made = any(self.gm.party.inventory.get(i, 0) > before.get(i, 0) for i in self.gm.party.inventory)
            self.gm.audio.play("hit_sparkle_1" if made else "menu_move")
            self._settle()

    def _settle(self) -> None:
        """After a mix: back to the left when nothing is left to pick here."""
        recipe = self.recipe()
        rows = self.right_rows()
        if not rows or (recipe is not None and not can_make(self.gm, recipe)):
            self.side = "left"
            return
        self._right %= len(rows)

    def render(self, surface: pygame.Surface) -> None:
        """The top boxes with the help line, the list on the left, what goes in on the right."""
        render_scene_background(self, surface)
        draw_header(surface, CraftSettings.TITLE, self.help_lines())
        draw_window(surface, _LEFT_RECT)
        draw_window(surface, _RIGHT_RECT)
        self._render_left(surface)
        self._render_right(surface)

    def _render_left(self, surface: pygame.Surface) -> None:
        picked = self.side == "right"
        color = ColorSettings.YELLOW if picked and self._left == 0 else ColorSettings.WHITE
        _text(surface, CraftSettings.INGREDIENTS_ROW, _LEFT_X, _TOP, color)
        pygame.draw.line(surface, ColorSettings.GRAY, (_LEFT_X - 4, _LINE_Y), (_LEFT_RECT.right - 12, _LINE_Y))
        for index, recipe in enumerate(found(self.gm), start=1):
            y = _RECIPES_TOP + (index - 1) * ROW
            if not can_make(self.gm, recipe):
                color = ColorSettings.GRAY
            elif picked and index == self._left:
                color = ColorSettings.YELLOW
            else:
                color = ColorSettings.WHITE
            _text(surface, item_name(recipe["id"]), _LEFT_X, y, color)
        if not picked:
            y = _TOP if self._left == 0 else _RECIPES_TOP + (self._left - 1) * ROW
            _pointer(surface, (_LEFT_X - 4, y + 3))

    def _render_right(self, surface: pygame.Surface) -> None:
        rows = self.right_rows()
        bag = self.gm.party.inventory
        first = 0
        if self.side == "right" and self._right >= _RIGHT_ROWS:
            first = self._right - _RIGHT_ROWS + 1
        for index, item in enumerate(rows[first:first + _RIGHT_ROWS], start=first):
            y = _TOP + (index - first) * ROW
            count = bag.get(item, 0)
            if self.gray(item):
                color = ColorSettings.GRAY
            elif item == self._first:
                color = ColorSettings.YELLOW
            else:
                color = ColorSettings.WHITE
            _text(surface, item_name(item), _RIGHT_X, y, color)
            _text(surface, f"x{count}", _COUNT_RIGHT, y, color, right=True)
            if self.side == "right" and index == self._right:
                _pointer(surface, (_RIGHT_X - 4, y + 3))
        draw_list_marks(surface, _MARK_X, _TOP, ROW, first, _RIGHT_ROWS, len(rows))


def _text(surface: pygame.Surface, words: str, x: int, y: int,
          color=ColorSettings.WHITE, right: bool = False) -> None:
    if right:
        x -= text_renderer.text_width(words, SIZE)
    text_renderer.draw_text(surface, words, (x, y), color=color, size=SIZE)


def _pointer(surface: pygame.Surface, tip: tuple[int, int]) -> None:
    """The yellow cursor arrow, pointing right at ``tip``."""
    pygame.draw.polygon(surface, ColorSettings.YELLOW, [
        tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 5, tip[1] + 5),
    ])
