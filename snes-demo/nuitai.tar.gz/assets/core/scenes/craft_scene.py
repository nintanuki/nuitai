"""The crafting pot: one, two or three things in, one out (Frankie, 10/22 and 11/2), with a list as in Skyrim (10/28).

One pot for every craft, like Dragon Quest VIII's alchemy pot; for now
only Kailo's cooking, so the screen is called Cook. Crafting is by
experiment first, then a list (Frankie, 10/28). What a mix makes is
``systems/cooking.py``: an exact recipe, then without salt, then by kind of
ingredient, as in Breath of the Wild, else ??? (Frankie, 11/2).

* On the left, Ingredients at the top, a line, then every dish already
  made, in ``data/crafting/pot.json``'s order. Nothing is on the list until
  it has been made once (the party flag ``recipe:<id>``). A dish the bag
  cannot make now is gray.
* On the right, Cook on top, then what goes in the pot: with Ingredients
  picked, every ingredient the bag holds, never food or medicine (Frankie,
  11/2), with how many; with a dish picked, only what can go into it now.
* Confirm on the left moves to the right; there the player picks up to
  three, each one yellow, confirm on a picked one puts it back, and Cook
  cooks them. No mix holds two of the same (Frankie, 10/28).
* Whatever is picked is used up and the dish goes in the bag, the first
  time joining the list; a mix that makes nothing makes ??? (Frankie, 11/2;
  they were lost, 10/28). With Kailo away nothing is used and he would know.
  After cooking the same picks stay up, so Cook again makes another
  (a batch, Frankie, 10/29).
* The help line says what the cursor's dish is and what it does, as
  "Taro root pounded with water. Heals 40 HP." (Frankie, 10/28), or what to
  do, or what happened.

Pushed by facing the pot inside Kailo's house (Frankie, 10/24: Craft is off
the field menu). The look is Frankie's preview, ``outbox/crafting-menu-preview.png``.
B puts the last pick back, then goes back to the left, then closes the pot.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from core.scenes.shop_scene import item_name
from systems import cooking
from settings import ColorSettings, CraftSettings, FontSettings, ItemSettings, UISettings
from ui import input_map, text_renderer
from ui.scroll_mark import draw_list_marks
from ui.window import draw_header, draw_window, help_wrap
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager

SIZE = FontSettings.SIZE_BODY
ROW = 16
_TOP = UISettings.HEADER_LIST_TOP          # The first row's letters.
_LEFT_RECT = pygame.Rect(0, 64, 120, 160)  # Ingredients and the recipes found.
_RIGHT_RECT = pygame.Rect(120, 64, 136, 160)  # What goes in the pot, with how many.
_LEFT_X = 16
_RIGHT_X = 136
_COUNT_RIGHT = 240
_LINE_Y = _TOP + 19                        # The line under Ingredients.
_RECIPES_TOP = _TOP + 24
_RIGHT_ROWS = 9                            # Rows that fit on the right; it scrolls past them.
_LEFT_ROWS = 8                             # Dishes that fit on the left under the line; it scrolls past them.
_MARK_X = 248
_HELP_WIDTH = 232                          # The help's two lines, out to the window's edge.
_POT_KINDS = ("ingredient",)  # only ingredients go in (Frankie, 11/2)

# The cartridge still draws the old one-list pot from these (snes/tools/make_art.py) until it
# catches up with this one (the TODO's cooking item); nothing in pygame uses them.
_LIST_TOP_Y = UISettings.HEADER_LIST_TOP
_LIST_LEFT_X = 16
_COUNT_X = 104
_ROW_HEIGHT = 16


def all_recipes(gm: "GameManager") -> list[dict]:
    """Every dish the pot knows, recipes then dishes by kind, whoever's craft it is."""
    return cooking.results()


def found(gm: "GameManager") -> list[dict]:
    """The dishes already made once, in the pot file's order."""
    return [r for r in all_recipes(gm) if gm.party.flags.get(f"recipe:{r['id']}")]


def ingredients(gm: "GameManager") -> list[str]:
    """The ingredients the bag holds, in the bag's order: all that goes in the pot."""
    from ui.item_icon import item_kind

    return [item for item, count in gm.party.inventory.items() if count > 0 and item_kind(item) in _POT_KINDS]


_MAKEABLE: dict = {}


def makeable(gm: "GameManager") -> dict[str, list[str]]:
    """Each dish the bag can make now, to the ingredients that can go into it, in the bag's order."""
    have = tuple(ingredients(gm))
    if _MAKEABLE.get("key") != have:
        out: dict[str, list[str]] = {}
        for mix_ in cooking.mixes(list(have)):
            dish = cooking.makes(list(mix_))
            if dish != ItemSettings.DUBIOUS:
                out.setdefault(dish, set()).update(mix_)
        _MAKEABLE.clear()
        _MAKEABLE.update(key=have, dishes={d: [i for i in have if i in items] for d, items in out.items()})
    return _MAKEABLE["dishes"]


def parts(recipe: dict, gm: "GameManager | None" = None) -> list[str]:
    """What can go into ``recipe``'s dish: from the bag when ``gm`` is given, else what it names."""
    if gm is not None:
        return list(makeable(gm).get(recipe["id"], []))
    if "from" in recipe:
        return [i for part in recipe["from"] for i in cooking.members(part)]
    return [i for kind in recipe["groups"] for i in ItemSettings.FOOD_GROUPS.get(kind, ())]


def can_make(gm: "GameManager", recipe: dict) -> bool:
    """Whether the bag can make ``recipe``'s dish now."""
    return recipe["id"] in makeable(gm)


def recipe_help(recipe: dict) -> str:
    """What a dish is and what it does (Frankie, 10/28): its ``about``, then its heal."""
    heals = ItemSettings.HEALS.get(recipe["id"])
    does = f" Heals {heals} HP." if heals else ""
    return recipe.get("about", "") + does


def recipe_for(gm: "GameManager", *items: str) -> dict | None:
    """The recipe or dish by kind these make, in any order, or None for ???."""
    return cooking.cook(list(items))


def _take(bag: dict[str, int], item: str) -> None:
    bag[item] -= 1
    if bag[item] <= 0:
        del bag[item]


def mix(gm: "GameManager", *items: str) -> list[str]:
    """Put one to three different things in the pot: they are used, and what they make goes in
    the bag, ??? when nothing (Frankie, 11/2). Says what happened."""
    bag = gm.party.inventory
    if gm.party.find(CraftSettings.CRAFTER) is None:
        return [CraftSettings.AWAY_LINE.format(crafter=CraftSettings.CRAFTER.title())]
    recipe = cooking.cook(list(items))
    for item in items:
        _take(bag, item)
    dish = recipe["id"] if recipe else ItemSettings.DUBIOUS
    bag[dish] = bag.get(dish, 0) + 1
    if recipe is None:
        return list(CraftSettings.DUBIOUS_LINES)
    made = CraftSettings.MADE_LINE.format(item=item_name(dish))
    flag = f"recipe:{dish}"
    if gm.party.flags.get(flag):
        return [made]
    gm.party.flags[flag] = True
    return [made, CraftSettings.NEW_RECIPE_LINE]


_COOK = "__cook__"   # The Cook row on top of the right side.


class CraftScene(Scene):
    """The Cook screen: the list on the left, Cook and what goes in the pot on the right."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        self.side = "left"         # "left" (Ingredients and dishes) or "right" (what goes in).
        self._left = 0             # 0 is Ingredients, then each dish found.
        self._right = 0            # 0 is Cook, then each ingredient.
        self._picked: list[str] = []
        self._message: list[str] | None = None

    # ------------------------------------------------------------------
    # WHAT IS SHOWN
    # ------------------------------------------------------------------

    @property
    def _first(self) -> str | None:
        """The first thing picked, or None."""
        return self._picked[0] if self._picked else None

    def recipe(self) -> dict | None:
        """The dish under the left cursor, or None on Ingredients."""
        recipes = found(self.gm)
        if self._left == 0 or not recipes:
            return None
        return recipes[min(self._left, len(recipes)) - 1]

    def items(self) -> list[str]:
        """The ingredients on the right: all in the bag, or only what can go into the picked dish."""
        recipe = self.recipe()
        return parts(recipe, self.gm) if recipe is not None else ingredients(self.gm)

    def right_rows(self) -> list[str]:
        """The right side: Cook, then the ingredients."""
        return [_COOK, *self.items()]

    def gray(self, item: str) -> bool:
        """Whether ``item`` cannot be picked: none in the bag, or three already in."""
        if item == _COOK:
            return not self._picked
        if self.gm.party.inventory.get(item, 0) < 1:
            return True
        return item not in self._picked and len(self._picked) >= cooking.MAX_PARTS

    def help_lines(self) -> list[str]:
        """The help window's two lines."""
        if self._message is not None:
            return self._message
        if self._picked:
            names = ", ".join(item_name(i) for i in self._picked)
            return help_wrap(f"In the pot: {names}. {CraftSettings.ADD_LINE}", _HELP_WIDTH)
        recipe = self.recipe()
        if recipe is not None:
            return help_wrap(recipe_help(recipe), _HELP_WIDTH)
        if not ingredients(self.gm):
            return [CraftSettings.EMPTY_LINE]
        return list(CraftSettings.FIND_THREE_LINES)

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move, pick, put one back, cook, go back to the list, or close the pot."""
        if self.side == "left":
            self._handle_left(event)
        else:
            self._handle_right(event)

    def _handle_left(self, event: pygame.event.Event) -> None:
        count = 1 + len(found(self.gm))
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif input_map.is_up(event) or input_map.is_down(event):
            self._left = (self._left + (-1 if input_map.is_up(event) else 1)) % count
            self._message = None
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            recipe = self.recipe()
            self._message = None
            if not self.items() or (recipe is not None and not can_make(self.gm, recipe)):
                self.gm.audio.play("menu_move")      # Gray: a quiet bump.
                return
            self.side, self._right, self._picked = "right", 1, []
            self.gm.audio.play("menu_select")

    def _handle_right(self, event: pygame.event.Event) -> None:
        rows = self.right_rows()
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self._message = None
            if self._picked:
                self._picked.pop()
            else:
                self.side = "left"
            return
        if input_map.is_up(event) or input_map.is_down(event):
            self._right = (self._right + (-1 if input_map.is_up(event) else 1)) % len(rows)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            item = rows[self._right % len(rows)]
            self._message = None
            if item == _COOK:
                if not self._picked:
                    self.gm.audio.play("menu_move")
                    return
                self._mix()
                return
            if item in self._picked:                 # Again on a picked one: put it back.
                self.gm.audio.play("menu_select")
                self._picked.remove(item)
                return
            if self.gray(item):
                self.gm.audio.play("menu_move")      # Gray: a quiet bump.
                return
            self._picked.append(item)
            self.gm.audio.play("menu_select")

    def _mix(self) -> None:
        """Cook what is picked; the same picks stay up for another, while the bag has them."""
        picked = list(self._picked)
        before = dict(self.gm.party.inventory)
        self._message = mix(self.gm, *picked)
        made = any(self.gm.party.inventory.get(i, 0) > before.get(i, 0) for i in self.gm.party.inventory
                   if i != ItemSettings.DUBIOUS)
        self.gm.audio.play("hit_sparkle_1" if made else "menu_move")
        bag = self.gm.party.inventory
        self._picked = picked if all(bag.get(i, 0) > 0 for i in picked) else []
        self._settle()

    def _settle(self) -> None:
        """After a mix: back to the left when nothing is left to pick here."""
        recipe = self.recipe()
        if not self.items() or (recipe is not None and not can_make(self.gm, recipe) and not self._picked):
            self.side = "left"
            self._picked = []
            return
        self._right %= len(self.right_rows())

    def render(self, surface: pygame.Surface) -> None:
        """The top boxes with the help line, the list on the left, what goes in on the right."""
        render_scene_background(self, surface)
        draw_header(surface, CraftSettings.TITLE, self.help_lines())
        draw_window(surface, _LEFT_RECT)
        draw_window(surface, _RIGHT_RECT)
        self._render_left(surface)
        self._render_right(surface)

    def _render_left(self, surface: pygame.Surface) -> None:
        picked = self.side == "right"
        color = ColorSettings.YELLOW if picked and self._left == 0 else ColorSettings.WHITE
        _text(surface, CraftSettings.INGREDIENTS_ROW, _LEFT_X, _TOP, color)
        pygame.draw.line(surface, ColorSettings.GRAY, (_LEFT_X - 4, _LINE_Y), (_LEFT_RECT.right - 12, _LINE_Y))
        recipes = found(self.gm)
        first = max(0, self._left - _LEFT_ROWS) if self._left > _LEFT_ROWS else 0
        for index, recipe in enumerate(recipes[first:first + _LEFT_ROWS], start=first + 1):
            y = _RECIPES_TOP + (index - 1 - first) * ROW
            if not can_make(self.gm, recipe):
                color = ColorSettings.GRAY
            elif picked and index == self._left:
                color = ColorSettings.YELLOW
            else:
                color = ColorSettings.WHITE
            _text(surface, item_name(recipe["id"]), _LEFT_X, y, color)
        if not picked:
            y = _TOP if self._left == 0 else _RECIPES_TOP + (self._left - 1 - first) * ROW
            _pointer(surface, (_LEFT_X - 4, y + 3))

    def _render_right(self, surface: pygame.Surface) -> None:
        rows = self.right_rows()
        bag = self.gm.party.inventory
        first = 0
        if self.side == "right" and self._right >= _RIGHT_ROWS:
            first = self._right - _RIGHT_ROWS + 1
        for index, item in enumerate(rows[first:first + _RIGHT_ROWS], start=first):
            y = _TOP + (index - first) * ROW
            if self.gray(item):
                color = ColorSettings.GRAY
            elif item == _COOK or item in self._picked:
                color = ColorSettings.YELLOW
            else:
                color = ColorSettings.WHITE
            if item == _COOK:
                _text(surface, CraftSettings.COOK_ROW, _RIGHT_X, y, color)
            else:
                _text(surface, item_name(item), _RIGHT_X, y, color)
                _text(surface, f"x{bag.get(item, 0)}", _COUNT_RIGHT, y, color, right=True)
            if self.side == "right" and index == self._right:
                _pointer(surface, (_RIGHT_X - 4, y + 3))
        draw_list_marks(surface, _MARK_X, _TOP, ROW, first, _RIGHT_ROWS, len(rows))


def _text(surface: pygame.Surface, words: str, x: int, y: int,
          color=ColorSettings.WHITE, right: bool = False) -> None:
    if right:
        x -= text_renderer.text_width(words, SIZE)
    text_renderer.draw_text(surface, words, (x, y), color=color, size=SIZE)


def _pointer(surface: pygame.Surface, tip: tuple[int, int]) -> None:
    """The yellow cursor arrow, pointing right at ``tip``."""
    pygame.draw.polygon(surface, ColorSettings.YELLOW, [
        tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 5, tip[1] + 5),
    ])
