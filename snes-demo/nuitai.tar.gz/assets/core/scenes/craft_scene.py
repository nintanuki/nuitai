"""The crafting pot: two things in, one out (Frankie, 10/22).

One pot for every craft, like Dragon Quest VIII's alchemy pot. Crafting
is by experiment (Frankie, 10/23): the pot lists what the bag holds that
goes in it, with how many, and never says what makes what. Pick one, then
a second (the same one twice, when there are two). If the pair is a
recipe in ``data/crafting/pot.json`` and its crafter travels with the
party, both are used and the result goes in the bag; if not, nothing is
used and the pot says the two do not go together. The order of the two
does not matter. In the demo the crafter is Kailo: what Hina grows goes
in, food comes out; with him away a right pair says he would know.

Pushed by facing the pot inside Kailo's house, the only place to craft
(Frankie, 10/24: Craft is off the field menu). Final Fantasy VI's layout (Frankie, 10/23): a small box saying
Craft, and the help line under it says what to do, or what happened.
B puts the first pick back, then closes the pot.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from core.scenes.shop_scene import item_name
from settings import ColorSettings, CraftSettings, FontSettings, UISettings
from ui import input_map, text_renderer
from ui.window import draw_header
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager

_LIST_TOP_Y = UISettings.HEADER_LIST_TOP
_LIST_LEFT_X = 16
_COUNT_X = 104
_ROW_HEIGHT = 16


def all_recipes(gm: "GameManager") -> list[dict]:
    """Every recipe the pot knows, whoever's craft it is."""
    return gm.data.load("crafting")["pot"]["recipes"]


def ingredients(gm: "GameManager") -> list[str]:
    """What goes in the pot and the bag holds, in the recipes' order."""
    bag = gm.party.inventory
    seen: list[str] = []
    for recipe in all_recipes(gm):
        for item in recipe["from"]:
            if item not in seen and bag.get(item, 0) > 0:
                seen.append(item)
    return seen


def recipe_for(gm: "GameManager", first: str, second: str) -> dict | None:
    """The recipe these two make, either way round, or None."""
    for recipe in all_recipes(gm):
        if sorted(recipe["from"]) == sorted((first, second)):
            return recipe
    return None


def make(bag: dict[str, int], recipe: dict) -> None:
    """Take the ingredients out of the bag and put the result in."""
    for item in recipe["from"]:
        bag[item] -= 1
        if bag[item] <= 0:
            del bag[item]
    bag[recipe["id"]] = bag.get(recipe["id"], 0) + 1


def mix(gm: "GameManager", first: str, second: str) -> str:
    """Put two in the pot: makes what they make, if anything, and says what happened."""
    bag = gm.party.inventory
    if first == second and bag.get(first, 0) < 2:
        return CraftSettings.ONLY_ONE_LINE.format(item=item_name(first))
    recipe = recipe_for(gm, first, second)
    if recipe is None:
        return CraftSettings.NO_MIX_LINE
    if gm.party.find(recipe["crafter"]) is None:
        return CraftSettings.AWAY_LINE.format(crafter=recipe["crafter"].title())
    make(bag, recipe)
    return CraftSettings.MADE_LINE.format(item=item_name(recipe["id"]))


class CraftScene(Scene):
    """The pot's ingredients; confirm twice puts two in."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        self._cursor = 0
        self._first: str | None = None
        self._message: str | None = None

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move the cursor, pick an ingredient, put one back, or close the pot."""
        rows = ingredients(self.gm)
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            if self._first is not None:
                self._first = None
                return
            self.gm.scene_stack.pop()
            return
        if not rows:
            return
        if input_map.is_up(event) or input_map.is_down(event):
            self._cursor = (self._cursor + (-1 if input_map.is_up(event) else 1)) % len(rows)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            item = rows[self._cursor % len(rows)]
            self._message = None
            if self._first is None:
                self._first = item
                self.gm.audio.play("menu_select")
                return
            before = dict(self.gm.party.inventory)
            self._message = mix(self.gm, self._first, item)
            self._first = None
            made = self.gm.party.inventory != before
            self.gm.audio.play("hit_sparkle_1" if made else "menu_move")
            rows = ingredients(self.gm)
            if rows:
                self._cursor %= len(rows)

    def render(self, surface: pygame.Surface) -> None:
        """The top boxes with the help line, and a row per ingredient with its count."""
        render_scene_background(self, surface)
        rows = ingredients(self.gm)
        bag = self.gm.party.inventory
        if self._message is not None:
            line = self._message
        elif self._first is not None:
            line = CraftSettings.WITH_LINE.format(item=item_name(self._first))
        elif rows:
            line = CraftSettings.PICK_LINE
        else:
            line = ""
        draw_header(surface, "Craft", [line] if line else [])
        if not rows:
            text_renderer.draw_text(surface, CraftSettings.EMPTY_LINE, (_LIST_LEFT_X, _LIST_TOP_Y),
                                    color=ColorSettings.GRAY, size=FontSettings.SIZE_BODY)
            return
        for index, item in enumerate(rows):
            y = _LIST_TOP_Y + index * _ROW_HEIGHT
            color = ColorSettings.YELLOW if item == self._first else ColorSettings.WHITE
            text_renderer.draw_text(surface, item_name(item), (_LIST_LEFT_X, y),
                                    color=color, size=FontSettings.SIZE_BODY)
            text_renderer.draw_text(surface, f"x{bag[item]}", (_COUNT_X, y),
                                    color=color, size=FontSettings.SIZE_BODY)
            if index == self._cursor % len(rows):
                tip = (_LIST_LEFT_X - 4, y + 3)
                pygame.draw.polygon(surface, ColorSettings.YELLOW, [
                    tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 5, tip[1] + 5),
                ])
