"""One character's techniques: the starting stance and the slots by mana row.

Pushed by the PARTY screen on confirm. The browser battle's Equip tab
(D-339) in the pygame game's terms:

* The top line is the stance the character starts each fight in
  (D-285, D-286); confirm switches it.
* Rows 1 to 7 are the mana rows, three slots each, shared by both
  stances (D-318 to D-320). A technique sits in its own row or, if it
  can grow, any higher row, where it does more and costs more.
* The last row is the bank: what they know and are not taking.

Confirm on a technique picks it up; confirm on a slot puts it there,
swapping with whatever was in it; confirm on the bank sets it aside.
The bottom lines read out the highlighted technique: what it does, and
how strong it is in the row the cursor is on (D-450: descriptions live
here, not in the fight).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pygame

from core.factories import known_moves
from core.scene import Scene
from core.shared import by_id, short_name
from settings import (
    BattleStageSettings,
    ColorSettings,
    FontSettings,
    LoadoutSettings,
    ScreenSettings,
    UISettings,
)
from systems.loadout import grown, checked, home_row, reach
from ui import input_map, text_renderer
from ui.grid_menu import GridCell, GridMenu, GridRow, short_move_name
from ui.window import draw_window
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


_HEADING_POSITION = (8, 8)
_GRID_POSITION = (14, 32)
_ROW_HEIGHT = 16
_FOOTER_Y = 192            # Two lines about the highlighted technique.
_FOOTER_X = 8
_FOOTER_WIDTH = ScreenSettings.WIDTH - 2 * _FOOTER_X
_COLOR_HELD = ColorSettings.WHITE   # No element is white, so the held one stands out.
_COLOR_EMPTY = ColorSettings.DARK_GRAY
_COLOR_NO = (255, 110, 100)    # The footer when a row cannot take the held one.


class LoadoutScene(Scene):
    """Choose a character's starting stance and where each technique sits."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", member: "PartyMember") -> None:
        super().__init__(gm)
        self.member = member
        self.known = known_moves(member.id, member.elements)
        self.by_id = {m["id"]: m for m in self.known}
        self.stances = by_id("characters").get(member.id, {}).get("stances", [])
        member.loadout = checked(member.loadout, self.known)
        self.held: dict[str, Any] | None = None
        self.grid = self._build_grid()

    # ------------------------------------------------------------------
    # THE GRID
    # ------------------------------------------------------------------

    def _build_grid(self, keep: tuple[int, int] | None = None) -> GridMenu:
        """Lay out the stance line, the seven rows and the bank."""
        rows: list[GridRow] = []
        if self.stances:
            stance = self.stances[self.member.stance]
            style = ColorSettings.ELEMENT_TEXT_STYLES.get(stance["element"], {})
            rows.append(GridRow("", [GridCell(
                f"Stance: {stance['name']}", self._toggle_stance,
                color=style.get("color"), glow=style.get("glow"),
                glow_radius=style.get("glow_radius", 3),
                glow_alpha=style.get("glow_alpha", 90),
                data=("stance", None),
            )]))
        loadout = self.member.loadout or {}
        for row in range(1, LoadoutSettings.ROWS + 1):
            here = [m for m in self.known if loadout.get(m["id"]) == row]
            cells = [self._move_cell(m, ("slot", row)) for m in here]
            while len(cells) < LoadoutSettings.PER_ROW:
                cells.append(GridCell("-", self._empty_chosen(row),
                                      color=_COLOR_EMPTY, data=("slot", row)))
            rows.append(GridRow(str(row), cells, BattleStageSettings.COLOR_MANA))
        bank = [m for m in self.known if m["id"] not in loadout]
        per = LoadoutSettings.PER_ROW
        chunks = [bank[i:i + per] for i in range(0, len(bank), per)] or [[]]
        for index, chunk in enumerate(chunks):
            cells = [self._move_cell(m, ("bank", None)) for m in chunk]
            if not cells:
                cells = [GridCell("-", self._bank_chosen, color=_COLOR_EMPTY,
                                  data=("bank", None))]
            rows.append(GridRow("B" if index == 0 else "", cells, ColorSettings.GRAY))
        grid = GridMenu(rows, on_cancel=self._cancel)
        if keep is not None:
            grid.row = min(keep[0], len(rows) - 1)
            cols = [c for c, cell in enumerate(rows[grid.row].cells) if cell is not None]
            grid.col = min(cols, key=lambda c: abs(c - keep[1])) if cols else 0
        return grid

    def _move_cell(self, move: dict[str, Any], where: tuple[str, int | None]) -> GridCell:
        """A technique's cell, in its element's colour, yellow while held."""
        style = ColorSettings.ELEMENT_TEXT_STYLES.get(move["element"], {})
        held = self.held is not None and self.held["id"] == move["id"]
        return GridCell(
            short_move_name(move), lambda move=move: self._move_chosen(move),
            color=_COLOR_HELD if held else style.get("color"),
            glow=None if held else style.get("glow"),
            glow_radius=style.get("glow_radius", 3),
            glow_alpha=style.get("glow_alpha", 90),
            data=(where[0], where[1], move),
        )

    def _rebuild(self) -> None:
        """Redraw the grid after a change, keeping the cursor where it was."""
        self.grid = self._build_grid(keep=(self.grid.row, self.grid.col))

    # ------------------------------------------------------------------
    # CHOICES
    # ------------------------------------------------------------------

    def _toggle_stance(self) -> None:
        """Start fights in the other stance."""
        if len(self.stances) >= 2:
            self.member.stance = 1 - self.member.stance
            self._rebuild()

    def _cursor_place(self) -> tuple[str, int | None]:
        """Return where the cursor is: ("slot", row), ("bank", None) or ("stance", None)."""
        cell = self.grid.current
        data = cell.data if cell is not None else ("stance", None)
        return data[0], data[1]

    def _move_chosen(self, move: dict[str, Any]) -> None:
        """Pick a technique up, or put the held one down here, swapping."""
        if self.held is None:
            self.held = move
            self._rebuild()
            return
        if self.held["id"] == move["id"]:
            self.held = None
            self._rebuild()
            return
        kind, row = self._cursor_place()
        if kind == "bank":
            self._bank_chosen()
            return
        self._put(row, swap_with=move)

    def _empty_chosen(self, row: int):
        """Return the action for an empty slot in ``row``."""
        def choose() -> None:
            if self.held is not None:
                self._put(row)
        return choose

    def _bank_chosen(self) -> None:
        """Set the held technique aside in the bank."""
        if self.held is None:
            return
        loadout = dict(self.member.loadout or {})
        loadout.pop(self.held["id"], None)
        self.member.loadout = loadout
        self.held = None
        self._rebuild()

    def _put(self, row: int, swap_with: dict[str, Any] | None = None) -> None:
        """Put the held technique in ``row``; ``swap_with`` goes where it came from."""
        held = self.held
        if held is None or row not in reach(held):
            self.gm.audio.play("menu_move")
            return
        loadout = dict(self.member.loadout or {})
        came_from = loadout.pop(held["id"], None)
        if swap_with is not None:
            loadout.pop(swap_with["id"], None)
            if came_from is not None and came_from in reach(swap_with):
                loadout[swap_with["id"]] = came_from
        loadout[held["id"]] = row
        self.member.loadout = loadout
        self.held = None
        self._rebuild()

    def _cancel(self) -> None:
        """Drop what is held, or go back to the party screen."""
        if self.held is not None:
            self.held = None
            self._rebuild()
            return
        self.gm.scene_stack.pop()

    # ------------------------------------------------------------------
    # INPUT AND DRAWING
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Four-way cursor; confirm picks up and puts down; cancel backs out."""
        grid = self.grid
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            grid.cancel()
        elif input_map.is_confirm(event):
            self.gm.audio.play("menu_select")
            grid.confirm()
        elif input_map.is_up(event):
            if grid.move_up():
                self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            if grid.move_down():
                self.gm.audio.play("menu_move")
        elif input_map.is_left(event):
            if grid.move_left():
                self.gm.audio.play("menu_move")
        elif input_map.is_right(event):
            if grid.move_right():
                self.gm.audio.play("menu_move")

    def render(self, surface: pygame.Surface) -> None:
        render_scene_background(self, surface)
        # The whole screen is one ocean-blue window (D-461).
        draw_window(surface, surface.get_rect())
        text_renderer.draw_text(
            surface, short_name(self.member.id), _HEADING_POSITION,
            color=ColorSettings.WHITE, size=FontSettings.SIZE_HEADING,
        )
        self.grid.render(
            surface, _GRID_POSITION, row_height=_ROW_HEIGHT,
            max_rows=(_FOOTER_Y - _GRID_POSITION[1]) // _ROW_HEIGHT,
            label_width=UISettings.ABILITY_LABEL_WIDTH,
            col_width=UISettings.ABILITY_COL_WIDTH,
        )
        lines, color = self._footer()
        for index, line in enumerate(lines[:2]):
            text_renderer.draw_text(
                surface, line, (_FOOTER_X, _FOOTER_Y + index * _ROW_HEIGHT),
                color=color, size=FontSettings.SIZE_SMALL,
            )

    def _footer(self) -> tuple[list[str], tuple[int, int, int]]:
        """Two lines about the highlighted or held technique, and their colour."""
        font = text_renderer.get_font(FontSettings.SIZE_SMALL)
        kind, row = self._cursor_place()
        cell = self.grid.current
        if self.held is not None:
            if kind == "slot" and row not in reach(self.held):
                rows = reach(self.held)
                where = f"row {rows[0]}" if len(rows) == 1 else f"rows {rows[0]} to {rows[-1]}"
                return [f"{self.held['name']}: only {where}"], _COLOR_NO
            if kind == "slot":
                return [f"Put {self.held['name']} in row {row}",
                        self._strength(self.held, row)], _COLOR_HELD
            if kind == "bank":
                return [f"Set {self.held['name']} aside"], _COLOR_HELD
        if kind == "stance":
            return [], ColorSettings.GRAY
        move = cell.data[2] if cell is not None and len(cell.data) > 2 else None
        if move is None:
            return [], ColorSettings.GRAY
        here = row if kind == "slot" else home_row(move)
        text = f"{move['name']}. {self._strength(move, here)} {move.get('description', '')}"
        return text_renderer.wrap(text.strip(), font, _FOOTER_WIDTH), ColorSettings.WHITE

    @staticmethod
    def _strength(move: dict[str, Any], row: int) -> str:
        """How strong ``move`` is in ``row``, in a few words."""
        power = move.get("power")
        if move.get("upcast") == "power" and power:
            amount = round(power * row / home_row(move))
            word = "Heals" if move.get("effect") == "cure" else "Power"
            return f"Row {row}: {word} {amount}."
        if move.get("upcast") == "gift":
            return f"Row {row}: Gives {grown(move, row)['gift']} mana."
        if power:
            word = "Heals" if move.get("effect") == "cure" else "Power"
            return f"Row {row}: {word} {power}."
        return f"Row {row}."
