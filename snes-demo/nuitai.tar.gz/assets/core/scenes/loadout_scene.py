"""One character's techniques: the starting stance and the slots by mana row.

ELEMENT on the field menu (D-455), laid out as Final Fantasy VI's Magic
screen (Frankie, 10/23): a top box with the portrait, first name, role and
HP; the grid in the middle; a window along the bottom saying what the
highlighted technique does.

Pushed by the field menu once a member is picked; L1 and R1 switch to the
previous or next member who travels (Frankie, 10/23). The browser battle's Equip tab
(D-339) in the pygame game's terms:

* The stance the character starts each fight in (D-285, D-286) sits in
  the top box with the element icons; up from the first row reaches it,
  and confirm switches it.
* Rows 1 to 7 are the mana rows, three slots each, shared by both
  stances (D-318 to D-320). A technique sits in its own row or, if it
  can grow, any higher row, where it does more and costs more.
* The last row is the bank: what they know and are not taking.

Confirm on a technique picks it up; confirm on a slot puts it there,
swapping with whatever was in it; confirm on the bank sets it aside.
The bottom window reads out the highlighted technique: one plain sentence,
then its number for the row it sits in, never its name or the row, since
both are on screen (Frankie, 10/23; D-450: descriptions live here, not in
the fight).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pygame

from core.factories import first_loadout, known_moves, stance_numbers
from core.scene import Scene
from core.shared import by_id, role, short_name
from settings import (
    BattleStageSettings,
    ColorSettings,
    FontSettings,
    LoadoutSettings,
    ScreenSettings,
    UISettings,
)
from systems.loadout import checked, help_lines, home_row, open_slots, reach
from ui import input_map, text_renderer
from ui.element_tag import tag_elements, tag_surface
from ui.grid_menu import GridCell, GridMenu, GridRow, short_move_name
from ui.window import draw_window
from utils.graphics import load_element_icon, load_portrait
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


# Final Fantasy VI's Magic screen (Frankie, 10/23), every edge and word on
# the 8 pixel grid so the cartridge draws them in the same places.
_TOP_RECT = pygame.Rect(0, 0, 256, 64)          # Portrait, name, HP, role, stance.
_PORTRAIT_POS = (8, 8)
_TOP_TEXT_X = 64
_HP_X = 128                  # HP beside the name, on the first line.
# The stance in the top box beside the portrait (Frankie, 10/23): STANCE in
# white and its name in its element's color on the third line, the two
# element icons, the starting one boxed, at the right of the second.
_STANCE_Y = 40
_STANCE_NAME_X = 120
_ICONS_X = 200
_ICONS_Y = 20
_ICON_STEP = 26
_GRID_RECT = pygame.Rect(0, 64, 256, 112)
_GRID_POSITION = (14, 72)
_GRID_BOTTOM = 168
_ROW_HEIGHT = 16
_BOTTOM_RECT = pygame.Rect(0, 176, 256, 48)     # What the technique does: the "footer".
_FOOTER_Y = _BOTTOM_RECT.top + 8
_FOOTER_X = 16
_FOOTER_WIDTH = ScreenSettings.WIDTH - 2 * _FOOTER_X
_COLOR_HELD = ColorSettings.YELLOW  # Every name is white, so the held one is yellow.
_COLOR_EMPTY = ColorSettings.DARK_GRAY
_COLOR_NO = (255, 110, 100)    # The footer when a row cannot take the held one.
_LABEL_WIDTH = 24   # The tier's number to its first slot's tag: room for the box's edge.


class LoadoutScene(Scene):
    """Choose a character's starting stance and where each technique sits."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", member: "PartyMember") -> None:
        super().__init__(gm)
        self._load(member)

    def _load(self, member: "PartyMember") -> None:
        """Show ``member``'s techniques, the cursor on the first row of them."""
        gm = self.gm
        self.member = member
        self.known = known_moves(member.id, member.elements, gm.party.flags)
        self.by_id = {m["id"]: m for m in self.known}
        self.stances = by_id("characters").get(member.id, {}).get("stances", [])
        self.slots = open_slots(gm.party.flags)
        member.loadout = checked(member.loadout, self.known, first_loadout(member.id, gm.party.flags),
                                 self.slots)
        self.held: dict[str, Any] | None = None
        self.grid = self._build_grid()
        if self.stances and len(self.grid.rows) > 1:
            self.grid.row = 1

    def _switch(self, step: int) -> None:
        """L1 and R1: the previous or next member who travels (Frankie, 10/23)."""
        members = self.gm.party.members
        if len(members) < 2:
            return
        index = next((i for i, m in enumerate(members) if m is self.member), 0)
        self._load(members[(index + step) % len(members)])
        self.gm.audio.play("menu_move")

    # ------------------------------------------------------------------
    # THE GRID
    # ------------------------------------------------------------------

    def _build_grid(self, keep: tuple[int, int] | None = None) -> GridMenu:
        """Lay out the stance (drawn in the top box), the seven rows and the bank."""
        rows: list[GridRow] = []
        if self.stances:
            stance = self.stances[self.member.stance]
            style = ColorSettings.ELEMENT_TEXT_STYLES.get(stance["element"], {})
            rows.append(GridRow("", [GridCell(
                f"Stance: {stance['name']}", self._toggle_stance,
                color=style.get("color"), glow=style.get("glow"),
                glow_radius=style.get("glow_radius", 3),
                glow_alpha=style.get("glow_alpha", 90),
                data=("stance", None),
            )]))
        loadout = self.member.loadout or {}
        for row in range(1, LoadoutSettings.ROWS + 1):
            here = [m for m in self.known if loadout.get(m["id"]) == row]
            cells = [self._move_cell(m, ("slot", row), boxed=True) for m in here]
            while len(cells) < self.slots[row - 1]:
                cells.append(GridCell("", self._empty_chosen(row), boxed=True, data=("slot", row)))
            if not cells:
                continue    # A tier no boss has opened is not drawn (Frankie, 11/1).
            rows.append(GridRow(str(row), cells, BattleStageSettings.COLOR_MANA))
        bank = [m for m in self.known if m["id"] not in loadout]
        per = LoadoutSettings.PER_ROW
        chunks = [bank[i:i + per] for i in range(0, len(bank), per)] or [[]]
        for index, chunk in enumerate(chunks):
            cells = [self._move_cell(m, ("bank", None)) for m in chunk]
            if not cells:
                cells = [GridCell("-", self._bank_chosen, color=_COLOR_EMPTY,
                                  data=("bank", None))]
            rows.append(GridRow("B" if index == 0 else "", cells, ColorSettings.GRAY))
        grid = GridMenu(rows, on_cancel=self._cancel)
        if keep is not None:
            grid.row = min(keep[0], len(rows) - 1)
            cols = [c for c, cell in enumerate(rows[grid.row].cells) if cell is not None]
            grid.col = min(cols, key=lambda c: abs(c - keep[1])) if cols else 0
        return grid

    def _move_cell(self, move: dict[str, Any], where: tuple[str, int | None], boxed: bool = False) -> GridCell:
        """A technique's cell: plain white after its element tag (Frankie, 10/23), yellow while held."""
        held = self.held is not None and self.held["id"] == move["id"]
        return GridCell(
            short_move_name(move), lambda move=move: self._move_chosen(move),
            color=_COLOR_HELD if held else ColorSettings.WHITE,
            tag=None if boxed else tag_surface(*tag_elements(move, self.member.elements)),
            data=(where[0], where[1], move), boxed=boxed,
            tint=tag_elements(move, self.member.elements) if boxed else None,
        )

    def _rebuild(self) -> None:
        """Redraw the grid after a change, keeping the cursor where it was."""
        self.grid = self._build_grid(keep=(self.grid.row, self.grid.col))

    # ------------------------------------------------------------------
    # CHOICES
    # ------------------------------------------------------------------

    def _toggle_stance(self) -> None:
        """Start fights in the other stance."""
        if len(self.stances) >= 2:
            self.member.stance = 1 - self.member.stance
            self._rebuild()

    def _cursor_place(self) -> tuple[str, int | None]:
        """Return where the cursor is: ("slot", row), ("bank", None) or ("stance", None)."""
        cell = self.grid.current
        data = cell.data if cell is not None else ("stance", None)
        return data[0], data[1]

    def _move_chosen(self, move: dict[str, Any]) -> None:
        """Pick a technique up, or put the held one down here, swapping."""
        if self.held is None:
            self.held = move
            self._rebuild()
            return
        if self.held["id"] == move["id"]:
            self.held = None
            self._rebuild()
            return
        kind, row = self._cursor_place()
        if kind == "bank":
            self._bank_chosen()
            return
        self._put(row, swap_with=move)

    def _empty_chosen(self, row: int):
        """Return the action for an empty slot in ``row``."""
        def choose() -> None:
            if self.held is not None:
                self._put(row)
        return choose

    def _bank_chosen(self) -> None:
        """Set the held technique aside in the bank."""
        if self.held is None:
            return
        loadout = dict(self.member.loadout or {})
        loadout.pop(self.held["id"], None)
        self.member.loadout = loadout
        self.held = None
        self._rebuild()

    def _put(self, row: int, swap_with: dict[str, Any] | None = None) -> None:
        """Put the held technique in ``row``; ``swap_with`` goes where it came from."""
        held = self.held
        if held is None or row not in reach(held) or self.slots[row - 1] == 0:
            self.gm.audio.play("menu_move")
            return
        loadout = dict(self.member.loadout or {})
        came_from = loadout.pop(held["id"], None)
        if swap_with is not None:
            loadout.pop(swap_with["id"], None)
            if came_from is not None and came_from in reach(swap_with):
                loadout[swap_with["id"]] = came_from
        loadout[held["id"]] = row
        self.member.loadout = loadout
        self.held = None
        self._rebuild()

    def _cancel(self) -> None:
        """Drop what is held, or go back to the party screen."""
        if self.held is not None:
            self.held = None
            self._rebuild()
            return
        self.gm.scene_stack.pop()

    # ------------------------------------------------------------------
    # INPUT AND DRAWING
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Four-way cursor; confirm picks up and puts down; cancel backs out."""
        grid = self.grid
        if input_map.is_l1(event) or input_map.is_r1(event):
            self._switch(-1 if input_map.is_l1(event) else 1)
        elif input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            grid.cancel()
        elif input_map.is_confirm(event):
            self.gm.audio.play("menu_select")
            grid.confirm()
        elif input_map.is_up(event):
            if grid.move_up():
                self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            if grid.move_down():
                self.gm.audio.play("menu_move")
        elif input_map.is_left(event):
            if grid.move_left():
                self.gm.audio.play("menu_move")
        elif input_map.is_right(event):
            if grid.move_right():
                self.gm.audio.play("menu_move")

    def render(self, surface: pygame.Surface) -> None:
        render_scene_background(self, surface)
        for rect in (_TOP_RECT, _GRID_RECT, _BOTTOM_RECT):
            draw_window(surface, rect)
        size = FontSettings.SIZE_BODY
        white = ColorSettings.WHITE
        frame = pygame.Rect(_PORTRAIT_POS, (UISettings.PORTRAIT_SIZE, UISettings.PORTRAIT_SIZE))
        surface.blit(load_portrait(self.member.id), frame.topleft)
        pygame.draw.rect(surface, white, frame.inflate(2, 2), 1)
        _, shown, top = stance_numbers(self.member)
        text_renderer.draw_text(surface, short_name(self.member.id), (_TOP_TEXT_X, 8), color=white, size=size)
        text_renderer.draw_text(surface, f"HP {shown}/{top}", (_HP_X, 8), color=white, size=size)
        text_renderer.draw_text(surface, role(self.member.id), (_TOP_TEXT_X, 24), color=white, size=size)
        self._render_stance(surface)
        lines, color = self._footer()
        for row, line in enumerate(lines[:2]):
            text_renderer.draw_text(surface, line, (_FOOTER_X, _FOOTER_Y + row * 16), color=color, size=size)
        self.grid.render(
            surface, _GRID_POSITION, row_height=_ROW_HEIGHT,
            max_rows=(_GRID_BOTTOM - _GRID_POSITION[1]) // _ROW_HEIGHT,
            label_width=_LABEL_WIDTH,
            col_width=UISettings.ABILITY_COL_WIDTH,
            hidden_rows=1 if self.stances else 0,
        )

    def _render_stance(self, surface: pygame.Surface) -> None:
        """STANCE and the stance's name in its color, the element icons, the cursor when it is here."""
        if not self.stances:
            return
        size = FontSettings.SIZE_BODY
        stance = self.stances[self.member.stance]
        text_renderer.draw_text(surface, "Stance", (_TOP_TEXT_X, _STANCE_Y), color=ColorSettings.WHITE, size=size)
        style = ColorSettings.ELEMENT_TEXT_STYLES.get(stance["element"], {})
        text_renderer.draw_text(surface, stance["name"], (_STANCE_NAME_X, _STANCE_Y), size=size, **style)
        icon_size = UISettings.ELEMENT_ICON_SIZE
        for slot, element in enumerate(self.member.elements):
            x = _ICONS_X + slot * _ICON_STEP
            icon = load_element_icon(element)
            if icon is not None:
                surface.blit(icon, (x, _ICONS_Y))
            if element == stance["element"]:
                pygame.draw.rect(surface, ColorSettings.YELLOW,
                                 pygame.Rect(x - 2, _ICONS_Y - 2, icon_size + 4, icon_size + 4), 2, border_radius=2)
        if self.grid.row == 0:
            text_renderer.draw_pointer(surface, (_TOP_TEXT_X - UISettings.MENU_LABEL_OFFSET, _STANCE_Y + size // 2),
                                       ColorSettings.YELLOW)

    def _footer(self) -> tuple[list[str], tuple[int, int, int]]:
        """The help window: the highlighted or held technique's sentence and its number
        for the row it is in, or would go to (Frankie, 10/23), and their colour."""
        kind, row = self._cursor_place()
        cell = self.grid.current
        if self.held is not None:
            if kind == "slot" and row not in reach(self.held):
                return ["It does not fit here."], _COLOR_NO
            if kind == "slot":
                return help_lines(self.held, row), _COLOR_HELD
            if kind == "bank":
                return ["Set it aside."], _COLOR_HELD
        if kind == "stance":
            return [], ColorSettings.GRAY
        move = cell.data[2] if cell is not None and len(cell.data) > 2 else None
        if move is None:
            return [], ColorSettings.GRAY
        return help_lines(move, row if kind == "slot" else home_row(move)), ColorSettings.WHITE
