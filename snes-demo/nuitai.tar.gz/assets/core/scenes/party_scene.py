"""The PARTY status screen -- selectable roster with a stats panel.

Pushed by [core/scenes/menu_scene.py](menu_scene.py) when the player
picks PARTY. The left column lists each member's name, current /
max HP, and element pair; up/down moves the cursor between members
and the right column shows the highlighted member's full stat block.
Cancel (B / Backspace) pops it back to the system menu.

Confirm opens the highlighted member's techniques and starting stance
(``loadout_scene.py``). The numbers in the right
panel are the same ones battle uses: each member's stats are derived
from their two elements by ``core/stats.py``.
"""

from __future__ import annotations

import os
import sys
from typing import TYPE_CHECKING

if __package__ is None or __package__ == "":
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

import pygame

from core.scene import Scene
from core.elements import Element
from core.shared import by_id, short_name
from core.factories import stance_numbers
from settings import ColorSettings, FontSettings, ScreenSettings, UISettings
from ui import input_map, text_renderer
from ui.layout import DebugOverlay, RosterRowLayout
from ui.window import draw_window
from utils.backgrounds import render_scene_background
from utils.graphics import load_element_icon, load_portrait

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


# Positions on the 256 by 224 screen. Text rows are 16 pixels apart.
_ROSTER_TOP_Y = 6
# A row is the 48 pixel portrait frame plus a little air; four members
# fill the page (Maika joined, 10/18).
_ROSTER_ROW_HEIGHT = 54
# Room on the left for the cursor triangle.
_ROSTER_LEFT_X = 12
# The frame drawn round a portrait, and the space to the text.
_PORTRAIT_BORDER = 1

# Stats panel layout (right column): the highlighted member's full
# name, then a table of stats. The roster already shows the elements.
_STATS_PANEL_LEFT_X = 128
_STATS_PANEL_TOP_Y = 32
_STATS_PANEL_WIDTH = 120
_STATS_PANEL_HEIGHT = 176
_STATS_PANEL_BORDER = 1
_STATS_PADDING = 6              # Room for a 14 letter name across the panel.
_STATS_LABEL_X = _STATS_PANEL_LEFT_X + _STATS_PADDING
_STATS_HEADER_Y = _STATS_PANEL_TOP_Y + 8
_STATS_STANCE_Y = _STATS_HEADER_Y + 16  # The stance's name, in its element's colour.
_STATS_ROW_TOP_Y = _STATS_HEADER_Y + 32
_STATS_ROW_HEIGHT = 16

# Stat rows displayed on the right panel. Level is left out: nobody
# levels yet, and the rows that fit are spoken for.
_STAT_ROWS: tuple[tuple[str, str], ...] = (
    ("hp", "HP"),
    ("strength", "Strength"),
    ("magic", "Magic"),
    ("vitality", "Vitality"),
    ("spirit", "Spirit"),
    ("speed", "Speed"),
    ("accuracy", "Accuracy"),
    ("evasion", "Evasion"),
)

_CURSOR_COLOR = ColorSettings.YELLOW


class PartyScene(Scene):
    """Selectable roster -- left list, right stat panel."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", cursor: int = 0) -> None:
        """Open on member ``cursor``, the one chosen in the field menu."""
        super().__init__(gm)
        self._cursor: int = cursor

    def handle_event(self, event: pygame.event.Event) -> None:
        """Up/down moves the selector; cancel pops back to the menu."""
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
            return
        members = self.gm.party.members
        if not members:
            return
        if input_map.is_confirm(event):
            # A member's techniques and starting stance.
            from core.scenes.loadout_scene import LoadoutScene
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.push(LoadoutScene(self.gm, members[self._cursor]))
            return
        if input_map.is_left(event) or input_map.is_right(event):
            # The other stance: the one they start the next fight in (D-463).
            member = members[self._cursor]
            if len(self._stances(member)) > 1:
                member.stance = 1 - member.stance
                self.gm.audio.play("menu_move")
            return
        if input_map.is_up(event):
            self._cursor = (self._cursor - 1) % len(members)
            self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            self._cursor = (self._cursor + 1) % len(members)
            self.gm.audio.play("menu_move")

    def render(self, surface: pygame.Surface) -> None:
        render_scene_background(self, surface)
        # The whole screen is one ocean-blue window (D-461).
        draw_window(surface, surface.get_rect())
        for index, member in enumerate(self.gm.party.members):
            self._render_member(surface, member, index)
        if self.gm.party.members:
            selected = self.gm.party.members[self._cursor]
            self._render_stats_panel(surface, selected)

    def _render_member(
        self, surface: pygame.Surface, member: "PartyMember", index: int
    ) -> None:
        """Render one member's status block at the indexed row."""
        top_y = _ROSTER_TOP_Y + index * _ROSTER_ROW_HEIGHT
        layout = RosterRowLayout(left_x=_ROSTER_LEFT_X, top_y=top_y)

        if index == self._cursor:
            triangle = layout.selection_triangle()
            pygame.draw.polygon(surface, _CURSOR_COLOR, triangle)
            DebugOverlay.polygon(
                surface, triangle, "cursor", DebugOverlay.COLOR_CURSOR,
            )

        portrait = load_portrait(member.id)
        portrait_rect = layout.portrait_rect
        surface.blit(portrait, portrait_rect.topleft)
        # The frame: yellow round the highlighted member, white round
        # the rest (Frankie, 10/7: portraits need borders).
        pygame.draw.rect(
            surface,
            _CURSOR_COLOR if index == self._cursor else ColorSettings.WHITE,
            portrait_rect.inflate(2 * _PORTRAIT_BORDER, 2 * _PORTRAIT_BORDER),
            _PORTRAIT_BORDER,
        )
        DebugOverlay.rect(
            surface, portrait_rect, "portrait", DebugOverlay.COLOR_PORTRAIT,
        )

        # HP has moved to the stats panel; the left column is purely
        # identity (first name + element icons; the full name heads the
        # stats panel). Dead members still flash red so a wipe is
        # visible at a glance.
        name_color = (
            ColorSettings.RED if member.current_hp <= 0 else ColorSettings.WHITE
        )
        text_renderer.draw_text(
            surface,
            short_name(member.id),
            layout.name_pos,
            color=name_color,
            size=FontSettings.SIZE_BODY,
        )
        DebugOverlay.point(
            surface, layout.name_pos, "name", DebugOverlay.COLOR_TEXT,
        )
        DebugOverlay.point(
            surface, layout.element_pos, "elements", DebugOverlay.COLOR_TEXT,
        )
        # The two element icons, the stance they start in boxed in
        # thick yellow, as in the field menu (D-461).
        stance = self._stance_element(member)
        x, y = layout.element_pos
        size = UISettings.ELEMENT_ICON_SIZE
        for slot, element_id in enumerate(member.elements):
            left = x + slot * (size + 8)
            icon = load_element_icon(element_id)
            if icon is not None:
                surface.blit(icon, (left, y))
            if stance is not None and element_id == stance.value:
                pygame.draw.rect(
                    surface, _CURSOR_COLOR,
                    pygame.Rect(left - 2, y - 2, size + 4, size + 4), 2, border_radius=2,
                )

    def _render_element_line(
        self,
        surface: pygame.Surface,
        element_ids: tuple,
        pos: tuple[int, int],
        *,
        show_word: bool = True,
    ) -> None:
        """Draw a multi-color element-pair line starting at ``pos``.

        For each element id the renderer prefers the per-element icon
        from ``assets/graphics/icons/<id>.png`` (loaded lazily by
        ``utils.graphics.load_element_icon``). When an icon exists and
        ``show_word`` is False, only the icon is drawn (used by the
        roster on the left of the party screen and by the battle
        roster). When ``show_word`` is True the word is drawn directly
        after the icon (used by the stats panel on the right). Elements
        without an icon yet fall back to the word so partial icon
        coverage degrades gracefully.

        Entries are separated by a gray "+" so the player can tell at
        a glance that a member has more than one affinity.

        An icon is taller than a text row. Beside a word it is centred
        on the word; alone (``show_word`` False) its top sits on the
        line, so the row above stays clear.
        """
        font = text_renderer.get_font(FontSettings.SIZE_SMALL)
        x, y = pos
        separator = "+"
        icon_y = y + (UISettings.ELEMENT_ICON_Y_OFFSET if show_word else 0)
        for i, element_id in enumerate(element_ids):
            style = ColorSettings.ELEMENT_TEXT_STYLES.get(
                element_id, {"color": ColorSettings.WHITE}
            )
            icon = load_element_icon(element_id)
            if icon is not None:
                surface.blit(icon, (x, icon_y))
                x += UISettings.ELEMENT_ICON_SIZE
                if show_word:
                    x += UISettings.ELEMENT_ICON_WORD_GAP
                    text_renderer.draw_text(
                        surface, element_id, (x, y),
                        size=FontSettings.SIZE_SMALL,
                        **style,
                    )
                    x += font.size(element_id.upper())[0]
            else:
                text_renderer.draw_text(
                    surface, element_id, (x, y),
                    size=FontSettings.SIZE_SMALL,
                    **style,
                )
                x += font.size(element_id.upper())[0]
            if i < len(element_ids) - 1:
                # The joining "+" sits level with the middle of the icons,
                # a small gap either side.
                plus_y = (
                    y if show_word
                    else icon_y + (UISettings.ELEMENT_ICON_SIZE - FontSettings.LETTER_WIDTH) // 2
                )
                x += UISettings.ELEMENT_ICON_GAP
                text_renderer.draw_text(
                    surface, separator, (x, plus_y),
                    color=ColorSettings.GRAY, size=FontSettings.SIZE_SMALL,
                )
                x += font.size(separator.upper())[0] + UISettings.ELEMENT_ICON_GAP

    @staticmethod
    def _stances(member: "PartyMember") -> list[dict]:
        """Return ``member``'s two stances from the shared file."""
        return by_id("characters").get(member.id, {}).get("stances", [])

    def _stance_element(self, member: "PartyMember") -> Element | None:
        """Return the element of the stance ``member`` starts a fight in."""
        stances = self._stances(member)
        if not stances:
            return None
        return Element(stances[member.stance if 0 <= member.stance < len(stances) else 0]["element"])

    def _render_stats_panel(
        self, surface: pygame.Surface, member: "PartyMember"
    ) -> None:
        """Paint the right-side stat panel for ``member``, in the stance they start in.

        The stance's element counts twice and the other not at all, HP
        keeping its share (D-365), so the numbers move when it changes.
        """
        stance = self._stance_element(member)
        points, stance_hp, stance_max = stance_numbers(member)
        panel_rect = pygame.Rect(
            _STATS_PANEL_LEFT_X,
            _STATS_PANEL_TOP_Y,
            _STATS_PANEL_WIDTH,
            _STATS_PANEL_HEIGHT,
        )
        draw_window(
            surface, panel_rect, border=ColorSettings.WHITE, fill=None,
            thickness=_STATS_PANEL_BORDER,
        )
        DebugOverlay.rect(
            surface, panel_rect, "stats panel", DebugOverlay.COLOR_PANEL,
        )
        text_renderer.draw_text(
            surface,
            member.name,
            (_STATS_LABEL_X, _STATS_HEADER_Y),
            color=ColorSettings.WHITE,
            size=FontSettings.SIZE_BODY,
        )
        stances = self._stances(member)
        if stance is not None:
            name = next(s["name"] for s in stances if s["element"] == stance.value)
            style = ColorSettings.ELEMENT_TEXT_STYLES.get(stance.value, {})
            text_renderer.draw_text(
                surface, name, (_STATS_LABEL_X, _STATS_STANCE_Y),
                color=style.get("color", ColorSettings.WHITE), size=FontSettings.SIZE_BODY,
            )
        for row_index, (key, label) in enumerate(_STAT_ROWS):
            y = _STATS_ROW_TOP_Y + row_index * _STATS_ROW_HEIGHT
            text_renderer.draw_text(
                surface,
                label,
                (_STATS_LABEL_X, y),
                color=ColorSettings.GRAY,
                size=FontSettings.SIZE_BODY,
            )
            if key == "hp":
                value_text = f"{stance_hp}/{stance_max}"
            else:
                value_text = str(points.get(key, 0))
            # Values end at the panel's right padding, so the figures
            # line up by their last digit and clear the longest label.
            value_x = (
                panel_rect.right - _STATS_PANEL_BORDER - _STATS_PADDING
                - text_renderer.text_width(value_text, FontSettings.SIZE_BODY)
            )
            text_renderer.draw_text(
                surface,
                value_text,
                (value_x, y),
                color=ColorSettings.WHITE,
                size=FontSettings.SIZE_BODY,
            )
