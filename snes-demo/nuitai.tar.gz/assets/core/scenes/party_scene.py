"""The STATUS screen: one member's page, Final Fantasy VI's (Frankie, 10/23).

Pushed by [core/scenes/menu_scene.py](menu_scene.py) when the player
picks Status and a member. One page per member, paged left and right
through everyone who travels: the portrait, then beside it the first
name, the role (the title from their wiki article) and HP; no Mana,
since it is always 0/7 outside a fight (Frankie, 10/27). Under it the
eight stats on the left, each name in its color with the stances' black
edge (Frankie, 10/27), each with its EXP under it: the hidden growth
meter (``systems/battle.py``, ``_fill``) as 10 notches, one per 10
points, in the stat's color. On the right their Skill (the signature
command) and the two stances, the one they start a fight in on top in
its element's color, and under them the EXP of the stat under the
cursor, Morrowind style: "EXP to next" over the stat's name over a dark
red bar reading "56/100", the points to the stat's next point (Frankie,
10/27). There are no levels (D-497). Up and down
move the cursor over the stats; confirm still switches the stance they
start in, wherever the cursor is, and the numbers move with it (D-463).
Cancel pops back to the field menu.

The numbers are the ones battle uses: the stance's element counts twice
and the other not at all, HP keeping its share (D-365), plus what the
member has grown (``core/factories.stance_numbers``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.factories import first_loadout, known_moves, stance_numbers
from core.scene import Scene
from core.shared import by_id, role, short_name, skill_for
from core.stats import STAT_NAMES
from settings import ColorSettings, FontSettings, UISettings
from systems import mastery
from systems.battle import _GROWTH
from systems.loadout import checked, open_slots, slot_grid
from ui.element_tag import tag_color, tag_elements
from ui import input_map, text_renderer
from ui.window import draw_window
from utils.backgrounds import render_scene_background
from utils.graphics import load_portrait

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


# Every word on the 8 pixel grid, so the cartridge draws them in the same places.
_PORTRAIT_POS = (16, 16)
_TOP_X = 80                 # Name, role and HP, beside the portrait.
_TOP_Y = 16
_LINE = 16
_STATS_X = 16
_STATS_TOP_Y = 72           # Up into the row Mana left.
_STATS_RIGHT_X = 136        # Where the numbers end.
_RIGHT_X = 144              # The Skill, the stances and the EXP bar.
_SKILL_LABEL_Y = 72
_STANCE_LABEL_Y = 112
_EXP_LABEL_Y = 168          # "EXP to next", grey like "Skill" and "Stance".
_EXP_NAME_Y = 184           # The stat's name in its color.
_EXP_BAR_Y = 196

# A stat's EXP under its line: 10 notches, one per 10 points, segmented like
# the battle's bars, as wide as the stats column (Frankie, 10/27).
_NOTCHES = 10
_NOTCH_W = 11
_NOTCH_GAP = 1
_NOTCH_H = 3
_NOTCH_DY = 10              # Below the top of the stat's line.
_NOTCH_OFF = (25, 35, 70)

def draw_notches(surface: pygame.Surface, pos: tuple[int, int], lit: int, color: tuple[int, int, int]) -> None:
    """The notched bar from ``pos``: ``lit`` of the 10 notches in ``color``, the rest dark navy.

    The Status page's stat EXP and the Equip screen's weapon mastery share it.
    """
    x, y = pos
    for index in range(_NOTCHES):
        pygame.draw.rect(surface, color if index < lit else _NOTCH_OFF,
                         (x + index * (_NOTCH_W + _NOTCH_GAP), y, _NOTCH_W, _NOTCH_H))


# The Morrowind bar: a gold frame, black inside, dark red fill, the points
# centered (mockup game/pygame/docs/design/stat-meter-preview.svg).
# The element slots (Frankie, 11/1): a box per open slot, a row per tier, top right
# beside the name, every row lined up on the left. Locked slots are not drawn, so the shape grows as bosses fall.
_GRID_LEFT = 206            # Where every row starts, the first box of each under the first of tier 1.
_GRID_TOP = 14
_BOX_W, _BOX_H, _BOX_GAP = 10, 5, 2
_BOX_EMPTY = (120, 124, 132)
_BOX_EDGE = (200, 208, 230)   # Light, so the black shadow box shows on the dark blue.
_EXP_BAR_W = 96
_EXP_BAR_H = 12
_EXP_FRAME = (200, 164, 106)
_EXP_FILL = (150, 36, 24)
_EXP_TEXT = (240, 226, 192)

_STAT_ROWS: tuple[tuple[str, str], ...] = tuple(STAT_NAMES.items())


def stances(member_id: str) -> list[dict]:
    """Return a member's two stances from the shared file."""
    return by_id("characters").get(member_id, {}).get("stances", [])


class PartyScene(Scene):
    """One member's status page, paged left and right."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", cursor: int = 0) -> None:
        """Open on member ``cursor``, the one chosen in the field menu."""
        super().__init__(gm)
        self._cursor: int = cursor
        self._stat_row: int = 0     # The stat under the cursor, kept while paging.

    def handle_event(self, event: pygame.event.Event) -> None:
        """Left and right, or L1 and R1, page; up and down pick a stat; confirm switches the starting stance; cancel goes back."""
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
            return
        members = self.gm.party.members
        if not members:
            return
        if input_map.is_confirm(event):
            member = members[self._cursor]
            if len(stances(member.id)) > 1:
                member.stance = 1 - member.stance
                self.gm.audio.play("menu_select")
        elif input_map.is_up(event):
            self._stat_row = (self._stat_row - 1) % len(_STAT_ROWS)
            self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            self._stat_row = (self._stat_row + 1) % len(_STAT_ROWS)
            self.gm.audio.play("menu_move")
        elif input_map.is_left(event) or input_map.is_l1(event):
            self._cursor = (self._cursor - 1) % len(members)
            self.gm.audio.play("menu_move")
        elif input_map.is_right(event) or input_map.is_r1(event):
            self._cursor = (self._cursor + 1) % len(members)
            self.gm.audio.play("menu_move")

    def render(self, surface: pygame.Surface) -> None:
        render_scene_background(self, surface)
        # The whole screen is one ocean-blue window (D-461).
        draw_window(surface, surface.get_rect())
        if self.gm.party.members:
            self._render_member(surface, self.gm.party.members[self._cursor])

    def _render_member(self, surface: pygame.Surface, member: "PartyMember") -> None:
        """Paint ``member``'s page, in the stance they start a fight in."""
        size = FontSettings.SIZE_BODY
        white, gray = ColorSettings.WHITE, ColorSettings.GRAY
        portrait = load_portrait(member.id)
        frame = pygame.Rect(_PORTRAIT_POS, (UISettings.PORTRAIT_SIZE, UISettings.PORTRAIT_SIZE))
        surface.blit(portrait, frame.topleft)
        pygame.draw.rect(surface, white, frame.inflate(2, 2), 1)
        points, shown, top = stance_numbers(member)
        lines = (
            (short_name(member.id), ColorSettings.RED if member.current_hp <= 0 else white),
            (role(member.id), white),
            (f"HP {shown}/{top}", white),
        )
        for row, (text, color) in enumerate(lines):
            text_renderer.draw_text(surface, text, (_TOP_X, _TOP_Y + row * _LINE), color=color, size=size)
        for row, (key, label) in enumerate(_STAT_ROWS):
            y = _STATS_TOP_Y + row * _LINE
            text_renderer.draw_text(surface, label, (_STATS_X, y), size=size,
                                    **ColorSettings.STAT_EDGE_STYLES[key])
            value = str(points.get(key, 0))
            text_renderer.draw_text(surface, value, (_STATS_RIGHT_X - text_renderer.text_width(value, size), y),
                                    color=white, size=size)
            self._render_notches(surface, (_STATS_X, y + _NOTCH_DY), key, member)
        text_renderer.draw_pointer(surface, (_STATS_X - 3, _STATS_TOP_Y + self._stat_row * _LINE + 3))
        text_renderer.draw_text(surface, "Skill", (_RIGHT_X, _SKILL_LABEL_Y), color=gray, size=size)
        # The Skill of the weapon type in hand (Frankie, 10/31), grey while not built.
        held = mastery.type_held(member.id, member.weapon)
        skill = skill_for(member.id, held) if held else None
        text_renderer.draw_text(surface, skill["name"] if skill else "None", (_RIGHT_X, _SKILL_LABEL_Y + _LINE),
                                color=white if skill and not skill.get("off") else gray, size=size)
        both = stances(member.id)
        if both:
            text_renderer.draw_text(surface, "Stance", (_RIGHT_X, _STANCE_LABEL_Y), color=gray, size=size)
            start = both[member.stance if 0 <= member.stance < len(both) else 0]
            # The one they start in, in its element's color with the black edge (Frankie, 10/22).
            style = ColorSettings.ELEMENT_TEXT_STYLES.get(start["element"], {})
            text_renderer.draw_text(surface, start["name"], (_RIGHT_X, _STANCE_LABEL_Y + _LINE), size=size, **style)
            for other in (s for s in both if s is not start):
                text_renderer.draw_text(surface, other["name"], (_RIGHT_X, _STANCE_LABEL_Y + 2 * _LINE),
                                        color=gray, size=size)
        self._render_slots(surface, member)
        self._render_exp(surface, member)

    def _render_slots(self, surface: pygame.Surface, member: "PartyMember") -> None:
        """Draw ``member``'s open element slots: a filled one in its element's color, a dual one in
        its two side by side, an empty one grey."""
        flags = self.gm.party.flags
        slots = open_slots(flags)
        known = known_moves(member.id, member.elements, flags)
        loadout = checked(member.loadout, known, first_loadout(member.id, flags), slots)
        for row, cells in enumerate(slot_grid(loadout, known, slots)):
            y = _GRID_TOP + row * (_BOX_H + _BOX_GAP)
            for col, move in enumerate(cells):
                x = _GRID_LEFT + col * (_BOX_W + _BOX_GAP)
                box = pygame.Rect(x, y, _BOX_W, _BOX_H)
                if move is None:
                    pygame.draw.rect(surface, _BOX_EMPTY, box)
                else:
                    first, second = tag_elements(move, member.elements)
                    if second is None:
                        pygame.draw.rect(surface, tag_color(first), box)
                    else:
                        half = _BOX_W // 2
                        pygame.draw.rect(surface, tag_color(first), (x, y, half, _BOX_H))
                        pygame.draw.rect(surface, tag_color(second), (x + half, y, _BOX_W - half, _BOX_H))
                pygame.draw.rect(surface, _BOX_EDGE, box, 1)

    def _render_notches(self, surface: pygame.Surface, pos: tuple[int, int], key: str,
                        member: "PartyMember") -> None:
        """Draw stat ``key``'s EXP as 10 notches from ``pos``, one lit per 10 points."""
        lit = int(exp_points(member, key)) * _NOTCHES // _GROWTH["meter"]
        draw_notches(surface, pos, lit, ColorSettings.STAT_TEXT_STYLES[key]["color"])

    def _render_exp(self, surface: pygame.Surface, member: "PartyMember") -> None:
        """Draw the EXP of the stat under the cursor, bottom right: its name over a Morrowind bar.

        "EXP to next" is a grey label above, like "Skill" and "Stance": there
        are no levels, so it is the EXP to the stat's next point (Frankie, 10/27).
        """
        size = FontSettings.SIZE_BODY
        key, label = _STAT_ROWS[self._stat_row]
        text_renderer.draw_text(surface, "EXP to next", (_RIGHT_X, _EXP_LABEL_Y), color=ColorSettings.GRAY, size=size)
        text_renderer.draw_text(surface, label, (_RIGHT_X, _EXP_NAME_Y), size=size,
                                **ColorSettings.STAT_EDGE_STYLES[key])
        full = int(_GROWTH["meter"])
        points = min(int(exp_points(member, key)), full)
        frame = pygame.Rect(_RIGHT_X, _EXP_BAR_Y, _EXP_BAR_W, _EXP_BAR_H)
        pygame.draw.rect(surface, (0, 0, 0), frame)
        inner = frame.inflate(-2, -2)
        inner.width = round(inner.width * points / full)
        if inner.width:
            pygame.draw.rect(surface, _EXP_FILL, inner)
        pygame.draw.rect(surface, _EXP_FRAME, frame, 1)
        text = f"{points}/{full}"
        text_renderer.draw_text(surface, text, (frame.centerx - text_renderer.text_width(text, size) // 2,
                                                frame.top + 2), color=_EXP_TEXT, size=size)


def exp_points(member: "PartyMember", key: str) -> float:
    """Return the points in ``member``'s hidden meter for stat ``key``, their EXP."""
    return member.meters.get(key, 0)
