"""The STATUS screen: one member's page, Final Fantasy VI's (Frankie, 10/23).

Pushed by [core/scenes/menu_scene.py](menu_scene.py) when the player
picks Status and a member. One page per member, paged left and right
through everyone who travels: the portrait, then beside it the first
name, the role (the title from their wiki article), HP and Mana; under
it the eight stats on the left, and on the right their TECH (the
signature command) and the two stances, the one they start a fight in
on top in its element's color. There are no levels or experience
(D-497). Confirm switches the stance they start in, and the numbers
move with it (D-463). Cancel pops back to the field menu.

The numbers are the ones battle uses: the stance's element counts twice
and the other not at all, HP keeping its share (D-365), plus what the
member has grown (``core/factories.stance_numbers``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.factories import stance_numbers
from core.scene import Scene
from core.shared import by_id, role, short_name, signature_name
from core.stats import STAT_NAMES
from settings import BattleSettings, ColorSettings, FontSettings, UISettings
from ui import input_map, text_renderer
from ui.window import draw_window
from utils.backgrounds import render_scene_background
from utils.graphics import load_portrait

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


# Every word on the 8 pixel grid, so the cartridge draws them in the same places.
_PORTRAIT_POS = (16, 16)
_TOP_X = 80                 # Name, role, HP and Mana, beside the portrait.
_TOP_Y = 16
_LINE = 16
_STATS_X = 16
_STATS_TOP_Y = 88
_STATS_RIGHT_X = 136        # Where the numbers end.
_RIGHT_X = 144              # TECH and the stances.
_TECH_LABEL_Y = 88
_STANCE_LABEL_Y = 128

_STAT_ROWS: tuple[tuple[str, str], ...] = tuple(STAT_NAMES.items())


def stances(member_id: str) -> list[dict]:
    """Return a member's two stances from the shared file."""
    return by_id("characters").get(member_id, {}).get("stances", [])


class PartyScene(Scene):
    """One member's status page, paged left and right."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", cursor: int = 0) -> None:
        """Open on member ``cursor``, the one chosen in the field menu."""
        super().__init__(gm)
        self._cursor: int = cursor

    def handle_event(self, event: pygame.event.Event) -> None:
        """Left and right, or L1 and R1, page; confirm switches the starting stance; cancel goes back."""
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
            return
        members = self.gm.party.members
        if not members:
            return
        if input_map.is_confirm(event):
            member = members[self._cursor]
            if len(stances(member.id)) > 1:
                member.stance = 1 - member.stance
                self.gm.audio.play("menu_select")
        elif input_map.is_left(event) or input_map.is_l1(event):
            self._cursor = (self._cursor - 1) % len(members)
            self.gm.audio.play("menu_move")
        elif input_map.is_right(event) or input_map.is_r1(event):
            self._cursor = (self._cursor + 1) % len(members)
            self.gm.audio.play("menu_move")

    def render(self, surface: pygame.Surface) -> None:
        render_scene_background(self, surface)
        # The whole screen is one ocean-blue window (D-461).
        draw_window(surface, surface.get_rect())
        if self.gm.party.members:
            self._render_member(surface, self.gm.party.members[self._cursor])

    def _render_member(self, surface: pygame.Surface, member: "PartyMember") -> None:
        """Paint ``member``'s page, in the stance they start a fight in."""
        size = FontSettings.SIZE_BODY
        white, gray = ColorSettings.WHITE, ColorSettings.GRAY
        portrait = load_portrait(member.id)
        frame = pygame.Rect(_PORTRAIT_POS, (UISettings.PORTRAIT_SIZE, UISettings.PORTRAIT_SIZE))
        surface.blit(portrait, frame.topleft)
        pygame.draw.rect(surface, white, frame.inflate(2, 2), 1)
        points, shown, top = stance_numbers(member)
        lines = (
            (short_name(member.id), ColorSettings.RED if member.current_hp <= 0 else white),
            (role(member.id), white),
            (f"HP {shown}/{top}", white),
            (f"Mana 0/{BattleSettings.MANA_CAP}", white),
        )
        for row, (text, color) in enumerate(lines):
            text_renderer.draw_text(surface, text, (_TOP_X, _TOP_Y + row * _LINE), color=color, size=size)
        for row, (key, label) in enumerate(_STAT_ROWS):
            y = _STATS_TOP_Y + row * _LINE
            text_renderer.draw_text(surface, label, (_STATS_X, y), color=white, size=size)
            value = str(points.get(key, 0))
            text_renderer.draw_text(surface, value, (_STATS_RIGHT_X - text_renderer.text_width(value, size), y),
                                    color=white, size=size)
        text_renderer.draw_text(surface, "TECH", (_RIGHT_X, _TECH_LABEL_Y), color=gray, size=size)
        text_renderer.draw_text(surface, signature_name(member.id), (_RIGHT_X, _TECH_LABEL_Y + _LINE),
                                color=white, size=size)
        both = stances(member.id)
        if both:
            text_renderer.draw_text(surface, "Stance", (_RIGHT_X, _STANCE_LABEL_Y), color=gray, size=size)
            start = both[member.stance if 0 <= member.stance < len(both) else 0]
            # The one they start in, in its element's color with the black edge (Frankie, 10/22).
            style = ColorSettings.ELEMENT_TEXT_STYLES.get(start["element"], {})
            text_renderer.draw_text(surface, start["name"], (_RIGHT_X, _STANCE_LABEL_Y + _LINE), size=size, **style)
            for other in (s for s in both if s is not start):
                text_renderer.draw_text(surface, other["name"], (_RIGHT_X, _STANCE_LABEL_Y + 2 * _LINE),
                                        color=gray, size=size)
