"""A story choice: the question and its answers in the text box's place.

The taro patch asks what Kailo takes, the wake what he brings
(``game/shared/story.md``, ``story-wake.md``). The window sits where the
text box does, the question in yellow on its first row as a speaker's
name is, each answer under it with the cursor, wrapped to the window.
Up and down move, confirm picks; there is no backing out of a story.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

import pygame

from core.scene import Scene
from settings import ColorSettings, FontSettings, ScreenSettings, UISettings
from ui import input_map, text_renderer
from ui.window import draw_window

if TYPE_CHECKING:
    from main import GameManager

# The answers start this far in, past the cursor.
_INDENT = 16


class ChoiceScene(Scene):
    """Pick one answer; pops itself, then calls ``on_pick`` with its index."""

    OPAQUE = False

    def __init__(self, gm: "GameManager", question: str, answers: list[str],
                 on_pick: Callable[[int], None]) -> None:
        super().__init__(gm)
        self.question = question
        self.answers = answers
        self.on_pick = on_pick
        self.cursor = 0

    def handle_event(self, event: pygame.event.Event) -> None:
        """Up and down move the cursor; confirm picks."""
        if input_map.is_confirm(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
            self.on_pick(self.cursor)
        elif input_map.is_up(event) and self.cursor > 0:
            self.cursor -= 1
            self.gm.audio.play("menu_move")
        elif input_map.is_down(event) and self.cursor < len(self.answers) - 1:
            self.cursor += 1
            self.gm.audio.play("menu_move")

    def rows(self) -> list[list[str]]:
        """Each answer wrapped to the window, as its rows."""
        font = text_renderer.get_font(FontSettings.SIZE_BODY)
        width = ScreenSettings.WIDTH - 2 * UISettings.TEXT_BOX_PADDING - _INDENT
        return [text_renderer.wrap(answer.upper(), font, width) for answer in self.answers]

    def render(self, surface: pygame.Surface) -> None:
        """The window along the bottom, as tall as the text box or its rows."""
        pad = UISettings.TEXT_BOX_PADDING
        row = text_renderer.line_height(FontSettings.SIZE_BODY)
        answers = self.rows()
        height = max(UISettings.TEXT_BOX_HEIGHT, 2 * pad + row * (1 + sum(map(len, answers))))
        rect = pygame.Rect(0, surface.get_height() - height, ScreenSettings.WIDTH, height)
        draw_window(surface, rect)
        x, y = rect.left + pad, rect.top + pad
        text_renderer.draw_text(surface, self.question, (x, y), color=ColorSettings.YELLOW,
                                size=FontSettings.SIZE_BODY)
        y += row
        for index, lines in enumerate(answers):
            if index == self.cursor:
                text_renderer.draw_pointer(
                    surface, (x + _INDENT - UISettings.MENU_LABEL_OFFSET + 4, y + FontSettings.SIZE_BODY // 2),
                )
            for line in lines:
                text_renderer.draw_text(surface, line, (x + _INDENT, y), size=FontSettings.SIZE_BODY)
                y += row
