"""The victory screen, laid out like Chrono Cross's (Frankie, 10/26).

On the left a window for each of the three who fought: name, HP and the
eight stats in two columns. On the right a tall RECEIVED box; along the
bottom the pule and the kupang, each by its icon. One thing at a time,
on a steady beat (``VictorySettings``), never two on the same beat:

1. Every stat that rose in the fight ticks up a point a beat, a blip
   each, a green up arrow beside it from its first tick.
2. A beat's rest, then the items unfold into the box, one a beat.
3. A beat's rest, then the pule counts up one number at a time, like a
   slot machine; a beat, then the kupang. A big amount steps by more
   than one, so no count takes much over two seconds. Money lives only
   in the bottom counter, never in the box.

An A carried over from the fight's last line is ignored for a moment
(``DEAF_SECONDS``). A during it finishes everything at once. The next A
clears the box and tells what happened after the fight: the passives,
narrated ("Kailo feeds everyone.") and typed out line by line, or in
their member's own voice the first time (``systems/passives.py``), and
anything else the fight's end reports. Once it is typed, HP that came
back counts up in the windows one number at a time, one fighter after
another. A during the typing or counting finishes it; the next A leaves.
With nothing to tell, that page is skipped. No damage, hits or healing
counts (Frankie, 10/26, from the third preview).

The battle builds the ``VictoryReport`` when it ends and pushes this on
top of itself; the victory song, already playing, goes on through it, and
the field's music comes back when the battle under it leaves.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable

import pygame

from core.scene import Scene
from core.scenes.shop_scene import item_name
from core.shared import short_name
from core.stats import STAT_SHORT
from settings import ColorSettings, FontSettings, ScreenSettings, UISettings, VictorySettings
from systems import config
from ui import input_map, text_renderer
from ui.item_icon import item_icon
from ui.text_box import TextBox
from ui.window import draw_window
from utils.graphics import load_element_icon

if TYPE_CHECKING:
    from main import GameManager


@dataclass
class Fighter:
    """One of the three who fought: their stats before the fight's growth and after."""

    member_id: str
    before: dict[str, int]
    after: dict[str, int]
    hp: int                 # As the fight ended.
    max_hp: int
    hp_after: int           # Once the passives have worked (the last page).
    grown: dict[str, int] = field(default_factory=dict)  # What rose in the fight, stat key -> points.


@dataclass
class VictoryReport:
    """What a won fight leaves for the victory screen."""

    fighters: list[Fighter]
    items: dict[str, int]
    pule: tuple[int, int]   # Old total, new total.
    kupang: tuple[int, int]
    lines: list[tuple[str | None, str]] = field(default_factory=list)  # (speaker or None, line)


# The windows on the 256 by 224 screen: three fighters down the left, the
# box on the right, the money along the bottom.
_LEFT_W = 136
_FIGHTER_H = 66
_MONEY_RECT = pygame.Rect(0, 3 * _FIGHTER_H, ScreenSettings.WIDTH, ScreenSettings.HEIGHT - 3 * _FIGHTER_H)
_BOX_RECT = pygame.Rect(_LEFT_W, 0, ScreenSettings.WIDTH - _LEFT_W, 3 * _FIGHTER_H)
_PAD = UISettings.TEXT_BOX_PADDING
_ROW = 10               # A fighter window's rows: name, HP, then four of stats.
_COLUMN = 62            # The second stat column starts this far right of the first.
_VALUE_RIGHT = 48       # A stat's number ends here, from its column's left.
_BOX_ROW = 12           # The box's lines.
_STATS = list(STAT_SHORT)  # hp, strength, ... evasion: down the first column, then the second.
_SIZE = FontSettings.SIZE_BODY


def _ticks(report: VictoryReport) -> list[tuple[int, str]]:
    """Every tick of the stat phase, in order, as (fighter, stat key).

    A stat ticks once per point it shows more; one that grew but shows the
    same (its multipliers round the new point away) still gets one tick and
    its arrow.
    """
    ticks = []
    for index, fighter in enumerate(report.fighters):
        for key in _STATS:
            rise = fighter.after.get(key, 0) - fighter.before.get(key, 0)
            if key in fighter.grown:
                ticks += [(index, key)] * max(1, rise)
    return ticks


def _count(old: int, new: int) -> list[int]:
    """The numbers a count shows on its way from ``old`` to ``new``, one per ``COUNT_SECONDS``.

    One at a time, unless that would take longer than ``COUNT_CAP_SECONDS``;
    then it steps by as much as fits the cap.
    """
    if new <= old:
        return [new] if new < old else []
    most = max(1, int(VictorySettings.COUNT_CAP_SECONDS / VictorySettings.COUNT_SECONDS))
    step = max(1, -(-(new - old) // most))
    return [min(new, value) for value in range(old + step, new + step, step)]


class VictoryScene(Scene):
    """The screen after a won fight."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", report: VictoryReport) -> None:
        """Lay out every beat of the tally, and start on the first."""
        super().__init__(gm)
        self.report = report
        self._ticks = _ticks(report)
        # The stats shown, which tick from before to after, and the ones with an arrow.
        self.shown = [dict(f.before) for f in report.fighters]
        self.risen: set[tuple[int, str]] = set()
        self._items = list(report.items.items())
        self.unfolded = 0       # Items fully in the box.
        self._fold = 0.0        # How far the next one has unfolded, 0 to 1.
        self.pule = report.pule[0]
        self.kupang = report.kupang[0]
        self.hp = [f.hp for f in report.fighters]  # The HP shown, which counts up on the last page.
        # An A carried over from the fight's last line is ignored this long.
        self._deaf = VictorySettings.DEAF_SECONDS
        # The tally, beat by beat: (phase, what happens, seconds to the next).
        self._steps = self._tally()
        self._step = 0
        self._clock = 0.0
        self.phase = self._steps[0][0] if self._steps else "done"
        # The last page: the narration in the box, typed out, and a
        # first-time line in a member's own voice under it; then the HP counts.
        self._told = [line for speaker, line in report.lines if speaker is None]
        self._typed = 0.0
        self._hp_steps: list[tuple[int, int]] = []
        self.text_box = TextBox()

    # ------------------------------------------------------------------
    # PHASES
    # ------------------------------------------------------------------

    def _tally(self) -> list[tuple[str, Callable[[], None], float]]:
        """Every beat of the tally in order, a beat's rest between one part and the next."""
        beat, count = VictorySettings.BEAT_SECONDS, VictorySettings.COUNT_SECONDS
        parts = [
            ("stats", [(lambda i=i: self._tick(i), beat) for i in range(len(self._ticks))]),
            ("items", [(self._unfold, beat) for _ in self._items]),
        ]
        for name in ("pule", "kupang"):
            old, new = getattr(self.report, name)
            parts.append(("money", [(lambda name=name, v=v: setattr(self, name, v), count)
                                    for v in _count(old, new)]))
        steps: list[tuple[str, Callable[[], None], float]] = []
        for phase, part in parts:
            if not part:
                continue
            if steps:
                steps.append((phase, lambda: None, beat))
            steps += [(phase, act, wait) for act, wait in part]
        return steps

    def _tick(self, number: int) -> None:
        """One stat point up, a blip and its arrow."""
        index, key = self._ticks[number]
        self.risen.add((index, key))
        fighter = self.report.fighters[index]
        self.shown[index][key] = min(fighter.after[key], self.shown[index][key] + 1)
        self.gm.audio.play("blip")

    def _unfold(self) -> None:
        """The next item starts opening into the box."""
        if self._fold > 0:
            self.unfolded += 1
        self._fold = 0.01

    def finish(self) -> None:
        """A during the counting: everything at once."""
        for fighter, shown in zip(self.report.fighters, self.shown):
            shown.update(fighter.after)
        self.risen.update(self._ticks)
        self._step = len(self._steps)
        self.unfolded = len(self._items)
        self._fold = 0.0
        self.pule, self.kupang = self.report.pule[1], self.report.kupang[1]
        self.phase = "done"

    def _tell(self) -> None:
        """Clear the box and tell what happened after the fight, or leave with nothing to tell."""
        if not self.report.lines:
            self._leave()
            return
        self.phase = "after"
        self._clock = 0.0
        for speaker, line in self.report.lines:
            if speaker is not None:
                self.text_box.push(line, speaker=speaker)

    def _told_out(self) -> bool:
        """True once the narration and the line in a member's voice have typed out."""
        voiced = self.text_box.is_done() or self.text_box.is_page_complete()
        return voiced and self._typed >= sum(len(line) for line in self._told)

    def _counted(self) -> bool:
        """True once every fighter's HP shows what the passives left them."""
        return self.hp == [f.hp_after for f in self.report.fighters]

    def _finish_after(self) -> None:
        """A during the last page's typing or counting: all of it at once."""
        self._typed = float(sum(len(line) for line in self._told))
        if not self.text_box.is_done() and not self.text_box.is_page_complete():
            self.text_box.advance()
        self.hp = [f.hp_after for f in self.report.fighters]
        self._hp_steps = []

    def _leave(self) -> None:
        """Back to the battle, which leaves at once for the field."""
        self.phase = "gone"
        self.gm.scene_stack.pop()

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """A finishes the counting, turns to the last page, finishes that, then leaves."""
        if not input_map.is_confirm(event) or self._deaf > 0:
            return
        if self.phase in ("stats", "items", "money"):
            self.finish()
        elif self.phase == "done":
            self._tell()
        elif self.phase == "after":
            if not (self._told_out() and self._counted()):
                self._finish_after()
            elif not self.text_box.is_done():
                self.text_box.advance()
            else:
                self._leave()

    def update(self, dt: float) -> None:
        """The tally's beats, then the last page's typing and counting."""
        self._deaf -= dt
        self.text_box.update(dt)
        if self._fold > 0:
            self._fold += dt / VictorySettings.UNFOLD_SECONDS
            if self._fold >= 1.0:
                self.unfolded += 1
                self._fold = 0.0
        if self.phase in ("stats", "items", "money"):
            self._clock += dt
            while self._step < len(self._steps) and self._clock >= 0:
                self.phase, act, wait = self._steps[self._step]
                act()
                self._step += 1
                self._clock -= wait
            if self._step >= len(self._steps):
                self.phase = "done"
        elif self.phase == "after":
            self._update_after(dt)

    def _update_after(self, dt: float) -> None:
        """Type the narration out, then count each fighter's HP up, one after another."""
        times = config.current.text_times()
        total = sum(len(line) for line in self._told)
        self._typed = total if times is None else min(
            total, self._typed + times * UISettings.TYPEWRITER_CHARS_PER_SECOND * dt)
        if not self._told_out() or self._counted():
            return
        if not self._hp_steps:
            for index, fighter in enumerate(self.report.fighters):
                self._hp_steps += [(index, v) for v in _count(self.hp[index], fighter.hp_after)]
            self._clock = 0.0
        self._clock += dt
        while self._hp_steps and self._clock >= VictorySettings.COUNT_SECONDS:
            self._clock -= VictorySettings.COUNT_SECONDS
            index, value = self._hp_steps.pop(0)
            self.hp[index] = value

    # ------------------------------------------------------------------
    # DRAWING
    # ------------------------------------------------------------------

    def render(self, surface: pygame.Surface) -> None:
        """The three windows, the box and the money."""
        surface.fill(ColorSettings.BLACK)
        for index in range(len(self.report.fighters)):
            rect = pygame.Rect(0, index * _FIGHTER_H, _LEFT_W, _FIGHTER_H)
            draw_window(surface, rect)
            self._render_fighter(surface, index, rect)
        draw_window(surface, _BOX_RECT)
        if self.phase == "after":
            self._render_told(surface)
        else:
            self._render_received(surface)
        draw_window(surface, _MONEY_RECT)
        self._render_money(surface)
        if self.phase == "after" and not self.text_box.is_done():
            self.text_box.render(surface)

    def _render_fighter(self, surface: pygame.Surface, index: int, rect: pygame.Rect) -> None:
        """Name, HP, then the eight stats in two columns, an arrow by each that rose."""
        fighter = self.report.fighters[index]
        x, y = rect.left + _PAD, rect.top + 5
        hp = self.hp[index]
        text_renderer.draw_text(surface, short_name(fighter.member_id), (x, y),
                                color=ColorSettings.RED if hp <= 0 else ColorSettings.WHITE, size=_SIZE)
        y += _ROW
        text_renderer.draw_text(surface, "HP", (x, y), color=ColorSettings.LABEL_CYAN, size=_SIZE)
        numbers = f"{hp}/{fighter.max_hp}"
        text_renderer.draw_text(surface, numbers, (x + 2 * _COLUMN - 14 - text_renderer.text_width(numbers, _SIZE), y),
                                size=_SIZE)
        y += _ROW
        for slot, key in enumerate(_STATS):
            col_x = x + (slot // 4) * _COLUMN
            row_y = y + (slot % 4) * _ROW
            text_renderer.draw_text(surface, STAT_SHORT[key], (col_x, row_y),
                                    color=ColorSettings.LABEL_CYAN, size=_SIZE)
            value = str(self.shown[index].get(key, 0))
            text_renderer.draw_text(surface, value, (col_x + _VALUE_RIGHT - text_renderer.text_width(value, _SIZE), row_y),
                                    size=_SIZE)
            if (index, key) in self.risen:
                ax = col_x + _VALUE_RIGHT + 2
                # The font has no arrow, so it is drawn: a green one pointing up.
                pygame.draw.polygon(surface, ColorSettings.ELEMENT_ARROW,
                                    [(ax + 3, row_y), (ax + 6, row_y + 3), (ax, row_y + 3)])
                pygame.draw.rect(surface, ColorSettings.ELEMENT_ARROW, pygame.Rect(ax + 2, row_y + 3, 3, 4))

    def _render_received(self, surface: pygame.Surface) -> None:
        """RECEIVED, then each item as it unfolds, its name wrapped under its icon."""
        x, y = _BOX_RECT.left + _PAD, _BOX_RECT.top + _PAD
        text_renderer.draw_text(surface, "RECEIVED", (x, y), color=ColorSettings.YELLOW, size=_SIZE)
        y += _BOX_ROW + 4
        shown = self.unfolded + (1 if self._fold > 0 else 0)
        width = _BOX_RECT.width - 2 * _PAD - FontSettings.LETTER_WIDTH
        font = text_renderer.get_font(_SIZE)
        clip = surface.get_clip()
        for number, (item_id, count) in enumerate(self._items[:shown]):
            name = item_name(item_id) + (f" x{count}" if count > 1 else "")
            lines = text_renderer.wrap(name.upper(), font, width)
            height = len(lines) * _BOX_ROW
            if y + height > _BOX_RECT.bottom - _PAD:
                break
            if number == self.unfolded:
                # Unfolding: it opens from its middle line out.
                open_to = max(1, round(height * self._fold))
                surface.set_clip(pygame.Rect(x, y + (height - open_to) // 2, _BOX_RECT.width - 2 * _PAD, open_to))
            self._draw_item(surface, item_id, lines, x, y)
            surface.set_clip(clip)
            y += height

    def _draw_item(self, surface: pygame.Surface, item_id: str, lines: list[str], x: int, y: int) -> None:
        """An item's icon, then its name over as many lines as it takes."""
        icon = item_icon(item_id)
        if icon is not None:
            surface.blit(icon, (x, y))
        for row, line in enumerate(lines):
            text_renderer.draw_text(surface, line, (x + FontSettings.LETTER_WIDTH, y + row * _BOX_ROW), size=_SIZE)

    def _render_told(self, surface: pygame.Surface) -> None:
        """The last page: what happened after the fight, narrated, one line under another, as typed."""
        x, y = _BOX_RECT.left + _PAD, _BOX_RECT.top + _PAD
        font = text_renderer.get_font(_SIZE)
        left = int(self._typed)
        for line in self._told:
            # Wrapped whole first, so a word never jumps rows as it types.
            for row in text_renderer.wrap(line.upper(), font, _BOX_RECT.width - 2 * _PAD):
                if left <= 0:
                    return
                text_renderer.draw_text(surface, row[:left], (x, y), size=_SIZE)
                left -= len(row)
                y += _BOX_ROW
            y += 4

    def _render_money(self, surface: pygame.Surface) -> None:
        """The pule on the left half, the kupang on the right, each by its icon."""
        y = _MONEY_RECT.top + (_MONEY_RECT.height - 8) // 2
        half = _MONEY_RECT.width // 2
        for slot, (icon_id, value) in enumerate((("pule", self.pule), ("kupang", self.kupang))):
            left = _MONEY_RECT.left + slot * half + _PAD
            icon = load_element_icon(icon_id)
            if icon is not None:
                surface.blit(icon, (left, y - 5))
            text = str(value)
            text_renderer.draw_text(surface, text, (left + half - 2 * _PAD - text_renderer.text_width(text, _SIZE), y),
                                    size=_SIZE)
