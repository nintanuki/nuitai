"""The maps on SELECT (Frankie, 10/26 and 10/28; what is decided is on ``game/answers.md``).

On the field SELECT opens the area map: the outside rooms Kailo has walked
into, in their tiles' colors (``systems/area_map.py``), the place's name over
it, and Kailo's dot blinking where he stands, in one window on black. The
map is bigger than the window's view; it opens on Kailo and the d-pad
glides it to the area's edges.
SELECT again goes to the world map once Kailo has the map Ama gives him
(``MapSettings.HAS_MAP_FLAG``); until then, the whole demo, it closes. On
the world map SELECT closes it. B closes either. The world map is the
picture map of Nuitai with no words on it (``systems/world_map.py``), in
the same window, and Kailo's dot on his area's spot.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from settings import ColorSettings, FontSettings, MapSettings, ScreenSettings
from systems import area_map, world_map
from ui import input_map, text_renderer
from ui.window import draw_window

if TYPE_CHECKING:
    from main import GameManager

AREA = "area"
WORLD = "world"


def has_map(gm: "GameManager") -> bool:
    """Whether Kailo has the map Ama gives him (after the demo, so not yet)."""
    return bool(gm.party and gm.party.flags.get(MapSettings.HAS_MAP_FLAG))


class MapScene(Scene):
    """The area map, then the world map once Kailo has one; pops itself to close."""

    def __init__(self, gm: "GameManager", seen: set[str], room: str, col: int, row: int) -> None:
        super().__init__(gm)
        self.showing = AREA
        self.seen = set(seen)
        self.room, self.col, self.row = room, col, row
        self.clock = 0.0
        self.picture = area_map.draw(self.seen)
        self.title = area_map.title(room)
        self.scroll = area_map.start(room, col, row)

    def handle_event(self, event: pygame.event.Event) -> None:
        if input_map.is_cancel(event):
            self.gm.scene_stack.pop()
        elif input_map.is_select(event):
            if self.showing == AREA and has_map(self.gm):
                self.showing = WORLD
                self.clock = 0.0
            else:
                self.gm.scene_stack.pop()

    def update(self, dt: float) -> None:
        self.clock += dt
        if self.showing == AREA:
            dx, dy = input_map.read_held_direction(getattr(self.gm, "connected_joysticks", []))
            step = MapSettings.PAN_SPEED * dt
            self.pan(dx * step, dy * step)

    def pan(self, dx: float, dy: float) -> None:
        """Move the view over the area map, stopping at its edges."""
        self.scroll = area_map.clamp(self.scroll[0] + dx, self.scroll[1] + dy, self.picture.get_size())

    def render(self, surface: pygame.Surface) -> None:
        surface.fill(ColorSettings.BLACK)
        if self.showing == WORLD:
            self._render_world(surface)
        else:
            self._render_area(surface)

    def _render_area(self, surface: pygame.Surface) -> None:
        """The window, the title in it, the map's view under the title, and the blinking dot."""
        pad, gap = MapSettings.PADDING, MapSettings.TITLE_GAP
        view_w, view_h = MapSettings.VIEW_W, MapSettings.VIEW_H
        heading = text_renderer.line_height(FontSettings.SIZE_BODY)
        title_width = text_renderer.text_width(self.title) if self.title else 0
        # The same window for every area and place, so it stays put.
        box = pygame.Rect(0, 0, view_w + 2 * pad, view_h + heading + gap + 2 * pad)
        box.center = (ScreenSettings.WIDTH // 2, ScreenSettings.HEIGHT // 2)
        draw_window(surface, box)
        top = box.y + pad
        if self.title:
            text_renderer.draw_text(surface, self.title, (box.centerx - title_width // 2, top))
        view = pygame.Rect(box.x + pad, top + heading + gap, view_w, view_h)
        left, top = view.x - int(self.scroll[0]), view.y - int(self.scroll[1])
        clip = surface.get_clip()
        surface.set_clip(view)
        surface.blit(self.picture, (left, top))
        if int(self.clock / MapSettings.BLINK_SECONDS) % 2 == 0:
            self._render_dot(surface, left, top)
        surface.set_clip(clip)

    def _render_dot(self, surface: pygame.Surface, left: int, top: int) -> None:
        """Kailo's tile on the area map."""
        self._dot(surface, left, top, area_map.dot_at(self.room, self.col, self.row))

    def _dot(self, surface: pygame.Surface, left: int, top: int, at: tuple[int, int] | None) -> None:
        """Kailo's dot, yellow, at pixel ``at`` of a map (``MapSettings.DOT_COLOR``)."""
        if at is None:
            return
        block = max(2, MapSettings.TILE_PIXELS)
        x = left + at[0] - (block - MapSettings.TILE_PIXELS) // 2
        y = top + at[1] - (block - MapSettings.TILE_PIXELS) // 2
        surface.fill(MapSettings.DOT_COLOR, (x, y, block, block))

    def _render_world(self, surface: pygame.Surface) -> None:
        """The world map: the picture map in the same window, no words, centered in its frame,
        and Kailo's dot blinking on his area's spot (``systems/world_map.py``)."""
        pad = MapSettings.PADDING
        picture = world_map.picture()
        width, height = picture.get_size()
        box = pygame.Rect(0, 0, width + 2 * pad, height + 2 * pad)
        box.center = (ScreenSettings.WIDTH // 2, ScreenSettings.HEIGHT // 2)
        draw_window(surface, box)
        left, top = box.centerx - width // 2, box.centery - height // 2
        surface.blit(picture, (left, top))
        if int(self.clock / MapSettings.BLINK_SECONDS) % 2 == 0:
            self._dot(surface, left, top, world_map.dot_at(self.room))
