"""The EQUIP screen: change the weapon a member holds (D-462).

Pushed by the field menu once a member is picked. The member's name and
the weapon held on top, then every weapon of a type they use, as the
browser's Equip tab offers, the one held in yellow; under the list, what
the highlighted weapon is. Confirm takes it up; cancel goes back.
Weapons do nothing in a fight yet, so there are no numbers to compare.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pygame

from core.scene import Scene
from core.shared import by_id, short_name
from settings import ColorSettings, FontSettings, UISettings
from ui import input_map, text_renderer
from ui.menu import Menu, MenuItem
from ui.window import draw_window
from utils.backgrounds import render_scene_background
from utils.graphics import load_weapon_icon

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


_NAME_POS = (12, 12)
_HELD_POS = (12, 30)
_LIST_POS = (30, 60)
_ROW_HEIGHT = 20
_ABOUT_Y = 186
_ABOUT_WIDTH = 232


class EquipScene(Scene):
    """One member's weapons, to choose which they hold."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", member: "PartyMember") -> None:
        """List the weapons ``member`` can use."""
        super().__init__(gm)
        self.member = member
        types = by_id("characters").get(member.id, {}).get("weapon_types", [])
        self.weapons: list[dict[str, Any]] = [
            w for w in by_id("weapons").values() if w["type"] in types
        ]
        self.menu = Menu(
            items=[
                MenuItem(w["name"], lambda w=w: self._take(w)) for w in self.weapons
            ],
            on_cancel=lambda: self.gm.scene_stack.pop(),
        )
        held = [w["id"] for w in self.weapons]
        if member.weapon in held:
            self.menu.cursor = held.index(member.weapon)

    def _take(self, weapon: dict[str, Any]) -> None:
        """Hold ``weapon``."""
        self.member.weapon = weapon["id"]

    def handle_event(self, event: pygame.event.Event) -> None:
        """Up and down choose, confirm takes it up, cancel goes back."""
        if input_map.is_up(event):
            if self.menu.move_up():
                self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            if self.menu.move_down():
                self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            if self.menu.confirm():
                self.gm.audio.play("menu_select")
        elif input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.menu.cancel()

    def render(self, surface: pygame.Surface) -> None:
        """The member, the weapon held, the list, and what the highlighted one is."""
        render_scene_background(self, surface)
        draw_window(surface, surface.get_rect())
        size = FontSettings.SIZE_BODY
        text_renderer.draw_text(
            surface, short_name(self.member.id), _NAME_POS,
            color=ColorSettings.WHITE, size=size,
        )
        weapons = by_id("weapons")
        held = weapons.get(self.member.weapon or "")
        text_renderer.draw_text(
            surface, f"Holds {held['name']}" if held else "Holds nothing", _HELD_POS,
            color=ColorSettings.GRAY, size=size,
        )
        for item, weapon in zip(self.menu.items, self.weapons):
            item.color = ColorSettings.YELLOW if held and weapon["id"] == held["id"] else None
        self.menu.render(surface, _LIST_POS, font_size=size, row_height=_ROW_HEIGHT)
        # Each weapon's type icon beside its name.
        for row, weapon in enumerate(self.weapons):
            icon = load_weapon_icon(weapon["type"])
            if icon is not None:
                surface.blit(icon, (
                    _LIST_POS[0] + UISettings.MENU_LABEL_OFFSET + 150,
                    _LIST_POS[1] + row * _ROW_HEIGHT - 5,
                ))
        about = self.weapons[self.menu.cursor].get("about", "") if self.weapons else ""
        y = _ABOUT_Y
        for line in text_renderer.wrap(about, text_renderer.get_font(size), _ABOUT_WIDTH):
            text_renderer.draw_text(surface, line, (12, y), color=ColorSettings.WHITE, size=size)
            y += 16
