"""The EQUIP screen, Final Fantasy VI's (Frankie, 10/24, from four screenshots of Cyan's).

Pushed by the field menu once a member is picked. At the top a bar of
commands: Equip, Remove, Mastery. Under it the two slots, Weapon
and Relic, each item with its icon before its name, then the line Final
Fantasy VI uses for Head and Body: the elements, each element's icon
with a green arrow up or a red one down, for a weapon the damage it
deals (none yet: only stat effects work) and for a relic the damage it
resists. The line follows the cursor (Frankie, 10/24): on a slot it is
what is worn there, in the list what the item under the cursor would
make it, so the difference shows before the swap; on the command bar it
is empty. The portrait and name at the right. Below, the list to pick
from at the left, the one worn grayed, and the stats at the right, HP
then the eight, as they are and as they would be, a rise in yellow and a
drop in red. Picking a slot swaps the bar for a small EQUIP box and a
help line of two saying what the item under the cursor does, its trade
in one plain line (Frankie, 10/24).

Equip picks a slot, then what goes in it; Remove picks a slot and puts
what is in it back in the bag. Mastery (Frankie, 10/30; Optimum and Empty
went) keeps the screen as it is and turns the lower window into the
member's three weapon types, each with its level and a bar to the next
(``systems/mastery.py``). The hook moves up and down them, and confirm
opens one: what its level gives a stroke now and at the next level, the
Skill it goes with, and what that Skill learns by level (Frankie, 11/2).
A weapon's own effect is the one plain line of the help box on Equip.
L1 and R1, or left and right on the Mastery page, switch member.

One hook (Frankie, 11/2): choosing on the bar carries it down to the
slots or the list, and backing out carries it up; nothing is left
behind greyed.

Rows are 12 pixels apart here, as Final Fantasy VI packs this screen,
not the game's 16 (Frankie saw and liked it, 10/24): at 16 the four slot
lines, nine stat lines and the portrait do not fit in 224. The cartridge
draws text on an 8 pixel grid, which is in the TODO.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pygame

from core.equipment import can_hold, description, element_changes, slot_of, trade_line, with_english
from core.factories import stance_numbers
from core.scene import Scene
from core.scenes.party_scene import draw_notches
from core.shared import by_id, skill_for
from core.stats import STAT_SHORT
from settings import BattleSettings, ColorSettings, FontSettings, ItemSettings, MasterySettings, UISettings
from systems import mastery
from ui import input_map, text_renderer
from ui.battle_stage import element_icon
from ui.item_icon import item_icon, kind_surface, weapon_kind
from ui.scroll_mark import draw_list_marks
from ui.window import draw_window, help_wrap
from utils.backgrounds import render_scene_background
from utils.graphics import load_portrait

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


SIZE = FontSettings.SIZE_BODY
ROW = 12                                  # Final Fantasy VI's pitch on this screen.
COMMANDS = ("Equip", "Remove", "Mastery")
_COMMAND_X = (32, 104, 176)
SLOTS = ("weapon", "relic")
_SLOT_LABELS = {"weapon": "Weapon", "relic": "Relic"}
# The top: the bar's window, or the one window under the small EQUIP box.
_BAR_RECT = pygame.Rect(0, 0, 256, 24)
_SLOTS_RECT = pygame.Rect(0, 24, 256, 72)
_PICK_RECT = pygame.Rect(0, 8, 256, 88)
_LABEL_RECT = pygame.Rect(176, 0, 80, 24)
_HELP_POS = (16, 28)                      # The help line's first line; the second a row under it.
_SLOTS_TOP = {"command": 36, "pick": 52}  # Weapon's row; Relic, then the element line, under it.
_ELEMENT_ROW = 2                          # The element line and the name, rows under Weapon.
_ITEM_X = 80                              # An item's name; its icon a letter before.
_PORTRAIT_X = 200
_PORTRAIT_Y = {"command": 32, "pick": 40}
# The Mastery page fills the lower window: three weapon types, a bar each.
_TYPE_TOP = 112
_TYPE_PITCH = 36
_BAR_X = 32
_DETAIL_TOP = 134                         # An opened type: the stroke lines, then the Skill.
_DETAIL_X = 80
# The bottom: the list at the left, the stats at the right.
_LOWER_RECT = pygame.Rect(0, 96, 256, 128)
_LIST_TOP = 108
_LIST_X = 24
_LIST_ROWS = 9
_STAT_X = 144
_MARK_X = 132                             # The list's scroll arrows, before the stats.
_NOW_RIGHT = 200
_ARROW_X = 203
_THEN_RIGHT = 240
_ARROW_UP = ("...#...", "..###..", ".#####.", "...#...", "...#...", "...#...", ".......")
_ARROW_DOWN = _ARROW_UP[-2::-1] + (".......",)


def candidates(party, member: "PartyMember", slot: str) -> list[str]:
    """What can go in ``slot``: the one worn first, then what in the bag ``member`` can use."""
    worn = getattr(member, slot)
    bag = sorted((item for item, count in party.inventory.items()
                  if count > 0 and slot_of(item) == slot and can_hold(member.id, item) and item != worn),
                 key=lambda item: ItemSettings.NAMES.get(item, item))
    return ([worn] if worn else []) + bag


def put_on(party, member: "PartyMember", slot: str, item: str | None) -> None:
    """Wear ``item`` in ``slot`` (None empties it): what was there goes back in the bag."""
    worn = getattr(member, slot)
    if worn == item:
        return
    if worn:
        party.inventory[worn] = party.inventory.get(worn, 0) + 1
    if item:
        party.inventory[item] -= 1
        if party.inventory[item] <= 0:
            del party.inventory[item]
    setattr(member, slot, item)
    member.refresh_stats()
    member.current_hp = min(member.current_hp, member.max_hp)


def numbers(member: "PartyMember", weapon: str | None) -> dict[str, int]:
    """HP and the eight stats in the stance the member starts a fight in, holding ``weapon``."""
    held = member.weapon
    member.weapon = weapon
    try:
        points, _, top = stance_numbers(member)
    finally:
        member.weapon = held
    return {"max_hp": top, **points}


class EquipScene(Scene):
    """One member's weapon and relic."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", member: "PartyMember") -> None:
        super().__init__(gm)
        self.member = member
        self.state = "command"    # "command", then "slot", then "list"; or "mastery", then "type".
        self.type_row = 0         # The weapon type the Mastery hook is on.
        self.command = 0
        self.slot = 0
        self.pick = 0
        self.removing = False

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def _move(self, changed: bool) -> None:
        if changed:
            self.gm.audio.play("menu_move")

    def _choices(self) -> list[str]:
        return candidates(self.gm.party, self.member, SLOTS[self.slot])

    def handle_event(self, event: pygame.event.Event) -> None:
        if input_map.is_l1(event) or input_map.is_r1(event):
            self._switch(-1 if input_map.is_l1(event) else 1)
        elif self.state == "command":
            self._handle_command(event)
        elif self.state in ("mastery", "type"):
            self._handle_mastery(event)
        elif self.state == "slot":
            self._handle_slot(event)
        else:
            self._handle_list(event)

    def _handle_command(self, event: pygame.event.Event) -> None:
        if input_map.is_left(event) or input_map.is_right(event):
            step = -1 if input_map.is_left(event) else 1
            self.command = (self.command + step) % len(COMMANDS)
            self._move(True)
        elif input_map.is_confirm(event):
            self.gm.audio.play("menu_select")
            chosen = COMMANDS[self.command]
            if chosen in ("Equip", "Remove"):
                self.state, self.removing = "slot", chosen == "Remove"
            else:
                self.state = "mastery"
                held = mastery.type_held(self.member.id, self.member.weapon)
                types = mastery.weapon_types(self.member.id)
                self.type_row = types.index(held) if held in types else 0
        elif input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()

    def _handle_mastery(self, event: pygame.event.Event) -> None:
        """The weapon types: up and down move the hook, confirm opens one, cancel backs out."""
        count = len(mastery.weapon_types(self.member.id))
        if input_map.is_left(event) or input_map.is_right(event):
            self._switch(-1 if input_map.is_left(event) else 1)
        elif self.state == "mastery" and count and (input_map.is_up(event) or input_map.is_down(event)):
            self.type_row = (self.type_row + (-1 if input_map.is_up(event) else 1)) % count
            self._move(True)
        elif self.state == "mastery" and input_map.is_confirm(event) and count:
            self.gm.audio.play("menu_select")
            self.state = "type"
        elif input_map.is_cancel(event) or (self.state == "type" and input_map.is_confirm(event)):
            self.gm.audio.play("menu_select")
            self.state = "command" if self.state == "mastery" else "mastery"

    def _handle_slot(self, event: pygame.event.Event) -> None:
        if input_map.is_up(event) or input_map.is_down(event):
            self.slot = 1 - self.slot
            self._move(True)
        elif input_map.is_confirm(event):
            self.gm.audio.play("menu_select")
            if self.removing:
                put_on(self.gm.party, self.member, SLOTS[self.slot], None)
            else:
                self.state, self.pick = "list", 0
        elif input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.state = "command"

    def _handle_list(self, event: pygame.event.Event) -> None:
        choices = self._choices()
        if choices and (input_map.is_up(event) or input_map.is_down(event)):
            step = -1 if input_map.is_up(event) else 1
            before = self.pick
            self.pick = (self.pick + step) % len(choices)
            self._move(self.pick != before)
        elif input_map.is_confirm(event) and choices:
            self.gm.audio.play("menu_select")
            put_on(self.gm.party, self.member, SLOTS[self.slot], choices[self.pick])
            self.state = "slot"
        elif input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.state = "slot"

    def _switch(self, step: int) -> None:
        """L1 and R1: the previous or next member who travels, as on the Element page (Frankie, 10/23)."""
        members = self.gm.party.members
        if len(members) < 2:
            return
        index = next((i for i, m in enumerate(members) if m is self.member), 0)
        self.member = members[(index + step) % len(members)]
        self.pick = 0
        self.type_row = min(self.type_row, max(0, len(mastery.weapon_types(self.member.id)) - 1))
        self.gm.audio.play("menu_move")

    # ------------------------------------------------------------------
    # DRAWING
    # ------------------------------------------------------------------

    def _pointed(self) -> str | None:
        """What the cursor is on: the item under it in the list, on a slot what is worn there."""
        if self.state == "command":
            return None
        return self._highlighted() if self.state == "list" else getattr(self.member, SLOTS[self.slot])

    def _highlighted(self) -> str | None:
        """The item the list's cursor is on, while choosing."""
        choices = self._choices()
        return choices[self.pick] if self.state == "list" and choices else None

    def render(self, surface: pygame.Surface) -> None:
        render_scene_background(self, surface)
        surface.fill(ColorSettings.BLACK)
        highlighted = self._highlighted()
        if self.state in ("command", "mastery", "type"):
            draw_window(surface, _BAR_RECT)
            for x, word in zip(_COMMAND_X, COMMANDS):
                _text(surface, word, x, 8)
            draw_window(surface, _SLOTS_RECT)
            top = _SLOTS_TOP["command"]
        else:
            draw_window(surface, _PICK_RECT)
            draw_window(surface, _LABEL_RECT)
            _text(surface, "Equip", _LABEL_RECT.x + 20, 8, ColorSettings.LABEL_CYAN)
            for row, words in enumerate(equip_help(self._pointed())):
                _text(surface, words, _HELP_POS[0], _HELP_POS[1] + row * ROW)
            top = _SLOTS_TOP["pick"]
        self._render_slots(surface, top, highlighted)
        self._render_lower(surface, highlighted)
        # The one hook, drawn last so no window covers it on its way (Frankie, 11/2).
        if self.state == "command":
            _pointer(surface, _COMMAND_X[self.command], 8)
        elif self.state == "slot":
            _pointer(surface, 16, top + self.slot * ROW)
        elif self.state == "mastery":
            _pointer(surface, 24, _TYPE_TOP + self.type_row * _TYPE_PITCH)
        elif self.state == "type":
            _pointer(surface, 24, _TYPE_TOP)
        elif self.state == "list" and self._choices():
            first = max(0, self.pick - _LIST_ROWS + 1)
            _pointer(surface, _LIST_X - 8, _LIST_TOP + (self.pick - first) * ROW)

    def _render_slots(self, surface: pygame.Surface, top: int, highlighted: str | None) -> None:
        """Weapon and Relic with their items, the two element lines, the portrait and name."""
        for index, slot in enumerate(SLOTS):
            y = top + index * ROW
            _text(surface, _SLOT_LABELS[slot], 16, y, ColorSettings.LABEL_CYAN)
            worn = getattr(self.member, slot)
            if worn:
                _item(surface, worn, _ITEM_X, y)
        # The element line follows the cursor; a weapon's is empty, none pushes an element yet.
        _element_line(surface, _ITEM_X - 8, top + _ELEMENT_ROW * ROW, element_changes(self._pointed()))
        # The portrait says who it is; a name alone under the relic looked awkward (Frankie, 10/30).
        surface.blit(load_portrait(self.member.id), (_PORTRAIT_X, _PORTRAIT_Y["pick" if self.state in ("slot", "list") else "command"]))

    def _render_types(self, surface: pygame.Surface) -> None:
        """The lower window on the Mastery page: the three weapon types, level, bar and EXP to the next."""
        for index, type_id in enumerate(mastery.weapon_types(self.member.id)):
            y = _TYPE_TOP + index * _TYPE_PITCH
            exp = self.member.mastery.get(type_id, 0)
            level = mastery.level_for(exp)
            top = level >= MasterySettings.MAX_LEVEL
            surface.blit(kind_surface(weapon_kind(type_id)), (24, y))
            _text(surface, mastery.type_name(type_id), 32, y)
            _text(surface, f"Lv {level}", 240, y, ColorSettings.YELLOW if top else ColorSettings.WHITE, right=True)
            step = mastery.progress(exp)
            # The same notched bar as a stat's EXP on Status: salmon red (Strength's), gold when maxed.
            draw_notches(surface, (_BAR_X, y + 14), 10 if step is None else step[0] * 10 // step[1],
                         ColorSettings.YELLOW if top else ColorSettings.STAT_TEXT_STYLES["strength"]["color"])
            _text(surface, "MAX" if step is None else f"{step[0]}/{step[1]}", 240, y + 12,
                  ColorSettings.YELLOW if top else ColorSettings.GRAY, right=True)

    def _render_type(self, surface: pygame.Surface, type_id: str) -> None:
        """One weapon type opened from the Mastery page (Frankie, 11/2): its row as on the list,
        what its level adds to a stroke now and at the next, its Skill, and what the Skill
        learns by level. Every number comes from ``MasterySettings`` and the rules.
        """
        exp = self.member.mastery.get(type_id, 0)
        level = mastery.level_for(exp)
        top = level >= MasterySettings.MAX_LEVEL
        y = _TYPE_TOP
        surface.blit(kind_surface(weapon_kind(type_id)), (24, y))
        _text(surface, mastery.type_name(type_id), 32, y)
        _text(surface, f"Lv {level}", 240, y, ColorSettings.YELLOW if top else ColorSettings.WHITE, right=True)
        step = mastery.progress(exp)
        draw_notches(surface, (_BAR_X, y + 14), 10 if step is None else step[0] * 10 // step[1],
                     ColorSettings.YELLOW if top else ColorSettings.STAT_TEXT_STYLES["strength"]["color"])
        _text(surface, "MAX" if step is None else f"{step[0]}/{step[1]}", 240, y + 12,
              ColorSettings.YELLOW if top else ColorSettings.GRAY, right=True)
        y = _DETAIL_TOP
        _text(surface, "Strokes", 16, y, ColorSettings.LABEL_CYAN)
        _text(surface, _bonus_line(level), _DETAIL_X, y)
        if not top:
            _text(surface, f"Lv {level + 1}", 16, y + ROW, ColorSettings.LABEL_CYAN)
            _text(surface, _bonus_line(level + 1), _DETAIL_X, y + ROW, ColorSettings.GRAY)
        y += 2 * ROW + 2
        skill = skill_for(self.member.id, type_id)
        _text(surface, "Skill", 16, y, ColorSettings.LABEL_CYAN)
        _text(surface, skill["name"] if skill else "None", _DETAIL_X, y,
              ColorSettings.WHITE if skill and not skill.get("off") else ColorSettings.GRAY)
        learns = _learned_by_level(skill["id"]) if skill else []
        if not learns and skill:
            for row, words in enumerate(help_wrap(skill.get("description", ""))):
                _text(surface, words, 16, y + (row + 1) * ROW)
        for row, (at, name) in enumerate(learns):
            color = ColorSettings.WHITE if at <= level else ColorSettings.GRAY
            _text(surface, f"Lv {at}", 16, y + (row + 1) * ROW, color)
            _text(surface, name, _DETAIL_X, y + (row + 1) * ROW, color)

    def _render_lower(self, surface: pygame.Surface, highlighted: str | None) -> None:
        """The list to pick from, then HP and the stats as they are and as they would be."""
        draw_window(surface, _LOWER_RECT)
        if self.state == "mastery":
            self._render_types(surface)
            return
        if self.state == "type":
            self._render_type(surface, mastery.weapon_types(self.member.id)[self.type_row])
            return
        if self.state != "command":
            choices = self._choices()
            first = max(0, self.pick - _LIST_ROWS + 1) if self.state == "list" else 0
            worn = getattr(self.member, SLOTS[self.slot])
            for row, item in enumerate(choices[first:first + _LIST_ROWS]):
                y = _LIST_TOP + row * ROW
                _item(surface, item, _LIST_X, y, ColorSettings.GRAY if item == worn else ColorSettings.WHITE)
            draw_list_marks(surface, _MARK_X, _LIST_TOP, ROW, first, _LIST_ROWS, len(choices))
        now = numbers(self.member, self.member.weapon)
        then = None
        if self.state != "command":
            weapon = highlighted if highlighted and SLOTS[self.slot] == "weapon" else self.member.weapon
            then = numbers(self.member, weapon)
        for row, (key, label) in enumerate({"max_hp": "HP", **STAT_SHORT}.items()):
            y = _LIST_TOP + row * ROW
            _text(surface, label, _STAT_X, y, ColorSettings.LABEL_CYAN)
            _text(surface, str(now[key]), _NOW_RIGHT, y, right=True)
            if then is None:
                continue
            color = (ColorSettings.YELLOW if then[key] > now[key]
                     else ColorSettings.STAT_DROP if then[key] < now[key] else ColorSettings.WHITE)
            # The font has no arrow, so it is drawn.
            pygame.draw.polygon(surface, color, [(_ARROW_X, y + 1), (_ARROW_X + 4, y + 4), (_ARROW_X, y + 7)])
            _text(surface, str(then[key]), _THEN_RIGHT, y, color, right=True)


def _text(surface: pygame.Surface, words: str, x: int, y: int,
          color=ColorSettings.WHITE, right: bool = False) -> None:
    """Words at ``x``, or ending at ``x`` when ``right``."""
    if right:
        x -= text_renderer.text_width(words, SIZE)
    text_renderer.draw_text(surface, words, (x, y), color=color, size=SIZE)


def _pointer(surface: pygame.Surface, x: int, y: int, color=ColorSettings.YELLOW) -> None:
    """The cursor, its tip just left of a word at ``x``."""
    text_renderer.draw_pointer(surface, (x - UISettings.MENU_LABEL_OFFSET, y + SIZE // 2), color)


def _item(surface: pygame.Surface, item: str, x: int, y: int, color=ColorSettings.WHITE) -> None:
    """An item's icon in the letter space before ``x``, its name after."""
    icon = item_icon(item)
    if icon is not None:
        surface.blit(icon, (x - 8, y))
    _text(surface, ItemSettings.NAMES.get(item, item), x, y, color)


def _element_line(surface: pygame.Surface, x: int, y: int, changes: list[tuple[str, int]]) -> None:
    """Each element's icon with its arrow, a green one up and a red one down, a letter apart."""
    for element, direction in changes:
        icon = element_icon(element)
        if icon is not None:
            surface.blit(icon, (x, y))
        color = ColorSettings.ELEMENT_ARROW if direction > 0 else ColorSettings.STAT_DROP
        for dy, row in enumerate(_ARROW_UP if direction > 0 else _ARROW_DOWN):
            for dx, pixel in enumerate(row):
                if pixel == "#":
                    surface.set_at((x + 8 + dx, y + dy), color)
        x += 24


def _bonus_line(level: int) -> str:
    """What ``level`` adds to a stroke: "Hit +1%  Damage +2%"."""
    return (f"Hit +{round(mastery.hit_bonus(level) * 100)}%  "
            f"Damage +{round(mastery.damage_bonus(level) * 100)}%")


def _learned_by_level(skill_id: str) -> list[tuple[int, str]]:
    """What a Skill learns as its weapon type levels up, as (level, name); none for most.

    Pound's moves by handwraps level, Dance's by fan level, Cook's dishes by tool level (Frankie, 10/31).
    """
    if skill_id == "pound":
        return [(m["level"], m["name"]) for m in BattleSettings.POUND_MOVES]
    if skill_id == "dance":
        return [(m["level"], m["name"]) for m in BattleSettings.DANCE_MOVES]
    if skill_id == "cook":
        return sorted((BattleSettings.COOK_LEARN[d], name) for d, name in BattleSettings.COOK_DISHES.items())
    return []


def equip_help(item: str | None) -> list[str]:
    """The help line's two lines for ``item``: its trade alone, or what it is when it has none."""
    if item is None:
        return []
    return help_wrap(with_english(item, trade_line(item) or description(item)))


def weapons_for(member_id: str) -> list[dict[str, Any]]:
    """The weapon a member starts with, as a list (the demo's first weapon each, Frankie 10/23)."""
    weapon = by_id("weapons").get(by_id("characters").get(member_id, {}).get("weapon") or "")
    return [weapon] if weapon else []
