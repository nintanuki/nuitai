"""The EQUIP screen, Final Fantasy VI's (Frankie, 10/24, from four screenshots of Cyan's).

Pushed by the field menu once a member is picked. At the top a bar of
commands: Equip, Optimum, Remove, Empty. Under it the two slots, Weapon
and Relic, each item with its icon before its name, then the line Final
Fantasy VI uses for Head and Body: the elements, each element's icon
with a green arrow up or a red one down, for a weapon the damage it
deals (none yet: only stat effects work) and for a relic the damage it
resists. The line follows the cursor (Frankie, 10/24): on a slot it is
what is worn there, in the list what the item under the cursor would
make it, so the difference shows before the swap; on the command bar it
is empty. The portrait and name at the right. Below, the list to pick
from at the left, the one worn grayed, and the stats at the right, HP
then the eight, as they are and as they would be, a rise in yellow and a
drop in red. Picking a slot swaps the bar for a small EQUIP box and a
help line of two saying what the item under the cursor does, its trade
in one plain line (Frankie, 10/24).

Equip picks a slot, then what goes in it; Remove picks a slot and puts
what is in it back in the bag; Empty puts both back; Optimum fills each
empty slot with the first thing in the bag that fits (Claude's call:
no weapon is better, only different). L1 and R1 switch member.

Rows are 12 pixels apart here, as Final Fantasy VI packs this screen,
not the game's 16 (Frankie saw and liked it, 10/24): at 16 the four slot
lines, nine stat lines and the portrait do not fit in 224. The cartridge
draws text on an 8 pixel grid, which is in the TODO.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pygame

from core.equipment import can_hold, description, element_changes, slot_of, trade_line
from core.factories import stance_numbers
from core.scene import Scene
from core.shared import short_name
from core.stats import STAT_SHORT
from settings import ColorSettings, FontSettings, ItemSettings, UISettings
from ui import input_map, text_renderer
from ui.battle_stage import element_icon
from ui.item_icon import item_icon
from ui.scroll_mark import draw_list_marks
from ui.window import draw_window, help_wrap
from utils.backgrounds import render_scene_background
from utils.graphics import load_portrait

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


SIZE = FontSettings.SIZE_BODY
ROW = 12                                  # Final Fantasy VI's pitch on this screen.
COMMANDS = ("Equip", "Optimum", "Remove", "Empty")
_COMMAND_X = (24, 80, 152, 208)
SLOTS = ("weapon", "relic")
_SLOT_LABELS = {"weapon": "Weapon", "relic": "Relic"}
# The top: the bar's window, or the one window under the small EQUIP box.
_BAR_RECT = pygame.Rect(0, 0, 256, 24)
_SLOTS_RECT = pygame.Rect(0, 24, 256, 72)
_PICK_RECT = pygame.Rect(0, 8, 256, 88)
_LABEL_RECT = pygame.Rect(176, 0, 80, 24)
_HELP_POS = (16, 28)                      # The help line's first line; the second a row under it.
_SLOTS_TOP = {"command": 36, "pick": 52}  # Weapon's row; Relic, then the element line, under it.
_ELEMENT_ROW = 2                          # The element line and the name, rows under Weapon.
_ITEM_X = 80                              # An item's name; its icon a letter before.
_PORTRAIT_X = 200
_PORTRAIT_Y = {"command": 32, "pick": 40}
_NAME_RIGHT = 192
# The bottom: the list at the left, the stats at the right.
_LOWER_RECT = pygame.Rect(0, 96, 256, 128)
_LIST_TOP = 108
_LIST_X = 24
_LIST_ROWS = 9
_STAT_X = 144
_MARK_X = 132                             # The list's scroll arrows, before the stats.
_NOW_RIGHT = 200
_ARROW_X = 203
_THEN_RIGHT = 240
_ARROW_UP = ("...#...", "..###..", ".#####.", "...#...", "...#...", "...#...", ".......")
_ARROW_DOWN = _ARROW_UP[-2::-1] + (".......",)


def candidates(party, member: "PartyMember", slot: str) -> list[str]:
    """What can go in ``slot``: the one worn first, then what in the bag ``member`` can use."""
    worn = getattr(member, slot)
    bag = sorted((item for item, count in party.inventory.items()
                  if count > 0 and slot_of(item) == slot and can_hold(member.id, item) and item != worn),
                 key=lambda item: ItemSettings.NAMES.get(item, item))
    return ([worn] if worn else []) + bag


def put_on(party, member: "PartyMember", slot: str, item: str | None) -> None:
    """Wear ``item`` in ``slot`` (None empties it): what was there goes back in the bag."""
    worn = getattr(member, slot)
    if worn == item:
        return
    if worn:
        party.inventory[worn] = party.inventory.get(worn, 0) + 1
    if item:
        party.inventory[item] -= 1
        if party.inventory[item] <= 0:
            del party.inventory[item]
    setattr(member, slot, item)
    member.refresh_stats()
    member.current_hp = min(member.current_hp, member.max_hp)


def numbers(member: "PartyMember", weapon: str | None) -> dict[str, int]:
    """HP and the eight stats in the stance the member starts a fight in, holding ``weapon``."""
    held = member.weapon
    member.weapon = weapon
    try:
        points, _, top = stance_numbers(member)
    finally:
        member.weapon = held
    return {"max_hp": top, **points}


class EquipScene(Scene):
    """One member's weapon and relic."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", member: "PartyMember") -> None:
        super().__init__(gm)
        self.member = member
        self.state = "command"    # "command", then "slot", then "list".
        self.command = 0
        self.slot = 0
        self.pick = 0
        self.removing = False

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def _move(self, changed: bool) -> None:
        if changed:
            self.gm.audio.play("menu_move")

    def _choices(self) -> list[str]:
        return candidates(self.gm.party, self.member, SLOTS[self.slot])

    def handle_event(self, event: pygame.event.Event) -> None:
        if input_map.is_l1(event) or input_map.is_r1(event):
            self._switch(-1 if input_map.is_l1(event) else 1)
        elif self.state == "command":
            self._handle_command(event)
        elif self.state == "slot":
            self._handle_slot(event)
        else:
            self._handle_list(event)

    def _handle_command(self, event: pygame.event.Event) -> None:
        if input_map.is_left(event) or input_map.is_right(event):
            step = -1 if input_map.is_left(event) else 1
            self.command = (self.command + step) % len(COMMANDS)
            self._move(True)
        elif input_map.is_confirm(event):
            self.gm.audio.play("menu_select")
            chosen = COMMANDS[self.command]
            if chosen in ("Equip", "Remove"):
                self.state, self.removing = "slot", chosen == "Remove"
            elif chosen == "Empty":
                for slot in SLOTS:
                    put_on(self.gm.party, self.member, slot, None)
            else:
                self._optimum()
        elif input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()

    def _handle_slot(self, event: pygame.event.Event) -> None:
        if input_map.is_up(event) or input_map.is_down(event):
            self.slot = 1 - self.slot
            self._move(True)
        elif input_map.is_confirm(event):
            self.gm.audio.play("menu_select")
            if self.removing:
                put_on(self.gm.party, self.member, SLOTS[self.slot], None)
            else:
                self.state, self.pick = "list", 0
        elif input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.state = "command"

    def _handle_list(self, event: pygame.event.Event) -> None:
        choices = self._choices()
        if choices and (input_map.is_up(event) or input_map.is_down(event)):
            step = -1 if input_map.is_up(event) else 1
            before = self.pick
            self.pick = (self.pick + step) % len(choices)
            self._move(self.pick != before)
        elif input_map.is_confirm(event) and choices:
            self.gm.audio.play("menu_select")
            put_on(self.gm.party, self.member, SLOTS[self.slot], choices[self.pick])
            self.state = "slot"
        elif input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.state = "slot"

    def _optimum(self) -> None:
        """Fill each empty slot with the first thing in the bag that fits."""
        for slot in SLOTS:
            if getattr(self.member, slot) is None:
                choices = candidates(self.gm.party, self.member, slot)
                if choices:
                    put_on(self.gm.party, self.member, slot, choices[0])

    def _switch(self, step: int) -> None:
        """L1 and R1: the previous or next member who travels, as on the Element page (Frankie, 10/23)."""
        members = self.gm.party.members
        if len(members) < 2:
            return
        index = next((i for i, m in enumerate(members) if m is self.member), 0)
        self.member = members[(index + step) % len(members)]
        self.pick = 0
        self.gm.audio.play("menu_move")

    # ------------------------------------------------------------------
    # DRAWING
    # ------------------------------------------------------------------

    def _pointed(self) -> str | None:
        """What the cursor is on: the item under it in the list, on a slot what is worn there."""
        if self.state == "command":
            return None
        return self._highlighted() if self.state == "list" else getattr(self.member, SLOTS[self.slot])

    def _highlighted(self) -> str | None:
        """The item the list's cursor is on, while choosing."""
        choices = self._choices()
        return choices[self.pick] if self.state == "list" and choices else None

    def render(self, surface: pygame.Surface) -> None:
        render_scene_background(self, surface)
        surface.fill(ColorSettings.BLACK)
        highlighted = self._highlighted()
        if self.state == "command":
            draw_window(surface, _BAR_RECT)
            for x, word in zip(_COMMAND_X, COMMANDS):
                _text(surface, word, x, 8)
            _pointer(surface, _COMMAND_X[self.command], 8)
            draw_window(surface, _SLOTS_RECT)
            top = _SLOTS_TOP["command"]
        else:
            draw_window(surface, _PICK_RECT)
            draw_window(surface, _LABEL_RECT)
            _text(surface, "Equip", _LABEL_RECT.x + 20, 8, ColorSettings.LABEL_CYAN)
            for row, words in enumerate(equip_help(self._pointed())):
                _text(surface, words, _HELP_POS[0], _HELP_POS[1] + row * ROW)
            top = _SLOTS_TOP["pick"]
        self._render_slots(surface, top, highlighted)
        self._render_lower(surface, highlighted)

    def _render_slots(self, surface: pygame.Surface, top: int, highlighted: str | None) -> None:
        """Weapon and Relic with their items, the two element lines, the portrait and name."""
        for index, slot in enumerate(SLOTS):
            y = top + index * ROW
            _text(surface, _SLOT_LABELS[slot], 16, y, ColorSettings.LABEL_CYAN)
            if self.state != "command" and index == self.slot:
                _pointer(surface, 16, y, ColorSettings.GRAY if self.state == "list" else ColorSettings.YELLOW)
            worn = getattr(self.member, slot)
            if worn:
                _item(surface, worn, _ITEM_X, y)
        # The element line follows the cursor; a weapon's is empty, none pushes an element yet.
        _element_line(surface, _ITEM_X - 8, top + _ELEMENT_ROW * ROW, element_changes(self._pointed()))
        surface.blit(load_portrait(self.member.id), (_PORTRAIT_X, _PORTRAIT_Y["command" if self.state == "command" else "pick"]))
        _text(surface, short_name(self.member.id), _NAME_RIGHT, top + _ELEMENT_ROW * ROW, right=True)

    def _render_lower(self, surface: pygame.Surface, highlighted: str | None) -> None:
        """The list to pick from, then HP and the stats as they are and as they would be."""
        draw_window(surface, _LOWER_RECT)
        if self.state != "command":
            choices = self._choices()
            first = max(0, self.pick - _LIST_ROWS + 1) if self.state == "list" else 0
            worn = getattr(self.member, SLOTS[self.slot])
            for row, item in enumerate(choices[first:first + _LIST_ROWS]):
                y = _LIST_TOP + row * ROW
                _item(surface, item, _LIST_X, y, ColorSettings.GRAY if item == worn else ColorSettings.WHITE)
                if self.state == "list" and first + row == self.pick:
                    _pointer(surface, _LIST_X - 8, y)
            draw_list_marks(surface, _MARK_X, _LIST_TOP, ROW, first, _LIST_ROWS, len(choices))
        now = numbers(self.member, self.member.weapon)
        then = None
        if self.state != "command":
            weapon = highlighted if highlighted and SLOTS[self.slot] == "weapon" else self.member.weapon
            then = numbers(self.member, weapon)
        for row, (key, label) in enumerate({"max_hp": "HP", **STAT_SHORT}.items()):
            y = _LIST_TOP + row * ROW
            _text(surface, label, _STAT_X, y, ColorSettings.LABEL_CYAN)
            _text(surface, str(now[key]), _NOW_RIGHT, y, right=True)
            if then is None:
                continue
            color = (ColorSettings.YELLOW if then[key] > now[key]
                     else ColorSettings.STAT_DROP if then[key] < now[key] else ColorSettings.WHITE)
            # The font has no arrow, so it is drawn.
            pygame.draw.polygon(surface, color, [(_ARROW_X, y + 1), (_ARROW_X + 4, y + 4), (_ARROW_X, y + 7)])
            _text(surface, str(then[key]), _THEN_RIGHT, y, color, right=True)


def _text(surface: pygame.Surface, words: str, x: int, y: int,
          color=ColorSettings.WHITE, right: bool = False) -> None:
    """Words at ``x``, or ending at ``x`` when ``right``."""
    if right:
        x -= text_renderer.text_width(words, SIZE)
    text_renderer.draw_text(surface, words, (x, y), color=color, size=SIZE)


def _pointer(surface: pygame.Surface, x: int, y: int, color=ColorSettings.YELLOW) -> None:
    """The cursor, its tip just left of a word at ``x``."""
    text_renderer.draw_pointer(surface, (x - UISettings.MENU_LABEL_OFFSET, y + SIZE // 2), color)


def _item(surface: pygame.Surface, item: str, x: int, y: int, color=ColorSettings.WHITE) -> None:
    """An item's icon in the letter space before ``x``, its name after."""
    icon = item_icon(item)
    if icon is not None:
        surface.blit(icon, (x - 8, y))
    _text(surface, ItemSettings.NAMES.get(item, item), x, y, color)


def _element_line(surface: pygame.Surface, x: int, y: int, changes: list[tuple[str, int]]) -> None:
    """Each element's icon with its arrow, a green one up and a red one down, a letter apart."""
    for element, direction in changes:
        icon = element_icon(element)
        if icon is not None:
            surface.blit(icon, (x, y))
        color = ColorSettings.ELEMENT_ARROW if direction > 0 else ColorSettings.STAT_DROP
        for dy, row in enumerate(_ARROW_UP if direction > 0 else _ARROW_DOWN):
            for dx, pixel in enumerate(row):
                if pixel == "#":
                    surface.set_at((x + 8 + dx, y + dy), color)
        x += 24


def equip_help(item: str | None) -> list[str]:
    """The help line's two lines for ``item``: its trade alone, or what it is when it has none."""
    if item is None:
        return []
    return help_wrap(trade_line(item) or description(item))


def weapons_for(member_id: str) -> list[dict[str, Any]]:
    """The weapon a member starts with, as a list (the demo's first weapon each, Frankie 10/23)."""
    from core.shared import by_id

    weapon = by_id("weapons").get(by_id("characters").get(member_id, {}).get("weapon") or "")
    return [weapon] if weapon else []
