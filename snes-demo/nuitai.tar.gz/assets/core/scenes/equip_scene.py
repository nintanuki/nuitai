"""The EQUIP screen: change the weapon a member holds (D-462).

Pushed by the field menu once a member is picked. Final Fantasy VI's
layout (Frankie, 10/23): the small box saying Equip with the member's name
beside it, the help line saying what the highlighted weapon is (so it never
runs off the screen), then what the member holds, the list, and the stats,
each with the number it would become beside it when the highlighted weapon
changes it, before it is taken. Confirm takes it up; cancel goes back.

In the demo each member has one weapon, the one they start with, and
nothing else to pick (Frankie, 10/23: Kailo the Frying Pan, Hina the Gohei,
Maika the Ko'oko'o, Tawiri the Tokotoko); Free Battle keeps every weapon.
Weapons change no stat yet (effects come later), so no number has a second
one beside it. Each weapon's name has its type's icon before it, in a
letter's space, Final Fantasy VI's (Frankie, 10/24; ui/item_icon.py).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pygame

from core.factories import stance_numbers
from core.scene import Scene
from core.shared import by_id, short_name
from core.stats import STAT_SHORT
from settings import ColorSettings, FontSettings, UISettings
from ui import input_map, text_renderer
from ui.element_tag import CELL
from ui.item_icon import weapon_icon
from ui.menu import Menu, MenuItem
from ui.window import draw_header, help_wrap
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


# Every word on the 8 pixel grid, so the cartridge draws them in the same places.
_HOLDS_Y = UISettings.HEADER_LIST_TOP     # "Holds" and the weapon held.
_HOLDS_NAME_X = 72                        # The icon in the letter space before it.
_LIST_POS = (40, 96)                      # The names; the icons a letter before.
_ROW_HEIGHT = 24
_LIST_ROWS = 2                            # Rows the list shows; it scrolls past them.
_STATS_TOP_Y = 152                        # Four rows of two: label, number, and the new one.
_STATS_COL_X = (16, 136)
_STATS_NUMBER_RIGHT = 56                  # From a column's left: where the number ends.
_STATS_NEW_RIGHT = 88                     # And where the number it would become ends, after ">".


def weapons_for(member_id: str) -> list[dict[str, Any]]:
    """The weapons a member can pick: in the demo, only the one they start with (Frankie, 10/23)."""
    weapon = by_id("weapons").get(by_id("characters").get(member_id, {}).get("weapon") or "")
    return [weapon] if weapon else []


def weapon_stats(weapon: dict[str, Any] | None) -> dict[str, int]:
    """What a weapon adds to each stat. None of them adds anything yet: effects come later."""
    return dict((weapon or {}).get("stats", {}))


class EquipScene(Scene):
    """One member's weapons, to choose which they hold."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", member: "PartyMember") -> None:
        """List the weapons ``member`` can use."""
        super().__init__(gm)
        self._load(member)

    def _load(self, member: "PartyMember") -> None:
        """Show ``member``'s weapons, the cursor on the one they hold."""
        self.member = member
        self.weapons = weapons_for(member.id)
        self.menu = Menu(
            items=[MenuItem(w["name"], lambda w=w: self._take(w), tag=weapon_icon(w)) for w in self.weapons],
            on_cancel=lambda: self.gm.scene_stack.pop(),
        )
        held = [w["id"] for w in self.weapons]
        if member.weapon in held:
            self.menu.cursor = held.index(member.weapon)

    def _switch(self, step: int) -> None:
        """L1 and R1: the previous or next member who travels, as on the Element page (Frankie, 10/23)."""
        members = self.gm.party.members
        if len(members) < 2:
            return
        index = next((i for i, m in enumerate(members) if m is self.member), 0)
        self._load(members[(index + step) % len(members)])
        self.gm.audio.play("menu_move")

    def _take(self, weapon: dict[str, Any]) -> None:
        """Hold ``weapon``."""
        self.member.weapon = weapon["id"]

    def handle_event(self, event: pygame.event.Event) -> None:
        """Up and down choose, confirm takes it up, L1 and R1 switch member, cancel goes back."""
        if input_map.is_l1(event) or input_map.is_r1(event):
            self._switch(-1 if input_map.is_l1(event) else 1)
        elif input_map.is_up(event):
            if self.menu.move_up():
                self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            if self.menu.move_down():
                self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            if self.menu.confirm():
                self.gm.audio.play("menu_select")
        elif input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.menu.cancel()

    def render(self, surface: pygame.Surface) -> None:
        """The top boxes, what is held, the list, and the stats with what would change."""
        render_scene_background(self, surface)
        highlighted = self.weapons[self.menu.cursor] if self.weapons else None
        draw_header(surface, "Equip", help_wrap((highlighted or {}).get("about", "")),
                    corner=short_name(self.member.id))
        size = FontSettings.SIZE_BODY
        held = by_id("weapons").get(self.member.weapon or "")
        text_renderer.draw_text(surface, "Holds", (_STATS_COL_X[0], _HOLDS_Y), color=ColorSettings.GRAY, size=size)
        if held:
            text_renderer.draw_text(surface, held["name"], (_HOLDS_NAME_X, _HOLDS_Y), color=ColorSettings.WHITE,
                                    size=size)
            surface.blit(weapon_icon(held), (_HOLDS_NAME_X - CELL, _HOLDS_Y))
        for item, weapon in zip(self.menu.items, self.weapons):
            item.color = ColorSettings.YELLOW if held and weapon["id"] == held["id"] else None
        first = max(0, self.menu.cursor - _LIST_ROWS + 1)
        shown = Menu(items=self.menu.items[first:first + _LIST_ROWS])
        shown.cursor = self.menu.cursor - first
        shown.render(surface, _LIST_POS, font_size=size, row_height=_ROW_HEIGHT)
        self._render_stats(surface, held, highlighted)

    def _render_stats(self, surface: pygame.Surface, held, highlighted) -> None:
        """Each stat as it is, and beside it the number it would become with ``highlighted``."""
        size = FontSettings.SIZE_BODY
        points, _, _ = stance_numbers(self.member)
        now, then = weapon_stats(held), weapon_stats(highlighted)
        for index, (key, label) in enumerate(STAT_SHORT.items()):
            x = _STATS_COL_X[index % 2]
            y = _STATS_TOP_Y + (index // 2) * 16
            value = points.get(key, 0)
            text_renderer.draw_text(surface, label, (x, y), color=ColorSettings.WHITE, size=size)
            words = str(value)
            text_renderer.draw_text(surface, words, (x + _STATS_NUMBER_RIGHT - text_renderer.text_width(words, size), y),
                                    color=ColorSettings.WHITE, size=size)
            new = value - now.get(key, 0) + then.get(key, 0)
            if new != value:
                color = ColorSettings.YELLOW if new > value else ColorSettings.GRAY
                text_renderer.draw_text(surface, ">", (x + _STATS_NUMBER_RIGHT, y), color=color, size=size)
                words = str(new)
                text_renderer.draw_text(surface, words, (x + _STATS_NEW_RIGHT - text_renderer.text_width(words, size), y),
                                        color=color, size=size)
