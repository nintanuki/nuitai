"""Kaigara on the screen: the chalk grid, the cowries, Gajumaru across the stone.

The rules are ``systems/kaigara.py``; the look is the mockup,
``docs/design/kaigara-board-preview.svg`` (10/27), its colors all in
``KaigaraSettings`` so the board is easy to restyle. The stone fills the
left of the screen, a point every 16 pixels; the window on the right holds
his face and name, the shells each side has taken, and Pass and Resign; the
bottom window has his slow talk, or what is going on. The player is black
and goes first: the D-pad moves the cursor, confirm puts a shell down,
cancel goes to Pass and Resign (cancel again comes back). He says something
slowly, thinks, and puts his shell anywhere legal at random; a yellow ring
marks it. When the game is over the count is shown, and confirm goes back
to the lodge, which calls ``on_done`` with the winner.
"""

from __future__ import annotations

import random
import time
from typing import TYPE_CHECKING, Callable, Optional

import pygame

from core.scene import Scene
from settings import ColorSettings, FontSettings, KaigaraSettings as K, UISettings
from systems import kaigara
from systems.kaigara import BLACK, WHITE, Board
from ui import input_map, text_renderer
from ui.window import draw_window
from utils.backgrounds import render_scene_background
from utils.graphics import speaker_face

if TYPE_CHECKING:
    from main import GameManager

# The flecked stone, drawn once.
_STONE: pygame.Surface | None = None


def point_xy(point: tuple[int, int]) -> tuple[int, int]:
    """The screen pixel of a point on the grid."""
    col, row = point
    return K.FIRST_POINT[0] + col * K.POINT_GAP, K.FIRST_POINT[1] + row * K.POINT_GAP


def draw_shell(surface: pygame.Surface, center: tuple[int, int], color: str) -> None:
    """A cowrie: an oval with its edge, a toothed slit along the middle, a glint top left."""
    w, h = K.SHELL_SIZE
    x, y = center
    rect = pygame.Rect(x - w // 2, y - h // 2, w, h)
    body, edge, slit = ((K.BLACK_SHELL, K.BLACK_EDGE, K.BLACK_SLIT) if color == BLACK
                        else (K.WHITE_SHELL, K.WHITE_EDGE, K.WHITE_SLIT))
    pygame.draw.ellipse(surface, body, rect)
    pygame.draw.ellipse(surface, edge, rect, 1)
    pygame.draw.line(surface, slit, (x - 3, y + 1), (x + 3, y + 1))
    for tooth in (-2, 0, 2):
        surface.set_at((x + tooth, y), slit)
    surface.set_at((x - 3, y - 2), ColorSettings.WHITE if color == WHITE else K.BLACK_SLIT)


def _stone() -> pygame.Surface:
    """The slab with its flecks, the same every time."""
    global _STONE
    if _STONE is None:
        rect = pygame.Rect(K.STONE_RECT)
        _STONE = pygame.Surface(rect.size, pygame.SRCALPHA)
        local = _STONE.get_rect()
        pygame.draw.rect(_STONE, K.STONE, local, border_radius=K.STONE_CORNER)
        rng = random.Random(9)
        for _ in range(K.FLECK_COUNT):
            x, y = rng.randrange(6, local.width - 8), rng.randrange(6, local.height - 8)
            pygame.draw.rect(_STONE, rng.choice(K.STONE_FLECKS), (x, y, 2, 2))
        pygame.draw.rect(_STONE, K.STONE_EDGE, local, 2, border_radius=K.STONE_CORNER)
    return _STONE


class KaigaraScene(Scene):
    """One game of Kaigara against Gajumaru."""

    def __init__(self, gm: "GameManager", on_done: Callable[[Optional[str]], None] | None = None,
                 rng: random.Random | None = None) -> None:
        super().__init__(gm)
        self.board = Board()
        self.on_done = on_done
        self.rng = rng or random.Random()
        self.cursor = (kaigara.SIZE // 2, kaigara.SIZE // 2)
        # Pass or Resign while the player is in the right window, else None.
        self.menu: int | None = None
        # The bottom window: who says it (None for what is going on), the words, how many letters are out.
        self.speaker: str | None = None
        self.message = ""
        self._shown = 0.0
        self.say(K.START)
        # Seconds until he puts his shell down, while it is his turn.
        self._think = 0.0

    # ------------------------------------------------------------------
    # THE BOTTOM WINDOW
    # ------------------------------------------------------------------

    def say(self, line: str) -> None:
        """Gajumaru says ``line``, slowly."""
        self.speaker, self.message, self._shown = K.SPEAKER, line, 0.0

    def tell(self, line: str) -> None:
        """What is going on, at once, no speaker."""
        self.speaker, self.message, self._shown = None, line, float(len(line))

    def typed(self) -> bool:
        return self._shown >= len(self.message)

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        if self.board.over:
            if input_map.is_confirm(event):
                self.gm.audio.play("menu_select")
                self.gm.scene_stack.pop()
                if self.on_done is not None:
                    self.on_done(self.board.winner())
            return
        if self.board.turn != BLACK:
            return
        if self.menu is not None:
            self._menu_event(event)
            return
        col, row = self.cursor
        moves = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}
        for name, (dx, dy) in moves.items():
            if getattr(input_map, f"is_{name}")(event):
                step = (min(max(col + dx, 0), kaigara.SIZE - 1), min(max(row + dy, 0), kaigara.SIZE - 1))
                if step != self.cursor:
                    self.cursor = step
                    self.gm.audio.play("menu_move")
                return
        if input_map.is_confirm(event):
            self.place(self.cursor)
        elif input_map.is_cancel(event):
            self.menu = 0
            self.gm.audio.play("menu_select")

    def _menu_event(self, event: pygame.event.Event) -> None:
        """In the right window: up and down pick Pass or Resign, confirm does it, cancel goes back."""
        if input_map.is_up(event) or input_map.is_down(event):
            self.menu = 1 - self.menu
            self.gm.audio.play("menu_move")
        elif input_map.is_cancel(event):
            self.menu = None
        elif input_map.is_confirm(event):
            picked, self.menu = self.menu, None
            self.gm.audio.play("menu_select")
            if picked == 0:
                self.pass_turn()
            else:
                self.resign()

    def place(self, point: tuple[int, int]) -> bool:
        """The player puts a shell on ``point``; False, and why not, if they cannot."""
        why = self.board.why_not(point)
        if why:
            self.tell(K.CANNOT[why])
            self.gm.audio.play("blip")
            return False
        self.board.play(point)
        self.gm.audio.play("menu_select")
        self._kame_turn()
        return True

    def pass_turn(self) -> None:
        self.board.pass_turn()
        self._kame_turn()

    def resign(self) -> None:
        self.board.resign(BLACK)
        self._show_end()

    # ------------------------------------------------------------------
    # GAJUMARU
    # ------------------------------------------------------------------

    def _kame_turn(self) -> None:
        if self.board.over:
            self._show_end()
            return
        self.say(self.rng.choice(K.THINKING))
        self._think = max(K.THINK_SECONDS,
                          len(self.message) / K.SLOW_CHARS_PER_SECOND + K.AFTER_LINE_SECONDS)

    def kame_plays(self) -> None:
        """He puts his shell down, or passes; then it is the player's turn, or the count."""
        move = kaigara.kame_move(self.board, self.rng)
        if move is None:
            self.board.pass_turn()
            self.say(K.KAME_PASSES)
        else:
            self.board.play(move)
            self.gm.audio.play("menu_move")
        if self.board.over:
            self._show_end()

    def _show_end(self) -> None:
        score = self.board.score()
        winner = self.board.winner()
        verdict = K.WIN if winner == BLACK else K.LOSE if winner == WHITE else K.DRAW
        first = K.RESIGNED if self.board.resigned else K.SCORE.format(b=score[BLACK], w=score[WHITE])
        self.tell(f"{first} {verdict}")

    def update(self, dt: float) -> None:
        if not self.typed():
            self._shown = min(len(self.message), self._shown + K.SLOW_CHARS_PER_SECOND * dt)
        if self.board.over or self.board.turn != WHITE:
            return
        self._think -= dt
        if self._think <= 0:
            self.kame_plays()

    # ------------------------------------------------------------------
    # DRAWING
    # ------------------------------------------------------------------

    def render(self, surface: pygame.Surface) -> None:
        render_scene_background(self, surface)
        self._render_stone(surface)
        self._render_side(surface)
        self._render_message(surface)

    def _render_stone(self, surface: pygame.Surface) -> None:
        surface.blit(_stone(), pygame.Rect(K.STONE_RECT).topleft)
        first, last = point_xy((0, 0)), point_xy((kaigara.SIZE - 1, kaigara.SIZE - 1))
        for k in range(kaigara.SIZE):
            x, y = point_xy((k, k))
            pygame.draw.line(surface, K.CHALK, (x, first[1]), (x, last[1]))
            pygame.draw.line(surface, K.CHALK, (first[0], y), (last[0], y))
        for star in K.STAR_POINTS:
            x, y = point_xy(star)
            pygame.draw.rect(surface, K.CHALK, pygame.Rect(x - 1, y - 1, 3, 3))
        for point in self.board.points():
            if self.board.at(point) != kaigara.EMPTY:
                draw_shell(surface, point_xy(point), self.board.at(point))
        last_move = self.board.last
        if last_move is not None and self.board.at(last_move) == WHITE:
            pygame.draw.circle(surface, K.MARK, point_xy(last_move), K.RING_RADIUS, 1)
        if not self.board.over and self.board.turn == BLACK and self.menu is None:
            self._render_cursor(surface)

    def _render_cursor(self, surface: pygame.Surface) -> None:
        """Four yellow corners around the point."""
        x, y = point_xy(self.cursor)
        r, arm = K.CURSOR_REACH, K.CURSOR_ARM
        for sx in (-1, 1):
            for sy in (-1, 1):
                cx, cy = x + sx * r, y + sy * r
                pygame.draw.line(surface, K.MARK, (cx, cy), (cx - sx * arm, cy), 2)
                pygame.draw.line(surface, K.MARK, (cx, cy), (cx, cy - sy * arm), 2)

    def _render_side(self, surface: pygame.Surface) -> None:
        rect = pygame.Rect(K.SIDE_RECT)
        draw_window(surface, rect)
        size = FontSettings.SIZE_BODY
        face_size = UISettings.PORTRAIT_SIZE
        face = pygame.Rect(rect.centerx - face_size // 2, rect.top + 6, face_size, face_size)
        picture = speaker_face(K.SPEAKER)
        if picture is not None:
            surface.blit(picture, face.topleft)
        pygame.draw.rect(surface, K.FACE_FRAME, face.inflate(2, 2), 1)
        name_w = text_renderer.text_width(K.SPEAKER, size)
        text_renderer.draw_text(surface, K.SPEAKER, (rect.centerx - name_w // 2, face.bottom + 6), size=size)
        x, y = rect.left + 8, face.bottom + 20
        text_renderer.draw_text(surface, K.TAKEN, (x, y), color=K.TAKEN_COLOR, size=size)
        for color in (BLACK, WHITE):
            y += 12
            draw_shell(surface, (x + 6, y + 3), color)
            text_renderer.draw_text(surface, str(self.board.taken[color]), (x + 18, y), size=size)
        y += 16
        for index, label in enumerate(K.MENU):
            if self.menu == index:
                text_renderer.draw_pointer(surface, (x + 4, y + size // 2))
            text_renderer.draw_text(surface, label, (x + 10, y), size=size)
            y += 12

    def _render_message(self, surface: pygame.Surface) -> None:
        rect = pygame.Rect(K.MESSAGE_RECT)
        draw_window(surface, rect)
        size = FontSettings.SIZE_BODY
        x, y = rect.left + 10, rect.top + 10
        if self.speaker:
            text_renderer.draw_text(surface, self.speaker, (x, y), color=ColorSettings.YELLOW, size=size, spoken=True)
            y += 16
        text_renderer.draw_text(surface, self.message[:int(self._shown)], (x, y), size=size,
                                max_width=rect.width - 20, spoken=True)
        if self.board.over and int(time.monotonic() * 2) % 2 == 0:
            # The text box's corner triangle: confirm goes on.
            tip_x, tip_y = rect.right - 8, rect.bottom - 4
            pygame.draw.polygon(surface, ColorSettings.WHITE,
                                [(tip_x, tip_y), (tip_x - 4, tip_y - 4), (tip_x + 4, tip_y - 4)])
