"""The words before the prologue (Frankie, 10/25 and 10/27): white on black, typed out.

Four cards setting up the taro patch (``StorySettings.BLURB``), each typed letter by letter at the
text box's speed (Config's message speed), then a last card the same way, the place and the day,
each line of it centered (``PlaceSettings.OPENING_CARD``). Confirm while one
types shows it all; confirm after goes on to the next card, or closes the last, and after the last the taro
patch, waiting underneath, fades in from this black as Kailo's first line
slowly types (the field's ``open_from_black``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from settings import ColorSettings, FontSettings, ScreenSettings, StorySettings, UISettings
from systems import config
from ui import input_map, text_renderer

if TYPE_CHECKING:
    from main import GameManager

# The words keep this far from the screen's sides.
_MARGIN = 32


class BlurbScene(Scene):
    """A black screen typing out ``pages`` one card at a time; pops itself when all are read."""

    def __init__(self, gm: "GameManager", pages: str | tuple[str, ...] = StorySettings.BLURB,
                 centered: bool = False) -> None:
        super().__init__(gm)
        # One string is one card. A new line in a card starts a line of its own.
        self.pages = (pages,) if isinstance(pages, str) else tuple(pages)
        self.page = 0
        self.centered = centered
        self.shown = 0.0

    @property
    def text(self) -> str:
        """The card on screen."""
        return self.pages[self.page]

    def done(self) -> bool:
        return self.shown >= len(self.text)

    def handle_event(self, event: pygame.event.Event) -> None:
        if not input_map.is_confirm(event):
            return
        if not self.done():
            self.shown = len(self.text)
        elif self.page + 1 < len(self.pages):
            self.page += 1
            self.shown = 0.0
        else:
            self.gm.scene_stack.pop()

    def update(self, dt: float) -> None:
        times = config.current.text_times()
        step = len(self.text) if times is None else dt * UISettings.TYPEWRITER_CHARS_PER_SECOND * times
        self.shown = min(len(self.text), self.shown + step)

    def render(self, surface: pygame.Surface) -> None:
        surface.fill(ColorSettings.BLACK)
        font = text_renderer.get_font(FontSettings.SIZE_DIALOGUE)
        lines = [line for part in self.text.split("\n")
                 for line in text_renderer.wrap(part, font, ScreenSettings.WIDTH - 2 * _MARGIN)]
        row = text_renderer.line_height(FontSettings.SIZE_DIALOGUE)
        y = (surface.get_height() - row * len(lines)) // 2
        left = int(self.shown)
        for line in lines:
            if left <= 0:
                break
            x = (ScreenSettings.WIDTH - text_renderer.text_width(line, FontSettings.SIZE_DIALOGUE)) // 2 if self.centered                 else _MARGIN
            text_renderer.draw_text(surface, line[:left], (x, y), size=FontSettings.SIZE_DIALOGUE)
            # The wrap drops the space or new line between lines; count it, as typed.
            left -= len(line) + 1
            y += row
