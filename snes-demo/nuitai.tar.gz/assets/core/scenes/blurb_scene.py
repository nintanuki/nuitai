"""The words before the prologue (Frankie, 10/25): white on black, typed out.

A sentence or two setting up the taro patch, typed letter by letter at the
text box's speed. Confirm while it types shows it all; confirm after closes
it, and the taro patch, waiting underneath, begins.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from settings import ColorSettings, FontSettings, ScreenSettings, StorySettings, UISettings
from ui import input_map, text_renderer

if TYPE_CHECKING:
    from main import GameManager

# The words keep this far from the screen's sides.
_MARGIN = 32


class BlurbScene(Scene):
    """A black screen typing out ``text``; pops itself when read."""

    def __init__(self, gm: "GameManager", text: str = StorySettings.BLURB) -> None:
        super().__init__(gm)
        self.text = text.upper()
        self.shown = 0.0

    def done(self) -> bool:
        return self.shown >= len(self.text)

    def handle_event(self, event: pygame.event.Event) -> None:
        if not input_map.is_confirm(event):
            return
        if self.done():
            self.gm.scene_stack.pop()
        else:
            self.shown = len(self.text)

    def update(self, dt: float) -> None:
        self.shown = min(len(self.text), self.shown + dt * UISettings.TYPEWRITER_CHARS_PER_SECOND)

    def render(self, surface: pygame.Surface) -> None:
        surface.fill(ColorSettings.BLACK)
        font = text_renderer.get_font(FontSettings.SIZE_BODY)
        lines = text_renderer.wrap(self.text, font, ScreenSettings.WIDTH - 2 * _MARGIN)
        row = text_renderer.line_height(FontSettings.SIZE_BODY)
        y = (surface.get_height() - row * len(lines)) // 2
        left = int(self.shown)
        for line in lines:
            if left <= 0:
                break
            text_renderer.draw_text(surface, line[:left], (_MARGIN, y), size=FontSettings.SIZE_BODY)
            # The wrap drops the space between lines; count it, as typed.
            left -= len(line) + 1
            y += row
