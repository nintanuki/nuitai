"""The three save slots, for saving at a save point or loading from the title.

One scene does both (D-523). Each slot is a window showing when it was
saved, who leads and the money; an empty slot says so. Saving over a
slot that holds a game asks first, NO selected, as every question in the
game does. Loading puts the party back where it stood on the map.

Loading, a last line under the slots says DELETE A SAVE, as Zelda's file
screen has Erase (Frankie, 10/22): picking it turns the heading to Delete,
then a slot picked asks "Delete slot 2?", NO selected. Cancel goes back to
loading.

A save holds the party (``Party.to_dict``), the overworld's place
(``OverworldScene.to_dict``), the Config settings (``systems/config.py``)
and the time it was written.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any

import pygame

from core import save
from core.scene import Scene
from core.scenes.confirm_scene import ConfirmScene
from settings import ColorSettings, FontSettings, StorySettings, UISettings
from systems import config, records
from ui import input_map, text_renderer
from ui.window import draw_window
from utils.backgrounds import render_scene_background
from utils.graphics import load_element_icon, load_turn_face

if TYPE_CHECKING:
    from main import GameManager


_SLOT_TOP = 32   # under the label box (UISettings.HEADER_LABEL_RECT)
_BAR_HEIGHT = 18
_DETAIL_TOP = 32 + 3 * (18 + 4) + 2
_DETAIL_HEIGHT = 88
_SLOT_GAP = 4
_SLOT_LEFT = 8
_SLOT_WIDTH = 240
_MESSAGE_Y = 211


def snapshot(gm: "GameManager") -> dict[str, Any]:
    """Everything a save holds: the party, where it stands, and when."""
    from core.scenes.overworld_scene import OverworldScene  # local: cycle.

    from systems.places import place_of  # local: it reads the loaded rooms.

    field = gm.scene_stack.find(OverworldScene)
    area = place_of(field.world.current_cell_name) if field is not None else None
    return {
        "party": gm.party.to_dict(),
        "overworld": field.to_dict() if field is not None else {},
        "config": config.current.to_dict(),
        "saved_at": datetime.now().isoformat(timespec="minutes"),
        "area": area or "",
        "chapter": _chapter_from_flags(gm.party.flags),
    }


def resume(gm: "GameManager", data: dict[str, Any]) -> None:
    """Throw away the stack and walk on from a save's ``data``."""
    from core.scenes.overworld_scene import OverworldScene  # local: cycle.
    from core.scenes.title_scene import add_missing_members  # local: cycle.
    from systems.party import Party

    gm.party = Party.from_dict(data.get("party", {}))
    add_missing_members(gm.party)
    config.from_save(gm, data)
    gm.scene_stack.clear()
    gm.scene_stack.push(OverworldScene.from_dict(gm, data.get("overworld", {})))


# The third is after the demo, the morning after the jump (Claude's draft, 10/31).
CHAPTERS = ("The Pork Strikes Back", "Dead Men Tell No Tales", "Ship Happens")


def _chapter_from_flags(flags: dict[str, Any]) -> str:
    """The chapter: the second once the Great Boar is beaten (the night flag it sets),
    the third the morning after the jump."""
    if flags.get(StorySettings.AFTER_JUMP_FLAG):
        return CHAPTERS[2]
    return CHAPTERS[1 if flags.get(StorySettings.NIGHT_FLAG) else 0]


def chapter_of(data: dict[str, Any]) -> str:
    """A save's chapter; an older save without one works it out from its flags."""
    chapter = data.get("chapter")
    if chapter in CHAPTERS:
        return chapter
    flags = data.get("party", {}).get("flags", {})
    return _chapter_from_flags(flags if isinstance(flags, dict) else {})


def _when(data: dict[str, Any]) -> str:
    """The save's time as the slot shows it, e.g. ``Oct 18 4:52 PM``."""
    try:
        stamp = datetime.fromisoformat(str(data.get("saved_at", "")))
    except ValueError:
        return "An older save"
    hour = stamp.hour % 12 or 12
    return f"{stamp:%b} {stamp.day} {hour}:{stamp:%M} {'AM' if stamp.hour < 12 else 'PM'}"


def _played(party_data: dict[str, Any]) -> str:
    """The time played as a slot shows it, e.g. ``1:05``; an older save without it reads 0:00."""
    try:
        minutes = int(float(party_data.get("flags", {}).get(records.TIME_FLAG, 0.0))) // 60
    except (TypeError, ValueError):
        minutes = 0
    return f"{minutes // 60}:{minutes % 60:02d}"


class SaveSlotScene(Scene):
    """Three slots: confirm saves into one, or loads one."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", loading: bool) -> None:
        """Build the list.

        Args:
            gm: The host game manager.
            loading: True from the title (pick a game to load), False
                from the field menu (pick a slot to save into).
        """
        super().__init__(gm)
        self.loading = loading
        self._slots = list(save.player_slots())
        self._read_slots()
        # Loading starts on the newest save; saving on it too, since
        # that is usually the game being played.
        newest = save.newest_slot()
        self._cursor = self._slots.index(newest) if newest in self._slots else 0
        self._message = ""
        # Picking a slot deletes it instead of loading it.
        self._deleting = False

    def _read_slots(self) -> None:
        """Read what each slot holds, once, so the list does not touch the disk every frame."""
        self._data = {slot_id: save.peek(slot_id) for slot_id in self._slots}

    # ------------------------------------------------------------------
    # ACTIONS
    # ------------------------------------------------------------------

    def _rows(self) -> int:
        """How many places the cursor can be: the slots, and Delete a save when loading."""
        return len(self._slots) + (1 if self.loading and not self._deleting else 0)

    def _pick(self) -> None:
        """Save into or load the slot under the cursor, or delete it."""
        if self._cursor == len(self._slots):
            # Delete a save: the slots are picked for deleting now.
            self.gm.audio.play("menu_select")
            self._deleting = True
            self._message = ""
            newest = save.newest_slot()
            self._cursor = self._slots.index(newest) if newest in self._slots else 0
            return
        slot_id = self._slots[self._cursor]
        if self._deleting:
            if self._data[slot_id] is None:
                self.gm.audio.play("menu_move")
                return
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.push(ConfirmScene(
                self.gm, f"Delete slot {slot_id}?",
                on_yes=lambda: self._delete(slot_id),
            ))
            return
        held = self._data[slot_id]
        if self.loading:
            if held is None:
                self.gm.audio.play("menu_move")
                return
            self.gm.audio.play("menu_select")
            resume(self.gm, held)
            return
        self.gm.audio.play("menu_select")
        if held is None:
            self._write(slot_id)
            return
        self.gm.scene_stack.push(ConfirmScene(
            self.gm, f"Save over slot {slot_id}?",
            on_yes=lambda: self._write(slot_id),
        ))

    def _delete(self, slot_id: int) -> None:
        """Delete the save in ``slot_id``, say so, and go back to loading."""
        save.delete(slot_id)
        self._read_slots()
        self._deleting = False
        self._message = f"Deleted slot {slot_id}."

    def _write(self, slot_id: int) -> None:
        """Save the game into ``slot_id`` and say so."""
        save.save(slot_id, snapshot(self.gm))
        self._read_slots()
        self._message = f"Saved to slot {slot_id}."

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move between the slots, pick one, or step back."""
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            if self._deleting:
                self._deleting = False
                return
            self.gm.scene_stack.pop()
        elif input_map.is_up(event):
            self._cursor = (self._cursor - 1) % self._rows()
            self._message = ""
            self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            self._cursor = (self._cursor + 1) % self._rows()
            self._message = ""
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            self._pick()

    def render(self, surface: pygame.Surface) -> None:
        """The label box, then a window per slot, the chosen one framed in yellow."""
        render_scene_background(self, surface)
        draw_window(surface, surface.get_rect())
        # Final Fantasy VI's small box with the screen's name (Frankie,
        # 10/23); the slots leave no room for a help line.
        label = pygame.Rect(UISettings.HEADER_LABEL_RECT)
        draw_window(surface, label)
        text_renderer.draw_text(
            surface, "Delete" if self._deleting else "Load" if self.loading else "Save",
            (UISettings.HEADER_TEXT_X, label.top + 8), color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
        )
        for index, slot_id in enumerate(self._slots):
            self._render_slot(surface, index, slot_id)
        self._render_detail(surface)
        if self._message:
            text_renderer.draw_text(
                surface, self._message, (_SLOT_LEFT + 8, _MESSAGE_Y),
                color=ColorSettings.YELLOW, size=FontSettings.SIZE_BODY,
            )
        elif self.loading and not self._deleting:
            # The last place the cursor can be: Delete a save, gray with nothing to delete.
            any_saved = any(self._data[s] is not None for s in self._slots)
            text_renderer.draw_text(
                surface, "Delete a save", (_SLOT_LEFT + 16, _MESSAGE_Y),
                color=ColorSettings.WHITE if any_saved else ColorSettings.GRAY, size=FontSettings.SIZE_BODY,
            )
            if self._cursor == len(self._slots):
                tip = (_SLOT_LEFT + 12, _MESSAGE_Y + 3)
                pygame.draw.polygon(surface, ColorSettings.YELLOW, [
                    tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 5, tip[1] + 5),
                ])

    def _render_slot(self, surface: pygame.Surface, index: int, slot_id: int) -> None:
        """One short bar: the slot number and the chapter, or Empty."""
        rect = pygame.Rect(
            _SLOT_LEFT, _SLOT_TOP + index * (_BAR_HEIGHT + _SLOT_GAP), _SLOT_WIDTH, _BAR_HEIGHT,
        )
        draw_window(surface, rect)
        if index == self._cursor:
            pygame.draw.rect(surface, ColorSettings.YELLOW, rect, 1, border_radius=4)
            tip = (rect.left + 10, rect.top + 9)
            pygame.draw.polygon(surface, ColorSettings.YELLOW, [
                tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 5, tip[1] + 5),
            ])
        size = FontSettings.SIZE_BODY
        left = rect.left + UISettings.TEXT_BOX_PADDING + 8
        data = self._data[slot_id]
        if data is None:
            text_renderer.draw_text(
                surface, f"Slot {slot_id}   Empty", (left, rect.top + 5),
                color=ColorSettings.GRAY, size=size,
            )
            return
        text_renderer.draw_text(
            surface, f"{slot_id}  {chapter_of(data)}", (left, rect.top + 5),
            color=ColorSettings.WHITE, size=size,
        )

    def _render_detail(self, surface: pygame.Surface) -> None:
        """The panel under the bars, for the slot under the cursor: area, time, money, party."""
        if self._cursor >= len(self._slots):
            return
        data = self._data[self._slots[self._cursor]]
        if data is None:
            return
        rect = pygame.Rect(_SLOT_LEFT, _DETAIL_TOP, _SLOT_WIDTH, _DETAIL_HEIGHT)
        draw_window(surface, rect)
        size = FontSettings.SIZE_BODY
        pad = UISettings.TEXT_BOX_PADDING
        left = rect.left + pad + 8
        party = data.get("party", {})
        text_renderer.draw_text(
            surface, str(data.get("area") or ""), (left, rect.top + 10),
            color=ColorSettings.WHITE, size=size,
        )
        # Time played, hours:minutes as an old SNES RPG shows it (Frankie, 10/29).
        played = _played(party)
        text_renderer.draw_text(
            surface, played, (rect.right - pad - 8 - text_renderer.text_width(played, size), rect.top + 10),
            color=ColorSettings.WHITE, size=size,
        )
        text_renderer.draw_text(
            surface, _when(data), (left, rect.top + 26), color=ColorSettings.GRAY, size=size,
        )
        # The money by its icons (D-476), as the field menu shows it.
        x = left
        for icon_id in ("pule", "kupang"):
            icon = load_element_icon(icon_id)
            if icon is not None:
                surface.blit(icon, (x, rect.top + 42))
                x += icon.get_width() + 3
            amount = str(int(party.get(icon_id, 0)))
            text_renderer.draw_text(
                surface, amount, (x, rect.top + 46), color=ColorSettings.WHITE, size=size,
            )
            x += text_renderer.text_width(amount, size) + 12
        # The party by their turn-order faces (no names).
        x = left
        for member in party.get("members", [])[:3]:
            face = load_turn_face(str(member.get("id", "")))
            if face is not None:
                surface.blit(face, (x, rect.top + 64))
            x += 20
