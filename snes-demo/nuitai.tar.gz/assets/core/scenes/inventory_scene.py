"""The INVENTORY screen: the item list, and potions used from it.

Pushed by [core/scenes/menu_scene.py](menu_scene.py) when the player
picks Items. Lists each item in ``Party.inventory`` with its count. The
cursor picks an item; confirm on a potion opens the party in a window
along the bottom, and confirm on a member gives them the potion, as a
Final Fantasy field menu does. Cancel steps back, then pops back to the
system menu.

A potion out of battle heals what it heals in one (``POTION_HEAL_AMOUNT``)
in the HP the member shows, the stance they start a fight in (D-365). It
does not wake the knocked out, the same as in a fight, and is not spent
on someone already at full HP.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.factories import stance_numbers
from core.scene import Scene
from core.shared import short_name
from settings import BattleSettings, ColorSettings, FontSettings
from ui import input_map, text_renderer
from ui.window import draw_window
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


_HEADING_POSITION = (8, 8)
_LIST_TOP_Y = 40
_LIST_LEFT_X = 16
_LIST_ROW_HEIGHT = 16
_COUNT_X = 96

# The party window, along the bottom while a potion waits for a drinker.
_PARTY_RECT = pygame.Rect(0, 112, 256, 112)
_PARTY_TOP_Y = _PARTY_RECT.top + 12
_PARTY_ROW_HEIGHT = 13
_HP_X = 112

# Items that can be used here, and what they do.
_USABLE = {"potion"}


class InventoryScene(Scene):
    """The item list; a potion can be given to a party member."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Bind this scene to the host game manager.

        Args:
            gm: The host game manager. ``gm.party.inventory`` is the
                data source.
        """
        super().__init__(gm)
        self._item_cursor = 0
        # The item waiting for a member, or None while picking an item.
        self._using: str | None = None
        self._member_cursor = 0

    def _rows(self) -> list[tuple[str, int]]:
        """The items in a stable order, sorted by id so visits do not reshuffle them."""
        return sorted(self.gm.party.inventory.items())

    def _can_drink(self, member: "PartyMember") -> bool:
        """A potion helps the living who are hurt."""
        return 0 < member.current_hp < member.max_hp

    def _give_potion(self, member: "PartyMember") -> None:
        """Heal ``member`` by a potion's worth of the HP they show, and spend one."""
        _, shown, top = stance_numbers(member)
        healed = min(top, shown + BattleSettings.POTION_HEAL_AMOUNT)
        member.current_hp = min(member.max_hp, round(healed * member.max_hp / max(1, top)))
        # The count stays at 0 rather than going: a missing entry means
        # an old save, and the battle would hand out a new stack.
        self.gm.party.inventory["potion"] -= 1

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move the cursor, use an item, or step back."""
        if self._using is not None:
            self._handle_member_pick(event)
            return
        rows = self._rows()
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif rows and input_map.is_up(event):
            self._item_cursor = (self._item_cursor - 1) % len(rows)
            self.gm.audio.play("menu_move")
        elif rows and input_map.is_down(event):
            self._item_cursor = (self._item_cursor + 1) % len(rows)
            self.gm.audio.play("menu_move")
        elif rows and input_map.is_confirm(event):
            item_id, count = rows[self._item_cursor % len(rows)]
            if item_id in _USABLE and count > 0:
                self._using = item_id
                self.gm.audio.play("menu_select")

    def _handle_member_pick(self, event: pygame.event.Event) -> None:
        """Choose who gets the item; cancel goes back to the list."""
        members = self.gm.party.members
        if input_map.is_cancel(event):
            self._using = None
            self.gm.audio.play("menu_move")
        elif input_map.is_up(event):
            self._member_cursor = (self._member_cursor - 1) % len(members)
            self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            self._member_cursor = (self._member_cursor + 1) % len(members)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            member = members[self._member_cursor]
            if not self._can_drink(member):
                self.gm.audio.play("menu_move")
                return
            self._give_potion(member)
            self.gm.audio.play("hit_sparkle_1")
            if self.gm.party.inventory.get("potion", 0) <= 0:
                self._using = None

    def render(self, surface: pygame.Surface) -> None:
        """Paint the heading, each item row with the cursor, and the party while picking.

        Args:
            surface: The screen surface to draw onto.
        """
        render_scene_background(self, surface)
        # The whole screen is one ocean-blue window (D-461).
        draw_window(surface, surface.get_rect())
        text_renderer.draw_text(
            surface,
            "Inventory",
            _HEADING_POSITION,
            color=ColorSettings.WHITE,
            size=FontSettings.SIZE_HEADING,
        )
        rows = self._rows()
        if not rows:
            text_renderer.draw_text(
                surface,
                "Empty.",
                (_LIST_LEFT_X, _LIST_TOP_Y),
                color=ColorSettings.GRAY,
                size=FontSettings.SIZE_BODY,
            )
        for index, (item_id, count) in enumerate(rows):
            y = _LIST_TOP_Y + index * _LIST_ROW_HEIGHT
            color = ColorSettings.WHITE if count > 0 else ColorSettings.GRAY
            text_renderer.draw_text(
                surface, item_id, (_LIST_LEFT_X, y), color=color, size=FontSettings.SIZE_BODY,
            )
            text_renderer.draw_text(
                surface, f"x{count}", (_COUNT_X, y), color=color, size=FontSettings.SIZE_BODY,
            )
            if index == self._item_cursor % len(rows):
                _draw_pointer(surface, (_LIST_LEFT_X - 4, y + 3), dim=self._using is not None)
        if self._using is not None:
            self._render_party(surface)

    def _render_party(self, surface: pygame.Surface) -> None:
        """The party along the bottom: name and HP, the knocked out in red."""
        draw_window(surface, _PARTY_RECT)
        for index, member in enumerate(self.gm.party.members):
            y = _PARTY_TOP_Y + index * _PARTY_ROW_HEIGHT
            _, shown, top = stance_numbers(member)
            down = member.current_hp <= 0
            color = ColorSettings.RED if down else ColorSettings.WHITE
            text_renderer.draw_text(
                surface, short_name(member.id), (_LIST_LEFT_X, y),
                color=color, size=FontSettings.SIZE_BODY,
            )
            text_renderer.draw_text(
                surface, f"HP {shown}/{top}", (_HP_X, y),
                color=color, size=FontSettings.SIZE_BODY,
            )
            if index == self._member_cursor:
                _draw_pointer(surface, (_LIST_LEFT_X - 4, y + 3))


def _draw_pointer(surface: pygame.Surface, tip: tuple[int, int], dim: bool = False) -> None:
    """The yellow cursor arrow, pointing right at ``tip``; grey while another list has the cursor."""
    pygame.draw.polygon(surface, ColorSettings.GRAY if dim else ColorSettings.YELLOW, [
        tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 5, tip[1] + 5),
    ])
