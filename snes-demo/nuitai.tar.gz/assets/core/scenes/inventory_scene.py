"""The Items screen: the item list, and the healing plants used from it.

Final Fantasy VI's layout (Frankie, 10/23): a small box saying Items, a
help line for the item under the cursor, the list below.

Pushed by [core/scenes/menu_scene.py](menu_scene.py) when the player
picks Items. Lists each item in ``Party.inventory`` with its count. The
cursor picks an item; confirm on something that heals opens the party in a window
along the bottom, and confirm on a member gives it to them, as a
Final Fantasy field menu does. Cancel steps back, then pops back to the
system menu.

Confirm on a lontar (``ItemSettings.SHELLS``, a palm-leaf book with the
move written in the Bandari script; the game never says the word) teaches
its member the move, and the lontar is gone (ELEMENTS, Frankie 10/22;
lontar, 10/24). The party opens first, as for a seed, and only someone
with every element of the move can be picked; the rest are grey
(Frankie, 10/26). The first time Kailo learns one, he and Hina talk in the dialogue box
(``ItemSettings.READ_TALK``, once only, Frankie 10/26), then the jingle and the learned line in a
window along the bottom. Until Sarjana joins Hina is the only one in the
party who can read; in the demo she is always in the party, so nothing
checks for her yet.

Confirm on a seed (``ItemSettings.SEEDS``) opens the party the same way;
the member picked grows that stat, and the seed is used up (Frankie, 10/22).

Noni out of battle heals what it heals in one (``ItemSettings.HEALS``,
'Awa and saimin from Kailo's pot too)
in the HP the member shows, the stance they start a fight in (D-365). It
does not wake the knocked out, the same as in a fight, and is not spent
on someone already at full HP. The plants that cure (``ItemSettings.CURES``)
are for a fight, where the ailments are, so here they only show their help line.

Sort, beside the Items box, puts the bag in order of type in one press, as
Final Fantasy VI's Arrange does (Frankie, 10/26): the cursor reaches it by
going up past the first item, or down past the last. The list shows the
bag in its own order, new things at the end, so the sorted order is the
one the save keeps.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.factories import stance_numbers
from core.scene import Scene
from core.shared import SHARED, by_id, short_name
from systems.loadout import learn
from core.scenes.shop_scene import draw_item_name
from settings import ColorSettings, FontSettings, ItemSettings, UISettings
from ui import input_map, text_renderer
from ui.scroll_mark import draw_list_marks
from ui.text_box import TextBox
from ui.window import draw_header, draw_window, help_wrap
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


_LIST_TOP_Y = UISettings.HEADER_LIST_TOP
_LIST_LEFT_X = 16   # The item's icon (ui/item_icon.py); its name a letter on.
_LIST_ROW_HEIGHT = 16
_COUNT_X = 192   # past the longest name, Seed of Intelligence
# Rows that fit in the window; the list scrolls past them.
_VISIBLE_ROWS = 9
_MARK_X = 224    # The scroll arrows, past the counts.

# The party window, along the bottom while a heal waits for someone to take it.
# Rows 16 pixels apart on the 8 pixel grid (D-445), so the cartridge's
# text layer draws them in the same places.
_PARTY_RECT = pygame.Rect(0, 144, 256, 80)
_PARTY_TOP_Y = _PARTY_RECT.top + 8
_PARTY_ROW_HEIGHT = 16
_HP_X = 112

# Items that can be used here: what heals (ItemSettings.HEALS).
_USABLE = set(ItemSettings.HEALS)

# Sort, on the top row right of the Items box.
_SORT_X = UISettings.HEADER_LABEL_RECT[2] + UISettings.HEADER_TEXT_X
_SORT_Y = 8
_SORT_HELP = "Puts the items in order by type."


def _type_order() -> list[str]:
    """Every item id the data knows, in Sort's order: heals, cures, dishes,
    ingredients, seeds, other things used up, gear, key items (Frankie, 10/26).
    Within a type, the data's own order."""
    dishes = [dish["id"] for dish in SHARED["cooking"]["dishes"]]
    kinds = [
        [i for i in ItemSettings.HEALS if i not in dishes and i not in ItemSettings.INGREDIENTS],
        list(ItemSettings.CURES),
        dishes,
        list(ItemSettings.INGREDIENTS),
        list(ItemSettings.SEEDS),
        [ItemSettings.SEER_SHELL, *ItemSettings.SHELLS],
        [entry["id"] for entry in SHARED["weapons"] + SHARED["relics"]],
    ]
    order = [i for kind in kinds for i in kind]
    return list(dict.fromkeys(order))


def sort_bag(bag: dict[str, int]) -> None:
    """Put ``bag`` in Sort's order, in place. Anything of no known type goes
    just before the key items, which come last."""
    order = {item_id: n for n, item_id in enumerate(_type_order())}
    keys = set(ItemSettings.KEY_DROPS.values())

    def rank(item_id: str) -> tuple[int, int]:
        if item_id in keys:
            return (2, 0)
        return (0, order[item_id]) if item_id in order else (1, 0)

    # sorted() keeps ties in the bag's order, so unknowns and key items do too.
    items = sorted(bag.items(), key=lambda pair: rank(pair[0]))
    bag.clear()
    bag.update(items)


def can_learn(member: "PartyMember", item_id: str) -> bool:
    """Whether ``member`` has every element of the lontar's move (Frankie, 10/26).

    A single element goes to anyone with it, a dual one only to the
    character with both, so Counter is Kailo's and Drain is Maika's.
    """
    move = by_id("moves")[ItemSettings.SHELLS[item_id][1]]
    elements = move.get("elements") or move["element"]
    if isinstance(elements, str):
        elements = [elements]
    return set(elements) <= set(member.elements)


def item_help(item_id: str) -> str:
    """The help line for an item: what it does, from its numbers, or ``ItemSettings.HELP``."""
    from core.equipment import description, slot_of
    from core.shared import by_id
    from core.stats import STAT_NAMES

    if item_id in ItemSettings.HEALS:
        heals = f"Heals one member {ItemSettings.HEALS[item_id]} HP."
        return f"{heals} {ItemSettings.HELP[item_id]}" if item_id in ItemSettings.HELP else heals
    if item_id in ItemSettings.SHELLS:
        member_id, move_id = ItemSettings.SHELLS[item_id]
        return f"{short_name(member_id)} learns {by_id('moves')[move_id]['name']}."
    if item_id in ItemSettings.SEEDS:
        stat = STAT_NAMES[ItemSettings.SEEDS[item_id]]
        return f"Raises one member's {stat} by {ItemSettings.SEED_POINTS}."
    # A weapon or a relic says its trade, then what it is (Frankie, 10/24).
    if slot_of(item_id):
        return description(item_id)
    return ItemSettings.HELP.get(item_id, "")


class InventoryScene(Scene):
    """The item list; a heal can be given to a party member."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Bind this scene to the host game manager.

        Args:
            gm: The host game manager. ``gm.party.inventory`` is the
                data source.
        """
        super().__init__(gm)
        self._item_cursor = 0
        # The item waiting for a member, or None while picking an item.
        self._using: str | None = None
        self._member_cursor = 0
        # The line a lontar or a seed leaves along the bottom, until the next key.
        self._message: str | None = None
        # The learner and Hina talking before a lontar's line.
        self.text_box = TextBox()
        self._jingle_due = False
        # The first row shown, when the bag holds more than fit.
        self._top = 0
        # Whether the cursor is on Sort rather than the list.
        self._on_sort = False

    def _rows(self) -> list[tuple[str, int]]:
        """The items in the bag's own order, which Sort sets and the save keeps."""
        return list(self.gm.party.inventory.items())

    def _learn(self, item_id: str, member: "PartyMember") -> None:
        """Use a lontar on ``member``: they learn the move, and it is gone."""
        member_id = member.id
        move_id = ItemSettings.SHELLS[item_id][1]
        self.gm.party.flags[f"{member_id}_learned_{move_id}"] = True
        self.gm.party.inventory.pop(item_id, None)
        member.loadout = learn(member.loadout, by_id("moves")[move_id])
        self._item_cursor = 0
        flags = self.gm.party.flags
        if member_id == ItemSettings.READ_TALK_MEMBER and not flags.get(ItemSettings.READ_FLAG):
            flags[ItemSettings.READ_FLAG] = True
            for speaker_id, line in ItemSettings.READ_TALK:
                self.text_box.push(line, speaker=short_name(speaker_id))
        # The jingle waits for the talk to end (update).
        self._jingle_due = True
        self._message = f"{short_name(member_id)} learned {by_id('moves')[move_id]['name'].upper()}!"

    def _plant_seed(self, member: "PartyMember") -> None:
        """Use the seed being held on ``member``: the stat grows, and one seed is gone."""
        from core.stats import STAT_NAMES

        stat = ItemSettings.SEEDS[self._using]
        member.growth[stat] = member.growth.get(stat, 0) + ItemSettings.SEED_POINTS
        member.refresh_stats()
        bag = self.gm.party.inventory
        bag[self._using] -= 1
        if bag[self._using] <= 0:
            del bag[self._using]
        self._using = None
        self._item_cursor = min(self._item_cursor, max(0, len(self._rows()) - 1))
        self.gm.audio.play("learned")
        self._message = f"{short_name(member.id)}'s {STAT_NAMES[stat]} up!"

    def _can_drink(self, member: "PartyMember") -> bool:
        """A heal helps the living who are hurt."""
        return 0 < member.current_hp < member.max_hp

    def _give_heal(self, member: "PartyMember") -> None:
        """Heal ``member`` by the item's worth of the HP they show, and spend one."""
        _, shown, top = stance_numbers(member)
        healed = min(top, shown + ItemSettings.HEALS[self._using])
        member.current_hp = min(member.max_hp, round(healed * member.max_hp / max(1, top)))
        # Noni's count stays at 0 rather than going: a missing entry
        # means an old save, and the battle would hand out a new stack.
        bag = self.gm.party.inventory
        bag[self._using] -= 1
        if bag[self._using] <= 0 and self._using != "noni":
            del bag[self._using]

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        """Type out the talk; once it ends, the jingle under the learned line."""
        self.text_box.update(dt)
        if self._jingle_due and self.text_box.is_done():
            self._jingle_due = False
            self.gm.audio.play("learned")

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move the cursor, use an item, or step back."""
        if not self.text_box.is_done():
            if input_map.is_confirm(event):
                self.text_box.advance()
            return
        if self._message is not None:
            if input_map.is_confirm(event) or input_map.is_cancel(event):
                self._message = None
            return
        if self._using is not None:
            self._handle_member_pick(event)
            return
        rows = self._rows()
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif self._on_sort and rows and (input_map.is_up(event) or input_map.is_down(event)):
            # Back into the list: down to its top, up to its bottom.
            self._on_sort = False
            self._item_cursor = 0 if input_map.is_down(event) else len(rows) - 1
            self.gm.audio.play("menu_move")
        elif self._on_sort and input_map.is_confirm(event):
            sort_bag(self.gm.party.inventory)
            self._item_cursor = self._top = 0
            self.gm.audio.play("menu_select")
        elif rows and input_map.is_up(event):
            if self._item_cursor % len(rows) == 0:
                self._on_sort = True
            else:
                self._item_cursor -= 1
            self.gm.audio.play("menu_move")
        elif rows and input_map.is_down(event):
            if self._item_cursor % len(rows) == len(rows) - 1:
                self._on_sort = True
            else:
                self._item_cursor += 1
            self.gm.audio.play("menu_move")
        elif rows and input_map.is_confirm(event):
            item_id, count = rows[self._item_cursor % len(rows)]
            if item_id in ItemSettings.SHELLS and count > 0:
                # Pick who learns it, the cursor on the first who can (Frankie, 10/26).
                self._using = item_id
                members = self.gm.party.members
                self._member_cursor = next(
                    (n for n, m in enumerate(members) if can_learn(m, item_id)), 0)
                self.gm.audio.play("menu_select")
            elif (item_id in _USABLE or item_id in ItemSettings.SEEDS) and count > 0:
                self._using = item_id
                self.gm.audio.play("menu_select")

    def _handle_member_pick(self, event: pygame.event.Event) -> None:
        """Choose who gets the item; cancel goes back to the list."""
        members = self.gm.party.members
        if input_map.is_cancel(event):
            self._using = None
            self.gm.audio.play("menu_move")
        elif input_map.is_up(event):
            self._member_cursor = (self._member_cursor - 1) % len(members)
            self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            self._member_cursor = (self._member_cursor + 1) % len(members)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            member = members[self._member_cursor]
            if self._using in ItemSettings.SHELLS:
                if not can_learn(member, self._using):
                    self.gm.audio.play("menu_move")
                    return
                item_id, self._using = self._using, None
                self._learn(item_id, member)
                return
            if self._using in ItemSettings.SEEDS:
                self._plant_seed(member)
                return
            if not self._can_drink(member):
                self.gm.audio.play("menu_move")
                return
            self._give_heal(member)
            self.gm.audio.play("hit_sparkle_1")
            if self.gm.party.inventory.get(self._using, 0) <= 0:
                self._using = None
                self._item_cursor = min(self._item_cursor, max(0, len(self._rows()) - 1))

    def render(self, surface: pygame.Surface) -> None:
        """Paint the heading, each item row with the cursor, and the party while picking.

        Args:
            surface: The screen surface to draw onto.
        """
        render_scene_background(self, surface)
        rows = self._rows()
        here = rows[self._item_cursor % len(rows)][0] if rows else None
        if self._on_sort:
            lines = help_wrap(_SORT_HELP)
        else:
            lines = help_wrap(item_help(here)) if here else []
        draw_header(surface, "Items", lines, corner="Sort")
        if self._on_sort:
            _draw_pointer(surface, (_SORT_X - 4, _SORT_Y + 3))
        if not rows:
            text_renderer.draw_text(
                surface,
                "Empty.",
                (_LIST_LEFT_X, _LIST_TOP_Y),
                color=ColorSettings.GRAY,
                size=FontSettings.SIZE_BODY,
            )
        cursor = self._item_cursor % len(rows) if rows else 0
        self._top = min(max(self._top, cursor - _VISIBLE_ROWS + 1), cursor)
        for index, (item_id, count) in enumerate(rows):
            if not self._top <= index < self._top + _VISIBLE_ROWS:
                continue
            y = _LIST_TOP_Y + (index - self._top) * _LIST_ROW_HEIGHT
            color = ColorSettings.WHITE if count > 0 else ColorSettings.GRAY
            draw_item_name(surface, item_id, _LIST_LEFT_X, y, color)
            text_renderer.draw_text(
                surface, f"x{count}", (_COUNT_X, y), color=color, size=FontSettings.SIZE_BODY,
            )
            if index == self._item_cursor % len(rows) and not self._on_sort:
                _draw_pointer(surface, (_LIST_LEFT_X - 4, y + 3), dim=self._using is not None)
        draw_list_marks(surface, _MARK_X, _LIST_TOP_Y, _LIST_ROW_HEIGHT, self._top, _VISIBLE_ROWS, len(rows))
        if self._using is not None:
            self._render_party(surface)
        if not self.text_box.is_done():
            self.text_box.render(surface)
        elif self._message is not None:
            draw_window(surface, _PARTY_RECT)
            text_renderer.draw_text(surface, self._message, (_LIST_LEFT_X, _PARTY_TOP_Y),
                                    color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY)

    def _render_party(self, surface: pygame.Surface) -> None:
        """The party along the bottom: name and HP, the knocked out in red.

        For a lontar, whoever cannot learn it is grey (Frankie, 10/26).
        """
        draw_window(surface, _PARTY_RECT)
        lontar = self._using in ItemSettings.SHELLS
        for index, member in enumerate(self.gm.party.members):
            y = _PARTY_TOP_Y + index * _PARTY_ROW_HEIGHT
            _, shown, top = stance_numbers(member)
            down = member.current_hp <= 0
            if lontar and not can_learn(member, self._using):
                color = ColorSettings.GRAY
            else:
                color = ColorSettings.RED if down else ColorSettings.WHITE
            text_renderer.draw_text(
                surface, short_name(member.id), (_LIST_LEFT_X, y),
                color=color, size=FontSettings.SIZE_BODY,
            )
            text_renderer.draw_text(
                surface, f"HP {shown}/{top}", (_HP_X, y),
                color=color, size=FontSettings.SIZE_BODY,
            )
            if index == self._member_cursor:
                _draw_pointer(surface, (_LIST_LEFT_X - 4, y + 3))


def _draw_pointer(surface: pygame.Surface, tip: tuple[int, int], dim: bool = False) -> None:
    """The yellow cursor arrow, pointing right at ``tip``; grey while another list has the cursor."""
    pygame.draw.polygon(surface, ColorSettings.GRAY if dim else ColorSettings.YELLOW, [
        tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 5, tip[1] + 5),
    ])
