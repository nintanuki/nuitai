"""The Items screen: the bag by category, the item list, and the healing plants used from it.

Final Fantasy VI's layout (Frankie, 10/23): a small box saying Items, a
help line for the item under the cursor, the list below.

Pushed by [core/scenes/menu_scene.py](menu_scene.py) when the player
picks Items. The bag is split by category (Frankie, 10/28; it was one list
with a Sort command, 10/26): Items first lists the categories that hold
something (``CATEGORIES``, an empty one hidden), and confirm on one lists
only its items from ``Party.inventory``, each with its count, in the bag's
own order; left and right flip to the category before or after it. Cancel steps back to the categories. The cursor picks an item; confirm on something that heals opens the party in a window
along the bottom, and confirm on a member gives it to them, as a
Final Fantasy field menu does. Cancel steps back, then pops back to the
system menu.

Confirm on a lontar (``ItemSettings.SHELLS``, a palm-leaf book with the
move written in the Bandari script; the game never says the word) teaches
its member the move, and the lontar is gone (ELEMENTS, Frankie 10/22;
lontar, 10/24). The party opens first, as for a seed, and only someone
with every element of the move can be picked; the rest are grey
(Frankie, 10/26). The first time Kailo learns one, he and Hina talk in the dialogue box
(``ItemSettings.READ_TALK``, once only, Frankie 10/26), then the jingle and the learned line in a
window along the bottom. Until Sarjana joins Hina is the only one in the
party who can read; while she is away, Kailo says he needs her and keeps
the lontar (Frankie, 10/31).

Confirm on a seed (``ItemSettings.SEEDS``) opens the party the same way;
the member picked grows that stat, and the seed is used up (Frankie, 10/22).

An item that revives (``ItemSettings.REVIVES``, Frankie 10/30) raises a fallen member here
with its share of max HP; the living are not asked.

Noni out of battle heals what it heals in one (``ItemSettings.HEALS``,
'Awa and saimin from Kailo's pot too)
in the HP the member shows, the stance they start a fight in (D-365). It
does not wake the knocked out, the same as in a fight, and is not spent
on someone already at full HP. The plants that cure (``ItemSettings.CURES``)
are for a fight, where the ailments are, so here they only show their help line.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.factories import first_loadout, stance_numbers
from core.scene import Scene
from core.shared import by_id, short_name
from systems.loadout import learn, open_slots
from core.scenes.shop_scene import draw_item_name
from settings import ColorSettings, CraftSettings, FontSettings, ItemSettings, UISettings
from ui import input_map, text_renderer
from ui.scroll_mark import draw_list_marks
from ui.item_icon import item_icon, item_kind, kind_surface
from ui.text_box import TextBox
from systems import diet
from ui.window import draw_header, draw_window, help_wrap
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


_LIST_TOP_Y = UISettings.HEADER_LIST_TOP
_LIST_LEFT_X = 24   # Room for the fishhook cursor (11/2). The item's icon (ui/item_icon.py); its name a letter on.
_LIST_ROW_HEIGHT = 16
_COUNT_X = 192   # past the longest name, Seed of Intelligence
# Rows that fit in the window; the list scrolls past them.
_VISIBLE_ROWS = 9
_MARK_X = 224    # The scroll arrows, past the counts.

# The party window, along the bottom while a heal waits for someone to take it.
# Rows 16 pixels apart on the 8 pixel grid (D-445), so the cartridge's
# text layer draws them in the same places.
_PARTY_RECT = pygame.Rect(0, 144, 256, 80)
_PARTY_TOP_Y = _PARTY_RECT.top + 8
_PARTY_ROW_HEIGHT = 16
_HP_X = 112

# Items that can be used here: what heals (ItemSettings.HEALS).
_USABLE = set(ItemSettings.HEALS) | set(ItemSettings.REVIVES)

# The bag's categories, in the order Items lists them, each with its help
# line (Frankie, 10/28: food, ingredients, medicine, elements and key items,
# and the kinds the bag already had; Claude's help lines). Each item's is
# from its icon's kind (ui/item_icon.py); what has no kind is Special.
CATEGORIES: dict = {
    "Meals": "Dishes Kailo cooked.",
    "Ingredients": "What goes in the pot, or eaten as it is.",
    "Medicine": "Plants that heal and cure.",
    "Elements": "Each teaches one member a move.",
    "Seeds": "Each raises one member's stat.",
    "Materials": "For repairing and making things.",
    "Weapons": "Equipped from Equip.",
    "Relics": "Equipped from Equip.",
    "Special": "Used in a fight.",
    "Key Items": "Tools and things kept. Never sold.",
}
# Weapons, Relics and Key Items show a picture of their own, not their first
# item's, which could be anything (Frankie, 10/28).
_CATEGORY_ICONS = {"Weapons": "swords", "Relics": "relics", "Key Items": "key"}
_KIND_CATEGORY = {
    "food": "Meals", "ingredient": "Ingredients", "medicine": "Medicine", "element": "Elements",
    "seed": "Seeds", "material": "Materials", "key": "Key Items",
}


def category_of(item_id: str) -> str:
    """Which of the bag's ``CATEGORIES`` ``item_id`` is listed under."""
    if by_id("weapons").get(item_id):
        return "Weapons"
    if by_id("relics").get(item_id):
        return "Relics"
    return _KIND_CATEGORY.get(item_kind(item_id), "Special")


def can_learn(member: "PartyMember", item_id: str) -> bool:
    """Whether ``member`` has every element of the lontar's move (Frankie, 10/26).

    A single element goes to anyone with it, a dual one only to the
    character with both, so Counter is Kailo's and Drain is Maika's.
    """
    move = by_id("moves")[ItemSettings.SHELLS[item_id][1]]
    elements = move.get("elements") or move["element"]
    if isinstance(elements, str):
        elements = [elements]
    return set(elements) <= set(member.elements)


def item_help(item_id: str) -> str:
    """The help line for an item: its English word if its name is not English, then
    what it does, from its numbers, or ``ItemSettings.HELP`` (Frankie, 10/30)."""
    from core.equipment import with_english

    return with_english(item_id, _item_help(item_id))


def _item_help(item_id: str) -> str:
    """``item_help`` without the English word."""
    from core.equipment import description, slot_of
    from core.shared import by_id
    from core.stats import STAT_NAMES

    if item_id == ItemSettings.DUBIOUS:
        return f"Makes whoever eats it sick. {ItemSettings.HELP[item_id]}"
    if item_id in ItemSettings.HEALS:
        heals = f"Heals one member {ItemSettings.HEALS[item_id]} HP."
        return f"{heals} {ItemSettings.HELP[item_id]}" if item_id in ItemSettings.HELP else heals
    if item_id in ItemSettings.REVIVES:
        return f"Raises one fallen member. {ItemSettings.HELP[item_id]}"
    if item_id in ItemSettings.SHELLS:
        # What the move does, as every help line says what its item does; who learned it
        # is the line after using it, "Maika learned Drain!" (Frankie, 10/31).
        _, move_id = ItemSettings.SHELLS[item_id]
        return by_id("moves")[move_id]["description"]
    if item_id in ItemSettings.SEEDS:
        stat = STAT_NAMES[ItemSettings.SEEDS[item_id]]
        return f"Raises one member's {stat} by {ItemSettings.SEED_POINTS}."
    # A weapon or a relic says its trade, then what it is (Frankie, 10/24).
    if slot_of(item_id):
        return description(item_id)
    return ItemSettings.HELP.get(item_id, "")


class InventoryScene(Scene):
    """The item list; a heal can be given to a party member."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Bind this scene to the host game manager.

        Args:
            gm: The host game manager. ``gm.party.inventory`` is the
                data source.
        """
        super().__init__(gm)
        self._item_cursor = 0
        # The item waiting for a member, or None while picking an item.
        self._using: str | None = None
        self._member_cursor = 0
        # The line a lontar or a seed leaves along the bottom, until the next key.
        self._message: str | None = None
        # The learner and Hina talking before a lontar's line.
        self.text_box = TextBox()
        self._jingle_due = False
        # The first row shown, when the bag holds more than fit.
        self._top = 0
        # The category open, or None while one is picked; the cursor and
        # first row shown on the categories.
        self.category: str | None = None
        self._category_cursor = 0
        self._category_top = 0

    def categories(self) -> list[str]:
        """The categories with something in them, in ``CATEGORIES``' order; an empty one is hidden."""
        held = {category_of(item_id) for item_id, count in self.gm.party.inventory.items() if count > 0}
        return [name for name in CATEGORIES if name in held]

    def _rows(self) -> list[tuple[str, int]]:
        """The open category's items, in the bag's own order."""
        return [(item_id, count) for item_id, count in self.gm.party.inventory.items()
                if category_of(item_id) == self.category]

    def _settle(self) -> None:
        """A category used up goes back to the categories, the cursor on one still there.

        Not while a line is up: the last seed's "up!" stays on screen until it is closed.
        """
        if (self.category is not None and self._using is None and self._message is None
                and self.text_box.is_done() and self.category not in self.categories()):
            self.category = None
        names = self.categories()
        self._category_cursor = min(self._category_cursor, max(0, len(names) - 1))

    def _learn(self, item_id: str, member: "PartyMember") -> None:
        """Use a lontar on ``member``: they learn the move, and it is gone."""
        member_id = member.id
        move_id = ItemSettings.SHELLS[item_id][1]
        self.gm.party.flags[f"{member_id}_learned_{move_id}"] = True
        self.gm.party.inventory.pop(item_id, None)
        member.loadout = learn(member.loadout, by_id("moves")[move_id],
                               first_loadout(member_id, self.gm.party.flags),
                               open_slots(self.gm.party.flags))
        self._item_cursor = 0
        flags = self.gm.party.flags
        if member_id == ItemSettings.READ_TALK_MEMBER and not flags.get(ItemSettings.READ_FLAG):
            flags[ItemSettings.READ_FLAG] = True
            for speaker_id, line in ItemSettings.READ_TALK:
                self.text_box.push(line, speaker=short_name(speaker_id))
        # The jingle waits for the talk to end (update).
        self._jingle_due = True
        self._message = f"{short_name(member_id)} learned {by_id('moves')[move_id]['name']}!"

    def _plant_seed(self, member: "PartyMember") -> None:
        """Use the seed being held on ``member``: the stat grows, and one seed is gone."""
        from core.stats import STAT_NAMES

        stat = ItemSettings.SEEDS[self._using]
        member.growth[stat] = member.growth.get(stat, 0) + ItemSettings.SEED_POINTS
        member.refresh_stats()
        bag = self.gm.party.inventory
        bag[self._using] -= 1
        if bag[self._using] <= 0:
            del bag[self._using]
        self._using = None
        self._item_cursor = min(self._item_cursor, max(0, len(self._rows()) - 1))
        self.gm.audio.play("learned")
        self._message = f"{short_name(member.id)}'s {STAT_NAMES[stat]} up!"

    def _can_drink(self, member: "PartyMember") -> bool:
        """A heal helps the living who are hurt."""
        return 0 < member.current_hp < member.max_hp

    def _first_who_needs(self, item_id: str) -> int:
        """Where the party pointer starts: the first who the item would help, else the top."""
        members = self.gm.party.members
        if item_id in ItemSettings.REVIVES:
            helps = lambda m: m.current_hp <= 0
        elif item_id in ItemSettings.HEALS:
            helps = self._can_drink
        else:
            return 0
        return next((n for n, m in enumerate(members) if helps(m)), 0)

    def _raise(self, member: "PartyMember") -> None:
        """Raise the fallen ``member`` with the item held (Frankie, 10/30): its share of max HP, and one is spent."""
        member.current_hp = max(1, round(member.max_hp * ItemSettings.REVIVES[self._using]))
        bag = self.gm.party.inventory
        bag[self._using] -= 1
        if bag[self._using] <= 0:
            del bag[self._using]

    def _give_heal(self, member: "PartyMember") -> None:
        """Heal ``member`` by the item's worth of the HP they show, and spend one."""
        _, shown, top = stance_numbers(member)
        healed = min(top, shown + ItemSettings.HEALS[self._using])
        member.current_hp = min(member.max_hp, round(healed * member.max_hp / max(1, top)))
        # Noni's count stays at 0 rather than going: a missing entry
        # means an old save, and the battle would hand out a new stack.
        bag = self.gm.party.inventory
        bag[self._using] -= 1
        if bag[self._using] <= 0 and self._using != "noni":
            del bag[self._using]

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        """Type out the talk; once it ends, the jingle under the learned line."""
        self.text_box.update(dt)
        if self._jingle_due and self.text_box.is_done():
            self._jingle_due = False
            self.gm.audio.play("learned")

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move the cursor, use an item, or step back."""
        if not self.text_box.is_done():
            if input_map.is_confirm(event):
                self.text_box.advance()
            return
        if self._message is not None:
            if input_map.is_confirm(event) or input_map.is_cancel(event):
                self._message = None
            return
        if self._using is not None:
            self._handle_member_pick(event)
            return
        self._settle()
        if self.category is None:
            self._handle_category_pick(event)
            return
        rows = self._rows()
        if input_map.is_cancel(event):
            self.category = None
            self.gm.audio.play("menu_move")
        elif input_map.is_left(event) or input_map.is_right(event):
            # Left and right flip to the next category with something in it, at once
            # (Frankie, 10/31: the Let's Play took the corner's name for a tab and pressed right).
            names = self.categories()
            step = -1 if input_map.is_left(event) else 1
            self._category_cursor = (names.index(self.category) + step) % len(names)
            self.category = names[self._category_cursor]
            self._item_cursor = self._top = 0
            self.gm.audio.play("menu_move")
        elif rows and input_map.is_up(event):
            self._item_cursor = (self._item_cursor - 1) % len(rows)
            self.gm.audio.play("menu_move")
        elif rows and input_map.is_down(event):
            self._item_cursor = (self._item_cursor + 1) % len(rows)
            self.gm.audio.play("menu_move")
        elif rows and input_map.is_confirm(event):
            item_id, count = rows[self._item_cursor % len(rows)]
            if item_id in ItemSettings.SHELLS and count > 0 and not any(
                    m.id == ItemSettings.READER for m in self.gm.party.members):
                # Only Hina can read one; while she is away Kailo keeps it (Frankie, 10/31).
                speaker_id, line = ItemSettings.NO_READER
                self.text_box.push(line, speaker=short_name(speaker_id))
                self.gm.audio.play("cant")
            elif item_id in ItemSettings.SHELLS and count > 0:
                # Pick who learns it, the cursor on the first who can (Frankie, 10/26).
                self._using = item_id
                members = self.gm.party.members
                self._member_cursor = next(
                    (n for n, m in enumerate(members) if can_learn(m, item_id)), 0)
                self.gm.audio.play("menu_select")
            elif (item_id in _USABLE or item_id in ItemSettings.SEEDS) and count > 0:
                self._using = item_id
                self._member_cursor = self._first_who_needs(item_id)
                self.gm.audio.play("menu_select")

    def _handle_category_pick(self, event: pygame.event.Event) -> None:
        """Pick a category to list; cancel closes Items."""
        names = self.categories()
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif names and input_map.is_up(event):
            self._category_cursor = (self._category_cursor - 1) % len(names)
            self.gm.audio.play("menu_move")
        elif names and input_map.is_down(event):
            self._category_cursor = (self._category_cursor + 1) % len(names)
            self.gm.audio.play("menu_move")
        elif names and input_map.is_confirm(event):
            self.category = names[self._category_cursor]
            self._item_cursor = self._top = 0
            self.gm.audio.play("menu_select")

    def _handle_member_pick(self, event: pygame.event.Event) -> None:
        """Choose who gets the item; cancel goes back to the list."""
        members = self.gm.party.members
        if input_map.is_cancel(event):
            self._using = None
            self.gm.audio.play("menu_move")
        elif input_map.is_up(event):
            self._member_cursor = (self._member_cursor - 1) % len(members)
            self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            self._member_cursor = (self._member_cursor + 1) % len(members)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            member = members[self._member_cursor]
            if self._using in ItemSettings.SHELLS:
                if not can_learn(member, self._using):
                    self.gm.audio.play("menu_move")
                    return
                item_id, self._using = self._using, None
                self._learn(item_id, member)
                return
            if self._using in ItemSettings.SEEDS:
                self._plant_seed(member)
                return
            if self._using in ItemSettings.REVIVES:
                if member.current_hp > 0:
                    self.gm.audio.play("menu_move")
                    return
                self._raise(member)
                self.gm.audio.play("hit_sparkle_1")
                if self.gm.party.inventory.get(self._using, 0) <= 0:
                    self._using = None
                    self._item_cursor = min(self._item_cursor, max(0, len(self._rows()) - 1))
                return
            # Who will not eat what (Frankie, 11/2): a refusal spends nothing. Nobody scolds
            # Sarjana out of a fight, so here he eats pork with his guilty line.
            outcome, said = diet.respond(member.id, self._using, [])
            if outcome == "refuse":
                self.gm.audio.play("cant")
                for speaker, line in said:
                    self.text_box.push(line, speaker=short_name(speaker))
                return
            if outcome == "sick":
                # It makes them sick (Frankie, 11/2): out of a fight a share of max HP, never the last.
                if member.current_hp <= 0:
                    self.gm.audio.play("menu_move")
                    return
                member.current_hp = max(1, member.current_hp - max(1, round(member.max_hp * ItemSettings.SICK_SHARE)))
                bag = self.gm.party.inventory
                bag[self._using] -= 1
                if bag[self._using] <= 0:
                    del bag[self._using]
                self.gm.audio.play("cant")
                for speaker, line in said:
                    self.text_box.push(line, speaker=short_name(speaker))
                self.text_box.push(CraftSettings.SICK_LINE.format(name=short_name(member.id)))
                if self.gm.party.inventory.get(self._using, 0) <= 0:
                    self._using = None
                    self._item_cursor = min(self._item_cursor, max(0, len(self._rows()) - 1))
                return
            if not self._can_drink(member):
                self.gm.audio.play("menu_move")
                return
            self._give_heal(member)
            for speaker, line in said:
                self.text_box.push(line, speaker=short_name(speaker))
            self.gm.audio.play("hit_sparkle_1")
            if self.gm.party.inventory.get(self._using, 0) <= 0:
                self._using = None
                self._item_cursor = min(self._item_cursor, max(0, len(self._rows()) - 1))

    def render(self, surface: pygame.Surface) -> None:
        """Paint the heading, each item row with the cursor, and the party while picking.

        Args:
            surface: The screen surface to draw onto.
        """
        render_scene_background(self, surface)
        self._settle()
        if self.category is None:
            self._render_categories(surface)
            return
        rows = self._rows()
        here = rows[self._item_cursor % len(rows)][0] if rows else None
        lines = help_wrap(item_help(here)) if here else []
        draw_header(surface, "Items", lines, corner=self.category)
        if not rows:
            text_renderer.draw_text(
                surface,
                "Empty.",
                (_LIST_LEFT_X, _LIST_TOP_Y),
                color=ColorSettings.GRAY,
                size=FontSettings.SIZE_BODY,
            )
        cursor = self._item_cursor % len(rows) if rows else 0
        self._top = min(max(self._top, cursor - _VISIBLE_ROWS + 1), cursor)
        for index, (item_id, count) in enumerate(rows):
            if not self._top <= index < self._top + _VISIBLE_ROWS:
                continue
            y = _LIST_TOP_Y + (index - self._top) * _LIST_ROW_HEIGHT
            color = ColorSettings.WHITE if count > 0 else ColorSettings.GRAY
            draw_item_name(surface, item_id, _LIST_LEFT_X, y, color)
            text_renderer.draw_text(
                surface, f"x{count}", (_COUNT_X, y), color=color, size=FontSettings.SIZE_BODY,
            )
            if index == self._item_cursor % len(rows) and self._using is None:
                # One hook: while an item is being used it is down on the party (Frankie, 11/2).
                _draw_pointer(surface, (_LIST_LEFT_X - 4, y + 3))
        draw_list_marks(surface, _MARK_X, _LIST_TOP_Y, _LIST_ROW_HEIGHT, self._top, _VISIBLE_ROWS, len(rows))
        if self._using is not None:
            self._render_party(surface)
        if not self.text_box.is_done():
            self.text_box.render(surface)
        elif self._message is not None:
            draw_window(surface, _PARTY_RECT)
            text_renderer.draw_text(surface, self._message, (_LIST_LEFT_X, _PARTY_TOP_Y),
                                    color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY)

    def _render_categories(self, surface: pygame.Surface) -> None:
        """The categories with something in them, each by the icon of its first item or its own."""
        names = self.categories()
        here = names[self._category_cursor] if names else None
        draw_header(surface, "Items", help_wrap(CATEGORIES[here]) if here else [])
        if not names:
            text_renderer.draw_text(surface, "Empty.", (_LIST_LEFT_X, _LIST_TOP_Y),
                                    color=ColorSettings.GRAY, size=FontSettings.SIZE_BODY)
            return
        cursor = self._category_cursor
        self._category_top = min(max(self._category_top, cursor - _VISIBLE_ROWS + 1), cursor)
        bag = self.gm.party.inventory
        for index, name in enumerate(names):
            if not self._category_top <= index < self._category_top + _VISIBLE_ROWS:
                continue
            y = _LIST_TOP_Y + (index - self._category_top) * _LIST_ROW_HEIGHT
            if name in _CATEGORY_ICONS:
                icon = kind_surface(_CATEGORY_ICONS[name])
            else:
                first = next(item_id for item_id, count in bag.items() if count > 0 and category_of(item_id) == name)
                icon = item_icon(first)
            if icon is not None:
                surface.blit(icon, (_LIST_LEFT_X, y))
            text_renderer.draw_text(surface, name, (_LIST_LEFT_X + 8, y),
                                    color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY)
            if index == cursor:
                _draw_pointer(surface, (_LIST_LEFT_X - 4, y + 3))
        draw_list_marks(surface, _MARK_X, _LIST_TOP_Y, _LIST_ROW_HEIGHT, self._category_top,
                        _VISIBLE_ROWS, len(names))

    def _render_party(self, surface: pygame.Surface) -> None:
        """The party along the bottom: name and HP, the knocked out in red.

        For a lontar, whoever cannot learn it is grey (Frankie, 10/26); for an item that revives, the standing.
        """
        draw_window(surface, _PARTY_RECT)
        lontar = self._using in ItemSettings.SHELLS
        raising = self._using in ItemSettings.REVIVES
        for index, member in enumerate(self.gm.party.members):
            y = _PARTY_TOP_Y + index * _PARTY_ROW_HEIGHT
            _, shown, top = stance_numbers(member)
            down = member.current_hp <= 0
            if (lontar and not can_learn(member, self._using)) or (raising and not down):
                color = ColorSettings.GRAY
            else:
                color = ColorSettings.RED if down else ColorSettings.WHITE
            text_renderer.draw_text(
                surface, short_name(member.id), (_LIST_LEFT_X, y),
                color=color, size=FontSettings.SIZE_BODY,
            )
            text_renderer.draw_text(
                surface, f"HP {shown}/{top}", (_HP_X, y),
                color=color, size=FontSettings.SIZE_BODY,
            )
            if index == self._member_cursor:
                _draw_pointer(surface, (_LIST_LEFT_X - 4, y + 3))


def _draw_pointer(surface: pygame.Surface, tip: tuple[int, int]) -> None:
    """The cursor, the fishhook, at ``tip``."""
    text_renderer.draw_pointer(surface, tip)
