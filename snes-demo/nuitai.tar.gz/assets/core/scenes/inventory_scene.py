"""The Items screen: the item list, and potions used from it.

Final Fantasy VI's layout (Frankie, 10/23): a small box saying Items, a
help line for the item under the cursor, the list below.

Pushed by [core/scenes/menu_scene.py](menu_scene.py) when the player
picks Items. Lists each item in ``Party.inventory`` with its count. The
cursor picks an item; confirm on a potion opens the party in a window
along the bottom, and confirm on a member gives them the potion, as a
Final Fantasy field menu does. Cancel steps back, then pops back to the
system menu.

Confirm on a memory shell (``ItemSettings.SHELLS``) teaches its member
the move, with a jingle and a line in a window along the bottom, and the
shell is gone (ELEMENTS, Frankie 10/22).

Confirm on a seed (``ItemSettings.SEEDS``) opens the party the same way;
the member picked grows that stat, and the seed is used up (Frankie, 10/22).

A potion out of battle heals what it heals in one (``ItemSettings.HEALS``,
saimin from Kailo's pot too)
in the HP the member shows, the stance they start a fight in (D-365). It
does not wake the knocked out, the same as in a fight, and is not spent
on someone already at full HP.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.factories import stance_numbers
from core.scene import Scene
from core.shared import short_name
from core.scenes.shop_scene import item_name
from settings import ColorSettings, FontSettings, ItemSettings, UISettings
from ui import input_map, text_renderer
from ui.window import draw_header, draw_window, help_wrap
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


_LIST_TOP_Y = UISettings.HEADER_LIST_TOP
_LIST_LEFT_X = 16
_LIST_ROW_HEIGHT = 16
_COUNT_X = 184   # past the longest name, Seed of Intelligence
# Rows that fit in the window; the list scrolls past them.
_VISIBLE_ROWS = 9

# The party window, along the bottom while a potion waits for a drinker.
# Rows 16 pixels apart on the 8 pixel grid (D-445), so the cartridge's
# text layer draws them in the same places.
_PARTY_RECT = pygame.Rect(0, 144, 256, 80)
_PARTY_TOP_Y = _PARTY_RECT.top + 8
_PARTY_ROW_HEIGHT = 16
_HP_X = 112

# Items that can be used here: what heals (ItemSettings.HEALS).
_USABLE = set(ItemSettings.HEALS)


def item_help(item_id: str) -> str:
    """The help line for an item: what it does, from its numbers, or ``ItemSettings.HELP``."""
    from core.shared import by_id
    from core.stats import STAT_NAMES

    if item_id in ItemSettings.HEALS:
        return f"Heals one member {ItemSettings.HEALS[item_id]} HP."
    if item_id in ItemSettings.SHELLS:
        member_id, move_id = ItemSettings.SHELLS[item_id]
        return f"{short_name(member_id)} learns {by_id('moves')[move_id]['name']}."
    if item_id in ItemSettings.SEEDS:
        stat = STAT_NAMES[ItemSettings.SEEDS[item_id]]
        return f"Raises one member's {stat} by {ItemSettings.SEED_POINTS}."
    return ItemSettings.HELP.get(item_id, "")


class InventoryScene(Scene):
    """The item list; a potion can be given to a party member."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Bind this scene to the host game manager.

        Args:
            gm: The host game manager. ``gm.party.inventory`` is the
                data source.
        """
        super().__init__(gm)
        self._item_cursor = 0
        # The item waiting for a member, or None while picking an item.
        self._using: str | None = None
        self._member_cursor = 0
        # The line a shell leaves along the bottom, until the next key.
        self._message: str | None = None
        # The first row shown, when the bag holds more than fit.
        self._top = 0

    def _rows(self) -> list[tuple[str, int]]:
        """The items in a stable order, sorted by id so visits do not reshuffle them."""
        return sorted(self.gm.party.inventory.items())

    def _learn(self, item_id: str) -> None:
        """Use a memory shell: its member learns the move, and the shell is gone."""
        from core.shared import by_id

        member_id, move_id = ItemSettings.SHELLS[item_id]
        self.gm.party.flags[f"{member_id}_learned_{move_id}"] = True
        self.gm.party.inventory.pop(item_id, None)
        self._item_cursor = 0
        self.gm.audio.play("learned")
        self._message = f"{short_name(member_id)} learned {by_id('moves')[move_id]['name']}!"

    def _plant_seed(self, member: "PartyMember") -> None:
        """Use the seed being held on ``member``: the stat grows, and one seed is gone."""
        from core.stats import STAT_NAMES

        stat = ItemSettings.SEEDS[self._using]
        member.growth[stat] = member.growth.get(stat, 0) + ItemSettings.SEED_POINTS
        member.refresh_stats()
        bag = self.gm.party.inventory
        bag[self._using] -= 1
        if bag[self._using] <= 0:
            del bag[self._using]
        self._using = None
        self._item_cursor = min(self._item_cursor, max(0, len(self._rows()) - 1))
        self.gm.audio.play("learned")
        self._message = f"{short_name(member.id)}'s {STAT_NAMES[stat]} up!"

    def _can_drink(self, member: "PartyMember") -> bool:
        """A potion helps the living who are hurt."""
        return 0 < member.current_hp < member.max_hp

    def _give_potion(self, member: "PartyMember") -> None:
        """Heal ``member`` by the item's worth of the HP they show, and spend one."""
        _, shown, top = stance_numbers(member)
        healed = min(top, shown + ItemSettings.HEALS[self._using])
        member.current_hp = min(member.max_hp, round(healed * member.max_hp / max(1, top)))
        # A potion's count stays at 0 rather than going: a missing entry
        # means an old save, and the battle would hand out a new stack.
        bag = self.gm.party.inventory
        bag[self._using] -= 1
        if bag[self._using] <= 0 and self._using != "potion":
            del bag[self._using]

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move the cursor, use an item, or step back."""
        if self._message is not None:
            if input_map.is_confirm(event) or input_map.is_cancel(event):
                self._message = None
            return
        if self._using is not None:
            self._handle_member_pick(event)
            return
        rows = self._rows()
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif rows and input_map.is_up(event):
            self._item_cursor = (self._item_cursor - 1) % len(rows)
            self.gm.audio.play("menu_move")
        elif rows and input_map.is_down(event):
            self._item_cursor = (self._item_cursor + 1) % len(rows)
            self.gm.audio.play("menu_move")
        elif rows and input_map.is_confirm(event):
            item_id, count = rows[self._item_cursor % len(rows)]
            if item_id in ItemSettings.SHELLS and count > 0:
                self._learn(item_id)
            elif (item_id in _USABLE or item_id in ItemSettings.SEEDS) and count > 0:
                self._using = item_id
                self.gm.audio.play("menu_select")

    def _handle_member_pick(self, event: pygame.event.Event) -> None:
        """Choose who gets the item; cancel goes back to the list."""
        members = self.gm.party.members
        if input_map.is_cancel(event):
            self._using = None
            self.gm.audio.play("menu_move")
        elif input_map.is_up(event):
            self._member_cursor = (self._member_cursor - 1) % len(members)
            self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            self._member_cursor = (self._member_cursor + 1) % len(members)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            member = members[self._member_cursor]
            if self._using in ItemSettings.SEEDS:
                self._plant_seed(member)
                return
            if not self._can_drink(member):
                self.gm.audio.play("menu_move")
                return
            self._give_potion(member)
            self.gm.audio.play("hit_sparkle_1")
            if self.gm.party.inventory.get(self._using, 0) <= 0:
                self._using = None
                self._item_cursor = min(self._item_cursor, max(0, len(self._rows()) - 1))

    def render(self, surface: pygame.Surface) -> None:
        """Paint the heading, each item row with the cursor, and the party while picking.

        Args:
            surface: The screen surface to draw onto.
        """
        render_scene_background(self, surface)
        rows = self._rows()
        here = rows[self._item_cursor % len(rows)][0] if rows else None
        draw_header(surface, "Items", help_wrap(item_help(here)) if here else [])
        if not rows:
            text_renderer.draw_text(
                surface,
                "Empty.",
                (_LIST_LEFT_X, _LIST_TOP_Y),
                color=ColorSettings.GRAY,
                size=FontSettings.SIZE_BODY,
            )
        cursor = self._item_cursor % len(rows) if rows else 0
        self._top = min(max(self._top, cursor - _VISIBLE_ROWS + 1), cursor)
        for index, (item_id, count) in enumerate(rows):
            if not self._top <= index < self._top + _VISIBLE_ROWS:
                continue
            y = _LIST_TOP_Y + (index - self._top) * _LIST_ROW_HEIGHT
            color = ColorSettings.WHITE if count > 0 else ColorSettings.GRAY
            text_renderer.draw_text(
                surface, item_name(item_id), (_LIST_LEFT_X, y), color=color, size=FontSettings.SIZE_BODY,
            )
            text_renderer.draw_text(
                surface, f"x{count}", (_COUNT_X, y), color=color, size=FontSettings.SIZE_BODY,
            )
            if index == self._item_cursor % len(rows):
                _draw_pointer(surface, (_LIST_LEFT_X - 4, y + 3), dim=self._using is not None)
        if self._using is not None:
            self._render_party(surface)
        if self._message is not None:
            draw_window(surface, _PARTY_RECT)
            text_renderer.draw_text(surface, self._message, (_LIST_LEFT_X, _PARTY_TOP_Y),
                                    color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY)

    def _render_party(self, surface: pygame.Surface) -> None:
        """The party along the bottom: name and HP, the knocked out in red."""
        draw_window(surface, _PARTY_RECT)
        for index, member in enumerate(self.gm.party.members):
            y = _PARTY_TOP_Y + index * _PARTY_ROW_HEIGHT
            _, shown, top = stance_numbers(member)
            down = member.current_hp <= 0
            color = ColorSettings.RED if down else ColorSettings.WHITE
            text_renderer.draw_text(
                surface, short_name(member.id), (_LIST_LEFT_X, y),
                color=color, size=FontSettings.SIZE_BODY,
            )
            text_renderer.draw_text(
                surface, f"HP {shown}/{top}", (_HP_X, y),
                color=color, size=FontSettings.SIZE_BODY,
            )
            if index == self._member_cursor:
                _draw_pointer(surface, (_LIST_LEFT_X - 4, y + 3))


def _draw_pointer(surface: pygame.Surface, tip: tuple[int, int], dim: bool = False) -> None:
    """The yellow cursor arrow, pointing right at ``tip``; grey while another list has the cursor."""
    pygame.draw.polygon(surface, ColorSettings.GRAY if dim else ColorSettings.YELLOW, [
        tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 5, tip[1] + 5),
    ])
