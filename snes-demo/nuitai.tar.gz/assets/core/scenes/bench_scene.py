"""The PARTY screen: who fights and who waits (Frankie, 10/23).

Pushed by Party on the field menu. Up to seven travel and only three
fight (D-196), so the screen is split as Final Fantasy VI splits the
party, or as Chrono Trigger's Epoch swaps who comes along: the three who
fight in the top window, everyone else in the bottom one. Pick one,
then another, and they trade places, as on any Super Nintendo party
screen (Frankie, 11/2): from different rows it swaps who fights, from
the same row it puts them in order. The first three's order is the
order they fight in and stand on the field menu. Picking the same one
again drops it; cancel drops the pick, then goes back to the menu. The
three can also be put in order on the field menu itself, by moving left
onto the portraits there.

Final Fantasy VI's top, as every screen the menu opens (``draw_header``):
the box saying Party, and the help line naming whoever the cursor is on.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.factories import stance_numbers
from core.scene import Scene
from core.shared import role, short_name
from settings import BattleSettings, ColorSettings, FontSettings, UISettings
from ui import input_map, text_renderer
from ui.window import draw_header, draw_window
from utils.backgrounds import render_scene_background
from utils.graphics import load_portrait

if TYPE_CHECKING:
    from main import GameManager


# The two rows' windows, a slot's place in them, on the 8 pixel grid.
_FIGHT_RECT = pygame.Rect(0, 64, 256, 80)
_WAIT_RECT = pygame.Rect(0, 144, 256, 80)
_SLOT_LEFT = 17           # A frame starts a tile (16), so the cartridge can blank an empty slot.
_SLOT_PITCH = 56            # Four across the bottom row: seven travel at most.
_PORTRAIT_DOWN = 9          # From the window's top to the portrait's; its frame starts a tile.
_NAME_DOWN = 64             # From the window's top to the name under it.
WAIT_SLOTS = 4


def slot_x(column: int) -> int:
    """The left edge of slot ``column``'s portrait."""
    return _SLOT_LEFT + column * _SLOT_PITCH


class BenchScene(Scene):
    """Swap who fights with who waits."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        # The cursor: row 0 the three who fight, row 1 the rest; and the pick, as (row, column).
        self._row = 0
        self._col = 0
        self._held: tuple[int, int] | None = None

    def _rows(self) -> tuple[list, list]:
        members = self.gm.party.members
        return members[:BattleSettings.FIGHTERS], members[BattleSettings.FIGHTERS:]

    def _index(self, row: int, col: int) -> int:
        return col if row == 0 else BattleSettings.FIGHTERS + col

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move between the two rows, pick, swap, or step back."""
        rows = self._rows()
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            if self._held is not None:
                self._held = None
            else:
                self.gm.scene_stack.pop()
        elif input_map.is_left(event) or input_map.is_right(event):
            step = -1 if input_map.is_left(event) else 1
            self._col = (self._col + step) % len(rows[self._row])
            self.gm.audio.play("menu_move")
        elif (input_map.is_up(event) or input_map.is_down(event)) and rows[1]:
            self._row = 1 - self._row
            self._col = min(self._col, len(rows[self._row]) - 1)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            self.gm.audio.play("menu_select")
            here = (self._row, self._col)
            if self._held is None or self._held == here:
                self._held = None if self._held == here else here
                return
            members = self.gm.party.members
            a, b = self._index(*self._held), self._index(*here)
            members[a], members[b] = members[b], members[a]
            self._held = None

    def render(self, surface: pygame.Surface) -> None:
        render_scene_background(self, surface)
        rows = self._rows()
        member = rows[self._row][self._col] if rows[self._row] else None
        help_lines = []
        if member is not None:
            _, shown, top = stance_numbers(member)
            help_lines = [f"{short_name(member.id)}, {role(member.id)}".rstrip(", "), f"HP {shown}/{top}"]
        draw_header(surface, "Party", help_lines)
        for row, rect in enumerate((_FIGHT_RECT, _WAIT_RECT)):
            draw_window(surface, rect)
            for col, someone in enumerate(rows[row]):
                self._render_slot(surface, rect, row, col, someone)
        if member is not None:
            # The hook, last so it is never under a window on its way (Frankie, 11/2; it was a yellow arrow).
            rect = (_FIGHT_RECT, _WAIT_RECT)[self._row]
            text_renderer.draw_pointer(surface, (slot_x(self._col) + 4,
                                                 rect.top + _PORTRAIT_DOWN + UISettings.PORTRAIT_SIZE // 2))

    def _render_slot(self, surface: pygame.Surface, rect: pygame.Rect, row: int, col: int, member) -> None:
        """One portrait with the first name under it; the pick and the cursor's framed yellow."""
        size = UISettings.PORTRAIT_SIZE
        frame = pygame.Rect(slot_x(col), rect.top + _PORTRAIT_DOWN, size, size)
        surface.blit(load_portrait(member.id), frame.topleft)
        held = self._held == (row, col)
        here = (self._row, self._col) == (row, col)
        pygame.draw.rect(surface, ColorSettings.YELLOW if held or here else ColorSettings.WHITE,
                         frame.inflate(2, 2), 1)
        color = ColorSettings.RED if member.current_hp <= 0 else ColorSettings.WHITE
        text_renderer.draw_text(surface, short_name(member.id), (frame.left - 1, rect.top + _NAME_DOWN),
                                color=color, size=FontSettings.SIZE_BODY)
