# Rooms set aside

The demo's old test rooms, painted before the woods were generated (10/21). The game and the
Workshop read only `data/cells/*.json`, so nothing here is loaded. Kept so nothing is lost; move a
file back up one folder to use it again (outside the woods' slots).
