"""The Workshop's small windows: Options, Help and Open room (Frankie, 11/2).

The menu bar in ``workshop.py`` opens them. They are tkinter, as the
dialogue editor (``workshop_lines.py``), hung from the same hidden root
and kept awake by the same ``pump`` in the Workshop's loop.

The options are kept in ``workshop_options.json`` beside this file, one
per computer: git leaves it alone, since a window size that suits one
screen may not suit another.
"""

from __future__ import annotations

import json
import os
from typing import Callable

try:
    import tkinter as tk
except ImportError:  # a Python without it: the Workshop says so
    tk = None

OPTIONS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "workshop_options.json")
DEFAULTS = {
    "show_grid": True,       # the grid over the room when the Workshop opens
    "show_map": False,       # the map of rooms in the panel when it opens
    "size": 0,               # how many times the layout is enlarged; 0 is as big as fits the screen
    "dialogue_look": "dark",  # the dialogue editor's colors when it opens
}

# The Workshop's colors, as the dialogue editor's dark look.
BACKGROUND = "#181c28"
BOX = "#10121c"
TEXT = "#d7d7d7"
DIM = "#8a8ea0"
PICKED = "#2a3350"
UI_FONT = ("Segoe UI", 10)
HEADING_FONT = ("Segoe UI", 13, "bold")
# One color per menu, the same as the menu bar's (``workshop.py``).
CATEGORY = {"file": "#6cc6ff", "edit": "#ff9a5c", "view": "#8be07a", "tools": "#e08ae0", "help": "#ffd24a"}


def load_options() -> dict:
    """The saved options, with the defaults for anything missing or unreadable."""
    options = dict(DEFAULTS)
    try:
        with open(OPTIONS_PATH, encoding="utf-8") as f:
            saved = json.load(f)
    except (OSError, ValueError):
        return options
    for key, default in DEFAULTS.items():
        if isinstance(saved.get(key), type(default)):
            options[key] = saved[key]
    return options


def save_options(options: dict) -> None:
    with open(OPTIONS_PATH, "w", encoding="utf-8", newline="\n") as f:
        json.dump({key: options[key] for key in DEFAULTS}, f, indent=4)
        f.write("\n")


def _dark(top) -> None:
    top.configure(bg=BACKGROUND)


def _button(parent, text: str, command: Callable) -> "tk.Button":
    return tk.Button(parent, text=text, command=command, width=10, relief="flat", font=UI_FONT,
                     bg=BOX, fg=TEXT, activebackground=PICKED, activeforeground=TEXT)


class _Single:
    """A window there is only one of: opening it again brings it to the front."""

    top = None

    def alive(self) -> bool:
        try:
            return self.top is not None and bool(self.top.winfo_exists())
        except tk.TclError:
            return False

    def lift(self) -> None:
        self.top.deiconify()
        self.top.lift()
        self.top.focus_force()


class OptionsWindow(_Single):
    """The options; OK keeps them, writes the file and hands them to ``apply``."""

    def __init__(self, root, options: dict, scales: list[int], apply: Callable[[dict], None]) -> None:
        self.apply = apply
        self.top = tk.Toplevel(root, padx=16, pady=14)
        self.top.title("Workshop options")
        self.top.resizable(False, False)
        _dark(self.top)
        self.grid = tk.BooleanVar(value=options["show_grid"])
        self.map = tk.BooleanVar(value=options["show_map"])
        self.size = tk.IntVar(value=options["size"])
        self.look = tk.StringVar(value=options["dialogue_look"])

        def heading(text: str, color: str) -> None:
            tk.Label(self.top, text=text, bg=BACKGROUND, fg=color, font=("Segoe UI", 11, "bold"),
                     anchor="w").pack(fill="x", pady=(10, 2))

        def choice(widget, **kwargs):
            widget(self.top, bg=BACKGROUND, fg=TEXT, selectcolor=BOX, activebackground=BACKGROUND,
                   activeforeground=TEXT, font=UI_FONT, anchor="w", **kwargs).pack(fill="x")

        heading("When the Workshop opens", CATEGORY["view"])
        choice(tk.Checkbutton, text="Show the grid over the room", variable=self.grid)
        choice(tk.Checkbutton, text="Show the map of rooms in the panel", variable=self.map)
        heading("Window size", CATEGORY["view"])
        choice(tk.Radiobutton, text="As big as fits the screen", variable=self.size, value=0)
        for scale in scales:
            choice(tk.Radiobutton, text=f"{scale}x" + (", the game's own size" if scale == 1 else ""), variable=self.size, value=scale)
        heading("Dialogue editor colors", CATEGORY["tools"])
        choice(tk.Radiobutton, text="Dark", variable=self.look, value="dark")
        choice(tk.Radiobutton, text="Light", variable=self.look, value="light")
        tk.Label(self.top, text="The grid, the map and the size change right away;\n"
                                "the colors next time the dialogue editor opens.",
                 bg=BACKGROUND, fg=DIM, font=UI_FONT, justify="left").pack(anchor="w", pady=(12, 0))

        buttons = tk.Frame(self.top, bg=BACKGROUND)
        buttons.pack(anchor="e", pady=(12, 0))
        _button(buttons, "Cancel", self.top.destroy).pack(side="right", padx=(6, 0))
        _button(buttons, "OK", self.ok).pack(side="right")
        self.top.bind("<Escape>", lambda _e: self.top.destroy())
        self.top.bind("<Return>", lambda _e: self.ok())
        self.lift()

    def ok(self) -> None:
        options = {"show_grid": self.grid.get(), "show_map": self.map.get(), "size": self.size.get(),
                   "dialogue_look": self.look.get()}
        save_options(options)
        self.apply(options)
        self.top.destroy()


class OpenRoomWindow(_Single):
    """Every room by name; a double click or Open opens one."""

    def __init__(self, root, names: list[str], current: str | None, open_room: Callable[[str], None]) -> None:
        self.open_room = open_room
        self.names = sorted(names)
        self.top = tk.Toplevel(root, padx=12, pady=12)
        self.top.title("Open a room")
        _dark(self.top)
        tk.Label(self.top, text="Type to find a room, then double click it or press Enter.",
                 bg=BACKGROUND, fg=DIM, font=UI_FONT).pack(anchor="w")
        self.query = tk.StringVar()
        search = tk.Entry(self.top, textvariable=self.query, font=UI_FONT, relief="flat", bg=BOX, fg=TEXT,
                          insertbackground=TEXT)
        search.pack(fill="x", pady=(6, 6), ipady=3)
        self.listbox = tk.Listbox(self.top, height=18, width=36, font=UI_FONT, relief="flat", bg=BOX, fg=TEXT,
                                  selectbackground=PICKED, selectforeground=CATEGORY["file"],
                                  activestyle="none", highlightthickness=0, exportselection=False)
        self.listbox.pack(fill="both", expand=True)
        self.shown: list[str] = []
        self.query.trace_add("write", lambda *_a: self._fill())
        self._fill()
        if current in self.shown:
            at = self.shown.index(current)
            self.listbox.selection_set(at)
            self.listbox.see(at)
        self.listbox.bind("<Double-Button-1>", lambda _e: self.open())
        self.top.bind("<Return>", lambda _e: self.open())
        self.top.bind("<Escape>", lambda _e: self.top.destroy())
        search.bind("<Down>", lambda _e: (self.listbox.focus_set(), self._first()))
        buttons = tk.Frame(self.top, bg=BACKGROUND)
        buttons.pack(anchor="e", pady=(10, 0))
        _button(buttons, "Cancel", self.top.destroy).pack(side="right", padx=(6, 0))
        _button(buttons, "Open", self.open).pack(side="right")
        self.lift()
        search.focus_set()

    def _fill(self) -> None:
        query = self.query.get().strip().lower()
        self.shown = [name for name in self.names if query in name.lower()]
        self.listbox.delete(0, "end")
        for name in self.shown:
            self.listbox.insert("end", name)
        if query and self.shown:
            self._first()

    def _first(self) -> None:
        if not self.listbox.curselection() and self.shown:
            self.listbox.selection_set(0)

    def open(self) -> None:
        picked = self.listbox.curselection()
        if not picked:
            return
        self.open_room(self.shown[picked[0]])
        self.top.destroy()


# The help page: (category, heading, paragraphs). A row of keys is "keys | what they do".
HELP = [
    ("help", "Getting started", [
        "The Workshop paints the game's rooms. The room is on the left, drawn by the game's own code, "
        "so what you see is what plays. The palette of brushes is on the right, and the bar along the "
        "bottom says where the mouse is and what just happened.",
        "Everything is in the menus along the top, and each menu item shows its key on the right, so the "
        "menus are also a list of the keys. The toolbar under the menus has the things used most. Point at "
        "a menu item or a button and the bottom bar says what it does.",
        "Nothing is written to the files until you save. A star after the room's name in the bottom bar "
        "means it has changes that are not saved yet.",
    ]),
    ("view", "Painting", [
        "Click a brush in the palette to pick it: a tile, a building, a garden patch, a monster or a person. "
        "The mouse wheel scrolls the palette when it is longer than the panel.",
        "Left click or drag on the room puts the brush down. A building goes down by its top left corner.",
        "Right click on anything opens a small menu at the mouse, with what can be done to it. A person: Edit "
        "what they say, Turn, Open sprite in Aseprite, Delete. A monster: Turn, Stand still or wander, the "
        "sprite, Delete. A door: Go inside, the sprite, Delete. Other things: the sprite and Delete. A bare "
        "tile: Use as brush (and Go back out, inside a house). Left click an item to do it; Esc, or a click "
        "anywhere else, closes the menu. Open sprite in Aseprite is greyed out when Aseprite is not installed.",
    ]),
    ("view", "Moving things", [
        "Press on a house, a person, a monster or a garden patch and drag it somewhere else. A house keeps "
        "its inside and its door.",
        "To move a whole area, hold Shift and drag on the room to draw a box. Then press inside the box and "
        "drag: the tiles and everything standing in the box move together, and the cells left behind become "
        "grass. Esc, or a click outside the box, puts the box away.",
        "T turns the person or monster under the mouse. F makes the monster under the mouse stand still or "
        "wander.",
    ]),
    ("tools", "People and their dialogue", [
        "Double click a person, or point at them and press D, and the dialogue editor opens at what they "
        "say. Tools, Dialogue editor (or L) opens it to look through every line in the game: the story "
        "scenes, the field lines, then the people in each room and the questions they answer. Type in its "
        "search box to find a name, or tick Words to find what is said.",
        "In the dialogue editor, click a row to change it, or Add before and Add after to put a new line "
        "next to it. Save in that window writes the lines, and the Workshop takes the new words at once.",
        "Someone who says nothing yet opens a small window instead, where their first words can be typed.",
    ]),
    ("file", "Rooms and the map", [
        "File, Open room lists every room by name. View, Map of rooms (or M) shows the rooms around this "
        "one in the panel: click a room to open it, or click an empty slot next to a room twice to make a "
        "new room there. Right click a room on the map for a menu: Open room, or Drop room, which asks once more. The arrow keys open the room next "
        "door.",
        "E on a house goes inside it, making the inside room the first time. E inside comes back out.",
        "Edit, Rename room (or R) types a new name: Enter keeps it, Esc drops it. Edit, Delete room (or "
        "Delete, twice) drops the open room. Saving makes a drop final.",
    ]),
    ("file", "Playing", [
        "File, Play here (or P) saves, then starts the game in this room where the mouse is, with fights "
        "off. Tools, Pick story (or C) chooses what the game is started with: a fresh game, or one of the "
        "checkpoints.",
    ]),
    ("edit", "Undo and redo", [
        "Undo (Z) takes back the last change in the open room: a stroke of painting, a thing placed, moved "
        "or taken away. Redo (Shift and Z, or Ctrl and Y) puts it back. Each room keeps its own undo, and "
        "making a new change ends what redo can bring back.",
    ]),
    ("help", "Every key", [
        "S | Save every changed room",
        "Z | Undo",
        "Shift Z, Ctrl Y | Redo",
        "P | Play here, fights off",
        "C | Pick the story P plays with",
        "R | Rename the room",
        "Delete, twice | Drop the room",
        "E | Go inside a house, or back out",
        "T | Turn the person or monster under the mouse",
        "F | A monster stands still or wanders",
        "D, or double click | The dialogue of the person under the mouse",
        "L | The dialogue editor",
        "G | Show or hide the grid",
        "M | Show or hide the map of rooms",
        "Arrow keys | The room next door",
        "Ctrl O | Open a room by name",
        "Ctrl + and Ctrl - | Make the window bigger or smaller",
        "Ctrl , | Options",
        "F1 | This help",
        "Esc | Close a menu or a box, or leave (twice if something is unsaved)",
    ]),
    ("tools", "Where things are kept", [
        "Each room is a file in data/cells, and Hina's garden patches are in data/crafting/garden.json. "
        "The pygame game and the cartridge build both read those same files, so a room painted here "
        "shows up in both.",
        "The options are kept in workshop_options.json beside the Workshop, one for each computer.",
    ]),
]


class HelpWindow(_Single):
    """The help page: what every tool does, in plain words, with a list of topics to jump to."""

    def __init__(self, root, topic: str | None = None) -> None:
        self.top = tk.Toplevel(root, padx=10, pady=10)
        self.top.title("Workshop help")
        self.top.geometry("900x640")
        _dark(self.top)
        topics = tk.Listbox(self.top, width=24, font=UI_FONT, relief="flat", bg=BOX, fg=TEXT,
                            selectbackground=PICKED, activestyle="none", highlightthickness=0,
                            exportselection=False)
        topics.pack(side="left", fill="y")
        page = tk.Frame(self.top, bg=BACKGROUND, padx=10)
        page.pack(side="left", fill="both", expand=True)
        self.text = tk.Text(page, wrap="word", font=UI_FONT, relief="flat", bg=BOX, fg=TEXT, padx=14, pady=10,
                            spacing1=2, spacing3=6, cursor="arrow", highlightthickness=0)
        scroll = tk.Scrollbar(page, command=self.text.yview)
        self.text.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.text.pack(side="left", fill="both", expand=True)
        self.text.bind("<Key>", lambda _e: "break")   # read only, but text can still be selected and copied
        for category, color in CATEGORY.items():
            self.text.tag_config("heading " + category, foreground=color, font=HEADING_FONT,
                                 spacing1=14, spacing3=4)
            self.text.tag_config("key " + category, foreground=color, font=("Consolas", 10, "bold"))
        self.text.tag_config("keyrow", lmargin1=12, lmargin2=12, spacing3=1)
        self.marks: list[str] = []
        for number, (category, heading, paragraphs) in enumerate(HELP):
            mark = f"topic{number}"
            self.text.mark_set(mark, "end-1c")
            self.text.mark_gravity(mark, "left")
            self.marks.append(mark)
            self.text.insert("end", heading + "\n", ("heading " + category,))
            for paragraph in paragraphs:
                keys, bar, what = paragraph.partition(" | ")
                if bar:
                    self.text.insert("end", f"{keys:<24}", ("key " + category, "keyrow"))
                    self.text.insert("end", what + "\n", ("keyrow",))
                else:
                    self.text.insert("end", paragraph + "\n")
            topics.insert("end", heading)
            topics.itemconfig(number, fg=CATEGORY[category])
        topics.bind("<<ListboxSelect>>", lambda _e: self._go(topics))
        self.top.bind("<Escape>", lambda _e: self.top.destroy())
        self.topics = topics
        self.show(topic)
        self.lift()

    def _go(self, topics) -> None:
        picked = topics.curselection()
        if picked:
            self.text.yview(self.marks[picked[0]])

    def show(self, topic: str | None) -> None:
        """Scroll to the topic with this heading, or the top."""
        at = next((k for k, (_c, heading, _p) in enumerate(HELP) if heading == topic), 0)
        self.topics.selection_clear(0, "end")
        self.topics.selection_set(at)
        self.text.yview(self.marks[at])
