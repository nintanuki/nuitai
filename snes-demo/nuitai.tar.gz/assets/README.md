# Nuitai RPG

A turn-based, sprite-based JRPG set in the world of **Nuitai**, an ocean planet of scattered islands that spiral around a permanent whirlpool, where magic is cast by motion and every fighter draws on two of six elements.

Long-term inspirations: *Chrono Trigger*, *Final Fantasy IV*, *Dragon Quest*. The eventual target is a complete SNES-style 2D JRPG with hand-drawn pixel art and an original score, all created by the author without using free assets.

## Status

**Layer 1 in progress.** `python main.py` gives a title screen, a walkable overworld with random encounters, save and load, and a battle. **As of 2026-10-07 the battle runs the rules from the browser battle test** ([`../browser/`](../browser/)): visible turn order, stats shaped by elements, shared element moves and one special each, for Kailo, Hina and Tawiri against the Beast pack. The rest of the browser's roster is not ported yet.

**As of 2026-10-17 the game draws on a Super Nintendo screen** (D-158, D-444, D-445): 256 by 224 pixels, enlarged by a whole number to fill the window (F11 for the whole screen), map tiles 16 pixels, walkers one 16 by 16 tile, Pokémon style (D-573), letters 8 by 8 on 16 pixel rows (32 to a line, so names shorten to first names), portraits 32 on the party screen. The battle window is Final Fantasy's: commands on the left, the party's names, bars and HP on the right. Every size is in `settings.py`; nothing is ever smoothed. Kailo walks as Ninja Adventure's Boy (CC0), unedited; `tools/screens.py` saves a picture of every screen into `docs/screens/`; `tools/snes_check.py` lists every picture or piece of code that breaks the Super Nintendo limits (D-577).

The game is being built in clearly-defined layers. See [docs/ROADMAP.md](docs/ROADMAP.md) for the full plan and acceptance criteria for each layer.

| Layer | Description | Status |
| ----- | ----------- | ------ |
| 0 | Engine spike: scenes, save/load, dialogue box, turn queue, in-window text rendering | In progress |
| 1 | Vertical-slice text demo: three-character party, one small dungeon, one boss | Planned |
| 2 | Content & polish on the same engine: town hub, second dungeon, full element coverage | Planned |
| 3 | Dragon-Quest stage: tile maps + sprite encounters, narration still in the text box | Planned |
| 4 | Art & audio pass: original sprites, original music, animated battles, ship/whirlpool system | Planned |
| 5 | Full vision: airship, Po'lelo stone-speech puzzles, complete world, full story arcs | Planned |

Every layer is **shippable on its own**. The Dragon Quest layer in particular is treated as a legitimate destination, not a stop-over.

## The world

Nuitai is documented in [lore/INDEX.md](../../lore/INDEX.md) — 114 articles across 12 categories (people, places, organizations, languages, professions, species, rituals, technologies). The World Anvil export is preserved at [lore/LOREDUMP.html](../../archive/world-anvil-2026-09/LOREDUMP.html). The original World Anvil Page can be found [here](https://www.worldanvil.com/w/nuitai-nintanuki).

The artistic and design pillars that come from the lore are summarized in [docs/VISION.md](docs/VISION.md).

## The starting party

The Layer-1 demo will have three playable characters with different battle rolls. Together they cover all six elements with no overlap.

| Character | Elements | Role | Source article |
| --------- | -------- | ---- | -------------- |
| **Kailo** | Fire + Water | Fighter / Defender | [lore/person/kailo-the-cook.md](../../lore/person/kailo-the-cook.md) |
| **Hina** | Light + Nature | Enhancer / Healer | [lore/person/hina-the-māla-priestess.md](../../lore/person/hina-the-māla-priestess.md) |
| **Tawiri** | Spirit + Shadow | Blaster / Saboteur | [lore/person/tawiri-the-elderly-caller.md](../../lore/person/tawiri-the-elderly-caller.md) |

A fourth character, **Maika** (Nature + Spirit, healer / blaster: [lore/person/maika-the-maki-sage.md](../../lore/person/maika-the-maki-sage.md)), will also appear as an NPC in the demo and join the party in Layer 2.

## Requirements

- Python 3.10+
- `pygame` 2.5+

## Run

```powershell
python main.py
```

## The Workshop: painting the rooms

The map is screens: every room is one screen of 16 by 14 tiles, its own file in
`data/cells/`, and walking off an edge puts the party in the room next door. **The
Workshop** is the paint program for them (D-663), a program of its own, not in the game
(Frankie, 10/23): double-click `Workshop.pyw`, or run `python workshop.py`. It opens its own window: the room on the left, drawn exactly as the
game draws it, a palette of tiles, monsters and people on the right with a map of the rooms
under it, and a bar of words along the bottom.

| Do this | To |
| ------- | -- |
| Left click or drag on the room | Put the brush down: paint a tile, or stand a monster or a person there |
| Press and drag on a thing | Move it; a house keeps its inside and its door |
| Right click on a thing | Take it away |
| Right click on a bare tile | Pick that tile up as the brush |
| Click a brush in the palette | Pick it |
| Click a room in the map, or the arrow keys | Open it |
| Click an empty slot beside a room in the map, twice | Make a new room there (its edges open where the neighbor's do) |
| Right click a room in the map, twice | Drop that room |
| `S` | Save every changed room |
| `Z` | Undo the last change in this room |
| `P` | Save, then play the game in this room where the mouse is, with fights off |
| `R` | Rename the room (type, then Enter) |
| `T` | Turn the person under the mouse (or flip the monster) |
| `F` | Make the monster under the mouse stand still, or wander again |
| `G` | Show or hide the grid |
| `Delete` twice | Drop the room |
| `Esc` | Leave; twice if something is unsaved |

A monster whose kind has a fixed fight (the Great Boar) is placed as a boss: it stands still
and is gone for good once beaten. A shopkeeper's `shop` is set in the room's file for now.
The Workshop is a desktop tool: it is not in the browser build and never goes on the cartridge,
which reads the same room files through `game/snes/tools/make_art.py`.

## Controls (defaults)

Every in-game action has both a keyboard binding and a controller binding. The controller does only what a Super Nintendo pad can do on the cartridge or in an emulator (Frankie, 10/23), so the window's own keys, fullscreen and mute, are keyboard only. The controller column uses Xbox-style face-button names; on a PlayStation or Switch pad the button in the same position does the same thing. A pad can be plugged in or out while the game runs.

| Action                       | Keyboard                   | Controller             |
| ---------------------------- | -------------------------- | ---------------------- |
| Move / navigate menus        | Arrow keys *or* `W A S D`  | D-pad *or* left stick  |
| Confirm / advance text       | `Enter` / `Z` / `Space`    | `A` (south)            |
| Cancel / back                | `Backspace` / `X`          | `B` (east)             |
| Open the field menu          | `Tab` / `Enter`            | `Y` (north)            |
| Pause and unpause, anywhere  | `P`                        | `START`                |
| Toggle fullscreen            | `F11`                      |                        |
| Mute and unmute all sound (MUTE shows in green, top right) | `M` |  |
| Reset to the title at once (no quitting inside the game; the window's close button closes it) |  | `L1 + R1 + START + SELECT` |

The pad layout is D-575.

The desktop game is also an emulator, for testing (Frankie, 10/23; `emulator.py`, not in the browser build or on the cartridge): `F1` freezes the game and opens a file menu (Reset, Save State, Load State, Resume; keyboard or mouse, `F1` or `Esc` closes it), `~` held fast-forwards at 4 times speed, `F2` saves a state and `F4` loads it (one state, `saves/state.pickle`, the whole running game: a menu, a story scene or a fight included; the save slots are untouched). `F3` shows the layout debug overlay.

## Documentation

| Document | Purpose |
| -------- | ------- |
| [docs/VISION.md](docs/VISION.md) | The artistic North Star. What "done" feels like. Largely immutable. |
| [docs/ROADMAP.md](docs/ROADMAP.md) | The six-layer plan. Acceptance criteria and asset requirements per layer. |
| [docs/TODO.md](docs/TODO.md) | The current layer's actionable tasks (code, writing, and art alike). |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | How the code currently fits together. |
| [docs/TESTING.md](docs/TESTING.md) | Manual smoke checks. |
| [docs/CHANGELOG.md](docs/CHANGELOG.md) | Append-only history of every change. |
| [lore/INDEX.md](../../lore/INDEX.md) | Per-article TOC of the Nuitai world bible. |
| [.github/copilot-instructions.md](.github/copilot-instructions.md) | Rules for human or AI editors. |

## Project layout

```
core/            Domain types: elements, scenes, save state, event records.
systems/         Gameplay systems: audio, battle, party, dialogue.
ui/              Renderers and widgets: text box, menu, battle view, world view.
utils/           Pure helpers and one-shot tools (e.g. the lore splitter).
data/            JSON content packs: characters, abilities, enemies, dungeons, dialogue.
assets/          Fonts, graphics, audio.
saves/           Player save files (gitignored).
docs/            Vision, roadmap, architecture, testing, changelog, lore.
crt.py           CRT post-processing overlay.
main.py          Entry point + GameManager.
settings.py      All tunable constants.
```

## Asset credits

- `assets/font/PressStart2P-Regular.ttf` — *Press Start 2P* by Cody "CodeMan38" Boisclair, SIL Open Font License 1.1 (the licence is beside it). Until Frankie draws his own 8 by 8 font.
- `assets/graphics/effects/tv.png` — CRT overlay reused from the arcade cabinet asset set. Originally created and coded by Clear Code of YouTube.
- `assets/graphics/player/kailo.png` — Kailo's walking frames, Ninja Adventure's Boy walk sheet (Pixel-boy, CC0), unedited. A stand-in until Kailo is drawn at 16 by 16 (D-573).
- The long-term goal is for **all** sprite art, music, and writing to be original work by the author. Free placeholder assets used during early layers will be credited here as they are added, and replaced as the project matures.
