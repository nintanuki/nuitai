"""The Workshop's dialogue window: type what a person says (Frankie, 10/25).

D over a person in the Workshop opens it. The words are shown as text,
one row per text box (``core/dialogue_text.py`` has the rules), each
speaker's name in a color of its own. Done puts them on the person in
the Workshop, one undo step, and S saves them to the room's file with
everything else; Cancel or closing the window drops them.

The window is tkinter, the window kit that comes with Python, because it
has real text boxes (typing, selecting, copy and paste) and pygame has
none. It runs in the Workshop's own loop: the Workshop calls ``pump``
every frame, so both windows stay awake and edit the same rooms.
"""

from __future__ import annotations

from typing import Callable

try:
    import tkinter as tk
except ImportError:  # a Python without it: the Workshop says so and goes on
    tk = None

from core import dialogue_text

# The Workshop's colors (its panel and bar), so the two windows match.
BACKGROUND = "#181c28"
BOX = "#10121c"
TEXT = "#d7d7d7"
DIM = "#787878"
WRONG = "#ff7070"
YELLOW = "#ffd24a"
# One color per speaker, the first speaker seen taking the first.
SPEAKER_COLORS = ("#6cc6ff", "#ff9a5c", "#8be07a", "#e08ae0", "#ffd24a", "#5ce0c8", "#ff7aa0", "#b8a0ff")
FONT = ("Consolas", 12)


class DialogueWindows:
    """Every open dialogue window, pumped from the Workshop's loop."""

    def __init__(self) -> None:
        self.root = None
        self.open: list["DialogueWindow"] = []

    @property
    def available(self) -> bool:
        return tk is not None

    def ensure_root(self):
        """The hidden root every window hangs from (the lines window's too, ``workshop_lines.py``)."""
        if self.root is None:
            self.root = tk.Tk()
            self.root.withdraw()
        return self.root

    def edit(self, person: dict, room: str, done: Callable[[dict, dict], str]) -> None:
        """Open a window for ``person``; ``done(person, words)`` is called with the new words."""
        self.ensure_root()
        for window in self.open:
            if window.person is person:
                window.top.lift()
                window.top.focus_force()
                return
        self.open.append(DialogueWindow(self, person, room, done))

    def pump(self) -> None:
        """Let the windows draw and hear keys; called every Workshop frame."""
        if self.root is None:
            return
        try:
            self.root.update()
        except tk.TclError:
            self.root = None
            self.open.clear()

    def close_all(self) -> None:
        if self.root is not None:
            self.root.destroy()
            self.root = None
        self.open.clear()


class DialogueWindow:
    """One person's words, a text box per field."""

    def __init__(self, owner: DialogueWindows, person: dict, room: str,
                 done: Callable[[dict, dict], str]) -> None:
        self.owner, self.person, self.done = owner, person, done
        name = person.get("speaker") or person.get("sheet", "Someone")
        self.top = tk.Toplevel(owner.root, bg=BACKGROUND, padx=10, pady=10)
        self.top.title(f"{name} in {room}")
        self.top.protocol("WM_DELETE_WINDOW", self.cancel)
        self.colors: dict[str, str] = {}

        how = f"{name} says the next line each time you talk to them, round and round."
        tk.Label(self.top, text=how + "\nOne row is one text box. talk: plays its indented rows as one line;"
                 " once FLAG: does that one time only.",
                 bg=BACKGROUND, fg=DIM, justify="left", font=("Segoe UI", 10)).pack(anchor="w")

        self.boxes: dict[str, tk.Text] = {}
        for key, heading, _spoken in dialogue_text.fields_of(person):
            tk.Label(self.top, text=heading.upper(), bg=BACKGROUND, fg=YELLOW,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 2))
            box = tk.Text(self.top, width=72, height=8, wrap="word", undo=True, font=FONT,
                          bg=BOX, fg=TEXT, insertbackground=TEXT, relief="flat", padx=6, pady=6)
            box.insert("1.0", dialogue_text.to_text(person, key))
            box.edit_reset()
            box.bind("<KeyRelease>", lambda _event, b=box: self.color(b))
            box.pack(fill="both", expand=True)
            self.boxes[key] = box
            self.color(box)

        self.message = tk.Label(self.top, text="", bg=BACKGROUND, fg=WRONG, font=("Segoe UI", 10),
                                justify="left")
        self.message.pack(anchor="w", pady=(8, 0))
        buttons = tk.Frame(self.top, bg=BACKGROUND)
        buttons.pack(anchor="e", pady=(6, 0))
        tk.Button(buttons, text="Cancel", width=10, command=self.cancel).pack(side="right", padx=(6, 0))
        tk.Button(buttons, text="Done", width=10, command=self.finish).pack(side="right")
        self.top.bind("<Escape>", lambda _event: self.cancel())
        first = next(iter(self.boxes.values()), None)
        if first is not None:
            first.focus_set()

    def color(self, box: "tk.Text") -> None:
        """Color each row's speaker, and the talk and once rows dim."""
        for tag in box.tag_names():
            if tag != "sel":
                box.tag_remove(tag, "1.0", "end")
        rows = box.get("1.0", "end-1c").split("\n")
        for number, row in enumerate(rows, 1):
            stripped = row.strip()
            if stripped == "talk:" or (stripped.startswith("once ") and stripped.endswith(":")):
                box.tag_add("once", f"{number}.0", f"{number}.end")
                continue
            if ":" not in stripped or not (row[:1].isspace() or self._spoken_box(box)):
                continue
            speaker = stripped.split(":", 1)[0].split("(")[0].strip()
            color = self.colors.setdefault(speaker, SPEAKER_COLORS[len(self.colors) % len(SPEAKER_COLORS)])
            tag = "speaker " + color
            box.tag_config(tag, foreground=color)
            start = len(row) - len(row.lstrip())
            box.tag_add(tag, f"{number}.{start}", f"{number}.{start + row.lstrip().index(':') + 1}")
        box.tag_config("once", foreground=DIM)

    def _spoken_box(self, box: "tk.Text") -> bool:
        return self.boxes.get("first.talk") is box

    def finish(self) -> None:
        """Done: read every box; any row that cannot be read keeps the window open and says why."""
        words = {}
        for key, box in self.boxes.items():
            try:
                words[key] = dialogue_text.from_text(box.get("1.0", "end-1c"), key)
            except ValueError as error:
                self.message.config(text=str(error))
                box.focus_set()
                return
        problem = self.done(self.person, words)
        if problem:
            self.message.config(text=problem)
            return
        self.close()

    def cancel(self) -> None:
        self.close()

    def close(self) -> None:
        if self in self.owner.open:
            self.owner.open.remove(self)
        self.top.destroy()
