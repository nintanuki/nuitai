"""The Workshop's dialogue window: type what a person says (Frankie, 10/25).

D over a person in the Workshop opens it. The words are shown as text,
one row per text box (``core/dialogue_text.py`` has the rules), each
speaker's name in a color of its own. Done puts them on the person in
the Workshop, one undo step, and S saves them to the room's file with
everything else; Cancel or closing the window drops them.

The window is tkinter, the window kit that comes with Python, because it
has real text boxes (typing, selecting, copy and paste) and pygame has
none. It runs in the Workshop's own loop: the Workshop calls ``pump``
every frame, so both windows stay awake and edit the same rooms.

Opened with the Workshop's ``Story`` (Edit Dialogue, D, a double click;
Frankie, 11/5), the window shows only the lines the person says at the
story bar's moment, the one branch the game would pick (``Story.branch``),
under a slider and switches of its own. They are the map's: moving
either moves both, and the window then shows that moment's lines. Lines
typed before a move are kept on the person first (one undo step), so
nothing typed is lost; Done keeps the rest and closes.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

try:
    import tkinter as tk
except ImportError:  # a Python without it: the Workshop says so and goes on
    tk = None

from core import dialogue_text

if TYPE_CHECKING:
    from workshop_story import Story

# The Workshop's colors (its panel and bar), so the two windows match.
BACKGROUND = "#181c28"
BOX = "#10121c"
TEXT = "#d7d7d7"
DIM = "#787878"
WRONG = "#ff7070"
YELLOW = "#ffd24a"
# One color per speaker, the first speaker seen taking the first.
SPEAKER_COLORS = ("#6cc6ff", "#ff9a5c", "#8be07a", "#e08ae0", "#ffd24a", "#5ce0c8", "#ff7aa0", "#b8a0ff")
FONT = ("Consolas", 12)
# The story bar's colors (workshop_storybar.py): yellow for the main story, one per group of switches.
GROUP_COLORS = {"melia": "#ff8cbe", "hina": "#6ebeff", "maika": "#8cdc78", "village": "#ffaa5a",
                "other": "#bebebe"}
SWITCH_COLUMNS = 4


class DialogueWindows:
    """Every open dialogue window, pumped from the Workshop's loop."""

    def __init__(self) -> None:
        self.root = None
        self.open: list["DialogueWindow"] = []

    @property
    def available(self) -> bool:
        return tk is not None

    def ensure_root(self):
        """The hidden root every window hangs from (the lines window's too, ``workshop_lines.py``)."""
        if self.root is None:
            self.root = tk.Tk()
            self.root.withdraw()
        return self.root

    def edit(self, person: dict, room: str, done: Callable[[dict, dict], str],
             story: "Story | None" = None) -> "DialogueWindow":
        """Open a window for ``person``; ``done(person, words)`` is called with the new words.
        With ``story``, only the lines of its moment, under its slider and switches."""
        self.ensure_root()
        for window in self.open:
            if window.person is person:
                window.top.lift()
                window.top.focus_force()
                return window
        window = DialogueWindow(self, person, room, done, story)
        self.open.append(window)
        return window

    def pump(self) -> None:
        """Let the windows draw and hear keys; called every Workshop frame."""
        if self.root is None:
            return
        try:
            self.root.update()
        except tk.TclError:
            self.root = None
            self.open.clear()

    def close_all(self) -> None:
        for window in list(self.open):
            if window.story is not None:
                window.story.forget(window.story_moved)
        if self.root is not None:
            self.root.destroy()
            self.root = None
        self.open.clear()


class DialogueWindow:
    """One person's words, a text box per field; with a story, only its moment's fields."""

    def __init__(self, owner: DialogueWindows, person: dict, room: str,
                 done: Callable[[dict, dict], str], story: "Story | None" = None) -> None:
        self.owner, self.person, self.room, self.done, self.story = owner, person, room, done, story
        self.name = person.get("speaker") or person.get("sheet", "Someone")
        self.top = tk.Toplevel(owner.root, bg=BACKGROUND, padx=10, pady=10)
        self.top.title(f"{self.name} in {room}")
        self.top.protocol("WM_DELETE_WINDOW", self.cancel)
        self.colors: dict[str, str] = {}

        how = f"{self.name} says the next line each time you talk to them, round and round."
        tk.Label(self.top, text=how + "\nOne row is one text box. talk: plays its indented rows as one line;"
                 " once FLAG: does that one time only.",
                 bg=BACKGROUND, fg=DIM, justify="left", font=("Segoe UI", 10)).pack(anchor="w")

        self.switch_vars: dict[str, "tk.IntVar"] = {}
        self.switch_buttons: dict[str, "tk.Checkbutton"] = {}
        if story is not None:
            self._story_controls(story)
        self.fields = tk.Frame(self.top, bg=BACKGROUND)
        self.fields.pack(fill="both", expand=True)
        self.boxes: dict[str, tk.Text] = {}
        self.shown_text: dict[str, str] = {}

        self.message = tk.Label(self.top, text="", bg=BACKGROUND, fg=WRONG, font=("Segoe UI", 10),
                                justify="left")
        self.message.pack(anchor="w", pady=(8, 0))
        buttons = tk.Frame(self.top, bg=BACKGROUND)
        buttons.pack(anchor="e", pady=(6, 0))
        tk.Button(buttons, text="Cancel", width=10, command=self.cancel).pack(side="right", padx=(6, 0))
        tk.Button(buttons, text="Done", width=10, command=self.finish).pack(side="right")
        self.top.bind("<Escape>", lambda _event: self.cancel())
        self.show_fields()
        if story is not None:
            story.listen(self.story_moved)

    # --- the slider and the switches, the map's own ----------------------------------

    def _story_controls(self, story: "Story") -> None:
        from workshop_story import MOMENTS
        bar = tk.Frame(self.top, bg=BACKGROUND)
        bar.pack(fill="x", pady=(10, 0))
        tk.Label(bar, text="STORY", bg=BACKGROUND, fg=YELLOW, font=("Segoe UI", 10, "bold")).pack(side="left")
        self.moment_var = tk.IntVar(value=story.moment)
        self.slider = tk.Scale(bar, from_=0, to=len(MOMENTS) - 1, orient="horizontal", showvalue=False,
                               variable=self.moment_var, command=self._slid, length=320, bg=BACKGROUND,
                               fg=YELLOW, troughcolor=BOX, highlightthickness=0, activebackground=YELLOW)
        self.slider.pack(side="left", padx=8)
        self.moment_label = tk.Label(bar, text="", bg=BACKGROUND, fg=YELLOW, font=("Segoe UI", 10, "bold"))
        self.moment_label.pack(side="left")
        grid = tk.Frame(self.top, bg=BACKGROUND)
        grid.pack(fill="x", pady=(4, 0))
        for index, (flag, words, group) in enumerate(story.switches):
            color = GROUP_COLORS.get(group, GROUP_COLORS["other"])
            var = tk.IntVar(value=int(story.is_on(flag)))
            button = tk.Checkbutton(grid, text=words, variable=var, command=lambda f=flag: self.switch(f),
                                    bg=BACKGROUND, fg=color, selectcolor=BOX, activebackground=BACKGROUND,
                                    activeforeground=color, disabledforeground=DIM, font=("Segoe UI", 9),
                                    anchor="w", highlightthickness=0)
            button.grid(row=index // SWITCH_COLUMNS, column=index % SWITCH_COLUMNS, sticky="w", padx=(0, 10))
            self.switch_vars[flag], self.switch_buttons[flag] = var, button

    def _slid(self, _value: str) -> None:
        self.slide(self.moment_var.get())

    def slide(self, moment: int) -> None:
        """The window's slider moved: keep what was typed, then move the story (and the map with it)."""
        if moment == self.story.moment:
            return
        if not self.keep():
            self.sync_controls()
            return
        self.story.set_moment(moment)

    def switch(self, flag: str) -> None:
        """A switch clicked in the window: keep what was typed, then turn it (the map's too)."""
        if not self.keep() or not self.story.toggle(flag):
            self.sync_controls()

    def story_moved(self) -> None:
        """The story moved, here or on the map: show the new moment's lines, keeping what was typed."""
        try:
            if not self.top.winfo_exists():
                return
        except tk.TclError:
            return
        if not self.keep():
            self.message.config(text=f"The story moved to {self.story.name}, but these lines could not"
                                     " be kept yet. Fix that row, then move the slider again.")
            self.sync_controls()
            return
        self.show_fields()

    def sync_controls(self) -> None:
        if self.story is None:
            return
        self.moment_var.set(self.story.moment)
        self.moment_label.config(text=f"{self.story.moment + 1}. {self.story.name}")
        for flag, var in self.switch_vars.items():
            var.set(int(self.story.is_on(flag)))
            self.switch_buttons[flag].config(state="disabled" if self.story.locked(flag) else "normal")

    # --- the boxes ---------------------------------------------------------------------

    def fields_now(self) -> list[tuple[str, str]]:
        """The fields this window shows: the story's moment's branch, or every field."""
        if self.story is None:
            return [(key, heading) for key, heading, _spoken in dialogue_text.fields_of(self.person)]
        if not self.story.shows_person(self.room, self.person):
            return []
        return self.story.branch(self.person)

    def show_fields(self) -> None:
        for child in self.fields.winfo_children():
            child.destroy()
        self.boxes, self.shown_text = {}, {}
        self.sync_controls()
        self.message.config(text="")
        shown = self.fields_now()
        if not shown and self.story is not None:
            tk.Label(self.fields, text=f"{self.name} is not in this room at {self.story.name}.",
                     bg=BACKGROUND, fg=DIM, font=("Segoe UI", 10)).pack(anchor="w", pady=(10, 2))
        for key, heading in shown:
            tk.Label(self.fields, text=heading.upper(), bg=BACKGROUND, fg=YELLOW,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 2))
            box = tk.Text(self.fields, width=72, height=8, wrap="word", undo=True, font=FONT,
                          bg=BOX, fg=TEXT, insertbackground=TEXT, relief="flat", padx=6, pady=6)
            text = dialogue_text.to_text(self.person, key)
            box.insert("1.0", text)
            box.edit_reset()
            box.bind("<KeyRelease>", lambda _event, b=box: self.color(b))
            box.pack(fill="both", expand=True)
            self.boxes[key] = box
            self.shown_text[key] = text
            self.color(box)
        first = next(iter(self.boxes.values()), None)
        if first is not None:
            first.focus_set()

    def keep(self) -> bool:
        """Put any changed box on the person (one undo step); False, saying why, if a row cannot be read."""
        words = {}
        for key, box in self.boxes.items():
            text = box.get("1.0", "end-1c")
            if text == self.shown_text.get(key):
                continue
            try:
                words[key] = dialogue_text.from_text(text, key)
            except ValueError as error:
                self.message.config(text=str(error))
                box.focus_set()
                return False
        if not words:
            return True
        problem = self.done(self.person, words)
        if problem:
            self.message.config(text=problem)
            return False
        for key in words:
            self.shown_text[key] = self.boxes[key].get("1.0", "end-1c")
        return True

    def color(self, box: "tk.Text") -> None:
        """Color each row's speaker, and the talk and once rows dim."""
        for tag in box.tag_names():
            if tag != "sel":
                box.tag_remove(tag, "1.0", "end")
        rows = box.get("1.0", "end-1c").split("\n")
        for number, row in enumerate(rows, 1):
            stripped = row.strip()
            if stripped == "talk:" or (stripped.startswith("once ") and stripped.endswith(":")):
                box.tag_add("once", f"{number}.0", f"{number}.end")
                continue
            if ":" not in stripped or not (row[:1].isspace() or self._spoken_box(box)):
                continue
            speaker = stripped.split(":", 1)[0].split("(")[0].strip()
            color = self.colors.setdefault(speaker, SPEAKER_COLORS[len(self.colors) % len(SPEAKER_COLORS)])
            tag = "speaker " + color
            box.tag_config(tag, foreground=color)
            start = len(row) - len(row.lstrip())
            box.tag_add(tag, f"{number}.{start}", f"{number}.{start + row.lstrip().index(':') + 1}")
        box.tag_config("once", foreground=DIM)

    def _spoken_box(self, box: "tk.Text") -> bool:
        return self.boxes.get("first.talk") is box

    def finish(self) -> None:
        """Done: keep every changed box; any row that cannot be read keeps the window open and says why."""
        if self.keep():
            self.close()

    def cancel(self) -> None:
        self.close()

    def close(self) -> None:
        if self.story is not None:
            self.story.forget(self.story_moved)
        if self in self.owner.open:
            self.owner.open.remove(self)
        self.top.destroy()
