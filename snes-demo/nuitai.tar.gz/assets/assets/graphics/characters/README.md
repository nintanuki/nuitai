# Walking character bases

Stand-ins, not final art, and not used by the game yet. Unedited, exactly as downloaded on
10/17; Frankie edits copies of them in Aseprite (D-452). The original zips are in
`game/free-packs/`.

| Folder | Pack | Licence | What it is |
|---|---|---|---|
| `memao/` | **Memao Fantasy Character Sprite Pack** by Sleeping Robot Games, <https://sleeping-robot-games.itch.io/fantasy-character-sprite-pack> | Free for personal and commercial use, editing allowed, credit to "Memao" optional; no reselling or sharing the sprites as assets on their own, no AI training or AI tools, no NFTs. Credited here anyway. | Ten dressed characters, one sheet each. A 16 by 32 figure in a 48 by 48 frame, four facings; idle, walk, run, strike, slash, hurt, downed, death and more. Frankie's favourite: the base for the party. |
| `moonforge/` | **PixelArt Characters Base** by MoonForgeStudios, <https://moonforgestudios.itch.io/pixelart-characters-base> | Free for personal and commercial projects, credit appreciated, not required; no reselling or redistributing. Credited here anyway. | Two female bodies and one male, bare, 16 by 32 in four facings, idle and walk, four frames each. |
| `puny/` | **Puny Characters** by Merchant Shade, <https://merchant-shade.itch.io/16x16-puny-characters> | CC0, no credit required. Credited here anyway. | Small round figures about 16 tall in 32 by 32 frames, eight facings, plus `Character-Base.png`, a bare one. For chibi versions or a world map. |

Because none of these may be passed on as loose art, this folder must not be published as a
download of its own. Inside the game it is fine.
