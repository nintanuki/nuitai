# Monster battle pictures

Stand-ins, not final art. One still image per monster.

All 25 are from **Free 16x16 Philippine Mythological Creature Sprites** by
Merchant Shade, <https://merchant-shade.itch.io/ph-myth-creatures>. License CC0:
free to use and change, no credit required. Credited here anyway.

The files were renamed to lowercase with underscores. On 10/19 the fourteen with more than 15
colors were cut to 15, to fit the Super Nintendo (D-579).

An enemy in `game/shared/battle.json` picks its picture with `"sprite"`, the file
name without `.png`. To add a monster picture, drop a PNG with a see-through
background in this folder and name it there.

Every picture is drawn at its own size, never enlarged or shrunk (D-577).
