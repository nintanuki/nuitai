# Item pictures

`poi.png` is Ninja Adventure's `Items/Food/Onigiri.png` (Pixel-boy and AAA, CC0), a stand-in:
the pack has no poi, and a white lump of pounded starch is the nearest thing in its food. Neither
game draws item pictures yet (10/23); they wait here for the screen that will.

The plant medicine (10/23) are Ninja Adventure stand-ins too, the nearest things in its items:
`noni.png` its `Items/Food/Nut.png`, a pale lumpy fruit; `kukui.png` its `Items/Food/Honey.png`, a
jar of golden oil; `ti_leaf.png` its `Items/Food/TeaLeaf.png`; `olena.png` its
`Items/Food/SeedBig1.png`, an orange root; `awa.png` its `Items/Resource/Water.png`, a bowl to
drink from.
