# Tiles beside the Mini World sheets

`dug_sand.png`: the hole a shovel leaves on sand (10/30). The shape is `dug_dirt.png` from Dungeon Digger,
whose credits give its pixel art to Kenney (Tiny Dungeon), license CC0: free to use and change, no
credit required, credited anyway. Recolored from dirt to Nuitai's sand and made by
`tools/make_dug_hole.py`; three colors, the background see-through.
