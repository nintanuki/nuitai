# Map tiles

**Mini World Sprites** by Merchant Shade, <https://merchant-shade.itch.io/16x16-mini-world-sprites>.
License CC0: free to use and change, no credit required. Credited here anyway.

The Ground, Nature, Miscellaneous and Buildings folders as they came out of
`game/free-packs/MiniWorldSprites.zip` on 10/17, with one edit: the market stall, tile 4 of
`Buildings/Wood/Market.png`, had 18 colors and now has 15 so it fits a Super Nintendo tile even
over sand (10/19). Five rarely used colors became their nearest neighbor; it looks the same. Every tile is 16 by 16 (D-444). Which tile each map
character draws is `OverworldSettings.TILE_PICTURES` in `settings.py`.
