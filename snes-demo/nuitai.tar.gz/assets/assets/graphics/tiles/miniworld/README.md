# Map tiles

**Mini World Sprites** by Merchant Shade, <https://merchant-shade.itch.io/16x16-mini-world-sprites>.
License CC0: free to use and change, no credit required. Credited here anyway.

Unedited, the Ground, Nature, Miscellaneous and Buildings folders exactly as they came out of
`game/free-packs/MiniWorldSprites.zip` on 10/17. Every tile is 16 by 16 (D-444). Which tile each map
character draws is `OverworldSettings.TILE_PICTURES` in `settings.py`.
