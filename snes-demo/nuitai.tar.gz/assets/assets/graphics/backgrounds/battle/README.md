# Battle backgrounds

Pixel-boy's Superpowers Battlebacks Pack, CC0 (Creative Commons Zero): no credit needed, credited
anyway. Made for the Superpowers engine by Sparklin Labs
(https://github.com/sparklinlabs/superpowers-asset-packs); downloaded 10/18 from tale's re-share,
https://tale.itch.io/pixel-boy-battlebacks-pack. The 640 by 320 set, each cut to a 256 by 224 window
at its own size, the bottom of the picture (10/19, D-577). No generative AI.

Each scene has a night version (`-night`). 1 dry hills, 2 desert, 3 tropical beach (behind every
fight for now), 4 above the clouds, 5 brick ruin, 6 jungle, 7 meadow clearing, 8 temple courtyard,
9 rocky wasteland, 10 grassland, 11 castle road, 12 stone hall.
