# Superpowers Battlebacks Pack

Assets created by [Pixel-boy](https://twitter.com/2pblog1)
for [Superpowers](http://superpowers-html5.com/) supporters!

See https://github.com/sparklinlabs/superpowers-asset-packs
for license information and more assets!

Backgrounds cropped (640x320) by [tale]
Released under the Creative Commons Zero (CC0) license.