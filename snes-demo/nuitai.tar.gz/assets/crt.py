import pygame
import random

from settings import ScreenSettings, ColorSettings, AssetPaths

class CRT:
    """Creates a CRT monitor effect over the window, after the game has been enlarged.

    The game draws at 256 by 224 and ``main.py`` scales it up by a whole
    number. The overlay belongs on the enlarged picture: one scan line
    per game row, so the lines sit between the game's pixels instead of
    cutting through them.
    """
    def __init__(self, window, scale):
        """
        Load the TV overlay image and scale it to the window.

        Args:
            window: The window surface the enlarged game is drawn onto.
            scale: Window pixels per game pixel.
        """
        self.window = window
        self.scale = max(1, int(scale))
        self.base_tv = pygame.image.load(AssetPaths.TV).convert_alpha()
        self.base_tv = pygame.transform.scale(self.base_tv, window.get_size())

    def create_crt_lines(self, surf):
        """Draw a dark line along the top of every game row to mimic CRT scan lines.

        Args:
            surf: Surface receiving the scanline overlay.
        """
        width, height = surf.get_size()
        for y in range(0, height, self.scale):
            pygame.draw.line(surf, ColorSettings.OVERLAY_BACKGROUND, (0, y), (width, y), 1)

    def draw(self):
        """Draws the CRT effect by copying the base TV image, applying a random alpha for flickering,
        adding scan lines, and blitting it on top of the window."""
        # Copy per frame so the overlay effect does not accumulate between frames.
        tv = self.base_tv.copy()

        tv.set_alpha(random.randint(*ScreenSettings.CRT_ALPHA_RANGE))
        self.create_crt_lines(tv)

        self.window.blit(tv, (0, 0))
