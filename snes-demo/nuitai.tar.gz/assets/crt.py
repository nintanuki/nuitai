import pygame
import random

from settings import ScreenSettings, ColorSettings, AssetPaths

class CRT:
    """Creates a CRT monitor effect over the window, after the game has been enlarged.

    The game draws at 256 by 224 and ``main.py`` enlarges it into a view
    (``viewport.py``). The overlay belongs on that picture only, never the
    black bars around it in fullscreen: one scan line per game row. In a
    window the rows are whole pixel blocks, so the lines sit between the
    game's pixels; in fullscreen the rows are a fraction of a pixel off a
    whole number, so each line sits at its row's rounded top edge.
    """
    def __init__(self, window, view):
        """
        Load the TV overlay image, enlarge it to the picture and draw the
        scan lines into it once.

        Args:
            window: The window surface the enlarged game is drawn onto.
            view: The rectangle the enlarged picture fills in the window.
        """
        self.window = window
        self.origin = view.topleft
        self.base_tv = pygame.image.load(AssetPaths.TV).convert_alpha()
        self.base_tv = pygame.transform.scale(self.base_tv, view.size)
        self.create_crt_lines(self.base_tv)

    def create_crt_lines(self, surf):
        """Draw a dark line along the top of every game row to mimic CRT scan lines.

        Args:
            surf: Surface receiving the scanline overlay.
        """
        width, height = surf.get_size()
        rows = ScreenSettings.HEIGHT
        for row in range(rows):
            y = row * height // rows
            pygame.draw.line(surf, ColorSettings.OVERLAY_BACKGROUND, (0, y), (width, y), 1)

    def draw(self):
        """Blit the overlay at a random alpha for the flicker."""
        self.base_tv.set_alpha(random.randint(*ScreenSettings.CRT_ALPHA_RANGE))
        self.window.blit(self.base_tv, self.origin)
