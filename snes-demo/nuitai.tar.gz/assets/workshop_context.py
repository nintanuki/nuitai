"""The Workshop's right click menu, drawn in the game's own font (Frankie, 11/4).

Right click on a room, a person, a door or a tile and a small list opens
at the mouse, in the same look as the menu bar (``workshop_menu.py``,
whose ``Item`` it reuses). A left click picks an item; Esc, or a click
anywhere else, closes it. ``workshop.py`` decides which items to show: its
``CONTEXT_MENUS`` is one plain list of item names per kind of thing, so the
lists can be edited by hand later, and its ``_context_items`` turns the
names into ``Item`` objects. This file only draws the list and hears the
mouse.
"""

from __future__ import annotations

import pygame

from ui import text_renderer
from workshop_menu import COLORS, DIM, DROP, HOVER, ITEM_H, LETTER, TEXT, Item


class ContextMenu:
    """One open list of items at a point on the whole layout."""

    def __init__(self, items: list[Item], at: tuple[int, int], category: str,
                 size: tuple[int, int]) -> None:
        self.items, self.category = items, category
        w = (max(len(item.label) for item in items) + 2) * LETTER + 8
        h = len(items) * ITEM_H + 4
        self.box = pygame.Rect(max(0, min(at[0], size[0] - w)), max(0, min(at[1], size[1] - h)), w, h)
        self.mouse = at

    def _rects(self) -> list[tuple[Item, pygame.Rect]]:
        return [(item, pygame.Rect(self.box.x + 1, self.box.y + 2 + index * ITEM_H, self.box.w - 2, ITEM_H))
                for index, item in enumerate(self.items)]

    def motion(self, point: tuple[int, int]) -> None:
        self.mouse = point

    def tip(self) -> str:
        """What the item under the mouse does, for the bottom bar."""
        for item, rect in self._rects():
            if rect.collidepoint(self.mouse):
                return item.tip
        return ""

    def pick(self, point: tuple[int, int]) -> Item | None:
        """The item that is on, under a left press; None when the press missed or hit one that is off."""
        for item, rect in self._rects():
            if rect.collidepoint(point) and item.on() and item.run is not None:
                return item
        return None

    def covers(self, point: tuple[int, int]) -> bool:
        return self.box.collidepoint(point)

    def draw(self, surface: pygame.Surface) -> None:
        color = COLORS[self.category]
        pygame.draw.rect(surface, DROP, self.box)
        pygame.draw.rect(surface, color, self.box, 1)
        for item, rect in self._rects():
            on = item.on() and item.run is not None
            if on and rect.collidepoint(self.mouse):
                pygame.draw.rect(surface, HOVER, rect)
            text_renderer.draw_text(surface, item.label, (rect.x + LETTER - 2, rect.y + 2),
                                    color=TEXT if on else DIM)
