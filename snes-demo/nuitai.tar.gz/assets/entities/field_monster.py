"""Monsters seen on the map, in place of random encounters (D-576).

A field monster stands on the grid like the player and, unless it is
told to stand still, wanders one tile at a time in a random direction
every second or so, sliding across the tile as the player does. One that
sees the player close by chases instead, a step at a time and quicker;
a boss never does (Frankie, 10/21). When it
and the player meet, the overworld starts its fight.

What each kind looks like and which fight it starts is in
``data/field_monsters/<kind>.json``:

* ``sheet``: the picture in ``AssetPaths.PEOPLE_DIR``, a row of frames
  facing right (Ninja Adventure's animals), flipped to face left; or
  ``picture``, a monster's battle picture in ``AssetPaths.MONSTERS_DIR``,
  one frame, also facing right.
* ``frame_width``: how wide one frame of a ``sheet`` is.
* ``tiles``: tiles across and down that it covers, ``[1, 1]`` unless
  given. Every picture is drawn at its own size, one picture pixel to
  one screen pixel, never enlarged (D-577).
* ``encounter``: a fixed fight from the shared battle file, for a boss;
  or ``lead`` (the monster always in the fight) and ``companions``
  (who may join it), for an ordinary one. See ``compose_fight``.
"""

from __future__ import annotations

import os
import random
from typing import TYPE_CHECKING

import pygame

from settings import AssetPaths, FieldMonsterSettings, GridSettings, OverworldSettings

if TYPE_CHECKING:
    from core.world import World


# Each kind's frames by id, loaded on first use.
_FRAMES: dict[str, list[pygame.Surface]] = {}


def _frames(kind: dict) -> list[pygame.Surface]:
    """Return ``kind``'s frames facing right, at their own size; empty if missing."""
    if kind["id"] not in _FRAMES:
        frames: list[pygame.Surface] = []
        if "picture" in kind:
            path = os.path.join(AssetPaths.MONSTERS_DIR, f"{kind['picture']}.png")
            if os.path.exists(path):
                frames.append(pygame.image.load(path).convert_alpha())
        else:
            path = os.path.join(AssetPaths.PEOPLE_DIR, f"{kind['sheet']}.png")
            if os.path.exists(path):
                sheet = pygame.image.load(path).convert_alpha()
                width = kind["frame_width"]
                for index in range(sheet.get_width() // width):
                    frames.append(sheet.subsurface(
                        pygame.Rect(index * width, 0, width, sheet.get_height())
                    ))
        _FRAMES[kind["id"]] = frames
    return _FRAMES[kind["id"]]


class FieldMonster:
    """One monster standing or wandering on the map."""

    def __init__(self, spot: dict, kind: dict) -> None:
        """Place a monster.

        Args:
            spot: Where it starts, from ``FIELD_MONSTERS`` in
                ``core/overworld_cells.py``: ``col``, ``row``, ``kind``,
                ``still`` for one that never moves, and ``faces_left``
                to set which way it looks.
            kind: Its ``data/field_monsters`` entry.
        """
        self.spot = spot
        self.kind = kind
        self.col: int = spot["col"]
        self.row: int = spot["row"]
        self.width, self.height = kind.get("tiles", (1, 1))
        self.still: bool = bool(spot.get("still"))
        self.facing_left = spot.get("faces_left", random.random() < 0.5)
        self._wait = random.uniform(*FieldMonsterSettings.WAIT_RANGE)
        self._from: tuple[int, int] = (self.col, self.row)
        self._progress = 1.0

    def tiles(self) -> set[tuple[int, int]]:
        """Every tile the monster covers."""
        return {
            (self.col + dx, self.row + dy)
            for dx in range(self.width) for dy in range(self.height)
        }

    def update(self, dt: float, world: "World", taken: set[tuple[int, int]],
               player: tuple[int, int] | None = None) -> None:
        """Finish the slide under way, or wait and then try a step.

        Args:
            dt: Frame time in seconds.
            world: Asked whether a tile is a wall.
            taken: Tiles the other monsters cover; a monster never steps
                onto another. The player's tile is not in it: stepping
                onto the player is how a monster starts its fight.
            player: Where the player stands, for the chase; None when
                the monster should not chase (just after a fight).
        """
        if self._progress < 1.0:
            self._progress = min(1.0, self._progress + dt * 1000 / FieldMonsterSettings.STEP_MS)
            return
        if self.still:
            return
        self._wait -= dt
        if self._wait > 0:
            return
        steps = self._chase_steps(player)
        if steps:
            self._wait = FieldMonsterSettings.CHASE_WAIT
        else:
            self._wait = random.uniform(*FieldMonsterSettings.WAIT_RANGE)
            steps = [random.choice(((1, 0), (-1, 0), (0, 1), (0, -1)))]
        for dx, dy in steps:
            if self._try_step(dx, dy, world, taken):
                return

    def _chase_steps(self, player: tuple[int, int] | None) -> list[tuple[int, int]]:
        """The steps toward the player, the longer way first; none if far, or a boss."""
        if player is None or self.spot.get("boss"):
            return []
        # Distance to the nearest of its tiles, so a big monster chases from its edge.
        near = min(self.tiles(), key=lambda t: abs(t[0] - player[0]) + abs(t[1] - player[1]))
        dx, dy = player[0] - near[0], player[1] - near[1]
        if abs(dx) + abs(dy) > FieldMonsterSettings.CHASE_TILES:
            return []
        across = [((dx > 0) - (dx < 0), 0)] if dx else []
        down = [(0, (dy > 0) - (dy < 0))] if dy else []
        return across + down if abs(dx) >= abs(dy) else down + across

    def _try_step(self, dx: int, dy: int, world: "World", taken: set[tuple[int, int]]) -> bool:
        """Start a slide one tile that way, if every tile it would cover is free."""
        moved = {(c + dx, r + dy) for c, r in self.tiles()}
        for c, r in moved:
            inside = 0 <= c < OverworldSettings.COLS and 0 <= r < OverworldSettings.ROWS
            if not inside or world.is_wall(c, r) or (c, r) in taken:
                return False
        if dx:
            self.facing_left = dx < 0
        self._from = (self.col, self.row)
        self.col, self.row = self.col + dx, self.row + dy
        self._progress = 0.0
        return True

    def render(self, surface: pygame.Surface) -> None:
        """Draw the monster on its tiles, part way along a slide; a coloured square without art."""
        tile = GridSettings.TILE_SIZE
        t = self._progress
        x = OverworldSettings.X + round((self._from[0] + (self.col - self._from[0]) * t) * tile)
        y = OverworldSettings.Y + round((self._from[1] + (self.row - self._from[1]) * t) * tile)
        frames = _frames(self.kind)
        if not frames:
            pygame.draw.rect(
                surface, FieldMonsterSettings.COLOR, (x, y, tile * self.width, tile * self.height)
            )
            return
        # The feet move while it slides; standing, it holds the first frame.
        frame = frames[int(t * len(frames)) % len(frames) if t < 1.0 else 0]
        if self.facing_left:
            frame = pygame.transform.flip(frame, True, False)
        # Centred across its tiles, its bottom on their bottom.
        left = x + (tile * self.width - frame.get_width()) // 2
        surface.blit(frame, (left, y + tile * self.height - frame.get_height()))
