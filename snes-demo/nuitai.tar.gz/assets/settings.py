import os
import sys

from core.shared import SHARED, SHARED_DIR

# Battle numbers shared with the browser game. See ``core/shared.py``.
_RULES = SHARED["rules"]
_STATS = SHARED["stats"]


class ColorSettings:
    """Class to hold all the color settings for the game."""
    BLACK = (0, 0, 0)
    NERO = (30, 30, 30)
    GRAY = (120, 120, 120)
    DARK_GRAY = (60, 60, 60)
    WHITE = (255, 255, 255)
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    BLUE = (0, 0, 255)
    YELLOW = (255, 220, 0)
    # The MUTE mark in the top right corner while the sound is off (M key).
    MUTE_MARK = (60, 230, 90)
    # Enemy names in the battle turn-order strip, so the two sides can
    # be told apart at a glance without reading.
    FOE_NAME = (240, 170, 150)

    BG_COLOR = NERO
    OVERLAY_BACKGROUND = BLACK
    # The Equip screen, Final Fantasy VI's (Frankie, 10/24): cyan slot and
    # stat names, a stat that would rise in yellow, one that would drop in
    # red, and the green arrows beside the element icons.
    LABEL_CYAN = (110, 220, 230)
    STAT_DROP = (255, 90, 90)
    ELEMENT_ARROW = (60, 230, 90)

    # Overworld tile placeholder colors. Replaced by tile sprite blits
    # in Pass 2 once we have real art chosen for Nuitai's island
    # setting. Until then these are how the cell area visually
    # distinguishes one terrain type from another.
    OVERWORLD_FLOOR = (110, 160, 90)    # grass green; walkable
    OVERWORLD_WALL = (90, 70, 60)       # rocky brown; impassable
    OVERWORLD_WATER = (60, 130, 180)    # ocean blue; impassable
    OVERWORLD_SAND = (220, 200, 140)    # sandy beige; walkable

    # Per-element accent colors. Used by menus / UI labels to flag the
    # affinity of an ability or item at a glance. Tuned for readability
    # on the black command-panel background -- fire and water are *lighter*
    # than the pure RED/BLUE constants above. Shadow's entry is the lore
    # color (black); rendering it readably is the job of
    # ``ELEMENT_TEXT_STYLES`` below, which pairs the black body with a
    # white halo so the glyph survives any backdrop.
    # D-366, set B: fire red, plant green, water turquoise, light gold,
    # shadow purple, spirit blue, each lightened enough to read on black
    # (10/18: Tawiri's black shadow moves were hard to see).
    ELEMENT_COLORS: dict = {
        "afi":  (240, 110, 95),   # red
        "wai":  (60, 200, 220),   # turquoise
        "lau":  (140, 205, 90),   # green
        "mana": (160, 190, 255),  # blue, light enough to read on the blue windows (10/18)
        "la":   (242, 194, 48),   # gold
        "ata":  (190, 120, 230),  # purple
    }

    # Per-element TEXT style. Anywhere the UI renders an element name
    # (element-pair lines on combatant cards, ability-row labels in the
    # battle command menu) reads its render kwargs from here and splats
    # them into ``text_renderer.draw_text``.
    #
    # SHIPPED RECIPE: every element gets the same white halo at radius
    # 3, alpha 90 -- the same recipe shadow originally needed so its lore-
    # black body would survive a dark background. Applying it to all
    # six keeps the screen visually balanced; without the halo the
    # other five read flat next to a halo'd shadow. Shadow's body stays
    # black; everyone else keeps their accent fill.
    #
    # Alternatives we considered (preserved as runnable recipes in
    # ``visual_test_text.py``):
    #   universal soft white: glow=WHITE,  r=2, a=70  (toned down)
    #   self-color soft:      glow=fill,   r=2, a=60  (own-color bloom)
    #   self-color parity:    glow=fill,   r=3, a=90  (own-color at shadow intensity)
    #   brighter self-color:  glow=lighter, r=2, a=80 ("flame edge" -- per-element lighter halo)
    # Re-run ``python visual_test_text.py`` to compare again.
    _TEXT_HALO_WHITE = {
        "glow": (255, 255, 255),
        "glow_radius": 1,
        "glow_alpha": 90,
    }
    # The white halo every element word had before 10/22, kept for the stats' words.
    _HALO_STYLES: dict = {
        "afi":  {"color": ELEMENT_COLORS["afi"],  **_TEXT_HALO_WHITE},
        "wai":  {"color": ELEMENT_COLORS["wai"],  **_TEXT_HALO_WHITE},
        "lau":  {"color": ELEMENT_COLORS["lau"],  **_TEXT_HALO_WHITE},
        "mana": {"color": ELEMENT_COLORS["mana"], **_TEXT_HALO_WHITE},
        "la":   {"color": ELEMENT_COLORS["la"],   **_TEXT_HALO_WHITE},
        "ata":  {"color": ELEMENT_COLORS["ata"],  **_TEXT_HALO_WHITE},
    }
    # Element words (moves, stances) have a thick black edge, every element
    # alike, because it reads best on the blue windows; shadow's words are
    # white and spirit's purple, since purple shadow and blue spirit were hard
    # to read (Frankie, 10/22). The cartridge draws the same edge on its
    # third background layer (game/snes/src/edge.h).
    _TEXT_EDGE_BLACK = {
        "glow": (0, 0, 0),
        "glow_radius": 2,
        "glow_alpha": 255,
    }
    # A move's element tag on the ELEMENT grid (ui/element_tag.py, Frankie
    # 10/23): each element's color as its words show it, but Shadow black,
    # which reads on the ocean blue. A dual move's two colors meet with no
    # line between them (Frankie tried white and black and liked neither).
    TAG_COLORS: dict = {
        "afi": ELEMENT_COLORS["afi"], "wai": ELEMENT_COLORS["wai"], "lau": ELEMENT_COLORS["lau"],
        "mana": ELEMENT_COLORS["ata"], "la": ELEMENT_COLORS["la"], "ata": (0, 0, 0),
    }

    ELEMENT_TEXT_STYLES: dict = {
        "afi":  {"color": ELEMENT_COLORS["afi"],  **_TEXT_EDGE_BLACK},
        "wai":  {"color": ELEMENT_COLORS["wai"],  **_TEXT_EDGE_BLACK},
        "lau":  {"color": ELEMENT_COLORS["lau"],  **_TEXT_EDGE_BLACK},
        "mana": {"color": ELEMENT_COLORS["ata"],  **_TEXT_EDGE_BLACK},
        "la":   {"color": ELEMENT_COLORS["la"],   **_TEXT_EDGE_BLACK},
        "ata":  {"color": (255, 255, 255),        **_TEXT_EDGE_BLACK},
    }

    # The stats' colours (D-503 to D-505), by stat key: their elements', with
    # Agility orange and Willpower pink. Not on the status screen, which is
    # white (D-506); kept for the "strength went up!" lines and dialogue.
    STAT_TEXT_STYLES: dict = {
        "hp": _HALO_STYLES["lau"],
        "strength": _HALO_STYLES["afi"],
        "magic": _HALO_STYLES["mana"],
        "vitality": _HALO_STYLES["wai"],
        "spirit": {"color": (245, 130, 190), **_TEXT_HALO_WHITE},
        "speed": {"color": (255, 160, 70), **_TEXT_HALO_WHITE},
        "accuracy": _HALO_STYLES["la"],
        "evasion": _HALO_STYLES["ata"],
    }


class BackgroundSettings:
    """Named scene-background templates and per-scene assignments."""

    SOLID = "solid"
    GRADIENT = "gradient"
    IMAGE = "image"
    # Battle backgrounds: Pixel-boy's battlebacks, CC0 (assets/graphics/backgrounds/battle/README.md).
    BATTLE_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'backgrounds', 'battle'
    )

    TEMPLATES: dict = {
        "ocean": (GRADIENT, (60, 180, 210), (10, 30, 70)),
        "midnight": (GRADIENT, (20, 20, 60), (0, 0, 0)),
        "dusk": (GRADIENT, (120, 60, 100), (20, 10, 40)),
        "ember": (GRADIENT, (200, 80, 30), (60, 10, 10)),
        "nero": (SOLID, (30, 30, 30)),
        # Behind a fight: dusk sky down into dark ground.
        "battlefield": (GRADIENT, (36, 58, 78), (16, 30, 26)),
        # Behind a fight in town: the tropical beach (Frankie, 10/18); anywhere
        # else, the jungle (Frankie, 10/23).
        "beach": (IMAGE, os.path.join(BATTLE_DIR, "3.png")),
        "jungle": (IMAGE, os.path.join(BATTLE_DIR, "6.png")),
        "black": (SOLID, (0, 0, 0)),
    }

    # The town's rooms, where a fight stands on the beach.
    TOWN_ROOMS: tuple = ("kailo_yard", "beach_west", "beach_east", "pono_yard")

    SCENE_BACKGROUNDS: dict = {
        "TitleScene": "ocean",
        "BattleScene": "beach",
        "MenuScene": "nero",
        "OverworldScene": "nero",
    }

    DEFAULT_TEMPLATE: str = "nero"


class ScreenSettings:
    """The screen is a Super Nintendo screen (D-158): 256 by 224 pixels.

    Every scene draws onto a surface this size. ``main.py`` then enlarges
    it by a whole number, the scale, to fill the window, so one game
    pixel is always the same square of screen pixels and nothing is ever
    smoothed. The window takes the largest whole number that fits the
    desktop; fullscreen does the same and leaves black bars around it.
    Every position in this file is on the 256 by 224 screen.
    """

    # True when running in a browser, built by pygbag (tools/web_build.py).
    # The page scales the canvas itself, so the game draws at WEB_SCALE.
    WEB = sys.platform == "emscripten"
    WEB_SCALE = 3
    WIDTH = 256
    HEIGHT = 224
    RESOLUTION = (WIDTH, HEIGHT)
    FPS = 60
    # Room the window leaves for the title bar and the taskbar when it
    # picks its scale, in desktop pixels.
    WINDOW_MARGIN_W = 64
    WINDOW_MARGIN_H = 120
    CRT_ALPHA_RANGE = (75, 90)
    WINDOW_TITLE = "Nuitai RPG"
    TITLE_SCREEN_HEADING = "Nuitai"


class InputSettings:
    """Controller button and axis mappings used by gameplay and menus."""

    # The face buttons by position, named as on a Super Nintendo pad whatever
    # the pad prints (Frankie, 10/24). The numbers are SDL's, which are by
    # position too: 0 south, 1 east, 2 west, 3 north. So on an Xbox or
    # Logitech pad, A here is the button printed B.
    JOY_BUTTON_B = 0  # south
    JOY_BUTTON_A = 1  # east
    JOY_BUTTON_Y = 2  # west
    JOY_BUTTON_X = 3  # north
    JOY_BUTTON_L1 = 4
    JOY_BUTTON_R1 = 5
    JOY_BUTTON_BACK = 6
    JOY_BUTTON_START = 7
    # Held together: a soft reset to the title, every build (Frankie, 10/23).
    JOY_BUTTON_RESET_COMBO = (7, 6, 4, 5)

    JOY_AXIS_LEFT_X = 0
    JOY_AXIS_LEFT_Y = 1
    JOY_AXIS_L2 = 4
    JOY_AXIS_R2 = 5
    JOY_TRIGGER_THRESHOLD = 0.5


class FontSettings:
    """The one font, and the pixel grid its text sits on.

    Press Start 2P draws every letter in an 8 by 8 cell at size 8, one
    font pixel per screen pixel, so 8 is the size of all text, 16 the
    heading size and 24 the title's; any other size blurs the pixels.
    Thirty-two letters fit across the screen (D-445). Text sits on rows
    ``LINE_HEIGHT`` apart, two 8 pixel cells, as the Super Nintendo
    games spaced their lines; a heading takes two rows.
    ``ui/text_renderer`` places text by the top of its capital letters,
    so a position here is where the letters start.
    """

    FONT = os.path.join(
        os.path.dirname(__file__), 'assets', 'font', 'PressStart2P-Regular.ttf'
    )

    SIZE_SMALL = 8
    SIZE_BODY = 8
    SIZE_HEADING = 16
    SIZE_TITLE_SCREEN_HEADING = 24
    LINE_HEIGHT = 16
    # Every letter is this wide, so a line holds its width // 8 letters.
    LETTER_WIDTH = 8


class AudioSettings:
    """Global audio toggles, mixer-level defaults, and the sound/music registry."""

    MUTE = False
    MUTE_MUSIC = False
    MUSIC_VOLUME = 1.0
    SFX_VOLUME = 1.0

    SOUND_EFFECTS: dict = {
        "menu_move": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_move2.ogg'
        ),
        "menu_select": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_select3.ogg'
        ),
        # A chest opening: Leohpaz's Minifantasy Dungeon SFX (Frankie, 10/24).
        "chest_open": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_chest_open.ogg'
        ),
        # Only sounds a Super Nintendo could hold (Frankie, 10/23): a jingle,
        # such as the lontar's, comes back as music made from MIDI.
    }

    # How a blow lands (D-151), shared with the browser battle: one take
    # of each, the browser's three being too much for the Super Nintendo's
    # sound memory (Frankie, 10/23). "hit_punch" for a physical blow,
    # "hit_magic" for a spell, "hit_sparkle" for healing, "hit_miss"
    # for a dodge or a miss.
    HIT_SOUNDS: tuple = ("hit_punch", "hit_magic", "hit_sparkle", "hit_miss")
    HIT_TAKES = 1
    for _kind in HIT_SOUNDS:
        for _take in range(1, HIT_TAKES + 1):
            SOUND_EFFECTS[f"{_kind}_{_take}"] = os.path.join(
                SHARED_DIR, 'sounds',
                # The browser build carries them as OGG (tools/web_build.py).
                f'{_kind}_{_take}.ogg' if sys.platform == "emscripten" else f'{_kind}_{_take}.mp3'
            )
    del _kind, _take

    SFX_FILE_VOLUMES: dict = {
        os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_move2.ogg'
        ): 0.2,
        os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_select3.ogg'
        ): 0.2,
    }

    MUSIC_TRACKS: list = []

    # Songs by screen. Only music made from MIDI, which a Super Nintendo
    # can hold (Frankie, 10/23): Frankie's own pieces as tracker modules in
    # game/shared/music/snes/, the same files the cartridge plays
    # (tools/music/midi_to_it.py). The title plays his Main Theme; the
    # town, its buildings too, its surf alone, always (Frankie, 10/24); at
    # night every room past the town is quiet; by day Potions, Poisons and Forest Mushrooms in the woods; The Big Bad in the
    # Great Boar's room while he is there; Spiny Shell in every fight;
    # Regrets at Pono's wake (Frankie, 10/23).
    # SCREEN_MUSIC is which songs each screen picks from, SONG_LOOPS each
    # song's loop start and length in seconds; a song without loops repeats
    # whole. A screen with no songs is quiet.
    MUSIC_DIR = os.path.join(SHARED_DIR, 'music')
    SCREEN_MUSIC: dict = {"title": [os.path.join('snes', 'main-theme.it')],
                          "beach": [os.path.join('snes', 'waves.it')],
                          "woods": [os.path.join('snes', 'potions-poisons-and-forest-mushrooms.it')],
                          "great_boar": [os.path.join('snes', 'the-big-bad.it')],
                          "wake": [os.path.join('snes', 'regrets.it')],
                          "battle": [os.path.join('snes', 'spiny-shell.it')],
                          "boss": [os.path.join('snes', 'spiny-shell.it')]}
    # The town's rooms: they and the buildings in them play "beach"; at night everything
    # else is quiet; by day the Great Boar's room plays "great_boar", the rest "woods".
    BEACH_ROOMS: tuple = ("kailo_yard", "beach_west", "beach_east", "pono_yard")
    SONG_LOOPS: dict = {}

    @staticmethod
    def music_file(name: str) -> str:
        """A song's file name: the browser build carries them as OGG (tools/web_build.py)."""
        return os.path.splitext(name)[0] + '.ogg' if sys.platform == "emscripten" else name

    MUSIC_FILE_VOLUMES: dict = {}


class AssetPaths:
    """Class to hold all the file paths for assets."""
    # The title's dawn: the logo, the spiral, the sun, the specks, the waves (tools/draw_title_art.py).
    TITLE_DIR = os.path.join(os.path.dirname(__file__), 'assets', 'graphics', 'title')
    TV = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'effects', 'tv.png'
    )
    MENU_MOVE_SOUND = os.path.join(
        os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_move2.ogg'
    )
    MENU_SELECT_SOUND = os.path.join(
        os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_select3.ogg'
    )
    # Per-character portrait sprites used in the party / status screens.
    # Files are named ``<member_id>_portrait.png`` and live in
    # ``assets/graphics/portraits/``; ``unknown_portrait.png`` is the
    # placeholder used when a member-specific portrait hasn't been drawn
    # yet.
    PORTRAITS_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'portraits'
    )
    UNKNOWN_PORTRAIT = os.path.join(
        os.path.dirname(__file__),
        'assets', 'graphics', 'portraits', 'unknown_portrait.png',
    )
    # Per-element 16x16 affinity icons (e.g. a flame for ``afi``, a wave
    # for ``wai``) used by the roster element lines on the party screen
    # and in battle. Files are named ``<element_id>.png`` -- if a file
    # for a given element does not exist, the renderer falls back to the
    # element word so partial coverage is fine while art lands.
    ICONS_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'icons'
    )
    # Monster battle pictures, one still image each, named
    # ``<sprite>.png``. An enemy in the shared battle file names its
    # picture with ``"sprite"``. A monster with no file gets a plain
    # box, so a missing picture never stops a fight.
    MONSTERS_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'monsters'
    )
    # Map tiles: Mini World Sprites by Merchant Shade, CC0, unedited, in
    # miniworld/; the insides' walls and mats from Ninja Adventure, CC0, in
    # interior/.
    TILES_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'tiles'
    )
    # The walking sprite sheet, a Ninja Adventure walk sheet: one column
    # per facing (down, up, left, right), four 16 by 16 frames down each
    # (D-573).
    PLAYER_SHEET = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'player', 'kailo.png'
    )
    # The people standing on the map, Ninja Adventure walk sheets laid
    # out like ``PLAYER_SHEET``, as ``<Name>-Walk.png``.
    PEOPLE_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'characters', 'ninja'
    )
    # The town's buildings and dressing (``OverworldSettings.BUILDINGS``),
    # cut from Ninja Adventure's TilesetHouse.png (CC0).
    BUILDINGS_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'buildings'
    )


class BattleStageSettings:
    """Where fighters stand in a battle and how they move.

    Positions are in screen pixels on the 256 by 224 screen. Times are
    in seconds. See ``ui/battle_stage.py``. From the top: the turn strip
    and the help line (two rows), the monsters standing on ``GROUND_Y``
    with their statuses under each, then the 80 pixel HUD, whose right
    panel lists the party.
    """

    # --- Monsters ---------------------------------------------------
    # Every monster picture is drawn at its own size (D-577).
    # The line the monsters stand on.
    GROUND_Y = 104
    # The box drawn for a monster that has no picture.
    PLACEHOLDER_SIZE = 32
    COLOR_PLACEHOLDER = (70, 70, 80, 255)
    SHADOW_WIDTH_SHARE = 0.8   # Of the picture's width.
    SHADOW_HEIGHT = 6
    SHADOW_ALPHA = 90
    # How far a monster's feet sink below the ground line, into its shadow.
    FEET_SINK = 1
    # Room between neighbouring monsters, picture edge to picture edge.
    MONSTER_GAP = 8
    # Statuses shown on a monster's picture, not in words (D-487).
    # Poison: the picture multiplied by one colour, then the other added.
    POISON_MULTIPLY = (140, 230, 120)
    POISON_ADD = (0, 40, 0)
    # Sleep: Zs drifting up from the head, one cycle per 1 / speed seconds.
    COLOR_SLEEP_Z = (235, 235, 255)
    COLOR_SLEEP_Z_EDGE = (20, 24, 60)
    SLEEP_Z_SPEED = 0.6
    SLEEP_Z_RISE = 4
    # Blind: sunglasses on the eyes. Each eye spot is a share of the
    # picture's width and height; a monster without one wears them over
    # its head until its spot is marked.
    EYES = {
        "boar": (0.71, 0.51),
    }

    # --- Party rows -------------------------------------------------
    # The party is listed in the HUD's right panel, Final Fantasy style:
    # one row each, the first name, the HP bar and the HP, 16 pixels
    # apart. A name with a status on it turns ``COLOR_STATUS``.
    PARTY_ROW_X = 131          # The element icons start here, past the divider.
    # The two element icons before each name, shrunk to 8 by 8, the
    # stance's boxed in yellow (D-453).
    PARTY_ICON_SIZE = 8
    PARTY_ICON_PITCH = 10      # One icon's box to the next.
    PARTY_NAME_DX = 22         # Row start to the name, past the icons.
    PARTY_ROW_TOP_Y = 163      # Centres the three rows in the HUD (Frankie, 10/18).
    PARTY_ROW_PITCH = 16
    PARTY_NAME_CHARS = 6       # A longer first name is cut.
    PARTY_BAR_DX = 72          # Row start to the bar.
    PARTY_FIGURES_DX = 98      # Row start to the HP figure.

    # --- Turn order ---------------------------------------------------
    # One bordered bar down the left of the field (D-453), Final Fantasy X
    # style: a small picture per turn, the one acting on top with a
    # yellow arrow over it, a stripe on each entry's left, blue for the
    # party and red for monsters. The monsters stand to its right.
    TURN_ICON_SIZE = 16
    TURN_STRIPE = 3            # The side's colour, left of each picture.
    TURN_BAR_X = 1
    TURN_BAR_Y = 2
    TURN_ARROW = 4             # The arrow's half height.
    FIELD_LEFT = 24            # The field's left edge, past the bar.
    COLOR_TURN_PARTY = (80, 130, 230)
    COLOR_TURN_FOE = (210, 80, 70)
    COLOR_TURN_MARKER = (24, 28, 44)   # Behind a monster's turn-order marker.
    PARTY_HOP_PIXELS = 2       # A row hops this far up when its member acts.
    COLOR_HURT_NAME = (255, 90, 80)    # The name while its member is hit.

    # --- Mana --------------------------------------------------------
    # Seven pips under each HP bar, lit for each point of mana
    # (D-213 to D-220), in spirit's blue (D-366).
    PIP_WIDTH = 2
    PIP_HEIGHT = 2
    PIP_GAP = 1
    PARTY_PIPS_DY = 8          # Row top to the pips, under the bar.
    COLOR_MANA = (80, 150, 255)
    COLOR_PIP_OFF = (45, 45, 60)
    # The stroke points left this turn, in the command panel's top right.
    COLOR_POINTS = (255, 130, 130)

    # --- HP bars ----------------------------------------------------
    BAR_WIDTH = 24
    BAR_HEIGHT = 4
    BAR_TEXT_GAP = 4
    BAR_LOW_SHARE = 0.35       # Below this the bar is red.
    BAR_SPEED = 1.5            # Bars slide at this many full bars a second.
    COLOR_BAR = (90, 210, 120)
    COLOR_BAR_LOW = (230, 70, 60)
    COLOR_BAR_BACK = (20, 20, 20)

    # --- Motion -----------------------------------------------------
    SHAKE_SECONDS = 0.35
    SHAKE_PIXELS = 3
    SHAKE_SPEED = 55.0         # How fast the jolt swings side to side.
    FLASH_SECONDS = 0.24
    FLASH_BLINK_HZ = 12.0
    LUNGE_SECONDS = 0.28
    LUNGE_PIXELS = 8           # A monster steps this far toward you.
    FADE_SECONDS = 0.6         # A defeated monster takes this long to go.
    FADE_SINK_PIXELS = 4
    BOB_PIXELS = 1             # Idle sway, so nothing stands dead still.
    BOB_SPEED = 2.6
    BOB_PHASE_STEP = 1.7       # Keeps neighbours from swaying in step.

    # --- Floating numbers -------------------------------------------
    FLOAT_SECONDS = 1.0
    FLOAT_RISE_PIXELS = 16
    FLOAT_FADE_SHARE = 0.3     # The last part of its life spent fading.
    FLOAT_SPRITE_HEIGHT = 0.95 # Starts this far up a monster picture.
    FLOAT_PARTY_RISE_START = 2
    # A party member's number rises only this much, so it stays on its own
    # row of the fight box, over the HP bar (Claude's call, 10/25).
    FLOAT_PARTY_RISE_PIXELS = 4
    FLOAT_STACK_STEP = 8       # A second number starts this much higher.
    FLOAT_STACK_WINDOW = 0.5
    COLOR_PARTY_DAMAGE = (255, 120, 110)
    COLOR_HEAL = (120, 230, 140)
    COLOR_STATUS = (200, 150, 245)
    # Shadow's own color is black, which vanishes on a dark field.
    COLOR_ATA_WORD = (190, 190, 200)

    # --- Target arrow -----------------------------------------------
    CURSOR_SIZE = 4
    CURSOR_GAP = 2


class BestiarySettings:
    """Layout of the bestiary, one creature per page, in screen pixels.

    The name and the page count on the top row, the picture under them,
    a row of facts, then a block of text rows (the description, where
    it is found, its moves) that scrolls when it is longer than the
    block. Left and right turn the page; up and down scroll.
    """

    NAME_POS = (8, 8)
    COUNT_RIGHT_X = 248        # The "3/8" ends here.
    PICTURE_CENTER_X = 128
    PICTURE_GROUND_Y = 100     # The picture's feet.
    FACTS_Y = 112              # On the 8 pixel text grid, as the cartridge's is (10/22).
    FACT_GAP = 8               # Between one fact and the next on the row.
    PANEL_X = 8
    PANEL_WIDTH = 240          # 30 letters.
    TEXT_TOP_Y = 128
    TEXT_ROWS = 5              # Rows of the scrolling block.
    SCROLL_MARK_X = 248        # The flashing arrows saying there is more (ui/scroll_mark.py).
    COLOR_BODY_TEXT = (215, 215, 215)
    COLOR_BEAST = (200, 170, 120)
    COLOR_ATA_WORD = (190, 190, 200)


class DebugSettings:
    """Settings related to debugging features."""


class SaveSettings:
    """Save-system tunables."""

    SAVES_DIR = os.path.join(os.path.dirname(__file__), 'saves')
    MAX_SAVE_SLOTS = 3
    AUTOSAVE_SLOT_ID = 0


class StatSettings:
    """How elements turn into stats. See ``core/stats.py``.

    The values come from the shared battle file, so they are the same
    in the browser game. Every number is a placeholder; the shape
    (elements decide stats) is the ruling.
    """

    BASE_POINTS = _STATS["base"]                # Every stat starts here.
    ELEMENT_MULTIPLIER = _STATS["element_multiplier"]  # Each element, on its two job stats.
    STANCE_MULTIPLIER = _STATS["stance_multiplier"]    # The stance in play, on its element's two.
    HP_PER_POINT = _STATS["hp_per_point"]       # Max HP is the HP score x this.


class LoadoutSettings:
    """Ability slots (D-318 to D-320): three per mana row, seven rows.

    The numbers are the shared file's ``rules.slots``.
    """

    PER_ROW = _RULES["slots"]["per_tier"]
    ROWS = _RULES["slots"]["tiers"]
    TURNS_PER_ROW = _RULES["slots"]["turns_per_tier"]
    GIFT_PER_ROW = _RULES["slots"]["gift_per_tier"]
    SHELL_PER_ROW = _RULES["slots"]["shell_per_tier"]


class BattleSettings:
    """Gameplay tunables for battles.

    Everything read from ``_RULES`` comes from the shared battle file
    and so is the same number in the browser game; change it there.
    The plain literals below are this game's alone.

    Waits are in turn-counter units: after acting, a combatant's
    counter goes up by the wait, and the lowest counter acts next.
    """

    # This game only: the browser test fills its own pockets. Noni, the
    # island's plant medicine, heals in the Potion's place (Frankie, 10/23).
    STARTING_NONI = 5
    NONI_HEAL_AMOUNT = 30  # Frankie, 10/23 (was 35)
    # 'Awa heals more than Noni, as much as the browser's old Hi-Potion
    # (Claude's number, 10/23).
    AWA_HEAL_AMOUNT = 80
    # What a beaten monster drops (D-524), placeholders: pule by its
    # max HP, and the chance it leaves the item it carries (a boss
    # always does).
    DROP_PULE_PER_HP = 0.1
    DROP_ITEM_CHANCE = 0.3

    # The plain Attack, and Kailo's counter kick.
    ATTACK_POWER = _RULES["attack_power"]
    # Damage rolls within +/- this fraction.
    DAMAGE_JITTER = _RULES["damage_jitter"]

    # Physical damage taken while defending.
    DEFEND_MULTIPLIER = _RULES["defend_multiplier"]
    # Physical damage a guard takes for an ally, then the extra factor
    # when the guarded hit is fire, and when it is nature.
    GUARD_MULTIPLIER = _RULES["guard_multiplier"]
    GUARD_AFI_MULTIPLIER = _RULES["guard_afi_multiplier"]
    GUARD_LAU_MULTIPLIER = _RULES["guard_lau_multiplier"]

    STATUS_HIT_CHANCE = _RULES["status_hit_chance"]    # A status takes hold.
    BLIND_MISS_CHANCE = _RULES["blind_miss_chance"]    # A blind physical hit misses.
    SLEEP_TURNS = _RULES["sleep_turns"]                # Turns a sleeper loses.
    POISON_RATE = _RULES["poison_rate"]                # Share of max HP per turn.
    HASTE_ACTIONS = _RULES["haste_actions"]            # Actions at a shorter wait.
    HASTE_WAIT_MULTIPLIER = _RULES["haste_wait_multiplier"]
    REGEN_TURNS = _RULES["regen_turns"]                # Turns Regen heals for.
    REGEN_RATE = _RULES["regen_rate"]                  # Share of max HP a Regen turn heals.
    POSSESS_TURNS = _RULES["possess_turns"]            # Turns Possess lasts (D-547).
    POSSESS_CHANCE = _RULES["possess_chance"]          # Chance a possessed monster turns on its side.
    SULK_TURNS = _RULES["sulk_turns"]                  # Turns a sulk lasts (Frankie, 10/25).
    # Tawiri's Call (Frankie, 10/25): the spirit's turns, and its share of her max HP and points.
    CALL_TURNS = _RULES["call_turns"]
    CALL_HP = _RULES["call_hp"]
    CALL_STATS = _RULES["call_stats"]
    # Kailo's Cook (Frankie, 10/25): the meal's share of max HP (and the most extra HP
    # past full), what the cure takes away, the dishes' names.
    COOK_HEAL = _RULES["cook_heal"]
    COOK_CURES = tuple(_RULES["cook_cures"])
    COOK_DISHES = _RULES["cook_dishes"]
    CHARM_TURNS = _RULES["charm_turns"]                # Turns Maika's Charm lasts (Frankie, 10/25).
    # How likely Scold and Charm take hold by Willpower, at least and at most (Frankie, 10/25).
    WILL_LEAST = _RULES["will_least"]
    WILL_MOST = _RULES["will_most"]
    BUFF_TURNS = _RULES["buff_turns"]                  # Turns a monster's Protect or Shell lasts.
    PROTECT_MULTIPLIER = _RULES["protect_multiplier"]  # Physical damage taken under Protect.
    SHELL_MULTIPLIER = _RULES["shell_multiplier"]      # Magic damage taken under Shell.
    FOE_STANCE_CHANCE = _RULES["foe_stance_chance"]    # A two-stance monster with no reasons switches (D-596).

    # Mana (D-213 to D-220) and fatigue (D-328, D-329), as the browser
    # battle plays them: every number is in the shared file's
    # ``rules.warmup``. Mana is a meter of up to 7. An Attack is a chain
    # of strokes on one enemy, up to 7 points a turn; a stroke that
    # lands builds its points in mana. A technique costs its ``warmup``
    # in mana. The wait after a turn is what the turn built: each
    # stroke its points, a TECH 7, anything else 1, Defend 1 less.
    _WARM = _RULES["warmup"]
    MANA_CAP = _WARM["cap"]
    MANA_START = _WARM["start"]
    DEFEND_MANA = _WARM["defend"]          # Mana Defend builds.
    STANCE_MANA = _WARM["form"]            # Mana a stance switch builds (D-285).
    TECH_MANA = _WARM["tech"]              # Mana a TECH builds (Frankie, 10/24).
    FIGHTERS = 3                           # The rest of the party waits on the bench (D-196).
    COMBO_MANA = _WARM["combo"]            # Mana a combo takes from each partner.
    WEAPON_MANA = 1                        # Mana changing weapons builds (D-455).
    # Escape (D-455): this chance, moved by the runner's Speed against the
    # fastest monster's, kept between the two limits. Claude's numbers.
    ESCAPE_CHANCE = 0.5
    ESCAPE_PER_SPEED = 0.05
    ESCAPE_LIMITS = (0.1, 0.9)
    DODGE_MANA = _WARM["dodge_gain"]       # Mana for dodging or blocking a blow.
    STROKE_POINTS = _WARM["strokes"]["points"]
    STROKE_STEADY = _WARM["strokes"]["steady"]   # Each stroke landed adds this to the next one's chance.
    STROKES: dict = {
        "light": _WARM["strokes"]["light"],
        "medium": _WARM["strokes"]["medium"],
        "strong": _WARM["strokes"]["strong"],
    }
    AUTO_STROKES: tuple = tuple(_WARM["strokes"]["auto"])  # A monster's chain.
    STROKE_POWER = _WARM["attack_power"]   # Times a stroke's own power.
    STROKE_WAIT = _WARM["wait"]["attack"]  # Fatigue per stroke point.
    FATIGUE_OTHER = _WARM["fatigue"]["other"]
    FATIGUE_TECH = _WARM["fatigue"]["tech"]  # A TECH's wait, a full Attack's (Frankie, 10/24).
    FATIGUE_DEFEND = _WARM["fatigue"]["defend"]
    FATIGUE_LEAST = _WARM["fatigue"]["least"]
    FATIGUE_DEFEND_LEAST = _WARM["fatigue"]["defend_least"]
    # Accuracy and Evasion: 1% a point over the base of 10. Vitality
    # blocks a blow for half damage.
    PER_ACCURACY = _WARM["accuracy"]["per_accuracy"]
    EVADE_BASE = _WARM["evade"]["base"]
    PER_EVASION = _WARM["evade"]["per_evasion"]
    BLOCK_BASE = _WARM["block"]["base"]
    PER_VITALITY = _WARM["block"]["per_vitality"]
    BLOCK_MULTIPLIER = _WARM["block"]["multiplier"]
    # The turn-order preview's guess at everyone else's next wait.
    PREVIEW_WAIT = 3


    TURN_ORDER_LENGTH = 7         # Upcoming turns shown after the current one.
    # Seconds a finished line of battle narration stays up before the
    # scene advances it on its own. Confirm still advances at once.
    NARRATION_HOLD_SECONDS = 0.9
    # Seconds between one stroke and the next as they play out. Strokes
    # have no line of their own, so this is their rhythm.
    STROKE_BEAT_SECONDS = 0.3


class UISettings:
    """Tunables for in-game UI presentation, on the 256 by 224 screen."""

    # The bar along the top for "went up!" lines (D-526): seconds each
    # line stays, and where it draws, right of the turn order.
    NOTICE_SECONDS = 2.5
    NOTICE_RECT = (28, 4, 224, 20)

    # The message window and the battle HUD: the bottom 80 pixels, five
    # map tiles tall. Eight pixels of padding leaves four rows of text.
    TEXT_BOX_HEIGHT = 80
    TEXT_BOX_PADDING = 8
    TEXT_BOX_BORDER_THICKNESS = 2
    # Every window's corners are rounded this many pixels (D-457).
    WINDOW_CORNER_RADIUS = 4
    # A window's inside shades from the first colour at the top to the
    # second at the bottom: deep ocean, not black (D-451). Claude's pick.
    WINDOW_TOP = (28, 74, 120)
    WINDOW_BOTTOM = (8, 26, 58)
    # The top of a screen the field menu opens, Final Fantasy VI's (Frankie,
    # 10/23): a small box with the screen's name, a help line under it for
    # what the cursor is on (two rows of text), and the list from
    # HEADER_LIST_TOP down. Every edge and word on the 8 pixel grid, so the
    # cartridge draws them in the same places.
    HEADER_LABEL_RECT = (0, 0, 88, 24)
    HEADER_HELP_RECT = (0, 24, 256, 40)
    HEADER_TEXT_X = 16
    HEADER_LIST_TOP = 72

    # Portraits are pixel faces in a ``PORTRAIT_SIZE`` frame, three tiles
    # square (D-449), on the party screen. A smaller face sits centred
    # in the frame, unscaled, until it is redrawn; a bigger one is cut
    # to the frame's middle. Nothing is ever resized. ``PORTRAIT_GAP``
    # is the space between the frame's right edge and the text beside
    # it. Text is placed by the top of its letters, so the frame and the
    # name share a top edge with no nudge.
    PORTRAIT_SIZE = 48
    PORTRAIT_GAP = 8
    PORTRAIT_Y_OFFSET = 0
    # The element line sits one text row under the name.
    ROSTER_ELEMENT_LINE_Y_OFFSET = 16

    # The element icons are 18 pixels square on disk, two more than a
    # tile; they are drawn as they are, never resized. Beside an 8 pixel
    # word an icon is centred on the word, which puts its top
    # ``ELEMENT_ICON_Y_OFFSET`` above the word's top.
    ELEMENT_ICON_SIZE = 18
    ELEMENT_ICON_GAP = 2
    ELEMENT_ICON_WORD_GAP = 4
    ELEMENT_ICON_Y_OFFSET = -5
    ELEMENT_ICON_INLINE_Y_OFFSET = -5

    # The battle HUD splits here: commands, or the narration, on the
    # left; the party's names, bars and HP on the right, the way Final
    # Fantasy lays out its window. A submenu (abilities, items) takes
    # the whole width while it is open, as its magic list does.
    COMMAND_PANEL_WIDTH = 128

    # Rows of the battle menus sit one text row apart.
    COMMAND_MENU_ROW_HEIGHT = 16
    # The stroke points left, a standing bar at the command panel's right edge.
    POINTS_BAR_WIDTH = 4
    POINTS_BAR_GAP = 1
    POINTS_BAR_SPENT = (60, 60, 60)
    ABILITY_MENU_ROW_HEIGHT = 16
    # The Ability menu is a grid (D-450): the mana row's number, then
    # three names of at most 7 letters, so a space always comes before the
    # next move's element tag (Frankie, 10/23), Final Fantasy's spell menu.
    ABILITY_NAME_CHARS = 7
    ABILITY_LABEL_WIDTH = 16   # The row's number to its first name.
    ABILITY_COL_WIDTH = 72     # One name to the next: the tag, 7 letters, a space.
    # Short names for every move whose name is longer than 7 letters
    # (Frankie, 10/23: Flame Kick is FlmKick, Wave Guard WaveGrd; the rest
    # Claude's, rename freely). Anything not here is cut to 7.
    MOVE_SHORT_NAMES: dict = {
        "Absolution": "Absolve", "Act of Mauga": "ActMaug", "Anglerfish": "Angler",
        "Annotate": "Annote", "Antidote": "Antidot", "Antidote Mist": "AntiMst",
        "Antivenom": "Antivnm", "Backstab": "Bkstab", "Bad Dancing": "BadDanc",
        "Bark Tea": "BarkTea", "Battle Meditation": "Meditat", "Belly Flop": "BlyFlop",
        "Bilge Water": "Bilge", "Bitter Medicine": "BitrMed", "Bitter Smoke": "BitrSmk",
        "Black Spot": "BlkSpot", "Bleed and Gather": "BleedGa", "Blessed Edge": "BlsEdge",
        "Blessing": "Blessng", "Blind Faith": "BlndFth", "Blood Trail": "BldTrl",
        "Boil Over": "BoilOvr", "Boomerang": "Boomrng", "Borrowed Life": "BrwLife",
        "Borrowed Notes": "BrwNote", "Bottle It": "Bottle", "Bright Seal": "BrtSeal",
        "Brilliance": "Brillnc", "Bush Tucker": "BshTuck", "Cartwheel": "Cartwhl",
        "Cast Iron": "CastIrn", "Catalyst": "Catalst", "Cauterize": "Cautrze",
        "Chain Lightning": "ChainLt", "Clear Head": "ClrHead", "Coin Toss": "CoinTos",
        "Cross Reference": "CrossRf", "Cure All": "CureAll", "Cure Blind": "CureBld",
        "Cure Poison": "CurePsn", "Cure Sleep": "CureSlp", "Damnation": "Damnatn",
        "Davy Jones": "DavyJns", "Dawn Seal": "DawnSl", "Death Knell": "DthKnel",
        "Death Mark": "DthMark", "Dim Seal": "DimSeal", "Dinner Bell": "DinBell",
        "Dirty Strike": "DrtyStk", "Dirty Trick": "DrtyTrk", "Discipline": "Discipl",
        "Dissertation": "Thesis", "Doldrums": "Doldrum", "Dragon's Breath": "DragBrt",
        "Drill Sergeant": "DrillSg", "Dust Devil": "DstDevl", "Eruption": "Erupt",
        "Evil Eye": "EvilEye", "Eye Drops": "EyeDrop", "Eye of Shaka": "EyeShak",
        "Fan the Flames": "FanFlam", "Feedback": "Feedbck", "Field Dress": "FldDres",
        "Field Dressing": "Dressng", "Field Notes": "FldNote", "Fire Arrow": "FirArrw",
        "Fire Blast": "FirBlst", "Fire Breath": "FirBrth", "Fire Guard": "FirGrd",
        "Fire Knife": "FirKnif", "Fire Rain": "FirRain", "Fire Sentinel": "FirSent",
        "Fire Spring": "FirSprg", "Fire Wheel": "FirWhel", "Fire Whirl": "FirWhrl",
        "Firebomb": "Firebmb", "Firestorm": "Firstrm", "Flame Kick": "FlmKick",
        "Flame Slash": "FlmSlsh", "Focus Beam": "FocBeam", "Follow Me": "FollwMe",
        "Forced March": "FrcMrch", "Glass Sea": "GlasSea", "Golden Hour": "GoldHr",
        "Golden Sun": "GoldSun", "Grand Spiral": "GrSpirl", "Grave Grip": "GrvGrip",
        "Haste and Slow": "HstSlow", "Heavy Limbs": "HvyLimb", "Heavy Weather": "HvyWthr",
        "Hex Bolt": "HexBolt", "Hex Doll": "HexDoll", "Hide in Shell": "HideShl",
        "Holy War": "HolyWar", "Hurricane Dance": "Hurrcan", "Ice Bath": "IceBath",
        "Inoculate": "Inocult", "Jolly Roger": "JlyRogr", "Judgment": "Judgmnt",
        "Kill Order": "KillOrd", "Kill or Cure": "KillCur", "Lanu's Bounty": "Bounty",
        "Last Stand": "LstStnd", "Lava Burst": "LavBrst", "Leech Seed": "LeechSd",
        "Leviathan": "Leviath", "Lomilomi": "Lomilom", "Long Draught": "LngDrgt",
        "Maelstrom": "Maelstr", "Magnum Opus": "MagOpus", "Mana Leech": "MnLeech",
        "Margin Note": "MrgNote", "Martyr Guard": "MrtyGrd", "Mending Hula": "MndHula",
        "Mental Break": "MindBrk", "Message in a Bottle": "Message", "Mirror Pool": "MirPool",
        "Mirror Sin": "MirSin", "Morning Prayer": "MrnPryr", "Nature Blast": "NatBlst",
        "Nightfall": "Nightfl", "Numbing Agent": "Numbing", "Open Flame": "OpnFlam",
        "Open Wound": "OpnWond", "Oven Mitt": "OvnMitt", "Overdose": "Overdos",
        "Pan Flip": "PanFlip", "Patience": "Patienc", "Peer Review": "PeerRev",
        "Perennial": "Perenl", "Petal Rain": "PetRain", "Pistol Shot": "Pistol",
        "Poison Dart": "PsnDart", "Poultice": "Poultic", "Purgative": "Purgatv",
        "Purification": "Purify", "Purifying Guard": "PureGrd", "Quick Draw": "QckDraw",
        "Radiant Edge": "RadEdge", "Radiant Seal": "RadSeal", "Reckless": "Reckles",
        "Regen and Poison": "RgnPsn", "Revelation": "Reveal", "Ricochet": "Ricoch",
        "Rough Seas": "RghSeas", "Safeguard": "Safegrd", "Sake Gourd": "SakeGrd",
        "Sanctuary": "Sanctum", "Sand in the Eyes": "SandEye", "Scapegoat": "Scapegt",
        "Sea Shanty": "Shanty", "Second Look": "2ndLook", "Second Opinion": "2ndOpin",
        "Set the Bone": "SetBone", "Shadow Blast": "ShdBlst", "Shadow Step": "ShdStep",
        "Shadow Strike": "ShdStrk", "Shaka's Light": "ShakaLt", "Shared Cup": "ShrdCup",
        "Sharkskin": "Shrkskn", "Siva Afi": "SivaAfi", "Sleep Dart": "SlpDart",
        "Sleeping Draught": "SlpDrgt", "Smelling Salts": "Salts", "Smite the Heretic": "Smite",
        "Smoke Bomb": "SmkBomb", "Smoke Out": "SmokOut", "Smoke Ring": "SmkRing",
        "Smoke and Flame": "SmkFlam", "Solar Seal": "SolSeal", "Somersault": "Somrslt",
        "Spirit Blast": "SprBlst", "Spirit Kick": "SprKick", "Spirit Storm": "SprStrm",
        "Spring Guard": "SprgGrd", "Squall Wall": "SqlWall", "Starfall": "Starfal",
        "Status Guard": "StatGrd", "Steam Vent": "StmVent", "Still Water": "StlWatr",
        "Stillness": "Stilnes", "Stir Fry": "StirFry", "Stone Skin": "StnSkin",
        "Storm Call": "StrmCal", "Storm Mirror": "StrmMir", "Study Group": "StudyGp",
        "Sun Blast": "SunBlst", "Sun Salute": "SunSalt", "Sun Slash": "SunSlsh",
        "Thank the Animal": "Thanks", "Thorn Arrow": "ThrnArw", "Thorn Kick": "ThrnKck",
        "Thousand Cuts": "1000Cut", "Thunderhead": "Thundhd", "Tidal Wave": "TdlWave",
        "Tide Guard": "TideGrd", "Tide Veil": "TideVl", "Tide of Life": "TidLife",
        "Tiga Nasib": "TigaNsb", "Tornado Kick": "Tornado", "Toxic Cloud": "ToxCld",
        "Triple Trouble": "Triple", "Turtle Stance": "Turtle", "Twist the Knife": "Twist",
        "Undercurrent": "Undercr", "Undertow": "Undrtow", "Use Every Part": "UseAll",
        "Veiled Seal": "VeilSl", "Venus Flytrap": "Flytrap", "Vigor Seal": "VigSeal",
        "Voice of Mauga": "VoiceMg", "Wasting Curse": "Wasting", "Waterspout": "Wtrspt",
        "Wave Guard": "WaveGrd", "Weak Spot": "WeakSpt", "Well Done": "WellDon",
        "Wellspring": "Wellspr", "Whirlwind Kick": "Whrlwnd", "Wild Card": "WildCrd",
        "Wrath of Mauga": "WrathMg",
    }

    # The battle turn-order strip across the top of the battle screen,
    # and the help line under it (the highlighted action's wait and
    # numbers) while a command is being chosen.
    TURN_STRIP_X = 8
    TURN_STRIP_Y = 4
    TURN_STRIP_GAP = 8    # Pixels between one name and the next.

    TYPEWRITER_CHARS_PER_SECOND = 60
    # A story line marked (fast) types this many times quicker; one that ends
    # on a dash is cut off, the next line on at once (Frankie, 10/23).
    FAST_TEXT_TIMES = 3
    CUT_OFF = ("—", "-")

    MENU_CURSOR_BLINK_HZ = 2.0
    # A list with more past its edge flashes a white arrow there (ui/scroll_mark.py).
    SCROLL_MARK_BLINK_HZ = 2.0
    SCROLL_MARK_ROW_MIDDLE = 4  # From the top of a row's letters to the arrow's middle.
    # Added to a text row to give the pitch of a menu's rows: 0 is one
    # row (16 pixels) per item.
    MENU_ITEM_SPACING = 0
    TITLE_SCREEN_MENU_ITEM_SPACING = 0
    # The cursor's tip sits this far left of a menu row's text.
    MENU_LABEL_OFFSET = 6

    TITLE_SCREEN_HEADING_X = 56
    TITLE_SCREEN_HEADING_Y = 56
    TITLE_SCREEN_MENU_X = 96
    # NEW GAME and CONTINUE over the sea, under the sun's reflection (ui/title_dawn.py).
    TITLE_SCREEN_MENU_TOP_Y = 152


class ConfirmSettings:
    """The NO / YES box (``core/scenes/confirm_scene.py``).

    Follows Dungeon Digger's dialog: NO first, cancel means NO. There is
    no quit box: the game cannot be quit from inside (Frankie, 10/23).
    """

    NO_INDEX = 0                # NO sits on the left and starts selected.
    YES_INDEX = 1
    LABEL_NO = "No"
    LABEL_YES = "Yes"

    BOX_WIDTH = 160             # Pixels; the warning wraps inside it.
    PADDING = 8                 # Pixels inside the border, top and bottom.
    BORDER_THICKNESS = 2        # Matches the text box border.
    OPTION_GAP = 48             # Pixels between the centres of NO and YES.
    DIM_ALPHA = 160             # Out of 255; dims the scene underneath.
    COLOR_WARNING = (255, 120, 110)   # The "what is lost" line.


class GameOverSettings:
    """The GAME OVER screen after a lost fight (``core/scenes/game_over_scene.py``).

    Final Fantasy VI's (Frankie, 10/24): a dark screen, the words, a short
    pause, then any button goes to the title. No music for now.
    """

    TEXT = "Game Over"
    HOLD_SECONDS = 2.0          # The pause before a button is listened to.


class GridSettings:
    """Tile dimensions for the overworld grid."""

    TILE_SIZE = 16  # Pixels per overworld tile (D-444).


class OverworldSettings:
    """Cell-area layout for the overworld scene.

    One cell is a fixed grid of tiles that fills the whole screen, 16
    across and 14 down (D-444). Crossing the edge swaps to the matching
    neighbor cell in ``WORLD_LAYOUT`` and snaps the sprite to its entry
    tile. Screen-locked -- no scrolling camera at this layer. The
    message window draws over the bottom four rows when it has text.
    """

    COLS = 16  # Tiles wide per cell.
    ROWS = 14  # Tiles tall per cell.
    PIXEL_W = COLS * GridSettings.TILE_SIZE   # 256 px.
    PIXEL_H = ROWS * GridSettings.TILE_SIZE   # 224 px.
    X = 0
    Y = 0

    # Wall character recognised by World.is_wall. Walls block the
    # player's step; the cell renderer draws them as coconut palms.
    WALL_CHAR = "#"
    WATER_CHAR = "~"  # Impassable.
    # A rest stop (D-525): a pond that looks like water and blocks like
    # it; facing it and pressing confirm heals and revives the party.
    SPRING_CHAR = "o"
    SAND_CHAR = "_"   # Walkable; paths and beaches.
    # A market stall: blocks, and facing it and pressing confirm opens
    # the shop (D-571).
    STALL_CHAR = "m"
    FLOOR_CHAR = "."  # Walkable default, grass.
    # Inside a house (Frankie, 10/22): woven mats to walk on, the wooden
    # wall around the room (ui/walls.py picks each tile's piece), and the
    # black outside it. Both of the last two block.
    MAT_CHAR = "f"
    INSIDE_WALL_CHAR = "w"
    VOID_CHAR = "v"
    # What can be walked on.
    WALKABLE_CHARS: tuple = (FLOOR_CHAR, SAND_CHAR, MAT_CHAR)

    # The picture for each cell character: a list of choices, each a
    # (file, tile index) pair in ``AssetPaths.TILES_DIR``, counting 16
    # pixel tiles left to right: Mini World Sprites (CC0) outside, Ninja
    # Adventure's mats inside. The inside wall's picture is only the
    # Workshop's brush; the room draws each wall tile with ui/walls.py.
    # A tile with several choices picks one by its position, so the
    # same map always looks the same. A wall is a palm drawn over grass.
    TILE_PICTURES: dict = {
        FLOOR_CHAR: [("miniworld/Ground/Grass.png", 1)] * 6
        + [("miniworld/Ground/TexturedGrass.png", 1), ("miniworld/Ground/TexturedGrass.png", 2)],
        SAND_CHAR: [("miniworld/Ground/Grass.png", 3)],
        WATER_CHAR: [("miniworld/Ground/Shore.png", 4)],
        SPRING_CHAR: [("miniworld/Ground/Shore.png", 4)],
        WALL_CHAR: [("miniworld/Nature/CoconutTrees.png", n) for n in (2, 3, 4, 5)],
        STALL_CHAR: [("miniworld/Buildings/Wood/Market.png", 4)],
        MAT_CHAR: [("interior/floor.png", n) for n in range(4)],
        INSIDE_WALL_CHAR: [("interior/walls.png", 3)],
        VOID_CHAR: [("interior/walls.png", 6)],
    }
    # What is drawn under a character whose picture has see-through parts.
    TILE_UNDER: dict = {WALL_CHAR: FLOOR_CHAR, STALL_CHAR: SAND_CHAR}

    # A building stands on the room's tiles, drawn at its own size (D-577)
    # with its top left corner on its tile, and blocks every tile it
    # covers. Each kind: its picture in ``AssetPaths.BUILDINGS_DIR`` and
    # the tiles it covers, across and down. A picture a few pixels taller
    # than its tiles (the pot) stands on their bottom edge. From Ninja
    # Adventure's TilesetHouse.png: the hale is the thatched house's roof
    # over its door, one story; the tall hale, the chief's house, is the
    # same house whole, two stories; the stall is the awning over three bottles of medicine.
    BUILDINGS: dict = {
        "hale": ("hale.png", (4, 5)),
        "tall_hale": ("tall_hale.png", (4, 7)),
        "stall": ("stall.png", (3, 2)),
        "baskets": ("baskets.png", (3, 1)),
        "crates": ("crates.png", (2, 2)),
        "pot": ("pot.png", (1, 1)),
        # A chest (Frankie, 10/24): Mini World Sprites' Miscellaneous/Chests.png,
        # the wooden one. Its ``item`` goes in the bag the first time, with its
        # ``line`` if it has one; after that it is empty. The sheet has no open
        # chest, so an opened one looks the same.
        "chest": ("chest.png", (1, 1)),
        # A wooden sign, Mini World Sprites' Miscellaneous/Signs.png (the second),
        # standing at the old man's stall at night (Frankie, 10/25).
        "sign": ("sign.png", (1, 1)),
        # The lore hints on the map (Frankie, 10/25), drawn from Mini World Sprites'
        # Trees.png and Rocks.png: the Maki Sages' spiral cut into a tree, a Pohaku
        # asleep with two faint eyes, Lanu's carved post with a cup of water, a banyan.
        # Each has its ``look`` lines, said when faced.
        "spiral_tree": ("spiral_tree.png", (1, 1)),
        "pohaku": ("pohaku.png", (1, 1)),
        "lanu_post": ("lanu_post.png", (1, 1)),
        "banyan": ("banyan.png", (1, 1)),
        # The insides' furniture, from Ninja Adventure's bed and camp
        # tilesets: sleeping mats, a bed, a fire pit, a stool, a stump
        # table, a clay jar, a barrel, a rug.
        "mat": ("mat.png", (1, 2)),
        "bed": ("bed.png", (1, 2)),
        "firepit": ("firepit.png", (2, 2)),
        "stool": ("stool.png", (1, 1)),
        "table": ("table.png", (2, 2)),
        "jar": ("jar.png", (1, 1)),
        "barrel": ("barrel.png", (2, 2)),
        "rug": ("rug.png", (2, 2)),
    }
    # Facing one of these and pressing confirm opens its keeper's shop, as
    # a market stall tile does.
    SHOP_BUILDINGS: tuple = ("stall",)
    # Buildings walked over, not around.
    FLAT_BUILDINGS: tuple = ("rug",)
    # The door of a building that can be walked into (Frankie, 10/22): the
    # tile of its picture the door is on, across and down from its top
    # left. A building's ``inside`` names the room behind the door. Walking
    # up into the door goes in, onto the gap in the bottom of that room's
    # wall; walking down out of the gap comes back out below the door.
    DOORS: dict = {"hale": (1, 4), "tall_hale": (1, 6)}


class ItemSettings:
    """What the items in the bag are called, and the lontar."""

    # The name an item shows in the bag and the shops; an item not here
    # shows its id.
    NAMES: dict = {
        "counter_shell": "Counter",  # a lontar shows the move's name (Frankie, 10/23)
        "seer_shell": "Seer's Shell",
        "seed_hp": "Seed of Vitality", "seed_strength": "Seed of Strength",
        "seed_magic": "Seed of Intelligence", "seed_vitality": "Seed of Endurance",
        "seed_spirit": "Seed of Willpower", "seed_speed": "Seed of Agility",
        "seed_accuracy": "Seed of Perception", "seed_evasion": "Seed of Luck",
        "wheat": "Wheat", "noodles": "Noodles", "broth": "Broth", "saimin": "Saimin",
        "taro": "Taro", "poi": "Poi",
        "boar_tusk": "Boar Tusk",
        "noni": "Noni", "awa": "'Awa", "kukui": "Kukui", "ti_leaf": "Ti Leaf", "olena": "'Ōlena",
        # Weapons and relics in the bag go by their own names (Frankie, 10/24).
        **{entry["id"]: entry["name"] for entry in SHARED["weapons"] + SHARED["relics"]},
    }
    # What heals from the bag, in a fight or out, and by how much: the
    # plant medicine, Noni and 'Awa, and the dishes in the shared file's
    # ``cooking`` (saimin as much as Noni, poi less; cooked fresh in a fight by Kailo's Cook,
    # each heals half again as much).
    # Every food ingredient can be eaten as it is, for a little HP, and is
    # worth more cooked (Frankie, 10/23).
    INGREDIENT_HEAL = 5
    INGREDIENTS: tuple = ("wheat", "taro", "noodles", "broth")
    HEALS: dict = {
        "noni": BattleSettings.NONI_HEAL_AMOUNT,
        "awa": BattleSettings.AWA_HEAL_AMOUNT,
        **{dish["id"]: dish.get("heals", BattleSettings.NONI_HEAL_AMOUNT)
           for dish in SHARED["cooking"]["dishes"]},
        **dict.fromkeys(INGREDIENTS, INGREDIENT_HEAL),
    }
    # The plant medicine that cures (Frankie, 10/23): used in a fight on an
    # ally, it takes away these ailments. Ailments last only the fight, so
    # out of one these only show their help line.
    CURES: dict = {
        "kukui": ("burn",),
        "ti_leaf": ("sleep", "possess"),
        "olena": ("poison",),
    }
    # A lontar, an ELEMENT (Frankie, 10/22; a lontar since 10/24): used
    # from Items, Hina reads it, the member learns the move (the party flag
    # ``<member>_learned_<move>``) and it is gone. Item id to (member, move
    # id in battle.json). The ids still say shell, so older saves keep it.
    SHELLS: dict = {"counter_shell": ("kailo", "counter_guard")}
    # What is said before a lontar is learned, speaker id and line
    # (Frankie's words, 10/24): Kailo cannot read, so Hina reads it.
    READ_TALK: tuple = (
        ("kailo", "...that's right, I can't read"),
        ("hina", "Here, give it to me, I'll read it for you."),
    )
    # The seeds (Frankie, 10/22): one per stat, named plainly, used from
    # Items on a member, it raises that stat by SEED_POINTS, as a rise from
    # use in a fight does (Claude's number). Item id to stat key.
    SEEDS: dict = {
        "seed_hp": "hp", "seed_strength": "strength", "seed_magic": "magic",
        "seed_vitality": "vitality", "seed_spirit": "spirit", "seed_speed": "speed",
        "seed_accuracy": "accuracy", "seed_evasion": "evasion",
    }
    SEED_POINTS = 1
    # The Items screen's help line for what is not a heal, a lontar or a
    # seed (those say what they do from the numbers), and the words after
    # a heal's number. Claude's words, 10/23; what it does comes first, since a
    # narrow help line (the shop's) keeps only the first sentences (10/24).
    HELP: dict = {
        "seer_shell": "Reads an enemy's element and HP. Used in a fight.",
        "wheat": "Grown in the palm grove.",
        "taro": "Grown in the town's garden.",
        "poi": "Taro pounded into a smooth paste.",
        "noodles": "Made from wheat.",
        "broth": "Sold at the market stall.",
        "noni": "Mashed noni. It stinks.",
        "awa": "A calming root drink.",
        "kukui": "In a fight, cures a burn. Candlenut oil.",
        "ti_leaf": "In a fight, cures sleep and confusion. A cool leaf.",
        "olena": "In a fight, cures poison. Turmeric root.",
        "boar_tusk": "The Great Boar's tusk. Melia asked for one.",
    }
    # The Seer's Shell (Frankie, 10/22): used in a fight on an enemy, it
    # reads it as Sarjana's Scan does, and is used up.
    SEER_SHELL = "seer_shell"
    # Drops besides a monster's own item (Frankie, 10/22; the numbers are
    # Claude's first guess). Each beaten monster: one time in
    # EVERYDAY_CHANCE an everyday item, picked by weight; one time in
    # SEED_CHANCE a seed, its favorite (if it has one) half the time,
    # any seed the rest.
    EVERYDAY_CHANCE = 0.2
    EVERYDAY: dict = {"noni": 3, "seer_shell": 1}
    SEED_CHANCE = 0.04
    SEED_FAVORITE_SHARE = 0.5
    # The demo's dropped equipment (Frankie, 10/24): rarer than items or
    # ingredients. One time in EQUIP_CHANCE a beaten monster leaves one of
    # these, any of them alike (Claude's number, 10/24).
    EQUIP_CHANCE = 0.03
    # Taro and wheat drop too (Frankie, 10/24), so selling or eating them
    # never leaves the garden with nothing to replant: one time in
    # 1 / INGREDIENT_CHANCE, either alike (Claude's number).
    INGREDIENT_CHANCE = 0.1
    INGREDIENT_DROPS: tuple = ("taro", "wheat")
    EQUIP_DROPS: tuple = ("kapa_wraps", "hamaya", "kagura_fan", "hula_kii", "pearl_anklet")
    # What a chest with ``random`` holds, one picked alike when it is opened
    # (Frankie, 10/25): ``equip`` a weapon or relic monsters drop, ``goodie``
    # a medicine Maika sells, a Seer's Shell or CHEST_PULE pule ("pule";
    # Claude's number).
    CHEST_PULE = 30
    CHEST_RANDOM: dict = {
        "equip": EQUIP_DROPS,
        "goodie": ("noni", "kukui", "ti_leaf", "olena", "awa", "seer_shell", "pule"),
    }
    # Which seed a kind of monster (the shared file's ``monsters``) drops
    # more often.
    # A key item a monster always leaves (Claude's call, 10/25): the Great
    # Boar's tusk, for Melia (game/shared/story-tusk.md). Never sold.
    KEY_DROPS: dict = {"great_boar": "boar_tusk"}
    SEED_FAVORITES: dict = {
        "boar": "seed_strength", "great_boar": "seed_hp", "mage": "seed_magic",
        "nuno": "seed_vitality", "shade": "seed_speed", "rot": "seed_hp",
        "lich": "seed_spirit",
    }


class ShopSettings:
    """Prices in the shops (D-571)."""

    # While Maika is in the party, every price is this share lower, rounded,
    # never under 1 pule: his party passive, he charms the sellers (Frankie,
    # 10/22). The share is Claude's first guess.
    CHARM_DISCOUNT = 0.2
    # Selling (Frankie, 10/24): at either shop, anything the demo gives again;
    # never the starting gear, a chest's item or a one-off (``once`` in a shop).
    # A shop's item sells for this share of its price, rounded down (Claude's
    # number); what no shop sells has its price here (Claude's numbers).
    SELL_SHARE = 0.5
    # The seller's line over the Buy and the Sell list, as Final Fantasy VI's
    # "Help yourself!" (Claude's drafts, 10/24, in docs/demo-script.md).
    BUY_LINE = "Help yourself!"
    SELL_LINE = "What'll you sell?"
    SELL_PRICES: dict = {
        **{seed: 25 for seed in ItemSettings.SEEDS},
        **{item: 20 for item in ItemSettings.EQUIP_DROPS},
    }


class TownSettings:
    """The two villagers sparring in town (the demo plan, Frankie 10/22), and Kailo's bed."""

    # Standing next to one, facing them, this long with nothing pressed
    # teaches Kailo, once (Frankie, 10/23).
    WATCH_SECONDS = 30
    WATCH_MEMBER = "kailo"
    WATCH_GROWTH = {"strength": 2, "speed": 2}
    WATCH_FLAG = "watched_lelua"
    WATCH_LINES = (
        "By watching the villagers spar, Kailo learned a few tricks.",
        "Kailo's strength and agility went up.",
    )
    # Facing Kailo's bed and confirming asks this, NO / YES; YES rests the
    # party (Frankie's words, 10/23; there is no inn).
    NAP_BOX = "Take a nap?"
    NAP_LINE = "The party recovered HP."
    # After the nap or the pond, the save point (Frankie, 10/23): YES opens
    # the three slots.
    SAVE_BOX = "Save your game?"
    # Only Kailo's own bed naps and saves (Frankie, 10/25). At anyone else's
    # Hina scolds, flustered at her own; with her away, Kailo says it is
    # not his (Claude's drafts, in docs/demo-script.md).
    OWN_BED = "kailo"
    SCOLD_SPEAKER = "Hina"
    NOT_YOUR_BED = "Kailo! That's not your bed. If you're tired, go home."
    HINA_BED = "Wh-what are you doing?! That's my bed! Get away from it!"
    NOT_MY_BED = "...this isn't my bed."
    # The old man's stall at night (Frankie, 10/25): a sign stands in his place,
    # Kailo cannot read it, Hina reads it, and his shop is open as by day.
    SIGN_STARE = ["...", "......", "........."]
    SIGN_READ = ["You can't read it, can you.",
                 "It says: \"Gone to Pono's wake. Leave your pule in the jar. Stealing is bad.\""]


class GardenSettings:
    """How Hina's garden patches look (``systems/garden.py``)."""

    # Each plant's four 16 pixel pictures in a row: bare soil, growing,
    # more grown, ripe. Wheat is Mini World Sprites' wheat field. Taro
    # (Frankie, 10/23) is Mini World's bare soil with Ninja Adventure's
    # plants on it, from TilesetNature.png: the small round plant at x 96,
    # y 160, the leafy one at x 0, y 160, and the big dark leaf at x 64,
    # y 176.
    PICTURES: dict = {
        "wheat": "miniworld/Nature/Wheatfield.png",
        "taro": "garden/Taro.png",
    }
    # The lines pressing on a patch says (Frankie, 10/23: one press, one
    # thing). Maika's ability is the Maki Hula (Frankie, 10/23).
    REPLANT_BOX = "Replant {item}?"  # names the plant (Frankie, 10/23)
    ABILITY_BOX = "Do the Maki Hula?"
    ABILITY_DONE_LINE = "Maika does the Maki Hula."
    GROWING_LINE = "It is still growing."
    NEEDS_HINA_LINE = "This soil can be replanted, but you're bad at gardening."
    # Replanting uses one of what the patch grows (Frankie, 10/23); with none
    # in the bag (Claude's words, {item} is its name):
    NO_SEED_LINE = "You need a {item} to replant it."
    ABILITY_LINE = "It will grow faster now."
    # The first time each ability can be used, its owner offers it before
    # the question, once a game (Frankie, 10/23). Claude's drafts, in their
    # voices, for Frankie to rewrite.
    HINA_OFFER_LINE = "Don't leave it bare. It should be replanted. I'll show you how."
    MAIKA_OFFER_LINE = "Let a wise man dance. My nature magic will make it grow faster."


class CraftSettings:
    """What the pot says (``core/scenes/craft_scene.py``). Crafting is by
    experiment (Frankie, 10/23): two in, and only then is it known what they
    make. The wording is Claude's; {item} is an ingredient's name and
    {crafter} the one whose craft it is."""

    PICK_LINE = "Put two things in the pot."
    WITH_LINE = "Put {item} with what?"
    MADE_LINE = "Made {item}."
    NO_MIX_LINE = "Those don't go together."
    ONLY_ONE_LINE = "There is only one {item}."
    AWAY_LINE = "{crafter} would know about these."
    EMPTY_LINE = "Nothing here goes in the pot."


class RecordSettings:
    """The date and Data's records (Frankie, 10/23; ``systems/records.py``)."""

    # Four seasons of 30 days. The game starts in late summer, SUMMER 30,
    # and the date never moves for now: sailing will move it.
    SEASONS = ("SPRING", "SUMMER", "AUTUMN", "WINTER")
    SEASON_DAYS = 30
    START_DAY = 60  # Counted from SPRING 1 as day 1: SUMMER 30.


class PassiveSettings:
    """The party passives (Frankie, 10/21 and 10/22; ``systems/passives.py``).

    A passive is on while its member is in the party, bench included. It
    is said once, in one sentence, when the member joins, and nowhere else.
    """

    # The one sentence said when each one joins; Kailo and Hina start in
    # the party, so theirs is never said.
    JOIN_LINES: dict = {
        "maika": "While he is in your party, shops charge less.",
        "tawiri": "While she is in your party, skills grow faster.",
    }
    # Tawiri's: the chance a stat grows from use in a fight is this many
    # times the usual. Claude's first guess.
    TAWIRI_GROWTH = 2.0


class FieldMonsterSettings:
    """Pacing for the monsters seen on the map (D-576)."""

    STEP_MS = 250                     # How long one tile's slide takes.
    WAIT_RANGE = (0.6, 1.6)           # Seconds standing between steps, picked at random.
    # A wandering monster this many tiles from the player (across plus
    # down) chases instead, a step every CHASE_WAIT seconds; a boss never
    # does (Frankie, 10/21).
    CHASE_TILES = 4
    CHASE_WAIT = 0.15
    COLOR = (150, 60, 50)             # Stand-in square when the picture is missing.
    # After a fight that is not won (run away, or lost), the monster
    # cannot start another for this long, so the party can walk off.
    GRACE_SECONDS = 2.0

class OverworldPlayerSettings:
    """Tunable values for the overworld player sprite.

    A walking character is one tile, 16 by 16, Pokemon style (D-573).
    The sheet named in ``AssetPaths.PLAYER_SHEET`` is a Ninja Adventure
    walk sheet: one column per facing, four walk frames down each.
    """

    STEP_DURATION_MS = 150            # Walk animation duration per tile.
    COLOR = ColorSettings.YELLOW      # Stand-in fill when the sheet is missing.
    WIDTH = GridSettings.TILE_SIZE
    HEIGHT = GridSettings.TILE_SIZE
    # Column of the sheet for each facing, as (dx, dy).
    SHEET_COLUMNS: dict = {(0, 1): 0, (0, -1): 1, (-1, 0): 2, (1, 0): 3}
    FRAME_WIDTH = 16
    FRAME_HEIGHT = 16
    WALK_FRAMES = 4                   # Frame 0 is also the standing frame.
    FRAMES_PER_STEP = 2               # Shown while crossing one tile.
    SPAWN_COL = OverworldSettings.COLS // 2  # Center column on first spawn.
    SPAWN_ROW = OverworldSettings.ROWS // 2  # Center row on first spawn.


class StorySettings:
    """The demo's story around its two scenes (the demo line in game/answers.md, 10/22)."""

    # A scene acted out on the map (core/staging.py, Frankie 10/23): the
    # player is this one of its cast, and a run takes this long a tile,
    # twice the walk's OverworldPlayerSettings.STEP_DURATION_MS.
    PLAYER = "Kailo"
    RUN_STEP_MS = 75
    # A foe on the stage facing down roots in the mud, a frame this long each.
    ROOT_SECONDS = 0.35

    # Party flags, so a save keeps the story's place: the taro patch is
    # over, and the Great Boar is beaten, so it is night.
    TARO_FLAG = "story_taro_patch"
    # After the taro patch Hina goes home, out of the party, until Kailo
    # talks to her there: her scene, and the flag that she has joined
    # (Frankie, 10/23). Saves from before this keep her in the party.
    HOME_MEMBER = "hina"
    HOME_SCENE = "hina_joins"
    HOME_FLAG = "story_hina_joined"
    # So she cannot be missed: walking into this room without her, the one
    # before the Great Boar's, she catches up and joins (Frankie, 10/25; it
    # was the hedge garden, before Maika could be met).
    WOODS_SCENE = "hina_woods"
    WOODS_ROOM = "gate_yard"
    # The log yard's west edge, where the painted map ends and the generated
    # woods begin (Frankie, 10/25): stepping onto it, Maika warns Kailo off,
    # else Hina, each once (game/shared/story-deep-woods.md).
    DEEP_ROOM = "log_yard"
    DEEP_COL = 0
    DEEP_HINA = "deep_woods_hina"
    DEEP_MAIKA = "deep_woods_maika"
    NIGHT_FLAG = "story_night"
    # Maika (game/shared/story-maika.md, Frankie 10/23): his scene the first
    # time he is talked to, then his shop; closing it, he joins if something
    # was bought, else says to come back. The first time the party replants
    # a garden patch with him and Hina along, he teaches her Seed, once
    # (Frankie, 10/24; it was walking into the Great Boar's room).
    JOINER = "maika"
    JOINER_MEETS = "maika_meets"
    JOINER_JOINS = "maika_joins"
    JOINER_LEAVES = "maika_leaves"
    # After he joins his stall stays open: pressing on it, he asks first
    # (Frankie, 10/24; Claude's words, a draft in docs/demo-script.md).
    JOINED_SHOP_LINE = "Still want to buy something, Kailo?"
    # A chest (Frankie, 10/24): what it held, then its own line if it has
    # one, said by Kailo; pressed again, it is empty.
    CHEST_FOUND = "Found {item}."
    CHEST_EMPTY = "It's empty."
    SEED_SCENE = "maika_seed"
    # The Great Boar's room: its music, and where the cartridge still plays
    # Seed until it catches up with the first planting.
    SEED_ROOM = "farm_field"
    SEED_FLAG = "hina_learned_seed"
    # The Great Boar never starts his fight on touch (Frankie, 10/23): walking
    # into him asks first (story-great-boar.md). The answer that fights; the
    # other walks the party this many steps back, and he asks again next time.
    ASK_KIND = "great_boar"
    ASK_SCENE = "great_boar_ready"
    ASK_FIGHT = "fight"
    BACK_STEPS = 3
    # Night over the field (Claude's call, 10/22): the Super Nintendo's
    # color math taking a fixed color away from every room pixel, the
    # text box left out. 5-bit amounts, red, green, blue (0 to 31).
    NIGHT_SUBTRACT = (16, 12, 2)
    # The scene played when the Great Boar falls, talk and no narration
    # (Frankie, 10/23; story-boar.md); then it is night.
    FALL_SCENE = "boar_falls"
    # The first time Kailo talks to Melia at night with the Great Boar's tusk
    # in the bag, he gives it to her before her question (Claude's call, 10/25).
    TUSK = "boar_tusk"
    TUSK_SCENE = "melia_tusk"
    TUSK_FLAG = "story_tusk_given"
    # Melia's question at night; YES starts the wake.
    ASK_SPEAKER = "Melia"
    ASK_LINE = "Everyone's at Pono's wake! Ready to go?"
    ASK_BOX = "Ready to go?"
    # Tawiri joins at the wake before its fight, with her pop-up.
    WAKE_JOINS = "tawiri"
    WAKE_JOIN_LINE = "Tawiri joined the party. While she is in your party, skills grow faster."
    # Whoever came along sits on the bench at the wake (he stays with the food).
    WAKE_BENCH = "maika"
    # A script's Fade (Frankie, 10/23: the wake fades in, and the demo fades
    # out): this long, in the Super Nintendo's sixteen brightness steps. The
    # demo ends on its End's words on black (TO BE CONTINUED), at this size.
    FADE_SECONDS = 0.6
    FADE_STEPS = 15
    CARD_SIZE = 16
    # Before the prologue (Frankie, 10/25): white on black, typed out letter
    # by letter, then the taro patch. His words, in docs/demo-script.md.
    BLURB = ("Far in the northeast seas lies a small island, green and full of life, far from the "
             "troubles of the wider world. There lives a warm, kindhearted young cook, and a "
             "headstrong, pious priestess...")
