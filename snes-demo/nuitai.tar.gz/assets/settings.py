import json
import os
import sys

from core.shared import SHARED, SHARED_DIR

# Battle numbers shared with the browser game. See ``core/shared.py``.
_RULES = SHARED["rules"]
_STATS = SHARED["stats"]


class ColorSettings:
    """Class to hold all the color settings for the game."""
    BLACK = (0, 0, 0)
    NERO = (30, 30, 30)
    GRAY = (120, 120, 120)
    DARK_GRAY = (60, 60, 60)
    WHITE = (255, 255, 255)
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    BLUE = (0, 0, 255)
    YELLOW = (255, 220, 0)
    # Enemy names in the battle turn-order strip, so the two sides can
    # be told apart at a glance without reading.
    FOE_NAME = (240, 170, 150)

    BG_COLOR = NERO
    OVERLAY_BACKGROUND = BLACK

    # Overworld tile placeholder colors. Replaced by tile sprite blits
    # in Pass 2 once we have real art chosen for Nuitai's island
    # setting. Until then these are how the cell area visually
    # distinguishes one terrain type from another.
    OVERWORLD_FLOOR = (110, 160, 90)    # grass green; walkable
    OVERWORLD_WALL = (90, 70, 60)       # rocky brown; impassable
    OVERWORLD_WATER = (60, 130, 180)    # ocean blue; impassable
    OVERWORLD_SAND = (220, 200, 140)    # sandy beige; walkable

    # Per-element accent colors. Used by menus / UI labels to flag the
    # affinity of an ability or item at a glance. Tuned for readability
    # on the black command-panel background -- Ahi and Wai are *lighter*
    # than the pure RED/BLUE constants above. Ata's entry is the lore
    # color (black); rendering it readably is the job of
    # ``ELEMENT_TEXT_STYLES`` below, which pairs the black body with a
    # white halo so the glyph survives any backdrop.
    # D-366, set B: fire red, plant green, water turquoise, light gold,
    # shadow purple, Mana blue, each lightened enough to read on black
    # (10/18: Tawiri's black shadow moves were hard to see).
    ELEMENT_COLORS: dict = {
        "ahi":  (240, 110, 95),   # red
        "wai":  (60, 200, 220),   # turquoise
        "lau":  (140, 205, 90),   # green
        "mana": (160, 190, 255),  # blue, light enough to read on the blue windows (10/18)
        "la":   (242, 194, 48),   # gold
        "ata":  (190, 120, 230),  # purple
    }

    # Per-element TEXT style. Anywhere the UI renders an element name
    # (element-pair lines on combatant cards, ability-row labels in the
    # battle command menu) reads its render kwargs from here and splats
    # them into ``text_renderer.draw_text``.
    #
    # SHIPPED RECIPE: every element gets the same white halo at radius
    # 3, alpha 90 -- the same recipe Ata originally needed so its lore-
    # black body would survive a dark background. Applying it to all
    # six keeps the screen visually balanced; without the halo the
    # other five read flat next to a halo'd Ata. Ata's body stays
    # black; everyone else keeps their accent fill.
    #
    # Alternatives we considered (preserved as runnable recipes in
    # ``visual_test_text.py``):
    #   universal soft white: glow=WHITE,  r=2, a=70  (toned down)
    #   self-color soft:      glow=fill,   r=2, a=60  (own-color bloom)
    #   self-color parity:    glow=fill,   r=3, a=90  (own-color at Ata intensity)
    #   brighter self-color:  glow=lighter, r=2, a=80 ("flame edge" -- per-element lighter halo)
    # Re-run ``python visual_test_text.py`` to compare again.
    _TEXT_HALO_WHITE = {
        "glow": (255, 255, 255),
        "glow_radius": 1,
        "glow_alpha": 90,
    }
    ELEMENT_TEXT_STYLES: dict = {
        "ahi":  {"color": ELEMENT_COLORS["ahi"],  **_TEXT_HALO_WHITE},
        "wai":  {"color": ELEMENT_COLORS["wai"],  **_TEXT_HALO_WHITE},
        "lau":  {"color": ELEMENT_COLORS["lau"],  **_TEXT_HALO_WHITE},
        "mana": {"color": ELEMENT_COLORS["mana"], **_TEXT_HALO_WHITE},
        "la":   {"color": ELEMENT_COLORS["la"],   **_TEXT_HALO_WHITE},
        "ata":  {"color": ELEMENT_COLORS["ata"],  **_TEXT_HALO_WHITE},
    }

    # The stats' colours (D-503 to D-505), by stat key: their elements', with
    # Agility orange and Willpower pink. Not on the status screen, which is
    # white (D-506); kept for the "strength went up!" lines and dialogue.
    STAT_TEXT_STYLES: dict = {
        "hp": ELEMENT_TEXT_STYLES["lau"],
        "strength": ELEMENT_TEXT_STYLES["ahi"],
        "magic": ELEMENT_TEXT_STYLES["mana"],
        "vitality": ELEMENT_TEXT_STYLES["wai"],
        "spirit": {"color": (245, 130, 190), **_TEXT_HALO_WHITE},
        "speed": {"color": (255, 160, 70), **_TEXT_HALO_WHITE},
        "accuracy": ELEMENT_TEXT_STYLES["la"],
        "evasion": ELEMENT_TEXT_STYLES["ata"],
    }


class BackgroundSettings:
    """Named scene-background templates and per-scene assignments."""

    SOLID = "solid"
    GRADIENT = "gradient"
    IMAGE = "image"
    # Battle backgrounds: Pixel-boy's battlebacks, CC0 (assets/graphics/backgrounds/battle/README.md).
    BATTLE_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'backgrounds', 'battle'
    )

    TEMPLATES: dict = {
        "ocean": (GRADIENT, (60, 180, 210), (10, 30, 70)),
        "midnight": (GRADIENT, (20, 20, 60), (0, 0, 0)),
        "dusk": (GRADIENT, (120, 60, 100), (20, 10, 40)),
        "ember": (GRADIENT, (200, 80, 30), (60, 10, 10)),
        "nero": (SOLID, (30, 30, 30)),
        # Behind a fight: dusk sky down into dark ground.
        "battlefield": (GRADIENT, (36, 58, 78), (16, 30, 26)),
        # Behind every fight for now: the tropical beach (Frankie, 10/18).
        "beach": (IMAGE, os.path.join(BATTLE_DIR, "3.png")),
        "black": (SOLID, (0, 0, 0)),
    }

    SCENE_BACKGROUNDS: dict = {
        "TitleScene": "ocean",
        "BattleScene": "beach",
        "MenuScene": "nero",
        "OverworldScene": "nero",
    }

    DEFAULT_TEMPLATE: str = "nero"


class ScreenSettings:
    """The screen is a Super Nintendo screen (D-158): 256 by 224 pixels.

    Every scene draws onto a surface this size. ``main.py`` then enlarges
    it by a whole number, the scale, to fill the window, so one game
    pixel is always the same square of screen pixels and nothing is ever
    smoothed. The window takes the largest whole number that fits the
    desktop; fullscreen does the same and leaves black bars around it.
    Every position in this file is on the 256 by 224 screen.
    """

    # True when running in a browser, built by pygbag (tools/web_build.py).
    # The page scales the canvas itself, so the game draws at WEB_SCALE.
    WEB = sys.platform == "emscripten"
    WEB_SCALE = 3
    WIDTH = 256
    HEIGHT = 224
    RESOLUTION = (WIDTH, HEIGHT)
    FPS = 60
    # Room the window leaves for the title bar and the taskbar when it
    # picks its scale, in desktop pixels.
    WINDOW_MARGIN_W = 64
    WINDOW_MARGIN_H = 120
    CRT_ALPHA_RANGE = (75, 90)
    WINDOW_TITLE = "Nuitai RPG"
    TITLE_SCREEN_HEADING = "Nuitai"


class InputSettings:
    """Controller button and axis mappings used by gameplay and menus."""

    JOY_BUTTON_A = 0
    JOY_BUTTON_B = 1
    JOY_BUTTON_X = 2
    JOY_BUTTON_Y = 3
    JOY_BUTTON_L1 = 4
    JOY_BUTTON_R1 = 5
    JOY_BUTTON_BACK = 6
    JOY_BUTTON_START = 7
    JOY_BUTTON_QUIT_COMBO = (7, 6, 4, 5)

    JOY_AXIS_LEFT_X = 0
    JOY_AXIS_LEFT_Y = 1
    JOY_AXIS_L2 = 4
    JOY_AXIS_R2 = 5
    JOY_TRIGGER_THRESHOLD = 0.5


class FontSettings:
    """The one font, and the pixel grid its text sits on.

    Press Start 2P draws every letter in an 8 by 8 cell at size 8, one
    font pixel per screen pixel, so 8 is the size of all text, 16 the
    heading size and 24 the title's; any other size blurs the pixels.
    Thirty-two letters fit across the screen (D-445). Text sits on rows
    ``LINE_HEIGHT`` apart, two 8 pixel cells, as the Super Nintendo
    games spaced their lines; a heading takes two rows.
    ``ui/text_renderer`` places text by the top of its capital letters,
    so a position here is where the letters start.
    """

    FONT = os.path.join(
        os.path.dirname(__file__), 'assets', 'font', 'PressStart2P-Regular.ttf'
    )

    SIZE_SMALL = 8
    SIZE_BODY = 8
    SIZE_HEADING = 16
    SIZE_TITLE_SCREEN_HEADING = 24
    LINE_HEIGHT = 16
    # Every letter is this wide, so a line holds its width // 8 letters.
    LETTER_WIDTH = 8


class AudioSettings:
    """Global audio toggles, mixer-level defaults, and the sound/music registry."""

    MUTE = False
    MUTE_MUSIC = False
    MUSIC_VOLUME = 1.0
    SFX_VOLUME = 1.0

    SOUND_EFFECTS: dict = {
        "menu_move": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_move2.ogg'
        ),
        "menu_select": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_select3.ogg'
        ),
    }

    # How a blow lands (D-151), shared with the browser battle: three
    # takes of each, picked at random. "hit_punch" for a physical blow,
    # "hit_magic" for a spell, "hit_sparkle" for healing, "hit_miss"
    # for a dodge or a miss.
    HIT_SOUNDS: tuple = ("hit_punch", "hit_magic", "hit_sparkle", "hit_miss")
    HIT_TAKES = 3
    for _kind in HIT_SOUNDS:
        for _take in range(1, HIT_TAKES + 1):
            SOUND_EFFECTS[f"{_kind}_{_take}"] = os.path.join(
                SHARED_DIR, 'sounds',
                # The browser build carries them as OGG (tools/web_build.py).
                f'{_kind}_{_take}.ogg' if sys.platform == "emscripten" else f'{_kind}_{_take}.mp3'
            )
    del _kind, _take

    SFX_FILE_VOLUMES: dict = {
        os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_move2.ogg'
        ): 0.2,
        os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_select3.ogg'
        ): 0.2,
    }

    MUSIC_TRACKS: list = []

    # Songs by screen, from the list the browser battle reads too
    # (game/shared/music/music.json, Frankie 10/14): which songs each
    # screen picks from, and each song's loop start and length in seconds.
    MUSIC_DIR = os.path.join(SHARED_DIR, 'music')
    with open(os.path.join(MUSIC_DIR, 'music.json'), encoding='utf-8') as _file:
        _music = json.load(_file)
    SCREEN_MUSIC: dict = _music["play"]
    SONG_LOOPS: dict = {
        name: tuple(song["loop"]) for name, song in _music["songs"].items() if "loop" in song
    }
    del _file, _music

    @staticmethod
    def music_file(name: str) -> str:
        """A song's file name: the browser build carries them as OGG (tools/web_build.py)."""
        return name[:-4] + '.ogg' if sys.platform == "emscripten" else name

    MUSIC_FILE_VOLUMES: dict = {
        os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'waves.ogg'
        ): 1.0,
    }


class AssetPaths:
    """Class to hold all the file paths for assets."""
    TV = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'effects', 'tv.png'
    )
    WAVES_SOUND = os.path.join(
        os.path.dirname(__file__), 'assets', 'audio', 'sound', 'waves.ogg'
    )
    MENU_MOVE_SOUND = os.path.join(
        os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_move2.ogg'
    )
    MENU_SELECT_SOUND = os.path.join(
        os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_select3.ogg'
    )
    # Per-character portrait sprites used in the party / status screens.
    # Files are named ``<member_id>_portrait.png`` and live in
    # ``assets/graphics/portraits/``; ``unknown_portrait.png`` is the
    # placeholder used when a member-specific portrait hasn't been drawn
    # yet.
    PORTRAITS_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'portraits'
    )
    UNKNOWN_PORTRAIT = os.path.join(
        os.path.dirname(__file__),
        'assets', 'graphics', 'portraits', 'unknown_portrait.png',
    )
    # Per-element 16x16 affinity icons (e.g. a flame for ``ahi``, a wave
    # for ``wai``) used by the roster element lines on the party screen
    # and in battle. Files are named ``<element_id>.png`` -- if a file
    # for a given element does not exist, the renderer falls back to the
    # element word so partial coverage is fine while art lands.
    ICONS_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'icons'
    )
    # Monster battle pictures, one still image each, named
    # ``<sprite>.png``. An enemy in the shared battle file names its
    # picture with ``"sprite"``. A monster with no file gets a plain
    # box, so a missing picture never stops a fight.
    MONSTERS_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'monsters'
    )
    # Map tiles: Mini World Sprites by Merchant Shade, CC0, unedited.
    TILES_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'tiles', 'miniworld'
    )
    # The walking sprite sheet: one row per facing (down, left, right,
    # up), seven frames per row, each ``OverworldPlayerSettings.FRAME_WIDTH``
    # by ``FRAME_HEIGHT``. Made by ``tools/make_walker.py`` from Memao's pack.
    PLAYER_SHEET = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'player', 'kailo.png'
    )


class BattleStageSettings:
    """Where fighters stand in a battle and how they move.

    Positions are in screen pixels on the 256 by 224 screen. Times are
    in seconds. See ``ui/battle_stage.py``. From the top: the turn strip
    and the help line (two rows), the monsters standing on ``GROUND_Y``
    with their statuses under each, then the 80 pixel HUD, whose right
    panel lists the party.
    """

    # --- Monsters ---------------------------------------------------
    # Every monster picture is drawn at this whole-number size, so one
    # source pixel is always the same size on screen. A picture too
    # tall for the field at this size drops to the next size down.
    MONSTER_SCALE = 1
    MONSTER_MAX_HEIGHT = 88
    # The line the monsters stand on.
    GROUND_Y = 104
    # The box drawn for a monster that has no picture.
    PLACEHOLDER_SIZE = 32
    COLOR_PLACEHOLDER = (70, 70, 80, 255)
    SHADOW_WIDTH_SHARE = 0.8   # Of the picture's width.
    SHADOW_HEIGHT = 6
    SHADOW_ALPHA = 90
    # How far a monster's feet sink below the ground line, into its shadow.
    FEET_SINK = 1
    # Room between neighbouring monsters, picture edge to picture edge.
    MONSTER_GAP = 8
    # Statuses shown on a monster's picture, not in words (D-487).
    # Poison: the picture multiplied by one colour, then the other added.
    POISON_MULTIPLY = (140, 230, 120)
    POISON_ADD = (0, 40, 0)
    # Sleep: Zs drifting up from the head, one cycle per 1 / speed seconds.
    COLOR_SLEEP_Z = (235, 235, 255)
    COLOR_SLEEP_Z_EDGE = (20, 24, 60)
    SLEEP_Z_SPEED = 0.6
    SLEEP_Z_RISE = 4
    # Blind: sunglasses on the eyes. Each eye spot is a share of the
    # picture's width and height; a monster without one wears them over
    # its head until its spot is marked.
    EYES = {
        "boar": (0.71, 0.51),
    }

    # --- Party rows -------------------------------------------------
    # The party is listed in the HUD's right panel, Final Fantasy style:
    # one row each, the first name, the HP bar and the HP, 16 pixels
    # apart. A name with a status on it turns ``COLOR_STATUS``.
    PARTY_ROW_X = 131          # The element icons start here, past the divider.
    # The two element icons before each name, shrunk to 8 by 8, the
    # stance's boxed in yellow (D-453).
    PARTY_ICON_SIZE = 8
    PARTY_ICON_PITCH = 10      # One icon's box to the next.
    PARTY_NAME_DX = 22         # Row start to the name, past the icons.
    PARTY_ROW_TOP_Y = 163      # Centres the three rows in the HUD (Frankie, 10/18).
    PARTY_ROW_PITCH = 16
    PARTY_NAME_CHARS = 6       # A longer first name is cut.
    PARTY_BAR_DX = 72          # Row start to the bar.
    PARTY_FIGURES_DX = 98      # Row start to the HP figure.

    # --- Turn order ---------------------------------------------------
    # One bordered bar down the left of the field (D-453), Final Fantasy X
    # style: a small picture per turn, the one acting on top with a
    # yellow arrow over it, a stripe on each entry's left, blue for the
    # party and red for monsters. The monsters stand to its right.
    TURN_ICON_SIZE = 16
    TURN_STRIPE = 3            # The side's colour, left of each picture.
    TURN_BAR_X = 1
    TURN_BAR_Y = 2
    TURN_ARROW = 4             # The arrow's half height.
    FIELD_LEFT = 24            # The field's left edge, past the bar.
    COLOR_TURN_PARTY = (80, 130, 230)
    COLOR_TURN_FOE = (210, 80, 70)
    PARTY_HOP_PIXELS = 2       # A row hops this far up when its member acts.
    COLOR_HURT_NAME = (255, 90, 80)    # The name while its member is hit.

    # --- Mana --------------------------------------------------------
    # Seven pips under each HP bar, lit for each point of mana
    # (D-213 to D-220), in Mana's blue (D-366).
    PIP_WIDTH = 2
    PIP_HEIGHT = 2
    PIP_GAP = 1
    PARTY_PIPS_DY = 8          # Row top to the pips, under the bar.
    COLOR_MANA = (80, 150, 255)
    COLOR_PIP_OFF = (45, 45, 60)
    # The stroke points left this turn, in the command panel's top right.
    COLOR_POINTS = (255, 130, 130)

    # --- HP bars ----------------------------------------------------
    BAR_WIDTH = 24
    BAR_HEIGHT = 4
    BAR_TEXT_GAP = 4
    BAR_LOW_SHARE = 0.35       # Below this the bar is red.
    BAR_SPEED = 1.5            # Bars slide at this many full bars a second.
    COLOR_BAR = (90, 210, 120)
    COLOR_BAR_LOW = (230, 70, 60)
    COLOR_BAR_BACK = (20, 20, 20)

    # --- Motion -----------------------------------------------------
    SHAKE_SECONDS = 0.35
    SHAKE_PIXELS = 3
    SHAKE_SPEED = 55.0         # How fast the jolt swings side to side.
    FLASH_SECONDS = 0.24
    FLASH_BLINK_HZ = 12.0
    LUNGE_SECONDS = 0.28
    LUNGE_PIXELS = 8           # A monster steps this far toward you.
    FADE_SECONDS = 0.6         # A defeated monster takes this long to go.
    FADE_SINK_PIXELS = 4
    BOB_PIXELS = 1             # Idle sway, so nothing stands dead still.
    BOB_SPEED = 2.6
    BOB_PHASE_STEP = 1.7       # Keeps neighbours from swaying in step.

    # --- Floating numbers -------------------------------------------
    FLOAT_SECONDS = 1.0
    FLOAT_RISE_PIXELS = 16
    FLOAT_FADE_SHARE = 0.3     # The last part of its life spent fading.
    FLOAT_SPRITE_HEIGHT = 0.95 # Starts this far up a monster picture.
    FLOAT_PARTY_RISE_START = 2
    FLOAT_STACK_STEP = 8       # A second number starts this much higher.
    FLOAT_STACK_WINDOW = 0.5
    COLOR_PARTY_DAMAGE = (255, 120, 110)
    COLOR_HEAL = (120, 230, 140)
    COLOR_STATUS = (200, 150, 245)
    # Ata's own color is black, which vanishes on a dark field.
    COLOR_ATA_WORD = (190, 190, 200)

    # --- Target arrow -----------------------------------------------
    CURSOR_SIZE = 4
    CURSOR_GAP = 2


class BestiarySettings:
    """Layout of the bestiary, one creature per page, in screen pixels.

    The name and the page count on the top row, the picture under them,
    a row of facts, then a block of text rows (the description, where
    it is found, its moves) that scrolls when it is longer than the
    block. Left and right turn the page; up and down scroll.
    """

    NAME_POS = (8, 8)
    COUNT_RIGHT_X = 248        # The "3/8" ends here.
    PICTURE_CENTER_X = 128
    PICTURE_GROUND_Y = 100     # The picture's feet.
    FACTS_Y = 110
    FACT_GAP = 8               # Between one fact and the next on the row.
    PANEL_X = 8
    PANEL_WIDTH = 240          # 30 letters.
    TEXT_TOP_Y = 128
    TEXT_ROWS = 5              # Rows of the scrolling block.
    SCROLL_MARK_X = 248        # The small triangles saying there is more.
    COLOR_BODY_TEXT = (215, 215, 215)
    COLOR_BEAST = (200, 170, 120)
    COLOR_ATA_WORD = (190, 190, 200)
    # Columns of a move's row, in letters from the panel's left edge:
    # the name, the kind, the element, the effect; the share of turns it
    # is used ends the row.
    MOVE_NAME_CHARS = 10
    MOVE_KIND_COL = 10
    MOVE_ELEMENT_COL = 15
    MOVE_EFFECT_COL = 20
    MOVE_USED_COL = 27


class DebugSettings:
    """Settings related to debugging features."""


class SaveSettings:
    """Save-system tunables."""

    SAVES_DIR = os.path.join(os.path.dirname(__file__), 'saves')
    MAX_SAVE_SLOTS = 3
    AUTOSAVE_SLOT_ID = 0


class StatSettings:
    """How elements turn into stats. See ``core/stats.py``.

    The values come from the shared battle file, so they are the same
    in the browser game. Every number is a placeholder; the shape
    (elements decide stats) is the ruling.
    """

    BASE_POINTS = _STATS["base"]                # Every stat starts here.
    TRIANGLE_BONUS = _STATS["triangle_bonus"]   # Per element, to both stats of its triangle.
    JOB_BONUS = _STATS["job_bonus"]             # Per element, to the two stats of its job.
    HP_PER_POINT = _STATS["hp_per_point"]       # Max HP is the HP score x this.
    STANCE_RULE = _STATS["stance_rule"]         # "percent" (D-508), "move" (D-365) or "add" (D-257).
    STANCE_BONUS = _STATS["stance_bonus"]       # The "add" rule's bonus.
    STANCE_PERCENT = _STATS.get("stance_percent", 0.25)  # The "percent" rule's boost (D-508).


class LoadoutSettings:
    """Ability slots (D-318 to D-320): three per mana row, seven rows.

    The numbers are the shared file's ``rules.slots``.
    """

    PER_ROW = _RULES["slots"]["per_tier"]
    ROWS = _RULES["slots"]["tiers"]
    TURNS_PER_ROW = _RULES["slots"]["turns_per_tier"]


class BattleSettings:
    """Gameplay tunables for battles.

    Everything read from ``_RULES`` comes from the shared battle file
    and so is the same number in the browser game; change it there.
    The plain literals below are this game's alone.

    Waits are in turn-counter units: after acting, a combatant's
    counter goes up by the wait, and the lowest counter acts next.
    """

    # This game only: the browser test has no potions.
    STARTING_POTIONS = 5
    POTION_HEAL_AMOUNT = 35

    # The plain Attack, and Kailo's counter kick.
    ATTACK_POWER = _RULES["attack_power"]
    # Damage rolls within +/- this fraction.
    DAMAGE_JITTER = _RULES["damage_jitter"]

    # Physical damage taken while defending.
    DEFEND_MULTIPLIER = _RULES["defend_multiplier"]
    # Physical damage a guard takes for an ally, then the extra factor
    # when the guarded hit is fire, and when it is nature.
    GUARD_MULTIPLIER = _RULES["guard_multiplier"]
    GUARD_AHI_MULTIPLIER = _RULES["guard_ahi_multiplier"]
    GUARD_LAU_MULTIPLIER = _RULES["guard_lau_multiplier"]

    STATUS_HIT_CHANCE = _RULES["status_hit_chance"]    # A status takes hold.
    BLIND_MISS_CHANCE = _RULES["blind_miss_chance"]    # A blind physical hit misses.
    SLEEP_TURNS = _RULES["sleep_turns"]                # Turns a sleeper loses.
    POISON_RATE = _RULES["poison_rate"]                # Share of max HP per turn.
    HASTE_ACTIONS = _RULES["haste_actions"]            # Actions at a shorter wait.
    HASTE_WAIT_MULTIPLIER = _RULES["haste_wait_multiplier"]

    # Mana (D-213 to D-220) and fatigue (D-328, D-329), as the browser
    # battle plays them: every number is in the shared file's
    # ``rules.warmup``. Mana is a meter of up to 7. An Attack is a chain
    # of strokes on one enemy, up to 7 points a turn; a stroke that
    # lands builds its points in mana. A technique costs its ``warmup``
    # in mana. The wait after a turn is what the turn built: each
    # stroke its points, anything else 1, Defend 1 less.
    _WARM = _RULES["warmup"]
    MANA_CAP = _WARM["cap"]
    MANA_START = _WARM["start"]
    DEFEND_MANA = _WARM["defend"]          # Mana Defend builds.
    STANCE_MANA = _WARM["form"]            # Mana a stance switch builds (D-285).
    FIGHTERS = 3                           # The rest of the party waits on the bench (D-196).
    COMBO_MANA = _WARM["combo"]            # Mana a combo takes from each partner.
    WEAPON_MANA = 1                        # Mana changing weapons builds (D-455).
    # Escape (D-455): this chance, moved by the runner's Speed against the
    # fastest monster's, kept between the two limits. Claude's numbers.
    ESCAPE_CHANCE = 0.5
    ESCAPE_PER_SPEED = 0.05
    ESCAPE_LIMITS = (0.1, 0.9)
    DODGE_MANA = _WARM["dodge_gain"]       # Mana for dodging or blocking a blow.
    STROKE_POINTS = _WARM["strokes"]["points"]
    STROKE_STEADY = _WARM["strokes"]["steady"]   # Each stroke landed adds this to the next one's chance.
    STROKES: dict = {
        "light": _WARM["strokes"]["light"],
        "medium": _WARM["strokes"]["medium"],
        "strong": _WARM["strokes"]["strong"],
    }
    AUTO_STROKES: tuple = tuple(_WARM["strokes"]["auto"])  # A monster's chain.
    STROKE_POWER = _WARM["attack_power"]   # Times a stroke's own power.
    STROKE_WAIT = _WARM["wait"]["attack"]  # Fatigue per stroke point.
    FATIGUE_OTHER = _WARM["fatigue"]["other"]
    FATIGUE_DEFEND = _WARM["fatigue"]["defend"]
    FATIGUE_LEAST = _WARM["fatigue"]["least"]
    FATIGUE_DEFEND_LEAST = _WARM["fatigue"]["defend_least"]
    # Accuracy and Evasion: 1% a point over the base of 10. Vitality
    # blocks a blow for half damage.
    PER_ACCURACY = _WARM["accuracy"]["per_accuracy"]
    EVADE_BASE = _WARM["evade"]["base"]
    PER_EVASION = _WARM["evade"]["per_evasion"]
    BLOCK_BASE = _WARM["block"]["base"]
    PER_VITALITY = _WARM["block"]["per_vitality"]
    BLOCK_MULTIPLIER = _WARM["block"]["multiplier"]
    # The turn-order preview's guess at everyone else's next wait.
    PREVIEW_WAIT = 3

    MONSTER_HP_SCALE = _RULES["monster_hp_scale"]        # On a monster's authored HP.
    MONSTER_POWER_SCALE = _RULES["monster_power_scale"]  # On a monster move's power.

    TURN_ORDER_LENGTH = 7         # Upcoming turns shown after the current one.
    # Seconds a finished line of battle narration stays up before the
    # scene advances it on its own. Confirm still advances at once.
    NARRATION_HOLD_SECONDS = 0.9
    # Seconds between one stroke and the next as they play out. Strokes
    # have no line of their own, so this is their rhythm.
    STROKE_BEAT_SECONDS = 0.3


class UISettings:
    """Tunables for in-game UI presentation, on the 256 by 224 screen."""

    # The message window and the battle HUD: the bottom 80 pixels, five
    # map tiles tall. Eight pixels of padding leaves four rows of text.
    TEXT_BOX_HEIGHT = 80
    TEXT_BOX_PADDING = 8
    TEXT_BOX_BORDER_THICKNESS = 2
    # Every window's corners are rounded this many pixels (D-457).
    WINDOW_CORNER_RADIUS = 4
    # A window's inside shades from the first colour at the top to the
    # second at the bottom: deep ocean, not black (D-451). Claude's pick.
    WINDOW_TOP = (28, 74, 120)
    WINDOW_BOTTOM = (8, 26, 58)

    # Portraits are pixel faces in a ``PORTRAIT_SIZE`` frame, three tiles
    # square (D-449), on the party screen. A smaller face sits centred
    # in the frame, unscaled, until it is redrawn; a bigger one is cut
    # to the frame's middle. Nothing is ever resized. ``PORTRAIT_GAP``
    # is the space between the frame's right edge and the text beside
    # it. Text is placed by the top of its letters, so the frame and the
    # name share a top edge with no nudge.
    PORTRAIT_SIZE = 48
    PORTRAIT_GAP = 8
    PORTRAIT_Y_OFFSET = 0
    # The element line sits one text row under the name.
    ROSTER_ELEMENT_LINE_Y_OFFSET = 16

    # The element icons are 18 pixels square on disk, two more than a
    # tile; they are drawn as they are, never resized. Beside an 8 pixel
    # word an icon is centred on the word, which puts its top
    # ``ELEMENT_ICON_Y_OFFSET`` above the word's top.
    ELEMENT_ICON_SIZE = 18
    ELEMENT_ICON_GAP = 2
    ELEMENT_ICON_WORD_GAP = 4
    ELEMENT_ICON_Y_OFFSET = -5
    ELEMENT_ICON_INLINE_Y_OFFSET = -5

    # The battle HUD splits here: commands, or the narration, on the
    # left; the party's names, bars and HP on the right, the way Final
    # Fantasy lays out its window. A submenu (abilities, items) takes
    # the whole width while it is open, as its magic list does.
    COMMAND_PANEL_WIDTH = 128

    # Rows of the battle menus sit one text row apart.
    COMMAND_MENU_ROW_HEIGHT = 16
    # The stroke points left, a standing bar at the command panel's right edge.
    POINTS_BAR_WIDTH = 4
    POINTS_BAR_GAP = 1
    POINTS_BAR_SPENT = (60, 60, 60)
    ABILITY_MENU_ROW_HEIGHT = 16
    # The Ability menu is a grid (D-450): the mana row's number, then
    # three names of at most 8 letters, Final Fantasy's spell menu.
    ABILITY_NAME_CHARS = 8
    ABILITY_LABEL_WIDTH = 16   # The row's number to its first name.
    ABILITY_COL_WIDTH = 72     # One name to the next.
    # Short names for the grid, where the full name will not fit in 8
    # letters. Claude's first picks; rename freely. Anything not here is
    # cut to 8.
    MOVE_SHORT_NAMES: dict = {
        "Flame Kick": "FlamKick",
        "Counter Guard": "Counter",
        "Cure Blind": "CureBlnd",
        "Cure Sleep": "CureSlp",
        "Cure Poison": "CurePsn",
        "Shaka's Light": "ShakaLt",
        "Purification": "Purify",
        "Shadow Blast": "ShdwBlst",
        "Spirit Blast": "SprtBlst",
        "Triple Trouble": "TripleTr",
    }

    # The battle turn-order strip across the top of the battle screen,
    # and the help line under it (the highlighted action's wait and
    # numbers) while a command is being chosen.
    TURN_STRIP_X = 8
    TURN_STRIP_Y = 4
    TURN_STRIP_GAP = 8    # Pixels between one name and the next.

    TYPEWRITER_CHARS_PER_SECOND = 60

    MENU_CURSOR_BLINK_HZ = 2.0
    # Added to a text row to give the pitch of a menu's rows: 0 is one
    # row (16 pixels) per item.
    MENU_ITEM_SPACING = 0
    TITLE_SCREEN_MENU_ITEM_SPACING = 0
    # The cursor's tip sits this far left of a menu row's text.
    MENU_LABEL_OFFSET = 6

    TITLE_SCREEN_HEADING_X = 56
    TITLE_SCREEN_HEADING_Y = 56
    TITLE_SCREEN_MENU_X = 96
    TITLE_SCREEN_MENU_TOP_Y = 128


class ConfirmSettings:
    """The NO / YES box (``core/scenes/confirm_scene.py``) and its words.

    Follows Dungeon Digger's quit dialog: NO first, cancel means NO,
    and every string lives here rather than in the scene.
    """

    NO_INDEX = 0                # NO sits on the left and starts selected.
    YES_INDEX = 1
    LABEL_NO = "No"
    LABEL_YES = "Yes"

    BOX_WIDTH = 160             # Pixels; the warning wraps inside it.
    PADDING = 8                 # Pixels inside the border, top and bottom.
    BORDER_THICKNESS = 2        # Matches the text box border.
    OPTION_GAP = 48             # Pixels between the centres of NO and YES.
    DIM_ALPHA = 160             # Out of 255; dims the scene underneath.
    COLOR_WARNING = (255, 120, 110)   # The "what is lost" line.

    # Esc, the window's X, or Quit on the title screen.
    TITLE_QUIT_GAME = "Quit game?"
    BODY_QUIT_GAME = ""
    # Esc during play, and Quit to Title in the pause menu.
    TITLE_QUIT_TO_TITLE = "Quit to title?"
    BODY_UNSAVED = "Unsaved progress will be lost"
    # The window's X during play closes the program, not just the game.
    TITLE_CLOSE_WINDOW = "Quit game?"


class GridSettings:
    """Tile dimensions for the overworld grid."""

    TILE_SIZE = 16  # Pixels per overworld tile (D-444).


class OverworldSettings:
    """Cell-area layout for the overworld scene.

    One cell is a fixed grid of tiles that fills the whole screen, 16
    across and 14 down (D-444). Crossing the edge swaps to the matching
    neighbor cell in ``WORLD_LAYOUT`` and snaps the sprite to its entry
    tile. Screen-locked -- no scrolling camera at this layer. The
    message window draws over the bottom four rows when it has text.
    """

    COLS = 16  # Tiles wide per cell.
    ROWS = 14  # Tiles tall per cell.
    PIXEL_W = COLS * GridSettings.TILE_SIZE   # 256 px.
    PIXEL_H = ROWS * GridSettings.TILE_SIZE   # 224 px.
    X = 0
    Y = 0

    # Wall character recognised by World.is_wall. Walls block the
    # player's step; the cell renderer draws them as coconut palms.
    WALL_CHAR = "#"
    WATER_CHAR = "~"  # Impassable.
    SAND_CHAR = "_"   # Walkable; paths and beaches.
    FLOOR_CHAR = "."  # Walkable default, grass.

    # The picture for each cell character: a list of choices, each a
    # (file, tile index) pair from Mini World Sprites (CC0) in
    # ``AssetPaths.TILES_DIR``, counting 16 pixel tiles left to right.
    # A tile with several choices picks one by its position, so the
    # same map always looks the same. A wall is a palm drawn over grass.
    TILE_PICTURES: dict = {
        FLOOR_CHAR: [("Ground/Grass.png", 1)] * 6
        + [("Ground/TexturedGrass.png", 1), ("Ground/TexturedGrass.png", 2)],
        SAND_CHAR: [("Ground/Grass.png", 3)],
        WATER_CHAR: [("Ground/Shore.png", 4)],
        WALL_CHAR: [("Nature/CoconutTrees.png", n) for n in (2, 3, 4, 5)],
    }
    # What is drawn under a character whose picture has see-through parts.
    TILE_UNDER: dict = {WALL_CHAR: FLOOR_CHAR}


class EncounterSettings:
    """Step-counted random-encounter parameters for the overworld.

    Pass-2 first cut uses one global rate; Pass-2 follow-up moves to
    per-cell tables (rate + min-quiet + enemy list) read from the cell
    data once cells migrate to JSON. The eligibility window (the first
    ``MIN_QUIET_STEPS`` steps after a fresh load or a finished battle)
    guarantees the player isn't immediately re-engaged.
    """

    # Probability per *eligible* step (after the quiet window) that an
    # encounter fires. 0.20 means ~5 steps on average past the quiet
    # window before a hit; the Layer-1 production value will be lower.
    RATE_PER_STEP = 0.20
    # Minimum number of steps after spawn / after the last battle
    # before any encounter can roll. Pure-quiet pacing window.
    MIN_QUIET_STEPS = 4


class OverworldPlayerSettings:
    """Tunable values for the overworld player sprite.

    A walking character is one tile wide and two tall (D-444): it stands
    on its tile and rises into the one above. The sheet named in
    ``AssetPaths.PLAYER_SHEET`` has one row per facing and seven frames
    per row, the first standing and the other six a walk cycle.
    """

    STEP_DURATION_MS = 150            # Walk animation duration per tile.
    COLOR = ColorSettings.YELLOW      # Stand-in fill when the sheet is missing.
    WIDTH = GridSettings.TILE_SIZE
    HEIGHT = 2 * GridSettings.TILE_SIZE
    # Row of the sheet for each facing, as (dx, dy).
    SHEET_ROWS: dict = {(0, 1): 0, (-1, 0): 1, (1, 0): 2, (0, -1): 3}
    # A sheet frame is bigger than the figure, which is about 16 by 33
    # (Memao's pack, D-452), so arms and hair have room. The frame is
    # centred on the tile, its bottom row on the tile's bottom.
    FRAME_WIDTH = 32
    FRAME_HEIGHT = 40
    WALK_FRAMES = 6                   # Frames 1 to 6 of each row.
    FRAMES_PER_STEP = 3               # Shown while crossing one tile.
    SPAWN_COL = OverworldSettings.COLS // 2  # Center column on first spawn.
    SPAWN_ROW = OverworldSettings.ROWS // 2  # Center row on first spawn.
