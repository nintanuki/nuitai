"""The desktop game's emulator tools, for testing (Frankie, 10/23).

The desktop pygame game acts like an emulator: the controller is
everything a Super Nintendo has, and the keyboard's hotkeys are the
emulator's. None of this is in the browser build or on the cartridge.

    F1   freeze the game and open the file menu (Reset, Save State, Load State)
    ~    fast-forward while held
    F2   save a state
    F4   load it

A state is the whole running game, frozen the way an emulator freezes a
console's memory: every scene on the stack (the field, a menu, a story
scene halfway through, a fight), the party with its flags, bag, steps,
time played and date, the room and where everyone stands. It is one
file, ``saves/state.pickle``, beside the save slots, which it never
touches. A state is pickled, so it fits the code that wrote it: after
the game's code changes, an old state may fail to load, and the game
says so and keeps going.
"""

from __future__ import annotations

import importlib
import io
import marshal
import os
import pickle
import sys
import types
from typing import TYPE_CHECKING

import pygame

from settings import ColorSettings, SaveSettings
from ui import text_renderer

if TYPE_CHECKING:
    from main import GameManager


STATE_FILE = "state.pickle"
# Bumped when what a state holds changes shape, so an old one is refused cleanly.
STATE_VERSION = 1
# ~ held: the world runs this many steps a frame.
FAST_FORWARD = 4
# How long "State saved" stays up, in seconds.
NOTE_SECONDS = 1.5


def state_path() -> str:
    """Where the one state lives, beside the save slots."""
    return os.path.join(SaveSettings.SAVES_DIR, STATE_FILE)


# ---------------------------------------------------------------------------
# SAVE STATE / LOAD STATE
# ---------------------------------------------------------------------------

def _surface(raw: bytes, size: tuple[int, int], alpha: bool, colorkey) -> pygame.Surface:
    """Rebuild a pickled picture."""
    surface = pygame.image.frombytes(raw, size, "RGBA")
    if not alpha:
        surface = surface.convert() if pygame.display.get_surface() else surface.copy()
    if colorkey is not None:
        surface.set_colorkey(colorkey)
    return surface


def _function(code: bytes, module: str, name: str, free: int) -> types.FunctionType:
    """Rebuild a lambda or a nested function, its closure still empty."""
    cells = tuple(types.CellType() for _ in range(free))
    return types.FunctionType(
        marshal.loads(code), vars(importlib.import_module(module)), name, None, cells or None
    )


def _fill_function(function: types.FunctionType, state) -> None:
    """Give a rebuilt function its defaults, closure and attributes."""
    defaults, kwdefaults, contents, attributes = state
    function.__defaults__ = defaults
    function.__kwdefaults__ = kwdefaults
    for cell, (filled, value) in zip(function.__closure__ or (), contents):
        if filled:
            cell.cell_contents = value
    function.__dict__.update(attributes)


def _importable(function: types.FunctionType) -> bool:
    """True if pickle can find ``function`` again by its module and name."""
    owner = sys.modules.get(function.__module__)
    found = owner
    for part in function.__qualname__.split("."):
        found = getattr(found, part, None)
    return found is function


class _StatePickler(pickle.Pickler):
    """Pickle the running game: the machine itself (the window, the sound,
    the data on disk) stays as it is; pictures, lambdas and modules, which
    plain pickle cannot write, go by hand."""

    def __init__(self, file, machine: dict[int, str]) -> None:
        super().__init__(file, protocol=5)
        self.machine = machine

    def persistent_id(self, obj):
        return self.machine.get(id(obj))

    def reducer_override(self, obj):
        if isinstance(obj, pygame.Surface):
            alpha = bool(obj.get_flags() & pygame.SRCALPHA)
            return _surface, (pygame.image.tobytes(obj, "RGBA"), obj.get_size(), alpha,
                              obj.get_colorkey())
        if isinstance(obj, types.FunctionType) and not _importable(obj):
            contents = []
            for cell in obj.__closure__ or ():
                try:
                    contents.append((True, cell.cell_contents))
                except ValueError:
                    contents.append((False, None))
            free = len(obj.__code__.co_freevars)
            return (_function, (marshal.dumps(obj.__code__), obj.__module__, obj.__name__, free),
                    (obj.__defaults__, obj.__kwdefaults__, tuple(contents), dict(obj.__dict__)),
                    None, None, _fill_function)
        if isinstance(obj, types.ModuleType):
            return importlib.import_module, (obj.__name__,)
        return NotImplemented


class _StateUnpickler(pickle.Unpickler):
    """Read a state back, plugging it into this machine."""

    def __init__(self, file, machine: dict[str, object]) -> None:
        super().__init__(file)
        self.machine = machine

    def persistent_load(self, pid):
        return self.machine[pid]


def _machine(gm: "GameManager") -> dict[str, object]:
    """The parts of the running program a state leaves alone."""
    return {
        "gm": gm, "audio": gm.audio, "data": gm.data, "gamepads": gm.gamepads,
        "screen": gm.screen, "window": gm.window, "clock": gm.clock, "crt": gm.crt,
    }


def snapshot(gm: "GameManager") -> bytes:
    """The whole running game as bytes."""
    machine = {id(part): name for name, part in _machine(gm).items() if part is not None}
    buffer = io.BytesIO()
    _StatePickler(buffer, machine).dump({
        "version": STATE_VERSION,
        "stack": gm.scene_stack._stack,
        "party": gm.party,
        "song": gm.audio.screen,
    })
    return buffer.getvalue()


def restore(gm: "GameManager", raw: bytes) -> None:
    """Put the game back exactly as ``snapshot`` found it.

    Raises if the state cannot be read (made by older code, or broken).
    """
    state = _StateUnpickler(io.BytesIO(raw), _machine(gm)).load()
    if state.get("version") != STATE_VERSION:
        raise ValueError("state from another version")
    # No on_exit or on_enter: the scenes are not leaving or arriving, they
    # are being swapped for themselves a moment ago.
    gm.scene_stack._stack = state["stack"]
    gm.party = state["party"]
    song = state["song"]
    if song != gm.audio.screen:
        if song is None:
            if pygame.mixer.get_init():
                gm.audio.stop_music()
        else:
            gm.audio.play_screen(song)


def save_state(gm: "GameManager") -> str:
    """F2: write the state; return the note to show."""
    try:
        raw = snapshot(gm)
    except Exception as error:  # noqa: BLE001 - a test tool reports, never crashes the game
        sys.stderr.write(f"Could not save the state: {error!r}\n")
        return "Could not save state"
    os.makedirs(SaveSettings.SAVES_DIR, exist_ok=True)
    with open(state_path(), "wb") as f:
        f.write(raw)
    return "State saved"


def load_state(gm: "GameManager") -> str:
    """F4: read the state back; return the note to show."""
    if not os.path.isfile(state_path()):
        return "No state saved"
    with open(state_path(), "rb") as f:
        raw = f.read()
    try:
        restore(gm, raw)
    except Exception as error:  # noqa: BLE001
        sys.stderr.write(f"Could not load the state: {error!r}\n")
        return "Could not load state"
    return "State loaded"


# ---------------------------------------------------------------------------
# THE F1 MENU
# ---------------------------------------------------------------------------

class FileMenu:
    """The emulator's GAME menu, drawn over the frozen game.

    It looks like an emulator's own menu, flat gray with a red bar, not
    like the game's blue windows, so it reads as outside the game.
    Keyboard (up, down, Enter; F1 or Esc closes) and mouse.
    """

    ITEMS = ("Reset", "Save State", "Load State", "Resume")
    TITLE = "GAME"
    X, Y = 4, 4
    PAD = 3
    ROW = 11

    BG = (192, 192, 192)
    EDGE = (64, 64, 64)
    LIGHT = (240, 240, 240)
    BAR = (160, 0, 64)
    INK = (0, 0, 0)
    INK_ON_BAR = (255, 255, 255)

    def __init__(self) -> None:
        self.cursor = 0
        # Wide enough for the longest item, with a margin each side.
        self.width = max(text_renderer.text_width(item) for item in self.ITEMS) + 10

    def rows(self) -> list[pygame.Rect]:
        """Each item's box on the 256 by 224 screen."""
        top = self.Y + self.ROW + self.PAD
        return [pygame.Rect(self.X + 2, top + i * self.ROW, self.width - 4, self.ROW)
                for i in range(len(self.ITEMS))]

    def frame(self) -> pygame.Rect:
        return pygame.Rect(self.X, self.Y, self.width,
                           self.ROW + self.PAD * 2 + self.ROW * len(self.ITEMS))

    def item_at(self, pos: tuple[int, int]) -> int | None:
        """The item under a point on the game screen, or None."""
        return next((i for i, row in enumerate(self.rows()) if row.collidepoint(pos)), None)

    def handle_key(self, key: int) -> str | None:
        """Move the cursor; return the item chosen, "Resume" to close, or None."""
        if key in (pygame.K_F1, pygame.K_ESCAPE):
            return "Resume"
        if key in (pygame.K_UP, pygame.K_w):
            self.cursor = (self.cursor - 1) % len(self.ITEMS)
        elif key in (pygame.K_DOWN, pygame.K_s):
            self.cursor = (self.cursor + 1) % len(self.ITEMS)
        elif key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            return self.ITEMS[self.cursor]
        return None

    def render(self, surface: pygame.Surface) -> None:
        frame = self.frame()
        pygame.draw.rect(surface, self.BG, frame)
        pygame.draw.rect(surface, self.EDGE, frame, 1)
        # The title strip, like a menu bar.
        strip = pygame.Rect(frame.x, frame.y, frame.w, self.ROW + 1)
        pygame.draw.rect(surface, self.EDGE, strip)
        self._write(surface, self.TITLE, frame.x + 4, frame.y + 2, self.LIGHT)
        for i, (item, row) in enumerate(zip(self.ITEMS, self.rows())):
            ink = self.INK
            if i == self.cursor:
                pygame.draw.rect(surface, self.BAR, row)
                ink = self.INK_ON_BAR
            if item == "Resume":
                # A rule above Resume, as an emulator's menu splits its groups.
                pygame.draw.line(surface, self.EDGE, (row.x, row.y), (row.right - 1, row.y))
            self._write(surface, item, row.x + 2, row.y + 2, ink)

    @staticmethod
    def _write(surface: pygame.Surface, text: str, x: int, y: int, color) -> None:
        surface.blit(text_renderer.render_line(text, color), (x, y - text_renderer.ink_top()))


def draw_note(surface: pygame.Surface, text: str) -> None:
    """A short note in the top left corner, outside the game's own text box."""
    width = text_renderer.text_width(text)
    pygame.draw.rect(surface, ColorSettings.BLACK, (1, 1, width + 4, 10))
    surface.blit(text_renderer.render_line(text, ColorSettings.WHITE),
                 (3, 2 - text_renderer.ink_top()))

