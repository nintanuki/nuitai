"""The story bar across the top of the Workshop's map (Frankie, 11/5).

A slider through the main story's moments and a checkbox for every
switch, over a ``workshop_story.Story``. It sits between the toolbar and
the room, ``STORY_H`` layout pixels tall, and is drawn at the window's own
size, not the layout's, so its small words stay sharp: the Workshop's
pixel font is eight pixels a letter, and fifteen switches would not fit.

``press``, ``drag`` and ``tip`` take points on the window, as the mouse
gives them, and ``draw`` draws straight onto the window.
"""

from __future__ import annotations

import pygame

from workshop_story import MOMENTS, Story

STORY_H = 36          # layout pixels: a row for the slider, three for the switches
SLIDER_ROW = 12
SWITCH_ROW = 8
BACKGROUND = (20, 24, 36)
EDGE = (60, 66, 90)
TRACK = (90, 96, 120)
YELLOW = (255, 210, 74)        # the main story, as the map's yellow marks
DIM = (120, 120, 120)
WHITE = (230, 230, 230)
# One color per group of switches, on the box and the words (Frankie reads by color).
GROUP_COLORS = {
    "melia": (255, 140, 190),
    "hina": (110, 190, 255),
    "maika": (140, 220, 120),
    "village": (255, 170, 90),
    "other": (190, 190, 190),
}


class StoryBar:
    """The slider and the switches, laid out for one window size."""

    def __init__(self, story: Story) -> None:
        self.story = story
        self.dragging = False
        self._fonts: dict[int, pygame.font.Font] = {}
        self._layout_for: tuple[int, int, int] | None = None
        self._track: tuple[int, int, int] = (0, 0, 0)    # x0, x1, y on the window
        self._switch_rects: list[tuple[str, pygame.Rect]] = []
        self.rect = pygame.Rect(0, 0, 0, 0)

    def _font(self, scale: int) -> pygame.font.Font:
        if scale not in self._fonts:
            pygame.font.init()
            self._fonts[scale] = pygame.font.SysFont("segoeui,arial,helvetica", 5 * scale + 2)
        return self._fonts[scale]

    def layout(self, width: int, top: int, scale: int) -> None:
        """Place the slider and the switches in a band ``width`` window pixels wide at ``top``."""
        if self._layout_for == (width, top, scale):
            return
        self._layout_for = (width, top, scale)
        self.rect = pygame.Rect(0, top, width, STORY_H * scale)
        font = self._font(scale)
        self._track = (44 * scale, width - 118 * scale, top + SLIDER_ROW * scale // 2)
        self._switch_rects = []
        x, y = 4 * scale, top + SLIDER_ROW * scale
        box = 6 * scale
        for flag, name, _group in self.story.switches:
            w = box + 2 * scale + font.size(name)[0]
            if x + w > width - 4 * scale and x > 4 * scale:
                x, y = 4 * scale, y + SWITCH_ROW * scale
            self._switch_rects.append((flag, pygame.Rect(x, y, w, SWITCH_ROW * scale)))
            x += w + 7 * scale

    def rows_needed(self) -> int:
        """How many switch rows the last layout used (the tests check they fit)."""
        if not self._switch_rects:
            return 0
        tops = {rect.y for _flag, rect in self._switch_rects}
        return len(tops)

    # --- the mouse ---------------------------------------------------------------

    def _moment_at(self, x: int) -> int:
        x0, x1, _y = self._track
        if len(MOMENTS) == 1 or x1 <= x0:
            return 0
        return round((min(max(x, x0), x1) - x0) * (len(MOMENTS) - 1) / (x1 - x0))

    def _tick_x(self, index: int) -> int:
        x0, x1, _y = self._track
        return x0 + (x1 - x0) * index // max(1, len(MOMENTS) - 1)

    def press(self, pos: tuple[int, int]) -> bool:
        """A left press on the window; True if it was on the bar."""
        if not self.rect.collidepoint(pos):
            return False
        if pos[1] < self.rect.y + self.rect.h * SLIDER_ROW // STORY_H:
            self.dragging = True
            self.story.set_moment(self._moment_at(pos[0]))
            return True
        for flag, rect in self._switch_rects:
            if rect.collidepoint(pos):
                self.story.toggle(flag)
        return True

    def drag(self, pos: tuple[int, int]) -> None:
        if self.dragging:
            self.story.set_moment(self._moment_at(pos[0]))

    def release(self) -> None:
        self.dragging = False

    def tip(self, pos: tuple[int, int]) -> str:
        """What the bar says under the mouse, for the Workshop's bottom bar."""
        if not self.rect.collidepoint(pos):
            return ""
        if pos[1] < self.rect.y + self.rect.h * SLIDER_ROW // STORY_H:
            return f"Story: {MOMENTS[self._moment_at(pos[0])]['name']}. Drag to move through the story"
        for flag, rect in self._switch_rects:
            if rect.collidepoint(pos):
                name = next(n for f, n, _g in self.story.switches if f == flag)
                if self.story.locked(flag):
                    return f"{name}: always on by {self.story.name}"
                return f"{name}: click to turn {'off' if flag in self.story.on else 'on'}"
        return ""

    # --- drawing -----------------------------------------------------------------

    def draw(self, surface: pygame.Surface, top: int, scale: int, mouse: tuple[int, int] | None = None) -> None:
        """Draw the bar onto the window, ``top`` window pixels down."""
        self.layout(surface.get_width(), top, scale)
        font = self._font(scale)
        pygame.draw.rect(surface, BACKGROUND, self.rect)
        pygame.draw.line(surface, EDGE, (0, self.rect.bottom - 1), (self.rect.w, self.rect.bottom - 1), max(1, scale // 2))
        x0, x1, y = self._track
        label = font.render("STORY", True, YELLOW)
        surface.blit(label, (4 * scale, y - label.get_height() // 2))
        pygame.draw.line(surface, TRACK, (x0, y), (x1, y), max(1, scale))
        for index in range(len(MOMENTS)):
            tx = self._tick_x(index)
            color = YELLOW if index <= self.story.moment else TRACK
            pygame.draw.line(surface, color, (tx, y - 2 * scale), (tx, y + 2 * scale), max(1, scale // 2 + 1))
        pygame.draw.line(surface, YELLOW, (x0, y), (self._tick_x(self.story.moment), y), max(1, scale))
        knob = self._tick_x(self.story.moment)
        pygame.draw.circle(surface, YELLOW, (knob, y), 3 * scale)
        pygame.draw.circle(surface, BACKGROUND, (knob, y), scale)
        name = font.render(f"{self.story.moment + 1}. {self.story.name}", True, YELLOW)
        surface.blit(name, (x1 + 8 * scale, y - name.get_height() // 2))
        for (flag, rect), (_flag, words, group) in zip(self._switch_rects, self.story.switches):
            color = GROUP_COLORS.get(group, GROUP_COLORS["other"])
            locked, on = self.story.locked(flag), self.story.is_on(flag)
            shade = tuple(c // 2 for c in color) if locked else color
            box = pygame.Rect(rect.x, rect.centery - 3 * scale, 6 * scale, 6 * scale)
            pygame.draw.rect(surface, shade, box, max(1, scale // 2 + 1))
            if on:
                pygame.draw.rect(surface, shade, box.inflate(-3 * scale, -3 * scale))
            text = font.render(words, True, shade if not on or locked else color)
            if mouse is not None and rect.collidepoint(mouse) and not locked:
                pygame.draw.line(surface, color, (box.right + 2 * scale, rect.bottom - scale),
                                 (rect.right, rect.bottom - scale), 1)
            surface.blit(text, (box.right + 2 * scale, rect.centery - text.get_height() // 2))
