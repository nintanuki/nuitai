"""The Workshop's dialogue editor: every line of dialogue in the game, to read and change (Frankie, 10/31).

L in the Workshop opens it, or Tools, Dialogue editor; a double click (or
D) on a person opens it at what that person says (Frankie, 11/2). On the left, the scenes from the story
scripts (``game/shared/story*.md``) by their names, and last the Field
lines (``story-field.md``: Noelani's, the garden's, the hens'...), then the
people in each room and the questions they answer (kept in the room and
menu files, ``core/dialogue_villagers.py``). Pick
one and its rows show numbered, in the order the game plays them: who
speaks, in their element's color, the line, and any condition. Stage
directions are there too, dim, so it is clear where in the scene a line
falls; only the lines are edited.

Click a row to edit it in the box under the list: its words, its
speaker (the scene's cast to pick from), its condition. Add before and
Add after put a new line next to any row, a stage direction too, and
the game plays it right there: after the direction above it finishes,
before the one below starts. Delete takes a line out, Undo steps back. Save writes only the lines that changed, and first
checks the file: changed on disk since it was opened, the two are merged
when they touch different lines, or both versions are shown to choose
between (``core/dialogue_editor.py``). Play starts the game at the scene.

tkinter, as the words window (``workshop_dialogue.py``): it shares that
window's root and is kept awake by the same ``pump`` in the Workshop's loop.
"""

from __future__ import annotations

import json
import os
from typing import Callable

try:
    import tkinter as tk
    from tkinter import messagebox, ttk
except ImportError:  # a Python without it: the Workshop says so
    tk = None

from core import dialogue_editor as de
from core import dialogue_villagers
from core.shared import SHARED_DIR
from settings import ColorSettings

FONT = ("Consolas", 12)
UI_FONT = ("Segoe UI", 10)
# A scene's notes for the browser, not shown: its card is under its name already.
NOTES = ("**Place:**", "**Background:**", "**Music:**", "**Card:**")

# One look for dark and one for light, the same roles in each; the Light button switches.
THEMES: dict[str, dict[str, str]] = {
    "dark": {"background": "#181c28", "box": "#10121c", "text": "#d7d7d7", "dim": "#6c7080",
             "heading": "#ffd24a", "picked": "#2a3350", "narration": "#c9b8f0", "wrong": "#ff7070",
             "good": "#8be07a", "nobody": "#e8e0d0", "hit": "#4a4224"},
    "light": {"background": "#f2efe8", "box": "#ffffff", "text": "#222222", "dim": "#8a8a8a",
              "heading": "#9a6a00", "picked": "#dde6ff", "narration": "#5b3fa0", "wrong": "#c02020",
              "good": "#2a7a20", "nobody": "#4a4030", "hit": "#fff0b8"},
}


def _hex(rgb: tuple[int, int, int], scale: float = 1.0) -> str:
    return "#%02x%02x%02x" % tuple(int(c * scale) for c in rgb)


def _speaker_elements() -> dict[str, str]:
    """Each party member's first element, by name: Kailo afi, Hina lau..."""
    with open(os.path.join(SHARED_DIR, "battle.json"), encoding="utf-8") as f:
        characters = json.load(f)["characters"]
    return {c["id"]: c["elements"][0] for c in characters if c.get("elements")}


class LinesWindow:
    """The one lines window."""

    def __init__(self, root, play: Callable[[str], None], saved: Callable[[list[str]], None] | None = None,
                 theme: str = "dark") -> None:
        self.play_scene = play
        self.saved = saved          # told the files a Save wrote, so the Workshop can take the words
        self.library = de.Library()
        self.undo_steps: list[tuple[de.Document, list[str]]] = []
        self.theme = theme
        self.elements = _speaker_elements()
        self.entries: list[tuple[str, object]] = []   # the list's rows: ("scene", Scene) or ("group", None)
        self.shown: tuple[str, object] | None = None
        self.rows: list[de.Row] = []                   # the shown scene's rows
        self.picked: int | None = None

        self.top = tk.Toplevel(root, padx=10, pady=10)
        self.top.title("Dialogue")
        self.top.geometry("1100x700")
        self.top.protocol("WM_DELETE_WINDOW", self.close)

        left = tk.Frame(self.top)
        left.pack(side="left", fill="y")
        # The search: a name narrows the list to the scenes where that person speaks.
        self.catalog: list[tuple[tuple[str, object], str]] = []   # every row of the list, before the search
        self.query = tk.StringVar()
        self.by_words = tk.BooleanVar(value=False)
        search = tk.Frame(left)
        search.pack(side="top", fill="x", pady=(0, 6))
        self.search = tk.Entry(search, textvariable=self.query, font=UI_FONT, relief="flat")
        self.search.pack(side="left", fill="x", expand=True, ipady=3)
        self.words_mode = tk.Checkbutton(search, text="Words", variable=self.by_words, font=UI_FONT,
                                         command=self._filter, relief="flat")
        self.words_mode.pack(side="left", padx=(6, 0))
        self.found = tk.Label(left, font=UI_FONT, anchor="w")
        self.found.pack(side="top", fill="x")
        self.query.trace_add("write", lambda *_a: self._filter())
        self.search.bind("<Escape>", lambda _e: (self.query.set(""), "break")[1])
        listing = tk.Frame(left)
        listing.pack(side="top", fill="both", expand=True)
        self.listbox = tk.Listbox(listing, width=30, font=UI_FONT, activestyle="none", relief="flat",
                                  exportselection=False, highlightthickness=0)
        list_scroll = tk.Scrollbar(listing, command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=list_scroll.set)
        list_scroll.pack(side="right", fill="y")
        self.listbox.pack(side="left", fill="both", expand=True)
        self.listbox.bind("<<ListboxSelect>>", lambda _e: self._pick_entry())

        right = tk.Frame(self.top, padx=10)
        right.pack(side="left", fill="both", expand=True)
        self.title = tk.Label(right, font=("Segoe UI", 14, "bold"), anchor="w")
        self.title.pack(fill="x")
        self.card = tk.Label(right, font=UI_FONT, anchor="w", justify="left")
        self.card.pack(fill="x", pady=(0, 6))
        view = tk.Frame(right)
        self.view = tk.Text(view, wrap="word", font=FONT, relief="flat", padx=8, pady=8,
                            cursor="arrow", spacing1=3, spacing3=3, highlightthickness=0)
        scroll = tk.Scrollbar(view, command=self.view.yview)
        self.view.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.view.pack(side="left", fill="both", expand=True)
        self.view.bind("<Button-1>", self._click_row)
        self.view.bind("<Key>", lambda _e: "break")     # read only, but text can still be selected

        # The edit box: the picked line's parts.
        self.editor = tk.Frame(right, pady=8)
        self.labels = []
        row1 = tk.Frame(self.editor)
        row1.pack(fill="x")
        self.labels.append(tk.Label(row1, text="Speaker", font=UI_FONT))
        self.labels[-1].pack(side="left")
        self.speaker = ttk.Combobox(row1, width=16, font=UI_FONT)
        self.speaker.pack(side="left", padx=(4, 12))
        self.labels.append(tk.Label(row1, text="Only if", font=UI_FONT))
        self.labels[-1].pack(side="left")
        self.cond = tk.Entry(row1, width=24, font=UI_FONT, relief="flat")
        self.cond.pack(side="left", padx=(4, 12))
        self.marker = tk.Label(row1, font=UI_FONT)
        self.marker.pack(side="left")
        self.words = tk.Text(self.editor, height=3, wrap="word", font=FONT, relief="flat", padx=6, pady=6,
                             undo=True, highlightthickness=1)
        self.words.pack(fill="x", pady=(6, 0))
        self.words.bind("<Return>", lambda _e: (self.change(), "break")[1])
        self.words.bind("<Escape>", lambda _e: self._show_picked())

        buttons = tk.Frame(right)
        self.buttons = {}
        for name, command in (("Change line", self.change), ("Add before", lambda: self.add(before=True)),
                              ("Add after", self.add), ("Delete line", self.delete), ("Undo", self.undo)):
            self.buttons[name] = tk.Button(buttons, text=name, command=command, width=11, relief="flat", font=UI_FONT)
            self.buttons[name].pack(side="left", padx=(0, 6))
        for name, command in (("Dark" if theme == "light" else "Light", self.switch_theme), ("Play scene", self.play), ("Save", self.save)):
            self.buttons[name] = tk.Button(buttons, text=name, command=command, width=11, relief="flat", font=UI_FONT)
            self.buttons[name].pack(side="right", padx=(6, 0))
        self.message = tk.Label(right, font=UI_FONT, anchor="w", justify="left")
        # Packed from the bottom up, so the scene's lines take what is left.
        self.message.pack(side="bottom", fill="x", pady=(6, 0))
        buttons.pack(side="bottom", fill="x")
        self.editor.pack(side="bottom", fill="x")
        view.pack(fill="both", expand=True)

        self.top.bind("<Control-s>", lambda _e: self.save())
        self.top.bind("<Control-z>", lambda _e: self.undo()
                      if self.top.focus_get() not in (self.words, self.search) else None)
        self.top.bind("<Control-f>", lambda _e: (self.search.focus_set(), self.search.select_range(0, "end"), "break")[2])

        self._fill_list()
        self._paint()
        first = next((k for k, entry in enumerate(self.entries) if entry[0] != "group"), None)
        if first is not None:
            self.listbox.selection_set(first)
            self._pick_entry()

    # ------------------------------------------------------------------
    # THE LIST OF SCENES
    # ------------------------------------------------------------------

    def _fill_list(self) -> None:
        self.catalog = []
        for file in de.script_files():
            if file == de.FIELD_FILE:
                self._add_entry(("group", None), "")     # a gap before the field lines
            document = self._fresh(self.library.script(file))
            scenes = de.scenes_of(file, document.lines)
            if len(scenes) > 1 or (scenes and scenes[0].heading != "Scene"):
                title = next((s.title for s in scenes if s.heading == "Scene"), None)
                if title is None:
                    self._add_entry(("group", None), _file_title(document, file))
                for scene in scenes:
                    self._add_entry(("scene", scene), scene.title if scene.heading == "Scene" else "    " + scene.title)
            elif scenes:
                self._add_entry(("scene", scenes[0]), scenes[0].title)
        # What people say on the map and in the question menus: kept in the room files.
        self._add_entry(("group", None), "")
        for file in dialogue_villagers.villager_files():
            document = self._fresh(self.library.script(file))
            self._add_entry(("group", None), f"{_VILLAGER_GROUPS[file.partition('/')[0]]}: {_file_title(document, file)}")
            for scene in de.scenes_of(file, document.lines):
                self._add_entry(("scene", scene), "    " + scene.title)
        self._refill()

    def _add_entry(self, entry: tuple[str, object], label: str) -> None:
        self.catalog.append((entry, label))

    def _refill(self) -> None:
        """Put the list on screen: all of it, or what the search leaves."""
        query = self.query.get().strip().lower()
        words = self.by_words.get()
        kept = self.catalog
        if query:
            kept, group = [], None
            for entry, label in self.catalog:
                if entry[0] == "group":
                    group = (entry, label) if label else None     # gaps are dropped while searching
                elif any(row_hit(row, query, words) for row in self._rows_of_scene(entry[1])):
                    if group is not None:
                        kept.append(group)
                        group = None
                    kept.append((entry, label))
        scenes_all = sum(1 for entry, _l in self.catalog if entry[0] != "group")
        scenes_left = sum(1 for entry, _l in kept if entry[0] != "group")
        self.listbox.delete(0, "end")
        self.entries = [entry for entry, _l in kept]
        for _e, label in kept:
            self.listbox.insert("end", label)
        if query:
            what = "says that" if words else "speaks"
            self.found.config(text=f"{scenes_left} of {scenes_all} scenes" if scenes_left
                              else f"Nobody who {what} matches.")
        else:
            self.found.config(text="Type a name to find where they speak (Ctrl+F)")
        self._paint_list()

    def _rows_of_scene(self, scene) -> list[de.Row]:
        document = self.library.script(scene.file)
        found = next((s for s in de.scenes_of(scene.file, document.lines) if s.heading == scene.heading), None)
        return de.rows_of(document, found) if found else []

    def _filter(self) -> None:
        """The search changed: narrow the list, keep the shown scene if it still has the person."""
        self._refill()
        self._select_shown()
        if self.shown is not None:
            self._mark_hits()

    def _select_shown(self) -> bool:
        """Select the shown scene in the list, if it is there."""
        self.listbox.selection_clear(0, "end")
        if self.shown is None:
            return False
        what = self.shown[1]
        for k, entry in enumerate(self.entries):
            if entry[0] != "group" and entry[1].file == what.file and entry[1].heading == what.heading:
                self.listbox.selection_set(k)
                self.listbox.see(k)
                return True
        return False

    def _mark_hits(self) -> None:
        """Color the shown scene's rows that match the search, and scroll to the first."""
        self.view.tag_remove("hit", "1.0", "end")
        query = self.query.get().strip().lower()
        if not query:
            return
        words = self.by_words.get()
        first = None
        for number, row in enumerate(self.rows):
            if row_hit(row, query, words):
                ranges = self.view.tag_ranges(f"row{number}")
                if ranges:
                    self.view.tag_add("hit", ranges[0], ranges[-1])
                    first = first or ranges[0]
        if first is not None:
            self.view.see(first)

    def _pick_entry(self) -> None:
        picked = self.listbox.curselection()
        if not picked:
            return
        entry = self.entries[picked[0]]
        if entry[0] == "group":
            # A heading: open the first scene under it.
            following = next((k for k in range(picked[0] + 1, len(self.entries)) if self.entries[k][0] != "group"), None)
            self.listbox.selection_clear(0, "end")
            if following is not None:
                self.listbox.selection_set(following)
                self._pick_entry()
            return
        self.shown, self.picked = entry, None
        self._show()

    def _fresh(self, document: de.Document) -> de.Document:
        """The file as it is on disk now, if nothing in it is edited here (it may have changed)."""
        if not document.unsaved:
            on_disk = de.open_document(document.path)
            if on_disk.base != document.base:
                self.library.documents[document.path] = on_disk
                self.undo_steps = [step for step in self.undo_steps if step[0] is not document]
                return on_disk
        return document

    # ------------------------------------------------------------------
    # THE SHOWN SCENE
    # ------------------------------------------------------------------

    def _document(self) -> de.Document:
        return self.library.script(self.shown[1].file)

    def _scene(self) -> de.Scene | None:
        """The shown scene, found again: lines added above move it."""
        what = self.shown[1]
        scenes = de.scenes_of(what.file, self._document().lines)
        return next((s for s in scenes if s.heading == what.heading), None)

    def _show(self) -> None:
        what = self.shown[1]
        self.view.delete("1.0", "end")
        for tag in self.view.tag_names():
            if tag != "sel":
                self.view.tag_delete(tag)
        self._fresh(self.library.script(what.file))
        scene = self._scene()
        self.title.config(text=scene.title if scene else what.title)
        if what.file == de.FIELD_FILE:
            self.card.config(text="Said on the field. Who says each line is decided by the game; "
                                  "the words in curly brackets are filled in by it.")
        elif dialogue_villagers.is_villager_file(what.file):
            self.card.config(text="Said on the map, kept in the room's file. Plain lines are the person's; "
                                  "after a talk or once direction each line has its own speaker.")
        else:
            self.card.config(text=scene.card if scene and scene.card else "")
        self.rows = de.rows_of(self._document(), scene) if scene else []
        shown = 0
        for number, row in enumerate(self.rows):
            tag = f"row{number}"
            if row.kind == "stage" and row.text.startswith(NOTES):
                continue
            shown += 1
            # Numbered, so the order the game plays them in is plain.
            self._put(f"{shown:>3}  ", ("number", tag))
            if row.kind == "part":
                self._put(row.text.upper() + "\n", ("part", tag))
            elif row.kind == "stage":
                self._put(row.text.replace("**", "").removeprefix("- ") + "\n", ("dim", tag))
            elif row.kind == "narration":
                self._put(row.text + "\n", ("narration", tag))
            else:
                self._put(row.speaker, ("speaker:" + row.speaker, tag))
                if row.cond:
                    self._put(f"  if {row.cond}", ("dim", tag))
                if row.marker:
                    self._put(f"  {row.marker}", ("dim", tag))
                self._put("   " + row.text + "\n", ("text", tag))
        self._paint_view()
        self._mark_hits()
        self.buttons["Play scene"].config(state="normal" if what.game_name else "disabled")
        self._show_picked()

    def _put(self, text: str, tags: tuple) -> None:
        self.view.insert("end", text, tags)

    def _color_of(self, speaker: str) -> str:
        element = self.elements.get(speaker.lower())
        if element is None:
            return THEMES[self.theme]["nobody"]
        rgb = ColorSettings.ELEMENT_COLORS[element]
        return _hex(rgb) if self.theme == "dark" else _hex(rgb, 0.62)

    def _paint_view(self) -> None:
        colors = THEMES[self.theme]
        for tag in self.view.tag_names():
            if tag.startswith("speaker:"):
                self.view.tag_config(tag, foreground=self._color_of(tag[8:]), font=FONT + ("bold",))
        self.view.tag_config("dim", foreground=colors["dim"])
        self.view.tag_config("number", foreground=colors["dim"], font=("Consolas", 9))
        self.view.tag_config("text", foreground=colors["text"])
        self.view.tag_config("narration", foreground=colors["narration"], font=FONT + ("italic",))
        self.view.tag_config("part", foreground=colors["heading"], font=FONT + ("bold",), spacing1=12)
        self.view.tag_config("hit", background=colors["hit"])
        self.view.tag_config("picked", background=colors["picked"])
        self.view.tag_raise("picked")

    def _click_row(self, event) -> str:
        index = self.view.index(f"@{event.x},{event.y}")
        tag = next((t for t in self.view.tag_names(index) if t.startswith("row")), None)
        if tag is not None:
            self.picked = int(tag[3:])
            self._show_picked()
        return "break"

    def _show_picked(self) -> None:
        """Mark the picked row and put its parts in the edit box."""
        self.view.tag_remove("picked", "1.0", "end")
        self.message.config(text="")
        row = self._picked_row()
        # Who says a field line is the game's to decide; only its words change here.
        field = self.shown[1].file == de.FIELD_FILE
        editable = row is not None and row.editable
        if row is not None:
            ranges = self.view.tag_ranges(f"row{self.picked}")
            if ranges:
                self.view.tag_add("picked", ranges[0], ranges[-1])
        self.words.config(state="normal")
        self.words.delete("1.0", "end")
        self.cond.config(state="normal")
        self.cond.delete(0, "end")
        self.speaker.set("")
        self.marker.config(text="")
        if editable:
            self.words.insert("1.0", row.text)
            self.words.edit_reset()
            self.speaker.set(row.speaker)
            self.cond.insert(0, row.cond)
            self.marker.config(text=f"types {row.marker[1:-1]}" if row.marker else "")
            self.words.focus_set()
        elif row is not None:
            self.message.config(text="Directions stay as they are for now. Add before or Add after puts a line next to this one.",
                                fg=THEMES[self.theme]["dim"])
        else:
            self.message.config(text="Click a row to change it, or to add a line before or after it. "
                                     "The game plays them from top to bottom.", fg=THEMES[self.theme]["dim"])
        self.speaker.config(values=self._speakers(), state="normal" if editable and not field else "disabled")
        self.cond.config(state="normal" if editable and not field else "disabled")
        self.words.config(state="normal" if editable else "disabled")
        self.buttons["Change line"].config(state="normal" if editable else "disabled")
        for name in ("Add before", "Add after"):
            self.buttons[name].config(state="normal" if row is not None else "disabled")
        self.buttons["Delete line"].config(state="normal" if editable else "disabled")
        self.buttons["Undo"].config(state="normal" if self.undo_steps else "disabled")
        self._mark_unsaved()

    def _speakers(self) -> list[str]:
        """The scene's cast, then anyone else who speaks in it; blank is narration."""
        names = de.cast_of(self._document().lines)
        names += sorted({row.speaker for row in self.rows if row.speaker} - set(names))
        return ["", *names]

    def _mark_unsaved(self) -> None:
        count = len(self.library.unsaved)
        self.buttons["Save"].config(text=f"Save ({count})" if count else "Save")
        self.top.title("Dialogue *" if count else "Dialogue")

    # ------------------------------------------------------------------
    # EDITS
    # ------------------------------------------------------------------

    def _picked_row(self):
        return self.rows[self.picked] if self.picked is not None and self.picked < len(self.rows) else None

    def _field_problem(self, document: de.Document, before: list[str]) -> bool:
        """An edit the game could not read the field lines after is taken back, and says why."""
        problem = de.field_problem(document) if self.shown[1].file == de.FIELD_FILE else ""
        if problem:
            document.lines[:] = before
            self._show()
            self._say(problem, "wrong")
        return bool(problem)

    def change(self) -> None:
        row = self._picked_row()
        if row is None or not row.editable:
            return
        words = self.words.get("1.0", "end-1c")
        document = self._document()
        before = list(document.lines)
        try:
            de.edit_row(document, row, self.speaker.get(), words, self.cond.get())
        except ValueError as error:
            document.lines[:] = before
            self._say(str(error), "wrong")
            return
        if document.lines == before:
            self._say("No change.", "dim")
            return
        self.undo_steps.append((document, before))
        self._show()
        self._say("Changed. Save writes it.", "good")

    def add(self, before: bool = False) -> None:
        """A new line right after the picked row, or right before it: the game plays it there."""
        row = self._picked_row()
        if row is None:
            return
        speaker = row.speaker if row.editable else ""
        document = self._document()
        lines = list(document.lines)
        de.add_row(document, row.index - 1 if before else row.index, speaker, "...")
        if self._field_problem(document, lines):
            return
        self.undo_steps.append((document, lines))
        if not before:
            self.picked += 1
        self._show()
        self.words.tag_add("sel", "1.0", "end-1c")
        self._say("A new line. Type its words, then Enter.", "good")

    def delete(self) -> None:
        row = self._picked_row()
        if row is None or not row.editable:
            return
        document = self._document()
        lines = list(document.lines)
        document.delete(row.index)
        if self._field_problem(document, lines):
            return
        self.undo_steps.append((document, lines))
        self.picked = min(self.picked, len(self.rows) - 2) if len(self.rows) > 1 else None
        self._show()
        self._say("Deleted. Undo brings it back.", "good")

    def undo(self) -> None:
        if not self.undo_steps:
            return
        document, lines = self.undo_steps.pop()
        document.lines[:] = lines
        self._show()
        self._say("Undone.", "good")

    def _say(self, text: str, color: str) -> None:
        self.message.config(text=text, fg=THEMES[self.theme][color])

    # ------------------------------------------------------------------
    # SAVE, PLAY, THE LOOK, CLOSING
    # ------------------------------------------------------------------

    @property
    def unsaved(self) -> bool:
        return bool(self.library.unsaved)

    def save(self) -> bool:
        """Save every edited file; True once all are written."""
        saved, written = 0, []
        for document in self.library.unsaved:
            choices: dict[int, str] = {}
            while True:
                try:
                    conflicts = document.save(choices)
                except ValueError as error:
                    self._say(f"Not saved: {error} Your changes are still here.", "wrong")
                    return False
                if not conflicts:
                    break
                for conflict in conflicts:
                    choice = ConflictChooser(self.top, self.theme, document, conflict, len(conflicts)).ask()
                    if choice is None:
                        self._say("Not saved. Your changes are still here.", "wrong")
                        self._show()
                        return False
                    choices[conflict.number] = choice
            saved += 1
            written.append(document.path)
        self.undo_steps.clear()
        if written and self.saved is not None:
            self.saved(written)
        self._fill_list_keeping()
        self._show()
        self._say(f"Saved {saved} file{'' if saved == 1 else 's'}." if saved else "Nothing to save.", "good")
        return True

    def _fill_list_keeping(self) -> None:
        self._fill_list()
        self._paint()
        self._select_shown()

    def play(self) -> None:
        what = self.shown[1]
        if not what.game_name:
            return
        if self.unsaved and not self.save():
            return
        self.play_scene(what.game_name)
        self._say(f"Playing {what.title}.", "good")

    def switch_theme(self) -> None:
        self.theme = "light" if self.theme == "dark" else "dark"
        self.buttons["Light"].config(text="Dark" if self.theme == "light" else "Light")
        self._paint()
        self._show()

    def _paint(self) -> None:
        colors = THEMES[self.theme]
        for frame in (self.top, *self._all(self.top)):
            if isinstance(frame, (tk.Frame, tk.Toplevel)):
                frame.config(bg=colors["background"])
            elif isinstance(frame, tk.Label):
                frame.config(bg=colors["background"], fg=colors["dim"])
            elif isinstance(frame, tk.Button):
                frame.config(bg=colors["box"], fg=colors["text"], activebackground=colors["picked"],
                             activeforeground=colors["text"], disabledforeground=colors["dim"])
        self.title.config(fg=colors["heading"])
        self.card.config(fg=colors["text"])
        for box in (self.view, self.words, self.cond, self.search):
            box.config(bg=colors["box"], fg=colors["text"], insertbackground=colors["text"])
        self.words.config(highlightbackground=colors["dim"], highlightcolor=colors["heading"])
        self.cond.config(disabledbackground=colors["background"])
        self.words_mode.config(bg=colors["background"], fg=colors["text"], selectcolor=colors["box"],
                               activebackground=colors["background"], activeforeground=colors["text"])
        self.listbox.config(bg=colors["box"], fg=colors["text"], selectbackground=colors["picked"],
                            selectforeground=colors["heading"])
        self._paint_list()

    def _paint_list(self) -> None:
        colors = THEMES[self.theme]
        for k, entry in enumerate(self.entries):
            if entry[0] == "group":
                self.listbox.itemconfig(k, fg=colors["heading"])

    def _all(self, widget) -> list:
        found = []
        for child in widget.winfo_children():
            found.append(child)
            found.extend(self._all(child))
        return found

    def show_scene(self, file: str, heading: str) -> bool:
        """Jump to one scene, a person in a room as ``cells/hut.json``, ``Keo at 4,7``; False if it is not there."""
        self.query.set("")
        self._fill_list_keeping()
        for k, entry in enumerate(self.entries):
            if entry[0] != "group" and entry[1].file == file and entry[1].heading == heading:
                self.listbox.selection_clear(0, "end")
                self.listbox.selection_set(k)
                self.listbox.see(k)
                self._pick_entry()
                self.lift()
                return True
        return False

    def lift(self) -> None:
        self.top.deiconify()
        self.top.lift()
        self.top.focus_force()

    @property
    def alive(self) -> bool:
        try:
            return bool(self.top.winfo_exists())
        except tk.TclError:
            return False

    def close(self) -> None:
        if self.unsaved:
            answer = messagebox.askyesnocancel("Unsaved lines", "Save the changed lines before closing?",
                                               parent=self.top)
            if answer is None or (answer and not self.save()):
                return
        self.top.destroy()


def row_hit(row: de.Row, query: str, words: bool = False) -> bool:
    """Does a row match the search? By who speaks (partial, any case); with ``words``, by what is said."""
    if not query:
        return False
    if words:
        return row.editable and query in row.text.lower()
    return row.kind == "say" and query in row.speaker.lower()


_VILLAGER_GROUPS = {"cells": "People in", "asks": "Questions to"}


def _file_title(document: de.Document, file: str) -> str:
    return next((line.strip()[2:] for line in document.lines if line.startswith("# ")), file)


class ConflictChooser:
    """Lines changed both here and on disk: show both, one choice at a time."""

    def __init__(self, parent, theme: str, document: de.Document, conflict: de.Conflict, count: int) -> None:
        colors = THEMES[theme]
        self.choice: str | None = None
        self.top = tk.Toplevel(parent, bg=colors["background"], padx=12, pady=12)
        self.top.title("Changed in two places")
        self.top.transient(parent)
        self.top.protocol("WM_DELETE_WINDOW", self.top.destroy)
        name = os.path.basename(document.path)
        tk.Label(self.top, bg=colors["background"], fg=colors["text"], font=UI_FONT, justify="left",
                 wraplength=760, text=f"These lines of {name} were changed here and also in the file since it was "
                 f"opened ({conflict.number + 1} of {count}). Which one stays?").pack(anchor="w")
        for heading, lines, color in (("Yours, from this window", conflict.mine, "good"),
                                      ("In the file now", conflict.disk, "heading")):
            tk.Label(self.top, text=heading, bg=colors["background"], fg=colors[color],
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 2))
            box = tk.Text(self.top, width=96, height=min(10, max(2, len(lines) + 1)), wrap="word", font=FONT,
                          bg=colors["box"], fg=colors["text"], relief="flat", padx=6, pady=6)
            box.insert("1.0", "".join(lines) or "(nothing: the lines were taken out)")
            box.config(state="disabled")
            box.pack(fill="x")
        buttons = tk.Frame(self.top, bg=colors["background"])
        buttons.pack(anchor="e", pady=(10, 0))
        tk.Button(buttons, text="Keep the file's", width=14,
                  command=lambda: self._pick("disk")).pack(side="right", padx=(6, 0))
        tk.Button(buttons, text="Keep mine", width=14, command=lambda: self._pick("mine")).pack(side="right")

    def _pick(self, choice: str) -> None:
        self.choice = choice
        self.top.destroy()

    def ask(self) -> str | None:
        self.top.grab_set()
        self.top.wait_window()
        return self.choice
