"""The Workshop: paint the game's rooms with the mouse.

    python workshop.py            (from game/pygame; the title screen opens it too)
    python workshop.py --shot out.png   (draw one frame without a window, for checking)

The map is screens, one file per room in ``data/cells/``, and this is
the paint program for them. The room is drawn with the game's own tile,
person and monster code, so what you see is what plays. The Workshop is
a desktop tool: it never goes near the cartridge, and the rooms it
writes are read by the pygame game and by the cartridge build alike.

The window is a 384 by 272 layout enlarged by a whole number: the room
on the left at the game's own size, a palette and a map of the rooms on
the right, a bar of words along the bottom.

What the mouse does:

* Left click or drag on the room puts the brush down: paints a tile, or
  stands a monster or a person there.
* Right click takes the thing on a tile away; on a bare tile it picks
  that tile up as the brush.
* Click a brush in the palette to pick it. Click a room in the map to
  open it, or an empty slot beside a room to make a new room there.

What the keys do: S saves, Z undoes, P plays the game in this room with
fights off, R renames the room, T turns the person (or monster) under
the mouse, F makes the monster under the mouse stand still or wander,
G shows or hides the grid, the arrows open the room next door, Delete
twice drops the room, and Esc leaves (twice if something is unsaved).
"""

from __future__ import annotations

import os
import subprocess
import sys

GAME = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, GAME)
os.chdir(GAME)

SHOT = "--shot" in sys.argv
if SHOT:
    os.environ["SDL_VIDEODRIVER"] = "dummy"
    os.environ["SDL_AUDIODRIVER"] = "dummy"

import pygame  # noqa: E402

from core import overworld_cells as cells  # noqa: E402
from core.scenes.overworld_scene import _TILE_COLORS, _person_sheet, _pick, _tiles  # noqa: E402
from core.workshop import TILE_NAMES, Brush, Workshop, generated_slots  # noqa: E402
from entities.field_monster import FieldMonster, _frames  # noqa: E402
from settings import (  # noqa: E402
    ColorSettings,
    FieldMonsterSettings,
    GridSettings,
    OverworldPlayerSettings,
    OverworldSettings,
)
from ui import shore, text_renderer  # noqa: E402

# The layout, before enlarging: the room, a panel beside it, a bar under both.
ROOM_W, ROOM_H = OverworldSettings.PIXEL_W, OverworldSettings.PIXEL_H   # 256 by 224
PANEL_X, PANEL_W = ROOM_W, 128
BAR_Y, BAR_H = ROOM_H, 48
WIDTH, HEIGHT = ROOM_W + PANEL_W, ROOM_H + BAR_H                         # 384 by 272
TILE = GridSettings.TILE_SIZE
MAX_SCALE = 4

# The palette: brushes sit in 20 pixel cells, six to a row.
PALETTE_X = PANEL_X + 4
CELL = 20
PER_ROW = 6
# The map of rooms: 16 by 14 thumbnails in 18 by 16 slots, six by six,
# the open room in the third column and row.
MAP_X, MAP_Y = PANEL_X + 4, 122
SLOT_W, SLOT_H = 18, 16
SLOTS = 6
CENTER_SLOT = 2

YELLOW = ColorSettings.YELLOW
WHITE = ColorSettings.WHITE
GRAY = (120, 120, 120)
PANEL_COLOR = (24, 28, 40)
BAR_COLOR = (16, 18, 28)
GRID_COLOR = (255, 255, 255, 40)
EMPTY_SLOT = (60, 66, 90)
WOODS_SLOT = (46, 84, 52)    # a map slot the woods fill, new every game
MESSAGE_SECONDS = 2.5
CONFIRM_SECONDS = 3.0


def _shrink_to_tile(picture: pygame.Surface) -> pygame.Surface:
    """A palette icon: the picture made to fit one tile.

    A picture a pixel or two over (a 17 pixel boar) is cropped to its
    middle; a big one (the Great Boar) is shrunk by a whole number.
    """
    width, height = picture.get_size()
    if width <= TILE + 2 and height <= TILE + 2:
        if width <= TILE and height <= TILE:
            return picture
        crop = pygame.Rect(max(0, (width - TILE) // 2), max(0, height - TILE),
                           min(TILE, width), min(TILE, height))
        return picture.subsurface(crop)
    factor = max(1, -(-width // TILE), -(-height // TILE))
    return pygame.transform.scale(picture, (width // factor, height // factor))


class WorkshopApp:
    """The window around a ``Workshop``."""

    def __init__(self, scale: int | None = None) -> None:
        pygame.init()
        self.scale = scale or self._pick_scale()
        self.window = pygame.display.set_mode((WIDTH * self.scale, HEIGHT * self.scale))
        pygame.display.set_caption("Nuitai Workshop")
        icon_path = os.path.join(GAME, "assets", "graphics", "app_icon.png")
        if os.path.exists(icon_path):
            pygame.display.set_icon(pygame.image.load(icon_path))
        self.canvas = pygame.Surface((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.shop = Workshop()
        self.hover: tuple[int, int] | None = None     # the tile under the mouse, if on the room
        self.mouse: tuple[int, int] = (0, 0)          # on the layout, not the window
        self.painting = False
        self.show_grid = True
        self.message = ""
        self.message_left = 0.0
        self.renaming: str | None = None              # the name being typed, while renaming
        self.confirm: str | None = None               # "quit", "delete", "drop" or "new", waiting for a second press
        # The slots the woods fill: shown on the map, never painted (Frankie, 10/21).
        self.woods = generated_slots()
        self.pending_slot: tuple[int, int] | None = None  # the empty map slot a "new" waits on
        self.pending_room: str | None = None              # the room on the map a "drop" waits on
        self.confirm_left = 0.0
        self.running = True
        self._icons: dict[Brush, pygame.Surface] = {}
        self._thumbnails: dict[str, tuple[str, pygame.Surface]] = {}
        self._grid_overlay: pygame.Surface | None = None

    @staticmethod
    def _pick_scale() -> int:
        """The largest whole number that leaves room for the title bar and the taskbar."""
        desktop_w, desktop_h = pygame.display.get_desktop_sizes()[0]
        return max(1, min(MAX_SCALE, (desktop_w - 64) // WIDTH, (desktop_h - 120) // HEIGHT))

    # ------------------------------------------------------------------
    # RUNNING
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Draw and listen until the window closes."""
        while self.running:
            dt = self.clock.tick(60) / 1000.0
            for event in pygame.event.get():
                self.handle(event)
            self.update(dt)
            self.draw()
            self.present()
        pygame.quit()

    def present(self) -> None:
        """Enlarge the layout onto the window by whole pixels."""
        pygame.transform.scale(self.canvas, self.window.get_size(), self.window)
        pygame.display.flip()

    def update(self, dt: float) -> None:
        """Let the message and any pending confirmation time out."""
        if self.message_left > 0:
            self.message_left -= dt
            if self.message_left <= 0:
                self.message = ""
        if self.confirm_left > 0:
            self.confirm_left -= dt
            if self.confirm_left <= 0:
                self.confirm = None

    def say(self, text: str) -> None:
        """Show a line in the bar for a moment."""
        self.message = text.upper()
        self.message_left = MESSAGE_SECONDS

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def _to_layout(self, pos: tuple[int, int]) -> tuple[int, int]:
        return (pos[0] // self.scale, pos[1] // self.scale)

    def _tile_under(self, point: tuple[int, int]) -> tuple[int, int] | None:
        x, y = point
        if 0 <= x < ROOM_W and 0 <= y < ROOM_H:
            return (x // TILE, y // TILE)
        return None

    def handle(self, event: pygame.event.Event) -> None:
        """Route one event."""
        if event.type == pygame.QUIT:
            self._ask_quit()
        elif event.type == pygame.MOUSEMOTION:
            self.mouse = self._to_layout(event.pos)
            self.hover = self._tile_under(self.mouse)
            if self.painting and self.hover and self.shop.brush.kind == "tile":
                self.shop.paint(*self.hover, self.shop.brush.key)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            self.mouse = self._to_layout(event.pos)
            self.hover = self._tile_under(self.mouse)
            if event.button == 1:
                self._left_click()
            elif event.button == 3:
                self._right_click()
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self.painting:
                self.shop.end_stroke()
                self.painting = False
        elif event.type == pygame.KEYDOWN:
            if self.renaming is not None:
                self._type_name(event)
            else:
                self._key(event)

    def _left_click(self) -> None:
        if self.hover is not None:
            if self.shop.brush.kind == "tile":
                self.painting = True
                self.shop.begin_stroke()
                self.shop.paint(*self.hover, self.shop.brush.key)
            elif not self.shop.place(*self.hover):
                self.say("No room for it there")
            return
        brush = self._brush_under(self.mouse)
        if brush is not None:
            self.shop.brush = brush
            return
        slot = self._slot_under(self.mouse)
        if slot is not None:
            self._click_slot(slot)

    def _right_click(self) -> None:
        if self.hover is None:
            # Right click on the map drops that room, after a second right click (Frankie, 10/21).
            slot = self._slot_under(self.mouse)
            target = self.shop.room_at(slot) if slot is not None else None
            if target is None:
                return
            if target == self.shop.current:
                self._ask_delete()
            elif self.confirm == "drop" and self.pending_room == target:
                here = self.shop.current
                self.confirm = None
                self.shop.open(target)
                self.shop.delete_room()
                if here in self.shop.names:
                    self.shop.open(here)
                self.say(f"Dropped {target}; S makes it final")
            elif len(self.shop.names) > 1:
                self.confirm, self.confirm_left, self.pending_room = "drop", CONFIRM_SECONDS, target
                self.say(f"Right click again drops {target}")
            return
        if self.shop.remove(*self.hover):
            return
        char = self.shop.tile_at(*self.hover)
        for brush in self.shop.brushes:
            if brush.kind == "tile" and brush.key == char:
                self.shop.brush = brush
                self.say(f"Brush: {brush.label}")

    def _key(self, event: pygame.event.Event) -> None:
        key = event.key
        if key == pygame.K_ESCAPE:
            self._ask_quit()
        elif key == pygame.K_s:
            self._save()
        elif key == pygame.K_z:
            if self.shop.undo():
                self.say("Undone")
            else:
                self.say("Nothing to undo")
        elif key == pygame.K_p:
            self._play()
        elif key == pygame.K_r:
            self.renaming = self.shop.current or ""
        elif key == pygame.K_t and self.hover is not None:
            if not self.shop.turn(*self.hover):
                self.say("Nothing to turn there")
        elif key == pygame.K_f and self.hover is not None:
            if not self.shop.toggle_still(*self.hover):
                self.say("No monster there")
        elif key == pygame.K_g:
            self.show_grid = not self.show_grid
        elif key == pygame.K_DELETE:
            self._ask_delete()
        elif key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN):
            dx, dy = {pygame.K_LEFT: (-1, 0), pygame.K_RIGHT: (1, 0),
                      pygame.K_UP: (0, -1), pygame.K_DOWN: (0, 1)}[key]
            cx, cy = self.shop.pos
            if not self.shop.open_at((cx + dx, cy + dy)):
                self.say("No room that way")

    def _type_name(self, event: pygame.event.Event) -> None:
        """Keys while renaming: letters build the name, Enter keeps it, Esc drops it."""
        assert self.renaming is not None
        if event.key == pygame.K_ESCAPE:
            self.renaming = None
        elif event.key == pygame.K_RETURN:
            try:
                if self.shop.rename(self.renaming):
                    self.say(f"Renamed to {self.renaming}")
            except ValueError as error:
                self.say(str(error))
            self.renaming = None
        elif event.key == pygame.K_BACKSPACE:
            self.renaming = self.renaming[:-1]
        elif event.unicode and (event.unicode.isalnum() or event.unicode == "_"):
            self.renaming += event.unicode.lower()

    def _ask_quit(self) -> None:
        if not self.shop.unsaved or self.confirm == "quit":
            self.running = False
            return
        self.confirm, self.confirm_left = "quit", CONFIRM_SECONDS
        self.say("Unsaved. S saves, Esc again drops it")

    def _ask_delete(self) -> None:
        if self.confirm == "delete":
            name = self.shop.delete_room()
            self.confirm = None
            self.say(f"Dropped {name}; S makes it final")
            return
        if len(self.shop.names) <= 1:
            self.say("The last room stays")
            return
        self.confirm, self.confirm_left = "delete", CONFIRM_SECONDS
        self.say("Again drops this room")

    def _save(self) -> int:
        written = self.shop.save()
        self.say(f"Saved {len(written)} room{'' if len(written) == 1 else 's'}")
        return len(written)

    def _play(self) -> None:
        """Save, then start the game in this room, fights off, where the mouse is."""
        self.shop.save()
        col, row = self.shop.spawn_near(*(self.hover or (-1, -1)))
        subprocess.Popen([
            sys.executable, os.path.join(GAME, "main.py"),
            "--room", self.shop.current, "--col", str(col), "--row", str(row), "--no-fights",
        ], cwd=GAME)
        self.say(f"Playing in {self.shop.current}")

    # ------------------------------------------------------------------
    # THE PALETTE AND THE MAP
    # ------------------------------------------------------------------

    def _sections(self) -> list[tuple[str, int, list[Brush]]]:
        """The palette's sections: a heading, its top, its brushes."""
        tiles = [b for b in self.shop.brushes if b.kind == "tile"]
        monsters = [b for b in self.shop.brushes if b.kind == "monster"]
        people = [b for b in self.shop.brushes if b.kind == "person"]
        sections, y = [], 2
        for heading, brushes in (("TILES", tiles), ("THINGS", monsters), ("PEOPLE", people)):
            sections.append((heading, y, brushes))
            rows = max(1, -(-len(brushes) // PER_ROW))
            y += 10 + rows * CELL
        return sections

    def _brush_cells(self) -> list[tuple[Brush, pygame.Rect]]:
        cells = []
        for _heading, top, brushes in self._sections():
            for index, brush in enumerate(brushes):
                x = PALETTE_X + (index % PER_ROW) * CELL
                y = top + 10 + (index // PER_ROW) * CELL
                cells.append((brush, pygame.Rect(x, y, CELL, CELL)))
        return cells

    def _brush_under(self, point: tuple[int, int]) -> Brush | None:
        for brush, rect in self._brush_cells():
            if rect.collidepoint(point):
                return brush
        return None

    def _slot_under(self, point: tuple[int, int]) -> tuple[int, int] | None:
        """The world position of the map slot under a point."""
        x, y = point
        if not (MAP_X <= x < MAP_X + SLOTS * SLOT_W and MAP_Y <= y < MAP_Y + SLOTS * SLOT_H):
            return None
        sx, sy = (x - MAP_X) // SLOT_W, (y - MAP_Y) // SLOT_H
        cx, cy = self.shop.pos
        return (cx + sx - CENTER_SLOT, cy + sy - CENTER_SLOT)

    def _touches_a_room(self, pos: tuple[int, int]) -> bool:
        cx, cy = pos
        return any(self.shop.room_at((cx + dx, cy + dy)) is not None
                   for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))

    def _click_slot(self, pos: tuple[int, int]) -> None:
        if self.shop.open_at(pos):
            return
        if pos in self.woods:
            self.say("The woods are made fresh each game")
            return
        if not self._touches_a_room(pos):
            self.say("A new room has to touch one")
            return
        # A new room takes a second click on the same slot, so a stray click makes nothing (Frankie, 10/21).
        if self.confirm != "new" or self.pending_slot != pos:
            self.confirm, self.confirm_left, self.pending_slot = "new", CONFIRM_SECONDS, pos
            self.say("Click again to make a room here")
            return
        self.confirm, self.pending_slot = None, None
        name = self.shop.new_room(pos)
        self.say(f"New room {name}; R names it")

    def _icon(self, brush: Brush) -> pygame.Surface:
        """The 16 by 16 picture for a brush, made once."""
        if brush in self._icons:
            return self._icons[brush]
        icon = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
        tiles = _tiles()
        if brush.kind == "tile":
            if tiles:
                under = OverworldSettings.TILE_UNDER.get(brush.key)
                if under is not None:
                    icon.blit(tiles[under][0], (0, 0))
                icon.blit(tiles[brush.key][0], (0, 0))
            else:
                icon.fill(_TILE_COLORS.get(brush.key, ColorSettings.OVERWORLD_FLOOR))
        elif brush.kind == "monster":
            frames = _frames(self.shop.monster_kinds[brush.key])
            if frames:
                picture = _shrink_to_tile(frames[0])
                icon.blit(picture, ((TILE - picture.get_width()) // 2,
                                    TILE - picture.get_height()))
            else:
                icon.fill(FieldMonsterSettings.COLOR)
        else:
            sheet = _person_sheet(brush.key)
            if sheet is not None:
                icon.blit(sheet, (0, 0), pygame.Rect(0, 0, TILE, TILE))
            else:
                icon.fill(OverworldPlayerSettings.COLOR)
        self._icons[brush] = icon
        return icon

    def _thumbnail(self, name: str) -> pygame.Surface:
        """A room as 16 by 14 dots, one per tile, remade when the room changes."""
        rows = cells.CELLS[name]
        key = "".join("".join(row) for row in rows)
        cached = self._thumbnails.get(name)
        if cached is not None and cached[0] == key:
            return cached[1]
        picture = pygame.Surface((OverworldSettings.COLS, OverworldSettings.ROWS))
        for row_index, row in enumerate(rows):
            for col_index, char in enumerate(row):
                picture.set_at((col_index, row_index),
                               _TILE_COLORS.get(char, ColorSettings.OVERWORLD_FLOOR))
        self._thumbnails[name] = (key, picture)
        return picture

    # ------------------------------------------------------------------
    # DRAWING
    # ------------------------------------------------------------------

    def draw(self) -> None:
        """Draw the whole layout onto the canvas."""
        self.canvas.fill(ColorSettings.BLACK)
        self._draw_room()
        self._draw_panel()
        self._draw_bar()

    def _draw_room(self) -> None:
        surface = self.canvas
        shop = self.shop
        tiles = _tiles()
        floor = OverworldSettings.FLOOR_CHAR
        for row in range(OverworldSettings.ROWS):
            for col in range(OverworldSettings.COLS):
                char = shop.grid[row][col]
                x, y = col * TILE, row * TILE
                if not tiles:
                    pygame.draw.rect(surface, _TILE_COLORS.get(char, ColorSettings.OVERWORLD_FLOOR),
                                     (x, y, TILE, TILE))
                    continue
                if char in shore.WATER:
                    coast = shore.water_tile(shop.grid, col, row)
                    if coast is not None:
                        surface.blit(coast, (x, y))
                        continue
                under = OverworldSettings.TILE_UNDER.get(char)
                if under is not None:
                    surface.blit(_pick(tiles[under], col, row), (x, y))
                surface.blit(_pick(tiles.get(char, tiles[floor]), col, row), (x, y))
        column = OverworldPlayerSettings.SHEET_COLUMNS
        for person in shop.people:
            sheet = _person_sheet(person["sheet"])
            if sheet is None:
                pygame.draw.rect(surface, OverworldPlayerSettings.COLOR,
                                 (person["col"] * TILE, person["row"] * TILE, TILE, TILE))
                continue
            frame = pygame.Rect(column.get(tuple(person["facing"]), 0) * TILE, 0, TILE, TILE)
            surface.blit(sheet, (person["col"] * TILE, person["row"] * TILE), frame)
        for spot in shop.monsters:
            kind = shop.monster_kinds.get(spot["kind"])
            if kind is None:
                continue
            monster = FieldMonster(spot, kind)
            monster.facing_left = bool(spot.get("faces_left", False))
            monster.render(surface)
        if self.show_grid:
            surface.blit(self._grid(), (0, 0))
        if self.hover is not None:
            col, row = self.hover
            width = height = 1
            if shop.brush.kind == "monster":
                width, height = shop.monster_kinds[shop.brush.key].get("tiles", (1, 1))
            pygame.draw.rect(surface, YELLOW, (col * TILE, row * TILE, TILE * width, TILE * height), 1)

    def _grid(self) -> pygame.Surface:
        if self._grid_overlay is None:
            overlay = pygame.Surface((ROOM_W, ROOM_H), pygame.SRCALPHA)
            for x in range(0, ROOM_W, TILE):
                pygame.draw.line(overlay, GRID_COLOR, (x, 0), (x, ROOM_H - 1))
            for y in range(0, ROOM_H, TILE):
                pygame.draw.line(overlay, GRID_COLOR, (0, y), (ROOM_W - 1, y))
            self._grid_overlay = overlay
        return self._grid_overlay

    def _draw_panel(self) -> None:
        surface = self.canvas
        pygame.draw.rect(surface, PANEL_COLOR, (PANEL_X, 0, PANEL_W, ROOM_H))
        for heading, top, _brushes in self._sections():
            text_renderer.draw_text(surface, heading, (PALETTE_X, top), color=GRAY)
        for brush, rect in self._brush_cells():
            surface.blit(self._icon(brush), (rect.x + 2, rect.y + 2))
            if brush == self.shop.brush:
                pygame.draw.rect(surface, YELLOW, rect, 1)
            elif rect.collidepoint(self.mouse):
                pygame.draw.rect(surface, WHITE, rect, 1)
        text_renderer.draw_text(surface, "MAP", (PALETTE_X, MAP_Y - 10), color=GRAY)
        cx, cy = self.shop.pos
        hovered = self._slot_under(self.mouse)
        for sy in range(SLOTS):
            for sx in range(SLOTS):
                pos = (cx + sx - CENTER_SLOT, cy + sy - CENTER_SLOT)
                x, y = MAP_X + sx * SLOT_W, MAP_Y + sy * SLOT_H
                name = self.shop.room_at(pos)
                if name is not None:
                    surface.blit(self._thumbnail(name), (x + 1, y + 1))
                elif pos in self.woods:
                    pygame.draw.rect(surface, WOODS_SLOT, (x + 1, y + 1, SLOT_W - 2, SLOT_H - 2))
                elif self._touches_a_room(pos):
                    pygame.draw.rect(surface, EMPTY_SLOT, (x + 1, y + 1, SLOT_W - 2, SLOT_H - 2), 1)
                if name == self.shop.current:
                    pygame.draw.rect(surface, YELLOW, (x, y, SLOT_W, SLOT_H), 1)
                elif pos == hovered and (name is not None or pos in self.woods
                                         or self._touches_a_room(pos)):
                    pygame.draw.rect(surface, WHITE, (x, y, SLOT_W, SLOT_H), 1)

    def _draw_bar(self) -> None:
        surface = self.canvas
        pygame.draw.rect(surface, BAR_COLOR, (0, BAR_Y, WIDTH, BAR_H))
        shop = self.shop
        cx, cy = shop.pos
        name = shop.current or ""
        if self.renaming is not None:
            first = f"NAME: {self.renaming}_"
        else:
            mark = " *" if name in shop.dirty else ""
            first = f"{name.upper()} AT {cx},{cy}{mark}"
        text_renderer.draw_text(surface, first[:48], (4, BAR_Y + 4), color=WHITE)
        if self.message:
            second = self.message
            color = YELLOW
        elif self.hover is not None:
            col, row = self.hover
            second = f"{col},{row} {shop.describe(col, row)}"
            color = WHITE
        else:
            second = f"BRUSH {shop.brush.label}"
            color = WHITE
        text_renderer.draw_text(surface, second[:48], (4, BAR_Y + 18), color=color)
        slot = self._slot_under(self.mouse)
        if slot is not None and slot in self.woods and self.shop.room_at(slot) is None:
            hints = "WOODS: NEW EVERY GAME, NOT PAINTED HERE"
        elif slot is not None:
            hints = "CLICK TWICE: NEW ROOM  RIGHT CLICK TWICE: DROP"
        else:
            hints = "S SAVE  Z UNDO  P PLAY  R NAME  T TURN  F STILL"
        text_renderer.draw_text(surface, hints[:48], (4, BAR_Y + 32), color=GRAY)

    # ------------------------------------------------------------------
    # A PICTURE WITHOUT A WINDOW
    # ------------------------------------------------------------------

    def shot(self, path: str) -> None:
        """Draw one frame with the mouse over a tile and save it, enlarged."""
        self.hover = (5, 5)
        self.mouse = (5 * TILE + 8, 5 * TILE + 8)
        self.draw()
        big = pygame.transform.scale(self.canvas, (WIDTH * self.scale, HEIGHT * self.scale))
        pygame.image.save(big, path)
        pygame.quit()


def main() -> None:
    if SHOT:
        out = sys.argv[sys.argv.index("--shot") + 1]
        WorkshopApp(scale=2).shot(out)
        print("saved", out)
        return
    WorkshopApp().run()


if __name__ == "__main__":
    main()
