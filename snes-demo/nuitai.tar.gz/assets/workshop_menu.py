"""The Workshop's menu bar and toolbar, drawn in the game's own font (Frankie, 11/2).

pygame has no menus, and its window cannot be given a Windows menu bar,
so these are drawn across the top of the Workshop's layout: a bar of
menus (File, Edit, View, Tools, Help), each opening a list of items with
its key on the right, and under it a row of buttons for the things used
most. Each menu has its own color, and its buttons share it. Pointing at
an item or a button gives ``tip``, a line for the bottom bar saying what it
does. ``workshop.py`` builds the items; this only draws them and hears
the mouse.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import pygame

from ui import text_renderer

MENU_H = 12          # the bar of menus
TOOL_Y, TOOL_H = MENU_H, 15
TOP = MENU_H + TOOL_H  # what the menus and the toolbar take off the top
LETTER = 8           # every letter of the font is 8 pixels wide
ITEM_H = 12

BAR = (34, 38, 54)
TOOL_BAR = (24, 28, 40)
DROP = (20, 22, 32)
HOVER = (52, 60, 92)
EDGE = (90, 96, 124)
TEXT = (215, 215, 215)
DIM = (110, 112, 124)
# One color per menu; the help page uses the same ones (``workshop_windows.py``).
COLORS = {
    "file": (108, 198, 255),
    "edit": (255, 154, 92),
    "view": (139, 224, 122),
    "tools": (224, 138, 224),
    "help": (255, 210, 74),
}


@dataclass
class Item:
    """One menu item; one with no label is a line between groups."""

    label: str = ""
    keys: str = ""
    run: Callable[[], None] | None = None
    tip: str = ""
    enabled: Callable[[], bool] | None = None
    checked: Callable[[], bool] | None = None   # a tick before it, for things that are on or off

    def on(self) -> bool:
        return self.enabled is None or self.enabled()


@dataclass
class Menu:
    title: str
    category: str
    items: list[Item]


@dataclass
class Button:
    label: str
    category: str
    run: Callable[[], None]
    tip: str
    enabled: Callable[[], bool] | None = None
    checked: Callable[[], bool] | None = None


class MenuBar:
    """The menus and the toolbar: where they are, what is open, what the mouse is on."""

    def __init__(self, menus: list[Menu], buttons: list[Button], width: int) -> None:
        self.menus, self.buttons, self.width = menus, buttons, width
        self.open: int | None = None      # the menu whose list is showing
        self.mouse = (-1, -1)
        self.titles: list[pygame.Rect] = []
        x = 2
        for menu in menus:
            w = len(menu.title) * LETTER + 8
            self.titles.append(pygame.Rect(x, 0, w, MENU_H))
            x += w
        self.button_rects: list[pygame.Rect] = []
        x = 2
        for button in buttons:
            w = len(button.label) * LETTER + 6
            self.button_rects.append(pygame.Rect(x, TOOL_Y + 2, w, TOOL_H - 4))
            x += w + 3

    # ------------------------------------------------------------------
    # WHERE THINGS ARE
    # ------------------------------------------------------------------

    def _list_rect(self, index: int) -> pygame.Rect:
        menu = self.menus[index]
        label = max(len(item.label) for item in menu.items)
        keys = max(len(item.keys) for item in menu.items)
        w = (2 + label + (2 + keys if keys else 0)) * LETTER + 12
        h = sum(ITEM_H if item.label else 5 for item in menu.items) + 4
        x = min(self.titles[index].x, self.width - w)
        return pygame.Rect(x, MENU_H, w, h)

    def _item_rects(self, index: int) -> list[tuple[Item, pygame.Rect]]:
        box = self._list_rect(index)
        y = box.y + 2
        found = []
        for item in self.menus[index].items:
            h = ITEM_H if item.label else 5
            found.append((item, pygame.Rect(box.x + 1, y, box.w - 2, h)))
            y += h
        return found

    def covers(self, point: tuple[int, int]) -> bool:
        """Whether the point is on the menus, the toolbar or an open list, so not on the room below."""
        return point[1] < TOP or (self.open is not None and self._list_rect(self.open).collidepoint(point))

    def tip(self) -> str:
        """What the item or button under the mouse does, for the bottom bar."""
        if self.open is not None:
            for item, rect in self._item_rects(self.open):
                if item.label and rect.collidepoint(self.mouse):
                    return item.tip if item.on() else item.tip + " (not now)"
        for button, rect in zip(self.buttons, self.button_rects):
            if rect.collidepoint(self.mouse):
                return button.tip
        for menu, rect in zip(self.menus, self.titles):
            if rect.collidepoint(self.mouse) and self.open is None:
                return f"The {menu.title} menu"
        return ""

    # ------------------------------------------------------------------
    # THE MOUSE
    # ------------------------------------------------------------------

    def motion(self, point: tuple[int, int]) -> None:
        """While a menu is open, pointing at another title opens that one instead."""
        self.mouse = point
        if self.open is not None:
            for index, rect in enumerate(self.titles):
                if rect.collidepoint(point):
                    self.open = index

    def press(self, point: tuple[int, int]) -> bool:
        """A left press; True when the menus took it, so the room below must not."""
        self.mouse = point
        for index, rect in enumerate(self.titles):
            if rect.collidepoint(point):
                self.open = None if self.open == index else index
                return True
        if self.open is not None:
            index, self.open = self.open, None
            if self._list_rect(index).collidepoint(point):
                for item, rect in self._item_rects(index):
                    if item.label and rect.collidepoint(point) and item.on() and item.run is not None:
                        item.run()
                return True
            return True   # a press outside an open list only closes it, so a stray click paints nothing
        for button, rect in zip(self.buttons, self.button_rects):
            if rect.collidepoint(point):
                if button.enabled is None or button.enabled():
                    button.run()
                return True
        return point[1] < TOP

    def close(self) -> bool:
        """Esc: close the open list; False when none was open."""
        was = self.open is not None
        self.open = None
        return was

    # ------------------------------------------------------------------
    # DRAWING
    # ------------------------------------------------------------------

    def draw(self, surface: pygame.Surface) -> None:
        """The two bars; ``draw_list`` goes on afterwards, over everything."""
        pygame.draw.rect(surface, BAR, (0, 0, self.width, MENU_H))
        pygame.draw.rect(surface, TOOL_BAR, (0, TOOL_Y, self.width, TOOL_H))
        pygame.draw.line(surface, EDGE, (0, TOP - 1), (self.width - 1, TOP - 1))
        for index, (menu, rect) in enumerate(zip(self.menus, self.titles)):
            color = COLORS[menu.category]
            if self.open == index or rect.collidepoint(self.mouse):
                pygame.draw.rect(surface, HOVER, rect)
            text_renderer.draw_text(surface, menu.title, (rect.x + 4, rect.y + 2), color=color)
        for button, rect in zip(self.buttons, self.button_rects):
            on = button.enabled is None or button.enabled()
            color = COLORS[button.category] if on else DIM
            lit = button.checked is not None and button.checked()
            if rect.collidepoint(self.mouse) and on and self.open is None:
                pygame.draw.rect(surface, HOVER, rect)
            pygame.draw.rect(surface, color if lit else EDGE, rect, 1)
            text_renderer.draw_text(surface, button.label, (rect.x + 3, rect.y + 2), color=color)

    def draw_list(self, surface: pygame.Surface) -> None:
        if self.open is None:
            return
        menu = self.menus[self.open]
        box = self._list_rect(self.open)
        color = COLORS[menu.category]
        pygame.draw.rect(surface, DROP, box)
        pygame.draw.rect(surface, color, box, 1)
        keys_x = box.right - 8 - max(len(item.keys) for item in menu.items) * LETTER
        for item, rect in self._item_rects(self.open):
            if not item.label:
                pygame.draw.line(surface, EDGE, (rect.x + 4, rect.centery), (rect.right - 5, rect.centery))
                continue
            on = item.on()
            if rect.collidepoint(self.mouse) and on:
                pygame.draw.rect(surface, HOVER, rect)
            if item.checked is not None and item.checked():
                # A tick, drawn: the font has no check mark.
                pygame.draw.lines(surface, color, False,
                                  [(rect.x + 4, rect.y + 6), (rect.x + 6, rect.y + 8), (rect.x + 10, rect.y + 3)])
            text_renderer.draw_text(surface, item.label, (rect.x + 2 * LETTER - 2, rect.y + 2),
                                    color=TEXT if on else DIM)
            if item.keys:
                text_renderer.draw_text(surface, item.keys, (keys_x, rect.y + 2), color=color if on else DIM)
