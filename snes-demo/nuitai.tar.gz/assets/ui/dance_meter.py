"""Hina's Dance on screen: a rhythm game on a bar of four rows, like Dance Dance Revolution (Frankie, 11/1).

In the window the commands were in: the move's name on top, and under it four
rows the notes slide along, right to left, onto a yellow line on the beat.
Each row holds a d-pad direction and the face button in the same place on the
pad (Claude's call, 11/1): Up and X on top, then Left and Y, Right and A, and
Down and B. Every note shows what to press. The game keeps the beat here, since
a dance is danced to music (unlike Tawiri's Call, which keeps her own).

Each of her four moves is its own step pattern (``MinigameSettings.DANCE_STEPS``,
Frankie, 11/1). A note pressed right on the beat counts in full, a little off
for less, and a wrong press, a press with no note near, or a note let by is
missed. ``share`` is how much of the dance was got, 0 to 1, and the move heals
by it (``Battle.submit_dance``).

How wide the beat is comes from Hina's Intelligence against the monsters'
(Frankie, 11/1): the ``ease`` widens or narrows it.
"""

from __future__ import annotations

from typing import Any

import pygame

from settings import FontSettings, MinigameSettings
from ui import text_renderer
from ui.block_meter import draw_frame

ROWS: dict[str, int] = {"UP": 0, "X": 0, "LEFT": 1, "Y": 1, "RIGHT": 2, "A": 2, "DOWN": 3, "B": 3}
_ROW = 11                 # A row's height, in pixels.
_LANE_WIDTH = 112
_LINE_FROM_LEFT = 10      # Where the beat line sits in the lane.
_SPEED = 60               # Pixels a second the notes slide.
_NOTE = 4                 # A face button note's radius; an arrow fits the same box.
_FACES = {
    "A": ((90, 12, 20), (214, 40, 48)),
    "B": ((110, 80, 0), (240, 196, 24)),
    "X": ((20, 36, 100), (70, 130, 240)),
    "Y": ((16, 70, 30), (60, 200, 90)),
}
_ARROW = (255, 222, 40)
_ARROW_EDGE = (40, 24, 0)
_ROW_SHADE = ((24, 40, 72), (18, 32, 60))
_LINE = (255, 222, 40)
_LETTER = (255, 255, 255)
_GOOD = (96, 220, 96)
_MISS = (240, 64, 56)
_LINGER = 0.4             # Seconds the bar stays after the last note.
_WORD = 0.35              # How long a judged note's word shows.


class DanceMeter:
    """One Dance move's notes, how each landed, and the clock."""

    def __init__(self, move: dict[str, Any], target_id: str | None, ease: float = 1.0) -> None:
        """Start the lead in for ``move`` at ``target_id`` (None for one that reaches everyone)."""
        self.move = move
        self.target_id = target_id
        beat = MinigameSettings.DANCE_BEAT
        self.window = MinigameSettings.DANCE_WINDOW * ease
        self.perfect = MinigameSettings.DANCE_PERFECT * ease
        self.now = 0.0
        self.notes: list[dict] = [
            {"button": button, "at": (MinigameSettings.DANCE_LEAD_IN + at) * beat, "score": None}
            for at, button in MinigameSettings.DANCE_STEPS[move["id"]]]
        self._end = self.notes[-1]["at"] + self.window + _LINGER
        self._word: tuple[str, tuple[int, int, int], float] | None = None

    @property
    def done(self) -> bool:
        """True once every note is past and the bar has lingered a moment."""
        return self.now >= self._end

    @property
    def share(self) -> float:
        """How much of the dance was got, 0 to 1: the average of every note's score, a missed one 0."""
        return sum(n["score"] or 0.0 for n in self.notes) / len(self.notes)

    def wanted(self) -> str:
        """The next note's button, for telling a d-pad corner apart."""
        waiting = [n for n in self.notes if n["score"] is None]
        return waiting[0]["button"] if waiting else ""

    def _judge(self, note: dict, score: float) -> None:
        note["score"] = score
        self._word = (("Perfect!", _GOOD) if score >= 1 else ("Good", _GOOD) if score > 0 else ("Miss", _MISS)) + (_WORD,)

    def press(self, button: str) -> str:
        """Take one press of any of the eight; "perfect", "good" or "miss" for the sound."""
        if self.done:
            return "miss"
        waiting = [n for n in self.notes if n["score"] is None and abs(n["at"] - self.now) <= self.window]
        match = [n for n in waiting if n["button"] == button]
        if not match:
            # A wrong press, or one with no note near: the nearest note coming is lost.
            ahead = [n for n in self.notes if n["score"] is None]
            if ahead:
                self._judge(min(ahead, key=lambda n: abs(n["at"] - self.now)), 0.0)
            return "miss"
        note = min(match, key=lambda n: abs(n["at"] - self.now))
        off = abs(note["at"] - self.now)
        if off <= self.perfect:
            self._judge(note, 1.0)
            return "perfect"
        # Off the beat counts for less, down to a fifth at the window's edge.
        self._judge(note, 1.0 - 0.8 * (off - self.perfect) / max(1e-6, self.window - self.perfect))
        return "good"

    def update(self, dt: float) -> None:
        """Run the clock; a note let by past the window is missed."""
        self.now += dt
        for note in self.notes:
            if note["score"] is None and self.now > note["at"] + self.window:
                self._judge(note, 0.0)
        if self._word is not None:
            text, color, left = self._word
            self._word = (text, color, left - dt) if left > dt else None

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the move's name (or how the last note went) on top, the four rows under it."""
        size = FontSettings.SIZE_BODY
        if self._word is not None:
            text, color, _ = self._word
        else:
            text, color = self.move["name"], _LETTER
        text_renderer.draw_text(surface, text, (window.centerx - text_renderer.text_width(text, size) // 2,
                                                window.top + 8), color=color, size=size)
        frame = pygame.Rect(0, 0, _LANE_WIDTH + 4, 4 * _ROW + 4)
        frame.midtop = (window.centerx, window.top + 22)
        well = draw_frame(surface, frame)
        for row in range(4):
            pygame.draw.rect(surface, _ROW_SHADE[row % 2], pygame.Rect(well.left, well.top + row * _ROW, well.width, _ROW))
        line_x = well.left + _LINE_FROM_LEFT
        pygame.draw.line(surface, _LINE, (line_x, well.top), (line_x, well.bottom - 1), 2)
        clip = surface.get_clip()
        surface.set_clip(well)
        for note in self.notes:
            if note["score"] is not None:
                continue
            x = round(line_x + (note["at"] - self.now) * _SPEED)
            if x > well.right + _NOTE:
                continue
            y = well.top + ROWS[note["button"]] * _ROW + _ROW // 2
            draw_note(surface, note["button"], (x, y))
        surface.set_clip(clip)


def draw_note(surface: pygame.Surface, button: str, center: tuple[int, int]) -> None:
    """Draw one note: a round face button with its letter, or a yellow arrow."""
    x, y = center
    if button in _FACES:
        rim, face = _FACES[button]
        pygame.draw.circle(surface, rim, (x, y + 1), _NOTE + 1)
        pygame.draw.circle(surface, face, (x, y), _NOTE)
        width = text_renderer.text_width(button, FontSettings.SIZE_BODY)
        text_renderer.draw_text(surface, button, (x - width // 2 + 1, y - 3), color=_LETTER,
                                size=FontSettings.SIZE_BODY)
        return
    r = _NOTE + 1
    points = {
        "UP": [(x, y - r), (x - r, y + r - 1), (x + r, y + r - 1)],
        "DOWN": [(x, y + r), (x - r, y - r + 1), (x + r, y - r + 1)],
        "LEFT": [(x - r, y), (x + r - 1, y - r), (x + r - 1, y + r)],
        "RIGHT": [(x + r, y), (x - r + 1, y - r), (x - r + 1, y + r)],
    }[button]
    pygame.draw.polygon(surface, _ARROW, points)
    pygame.draw.polygon(surface, _ARROW_EDGE, points, 1)
