"""Cursor-driven vertical menu.

A menu is a list of labelled items, each with a callback. The cursor
moves up/down with arrow keys or D-pad/analog input. Confirm fires the
selected item's callback. Cancel fires the menu's optional cancel
callback.

Drawing puts a blinking triangle beside the selected row. A menu with
more rows than fit shows a window of them that slides to keep the
cursor in view, with a flashing arrow past the widest row wherever more
are hidden (ui/scroll_mark.py). The menu is deliberately simple — battle command menus
and pause menus can both be built on top of it.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

import pygame

from settings import ColorSettings, FontSettings, UISettings
from ui import text_renderer
from ui.scroll_mark import draw_list_marks

# From the end of the widest row to the middle of its scroll arrows.
_MARK_GAP = 6


@dataclass
class MenuItem:
    """One row of a menu."""

    label: str
    on_select: Callable[[], None]
    enabled: bool = True
    # Optional override for the row's label color. When ``None`` the
    # menu uses ``ColorSettings.WHITE`` (or ``GRAY`` if disabled). When
    # set, the override applies to enabled rows; disabled rows still
    # render gray so the "you can't pick this" affordance survives.
    # Used to tint ability rows by their element.
    color: tuple[int, int, int] | None = None
    # Optional halo for the row's label, paired with ``color``. Used by
    # shadow-element abilities so the lore-black body stays visible on the
    # black command panel. ``None`` skips the glow render path entirely.
    glow: tuple[int, int, int] | None = None
    glow_radius: int = 1
    glow_alpha: int = 90
    # An 8 by 8 picture in the letter space before the label, the cursor
    # before it: a weapon's icon (ui/item_icon.py).
    tag: pygame.Surface | None = None
    # What Select says of this row, held over it (the battle's help window, Frankie, 11/1); None says nothing.
    help: str | None = None


class Menu:
    """Cursor-driven vertical menu, controller and keyboard friendly."""

    def __init__(
        self,
        items: list[MenuItem],
        on_cancel: Optional[Callable[[], None]] = None,
    ) -> None:
        """Build a menu over ``items``."""
        self.items = items
        self.on_cancel = on_cancel
        self.cursor = self._first_enabled()
        # First row drawn when the menu shows a window of its rows.
        self._first_shown = 0

    # ------------------------------------------------------------------
    # NAVIGATION
    # ------------------------------------------------------------------

    def move_up(self) -> bool:
        return self._step(-1)

    def move_down(self) -> bool:
        return self._step(1)

    def confirm(self) -> bool:
        if 0 <= self.cursor < len(self.items):
            item = self.items[self.cursor]
            if item.enabled:
                item.on_select()
                return True
        return False

    def cancel(self) -> bool:
        if self.on_cancel is not None:
            self.on_cancel()
            return True
        return False

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def render(
        self,
        surface: pygame.Surface,
        position: tuple[int, int],
        centered: bool = False,
        item_spacing: int | None = None,
        font_size: int | None = None,
        row_height: int | None = None,
        max_rows: int | None = None,
        pointer: str | None = "hook",
    ) -> None:
        """Draw the menu starting at ``position``.

        Args:
            surface: The target render surface.
            position: Anchor position in pixels: the top of the first
                row's letters.
            centered: If True, each row label is centered on ``position[0]``.
            item_spacing: Optional per-render row gap in pixels (added
                to the text row height).
            font_size: Optional override for the row font size; defaults
                to ``FontSettings.SIZE_BODY``.
            row_height: Optional **explicit** pixel distance between
                rows. Overrides ``item_spacing`` + font metrics.
            max_rows: Rows that fit. When the menu has more, only this
                many are drawn, sliding so the cursor stays in view.
            pointer: The cursor: "hook", the fishhook; "arrow", the
                title's yellow triangle; None while the cursor is
                elsewhere on the screen, so only one hook shows.
        """
        size = FontSettings.SIZE_BODY if font_size is None else font_size
        if row_height is not None:
            line_height = row_height
        else:
            spacing = (
                UISettings.MENU_ITEM_SPACING if item_spacing is None
                else item_spacing
            )
            line_height = text_renderer.line_height(size) + spacing
        x, y = position

        first = self._slide_window(max_rows)
        shown = (
            self.items[first:first + max_rows] if max_rows is not None
            else self.items
        )
        for offset, item in enumerate(shown):
            index = first + offset
            # Disabled rows always render gray so the player can tell
            # they're locked out. Enabled rows use the row's own
            # ``color`` override (e.g. an ability's element accent)
            # when set, falling back to plain white. Disabled rows
            # always skip the glow path too — a halo on a "locked"
            # row would over-sell its availability.
            if not item.enabled:
                color = ColorSettings.GRAY
                glow = None
            elif item.color is not None:
                color = item.color
                glow = item.glow
            else:
                color = ColorSettings.WHITE
                glow = None
            row_y = y + offset * line_height
            text_x = x
            if centered:
                label_width = text_renderer.text_width(item.label, size)
                text_x = x - (label_width // 2)
            tag_width = 0
            if item.tag is not None:
                tag_width = item.tag.get_width()
                surface.blit(item.tag, (text_x - tag_width, row_y))
            if index == self.cursor and pointer is not None:
                draw = text_renderer.draw_arrow if pointer == "arrow" else text_renderer.draw_pointer
                draw(
                    surface,
                    (text_x - tag_width - UISettings.MENU_LABEL_OFFSET, row_y + size // 2),
                    ColorSettings.YELLOW,
                )
            text_renderer.draw_text(
                surface, item.label, (text_x, row_y), color, size=size,
                glow=glow,
                glow_radius=item.glow_radius,
                glow_alpha=item.glow_alpha,
            )
        if max_rows is not None and len(self.items) > max_rows:
            widest = max(text_renderer.text_width(item.label, size) for item in self.items)
            right = x + (widest // 2 if centered else widest)
            draw_list_marks(surface, right + _MARK_GAP, y, line_height, first, max_rows, len(self.items))

    # ------------------------------------------------------------------
    # INTERNALS
    # ------------------------------------------------------------------

    def _slide_window(self, max_rows: int | None) -> int:
        """Return the first row to draw, moved so the cursor is inside the window."""
        if max_rows is None or max_rows <= 0:
            return 0
        if self.cursor < self._first_shown:
            self._first_shown = self.cursor
        elif self.cursor >= self._first_shown + max_rows:
            self._first_shown = self.cursor - max_rows + 1
        self._first_shown = max(0, min(self._first_shown, len(self.items) - max_rows))
        return self._first_shown

    def _first_enabled(self) -> int:
        for index, item in enumerate(self.items):
            if item.enabled:
                return index
        return 0

    def _step(self, direction: int) -> bool:
        if not self.items:
            return False
        original_cursor = self.cursor
        n = len(self.items)
        for _ in range(n):
            self.cursor = (self.cursor + direction) % n
            if self.items[self.cursor].enabled:
                return self.cursor != original_cursor
        return False
