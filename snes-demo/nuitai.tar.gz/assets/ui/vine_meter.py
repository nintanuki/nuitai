"""Pōhuehue's second half on screen: spin the vine round the d-pad, then crack it with A (Frankie, 11/3).

The first half is the nature partner's dance (``ui/dance_meter.py``, the "pohuehue"
steps), which grows the vine. This half is the fire partner's: the same pad and
ring as Wili's spin (``ui/spin_meter.py``), and a green vine round the ring that
grows with every full turn, up to ``VINE_FULL_TURNS``. A cracks it. A crack with
the pad last pressed at the top, where the white mark is, hooks the enemy and
slams it down, for ``VINE_TOP`` times the hit. If the time runs out first, the
vine cracks on its own wherever it is. ``quality`` is what the hit is
multiplied by (``Battle.submit_combo``).
"""

from __future__ import annotations

import math

import pygame

from settings import FontSettings, MinigameSettings
from ui import text_renderer
from ui.spin_meter import SpinMeter, _LETTER, _RING

_VINE = (60, 200, 90)
_VINE_DARK = (16, 70, 30)
_MARK = (255, 255, 255)   # White, apart from the yellow arrows going round.
_TOP = (7, 0, 1)          # Up, and the corners beside it.


class VineMeter(SpinMeter):
    """The vine's turns, the crack, and how hard it will hit."""

    def __init__(self, combo_id: str, partner_id: str, target_id: str, dance_share: float) -> None:
        """Start the spin after the dance got ``dance_share`` (0 to 1) of its notes."""
        super().__init__(0)
        self.combo_id, self.partner_id, self.target_id = combo_id, partner_id, target_id
        self.dance_share = dance_share
        self.seconds = self.left = float(MinigameSettings.VINE_SECONDS)
        self.cracked = False
        self.at_top = False

    @property
    def done(self) -> bool:
        """True once the vine has cracked, by A or by the time running out."""
        return self.cracked or self.left <= 0

    @property
    def grown(self) -> float:
        """How long the vine has grown, 0 to 1, by the full turns."""
        return min(1.0, self.rotations / MinigameSettings.VINE_FULL_TURNS)

    def crack(self) -> bool:
        """A pressed: crack the vine; True when it was at the top."""
        if self.done:
            return False
        self.cracked = True
        self.at_top = self._place in _TOP
        return self.at_top

    @property
    def quality(self) -> float:
        """What the hit is multiplied by: the dance, the spin, and the crack at the top or not."""
        s = MinigameSettings
        dance = s.VINE_DANCE_FLOOR + (1 - s.VINE_DANCE_FLOOR) * self.dance_share
        spin = s.VINE_SPIN_FLOOR + (1 - s.VINE_SPIN_FLOOR) * self.grown
        return dance * spin * (s.VINE_TOP if self.at_top else 1.0)

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the pad with the vine round it, the mark at the top, the words beside it, the bar under."""
        center = (window.left + 34, window.top + 38)
        cx, cy = center
        radius = _RING + 5
        rect = pygame.Rect(cx - radius, cy - radius, 2 * radius, 2 * radius)
        pygame.draw.circle(surface, _VINE_DARK, center, radius, 1)
        if self.grown > 0:
            # Clockwise from the top, as far as it has grown.
            start = math.pi / 2 - 2 * math.pi * self.grown
            pygame.draw.arc(surface, _VINE, rect, start, math.pi / 2, 3)
        pygame.draw.polygon(surface, _MARK, [(cx - 3, cy - radius - 5), (cx + 3, cy - radius - 5), (cx, cy - radius - 1)])
        self.render_pad(surface, center)
        size = FontSettings.SIZE_BODY
        left = center[0] + radius + 8
        for n, text in enumerate(("Spin!", "Then A")):
            text_renderer.draw_text(surface, text, (left, window.top + 24 + 14 * n), color=_LETTER, size=size)
        self.render_bar(surface, pygame.Rect(window.left, window.bottom - 22, window.width, 12))
