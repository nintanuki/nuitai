"""Bordered JRPG-style dialogue box.

The text box hugs the bottom of its host surface, draws a bordered
panel, and reveals queued lines with a typewriter effect. Callers
``push`` lines (optionally with a speaker tag); pressing confirm
fast-forwards to the end of the current page or advances to the next
page. A line longer than the panel is split into pages of as many rows
as fit; a small triangle in the corner says there is more. When the
queue empties, ``is_done`` returns True and the host scene can pop the
box.

The text box does not own any input mapping itself — the host scene
calls ``advance()`` when its confirm button is pressed.
"""

from __future__ import annotations

from collections import deque
from typing import Optional

import pygame

from settings import ColorSettings, FontSettings, ScreenSettings, UISettings
from ui import text_renderer
from ui.window import draw_window


class TextBox:
    """A bordered dialogue panel with paginated typewriter text."""

    def __init__(
        self,
        width: int = ScreenSettings.WIDTH,
        height: int = UISettings.TEXT_BOX_HEIGHT,
        x: int = 0,
    ) -> None:
        """Construct a text box for the bottom of the screen.

        Args:
            width: Panel width in pixels (defaults to the full screen width).
            height: Panel height in pixels.
            x: The panel's left edge. The battle narrates in the left
                part of its window, so its box starts at 0 and is as
                wide as the command panel.
        """
        self.x = x
        self.width = width
        self.height = height
        self._queue: deque[tuple[Optional[str], str]] = deque()

        # The line being shown, wrapped and cut into pages of rows.
        self._current_speaker: Optional[str] = None
        self._pages: list[list[str]] = []
        self._page: int = 0
        self._chars_revealed: float = 0.0
        self._total_chars: int = 0

    # ------------------------------------------------------------------
    # GEOMETRY
    # ------------------------------------------------------------------

    @property
    def rows_per_page(self) -> int:
        """Rows of words a page holds; the speaker's name takes one."""
        rows = (self.height - 2 * UISettings.TEXT_BOX_PADDING) // text_renderer.line_height(
            FontSettings.SIZE_BODY
        )
        if self._current_speaker:
            rows -= 1
        return max(1, rows)

    # ------------------------------------------------------------------
    # QUEUE
    # ------------------------------------------------------------------

    def push(self, text: str, speaker: Optional[str] = None) -> None:
        """Append a line to the queue.

        Args:
            text: The line to display. Wrapping happens lazily when the
                line becomes the current one.
            speaker: Optional speaker label rendered above the line.
        """
        self._queue.append((speaker, text))
        if not self._pages:
            self._pull_next()

    def clear(self) -> None:
        """Drop any queued and currently-displayed text."""
        self._queue.clear()
        self._pages = []
        self._page = 0
        self._current_speaker = None
        self._chars_revealed = 0.0
        self._total_chars = 0

    def is_done(self) -> bool:
        """Return True when nothing is queued and nothing is displayed."""
        return not self._pages and not self._queue

    def is_page_complete(self) -> bool:
        """Return True if the current page has fully revealed its text."""
        return self._chars_revealed >= self._total_chars

    def has_more(self) -> bool:
        """Return True when another page or line follows the current page."""
        return self._page + 1 < len(self._pages) or bool(self._queue)

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def advance(self) -> None:
        """Advance presentation: fast-forward, next page, or next line."""
        if not self._pages:
            return
        if not self.is_page_complete():
            self._chars_revealed = self._total_chars
            return
        if self._page + 1 < len(self._pages):
            self._page += 1
            self._start_page()
            return
        self._pull_next()

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        """Advance the typewriter reveal by ``dt`` seconds.

        Args:
            dt: Frame time in seconds.
        """
        if not self._pages:
            return
        if self._chars_revealed < self._total_chars:
            self._chars_revealed += UISettings.TYPEWRITER_CHARS_PER_SECOND * dt
            if self._chars_revealed > self._total_chars:
                self._chars_revealed = float(self._total_chars)

    def render(self, surface: pygame.Surface) -> None:
        """Draw the panel and the currently-revealed text onto ``surface``."""
        if not self._pages:
            return

        host_h = surface.get_height()
        rect = pygame.Rect(self.x, host_h - self.height, self.width, self.height)
        draw_window(surface, rect)

        pad = UISettings.TEXT_BOX_PADDING
        x = rect.left + pad
        y = rect.top + pad
        line_height = text_renderer.line_height(FontSettings.SIZE_BODY)

        if self._current_speaker:
            y += text_renderer.draw_text(
                surface,
                self._current_speaker,
                (x, y),
                color=ColorSettings.YELLOW,
                size=FontSettings.SIZE_BODY,
            )

        # Reveal characters across the page's rows in order.
        revealed = int(self._chars_revealed)
        consumed = 0
        for line in self._pages[self._page]:
            if revealed <= consumed:
                break
            chunk = line[: max(0, revealed - consumed)]
            text_renderer.draw_text(
                surface,
                chunk,
                (x, y),
                color=ColorSettings.WHITE,
                size=FontSettings.SIZE_BODY,
            )
            y += line_height
            consumed += len(line)

        # The corner triangle: more to read after this page.
        if self.is_page_complete() and self.has_more():
            tip_x = rect.right - pad
            tip_y = rect.bottom - pad // 2
            pygame.draw.polygon(
                surface, ColorSettings.WHITE,
                [(tip_x, tip_y), (tip_x - 4, tip_y - 4), (tip_x + 4, tip_y - 4)],
            )

    # ------------------------------------------------------------------
    # INTERNALS
    # ------------------------------------------------------------------

    def _pull_next(self) -> None:
        """Take the next queued line, wrap it for the panel, cut it into pages."""
        if not self._queue:
            self.clear()
            return
        speaker, text = self._queue.popleft()
        body_font = text_renderer.get_font(FontSettings.SIZE_BODY)
        max_width = self.width - 2 * UISettings.TEXT_BOX_PADDING
        wrapped = text_renderer.wrap(text.upper(), body_font, max_width)
        self._current_speaker = speaker
        rows = self.rows_per_page
        self._pages = [wrapped[i:i + rows] for i in range(0, len(wrapped), rows)] or [[""]]
        self._page = 0
        self._start_page()

    def _start_page(self) -> None:
        """Begin revealing the current page from its first letter."""
        self._chars_revealed = 0.0
        self._total_chars = sum(len(line) for line in self._pages[self._page])
