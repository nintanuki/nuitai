"""Tinju Surya's second half on screen: one tap of A as the circle shrinks on the enemy (Frankie, 11/3).

The first half is the light partner's hand seals, Charm's Simon game
(``ui/simon_meter.py``): every round got right makes the fist glow brighter.
This half is the fire partner's punch, Moepapa's tap (``ui/banish_meter.py``):
the circle shrinks on the enemy and one tap of A throws it, the smaller the
circle the harder. Four suns over "Punch!" show the glow, one lit for each round
of seals got. ``quality`` is what the hit is multiplied by (``Battle.submit_combo``).
"""

from __future__ import annotations

import pygame

from settings import FontSettings, MinigameSettings
from ui import text_renderer
from ui.banish_meter import TapMeter

_SUN = (255, 222, 40)
_SUN_DIM = (90, 70, 20)
_LETTER = (255, 255, 255)
_MISS = (214, 40, 48)


class PunchMeter(TapMeter):
    """The seals got, the punch, and how hard it will hit."""

    def __init__(self, combo_id: str, partner_id: str, target_id: str, rounds: int) -> None:
        """Start the punch after ``rounds`` rounds of seals were got right."""
        super().__init__(target_id)
        self.combo_id, self.partner_id = combo_id, partner_id
        self.rounds = min(rounds, MinigameSettings.SIMON_ROUNDS)

    @property
    def glow(self) -> float:
        """How bright the fist is, 0 to 1, by the seals."""
        return self.rounds / MinigameSettings.SIMON_ROUNDS

    @property
    def quality(self) -> float:
        """What the hit is multiplied by: the seals, then the punch."""
        s = MinigameSettings
        seals = s.SUN_SEAL_FLOOR + (1 - s.SUN_SEAL_FLOOR) * self.glow
        return seals * (s.SUN_PUNCH_FLOOR + (self.share or 0.0))

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the four suns, lit by the seals, and under them what to do or how it went."""
        count = MinigameSettings.SIMON_ROUNDS
        for n in range(count):
            x = window.centerx + (n - (count - 1) / 2) * 16
            pygame.draw.circle(surface, _SUN if n < self.rounds else _SUN_DIM, (round(x), window.top + 20), 5)
        if self.share is None:
            text, color = ("Ready..." if self.ready > 0 else "Punch! A"), _LETTER
        elif self.share <= 0:
            text, color = "Missed!", _MISS
        else:
            text, color = ("Sunburst!" if self.share >= 0.5 else "Hit!"), _SUN
        size = FontSettings.SIZE_BODY
        text_renderer.draw_text(surface, text, (window.centerx - text_renderer.text_width(text, size) // 2,
                                                window.top + 40), color=color, size=size)
