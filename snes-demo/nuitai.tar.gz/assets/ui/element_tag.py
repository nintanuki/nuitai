"""A move's element tag: 7 by 7, cut on the diagonal (Frankie, 10/23).

It sits in the one-letter gap before a move's name on the ELEMENT grid,
like the browser game's move buttons and Chrono Cross's element slots,
with a pixel of space between it and the word. A dual move's tag is its
two colors meeting on the diagonal, the first element top left, with no
line between them; a single move's is its color top left and gray bottom
right. The cartridge cuts the same tags from ``tag_pixels``
(snes/tools/make_art.py).
"""

from __future__ import annotations

from typing import Any, Iterable

import pygame

from settings import ColorSettings

SIZE = 7      # The tag; it sits in an 8 by 8 square, the last column and row clear.
CELL = 8

# Each pixel's part: "a" the first element, "b" the second (or gray), "" clear.
# The diagonal itself goes with the first.
_PARTS: tuple[tuple[str, ...], ...] = tuple(
    tuple("" if x >= SIZE or y >= SIZE else "a" if x + y < SIZE else "b" for x in range(CELL))
    for y in range(CELL)
)


def tag_pixels() -> tuple[tuple[str, ...], ...]:
    """The 8 by 8 square's parts, row by row."""
    return _PARTS


def tag_elements(move: dict[str, Any], member_elements: Iterable[str]) -> tuple[str, str | None]:
    """The tag's two elements, as the browser picks a move button's: ``elements`` if the
    move names them, else a special uses both of the member's, its own first; else its
    one element and None (gray)."""
    named = move.get("elements")
    if not named and move.get("tier") == "special":
        mine = list(member_elements)
        named = [move["element"]] + [e for e in mine if e != move["element"]] if move["element"] in mine else mine
    named = list(dict.fromkeys(named or [move["element"]]))
    return named[0], (named[1] if len(named) > 1 else None)


def tag_color(element: str | None) -> tuple[int, int, int]:
    """An element's color on a tag; gray for none."""
    return ColorSettings.GRAY if element is None else ColorSettings.TAG_COLORS[element]


_CACHE: dict[tuple, pygame.Surface] = {}


def tag_surface(first: str, second: str | None) -> pygame.Surface:
    """The tag for ``first`` and ``second`` (None for a single move), in its 8 by 8 square."""
    key = (first, second)
    if key not in _CACHE:
        colors = {"a": tag_color(first), "b": tag_color(second)}
        surface = pygame.Surface((CELL, CELL), pygame.SRCALPHA)
        for y, row in enumerate(_PARTS):
            for x, part in enumerate(row):
                if part:
                    surface.set_at((x, y), colors[part])
        _CACHE[key] = surface
    return _CACHE[key]
