"""Escape on screen: alternate L and R, like Tawiri's A and B (Frankie, 11/4).

The same window as Tawiri's Call (``ui/rhythm_meter.py``): an L and an R
button side by side, each lighting as it is pressed, "Alternate!" over
them and the time draining along the bottom. Here the pace matters: reach
``needed`` presses, each the other shoulder from the last, before the time
runs out and the party gets away. The same shoulder twice does not count
and costs a little of the time (``MinigameSettings.ESCAPE_SLIP``); it never
ends the try by itself. ``needed`` comes from the stats that used to set the
escape chance (``Battle.escape_chance``): the better the chance, the fewer.
"""

from __future__ import annotations

import pygame

from settings import BattleSettings, FontSettings, MinigameSettings
from ui import text_renderer
from ui.block_meter import draw_frame, draw_shaded
from ui.spin_meter import _BAR_HEIGHT, _BAR_WIDTH

_RADIUS = 12
_FACES = {"L": ((20, 60, 110), (40, 110, 190), (120, 190, 255)),
          "R": ((20, 90, 50), (40, 160, 90), (120, 235, 160))}
_LETTER = (255, 255, 255)
_LIT = 0.1


def presses_needed(chance: float) -> int:
    """How many alternating presses it takes at an escape ``chance`` (the old limits, 0.1 to 0.9)."""
    low, high = BattleSettings.ESCAPE_LIMITS
    share = (max(low, min(high, chance)) - low) / (high - low)
    easiest, hardest = MinigameSettings.ESCAPE_EASIEST, MinigameSettings.ESCAPE_HARDEST
    return round(hardest + (easiest - hardest) * share)


class EscapeMeter:
    """The presses counted and the clock, for one try to run."""

    def __init__(self, chance: float = 0.5) -> None:
        """Start the clock; ``chance`` is ``Battle.escape_chance()`` and sets the count."""
        self.needed = presses_needed(chance)
        self.seconds = MinigameSettings.ESCAPE_SECONDS
        self.left = float(self.seconds)
        self.count = 0
        self.slips = 0
        self._last: str | None = None
        self._lit: tuple[str, float] | None = None

    @property
    def escaped(self) -> bool:
        """True once enough presses were made in time."""
        return self.count >= self.needed

    @property
    def done(self) -> bool:
        """True once the party is away or the time is up."""
        return self.escaped or self.left <= 0

    def press(self, button: str) -> bool:
        """Take a press of L or R; True if it was the other one from the last, False for the same twice."""
        if self.done:
            return False
        self._lit = (button, _LIT)
        if button == self._last:
            self.slips += 1
            self.left = max(0.0, self.left - MinigameSettings.ESCAPE_SLIP)
            return False
        self._last = button
        self.count += 1
        return True

    def update(self, dt: float) -> None:
        """Run the clock down by ``dt`` seconds."""
        if not self.escaped:
            self.left = max(0.0, self.left - dt)
        if self._lit is not None:
            button, left = self._lit
            self._lit = (button, left - dt) if left > dt else None

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw "Alternate!" and the count on top, L and R under it, the time along the bottom."""
        size = FontSettings.SIZE_BODY
        for text, top in (("Alternate!", 8), (f"{self.count} / {self.needed}", 20)):
            text_renderer.draw_text(surface, text, (window.centerx - text_renderer.text_width(text, size) // 2,
                                                    window.top + top), color=_LETTER, size=size)
        for button in "LR":
            x = window.centerx + (-1 if button == "L" else 1) * (_RADIUS + 6)
            y = window.top + 46
            rim, face, lit = _FACES[button]
            down = self._lit is not None and self._lit[0] == button
            pygame.draw.circle(surface, rim, (x, y + 2), _RADIUS + 1)
            pygame.draw.circle(surface, lit if down else face, (x, y + (2 if down else 0)), _RADIUS)
            width = text_renderer.text_width(button, size)
            text_renderer.draw_text(surface, button, (x - width // 2 + 1, y - 3 + (2 if down else 0)),
                                    color=_LETTER, size=size)
        frame = pygame.Rect(0, 0, _BAR_WIDTH + 4, _BAR_HEIGHT + 4)
        frame.center = pygame.Rect(window.left, window.bottom - 22, window.width, 12).center
        well = draw_frame(surface, frame)
        draw_shaded(surface, well, well.left, round(_BAR_WIDTH * self.left / self.seconds))
