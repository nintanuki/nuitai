"""Escape on screen: alternate L and R in a steady rhythm of your own (Frankie, 11/4).

Tawiri's Call on the shoulder buttons (``ui/rhythm_meter.py``): the same
window, "Alternate!" and the Steady, Wobbly or Uneven word over L and R, the
time draining along the bottom. Nothing keeps the beat; fast or slow does not
matter, only even, and the same shoulder twice is a missed beat. How tight the
rhythm was, ``quality`` 0 to 1, sets the chance of getting away, which is then
rolled (``Battle.submit_escape``). The runner's Speed against the fastest
foe's is the ``ease``: it widens or narrows how uneven the rhythm may be
(``Battle.escape_ease``).

L and R are drawn as the controller's shoulder buttons, wide grey tabs
rounded on top, not round face buttons (Frankie, 11/4).
"""

from __future__ import annotations

import pygame

from settings import FontSettings, MinigameSettings
from ui import text_renderer
from ui.rhythm_meter import RhythmMeter

_TAB = (34, 14)           # A shoulder button's width and height.
_RIM = (58, 58, 66)
_FACE = (150, 150, 160)
_LIT = (224, 224, 232)
_SHINE = (196, 196, 206)
_LETTER = (44, 44, 52)


class EscapeMeter(RhythmMeter):
    """The presses timed and the clock, for one try to run."""

    BUTTONS = "LR"
    SECONDS = MinigameSettings.ESCAPE_SECONDS
    SPREAD = MinigameSettings.ESCAPE_SPREAD
    PRESSES = MinigameSettings.ESCAPE_PRESSES

    def _draw_button(self, surface: pygame.Surface, button: str, i: int, window: pygame.Rect, down: bool) -> None:
        """Draw L or R as a shoulder tab, round along the top, ``i`` 0 on the left, sunk while ``down``."""
        width, height = _TAB
        sink = 2 if down else 0
        x = window.centerx + (-1 if i == 0 else 1) * (width // 2 + 4)
        top = window.top + 40
        corners = {"border_top_left_radius": 7, "border_top_right_radius": 7,
                   "border_bottom_left_radius": 2, "border_bottom_right_radius": 2}
        rim = pygame.Rect(0, 0, width + 2, height + 2)
        rim.midtop = (x, top + 1)
        pygame.draw.rect(surface, _RIM, rim.move(0, 1), **corners)
        tab = pygame.Rect(0, 0, width, height)
        tab.midtop = (x, top + sink)
        pygame.draw.rect(surface, _LIT if down else _FACE, tab, **corners)
        if not down:
            pygame.draw.line(surface, _SHINE, (tab.left + 5, tab.top + 1), (tab.right - 6, tab.top + 1))
        size = FontSettings.SIZE_BODY
        text_renderer.draw_text(surface, button, (x - text_renderer.text_width(button, size) // 2 + 1,
                                                  tab.top + 3), color=_LETTER, size=size)
