"""A small bar along the top of the screen for lines that should not stop play.

"Kailo's Strength went up!" goes here instead of the battle's text box
(Frankie, 10/18, D-526): the fight carries on underneath while it shows.
Each line stays a few seconds and goes; lines that come in while one is
showing wait their turn, and each gets its own few seconds.
"""

from __future__ import annotations

from collections import deque
from typing import Any

import pygame

from settings import ColorSettings, FontSettings, UISettings
from ui import text_renderer
from ui.window import draw_window


class NoticeBar:
    """A queue of short lines, shown one at a time at the top of the screen."""

    def __init__(self, rect: pygame.Rect, seconds: float = UISettings.NOTICE_SECONDS) -> None:
        """Build an empty bar.

        Args:
            rect: Where the bar draws.
            seconds: How long each line stays.
        """
        self.rect = rect
        self.seconds = seconds
        self._queue: deque[tuple[str, dict[str, dict[str, Any]]]] = deque()
        self._line: tuple[str, dict[str, dict[str, Any]]] | None = None
        self._left = 0.0

    def push(self, text: str, keywords: dict[str, dict[str, Any]] | None = None) -> None:
        """Queue ``text``; ``keywords`` colour words in it, as the text box's do."""
        self._queue.append((text, {text_renderer.cased(w): s for w, s in (keywords or {}).items()}))

    def is_done(self) -> bool:
        """Whether nothing is showing or waiting."""
        return self._line is None and not self._queue

    def update(self, dt: float) -> None:
        """Count down the line showing, and bring on the next when it is gone."""
        if self._line is not None:
            self._left -= dt
            if self._left > 0:
                return
            self._line = None
        if self._queue:
            self._line = self._queue.popleft()
            self._left = self.seconds

    def render(self, surface: pygame.Surface) -> None:
        """Draw the line showing, centred in its window, key words in their colours."""
        if self._line is None:
            return
        text, keywords = self._line
        text = text_renderer.cased(text)
        size = FontSettings.SIZE_BODY
        draw_window(surface, self.rect)
        # Cut the line into plain and key-word pieces, in order.
        pieces: list[tuple[str, dict[str, Any]]] = []
        pos = 0
        spans = sorted(
            (text.find(word), word, style) for word, style in keywords.items() if word in text
        )
        for start, word, style in spans:
            if start < pos:
                continue
            pieces += [(text[pos:start], {}), (word, style)]
            pos = start + len(word)
        pieces.append((text[pos:], {}))
        width = sum(text_renderer.text_width(piece, size) for piece, _ in pieces)
        x = self.rect.centerx - width // 2
        y = self.rect.centery - text_renderer.line_height(size) // 2 + 1
        for piece, look in pieces:
            if not piece:
                continue
            text_renderer.draw_text(
                surface, piece, (x, y), **{"color": ColorSettings.WHITE, **look}, size=size,
            )
            x += text_renderer.text_width(piece, size)
