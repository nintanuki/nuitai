"""An item's icon: one per kind of item, Final Fantasy VI's (Frankie, 10/24).

Each is 7 by 7 in an 8 by 8 letter space, the last column and row clear,
and sits in the letter space right before the item's name, as a move's
ELEMENT tag does (ui/element_tag.py). The pixels and three shades of each
kind are in ``game/shared/item-icons.json``, drawn once and kept as drawn.
A lontar shows its move's own ELEMENT tag; a weapon its type's icon. An
item with no kind yet has no icon (``item_kind`` says None). The
cartridge cuts the same icons (snes/tools/make_art.py).
"""

from __future__ import annotations

import json
import os
from typing import Any

import pygame

from core.shared import SHARED, SHARED_DIR, by_id
from settings import ItemSettings
from ui.element_tag import CELL, tag_elements, tag_surface

with open(os.path.join(SHARED_DIR, "item-icons.json"), encoding="utf-8") as _f:
    ICONS: dict[str, Any] = json.load(_f)

# The plant medicine (Frankie, 10/24): what heals or cures and was never cooked.
MEDICINE: tuple = ("noni", "awa", "kukui", "ti_leaf", "olena")
FOOD: tuple = tuple(dish["id"] for dish in SHARED["cooking"]["dishes"])
SPECIAL: tuple = ("seer_shell",)


def weapon_kind(weapon_type: str) -> str:
    """A weapon type's icon in the json, by the type's plural name: "Bo Staffs" is bo_staffs."""
    return by_id("weapon_types")[weapon_type]["name"].lower().replace(" ", "_")


def item_kind(item_id: str) -> str | None:
    """Which icon ``item_id`` shows: a kind in the json, "element" for a lontar, or None."""
    if item_id in ItemSettings.SHELLS:
        return "element"
    if item_id in ItemSettings.INGREDIENTS:
        return "ingredient"
    if item_id in FOOD:
        return "food"
    if item_id in MEDICINE:
        return "medicine"
    if item_id in ItemSettings.SEEDS:
        return "seed"
    if item_id in SPECIAL:
        return "special"
    weapon = by_id("weapons").get(item_id)
    return weapon_kind(weapon["type"]) if weapon else None


def _hex(color: str) -> tuple[int, int, int]:
    return tuple(int(color[i:i + 2], 16) for i in (1, 3, 5))


_CACHE: dict[str, pygame.Surface] = {}


def kind_surface(kind: str) -> pygame.Surface:
    """The icon of one kind in the json, in its 8 by 8 square."""
    if kind not in _CACHE:
        icon = ICONS["icons"][kind]
        shades = [_hex(c) for c in ICONS["palettes"][icon["palette"]]]
        surface = pygame.Surface((CELL, CELL), pygame.SRCALPHA)
        for y, row in enumerate(icon["pixels"]):
            for x, pixel in enumerate(row):
                if pixel != ".":
                    surface.set_at((x, y), shades[int(pixel) - 1])
        _CACHE[kind] = surface
    return _CACHE[kind]


def item_icon(item_id: str) -> pygame.Surface | None:
    """The icon before ``item_id``'s name, or None for an item with no kind yet."""
    kind = item_kind(item_id)
    if kind is None:
        return None
    if kind == "element":
        member_id, move_id = ItemSettings.SHELLS[item_id]
        elements = by_id("characters")[member_id]["elements"]
        return tag_surface(*tag_elements(by_id("moves")[move_id], elements))
    return kind_surface(kind)


def weapon_icon(weapon: dict[str, Any]) -> pygame.Surface:
    """The icon before a weapon's name: its type's."""
    return kind_surface(weapon_kind(weapon["type"]))
