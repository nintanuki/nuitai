"""Geometry helpers for UI layout: the F3 debug overlay.

``DebugOverlay`` draws labeled rectangles over a scene so a layout can be
checked by eye. (The roster row geometry that once lived here, one anchor
rectangle per region with everything else derived from its Rect properties,
was never used by a scene and was removed.)
"""

from __future__ import annotations

from typing import Iterable

import pygame

from settings import FontSettings
from ui import text_renderer


# ---------------------------------------------------------------------
# DEBUG OVERLAY
# ---------------------------------------------------------------------


class DebugOverlay:
    """Toggleable visual overlay for UI layout debugging.

    Why this exists
    ---------------
    When something is "off by a few pixels", the fastest way to debug
    is to *see* the bounding rectangles the layout code is computing.
    Without this, you launch the game, squint, change a number, relaunch,
    squint again, repeat. With this, you press F1 in-game and every
    registered element shows up as a colored outline with its semantic
    name floating above it. Misalignments become obvious in one frame.

    How to use it
    -------------
    1. Press ``F1`` in-game to toggle. Wired in ``main.py``.
    2. In your scene's render path, call ``DebugOverlay.rect(surface,
       rect, "portrait")`` or ``DebugOverlay.point(surface, pos,
       "name")`` at the moment you've computed a position you'd like
       to be able to see. The call is a no-op when the overlay is off,
       so leave them in.
    3. Pick a color per category if you want — e.g. magenta for
       portraits, cyan for text anchors, yellow for cursors — so you
       can tell categories apart at a glance.

    Why a class with classmethods instead of an instance? The overlay
    is one global on/off; threading it through every scene as an
    instance is more ceremony than the feature deserves. ``classmethod``
    keeps the call sites short (``DebugOverlay.rect(...)``).
    """

    # Master switch. Flipped by main.py's F1 handler.
    enabled: bool = False

    # Default colors for common categories. Use these so the same kind
    # of element always shows up in the same color across scenes.
    COLOR_PORTRAIT = (255, 0, 255)   # magenta
    COLOR_TEXT = (0, 255, 255)       # cyan
    COLOR_CURSOR = (255, 220, 0)     # yellow
    COLOR_PANEL = (0, 255, 0)        # green
    COLOR_REGION = (255, 120, 0)     # orange

    @classmethod
    def toggle(cls) -> None:
        """Flip the overlay on/off. Called by the F1 key handler."""
        cls.enabled = not cls.enabled

    @classmethod
    def rect(
        cls,
        surface: pygame.Surface,
        rect: pygame.Rect | tuple[int, int, int, int],
        label: str,
        color: tuple[int, int, int] = COLOR_PORTRAIT,
    ) -> None:
        """Draw a 1px outline + label for one rectangle.

        No-op when ``enabled`` is False so call sites are free.

        Args:
            surface: The screen surface (same one the scene is
                rendering to).
            rect: A pygame.Rect or 4-tuple ``(x, y, w, h)``.
            label: Short semantic name shown above the rectangle.
                The label is rendered ALL-CAPS by the text renderer
                so keep it terse.
            color: RGB stroke color. Defaults to the portrait magenta;
                pass ``DebugOverlay.COLOR_TEXT`` etc. for other
                categories.
        """
        if not cls.enabled:
            return
        rect = rect if isinstance(rect, pygame.Rect) else pygame.Rect(rect)
        pygame.draw.rect(surface, color, rect, 1)
        cls._label(surface, (rect.left, rect.top - 6), label, color)

    @classmethod
    def point(
        cls,
        surface: pygame.Surface,
        pos: tuple[int, int],
        label: str,
        color: tuple[int, int, int] = COLOR_TEXT,
    ) -> None:
        """Draw a small crosshair + label at a single anchor position.

        Use this for things that aren't rectangles — text anchors,
        cursor tips, alignment points. No-op when the overlay is off.
        """
        if not cls.enabled:
            return
        x, y = pos
        # 5px crosshair so the anchor's exact pixel is identifiable.
        pygame.draw.line(surface, color, (x - 4, y), (x + 4, y), 1)
        pygame.draw.line(surface, color, (x, y - 4), (x, y + 4), 1)
        cls._label(surface, (x + 6, y - 6), label, color)

    @classmethod
    def polygon(
        cls,
        surface: pygame.Surface,
        points: Iterable[tuple[int, int]],
        label: str,
        color: tuple[int, int, int] = COLOR_CURSOR,
    ) -> None:
        """Outline an arbitrary polygon (e.g. the selection triangle)."""
        if not cls.enabled:
            return
        pts = list(points)
        if len(pts) < 2:
            return
        pygame.draw.polygon(surface, color, pts, 1)
        cls._label(surface, (pts[0][0], pts[0][1] - 6), label, color)

    # -----------------------------------------------------------------
    # INTERNALS
    # -----------------------------------------------------------------

    @classmethod
    def _label(
        cls,
        surface: pygame.Surface,
        pos: tuple[int, int],
        text: str,
        color: tuple[int, int, int],
    ) -> None:
        """Render a small debug label at ``pos``.

        Uses the smallest font in the renderer so labels don't
        smother the UI they're annotating. The text_renderer
        upper-cases everything automatically.
        """
        text_renderer.draw_text(surface, text, pos, color, FontSettings.SIZE_SMALL)
