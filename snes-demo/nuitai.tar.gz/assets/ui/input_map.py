"""Shared input helpers for scenes.

Centralises the mapping from raw pygame events to logical UI actions
(``confirm``, ``cancel``, ``up``, ``down``, ``left``, ``right``) so each
scene doesn't reimplement the keyboard + controller routing.
"""

from __future__ import annotations

import pygame

from settings import InputSettings
from systems import config


# The keys that stand for the pad's four face buttons, before Config swaps
# them (Frankie, 10/26: A with B, X with Y, the keyboard as the pad).
CONFIRM_KEYS = (pygame.K_RETURN, pygame.K_z, pygame.K_SPACE)  # A
CANCEL_KEYS = (pygame.K_BACKSPACE, pygame.K_x)  # B
UP_KEYS = (pygame.K_UP, pygame.K_w)
DOWN_KEYS = (pygame.K_DOWN, pygame.K_s)
LEFT_KEYS = (pygame.K_LEFT, pygame.K_a)
RIGHT_KEYS = (pygame.K_RIGHT, pygame.K_d)
# The shoulder buttons on the keyboard: switch characters on the Element, Equip and Status pages.
L1_KEYS = (pygame.K_q,)
R1_KEYS = (pygame.K_e,)
# The field menu opens on X (below), and on Enter too, whatever Config
# swaps: Enter in the overworld advances any active text first, then opens
# the menu the next time.
MENU_KEYS = (pygame.K_RETURN,)
# The key that stands for the pad's X button: moves the text box to the top and back.
# Not Enter, which also confirms (Frankie, 10/25).
TEXTBOX_FLIP_KEYS = (pygame.K_TAB,)  # X
# The pad's Y button, the field tools (Frankie, 10/26); C, beside Z and X.
Y_KEYS = (pygame.K_c,)
# Keys that pause and unpause, anywhere (D-575).
PAUSE_KEYS = (pygame.K_p,)
# SELECT on the keyboard: either Shift (on the title it opens the scene select).
SELECT_KEYS = (pygame.K_LSHIFT, pygame.K_RSHIFT)

# On the pad, by position as on a Super Nintendo pad (Frankie, 10/24): A (east)
# confirms, B (south) cancels, X (north) opens the menu, START pauses.
_FACE = {
    "A": (CONFIRM_KEYS, InputSettings.JOY_BUTTON_A),
    "B": (CANCEL_KEYS, InputSettings.JOY_BUTTON_B),
    "X": (TEXTBOX_FLIP_KEYS, InputSettings.JOY_BUTTON_X),
    "Y": (Y_KEYS, InputSettings.JOY_BUTTON_Y),
}

# Config's Buttons, read here rather than from ``config.current`` while the
# Config screen is open, so a swap made there waits until it closes and the
# next press there still does what the player's hand expects (10/26).
held: config.Config | None = None


def physical(button: str) -> str:
    """The face button that does ``button``'s job now: A's is B's once Config swaps them."""
    settings = held or config.current
    if settings.swap_ab and button in "AB":
        return "B" if button == "A" else "A"
    if settings.swap_xy and button in "XY":
        return "Y" if button == "X" else "X"
    return button


def _face(event: pygame.event.Event, button: str, down: bool = True) -> bool:
    """Return True if ``event`` presses the key or pad button doing ``button``'s job
    (lets go of it, with ``down`` False)."""
    keys, pad = _FACE[physical(button)]
    key_type, pad_type = (pygame.KEYDOWN, pygame.JOYBUTTONDOWN) if down else (pygame.KEYUP, pygame.JOYBUTTONUP)
    if event.type == key_type and event.key in keys:
        return True
    return event.type == pad_type and event.button == pad


def confirm_key() -> int:
    """A key that confirms now, for a press made in code (the scene select's)."""
    return sorted(_FACE[physical("A")][0])[0]


def is_confirm(event: pygame.event.Event) -> bool:
    """Return True if ``event`` is a confirm press (Enter / Z / Space / A; B's once swapped)."""
    return _face(event, "A")


def is_cancel(event: pygame.event.Event) -> bool:
    """Return True if ``event`` is a cancel press (Backspace / X / B; A's once swapped)."""
    return _face(event, "B")


def is_up(event: pygame.event.Event) -> bool:
    """Return True for an up press (arrow / WASD / D-pad up / left-stick up)."""
    if event.type == pygame.KEYDOWN and event.key in UP_KEYS:
        return True
    if event.type == pygame.JOYHATMOTION and event.value[1] > 0:
        return True
    if event.type == pygame.JOYAXISMOTION and event.axis == InputSettings.JOY_AXIS_LEFT_Y:
        if event.value < -InputSettings.JOY_TRIGGER_THRESHOLD:
            return True
    return False


def is_down(event: pygame.event.Event) -> bool:
    """Return True for a down press."""
    if event.type == pygame.KEYDOWN and event.key in DOWN_KEYS:
        return True
    if event.type == pygame.JOYHATMOTION and event.value[1] < 0:
        return True
    if event.type == pygame.JOYAXISMOTION and event.axis == InputSettings.JOY_AXIS_LEFT_Y:
        if event.value > InputSettings.JOY_TRIGGER_THRESHOLD:
            return True
    return False


def is_left(event: pygame.event.Event) -> bool:
    """Return True for a left press (arrow / A / D-pad left / left-stick left)."""
    if event.type == pygame.KEYDOWN and event.key in LEFT_KEYS:
        return True
    if event.type == pygame.JOYHATMOTION and event.value[0] < 0:
        return True
    if event.type == pygame.JOYAXISMOTION and event.axis == InputSettings.JOY_AXIS_LEFT_X:
        if event.value < -InputSettings.JOY_TRIGGER_THRESHOLD:
            return True
    return False


def is_right(event: pygame.event.Event) -> bool:
    """Return True for a right press (arrow / D / D-pad right / left-stick right)."""
    if event.type == pygame.KEYDOWN and event.key in RIGHT_KEYS:
        return True
    if event.type == pygame.JOYHATMOTION and event.value[0] > 0:
        return True
    if event.type == pygame.JOYAXISMOTION and event.axis == InputSettings.JOY_AXIS_LEFT_X:
        if event.value > InputSettings.JOY_TRIGGER_THRESHOLD:
            return True
    return False


def is_l1(event: pygame.event.Event) -> bool:
    """Return True for an L1 press (Q, the shoulder button), as Mesen's keyboard has it."""
    if event.type == pygame.KEYDOWN and event.key in L1_KEYS:
        return True
    return event.type == pygame.JOYBUTTONDOWN and event.button == InputSettings.JOY_BUTTON_L1


def is_r1(event: pygame.event.Event) -> bool:
    """Return True for an R1 press (E, the shoulder button)."""
    if event.type == pygame.KEYDOWN and event.key in R1_KEYS:
        return True
    return event.type == pygame.JOYBUTTONDOWN and event.button == InputSettings.JOY_BUTTON_R1


def is_menu(event: pygame.event.Event) -> bool:
    """Return True for the field menu press (X: Tab or the pad's X, Y's once swapped; Enter too)."""
    if event.type == pygame.KEYDOWN and event.key in MENU_KEYS:
        return True
    return _face(event, "X")


def is_tool(event: pygame.event.Event) -> bool:
    """Return True for the tool press (Y: C or the pad's Y, X's once swapped), Frankie 10/26."""
    return _face(event, "Y")


def is_tool_up(event: pygame.event.Event) -> bool:
    """Return True for letting go of the tool button: a tap uses the tool, a hold sets one (10/28)."""
    return _face(event, "Y", down=False)


def is_textbox_flip(event: pygame.event.Event) -> bool:
    """Return True for the press that moves a dialogue box to the top or back (X: Tab / pad X)."""
    return _face(event, "X")


def is_pause(event: pygame.event.Event) -> bool:
    """Return True for the pause press (P / START), D-575."""
    if event.type == pygame.KEYDOWN and event.key in PAUSE_KEYS:
        return True
    if event.type == pygame.JOYBUTTONDOWN and event.button == InputSettings.JOY_BUTTON_START:
        return True
    return False


def is_select(event: pygame.event.Event) -> bool:
    """Return True for a SELECT press (Shift / SELECT)."""
    if event.type == pygame.KEYDOWN and event.key in SELECT_KEYS:
        return True
    return event.type == pygame.JOYBUTTONDOWN and event.button == InputSettings.JOY_BUTTON_BACK


def read_held_direction(joysticks) -> tuple[int, int]:
    """Return the currently-held cardinal direction as ``(dx, dy)``.

    Polls keyboard state and every connected joystick's D-pad and left
    analog stick. Each axis is clamped to one of ``-1``, ``0``, ``+1``;
    diagonals are returned as-is and the caller decides how to resolve
    them (the overworld player prefers horizontal when both are held).

    Args:
        joysticks: Iterable of connected ``pygame.joystick.Joystick``
            instances, normally ``GameManager.connected_joysticks``.

    Returns:
        A ``(dx, dy)`` tuple in ``{-1, 0, +1} x {-1, 0, +1}`` where
        ``dx`` is east-positive and ``dy`` is south-positive.
    """
    dx = 0
    dy = 0
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] or keys[pygame.K_a]:
        dx -= 1
    if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        dx += 1
    if keys[pygame.K_UP] or keys[pygame.K_w]:
        dy -= 1
    if keys[pygame.K_DOWN] or keys[pygame.K_s]:
        dy += 1
    threshold = InputSettings.JOY_TRIGGER_THRESHOLD
    for joystick in joysticks:
        # D-pad: pygame hats use screen-inverted Y (up = +1).
        try:
            if joystick.get_numhats() > 0:
                hx, hy = joystick.get_hat(0)
                dx += hx
                dy -= hy
        except pygame.error:
            pass
        # Left analog stick.
        try:
            ax = joystick.get_axis(InputSettings.JOY_AXIS_LEFT_X)
            ay = joystick.get_axis(InputSettings.JOY_AXIS_LEFT_Y)
        except pygame.error:
            ax = 0.0
            ay = 0.0
        if ax < -threshold:
            dx -= 1
        elif ax > threshold:
            dx += 1
        if ay < -threshold:
            dy -= 1
        elif ay > threshold:
            dy += 1
    # Clamp so multiple sources holding the same direction don't stack.
    if dx > 1:
        dx = 1
    elif dx < -1:
        dx = -1
    if dy > 1:
        dy = 1
    elif dy < -1:
        dy = -1
    return dx, dy
