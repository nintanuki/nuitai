"""Draw the timed block meter in the bottom window's left half (Frankie, 10/30).

A thin black well in a two ring border with cut corners, a shaded yellow zone at
its left, and pairs of red arrows (above and below) sliding left toward it, as in
Frankie's approved mock-up. The command menu is gone while it is up. A perfect catch floats PERFECT up from the meter.
"""

from __future__ import annotations

import pygame

from settings import BlockSettings, ColorSettings, FontSettings
from systems.timed_block import BlockMeter
from ui import text_renderer

_BORDER = 2  # Frame thickness: an outer and an inner ring.
_WELL = (6, 6, 10)
_SHINE = (36, 36, 48)
_RING_OUTER = (120, 128, 150)
_RING_INNER = (232, 236, 244)
_BEVEL = (168, 176, 196)
# The zone, one color per row from top to bottom, with a pale left edge and a dark right edge.
_ZONE_ROWS = ((255, 244, 150), (255, 226, 80), (255, 206, 40), (250, 190, 24), (240, 170, 16),
              (226, 150, 12), (210, 132, 8), (190, 112, 6), (170, 96, 4), (150, 80, 4))
_ZONE_EDGE_LEFT = (255, 250, 200)
_ZONE_EDGE_RIGHT = (150, 90, 4)
_ARROW_LEFT = (255, 150, 140)
_ARROW_MIDDLE = (240, 64, 56)
_ARROW_RIGHT = (196, 24, 24)
_ARROW_BASE = (120, 8, 12)


class BlockMeterView:
    """The meter, its PERFECT pop-ups, and where they are drawn."""

    def __init__(self, meter: BlockMeter) -> None:
        """Wrap the ``meter`` whose bars are drawn."""
        self.meter = meter
        self._pops: list[float] = []  # Ages of the PERFECTs rising.

    def perfect(self) -> None:
        """Start a PERFECT rising from the meter."""
        self._pops.append(0.0)

    def update(self, dt: float) -> None:
        """Age the pop-ups, dropping the ones that are done."""
        self._pops = [age + dt for age in self._pops if age + dt < BlockSettings.POP_SECONDS]

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the meter centered in ``window``, the left window of the bottom row."""
        length = BlockSettings.LENGTH
        frame = pygame.Rect(0, 0, length + 2 * _BORDER, BlockSettings.HEIGHT + 2 * _BORDER)
        frame.center = window.center
        well = pygame.Rect(frame.left + _BORDER, frame.top + _BORDER, length, BlockSettings.HEIGHT)
        bar = frame
        pygame.draw.rect(surface, _WELL, well)
        pygame.draw.line(surface, _SHINE, well.topleft, (well.right - 1, well.top))
        # Two rings with their corner pixels cut; the row under the well is a lighter bevel.
        for inset, color in ((0, _RING_OUTER), (1, _RING_INNER)):
            ring = frame.inflate(-2 * inset, -2 * inset)
            l, t, r, b = ring.left, ring.top, ring.right - 1, ring.bottom - 1
            for start, end in (((l + 1, t), (r - 1, t)), ((l + 1, b), (r - 1, b)),
                               ((l, t + 1), (l, b - 1)), ((r, t + 1), (r, b - 1))):
                pygame.draw.line(surface, color, start, end)
        pygame.draw.line(surface, _BEVEL, (well.left, well.bottom), (well.right - 1, well.bottom))
        meter = self.meter
        for row, color in enumerate(_ZONE_ROWS):
            y = well.top + row
            pygame.draw.line(surface, color, (well.left + meter.zone_left, y),
                             (well.left + meter.zone_left + meter.zone - 1, y))
        pygame.draw.line(surface, _ZONE_EDGE_LEFT, (well.left + meter.zone_left, well.top),
                         (well.left + meter.zone_left, well.bottom - 1))
        pygame.draw.line(surface, _ZONE_EDGE_RIGHT, (well.left + meter.zone_left + meter.zone - 1, well.top),
                         (well.left + meter.zone_left + meter.zone - 1, well.bottom - 1))
        old_clip = surface.get_clip()
        surface.set_clip(pygame.Rect(frame.left, 0, frame.width, surface.get_height()))
        for red in meter.bars:
            # A caught stroke is gone; one pressed too early keeps sliding until it lands.
            if red.result in ("catch", "perfect"):
                continue
            self._arrows(surface, well.left + round(red.x), frame, red.width)
        surface.set_clip(old_clip)
        for age in self._pops:
            progress = age / BlockSettings.POP_SECONDS
            text = "PERFECT"
            width = text_renderer.text_width(text, FontSettings.SIZE_BODY)
            x = bar.centerx - width // 2
            top = bar.top - 14 - round(BlockSettings.POP_RISE * progress)
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                text_renderer.draw_text(
                    surface, text, (x + dx, top + dy), color=ColorSettings.BLACK, size=FontSettings.SIZE_BODY)
            text_renderer.draw_text(
                surface, text, (x, top), color=ColorSettings.YELLOW, size=FontSettings.SIZE_BODY)

    @staticmethod
    def _arrows(surface: pygame.Surface, column: int, frame: pygame.Rect, width: int) -> None:
        """Draw one stroke's pair of arrows, tips toward the bar, squeezing its frame.

        ``column`` is the middle column. The tips sit on the frame's inner ring rows,
        so the pair is centered on the frame; each base line is one row beyond the
        widest row.
        """
        rows = (width + 1) // 2
        for step, tip in ((-1, frame.top + 1), (1, frame.bottom - 2)):  # Above pointing down, below pointing up.
            for k in range(rows):
                y = tip + step * k
                half = k
                pygame.draw.line(surface, _ARROW_MIDDLE, (column - half, y), (column + half, y))
                pygame.draw.line(surface, _ARROW_LEFT, (column - half, y), (column - half, y))
                if half:
                    pygame.draw.line(surface, _ARROW_RIGHT, (column + half, y), (column + half, y))
            base = tip + step * rows
            pygame.draw.line(surface, _ARROW_BASE, (column - rows + 1, base), (column + rows - 1, base))
