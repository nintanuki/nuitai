"""Kailo's Cook on screen: stir the pot by turning the d-pad round, as steady as you can (Frankie, 11/1).

The same pad and ring as Wili's spin (``ui/spin_meter.py``), in the window the
commands were in, but the game is the other way round: not as fast as you can,
as even as you can. Every step round the pad is timed, and the steadier the
time between them, the better the dish. Stopping, jerking or turning back
counts against it, and so does too little stirring. "Stir!" sits beside the
pad, and under it a word for how it is going: Steady, Wobbly or Uneven.
When the bar is empty everyone eats (``Battle.submit_cook``).

How hard it is comes from Kailo's Perception against the monsters'
(Frankie, 11/1): the ``ease`` widens or narrows how uneven he may be.
"""

from __future__ import annotations

import pygame

from settings import FontSettings, MinigameSettings
from ui import text_renderer
from ui.block_meter import draw_frame, draw_shaded
from ui.spin_meter import SpinMeter, _BAR_HEIGHT, _BAR_WIDTH, _LETTER, _RING

_STEADY = (96, 220, 96)
_WOBBLY = (255, 222, 40)
_UNEVEN = (240, 64, 56)


class StirMeter(SpinMeter):
    """The clock and the stirring timed, for one Cook."""

    def __init__(self, dish: str, ease: float = 1.0) -> None:
        """Start the clock to stir ``dish``; ``ease`` is from the stats, 1 when even."""
        super().__init__(0)
        self.dish = dish
        self.ease = ease
        self.seconds = self.left = float(MinigameSettings.STIR_SECONDS)
        self._steps: list[tuple[float, int]] = []   # When each step came, and how many eighths it was.

    def _stepped(self, move: int) -> None:
        """Time the step: when it came and how far round it went."""
        self._steps.append((self._age, abs(move)))

    def _gaps(self, closing: bool) -> list[float]:
        """The time per eighth between each step and the next; ``closing`` counts a stop before the end."""
        gaps = [(t - t0) / eighths for (t0, _), (t, eighths) in zip(self._steps, self._steps[1:])]
        if closing and gaps:
            # Stopping early is uneven too: the wait from the last step to the end, if it is
            # well past a usual step, counts as one more step that long.
            steps = [t - t0 for (t0, _), (t, _) in zip(self._steps, self._steps[1:])]
            eighths = sum(e for _, e in self._steps[1:]) / len(steps)
            tail = self._age - self._steps[-1][0]
            if tail > 2 * sum(steps) / len(steps):
                gaps.append(tail / eighths)
        return gaps

    def _evenness(self, closing: bool) -> float | None:
        """How even the stirring is, 0 to 1, or None before there is enough to tell."""
        gaps = self._gaps(closing)
        if len(gaps) < 3:
            return None
        mean = sum(gaps) / len(gaps)
        spread = (sum((g - mean) ** 2 for g in gaps) / len(gaps)) ** 0.5 / max(1e-6, mean)
        return max(0.0, 1.0 - spread / (MinigameSettings.STIR_SPREAD * self.ease))

    @property
    def quality(self) -> float:
        """How good the dish is, 0 to 1: how even the stir, times how much stirring there was."""
        evenness = self._evenness(closing=True)
        if evenness is None:
            return 0.0
        turns = sum(eighths for _, eighths in self._steps) / 8
        return evenness * min(1.0, turns / MinigameSettings.STIR_TURNS)

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the pad with its ring on the left, "Stir!" and how steady to its right, the bar along the bottom."""
        center = (window.left + 34, window.top + 38)
        self.render_pad(surface, center)
        size = FontSettings.SIZE_BODY
        middle = (center[0] + _RING + window.right) // 2
        text = "Stir!"
        text_renderer.draw_text(surface, text, (middle - text_renderer.text_width(text, size) // 2, window.top + 28),
                                color=_LETTER, size=size)
        evenness = self._evenness(closing=False)
        if evenness is not None:
            text, color = (("Steady", _STEADY) if evenness >= 0.7 else
                           ("Wobbly", _WOBBLY) if evenness >= 0.35 else ("Uneven", _UNEVEN))
            text_renderer.draw_text(surface, text, (middle - text_renderer.text_width(text, size) // 2,
                                                    window.top + 42), color=color, size=size)
        frame = pygame.Rect(0, 0, _BAR_WIDTH + 4, _BAR_HEIGHT + 4)
        frame.center = pygame.Rect(window.left, window.bottom - 22, window.width, 12).center
        well = draw_frame(surface, frame)
        draw_shaded(surface, well, well.left, round(_BAR_WIDTH * self.left / MinigameSettings.STIR_SECONDS))
