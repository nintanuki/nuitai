"""Soft edges: a sand tile pushes ragged grass in and wears a wet lip where the sea touches it.

The tile pack has flat squares, so a beach used to be a staircase. Here a
sand tile looks at its eight neighbors and draws, over the sand, the tile
numbered by which of them are grass and which are water, from the
sheets ``tools/make_edges.py`` draws in ``tiles/edges/``. No room file
names an edge. The game and the Workshop both draw through here.

    Ponds and rivers (Frankie, 10/30) work the same way with
``tools/make_fresh_edges.py``'s sheets: a grass tile gets water pushed into
it with a ragged rim, a wet lip and pale shallows, and a water tile gets
a few shallows pixels along the grass. Only grass makes them: where water
meets sand the sea's tide above is the only edge, so nothing doubles.
"""

from __future__ import annotations

import os

import pygame

from settings import AssetPaths, GridSettings, OverworldSettings
from ui.shore import NEIGHBORS, WATER

GRASS = (OverworldSettings.FLOOR_CHAR, OverworldSettings.WALL_CHAR, OverworldSettings.STUMP_CHAR)
SAND = OverworldSettings.SAND_CHAR

TIDE_SECONDS = 1.1                 # one step of the tide; a whole cycle is about six and a half seconds
TIDE_STEPS = (0, 1, 2, 3, 2, 1)    # which sea sheet, in turn: in, in, in, out, out, out
SEA_SHEETS = tuple(f"sea_onto_sand_{n}.png" for n in range(4))

RIPPLE_SECONDS = 0.9               # one step of a pond's ripple, a gentle swap of four sheets
FRESH_LAND = (OverworldSettings.FLOOR_CHAR,) + tuple(
    char for char, under in OverworldSettings.TILE_UNDER.items() if under == OverworldSettings.FLOOR_CHAR)

_SHEETS: dict[str, pygame.Surface] = {}
_PICTURES: dict[tuple[str, int], pygame.Surface | None] = {}


def _mask(grid, col: int, row: int, chars: tuple[str, ...]) -> int:
    """Which of the eight neighbors are one of ``chars``, one bit each."""
    mask = 0
    for bit, (dx, dy) in enumerate(NEIGHBORS):
        c, r = col + dx, row + dy
        if 0 <= r < len(grid) and 0 <= c < len(grid[r]) and grid[r][c] in chars:
            mask |= 1 << bit
    return mask


def _picture(sheet: str, mask: int) -> pygame.Surface | None:
    key = (sheet, mask)
    if key not in _PICTURES:
        if sheet not in _SHEETS:
            path = os.path.join(AssetPaths.TILES_DIR, "edges", sheet)
            _SHEETS[sheet] = pygame.image.load(path)
        size = GridSettings.TILE_SIZE
        picture = pygame.Surface((size, size), pygame.SRCALPHA)
        picture.blit(_SHEETS[sheet], (0, 0), pygame.Rect((mask % 16) * size, (mask // 16) * size, size, size))
        _PICTURES[key] = picture
    return _PICTURES[key]


def draw(surface: pygame.Surface, grid, col: int, row: int, at: tuple[int, int]) -> None:
    """Draw the edges over a sand tile already drawn at ``at``."""
    if grid[row][col] != SAND:
        return
    grass = _mask(grid, col, row, GRASS)
    if grass:
        surface.blit(_picture("grass_into_sand.png", grass), at)
    sea = _mask(grid, col, row, WATER)
    if sea:
        step = int(pygame.time.get_ticks() / 1000 / TIDE_SECONDS) % len(TIDE_STEPS)
        surface.blit(_picture(SEA_SHEETS[TIDE_STEPS[step]], sea), at)


def _ripple() -> int:
    return int(pygame.time.get_ticks() / 1000 / RIPPLE_SECONDS) % 4


def draw_bank(surface: pygame.Surface, grid, col: int, row: int, at: tuple[int, int]) -> None:
    """Draw the water's edge over a grass tile already drawn at ``at``."""
    if grid[row][col] not in FRESH_LAND:
        return
    water = _mask(grid, col, row, WATER)
    if water:
        rim = "ab"[(col * 5 + row * 3) % 2]
        surface.blit(_picture(f"water_into_grass_{rim}{_ripple()}.png", water), at)


def draw_shallows(surface: pygame.Surface, grid, col: int, row: int, at: tuple[int, int]) -> None:
    """Draw pale shallows over a water tile already drawn at ``at``, along its grass."""
    grass = _mask(grid, col, row, FRESH_LAND)
    if grass:
        surface.blit(_picture(f"shallows_{_ripple()}.png", grass), at)
