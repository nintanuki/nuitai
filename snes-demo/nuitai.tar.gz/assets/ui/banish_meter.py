"""Hina's Banish on screen: hold A to draw the bow, let go to shoot (Frankie, 10/31).

Two circles on the enemy picked. The outer one stays put; the inner one
starts shrinking the moment A goes down, and the smaller it is when A is
let go, the stronger the arrow. Hold too long and it shrinks away: the shot
fails, and she can draw again if the time is not up. In the window the
commands were in: the A button, "Hold A!" and the time draining, as
Paddle's are (``ui/paddle_meter.py``).

Maika's Vault uses the same circles with one try (Frankie, 11/1): held too
long, he misses. Tawiri's Moepapa is ``TapMeter`` below: the circle shrinks
by itself, fast, and one tap of A is all she gets (Frankie, 11/1). How fast
the circle shrinks comes from the stats (``ease``, Frankie, 11/1).
"""

from __future__ import annotations

import pygame

from settings import BattleSettings, FontSettings
from ui import text_renderer
from ui.paddle_meter import PaddleMeter

_OUTER = 20                    # The outer circle's radius, in pixels.
_OUTER_COLOR = (255, 255, 255)
_INNER_COLOR = (255, 222, 40)   # The yellow of the target arrow.
_SLIP_COLOR = (214, 40, 48)
_EDGE = (0, 0, 0)
_SLIP_SHOW = 0.5               # How long "Too long!" shows after a slip.


class BanishMeter:
    """The time, the draw and the shot, for one Banish."""

    def __init__(self, target_id: str, ease: float = 1.0, seconds: float | None = None,
                 draw_seconds: float | None = None, one_shot: bool = False) -> None:
        """Start the time for a Banish at ``target_id``; ``ease`` from the stats slows the circle.

        The rest are for Maika's Vault (Frankie, 11/1): its own times, and
        ``one_shot``, a draw held too long is the end of it.
        """
        self.target_id = target_id
        self.seconds = float(BattleSettings.BANISH_SECONDS if seconds is None else seconds)
        self.draw_seconds = (BattleSettings.BANISH_DRAW_SECONDS if draw_seconds is None else draw_seconds) * ease
        self.one_shot = one_shot
        self.failed = False
        self.left = self.seconds
        self.drawn = 0.0           # Seconds A has been held on this draw.
        self.holding = False
        self.share: float | None = None  # Set when the arrow flies: 0 weakest, 1 strongest.
        self.slips = 0
        self._slip = 0.0
        self._button = PaddleMeter(target_id)  # Only for its A button and time bar.

    @property
    def size(self) -> float:
        """The inner circle as a share of the outer: 1 at the start of a draw, 0 when gone."""
        return max(0.0, 1.0 - self.drawn / self.draw_seconds)

    @property
    def done(self) -> bool:
        """True once the arrow has flown or the time is up."""
        return self.share is not None or self.left <= 0 or self.failed

    def hold(self) -> None:
        """A goes down: the inner circle starts shrinking."""
        if not self.done and not self.holding:
            self.holding, self.drawn = True, 0.0

    def release(self) -> None:
        """A comes up: the arrow flies, the smaller the circle the stronger."""
        if self.holding and not self.done:
            self.holding = False
            self.share = 1.0 - self.size

    def update(self, dt: float) -> None:
        """Run the time and the draw by ``dt`` seconds; a draw held too long slips."""
        if self.done:
            return
        self.left = max(0.0, self.left - dt)
        self._slip = max(0.0, self._slip - dt)
        self._button.left = self.left * BattleSettings.PADDLE_SECONDS / self.seconds
        self._button.update(0.0 if self.holding else dt)
        self._button._pressed = 1.0 if self.holding else 0.0
        if self.holding:
            self.drawn += dt
            if self.size <= 0:
                # Held too long: the shot fails, and she may draw again (Frankie, 10/31).
                self.holding, self.drawn = False, 0.0
                self.slips += 1
                self._slip = _SLIP_SHOW
                if self.one_shot:
                    # Vault: held too long, he misses (Frankie, 11/1).
                    self.failed = True

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the A button, "Hold A!", "Aim..." or "Too long!" and the time, in the commands' window."""
        button_x = window.left + 34
        self._button.render_button(surface, (button_x, window.top + 38))
        text = "Too long!" if self._slip > 0 else ("Aim..." if self.holding else "Hold A!")
        color = _SLIP_COLOR if self._slip > 0 else (255, 255, 255)
        size = FontSettings.SIZE_BODY
        middle = (button_x + 14 + window.right) // 2
        text_renderer.draw_text(surface, text, (middle - text_renderer.text_width(text, size) // 2, window.top + 34),
                                color=color, size=size)
        self._button.render_bar(surface, pygame.Rect(window.left, window.bottom - 22, window.width, 12))

    def render_rings(self, surface: pygame.Surface, center: tuple[int, int]) -> None:
        """Draw the two circles on the enemy: the outer fixed, the inner shrinking while A is held."""
        pygame.draw.circle(surface, _EDGE, center, _OUTER + 1, 3)
        pygame.draw.circle(surface, _OUTER_COLOR, center, _OUTER, 1)
        inner = round(_OUTER * 0.8 * (self.size if self.holding else 1.0))
        color = _SLIP_COLOR if self._slip > 0 else _INNER_COLOR
        if inner >= 1:
            pygame.draw.circle(surface, _EDGE, center, inner + 1, 3)
            pygame.draw.circle(surface, color, center, inner, 1)
        pygame.draw.line(surface, color, (center[0] - 2, center[1]), (center[0] + 2, center[1]))
        pygame.draw.line(surface, color, (center[0], center[1] - 2), (center[0], center[1] + 2))


class TapMeter:
    """Tawiri's Moepapa (Frankie, 11/1): the circle shrinks by itself, fast; tap A once, the smaller the better.

    A short wait (MOEPAPA_READY), then the inner circle shrinks away in
    MOEPAPA_SHRINK times the ease. One tap, one shot: ``share`` is how small
    it was, and 0 if it was gone first or tapped too soon. The circles sit on
    the middle enemy; the curse reaches them all.
    """

    def __init__(self, target_id: str, ease: float = 1.0) -> None:
        """Start the wait; ``target_id`` is where the circles are drawn."""
        from settings import MinigameSettings
        self.target_id = target_id
        self.ready = float(MinigameSettings.MOEPAPA_READY)
        self.shrink_seconds = MinigameSettings.MOEPAPA_SHRINK * ease
        self.shrunk = 0.0
        self.share: float | None = None
        self._after = 0.0          # Time the result shows before it is done.

    @property
    def size(self) -> float:
        """The inner circle as a share of the outer: 1 at the start, 0 when gone."""
        return max(0.0, 1.0 - self.shrunk / self.shrink_seconds)

    @property
    def done(self) -> bool:
        """True once the tap is in (or the circle is gone) and the result has shown a moment."""
        return self.share is not None and self._after >= _SLIP_SHOW

    def tap(self) -> None:
        """A goes down: the one shot. Too soon or too late is a miss."""
        if self.share is None:
            self.share = 0.0 if self.ready > 0 else 1.0 - self.size

    def update(self, dt: float) -> None:
        """Run the wait, then the shrink; a circle that shrinks away is a miss."""
        if self.share is not None:
            self._after += dt
            return
        if self.ready > 0:
            self.ready = max(0.0, self.ready - dt)
            return
        self.shrunk += dt
        if self.size <= 0:
            self.share = 0.0

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw "Ready..." then "Tap A!", then how it went, in the commands' window."""
        if self.share is None:
            text, color = ("Ready..." if self.ready > 0 else "Tap A!"), (255, 255, 255)
        elif self.share <= 0:
            text, color = "Missed!", _SLIP_COLOR
        else:
            text, color = ("Nightmares!" if self.share >= 0.5 else "Bad dreams."), _INNER_COLOR
        size = FontSettings.SIZE_BODY
        text_renderer.draw_text(surface, text, (window.centerx - text_renderer.text_width(text, size) // 2,
                                                window.top + 34), color=color, size=size)

    def render_rings(self, surface: pygame.Surface, center: tuple[int, int]) -> None:
        """Draw the two circles, the inner shrinking on its own."""
        pygame.draw.circle(surface, _EDGE, center, _OUTER + 1, 3)
        pygame.draw.circle(surface, _OUTER_COLOR, center, _OUTER, 1)
        inner = round(_OUTER * 0.8 * self.size)
        color = _SLIP_COLOR if self.share == 0.0 else _INNER_COLOR
        if inner >= 1:
            pygame.draw.circle(surface, _EDGE, center, inner + 1, 3)
            pygame.draw.circle(surface, color, center, inner, 1)
