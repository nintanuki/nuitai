"""The pier: a pier tile picks its piece of the planks by which neighbors are pier too.

The harbor's pier (Frankie, 10/27) is painted as tiles like the sand, and
walked on like it. Its picture, ``tiles/pier.png`` (``tools/make_pier.py``),
is nine pieces: an edge has its black outline and, along the bottom, the
posts. The water shows through under the gaps, so a pier tile draws the
water first, with the shore it would have. The game and the Workshop both
draw piers through here, so they match.
"""

from __future__ import annotations

import os

import pygame

from settings import AssetPaths, GridSettings, OverworldSettings

CHAR = OverworldSettings.PIER_CHAR

_SHEET: pygame.Surface | None = None
_PICTURES: dict[tuple[int, int], pygame.Surface] = {}


def _pier(grid, col: int, row: int) -> bool:
    """Whether a tile is on the grid and pier."""
    return 0 <= row < len(grid) and 0 <= col < len(grid[row]) and grid[row][col] == CHAR


def piece(grid, col: int, row: int) -> tuple[int, int]:
    """Which piece a pier tile takes: (across, down), each 0 at the edge before, 2 at the edge after."""
    across = 0 if not _pier(grid, col - 1, row) else 2 if not _pier(grid, col + 1, row) else 1
    down = 0 if not _pier(grid, col, row - 1) else 2 if not _pier(grid, col, row + 1) else 1
    return across, down


def tile(grid, col: int, row: int) -> pygame.Surface:
    """The 16 pixel picture of a pier tile's planks, see-through where the water shows."""
    global _SHEET
    key = piece(grid, col, row)
    if key not in _PICTURES:
        size = GridSettings.TILE_SIZE
        if _SHEET is None:
            _SHEET = pygame.image.load(os.path.join(AssetPaths.TILES_DIR, "pier.png"))
        picture = pygame.Surface((size, size), pygame.SRCALPHA)
        picture.blit(_SHEET, (0, 0), pygame.Rect(key[0] * size, key[1] * size, size, size))
        _PICTURES[key] = picture
    return _PICTURES[key]
