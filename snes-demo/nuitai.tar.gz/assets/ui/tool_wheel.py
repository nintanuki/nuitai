"""The tool wheel on Y, and the set tool's icon flashed in the field's corner (Frankie, 10/28).

Holding Y opens a wheel of ``ToolSettings.WHEEL_SLOTS`` slots around Kailo,
up first then clockwise; the d-pad picks one, and letting go of Y sets it. A
quick tap of Y, let go before the wheel opens, uses the tool that is set.
Only tools Kailo owns show on the wheel; a slot with none stays an empty box,
so each tool keeps its place as more come. Four slots now, eight later, the
diagonals then counting too (``systems/tools.slot_at``).

Each slot is a small window with the tool's 7 by 7 picture from
``game/shared/item-icons.json``, drawn as it is, never scaled (SNES limits).
"""

from __future__ import annotations

import math

import pygame

from settings import ColorSettings, ToolSettings
from systems import tools
from ui.item_icon import kind_surface
from ui.window import draw_window

# A slot's window, and how far its middle sits from Kailo's.
_BOX = 16
_REACH = 22


def tool_picture(job: str, party) -> pygame.Surface | None:
    """The picture of the tool Kailo has for ``job``: its own icon, or None."""
    item = tools.best(party, job)
    return kind_surface(item) if item else None


class ToolWheel:
    """Y held or tapped: the wheel's state between the press and the let-go."""

    def __init__(self) -> None:
        # Seconds Y has been held, or None while it is up.
        self.held: float | None = None
        # The slot the d-pad last pointed at while the wheel is open.
        self.pick: int | None = None
        # Seconds left to show the set tool in the corner, after the wheel set it.
        self.flash = 0.0

    @property
    def open(self) -> bool:
        """Whether the wheel shows: Y held long enough."""
        return self.held is not None and self.held >= ToolSettings.WHEEL_HOLD_SECONDS

    def press(self, party) -> None:
        """Y went down: start timing, the cursor on the tool that is set."""
        self.held = 0.0
        slots = tools.wheel(party)
        job = tools.current(party)
        self.pick = slots.index(job) if job in slots else None

    def update(self, dt: float, direction: tuple[int, int], party) -> None:
        """Time the hold and the corner's flash; once open, the d-pad picks a slot with a tool in it."""
        self.flash = max(0.0, self.flash - dt)
        if self.held is None:
            return
        self.held += dt
        if not self.open:
            return
        slot = tools.slot_at(*direction)
        if slot is not None and tools.wheel(party)[slot]:
            self.pick = slot

    def release(self, party) -> str | None:
        """Y let go: "use" for a tap, "set" once the wheel was open (the pick set), else None."""
        if self.held is None:
            return None
        was_open, self.held = self.open, None
        if not was_open:
            return "use"
        if self.pick is not None:
            party.tool = tools.wheel(party)[self.pick]
            self.flash = ToolSettings.CORNER_SECONDS
        return "set"

    def cancel(self) -> None:
        """Close without setting anything: something else took the screen."""
        self.held = None

    def render(self, surface: pygame.Surface, middle: tuple[int, int], party) -> None:
        """The slots around ``middle`` (Kailo's), each tool in its own, the pick in yellow."""
        if not self.open:
            return
        slots = tools.wheel(party)
        for index, job in enumerate(slots):
            angle = 2 * math.pi * index / len(slots)
            x = middle[0] + round(_REACH * math.sin(angle)) - _BOX // 2
            y = middle[1] - round(_REACH * math.cos(angle)) - _BOX // 2
            rect = pygame.Rect(x, y, _BOX, _BOX)
            border = ColorSettings.YELLOW if index == self.pick else ColorSettings.WHITE
            draw_window(surface, rect, border=border)
            picture = tool_picture(job, party) if job else None
            if picture is not None:
                surface.blit(picture, (x + 4, y + 4))


def render_corner(surface: pygame.Surface, party, wheel: ToolWheel) -> None:
    """The set tool's picture in the field's top right corner, only for a moment after
    the wheel set it (Frankie, 10/28); nothing with no tool."""
    if wheel.flash <= 0:
        return
    job = tools.current(party)
    picture = tool_picture(job, party) if job else None
    if picture is None:
        return
    x = surface.get_width() - ToolSettings.CORNER_MARGIN - _BOX
    rect = pygame.Rect(x, ToolSettings.CORNER_MARGIN, _BOX, _BOX)
    draw_window(surface, rect)
    surface.blit(picture, (rect.left + 4, rect.top + 4))
