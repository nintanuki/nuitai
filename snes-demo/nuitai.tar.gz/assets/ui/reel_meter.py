"""Draw the reel meter while a fish is on the line (Frankie, 11/2; ``systems/fishing.py``).

A window at the bottom center (the top, when Kailo stands in the lower half) with REEL and the block meter's frame, filled in its
shaded yellow as far as the fish is reeled in, and a thin bar under it for the time
left. The first fish ever shows the hint above it. The layout is Claude's.
"""

from __future__ import annotations

import pygame

from settings import ColorSettings, FishingSettings, FontSettings, UISettings
from systems.fishing import Reel
from ui import text_renderer
from ui.block_meter import draw_frame, draw_shaded
from ui.window import draw_window

_LABEL = "Reel"
_METER_W = 112
_METER_H = 10
_GAP = 6  # between the label and the meter
_TIME_H = 2  # the time bar under the meter
_TIME_COLOR = (150, 200, 255)
_EDGE_GAP = 16  # from the window to the screen's edge


def render_reel(surface: pygame.Surface, reel: Reel, hint: bool, at_top: bool = False) -> None:
    """The meter, and the hint when ``hint`` is True; at the top when ``at_top``, out of Kailo's way."""
    size = FontSettings.SIZE_BODY
    pad = UISettings.TEXT_BOX_PADDING
    row = text_renderer.line_height(size)
    label_w = text_renderer.text_width(_LABEL, size)
    inner_w = label_w + _GAP + _METER_W
    if hint:
        inner_w = max(inner_w, text_renderer.text_width(FishingSettings.REEL_HINT, size))
    width = -(-(inner_w + 2 * pad) // 8) * 8
    height = 2 * pad + max(row, _METER_H) + _TIME_H + 2 + (row + 4 if hint else 0)
    rect = pygame.Rect((surface.get_width() - width) // 16 * 8,
                       _EDGE_GAP if at_top else surface.get_height() - _EDGE_GAP - height, width, height)
    draw_window(surface, rect)
    top = rect.top + pad
    if hint:
        x = rect.left + (rect.width - text_renderer.text_width(FishingSettings.REEL_HINT, size)) // 2
        text_renderer.draw_text(surface, FishingSettings.REEL_HINT, (x, top), size=size, color=ColorSettings.YELLOW)
        top += row + 4
    left = rect.left + (rect.width - (label_w + _GAP + _METER_W)) // 2
    text_renderer.draw_text(surface, _LABEL, (left, top + (_METER_H - row) // 2), size=size,
                            color=ColorSettings.WHITE)
    frame = pygame.Rect(left + label_w + _GAP, top, _METER_W, _METER_H)
    well = draw_frame(surface, frame)
    draw_shaded(surface, well, well.left, int(well.width * max(0.0, min(1.0, reel.fill))))
    time_w = int(frame.width * max(0.0, reel.left) / FishingSettings.REEL_SECONDS)
    if time_w > 0:
        pygame.draw.rect(surface, _TIME_COLOR, (frame.left, frame.bottom + 2, time_w, _TIME_H))
