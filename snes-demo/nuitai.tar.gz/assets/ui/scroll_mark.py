"""The arrows that say a list goes on past its edge (Frankie, 10/24, a rule).

A list with more below shows a flashing white arrow pointing down at its
bottom edge, and one with more above an arrow pointing up at its top, so
nothing hides off the end. ``Menu`` and ``GridMenu`` draw them by
themselves; a scene that draws its own list calls ``draw_list_marks``.
"""

from __future__ import annotations

import time

import pygame

from settings import ColorSettings, UISettings

# The arrow: 7 pixels wide, 4 tall.
_HALF = 3
_TALL = 4


def blink_on() -> bool:
    """Return True on the half of the blink when the arrows show."""
    return int(time.monotonic() * UISettings.SCROLL_MARK_BLINK_HZ * 2) % 2 == 0


def draw_scroll_mark(surface: pygame.Surface, x: int, y: int, up: bool) -> None:
    """Draw one arrow centered on (``x``, ``y``), pointing up or down, on the lit half of the blink."""
    if not blink_on():
        return
    tip, base = (y - _TALL // 2, y + _TALL // 2) if up else (y + _TALL // 2, y - _TALL // 2)
    pygame.draw.polygon(surface, ColorSettings.WHITE, [(x, tip), (x - _HALF, base), (x + _HALF, base)])


def draw_list_marks(
    surface: pygame.Surface, x: int, top_y: int, row_height: int,
    first: int, shown: int, total: int, hidden: int = 0,
) -> None:
    """Draw the arrows for a list showing ``shown`` of ``total`` rows from row ``first``.

    The up arrow sits on the first row shown, the down arrow on the last,
    both centered on ``x``, which is just past the rows' right end.

    Args:
        top_y: The top of the first shown row's letters.
        row_height: Pixels from one row to the next.
        hidden: Rows at the start that the list's owner draws itself;
            they do not count as more above.
    """
    middle = top_y + UISettings.SCROLL_MARK_ROW_MIDDLE
    if first > hidden:
        draw_scroll_mark(surface, x, middle, up=True)
    if first + shown < total:
        draw_scroll_mark(surface, x, middle + (shown - 1) * row_height, up=False)
