"""Kailo's Pound on screen: press a move's buttons before the time runs out (Frankie, 10/31).

In the bottom window's left half, where the commands were, as Paddle's meter
is: the move's name on top, the buttons still to press in a row under it, the
next one lifted, and the time bar along the bottom in the block meter's frame.
Each right press takes the first button off the row; a wrong one shakes the
row red and puts every button back, while the time keeps draining (Frankie,
10/31). When the row is empty or the time is up, the battle swings the move
(``Battle.submit_pound``).
"""

from __future__ import annotations

import math
from typing import Any

import pygame

from settings import BattleSettings, BlockSettings, FontSettings
from ui import text_renderer
from ui.block_meter import draw_frame, draw_shaded

_KEY = 14                 # A button's size, in pixels.
_GAP = 2                  # Between two buttons.
_LIFT = 2                 # How far the next button bobs up.
_SHAKE_SECONDS = 0.25     # How long a wrong press shakes the row.
_SHAKE = 3                # Pixels it shakes.
_BAR_WIDTH = 96
_BAR_HEIGHT = BlockSettings.HEIGHT
# The Super Famicom's colors: a grey pad with yellow arrows, red A, yellow B (Claude's picks).
_PAD_RIM = (40, 44, 56)
_PAD_FACE = (150, 156, 172)
_PAD_SHINE = (210, 214, 226)
_ARROW = (255, 222, 40)
_ARROW_EDGE = (40, 24, 0)
_FACES = {"A": ((90, 12, 20), (214, 40, 48)), "B": ((110, 80, 0), (240, 196, 24))}
_LETTER = (255, 255, 255)
_WRONG = (240, 64, 56)
_NAME = (255, 255, 255)
# Each arrow's tip and its two back corners, on a key 14 across.
_ARROWS = {
    "UP": ((7, 2), (2, 10), (12, 10)),
    "DOWN": ((7, 11), (2, 3), (12, 3)),
    "LEFT": ((2, 7), (10, 2), (10, 12)),
    "RIGHT": ((11, 7), (3, 2), (3, 12)),
}


class PoundMeter:
    """One Pound move's buttons, how far along they are, and the clock."""

    def __init__(self, move: dict[str, Any], target_id: str | None) -> None:
        """Start the clock for ``move`` at ``target_id`` (None for one that hits every enemy)."""
        self.move = move
        self.target_id = target_id
        self.buttons: list[str] = move["input"].split()
        self.pressed = 0
        self.left = float(BattleSettings.POUND_SECONDS)
        self._age = 0.0
        self._shake = 0.0

    @property
    def finished(self) -> bool:
        """True once every button was pressed in order."""
        return self.pressed >= len(self.buttons)

    @property
    def done(self) -> bool:
        """True once the move is finished or the time is up."""
        return self.finished or self.left <= 0

    @property
    def share(self) -> float:
        """How much of the move lands: all of it finished, else the share pressed so far."""
        return 1.0 if self.finished else self.pressed / len(self.buttons)

    def press(self, button: str) -> bool:
        """Take one press; True if it was the next button, False (and back to the start) if not."""
        if self.done:
            return False
        if button == self.buttons[self.pressed]:
            self.pressed += 1
            return True
        self.pressed = 0
        self._shake = _SHAKE_SECONDS
        return False

    def update(self, dt: float) -> None:
        """Run the clock down by ``dt`` seconds."""
        if not self.finished:
            self.left = max(0.0, self.left - dt)
        self._age += dt
        self._shake = max(0.0, self._shake - dt)

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the name on top, the buttons left in the middle, the bar along the bottom."""
        size = FontSettings.SIZE_BODY
        name = self.move["name"]
        text_renderer.draw_text(surface, name, (window.centerx - text_renderer.text_width(name, size) // 2,
                                                window.top + 12), color=_NAME, size=size)
        left = self.buttons[self.pressed:]
        row = len(left) * (_KEY + _GAP) - _GAP
        x = window.centerx - row // 2
        if self._shake:
            x += round(_SHAKE * math.sin(self._shake * 60))
        y = window.top + 30
        for i, button in enumerate(left):
            lift = round(_LIFT * abs(math.sin(self._age * 6))) if i == 0 and not self._shake else 0
            self._key(surface, button, x + i * (_KEY + _GAP), y - lift, wrong=self._shake > 0)
        frame = pygame.Rect(0, 0, _BAR_WIDTH + 4, _BAR_HEIGHT + 4)
        frame.center = (window.centerx, window.bottom - 16)
        well = draw_frame(surface, frame)
        draw_shaded(surface, well, well.left, round(_BAR_WIDTH * self.left / BattleSettings.POUND_SECONDS))

    @staticmethod
    def _key(surface: pygame.Surface, button: str, x: int, y: int, wrong: bool) -> None:
        """Draw one button with its top left at (``x``, ``y``): an arrow key or a round A or B."""
        if button in _FACES:
            rim, face = _FACES[button]
            if wrong:
                face = _WRONG
            center = (x + _KEY // 2, y + _KEY // 2)
            pygame.draw.circle(surface, rim, (center[0], center[1] + 1), _KEY // 2)
            pygame.draw.circle(surface, face, center, _KEY // 2 - 1)
            width = text_renderer.text_width(button, FontSettings.SIZE_BODY)
            text_renderer.draw_text(surface, button, (center[0] - width // 2 + 1, center[1] - 3),
                                    color=_LETTER, size=FontSettings.SIZE_BODY)
            return
        key = pygame.Rect(x, y, _KEY, _KEY)
        pygame.draw.rect(surface, _PAD_RIM, key.move(0, 1), border_radius=3)
        pygame.draw.rect(surface, _WRONG if wrong else _PAD_FACE, key, border_radius=3)
        pygame.draw.line(surface, _PAD_SHINE, (key.left + 3, key.top + 1), (key.right - 4, key.top + 1))
        points = [(x + px, y + py) for px, py in _ARROWS[button]]
        pygame.draw.polygon(surface, _ARROW, points)
        pygame.draw.polygon(surface, _ARROW_EDGE, points, 1)
