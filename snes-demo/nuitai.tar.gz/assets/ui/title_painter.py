"""Paints the title's dawn on a quiet beach, frame by frame (Frankie, 10/24).

The numbers are ``ui/title_dawn.py``'s and the pictures
``assets/graphics/title/``'s, which the cartridge reads too; this paints
them the way the Super Nintendo shows them, a layer at a time and a line at
a time: the backdrop's color a line, the spiral added over everything by
color math, the waves' bands each slid sideways, the reflection a span a
line added to the sea, the sun, the island, the specks, the boat and the
gulls as sprites, the logo's lines each
nudged a pixel, and only above the horizon.
"""

from __future__ import annotations

import os

import pygame

from settings import AssetPaths
from ui import title_dawn as dawn


def _load(name: str) -> pygame.Surface:
    return pygame.image.load(os.path.join(AssetPaths.TITLE_DIR, f"{name}.png"))


def _recolor(picture: pygame.Surface, colors) -> pygame.Surface:
    """A copy of an indexed picture with its colors 1 on set to ``colors`` (5 bit)."""
    copy = picture.copy()
    palette = list(copy.get_palette())
    for k, c in enumerate(colors):
        palette[k + 1] = dawn.to_rgb(c)
    copy.set_palette(palette)
    copy.set_colorkey(0)
    return copy


class DawnPainter:
    """Holds the title's pictures, and paints the dawn as it stands at a frame."""

    def __init__(self) -> None:
        self._backdrops: dict[int, pygame.Surface] = {}
        spiral = _load("spiral")
        # White on black, so adding it adds nothing where it is not.
        self._spiral = pygame.Surface(spiral.get_size())
        self._spiral.blit(spiral, (0, 0))
        sun = _load("sun")
        self._suns = [_recolor(sun, [dawn.mix(dawn.OCEAN_BLUE, c, step) for c in dawn.SUN_COLORS])
                      for step in range(17)]
        specks = _load("specks")
        specks.set_colorkey(0)
        self._specks = [specks.subsurface((look * 8, 0, 8, 8)) for look in range(3)]
        waves = _load("waves")
        self._waves = [_recolor(waves, [dawn.wave_color(group, i, step)
                                        for group in range(3) for i in (1, 2, 3)])
                       for step in range(17)]
        island = _load("island")
        self._islands = [_recolor(island, [dawn.island_color(i, step) for i in (1, 2, 3)])
                         for step in range(17)]
        self._boat = _load("boat")
        self._boat.set_colorkey(0)
        gulls = _load("gulls")
        gulls.set_colorkey(0)
        self._gulls = [gulls.subsurface((look * 8, 0, 8, 8)) for look in range(3)]
        self._logo = _load("logo")
        self._logo.set_colorkey(0)
        self._glow = dawn.to_rgb(dawn.GLOW)

    def _backdrop(self, step: int) -> pygame.Surface:
        if step not in self._backdrops:
            surf = pygame.Surface((dawn.WIDTH, dawn.HEIGHT))
            for y in range(dawn.HEIGHT):
                surf.fill(dawn.to_rgb(dawn.backdrop(y, step)), (0, y, dawn.WIDTH, 1))
            self._backdrops[step] = surf
        return self._backdrops[step]

    def paint(self, surface: pygame.Surface, frame: int, specks: dawn.Specks, wave_ticks: int) -> None:
        """The dawn ``frame`` frames in: everything but the menu."""
        surface.blit(self._backdrop(dawn.fade_step(frame)), (0, 0))
        sea = dawn.sea_step(frame)
        if sea:
            self._paint_sea(surface, frame, sea, wave_ticks)
        sun = self._suns[dawn.fade_step(frame)]
        surface.blit(sun, (dawn.CENTER_X - 24, dawn.HORIZON - 32))
        surface.blit(self._islands[dawn.fade_step(frame)], (dawn.ISLAND_LEFT, dawn.HORIZON - 32))
        for x, y, look in specks.shown():
            surface.blit(self._specks[look], (x - 3, y - 3))
        boat = dawn.boat_place(frame)
        if boat:
            surface.blit(self._boat, boat)
        for x, y, look in dawn.gulls(frame):
            surface.blit(self._gulls[look], (x, y))
        if frame < dawn.SEA_START:
            self._paint_spiral(surface, frame)
        else:
            self._paint_logo(surface, frame)

    def _paint_spiral(self, surface: pygame.Surface, frame: int) -> None:
        """Mode 7's turning, growing spiral, its brightness added to what is behind it."""
        gray = dawn.spiral_gray(frame)
        if not gray:
            return
        angle, scale = dawn.spiral_pose(frame)
        size = max(1, round(dawn.SPIRAL_SIZE * scale))
        picture = pygame.transform.scale(self._spiral, (size, size))
        picture = pygame.transform.rotate(picture, -angle)
        level = dawn.to_rgb((gray, gray, gray))
        picture.fill(level, special_flags=pygame.BLEND_MULT)
        rect = picture.get_rect(center=(dawn.CENTER_X, dawn.HORIZON))
        surface.blit(picture, rect, special_flags=pygame.BLEND_ADD)

    def _paint_sea(self, surface: pygame.Surface, frame: int, step: int, wave_ticks: int) -> None:
        """The waves band by band, then the reflection's glow added inside its window."""
        waves = self._waves[step]
        for (first, lines, speed) in dawn.WAVE_BANDS:
            shift = (wave_ticks * speed >> 8) & 255
            area = pygame.Rect(0, first - dawn.HORIZON, dawn.WIDTH, lines)
            surface.blit(waves, (-shift, first), area)
            surface.blit(waves, (dawn.WIDTH - shift, first), area)
        glow = tuple(round(c * step / 16) for c in self._glow)
        shape = dawn.reflection(dawn.reflection_shape(frame))
        for line, span in enumerate(shape, dawn.HORIZON):
            if span:
                surface.fill(glow, (span[0], line, span[1] - span[0] + 1, 1), special_flags=pygame.BLEND_ADD)

    def _paint_logo(self, surface: pygame.Surface, frame: int) -> None:
        """The logo, each line slid by the wobble, hidden from the horizon down."""
        logo = self._logo
        top = dawn.logo_top(frame, logo.get_height())
        left = (dawn.WIDTH - logo.get_width()) // 2
        phase = dawn.wobble_phase(frame)
        for row in range(logo.get_height()):
            y = top + row
            if y >= dawn.HORIZON:
                break
            surface.blit(logo, (left - dawn.wobble(y, phase), y), (0, row, logo.get_width(), 1))
