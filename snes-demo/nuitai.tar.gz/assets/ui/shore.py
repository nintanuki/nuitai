"""Coastline: a water tile draws its own shore on the sides that touch land.

The tile pack has one flat water square and one flat sand square, so a
beach used to be a staircase of squares. Here a water tile looks at its
eight neighbors, and every pixel is coloured by how far it is from the
nearest land: wet sand right at the edge, a line of foam, two bands of
shallows, then open water. Corners come out round because the distance
is measured as a straight line, the way a real shore curves.

The edge wobbles a little so it is not ruler-straight. The wobble
repeats every 16 pixels, so two tiles side by side meet without a seam,
and a tile's picture depends only on which neighbors are land. That is
at most 256 pictures, each made once and kept.

Off the edge of the room counts as water, so a sea running off screen
has no shore drawn along the screen's border.
"""

from __future__ import annotations

import math

import pygame

from settings import GridSettings, OverworldSettings

# Characters that are water for the shore: the sea and the healing pond.
WATER: tuple[str, ...] = (OverworldSettings.WATER_CHAR, OverworldSettings.SPRING_CHAR)
# What stands over water and has no shore against it: the water, and the pier.
OVER_WATER: tuple[str, ...] = WATER + (OverworldSettings.PIER_CHAR,)

# (distance from land in pixels, colour) from the shore out. A pixel
# takes the first band its distance is under; past the last it is open
# water. The colours are the tile pack's own: its sand, its three
# shallows (Ground/Shore.png), and the water the map already uses.
BANDS: tuple[tuple[float, tuple[int, int, int]], ...] = (
    (1.6, (220, 196, 126)),   # wet sand
    (2.7, (236, 242, 222)),   # foam
    (5.0, (119, 192, 180)),   # shallows
    (8.0, (78, 188, 185)),    # shelf
)
OPEN_WATER = (66, 172, 175)

# The eight neighbors as (dx, dy), in the bit order of the mask.
NEIGHBORS: tuple[tuple[int, int], ...] = (
    (-1, -1), (0, -1), (1, -1),
    (-1, 0), (1, 0),
    (-1, 1), (0, 1), (1, 1),
)

_PICTURES: dict[int, pygame.Surface] = {}


def land_mask(grid, col: int, row: int) -> int:
    """Which of the tile's eight neighbors are land, one bit each."""
    mask = 0
    for bit, (dx, dy) in enumerate(NEIGHBORS):
        c, r = col + dx, row + dy
        if 0 <= r < len(grid) and 0 <= c < len(grid[r]) and grid[r][c] not in OVER_WATER:
            mask |= 1 << bit
    return mask


def _wobble(x: float, y: float) -> float:
    """How far the shore bends at this pixel; repeats every 16 pixels."""
    turn = 2 * math.pi / GridSettings.TILE_SIZE
    return 0.6 * math.sin(turn * x) + 0.4 * math.sin(turn * 2 * y + 1.3)


def _distance_to_land(mask: int, x: float, y: float) -> float:
    """Straight-line pixels from (x, y) inside the tile to the nearest land neighbor."""
    size = GridSettings.TILE_SIZE
    best = math.inf
    for bit, (dx, dy) in enumerate(NEIGHBORS):
        if not mask & (1 << bit):
            continue
        # The neighbor is the square [dx*size, dx*size+size) by the same down.
        left, top = dx * size, dy * size
        gap_x = max(left - x, 0.0, x - (left + size))
        gap_y = max(top - y, 0.0, y - (top + size))
        best = min(best, math.hypot(gap_x, gap_y))
    return best


def picture(mask: int) -> pygame.Surface | None:
    """The water tile for this land mask; None when no neighbor is land."""
    if mask == 0:
        return None
    if mask in _PICTURES:
        return _PICTURES[mask]
    size = GridSettings.TILE_SIZE
    tile = pygame.Surface((size, size))
    for y in range(size):
        for x in range(size):
            px, py = x + 0.5, y + 0.5
            distance = _distance_to_land(mask, px, py) + _wobble(px, py)
            colour = OPEN_WATER
            for limit, band in BANDS:
                if distance < limit:
                    colour = band
                    break
            tile.set_at((x, y), colour)
    _PICTURES[mask] = tile
    return tile


def water_tile(grid, col: int, row: int) -> pygame.Surface | None:
    """The shore picture for the water tile at (col, row), or None for open water."""
    return picture(land_mask(grid, col, row))
