"""What counts as water for the shores, and the order of a tile's eight neighbors.

The shores themselves are drawn by ``ui/edges.py`` from sheets of overlay tiles
(``tools/make_edges.py`` for the beach, ``tools/make_fresh_edges.py`` for
ponds and rivers). A sheet's tile number is a mask of which neighbors count,
one bit each, in the order of ``NEIGHBORS``.
"""

from __future__ import annotations

from settings import OverworldSettings

# Characters that are water for the shore: the sea and the healing pond.
WATER: tuple[str, ...] = (OverworldSettings.WATER_CHAR, OverworldSettings.SPRING_CHAR)

# The eight neighbors as (dx, dy), in the bit order of the mask.
NEIGHBORS: tuple[tuple[int, int], ...] = (
    (-1, -1), (0, -1), (1, -1),
    (-1, 0), (1, 0),
    (-1, 1), (0, 1), (1, 1),
)
