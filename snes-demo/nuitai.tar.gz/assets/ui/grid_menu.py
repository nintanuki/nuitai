"""A menu laid out in rows and columns, Final Fantasy's spell menu (D-450).

Each row has a short label on the left (a mana cost) and up to a few
cells across it. The cursor moves in four directions over the cells
that exist; a greyed cell can be pointed at, to read it, but not picked.
A grid with more rows than fit shows a window of them that slides to
keep the cursor in view, like ``ui.menu.Menu``.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Callable, Optional

import pygame

from settings import ColorSettings, FontSettings, UISettings
from ui import text_renderer


@dataclass
class GridCell:
    """One pickable cell."""
    label: str
    on_select: Callable[[], None]
    enabled: bool = True
    color: tuple[int, int, int] | None = None
    glow: tuple[int, int, int] | None = None
    glow_radius: int = 1
    glow_alpha: int = 90
    # Anything the owner wants back when this cell is highlighted.
    data: object = None
    # An 8 by 8 picture in the gap before the label: a move's element tag (ui/element_tag.py).
    tag: object = None


@dataclass
class GridRow:
    """One row: its label, its label's colour, and its cells (None is an empty slot)."""
    label: str
    cells: list[GridCell | None]
    label_color: tuple[int, int, int] | None = None


class GridMenu:
    """Cursor-driven grid menu, controller and keyboard friendly."""

    def __init__(
        self, rows: list[GridRow], on_cancel: Optional[Callable[[], None]] = None
    ) -> None:
        """Build a grid over ``rows``. The cursor starts on the first enabled cell."""
        self.rows = rows
        self.on_cancel = on_cancel
        self.row, self.col = self._first_cell()
        self._first_shown = 0

    # ------------------------------------------------------------------
    # NAVIGATION
    # ------------------------------------------------------------------

    @property
    def current(self) -> GridCell | None:
        """Return the highlighted cell, or None in an empty grid."""
        if not self.rows:
            return None
        cells = self.rows[self.row].cells
        return cells[self.col] if 0 <= self.col < len(cells) else None

    def move_up(self) -> bool:
        return self._step_row(-1)

    def move_down(self) -> bool:
        return self._step_row(1)

    def move_left(self) -> bool:
        return self._step_col(-1)

    def move_right(self) -> bool:
        return self._step_col(1)

    def confirm(self) -> bool:
        cell = self.current
        if cell is not None and cell.enabled:
            cell.on_select()
            return True
        return False

    def cancel(self) -> bool:
        if self.on_cancel is not None:
            self.on_cancel()
            return True
        return False

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def render(
        self,
        surface: pygame.Surface,
        position: tuple[int, int],
        row_height: int,
        max_rows: int,
        label_width: int,
        col_width: int,
        font_size: int | None = None,
        hidden_rows: int = 0,
    ) -> None:
        """Draw the grid from ``position``, the top of the first row's letters.

        Args:
            row_height: Pixels from one row to the next.
            max_rows: Rows that fit; the window slides to the cursor.
            label_width: Pixels from a row's label to its first cell.
            col_width: Pixels from one cell to the next.
            hidden_rows: The first rows, which the owner draws itself.
        """
        size = FontSettings.SIZE_BODY if font_size is None else font_size
        x, y = position
        blink_on = int(time.monotonic() * UISettings.MENU_CURSOR_BLINK_HZ * 2) % 2 == 0
        first = self._slide_window(max_rows, hidden_rows)
        for offset, row in enumerate(self.rows[first:first + max_rows]):
            index = first + offset
            row_y = y + offset * row_height
            if row.label:
                text_renderer.draw_text(
                    surface, row.label, (x, row_y),
                    row.label_color or ColorSettings.WHITE, size=size,
                )
            for col, cell in enumerate(row.cells):
                cell_x = x + label_width + col * col_width
                if cell is None:
                    text_renderer.draw_text(
                        surface, "-", (cell_x, row_y), ColorSettings.DARK_GRAY, size=size,
                    )
                    continue
                if not cell.enabled:
                    color, glow = ColorSettings.GRAY, None
                else:
                    color = cell.color or ColorSettings.WHITE
                    glow = cell.glow
                if cell.tag is not None:
                    surface.blit(cell.tag, (cell_x - cell.tag.get_width(), row_y))
                if index == self.row and col == self.col and blink_on:
                    text_renderer.draw_pointer(
                        surface,
                        (cell_x - UISettings.MENU_LABEL_OFFSET, row_y + size // 2),
                        ColorSettings.YELLOW,
                    )
                text_renderer.draw_text(
                    surface, cell.label, (cell_x, row_y), color, size=size,
                    glow=glow, glow_radius=cell.glow_radius, glow_alpha=cell.glow_alpha,
                )

    # ------------------------------------------------------------------
    # INTERNALS
    # ------------------------------------------------------------------

    def _cells(self, row: int) -> list[int]:
        """Return the columns of ``row`` that hold a cell."""
        return [c for c, cell in enumerate(self.rows[row].cells) if cell is not None]

    def _first_cell(self) -> tuple[int, int]:
        """Return the first enabled cell, else the first cell, else (0, 0)."""
        fallback = None
        for r, row in enumerate(self.rows):
            for c, cell in enumerate(row.cells):
                if cell is None:
                    continue
                if cell.enabled:
                    return r, c
                fallback = fallback or (r, c)
        return fallback or (0, 0)

    def _step_row(self, direction: int) -> bool:
        """Move to the nearest row with a cell, to the column closest to this one."""
        r = self.row + direction
        while 0 <= r < len(self.rows):
            cols = self._cells(r)
            if cols:
                self.row = r
                self.col = min(cols, key=lambda c: abs(c - self.col))
                return True
            r += direction
        return False

    def _step_col(self, direction: int) -> bool:
        """Move to the next cell along this row."""
        cols = [c for c in self._cells(self.row) if (c - self.col) * direction > 0]
        if not cols:
            return False
        self.col = min(cols, key=lambda c: abs(c - self.col))
        return True

    def _slide_window(self, max_rows: int, hidden: int = 0) -> int:
        """Return the first row to draw, moved so the cursor is inside the window.

        The first ``hidden`` rows are drawn by the owner somewhere else; on
        one of them, the window rests at the top of the rest.
        """
        row = max(self.row, hidden)
        if row < self._first_shown:
            self._first_shown = row
        elif row >= self._first_shown + max_rows:
            self._first_shown = row - max_rows + 1
        self._first_shown = max(hidden, min(self._first_shown, len(self.rows) - max_rows))
        return self._first_shown


def short_move_name(move: dict) -> str:
    """Return a move's name as the grid shows it: 7 letters at most (D-450, Frankie 10/23)."""
    name = move["name"]
    short = UISettings.MOVE_SHORT_NAMES.get(name, name)
    return short[:UISettings.ABILITY_NAME_CHARS]

