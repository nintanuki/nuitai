"""Kailo's Paddle on screen: mash A while the time runs out (Frankie, 10/31).

All in the bottom window's left half, where the commands were (Frankie,
10/31): a large Super Nintendo A button, an arrow bobbing above it, the
button pushing in and out to say "mash" and pushed in by every real press,
"Mash A!" beside it, and under them a bar that drains left to right in PADDLE_SECONDS. The presses are not shown; when the bar is empty the
battle swings them all, rapidfire (``Battle.submit_paddle``).

Hina's Scold is the same mash (Frankie, 11/1), with its own time and
"Scold!", which turns to "That told it!" once the presses for the full sulk
are in (``needed``, set by the ease, Willpower against the monster's).
"""

from __future__ import annotations

import math

import pygame

from settings import BattleSettings, BlockSettings, FontSettings
from ui import text_renderer
from ui.block_meter import draw_frame, draw_shaded

_RADIUS = 14              # The button, 28 pixels across.
_PUSH = 2                 # How far it sinks when pressed.
_BLINK = 0.12             # Seconds up, then down, as the "mash" hint.
_PRESS_SHOW = 0.06        # How long a real press keeps it down.
_ARROW_BOB = 2            # Pixels the arrow bobs.
# The time bar, in the block meter's frame and shaded yellow (Frankie, 10/31).
_BAR_WIDTH = 96
_BAR_HEIGHT = BlockSettings.HEIGHT
# The button in the Super Famicom's red A (Claude's pick).
_RIM = (90, 12, 20)
_FACE = (214, 40, 48)
_FACE_DOWN = (176, 28, 36)
_SHINE = (255, 140, 140)
_LETTER = (255, 255, 255)
_ARROW = (255, 222, 40)
_ARROW_EDGE = (40, 24, 0)


class PaddleMeter:
    """The clock and the presses counted, for one Paddle."""

    def __init__(self, target_id: str, seconds: float | None = None, most: int | None = None,
                 label: str = "Mash A!", needed: int | None = None, done_label: str = "") -> None:
        """Start the clock for a Paddle at ``target_id``; the rest are for Scold's mash (Frankie, 11/1)."""
        self.target_id = target_id
        self.seconds = float(BattleSettings.PADDLE_SECONDS if seconds is None else seconds)
        self.most = BattleSettings.PADDLE_MOST if most is None else most
        self.label = label
        self.needed = needed
        self.done_label = done_label
        self.left = self.seconds
        self.presses = 0
        self._age = 0.0
        self._pressed = 0.0  # Time left showing a real press.

    @property
    def done(self) -> bool:
        """True once the time is up."""
        return self.left <= 0

    def press(self) -> bool:
        """Count one press of A; False once the time is up or the most is reached."""
        if self.done or self.presses >= self.most:
            return False
        self.presses += 1
        self._pressed = _PRESS_SHOW
        return True

    def update(self, dt: float) -> None:
        """Run the clock down by ``dt`` seconds."""
        self.left = max(0.0, self.left - dt)
        self._age += dt
        self._pressed = max(0.0, self._pressed - dt)

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the button with its arrow on the left, "Mash A!" to its right, the bar along the bottom."""
        button_x = window.left + 34
        self.render_button(surface, (button_x, window.top + 38))
        text = self.label
        if self.needed is not None and self.presses >= self.needed and self.done_label:
            text = self.done_label
        size = FontSettings.SIZE_BODY
        middle = (button_x + _RADIUS + window.right) // 2
        text_renderer.draw_text(surface, text, (middle - text_renderer.text_width(text, size) // 2, window.top + 34),
                                color=_LETTER, size=size)
        self.render_bar(surface, pygame.Rect(window.left, window.bottom - 22, window.width, 12))

    def render_button(self, surface: pygame.Surface, center: tuple[int, int]) -> None:
        """Draw the A button at ``center`` with the arrow above it."""
        down = self._pressed > 0 or int(self._age / _BLINK) % 2 == 1
        cx, cy = center
        # The rim stays put; the face sinks into it when pressed.
        pygame.draw.circle(surface, _RIM, (cx, cy + _PUSH), _RADIUS + 1)
        face_y = cy + (_PUSH if down else 0)
        pygame.draw.circle(surface, _FACE_DOWN if down else _FACE, (cx, face_y), _RADIUS)
        if not down:
            pygame.draw.arc(surface, _SHINE, pygame.Rect(cx - _RADIUS + 4, face_y - _RADIUS + 4,
                                                         2 * _RADIUS - 8, 2 * _RADIUS - 8), 1.9, 2.9, 2)
        letter = pygame.Surface((8, 8), pygame.SRCALPHA)
        text_renderer.draw_text(letter, "A", (0, 0), color=_LETTER, size=FontSettings.SIZE_BODY)
        letter = pygame.transform.scale_by(letter, 2)
        surface.blit(letter, letter.get_rect(center=(cx + 1, face_y + 1)))
        # The arrow, pointing down at it, bobbing.
        tip = cy - _RADIUS - 4 + round(_ARROW_BOB * math.sin(self._age * 9))
        points = [(cx - 7, tip - 7), (cx + 7, tip - 7), (cx, tip)]
        pygame.draw.rect(surface, _ARROW_EDGE, pygame.Rect(cx - 3, tip - 14, 6, 8))
        pygame.draw.rect(surface, _ARROW, pygame.Rect(cx - 2, tip - 13, 4, 7))
        pygame.draw.polygon(surface, _ARROW, points)
        pygame.draw.polygon(surface, _ARROW_EDGE, points, 1)

    def render_bar(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the time left as a draining bar centered in ``window``, in the block meter's frame."""
        frame = pygame.Rect(0, 0, _BAR_WIDTH + 4, _BAR_HEIGHT + 4)
        frame.center = window.center
        well = draw_frame(surface, frame)
        draw_shaded(surface, well, well.left, round(_BAR_WIDTH * self.left / self.seconds))
