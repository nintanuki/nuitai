"""Tawiri's Call on screen: alternate A and B in a steady rhythm of her own (Frankie, 11/1).

In the window the commands were in: an A and a B button side by side, each
lighting as it is pressed, "Alternate!" over them, and the time draining
along the bottom. Nothing on screen keeps the beat: the player sets the pace,
and the tighter (steadier) the rhythm kept, the stronger the spirit
(Frankie, 11/1). Fast or slow does not matter, only even. The same button
twice is a missed beat, and so is stopping; a missed beat only weakens the
spirit, it never fails the Call. Under "Alternate!" a word says how it is
going: Steady, Wobbly or Uneven. ``quality`` is 0 to 1
(``Battle.submit_call``).

How uneven the rhythm may be comes from Tawiri's Intelligence against the
monsters' (Frankie, 11/1): the ``ease`` widens or narrows it.
"""

from __future__ import annotations

import pygame

from settings import FontSettings, MinigameSettings
from ui import text_renderer
from ui.block_meter import draw_frame, draw_shaded
from ui.spin_meter import _BAR_HEIGHT, _BAR_WIDTH

_RADIUS = 12
_FACES = {"A": ((90, 12, 20), (176, 28, 36), (255, 90, 90)), "B": ((110, 80, 0), (196, 156, 16), (255, 236, 90))}
_LETTER = (255, 255, 255)
_STEADY = (96, 220, 96)
_WOBBLY = (255, 222, 40)
_UNEVEN = (240, 64, 56)
_LIT = 0.1                # How long a press keeps its button lit.


class RhythmMeter:
    """The presses timed and the clock, for one Call."""

    def __init__(self, ease: float = 1.0) -> None:
        """Start the clock; ``ease`` from the stats forgives a less even rhythm."""
        self.ease = ease
        self.seconds = MinigameSettings.CALL_SECONDS
        self.left = float(self.seconds)
        self.now = 0.0
        self.presses: list[float] = []   # When each press in turn came.
        self.missed = 0                  # The same button twice.
        self._last: str | None = None
        self._lit: tuple[str, float] | None = None

    @property
    def done(self) -> bool:
        """True once the time is up."""
        return self.left <= 0

    def press(self, button: str) -> bool:
        """Take a press of A or B; True if it was the other one from the last, False for the same twice."""
        if self.done:
            return False
        self._lit = (button, _LIT)
        if button == self._last:
            self.missed += 1
            return False
        self._last = button
        self.presses.append(self.now)
        return True

    def update(self, dt: float) -> None:
        """Run the clock down by ``dt`` seconds."""
        self.left = max(0.0, self.left - dt)
        self.now += dt
        if self._lit is not None:
            button, left = self._lit
            self._lit = (button, left - dt) if left > dt else None

    def _evenness(self, closing: bool) -> float | None:
        """How even the gaps between presses are, 0 to 1, or None before there is enough to tell.

        ``closing`` counts a stop before the time ran out as one more gap that long.
        """
        gaps = [b - a for a, b in zip(self.presses, self.presses[1:])]
        if len(gaps) < 3:
            return None
        mean = sum(gaps) / len(gaps)
        if closing:
            tail = self.now - self.presses[-1]
            if tail > 2 * mean:
                gaps.append(tail)
                mean = sum(gaps) / len(gaps)
        spread = (sum((g - mean) ** 2 for g in gaps) / len(gaps)) ** 0.5 / max(1e-6, mean)
        return max(0.0, 1.0 - spread / (MinigameSettings.CALL_SPREAD * self.ease))

    @property
    def quality(self) -> float:
        """How tight the rhythm was, 0 to 1: how even, times how much of it, less for every missed beat."""
        evenness = self._evenness(closing=True)
        if evenness is None:
            return 0.0
        count = len(self.presses)
        return evenness * min(1.0, count / MinigameSettings.CALL_PRESSES) * count / (count + self.missed)

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw "Alternate!" and how steady on top, A and B under it, the time along the bottom."""
        size = FontSettings.SIZE_BODY
        text = "Alternate!"
        text_renderer.draw_text(surface, text, (window.centerx - text_renderer.text_width(text, size) // 2,
                                                window.top + 8), color=_LETTER, size=size)
        evenness = self._evenness(closing=False)
        if evenness is not None:
            text, color = (("Steady", _STEADY) if evenness >= 0.7 else
                           ("Wobbly", _WOBBLY) if evenness >= 0.35 else ("Uneven", _UNEVEN))
            text_renderer.draw_text(surface, text, (window.centerx - text_renderer.text_width(text, size) // 2,
                                                    window.top + 20), color=color, size=size)
        for i, button in enumerate("AB"):
            x = window.centerx + (-1 if button == "A" else 1) * (_RADIUS + 6)
            y = window.top + 46
            rim, face, lit = _FACES[button]
            down = self._lit is not None and self._lit[0] == button
            pygame.draw.circle(surface, rim, (x, y + 2), _RADIUS + 1)
            pygame.draw.circle(surface, lit if down else face, (x, y + (2 if down else 0)), _RADIUS)
            width = text_renderer.text_width(button, size)
            text_renderer.draw_text(surface, button, (x - width // 2 + 1, y - 3 + (2 if down else 0)),
                                    color=_LETTER, size=size)
        frame = pygame.Rect(0, 0, _BAR_WIDTH + 4, _BAR_HEIGHT + 4)
        frame.center = pygame.Rect(window.left, window.bottom - 22, window.width, 12).center
        well = draw_frame(surface, frame)
        draw_shaded(surface, well, well.left, round(_BAR_WIDTH * self.left / self.seconds))
