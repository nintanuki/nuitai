"""The battle stage: the fighters you can see, and how they move.

The battle rules (``systems/battle.py``) decide what happens and say so
as events. This module is one of the things that listens. It draws each
monster as a picture on a battlefield, lists the party in the HUD's
right panel, and turns events into motion:

* someone acts            -> they lunge forward (a party row hops)
* someone takes damage    -> they shake and flash, and a number floats up
* someone is healed       -> a green number floats up
* a monster is defeated   -> it fades out
* HP changes              -> the bar slides to its new length

All of the motion is done by moving one still picture a little each
frame (a "tween"). No animation frames are needed, so any still image
dropped into ``assets/graphics/monsters/`` works at once.

Monsters are drawn alone, facing the player, in the style of Dragon
Quest. The party is a list of names, bars and HP in the window below,
in the style of Final Fantasy (D-445); there are no portraits in a
fight. Nothing here stops party sprites being added later: they would
be one more kind of actor that reacts to the same events.

The stage owns no rules and changes nothing in the battle. Deleting it
would leave a fight that still plays out correctly in text.
"""

from __future__ import annotations

import math
import os
from dataclasses import dataclass, field
from typing import Any

import pygame

from core.events import (
    AbilityUsedEvent,
    AttackEvent,
    ComboUsedEvent,
    CombatantDefeatedEvent,
    DamageEvent,
    DodgeEvent,
    HealEvent,
    ManaEvent,
    MissEvent,
    PotionUsedEvent,
    RevivedEvent,
    StatusAppliedEvent,
    StrokeEvent,
    SwapEvent,
    WardBlockedEvent,
)
from core.shared import short_name
from settings import (
    AssetPaths,
    BattleSettings,
    BattleStageSettings as Stage,
    ColorSettings,
    FontSettings,
    ScreenSettings,
    UISettings,
)
from systems.battle import Combatant
from ui import text_renderer
from utils.graphics import (
    load_monster_sprite, load_turn_face,
)

# Short labels for the status line under a monster's name.
_GUARD_LABELS: dict[str, str] = {
    "sentinel": "Guard", "counter": "Counter", "cooker": "Cooker",
    "bell": "Bell", "oil": "Hot Oil", "steam": "Steam", "boil": "Boil Over",
    "cast_iron": "Cast Iron", "oven_mitt": "Oven Mitt",
}

# The short tags for the kits' statuses (10/21); any other status shows by its id.
_STATUS_LABELS: dict[str, str] = {
    "burn": "Burn", "weak": "Weak", "mbreak": "Mind Break", "calm": "Still",
    "mleech": "Leeched", "seed": "Seeded", "sprout": "Seed", "bloom": "Bloom",
    "perennial": "Perennial", "haunt": "Haunted", "grip": "Gripped", "sap": "Sap",
    "doom": "Doom", "up_magic": "Magic Up", "up_hp": "HP Up",
}


_SMALL_ICONS: dict[tuple[str, int], pygame.Surface | None] = {}


def _small_element_icon(element_id: str, size: int) -> pygame.Surface | None:
    """Return the hand-made ``size`` square element icon, or None without one.

    The icon is icons/<element>_<size>.png, drawn at that size (10/19); a
    bigger icon is never shrunk to stand in for it (D-577).
    """
    key = (element_id, size)
    if key not in _SMALL_ICONS:
        drawn = os.path.join(AssetPaths.ICONS_DIR, f"{element_id}_{size}.png")
        _SMALL_ICONS[key] = (
            pygame.image.load(drawn).convert_alpha() if os.path.exists(drawn) else None
        )
    return _SMALL_ICONS[key]


def status_labels(combatant: Combatant) -> list[str]:
    """Return short labels for everything currently on ``combatant``."""
    if not combatant.alive:
        return []
    labels: list[str] = []
    if combatant.guard is not None:
        labels.append(_GUARD_LABELS.get(combatant.guard, "Guard"))
    if combatant.defending:
        labels.append("Defend")
    if combatant.ward:
        labels.append("Ward")
    if combatant.haste > 0:
        labels.append(f"Haste {combatant.haste}")
    if combatant.safe:
        labels.append("Safeguard")
    if combatant.regen > 0:
        labels.append(f"Regen {combatant.regen}")
    for status, value in combatant.statuses.items():
        label = _STATUS_LABELS.get(status, status)
        labels.append(f"{label} {value}" if status == "doom" else label)
    if combatant.spirit:
        labels.append(f"Spirit {combatant.spirit['left']}")
    return labels


@dataclass
class _Floater:
    """A number or word drifting up from a fighter."""

    text: str
    color: tuple[int, int, int]
    x: float
    y: float
    age: float = 0.0


@dataclass
class _Actor:
    """The on-screen state of one fighter. Times count down to zero."""

    combatant: Combatant
    # Where the fighter stands: bottom-centre for a monster, the start
    # of the row for a party member.
    home: tuple[int, int]
    sprite: pygame.Surface | None = None
    flash_sprite: pygame.Surface | None = None
    poison_sprite: pygame.Surface | None = None
    shake: float = 0.0
    flash: float = 0.0
    lunge: float = 0.0
    # Seconds since a monster was defeated, or None while it stands.
    fallen_for: float | None = None
    # HP as the bar shows it, sliding toward the real figure.
    bar_hp: float = 0.0
    # Mana as the pips show it, set by each ManaEvent as it is played.
    mana: int = 0
    bob_phase: float = 0.0
    floaters: list[_Floater] = field(default_factory=list)


class BattleStage:
    """Draws both sides of a fight and animates them from battle events."""

    def __init__(
        self,
        party: list[Combatant],
        enemies: list[Combatant],
        sprite_ids: dict[str, str | None],
        floating: set[str] = frozenset(),
        bench: list[Combatant] | None = None,
    ) -> None:
        """Place every fighter.

        Args:
            party: The party's combatants, in menu order.
            enemies: The monsters, left to right.
            sprite_ids: Monster combatant id -> picture name in
                ``assets/graphics/monsters/`` (without ".png"), or None
                for a monster with no picture, which gets a plain box.
            floating: Monster ids that bob in the air, ghosts and flyers
                (``floats`` in the shared file). The rest stand still.
            bench: Party members who can be swapped in. Each gets a row
                the moment they take someone's place.
        """
        self._floating = set(floating)
        self._sprite_ids = dict(sprite_ids)
        # Combatant id -> its small turn-order picture.
        self._turn_icons: dict[str, pygame.Surface] = {}
        self._clock = 0.0
        self._actors: dict[str, _Actor] = {}
        self._party = party
        self._enemies = enemies
        # The monsters stand side by side in the middle of the field,
        # MONSTER_GAP apart, not spread to its edges (Frankie, 10/18). A pack
        # too wide for that falls back to an even share of the field each.
        sprites = [load_monster_sprite(sprite_ids.get(c.id)) for c in enemies]
        widths = [
            (pic[0].get_bounding_rect().width if pic else Stage.PLACEHOLDER_SIZE)
            for pic in sprites
        ]
        field = ScreenSettings.WIDTH - Stage.FIELD_LEFT
        total = sum(widths) + Stage.MONSTER_GAP * (len(enemies) - 1)
        centres = []
        if total <= field:
            x = Stage.FIELD_LEFT + (field - total) / 2
            for w in widths:
                centres.append(round(x + w / 2))
                x += w + Stage.MONSTER_GAP
        else:
            column = field / len(enemies)
            centres = [round(Stage.FIELD_LEFT + column * (i + 0.5)) for i in range(len(enemies))]
        for index, c in enumerate(enemies):
            actor = _Actor(
                combatant=c,
                home=(centres[index], Stage.GROUND_Y),
                bar_hp=float(c.hp),
                mana=c.mana,
                bob_phase=index * Stage.BOB_PHASE_STEP,
            )
            loaded = sprites[index]
            if loaded is not None:
                actor.sprite, actor.flash_sprite = loaded
            self._actors[c.id] = actor
        for index, c in enumerate(list(party) + list(bench or [])):
            self._actors[c.id] = _Actor(
                combatant=c,
                home=(
                    Stage.PARTY_ROW_X,
                    Stage.PARTY_ROW_TOP_Y + index * Stage.PARTY_ROW_PITCH,
                ),
                bar_hp=float(c.hp),
                mana=c.mana,
            )

    # ------------------------------------------------------------------
    # EVENTS IN
    # ------------------------------------------------------------------

    def consume(self, event: Any) -> None:
        """Start whatever motion ``event`` calls for."""
        if isinstance(event, (AttackEvent, StrokeEvent)):
            self._lunge(event.attacker_id)
        elif isinstance(event, ManaEvent):
            actor = self._actors.get(event.combatant_id)
            if actor is not None:
                actor.mana = event.total
        elif isinstance(event, DodgeEvent):
            actor = self._actors.get(event.target_id)
            if actor is not None:
                self._float(actor, "Dodge", ColorSettings.GRAY)
        elif isinstance(event, (AbilityUsedEvent, PotionUsedEvent)):
            self._lunge(event.user_id)
        elif isinstance(event, ComboUsedEvent):
            self._lunge(event.user_id)
            self._lunge(event.partner_id)
        elif isinstance(event, SwapEvent):
            # The one coming in takes the row of the one stepping back.
            leaving = self._actors[event.out_id]
            coming = self._actors[event.in_id]
            coming.home, leaving.home = leaving.home, coming.home
            coming.lunge = Stage.LUNGE_SECONDS
        elif isinstance(event, DamageEvent):
            actor = self._actors.get(event.target_id)
            if actor is None:
                return
            actor.shake = Stage.SHAKE_SECONDS
            actor.flash = Stage.FLASH_SECONDS
            if actor.combatant.is_party:
                color = Stage.COLOR_PARTY_DAMAGE
            elif event.guarded or event.multiplier == 1.0:
                color = ColorSettings.WHITE
            elif event.multiplier > 1.0:
                color = ColorSettings.YELLOW
            else:
                color = ColorSettings.GRAY
            self._float(actor, str(event.amount), color)
        elif isinstance(event, HealEvent):
            actor = self._actors.get(event.target_id)
            if actor is not None:
                self._float(actor, f"+{event.amount}", Stage.COLOR_HEAL)
        elif isinstance(event, RevivedEvent):
            actor = self._actors.get(event.target_id)
            if actor is not None:
                actor.fallen_for = None
                self._float(actor, f"+{event.hp}", Stage.COLOR_HEAL)
        elif isinstance(event, MissEvent):
            actor = self._actors.get(event.target_id)
            if actor is not None:
                self._float(actor, "Miss", ColorSettings.GRAY)
        elif isinstance(event, WardBlockedEvent):
            actor = self._actors.get(event.target_id)
            if actor is not None:
                self._float(actor, "Block", Stage.COLOR_STATUS)
        elif isinstance(event, StatusAppliedEvent):
            actor = self._actors.get(event.target_id)
            if actor is not None and event.applied:
                self._float(actor, event.status, Stage.COLOR_STATUS)
        elif isinstance(event, CombatantDefeatedEvent):
            actor = self._actors.get(event.combatant_id)
            if actor is not None and not actor.combatant.is_party:
                actor.fallen_for = 0.0

    def _lunge(self, combatant_id: str) -> None:
        """Send a fighter forward and back."""
        actor = self._actors.get(combatant_id)
        if actor is not None:
            actor.lunge = Stage.LUNGE_SECONDS

    def _float(
        self, actor: _Actor, text: str, color: tuple[int, int, int]
    ) -> None:
        """Start a number or word rising from ``actor``.

        A second floater started while the first is still low is nudged
        upward so the two do not print on top of each other.
        """
        x, y = self._float_origin(actor)
        y -= Stage.FLOAT_STACK_STEP * sum(
            1 for f in actor.floaters if f.age < Stage.FLOAT_STACK_WINDOW
        )
        actor.floaters.append(_Floater(text, color, x, y))

    def _float_origin(self, actor: _Actor) -> tuple[float, float]:
        """Return where a floater over ``actor`` starts."""
        if actor.combatant.is_party:
            return (
                actor.home[0] + Stage.PARTY_BAR_DX / 2,
                actor.home[1] - Stage.FLOAT_PARTY_RISE_START,
            )
        height = (
            actor.sprite.get_height()
            if actor.sprite is not None
            else Stage.PLACEHOLDER_SIZE
        )
        return (actor.home[0], actor.home[1] - height * Stage.FLOAT_SPRITE_HEIGHT)

    # ------------------------------------------------------------------
    # TIME
    # ------------------------------------------------------------------

    def update(self, dt: float, shown_hp: dict[str, int]) -> None:
        """Advance every motion by ``dt`` seconds.

        Args:
            dt: Seconds since the last frame.
            shown_hp: The HP the scene is currently narrating for each
                combatant id. Bars slide toward these.
        """
        self._clock += dt
        for combatant_id, actor in self._actors.items():
            actor.shake = max(0.0, actor.shake - dt)
            actor.flash = max(0.0, actor.flash - dt)
            actor.lunge = max(0.0, actor.lunge - dt)
            if actor.fallen_for is not None:
                actor.fallen_for += dt
            target = float(
                max(0, min(shown_hp[combatant_id], actor.combatant.max_hp))
            )
            step = actor.combatant.max_hp * Stage.BAR_SPEED * dt
            if actor.bar_hp < target:
                actor.bar_hp = min(target, actor.bar_hp + step)
            else:
                actor.bar_hp = max(target, actor.bar_hp - step)
            for floater in actor.floaters:
                floater.age += dt
            actor.floaters = [
                f for f in actor.floaters if f.age < Stage.FLOAT_SECONDS
            ]

    # ------------------------------------------------------------------
    # DRAWING
    # ------------------------------------------------------------------

    def render_enemies(
        self,
        surface: pygame.Surface,
        shown_hp: dict[str, int],
        active_id: str | None,
        target: Combatant | None,
        cursor_visible: bool,
    ) -> None:
        """Draw the monsters: pictures only, a name while aimed at (D-458).

        Args:
            surface: Where to draw.
            shown_hp: HP per combatant id as currently narrated.
            active_id: Whose turn it is, drawn in yellow.
            target: The fighter the player is aiming at, if any.
            cursor_visible: Whether the blinking cursor is on this frame.
        """
        for c in self._enemies:
            self._render_enemy(
                surface, self._actors[c.id], shown_hp[c.id], active_id,
                c is target and cursor_visible,
            )

    def render_party(
        self,
        surface: pygame.Surface,
        shown_hp: dict[str, int],
        active_id: str | None,
        target: Combatant | None,
        cursor_visible: bool,
    ) -> None:
        """Draw the party's rows in the HUD. The scene draws the window first."""
        for c in self._party:
            self._render_party_row(
                surface, self._actors[c.id], shown_hp[c.id], active_id,
                c is target and cursor_visible,
            )

    def render_turn_order(
        self, surface: pygame.Surface, order: list[Combatant]
    ) -> None:
        """Draw the turn order as one bordered bar of small pictures (D-453).

        ``order`` starts with the one acting now, who gets the yellow
        arrow. Each entry has a stripe on its left, blue for the party
        and red for monsters. As many as fit above the bottom window.
        """
        size = Stage.TURN_ICON_SIZE
        stripe = Stage.TURN_STRIPE
        pitch = size + 1
        bottom = ScreenSettings.HEIGHT - UISettings.TEXT_BOX_HEIGHT - 2
        count = min(len(order), (bottom - Stage.TURN_BAR_Y - 2) // pitch)
        if count <= 0:
            return
        frame = pygame.Rect(
            Stage.TURN_BAR_X, Stage.TURN_BAR_Y,
            stripe + size + 3, count * pitch + 1,
        )
        pygame.draw.rect(surface, UISettings.WINDOW_BOTTOM, frame.inflate(-2, -2))
        x = frame.left + 1
        for index, c in enumerate(order[:count]):
            y = frame.top + 1 + index * pitch
            pygame.draw.rect(
                surface,
                Stage.COLOR_TURN_PARTY if c.is_party else Stage.COLOR_TURN_FOE,
                pygame.Rect(x, y, stripe, size),
            )
            surface.blit(self._turn_icon(c), (x + stripe + 1, y))
            if index:
                pygame.draw.line(
                    surface, ColorSettings.GRAY,
                    (x, y - 1), (frame.right - 2, y - 1),
                )
        # The border leaves out its four corner pixels (D-457).
        l, t, r, b = frame.left, frame.top, frame.right - 1, frame.bottom - 1
        for start, end in (((l + 1, t), (r - 1, t)), ((l + 1, b), (r - 1, b)),
                           ((l, t + 1), (l, b - 1)), ((r, t + 1), (r, b - 1))):
            pygame.draw.line(surface, ColorSettings.WHITE, start, end)
        # The arrow points left at the one acting, over their picture's right side.
        tip_x = frame.right - Stage.TURN_ARROW - 3
        tip_y = frame.top + 1 + size // 2
        arrow = [
            (tip_x, tip_y),
            (tip_x + Stage.TURN_ARROW + 1, tip_y - Stage.TURN_ARROW - 1),
            (tip_x + Stage.TURN_ARROW + 1, tip_y + Stage.TURN_ARROW + 1),
        ]
        pygame.draw.polygon(surface, ColorSettings.BLACK, arrow)
        pygame.draw.polygon(surface, ColorSettings.YELLOW, [
            (tip_x + 1, tip_y),
            (tip_x + Stage.TURN_ARROW + 1, tip_y - Stage.TURN_ARROW + 1),
            (tip_x + Stage.TURN_ARROW + 1, tip_y + Stage.TURN_ARROW - 1),
        ])

    def _turn_icon(self, c: Combatant) -> pygame.Surface:
        """Return ``c``'s turn-order picture: a hand-drawn 16 by 16 face, or a marker.

        The marker stands in until a face is drawn: the element icon on a
        dark tile edged in the element's colour, a monster's one element
        or a party member's first. Nothing is shrunk to fit (D-577, D-585).
        """
        cached = self._turn_icons.get(c.id)
        if cached is not None:
            return cached
        size = Stage.TURN_ICON_SIZE
        if c.is_party:
            face = load_turn_face(c.id)
        else:
            # Frankie's angry face, every monster's marker (10/19).
            path = os.path.join(AssetPaths.ICONS_DIR, "monster_turn.png")
            face = pygame.image.load(path).convert_alpha() if os.path.exists(path) else None
        if face is not None and face.get_size() == (size, size):
            self._turn_icons[c.id] = face
            return face
        element = c.elements[0].value if c.elements else ""
        color = ColorSettings.ELEMENT_COLORS.get(element, Stage.COLOR_TURN_FOE)
        icon = pygame.Surface((size, size), pygame.SRCALPHA)
        pygame.draw.rect(icon, Stage.COLOR_TURN_MARKER, icon.get_rect(), border_radius=3)
        pygame.draw.rect(icon, color, icon.get_rect(), width=1, border_radius=3)
        mark = _small_element_icon(element, 8)
        if mark is not None:
            icon.blit(mark, ((size - 8) // 2, (size - 8) // 2))
        self._turn_icons[c.id] = icon
        return icon

    def render_floaters(self, surface: pygame.Surface) -> None:
        """Draw the rising numbers and words, over everything else."""
        for actor in self._actors.values():
            for floater in actor.floaters:
                self._render_floater(surface, floater)

    def _text(
        self,
        surface: pygame.Surface,
        text: str,
        pos: tuple[int, int],
        color: tuple[int, int, int],
        size: int,
    ) -> None:
        """Draw text so the top of its letters sits at ``pos``."""
        text_renderer.draw_text(surface, text, pos, color=color, size=size)

    def _text_width(self, text: str, size: int) -> int:
        """Return the drawn width of ``text`` at ``size``."""
        return text_renderer.text_width(text, size)

    def _name_color(
        self, combatant: Combatant, hp: int, active_id: str | None
    ) -> tuple[int, int, int]:
        """Gray when down, yellow on their turn, white otherwise."""
        if hp <= 0:
            return ColorSettings.GRAY
        if combatant.id == active_id:
            return ColorSettings.YELLOW
        return ColorSettings.WHITE

    def _shake_offset(self, actor: _Actor) -> int:
        """Return the sideways jolt for a fighter who was just hit."""
        if actor.shake <= 0:
            return 0
        fade = actor.shake / Stage.SHAKE_SECONDS
        return round(
            math.sin(actor.shake * Stage.SHAKE_SPEED) * Stage.SHAKE_PIXELS * fade
        )

    def _lunge_amount(self, actor: _Actor) -> float:
        """Return 0..1..0 over the course of a lunge."""
        if actor.lunge <= 0:
            return 0.0
        return math.sin(math.pi * (1 - actor.lunge / Stage.LUNGE_SECONDS))

    def _flashing(self, actor: _Actor) -> bool:
        """Return True on the lit frames of a hit fighter's flash."""
        return (
            actor.flash > 0
            and int(actor.flash * Stage.FLASH_BLINK_HZ * 2) % 2 == 0
        )

    def _render_bar(
        self,
        surface: pygame.Surface,
        pos: tuple[int, int],
        actor: _Actor,
    ) -> None:
        """Draw an HP bar. It turns red when HP is low."""
        x, y = pos
        frame = pygame.Rect(x, y, Stage.BAR_WIDTH, Stage.BAR_HEIGHT)
        pygame.draw.rect(surface, Stage.COLOR_BAR_BACK, frame)
        share = actor.bar_hp / max(1, actor.combatant.max_hp)
        if share > 0:
            color = (
                Stage.COLOR_BAR_LOW
                if share < Stage.BAR_LOW_SHARE
                else Stage.COLOR_BAR
            )
            inner = frame.inflate(-2, -2)
            inner.width = max(1, round(inner.width * share))
            pygame.draw.rect(surface, color, inner)
        pygame.draw.rect(surface, ColorSettings.WHITE, frame, 1)

    @staticmethod
    def render_pip_row(
        surface: pygame.Surface,
        pos: tuple[int, int],
        lit: int,
        color: tuple[int, int, int],
        count: int = BattleSettings.MANA_CAP,
    ) -> None:
        """Draw ``count`` small pips from ``pos``, the first ``lit`` in ``color``."""
        x, y = pos
        for index in range(count):
            pygame.draw.rect(
                surface,
                color if index < lit else Stage.COLOR_PIP_OFF,
                (x + index * (Stage.PIP_WIDTH + Stage.PIP_GAP), y,
                 Stage.PIP_WIDTH, Stage.PIP_HEIGHT),
            )

    def _render_pips(
        self, surface: pygame.Surface, pos: tuple[int, int], mana: int
    ) -> None:
        """Draw a fighter's mana: seven pips, one lit per point."""
        self.render_pip_row(surface, pos, mana, Stage.COLOR_MANA)

    def _render_cursor(
        self, surface: pygame.Surface, tip: tuple[int, int], down: bool
    ) -> None:
        """Draw the yellow target arrow with its point at ``tip``."""
        x, y = tip
        s = Stage.CURSOR_SIZE
        points = (
            [(x, y), (x - s, y - s), (x + s, y - s)]
            if down
            else [(x, y), (x - s, y - s), (x - s, y + s)]
        )
        pygame.draw.polygon(surface, ColorSettings.YELLOW, points)
        pygame.draw.polygon(surface, ColorSettings.BLACK, points, 1)

    def _render_enemy(
        self,
        surface: pygame.Surface,
        actor: _Actor,
        hp: int,
        active_id: str | None,
        targeted: bool,
    ) -> None:
        """Draw one monster."""
        cx, ground = actor.home
        gone = (
            actor.fallen_for is not None
            and actor.fallen_for >= Stage.FADE_SECONDS
        )
        height = (
            actor.sprite.get_height()
            if actor.sprite is not None
            else Stage.PLACEHOLDER_SIZE
        )
        if not gone:
            self._render_enemy_body(surface, actor)
        if targeted:
            self._render_cursor(
                surface, (cx, ground - height - Stage.CURSOR_GAP), down=True
            )

        # A monster is only its picture (D-458): no name (the window shows it
        # while it is aimed at) and no status words. A few statuses show on
        # the picture instead (D-487): poison tints it green, sleep floats
        # Zs over it, blind puts sunglasses on it.
        if not gone and actor.fallen_for is None:
            self._render_status_signs(surface, actor)

    def _render_enemy_body(
        self, surface: pygame.Surface, actor: _Actor
    ) -> None:
        """Draw a monster's shadow and picture, with any motion applied."""
        cx, ground = actor.home
        if actor.sprite is None:
            size = Stage.PLACEHOLDER_SIZE
            image = pygame.Surface((size, size), pygame.SRCALPHA)
            image.fill(Stage.COLOR_PLACEHOLDER)
            pygame.draw.rect(image, ColorSettings.WHITE, image.get_rect(), 1)
            flash_image = image
        else:
            image, flash_image = actor.sprite, actor.flash_sprite
        width, height = image.get_size()

        alpha = 255
        sink = 0
        if actor.fallen_for is not None:
            done = min(1.0, actor.fallen_for / Stage.FADE_SECONDS)
            alpha = round(255 * (1 - done))
            sink = round(Stage.FADE_SINK_PIXELS * done)

        # Shadow first, so the monster stands on something.
        shadow_w = max(8, round(width * Stage.SHADOW_WIDTH_SHARE))
        shadow = pygame.Surface((shadow_w, Stage.SHADOW_HEIGHT), pygame.SRCALPHA)
        pygame.draw.ellipse(
            shadow,
            (0, 0, 0, round(Stage.SHADOW_ALPHA * alpha / 255)),
            shadow.get_rect(),
        )
        surface.blit(
            shadow, (cx - shadow_w // 2, ground - Stage.SHADOW_HEIGHT // 2)
        )

        standing = actor.fallen_for is None and actor.combatant.id in self._floating
        bob = (
            round(
                math.sin(self._clock * Stage.BOB_SPEED + actor.bob_phase)
                * Stage.BOB_PIXELS
            )
            if standing
            else 0
        )
        x = cx - width // 2 + self._shake_offset(actor)
        # Stand on the feet, not on the picture's edge: the empty rows under
        # a monster (seven under the boar) made it float (Frankie, 10/18).
        feet = image.get_bounding_rect().bottom or height
        y = (
            ground - feet + Stage.FEET_SINK + bob + sink
            + round(self._lunge_amount(actor) * Stage.LUNGE_PIXELS)
        )
        picture = (
            flash_image if self._flashing(actor) and flash_image is not None
            else image
        )
        if picture is image and "poison" in actor.combatant.statuses:
            picture = self._poisoned(actor, image)
        if alpha < 255:
            picture = picture.copy()
            picture.set_alpha(alpha)
        surface.blit(picture, (x, y))

    def _poisoned(self, actor: _Actor, image: pygame.Surface) -> pygame.Surface:
        """Return ``image`` tinted green, made once per monster."""
        if actor.poison_sprite is None:
            tinted = image.copy()
            tinted.fill(Stage.POISON_MULTIPLY, special_flags=pygame.BLEND_RGB_MULT)
            tinted.fill(Stage.POISON_ADD, special_flags=pygame.BLEND_RGB_ADD)
            actor.poison_sprite = tinted
        return actor.poison_sprite

    def _visible_box(self, actor: _Actor) -> pygame.Rect:
        """Return the monster's drawn picture, empty edges cut, on the screen."""
        cx, ground = actor.home
        image = actor.sprite
        if image is None:
            size = Stage.PLACEHOLDER_SIZE
            return pygame.Rect(cx - size // 2, ground - size, size, size)
        box = image.get_bounding_rect()
        feet = box.bottom or image.get_height()
        left = cx - image.get_width() // 2
        top = ground - feet + Stage.FEET_SINK
        return box.move(left, top)

    def _render_status_signs(self, surface: pygame.Surface, actor: _Actor) -> None:
        """Draw sleep's Zs and blind's sunglasses on a monster (D-487)."""
        statuses = actor.combatant.statuses
        if "sleep" not in statuses and "blind" not in statuses:
            return
        box = self._visible_box(actor)
        if "sleep" in statuses:
            # Three Zs, small to large, drifting up and to the side in turn,
            # outlined dark so they read against a bright sky.
            for i, size in enumerate((FontSettings.SIZE_SMALL, FontSettings.SIZE_SMALL, FontSettings.SIZE_BODY)):
                phase = (self._clock * Stage.SLEEP_Z_SPEED + i / 3) % 1.0
                x = box.right - 6 + i * 7 + round(phase * 2)
                y = box.top - 4 - i * 8 - round(phase * Stage.SLEEP_Z_RISE)
                text_renderer.draw_text(
                    surface, "Z", (x, y), color=Stage.COLOR_SLEEP_Z, size=size,
                    glow=Stage.COLOR_SLEEP_Z_EDGE, glow_radius=1, glow_alpha=255,
                )
        if "blind" in statuses:
            spot = Stage.EYES.get(self._sprite_ids.get(actor.combatant.id))
            if spot is not None and actor.sprite is not None:
                w, h = actor.sprite.get_size()
                ex = box.left - actor.sprite.get_bounding_rect().left + round(spot[0] * w)
                ey = box.top - actor.sprite.get_bounding_rect().top + round(spot[1] * h)
            else:
                # No eye spot marked for this monster yet: over its head.
                ex, ey = box.centerx, box.top - 6
            self._render_sunglasses(surface, ex, ey)

    def _render_sunglasses(self, surface: pygame.Surface, cx: int, cy: int) -> None:
        """Draw a tiny pair of sunglasses centred on ``(cx, cy)``."""
        black, glint = (12, 12, 16), (235, 235, 245)
        left = cx - 5
        pygame.draw.rect(surface, black, (left, cy - 1, 4, 3))       # left lens
        pygame.draw.rect(surface, black, (left + 6, cy - 1, 4, 3))   # right lens
        pygame.draw.line(surface, black, (left + 4, cy - 1), (left + 5, cy - 1))  # bridge
        pygame.draw.line(surface, black, (left - 2, cy - 1), (left, cy - 1))      # arm
        surface.set_at((left + 1, cy - 1), glint)
        surface.set_at((left + 7, cy - 1), glint)

    def _render_party_row(
        self,
        surface: pygame.Surface,
        actor: _Actor,
        hp: int,
        active_id: str | None,
        targeted: bool,
    ) -> None:
        """Draw one party member's row: first name, HP bar, HP.

        The name is yellow on their turn, red while they are being hit,
        the status colour while something is on them, gray when down.
        """
        c = actor.combatant
        hp = max(0, min(hp, c.max_hp))
        x = actor.home[0] + self._shake_offset(actor)
        y = actor.home[1] - round(
            self._lunge_amount(actor) * Stage.PARTY_HOP_PIXELS
        )
        if hp > 0 and self._flashing(actor):
            color = Stage.COLOR_HURT_NAME
        elif hp > 0 and c.id != active_id and status_labels(c):
            color = Stage.COLOR_STATUS
        else:
            color = self._name_color(c, hp, active_id)
        self._render_party_icons(surface, c, x, y)
        self._text(
            surface, short_name(c.id)[:Stage.PARTY_NAME_CHARS],
            (x + Stage.PARTY_NAME_DX, y), color, FontSettings.SIZE_BODY,
        )
        # The bar is centred on the row's letters.
        bar_y = y + (FontSettings.LETTER_WIDTH - Stage.BAR_HEIGHT) // 2
        self._render_bar(surface, (x + Stage.PARTY_BAR_DX, bar_y), actor)
        if hp > 0:
            self._render_pips(
                surface, (x + Stage.PARTY_BAR_DX, y + Stage.PARTY_PIPS_DY), actor.mana
            )
        self._text(
            surface, str(round(actor.bar_hp)), (x + Stage.PARTY_FIGURES_DX, y),
            ColorSettings.GRAY if hp <= 0 else ColorSettings.WHITE,
            FontSettings.SIZE_SMALL,
        )
        if targeted:
            self._render_cursor(
                surface,
                (x - Stage.CURSOR_GAP, y + FontSettings.LETTER_WIDTH // 2),
                down=False,
            )

    def _render_party_icons(
        self, surface: pygame.Surface, c: Combatant, x: int, y: int
    ) -> None:
        """Draw a member's two element icons, the stance's boxed in yellow (D-453)."""
        size = Stage.PARTY_ICON_SIZE
        for index, element in enumerate(c.elements):
            icon = _small_element_icon(element.value, size)
            left = x + index * Stage.PARTY_ICON_PITCH
            if icon is not None:
                surface.blit(icon, (left + 1, y))
            if element is c.stance_element:
                pygame.draw.rect(
                    surface, ColorSettings.YELLOW,
                    pygame.Rect(left, y - 1, size + 2, size + 2), 1,
                )

    def _render_floater(
        self, surface: pygame.Surface, floater: _Floater
    ) -> None:
        """Draw one rising number with a dark edge so it reads anywhere."""
        progress = floater.age / Stage.FLOAT_SECONDS
        # Ease out: quick at first, slowing as it rises.
        rise = Stage.FLOAT_RISE_PIXELS * (1 - (1 - progress) ** 2)
        body = text_renderer.render_line(
            floater.text, floater.color, FontSettings.SIZE_BODY
        )
        edge = text_renderer.render_line(
            floater.text, ColorSettings.BLACK, FontSettings.SIZE_BODY
        )
        fade_from = 1 - Stage.FLOAT_FADE_SHARE
        alpha = (
            255 if progress < fade_from
            else round(255 * (1 - (progress - fade_from) / Stage.FLOAT_FADE_SHARE))
        )
        x = round(floater.x - body.get_width() / 2)
        y = round(floater.y - rise) - text_renderer.ink_top(FontSettings.SIZE_BODY)
        edge.set_alpha(alpha)
        body.set_alpha(alpha)
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            surface.blit(edge, (x + dx, y + dy))
        surface.blit(body, (x, y))
