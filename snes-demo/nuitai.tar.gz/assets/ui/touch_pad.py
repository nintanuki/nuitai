"""The SNES Demo's on-screen pad, for phones (Frankie, 10/24).

On a touch screen the website's page draws a Super Nintendo pad under or
beside the game (``tools/web_page.tmpl``) and answers
``window.nuitai_pad_read()`` with what is held, one bit per button,
numbered as ``InputSettings`` numbers the pad, by position: B (south) 0,
A (east) 1, Y (west) 2, X (north) 3, L 4, R 5, SELECT 6, START 7, and the D-pad's up, down, left and right 8 to 11.
``TouchPad`` reads it once a frame (a tap shorter than a frame counts as
held for one) and answers like one more connected pad, so each button
means what it means on a controller: the reset chord and a held D-pad
included.
"""

from __future__ import annotations

import sys
from typing import Callable

import pygame

# The id its events carry, one no real pad has.
INSTANCE_ID = -100

_BUTTON_COUNT = 8
_UP, _DOWN, _LEFT, _RIGHT = (1 << 8, 1 << 9, 1 << 10, 1 << 11)


class TouchPad:
    """The page's pad, polled through ``read`` (the held bits)."""

    def __init__(self, read: Callable[[], int]) -> None:
        self._read = read
        self._held = 0

    def get_numhats(self) -> int:
        return 1

    def get_hat(self, _index: int) -> tuple[int, int]:
        return _hat_of(self._held)

    def get_axis(self, _axis: int) -> float:
        return 0.0

    def get_button(self, button: int) -> bool:
        return 0 <= button < _BUTTON_COUNT and bool(self._held >> button & 1)

    def poll(self) -> list[pygame.event.Event]:
        """Read the page and return the presses and releases since the last frame."""
        before, self._held = self._held, self._read()
        events = []
        for button in range(_BUTTON_COUNT):
            was, now = before >> button & 1, self._held >> button & 1
            if was != now:
                kind = pygame.JOYBUTTONDOWN if now else pygame.JOYBUTTONUP
                events.append(pygame.event.Event(kind, button=button, instance_id=INSTANCE_ID))
        if _hat_of(before) != _hat_of(self._held):
            events.append(pygame.event.Event(
                pygame.JOYHATMOTION, hat=0, value=_hat_of(self._held), instance_id=INSTANCE_ID
            ))
        return events


def _hat_of(held: int) -> tuple[int, int]:
    """Return the D-pad bits as a hat value, up positive."""
    return (
        int(bool(held & _RIGHT)) - int(bool(held & _LEFT)),
        int(bool(held & _UP)) - int(bool(held & _DOWN)),
    )


def on_touch_screen() -> bool:
    """True in the browser build on a phone or tablet, as the page judges it."""
    if sys.platform != "emscripten":
        return False
    import platform

    try:
        return bool(platform.window.nuitai_touch)
    except Exception:  # An older page that does not say.
        return False


def from_page() -> TouchPad | None:
    """Return the page's pad in the browser build, None on the desktop."""
    if sys.platform != "emscripten":
        return None
    import platform  # pygbag's, which reaches the page as ``platform.window``.

    window = getattr(platform, "window", None)
    if window is None:
        return None

    def read() -> int:
        try:
            return int(window.nuitai_pad_read() or 0)
        except Exception:  # The page has no pad yet, or never will.
            return 0

    return TouchPad(read)
