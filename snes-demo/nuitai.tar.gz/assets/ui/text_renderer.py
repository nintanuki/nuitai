"""Centralised text rendering.

One place in the codebase loads fonts, wraps text, and puts names in
capitals. Text is mixed case, and in menus a name (a character's, or
anyone who speaks in the game's words) is drawn in capitals, as Final
Fantasy VI did (Frankie, 10/27): gameplay code writes "Kailo", the menu
shows KAILO. In dialogue and story text names stay as written, "Kailo",
since capitals there read as shouting (Frankie, 10/27): text drawn in the
dialogue font, and anything drawn with ``spoken=True`` (a speaker's name
over a text box, Kaigara's lines). Dialogue is drawn at ``FontSettings.SIZE_DIALOGUE``, which is its
own font, proportional, on rows ``DIALOGUE_LINE_HEIGHT`` apart, with
``DIALOGUE_LETTER_GAP`` pixels after every letter, as the Super Nintendo's
variable-width fonts built a gap into each letter, so no two letters touch.

Text is placed by the top of its capital letters, not by the font's
own box: Pixeled carries blank space above its letters, and on a 256 by
224 screen that space would throw every layout off. ``draw_text`` takes
that space off, so a position is where the letters start, and rows are
``FontSettings.LINE_HEIGHT`` apart.

The cache keys on (font path, point size) so callers can ask for the
same logical font-size repeatedly without paying the load cost.
"""

from __future__ import annotations

import functools
import glob
import json
import os
import re
import time
import unicodedata

import pygame

from settings import ColorSettings, FontSettings, UISettings


_FONT_CACHE: dict[tuple[str, int], pygame.font.Font] = {}
_INK_TOP_CACHE: dict[int, int] = {}


def get_font(size: int = FontSettings.SIZE_BODY) -> pygame.font.Font:
    """Return a cached pygame font at ``size`` points.

    Args:
        size: Point size; should come from ``FontSettings.SIZE_*``.
            ``SIZE_DIALOGUE`` is the dialogue font at its own size.

    Returns:
        The cached ``pygame.font.Font`` for that size.
    """
    if size == FontSettings.SIZE_DIALOGUE:
        key = (FontSettings.DIALOGUE_FONT, FontSettings.DIALOGUE_POINTS)
    else:
        key = (FontSettings.FONT, size)
    cached = _FONT_CACHE.get(key)
    if cached is None:
        cached = pygame.font.Font(*key)
        _FONT_CACHE[key] = cached
    return cached


def _spaced(font: pygame.font.Font) -> bool:
    """Whether ``font`` is the dialogue font, drawn with a gap after every letter."""
    return font is _FONT_CACHE.get((FontSettings.DIALOGUE_FONT, FontSettings.DIALOGUE_POINTS))


# Letters a font lacks are built from ones it has (Frankie, 10/27: Galmuri has no
# macrons, neither font the ʻokina): the ʻokina drawn as an opening quote, an
# accented letter as its plain letter with each mark laid over it, the mark
# taken from the font's own spacing accent ("ā" is "a" under "¯").
_STAND_INS = {"ʻ": ("‘", "'")}
_MARKS = {"̄": "¯", "́": "´", "̀": "`", "̂": "^",
          "̃": "~", "̈": "¨", "̛": "'"}
_HORN = "̛"        # Vietnamese ư, ơ: a hook at the letter's top right, not above it.
_HAS_CACHE: dict[tuple[int, str], bool] = {}


def has_glyph(font: pygame.font.Font, letter: str) -> bool:
    """Whether ``font`` draws ``letter`` itself, rather than its box for a missing letter."""
    key = (id(font), letter)
    cached = _HAS_CACHE.get(key)
    if cached is None:
        def look(text: str) -> tuple:
            drawn = font.render(text, False, ColorSettings.WHITE)
            surf = pygame.Surface(drawn.get_size(), pygame.SRCALPHA)
            surf.blit(drawn, (0, 0))
            return surf.get_size(), pygame.image.tobytes(surf, "RGBA")
        cached = letter.isspace() or look(letter) != look("\U0010fffd")
        _HAS_CACHE[key] = cached
    return cached


def _built(font: pygame.font.Font, letter: str) -> tuple[str, list[str]] | None:
    """How a letter the font lacks is built: the letter it has, and the spacing marks over it.

    None if it cannot be built, so the font's missing box shows.
    """
    for stand_in in _STAND_INS.get(letter, ()):
        if has_glyph(font, stand_in):
            return stand_in, []
    parts = unicodedata.normalize("NFD", letter)
    # The longest start the font has whole: ố is ô under an acute.
    for cut in range(len(parts) - 1, 0, -1):
        base = unicodedata.normalize("NFC", parts[:cut])
        if len(base) == 1 and has_glyph(font, base):
            marks = [_MARKS.get(mark) for mark in parts[cut:]]
            if all(mark is not None and has_glyph(font, mark) for mark in marks):
                return base, [mark if mark != "'" or part != _HORN else _HORN
                              for mark, part in zip(marks, parts[cut:])]
            return None
    return None


def drawable(font: pygame.font.Font, letter: str) -> bool:
    """Whether ``letter`` draws in ``font``, itself or built from letters it has."""
    return has_glyph(font, letter) or _built(font, letter) is not None


def _letter(font: pygame.font.Font, letter: str, color: tuple[int, int, int]) -> pygame.Surface:
    """One letter as drawn: the font's own, or built over its plain letter (``_built``)."""
    built = None if has_glyph(font, letter) else _built(font, letter)
    if built is None:
        return font.render(letter, False, color)
    base, marks = built
    plain = font.render(base, False, color)
    ink = plain.get_bounding_rect()
    # Where each mark goes, before the letter's surface is made wide enough for them.
    placed = []
    above = base != unicodedata.normalize("NFD", base)[0]   # ô already carries a mark
    for mark in marks:
        shape = font.render("'" if mark == _HORN else mark, False, color)
        area = shape.get_bounding_rect()
        cut = 0
        if mark == _HORN:
            # Up and right off the letter's top right.
            x, y = ink.right - 1, max(0, ink.top - area.height + 1)
        elif above:
            # A second mark goes beside the first, as Vietnamese sets the acute of ố.
            x, y = ink.right, ink.top
        else:
            # A pixel above the letter, or as high as the row allows: in Galmuri, whose
            # capitals reach its top, Ā's bar takes the place of the A's top rows.
            x, y = ink.centerx - area.width // 2, max(0, ink.top - 1 - area.height)
            cut = max(0, y + area.height + 1 - ink.top)
        placed.append((shape, area, x, y, cut))
        ink = ink.union(pygame.Rect(x, y, area.width, area.height))
        above = True
    width = max([plain.get_width()] + [x + area.width + 1 for _, area, x, _, _ in placed])
    surf = pygame.Surface((width, plain.get_height()), pygame.SRCALPHA)
    surf.blit(plain, (0, 0))
    top = plain.get_bounding_rect().top
    for shape, area, x, y, cut in placed:
        if cut:
            pygame.draw.rect(surf, (0, 0, 0, 0), (x, top, area.width, cut))
        surf.blit(shape, (x, y), area)
    return surf


def _measure(font: pygame.font.Font, text: str) -> int:
    """The drawn width of ``text`` in ``font``, the dialogue font's letter gaps counted."""
    if not _spaced(font) and all(has_glyph(font, letter) for letter in text):
        return font.size(text)[0]
    gap = FontSettings.DIALOGUE_LETTER_GAP if _spaced(font) else 0
    return sum(_letter(font, letter, ColorSettings.WHITE).get_width() + gap for letter in text)


def _render(font: pygame.font.Font, text: str, color: tuple[int, int, int]) -> pygame.Surface:
    """Render ``text`` in ``font``; the dialogue font one letter at a time, a gap after each.

    A letter the font lacks is built (``_letter``), so its line is drawn letter by letter too.
    """
    if not _spaced(font) and all(has_glyph(font, letter) for letter in text):
        return font.render(text, False, color)
    gap = FontSettings.DIALOGUE_LETTER_GAP if _spaced(font) else 0
    surf = pygame.Surface((max(1, _measure(font, text)), font.get_height()), pygame.SRCALPHA)
    x = 0
    for letter in text:
        shape = _letter(font, letter, color)
        surf.blit(shape, (x, 0))
        x += shape.get_width() + gap
    return surf


def ink_top(size: int = FontSettings.SIZE_BODY) -> int:
    """Return the blank rows above the capital letters at ``size``.

    Subtract it from a blit position to put the top of the letters
    where the position says.
    """
    cached = _INK_TOP_CACHE.get(size)
    if cached is None:
        cached = (
            get_font(size).render("H", False, ColorSettings.WHITE)
            .get_bounding_rect().top
        )
        _INK_TOP_CACHE[size] = cached
    return cached


def line_height(size: int = FontSettings.SIZE_BODY) -> int:
    """Return the row pitch for text at ``size``: one text row, or two for a heading."""
    if size == FontSettings.SIZE_DIALOGUE:
        return FontSettings.DIALOGUE_LINE_HEIGHT
    rows = max(1, round(size / FontSettings.SIZE_BODY))
    return FontSettings.LINE_HEIGHT * rows


@functools.cache
def _names_pattern() -> re.Pattern[str]:
    """The names drawn in capitals, as one whole-word pattern.

    Every character's short name, and every speaker in the rooms and the
    story scripts but those in ``FontSettings.NOT_NAMES`` (Villager...).
    """
    from core.shared import by_id, short_name
    from core import story

    names = {short_name(member_id) for member_id in by_id("characters")}

    def walk(node) -> None:
        if isinstance(node, dict):
            for key, value in node.items():
                if key == "speaker" and isinstance(value, str):
                    names.add(value)
                elif key == "talk" and isinstance(value, list):
                    names.update(pair[0] for pair in value if isinstance(pair, list) and len(pair) == 2)
                walk(value)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    game_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for path in glob.glob(os.path.join(game_dir, "data", "cells", "*.json")):
        with open(path, encoding="utf-8") as f:
            walk(json.load(f))
    for scene in [*story.SCRIPTS, *story.PYGAME_SCRIPTS]:
        names.update(step["say"] for step in story.load(scene) if "say" in step)
    names = {name for name in names if isinstance(name, str) and name.isalpha()}
    names -= set(FontSettings.NOT_NAMES)
    return re.compile(r"\b(" + "|".join(sorted(names, key=len, reverse=True)) + r")\b")


def cased(text: str, size: int = FontSettings.SIZE_BODY, spoken: bool = False) -> str:
    """Return ``text`` as drawn: in menus its names in capitals, the rest as written.

    Dialogue (the dialogue font, or ``spoken``) keeps its names as written.
    """
    if spoken or size == FontSettings.SIZE_DIALOGUE:
        return text
    return _names_pattern().sub(lambda match: match[0].upper(), text)


def text_width(text: str, size: int = FontSettings.SIZE_BODY, spoken: bool = False) -> int:
    """Return the drawn width of ``text`` at ``size``, cased as ``cased`` draws it."""
    return _measure(get_font(size), cased(text, size, spoken))


def wrap(text: str, font: pygame.font.Font, max_width: int, spoken: bool = False) -> list[str]:
    """Greedy word-wrap ``text`` so each line fits within ``max_width`` pixels.

    Args:
        text: The text to wrap. May contain ``\n`` for hard breaks.
        font: The font to measure with.
        max_width: The maximum allowed pixel width per line.
        spoken: Dialogue drawn in a menu font: names stay as written.

    Returns:
        A list of lines.
    """
    out: list[str] = []
    for paragraph in (text if spoken or _spaced(font) else cased(text)).split("\n"):
        if not paragraph:
            out.append("")
            continue
        words = paragraph.split(" ")
        current = ""
        for word in words:
            candidate = word if not current else f"{current} {word}"
            if _measure(font, candidate) <= max_width:
                current = candidate
            else:
                if current:
                    out.append(current)
                current = word
        if current:
            out.append(current)
    return out


def _render_glow(
    text: str,
    font: pygame.font.Font,
    fill: tuple[int, int, int],
    glow: tuple[int, int, int],
    radius: int,
    alpha: int,
) -> tuple[pygame.Surface, int]:
    """Render ``text`` in ``fill`` with a soft ``glow`` halo behind it.

    The halo is drawn by blitting the glow-colored text at every offset
    inside a filled circle of ``radius`` pixels with a single per-blit
    ``alpha`` so the offsets accumulate into a soft cloud rather than a
    hard edge. Returned alongside the surface is the pad amount, which
    callers use to offset the blit so the glyph's natural baseline still
    lands at the requested ``position`` (glow bleeds *outward* from the
    text and shouldn't shift layout).
    """
    body = _render(font, text, fill)
    halo = _render(font, text, glow)
    halo.set_alpha(alpha)
    w, h = body.get_size()
    pad = radius + 1
    surf = pygame.Surface((w + 2 * pad, h + 2 * pad), pygame.SRCALPHA)
    r_sq = radius * radius
    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            if dx == 0 and dy == 0:
                continue
            # Drop the box corners so the halo reads round, not square.
            if dx * dx + dy * dy > r_sq:
                continue
            surf.blit(halo, (dx + pad, dy + pad))
    surf.blit(body, (pad, pad))
    return surf, pad


def render_line(
    text: str,
    color: tuple[int, int, int] = ColorSettings.WHITE,
    size: int = FontSettings.SIZE_BODY,
    glow: tuple[int, int, int] | None = None,
    glow_radius: int = 1,
    glow_alpha: int = 110,
    spoken: bool = False,
) -> pygame.Surface:
    """Render one line of text to a fresh surface, its names in capitals.

    The surface is the font's own box, blank space above the letters
    included; blit it ``ink_top(size)`` higher than where the letters
    should start.

    Args:
        text: The text to render.
        color: The text color (the sharp body of the glyph).
        size: Point size; should come from ``FontSettings.SIZE_*``.
        glow: Optional halo color. When set, the returned surface is
            ``2 * (glow_radius + 1)`` pixels wider and taller than the
            raw glyph box; callers blitting it should account for the
            pad (or use ``draw_text`` which handles the offset itself).
        glow_radius: Pixel radius of the halo.
        glow_alpha: Per-blit alpha of the halo passes. Lower values
            make the halo softer.
        spoken: Dialogue drawn in a menu font: names stay as written.

    Returns:
        A new surface containing the rendered glyphs.
    """
    font = get_font(size)
    text = cased(text, size, spoken)
    if glow is None:
        return _render(font, text, color)
    surf, _pad = _render_glow(
        text, font, color, glow, glow_radius, glow_alpha,
    )
    return surf


def draw_text(
    surface: pygame.Surface,
    text: str,
    position: tuple[int, int],
    color: tuple[int, int, int] = ColorSettings.WHITE,
    size: int = FontSettings.SIZE_BODY,
    max_width: int | None = None,
    line_spacing: int = 0,
    glow: tuple[int, int, int] | None = None,
    glow_radius: int = 1,
    glow_alpha: int = 110,
    spoken: bool = False,
) -> int:
    """Draw ``text`` onto ``surface``, wrapping if ``max_width`` is given.

    Args:
        surface: The surface to draw onto.
        text: The text to render.
        position: Top-left in pixels of the first line's capital
            letters. The glow halo, if any, bleeds outside this box
            symmetrically and does not shift the letters.
        color: Text color (sharp body).
        size: Point size.
        max_width: If set, word-wrap to this many pixels per line.
        line_spacing: Extra pixels between rows, on top of ``line_height``.
        glow: Optional halo color. Used by shadow-element labels so the
            lore-black body remains readable against the black command
            panel and any other dark background.
        glow_radius: Pixel radius of the halo.
        glow_alpha: Per-blit alpha of the halo passes.
        spoken: Dialogue drawn in a menu font, such as a speaker's name
            over a text box: names stay as written (Frankie, 10/27).

    Returns:
        The total height in pixels that was drawn (so callers can stack
        further content below it). Halo bleed is NOT counted toward this
        height -- vertical layout treats glow as a free overhang.
    """
    font = get_font(size)
    text = cased(text, size, spoken)
    lines = wrap(text, font, max_width, spoken=True) if max_width is not None else text.split("\n")
    x, y = position
    y -= ink_top(size)
    pitch = line_height(size) + line_spacing
    drawn = 0
    for line in lines:
        if glow is None:
            rendered = _render(font, line, color)
            surface.blit(rendered, (x, y + drawn))
        else:
            rendered, pad = _render_glow(
                line, font, color, glow, glow_radius, glow_alpha,
            )
            # Offset by -pad so the glyph body lines up with where the
            # plain-text render would have placed it.
            surface.blit(rendered, (x - pad, y + drawn - pad))
        drawn += pitch
    return drawn


def pointer_color() -> tuple[int, int, int]:
    """Return the target arrow's colour this frame: bright and dim yellow in turn, never off.

    Menu cursors stay solid yellow; only the arrow over a fighter pulses (Frankie, 10/26).
    """
    lit = int(time.monotonic() * UISettings.MENU_CURSOR_BLINK_HZ * 2) % 2 == 0
    return ColorSettings.YELLOW if lit else UISettings.MENU_CURSOR_DIM


def draw_pointer(
    surface: pygame.Surface,
    tip: tuple[int, int],
    color: tuple[int, int, int] = ColorSettings.YELLOW,
    size: int = 4,
) -> None:
    """Draw the menu cursor: a triangle pointing right, its tip at ``tip``.

    Drawn, not typed, because the game font has no ">" glyph. ``size``
    is the half-height; the triangle is as deep as it is tall.
    """
    x, y = tip
    pygame.draw.polygon(
        surface, color, [(x, y), (x - size, y - size), (x - size, y + size)]
    )
