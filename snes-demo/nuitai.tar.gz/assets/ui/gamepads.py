"""Every connected gamepad, in one layout, plugged in at any time.

The scenes read controller input as Xbox-numbered joystick events
(``InputSettings``: the south face button is 0, START is 7, the left
stick is axes 0 and 1). A raw joystick only numbers its buttons that
way if it is an Xbox-style pad; a PlayStation or Switch pad numbers them its own way.
SDL's game controller layer knows those pads and names their buttons
by position (the bottom face button is A on every pad), so this module
opens each pad as a game controller where SDL knows it and rewrites
its events into the Xbox-numbered joystick events the scenes expect.
A pad SDL does not know is left as a raw joystick, as before.

It also does two things the raw events did not:

* A pad plugged in after the game starts is picked up, and one pulled
  out is dropped.
* A stick tilt is passed on once, when it crosses the threshold, so one
  push moves a menu cursor one step instead of racing it. The overworld
  reads the held stick by polling (``read_held_direction``) and is
  unaffected.
"""

from __future__ import annotations

from typing import Any

import pygame

try:
    from pygame._sdl2 import controller as sdl_controller
except ImportError:  # A browser build may lack it; pads then read as plain joysticks.
    sdl_controller = None

from settings import InputSettings
from ui import touch_pad


# The game controller button each Xbox-numbered button reads from. SDL names
# a controller's face buttons Xbox style, by position (its A is south), and
# ``InputSettings`` names them Super Nintendo style, so the letters cross.
_BUTTONS: dict[int, int] = {
    InputSettings.JOY_BUTTON_B: pygame.CONTROLLER_BUTTON_A,  # south
    InputSettings.JOY_BUTTON_A: pygame.CONTROLLER_BUTTON_B,  # east
    InputSettings.JOY_BUTTON_Y: pygame.CONTROLLER_BUTTON_X,  # west
    InputSettings.JOY_BUTTON_X: pygame.CONTROLLER_BUTTON_Y,  # north
    InputSettings.JOY_BUTTON_L1: pygame.CONTROLLER_BUTTON_LEFTSHOULDER,
    InputSettings.JOY_BUTTON_R1: pygame.CONTROLLER_BUTTON_RIGHTSHOULDER,
    InputSettings.JOY_BUTTON_BACK: pygame.CONTROLLER_BUTTON_BACK,
    InputSettings.JOY_BUTTON_START: pygame.CONTROLLER_BUTTON_START,
}
_FROM_CONTROLLER: dict[int, int] = {pad: joy for joy, pad in _BUTTONS.items()}

# The game controller axis each Xbox-numbered axis reads from.
_AXES: dict[int, int] = {
    InputSettings.JOY_AXIS_LEFT_X: pygame.CONTROLLER_AXIS_LEFTX,
    InputSettings.JOY_AXIS_LEFT_Y: pygame.CONTROLLER_AXIS_LEFTY,
    InputSettings.JOY_AXIS_L2: pygame.CONTROLLER_AXIS_TRIGGERLEFT,
    InputSettings.JOY_AXIS_R2: pygame.CONTROLLER_AXIS_TRIGGERRIGHT,
}
_AXES_FROM_CONTROLLER: dict[int, int] = {pad: joy for joy, pad in _AXES.items()}

# The sticks, whose tilts reach the scenes only when they cross the threshold.
_STICK_AXES = (InputSettings.JOY_AXIS_LEFT_X, InputSettings.JOY_AXIS_LEFT_Y)

_DPAD = (
    pygame.CONTROLLER_BUTTON_DPAD_UP,
    pygame.CONTROLLER_BUTTON_DPAD_DOWN,
    pygame.CONTROLLER_BUTTON_DPAD_LEFT,
    pygame.CONTROLLER_BUTTON_DPAD_RIGHT,
)

# A game controller reports an axis from -32768 to 32767.
_AXIS_RANGE = 32767.0

_JOY_EVENTS = (
    pygame.JOYBUTTONDOWN, pygame.JOYBUTTONUP,
    pygame.JOYHATMOTION, pygame.JOYAXISMOTION, pygame.JOYBALLMOTION,
)
_CONTROLLER_EVENTS = (
    pygame.CONTROLLERBUTTONDOWN, pygame.CONTROLLERBUTTONUP,
    pygame.CONTROLLERAXISMOTION,
)
_PLUG_EVENTS = (
    pygame.JOYDEVICEADDED, pygame.JOYDEVICEREMOVED,
    pygame.CONTROLLERDEVICEADDED, pygame.CONTROLLERDEVICEREMOVED,
)


class _Pad:
    """A game controller that answers like an Xbox-numbered joystick.

    ``read_held_direction`` and the quit chord poll pads through
    ``get_numhats``, ``get_hat``, ``get_axis`` and ``get_button``.
    """

    def __init__(self, pad: Any) -> None:
        self._pad = pad

    def get_numhats(self) -> int:
        return 1

    def get_hat(self, _index: int) -> tuple[int, int]:
        return _hat_of(self._pad.get_button)

    def get_axis(self, axis: int) -> float:
        if axis not in _AXES:
            return 0.0
        return self._pad.get_axis(_AXES[axis]) / _AXIS_RANGE

    def get_button(self, button: int) -> bool:
        if button not in _BUTTONS:
            return False
        return bool(self._pad.get_button(_BUTTONS[button]))


def _hat_of(pressed) -> tuple[int, int]:
    """Return the D-pad as a hat value, up positive, from a button reader."""
    up, down, left, right = (bool(pressed(b)) for b in _DPAD)
    return (int(right) - int(left), int(up) - int(down))


class Gamepads:
    """The connected pads, and the events they send rewritten for the scenes."""

    def __init__(self) -> None:
        pygame.joystick.init()
        if sdl_controller is not None:
            sdl_controller.init()
        # What ``read_held_direction`` and the quit chord poll.
        self.devices: list[Any] = []
        # Instance ids opened as game controllers, whose raw joystick
        # events are dropped so nothing arrives twice.
        self._mapped: set[int] = set()
        # Kept so SDL does not close them.
        self._open: list[Any] = []
        # (instance id, axis) -> -1, 0 or +1: which side of the threshold
        # a stick was last on.
        self._tilt: dict[tuple[int, int], int] = {}
        # Instance id -> the D-pad buttons held down.
        self._held: dict[int, set[int]] = {}
        # The website's on-screen pad, in the browser build only.
        self.touch = touch_pad.from_page()
        self.refresh()

    def refresh(self) -> None:
        """Open every connected pad again; called at start and on each plug or unplug."""
        self.devices = []
        self._mapped = set()
        self._open = []
        for index in range(pygame.joystick.get_count()):
            if sdl_controller is not None and sdl_controller.is_controller(index):
                pad = sdl_controller.Controller(index)
                instance = pad.as_joystick().get_instance_id()
                self._mapped.add(instance)
                self._open.append(pad)
                self.devices.append(_Pad(pad))
            else:
                joystick = pygame.joystick.Joystick(index)
                self._open.append(joystick)
                self.devices.append(joystick)
        if self.touch is not None:
            self.devices.append(self.touch)

    def poll(self) -> list[pygame.event.Event]:
        """Return the on-screen pad's presses since the last frame, as joystick events."""
        return self.touch.poll() if self.touch is not None else []

    def translate(self, event: pygame.event.Event) -> pygame.event.Event | None:
        """Return the event the scenes should see, or None to drop it.

        Plugging a pad in or out refreshes the list and is dropped.
        Game controller events come back as Xbox-numbered joystick
        events. A raw joystick event from a pad opened as a game
        controller is dropped, since its controller event carries it.
        A stick tilt is kept only when it crosses the threshold.
        Everything else passes through unchanged.
        """
        if event.type in _PLUG_EVENTS:
            self.refresh()
            return None
        if event.type in _JOY_EVENTS:
            if getattr(event, "instance_id", None) in self._mapped:
                return None
            if event.type == pygame.JOYAXISMOTION:
                return self._stick(event.instance_id, event.axis, event.value)
            return event
        if event.type in _CONTROLLER_EVENTS:
            return self._from_controller(event)
        return event

    def _from_controller(self, event: pygame.event.Event) -> pygame.event.Event | None:
        """Rewrite one game controller event as the joystick event the scenes read."""
        instance = event.instance_id
        if event.type == pygame.CONTROLLERAXISMOTION:
            if event.axis not in _AXES_FROM_CONTROLLER:
                return None
            return self._stick(
                instance, _AXES_FROM_CONTROLLER[event.axis], event.value / _AXIS_RANGE
            )
        if event.button in _DPAD:
            held = self._held.setdefault(instance, set())
            before = _hat_of(held.__contains__)
            if event.type == pygame.CONTROLLERBUTTONDOWN:
                held.add(event.button)
            else:
                held.discard(event.button)
            value = _hat_of(held.__contains__)
            if value == before:
                return None
            return pygame.event.Event(
                pygame.JOYHATMOTION, hat=0, value=value, instance_id=instance
            )
        if event.button not in _FROM_CONTROLLER:
            return None
        kind = (
            pygame.JOYBUTTONDOWN if event.type == pygame.CONTROLLERBUTTONDOWN
            else pygame.JOYBUTTONUP
        )
        return pygame.event.Event(
            kind, button=_FROM_CONTROLLER[event.button], instance_id=instance
        )

    def _stick(self, instance: int, axis: int, value: float) -> pygame.event.Event | None:
        """Return an axis event only when a stick crosses the threshold.

        A trigger is passed on as it is; nothing reads triggers yet.
        """
        if axis not in _STICK_AXES:
            return pygame.event.Event(
                pygame.JOYAXISMOTION, axis=axis, value=value, instance_id=instance
            )
        threshold = InputSettings.JOY_TRIGGER_THRESHOLD
        side = -1 if value < -threshold else (1 if value > threshold else 0)
        before = self._tilt.get((instance, axis), 0)
        self._tilt[(instance, axis)] = side
        if side == 0 or side == before:
            return None
        return pygame.event.Event(
            pygame.JOYAXISMOTION, axis=axis, value=value, instance_id=instance
        )
