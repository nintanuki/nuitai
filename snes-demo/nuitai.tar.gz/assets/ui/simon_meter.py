"""Maika's Charm on screen: Simon on A, B, X and Y, fast, against a timer (Frankie, 11/1).

The four face buttons sit in the window the commands were in, laid out as on
a Super Nintendo pad (X on top, Y left, A right, B below). One lights up and
the player presses it back; then the same string lights again one longer, A,
then A B, and so on. A wrong press ends it, and so does the time running out.
Every round got right makes the charm take hold longer (``Battle.submit_charm``,
no roll on top, Frankie, 11/1).

How fast the buttons light comes from Maika's Willpower against the monster's
(Frankie, 11/1): the ``ease`` slows them down for a stronger Maika.
"""

from __future__ import annotations

import random

import pygame

from settings import FontSettings, MinigameSettings
from ui import input_map, text_renderer
from ui.block_meter import draw_frame, draw_shaded
from ui.spin_meter import _BAR_HEIGHT, _BAR_WIDTH

_BUTTONS = ("A", "B", "X", "Y")
_RADIUS = 7
_SPREAD = 11              # How far each button sits from the middle.
_PLACE = {"X": (0, -1), "Y": (-1, 0), "A": (1, 0), "B": (0, 1)}
# The Super Famicom's colors (Claude's picks): dim, then lit.
_COLORS = {
    "A": ((110, 24, 30), (255, 70, 70)),
    "B": ((120, 96, 10), (255, 230, 60)),
    "X": ((24, 44, 120), (90, 150, 255)),
    "Y": ((20, 90, 40), (80, 230, 110)),
}
_RIM = (20, 20, 28)
_LETTER = (255, 255, 255)
_WRONG = (240, 64, 56)
_PRESS_SHOW = 0.12        # How long a press keeps its button lit.
_BETWEEN = 0.25           # The pause after a round is got right.


def button_of(event: pygame.event.Event) -> str | None:
    """The face button ``event`` presses, by its job (A confirm, B cancel, X menu, Y tool), or None."""
    for test, name in ((input_map.is_confirm, "A"), (input_map.is_cancel, "B"),
                       (input_map.is_menu, "X"), (input_map.is_tool, "Y")):
        if test(event):
            return name
    return None


class SimonMeter:
    """The string, how far the player is, and the clock, for one Charm."""

    def __init__(self, target_id: str, ease: float = 1.0, rng: random.Random | None = None) -> None:
        """Start the first round at ``target_id``; ``ease`` from the stats slows the lights."""
        self.target_id = target_id
        self._rng = rng or random.Random()
        self.lit_seconds = MinigameSettings.SIMON_LIT * ease
        self.gap_seconds = MinigameSettings.SIMON_GAP * ease
        self.left = float(MinigameSettings.SIMON_SECONDS)
        self.string: list[str] = [self._rng.choice(_BUTTONS)]
        self.rounds = 0           # Rounds got right.
        self.pressed = 0          # Buttons pressed back so far this round.
        self.wrong = False
        self._showing = 0.0       # Time into showing the string.
        self._watching = True
        self._pause = 0.0
        self._lit_press: tuple[str, float] | None = None

    @property
    def done(self) -> bool:
        """True after a wrong press, the time running out, or the last round."""
        return self.wrong or self.left <= 0 or self.rounds >= MinigameSettings.SIMON_MOST

    def _lit_now(self) -> str | None:
        """The button lit while the string is being shown, or None in a gap."""
        step = self.lit_seconds + self.gap_seconds
        index = int(self._showing // step)
        if index < len(self.string) and self._showing - index * step < self.lit_seconds:
            return self.string[index]
        return None

    def press(self, button: str) -> bool:
        """Take one press in the player's turn; True if it was the next one, False if wrong (or not their turn)."""
        if self.done or self._watching or self._pause > 0:
            return False
        self._lit_press = (button, _PRESS_SHOW)
        if button != self.string[self.pressed]:
            self.wrong = True
            return False
        self.pressed += 1
        if self.pressed >= len(self.string):
            self.rounds += 1
            self.pressed = 0
            self.string.append(self._rng.choice(_BUTTONS))
            self._pause = _BETWEEN
        return True

    def update(self, dt: float) -> None:
        """Run the clock, show the string, and start the next showing after a round."""
        if self.done:
            return
        self.left = max(0.0, self.left - dt)
        if self._lit_press is not None:
            button, left = self._lit_press
            self._lit_press = (button, left - dt) if left > dt else None
        if self._pause > 0:
            self._pause -= dt
            if self._pause <= 0:
                self._watching, self._showing = True, 0.0
            return
        if self._watching:
            self._showing += dt
            if self._showing >= len(self.string) * (self.lit_seconds + self.gap_seconds):
                self._watching = False

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the four buttons on the left, what to do to their right, the bar along the bottom."""
        center = (window.left + 34, window.top + 38)
        lit = self._lit_now() if self._watching else None
        if self._lit_press is not None:
            lit = self._lit_press[0]
        for button, (dx, dy) in _PLACE.items():
            x, y = center[0] + dx * _SPREAD, center[1] + dy * _SPREAD
            dim, bright = _COLORS[button]
            face = bright if button == lit else dim
            if self.wrong and self._lit_press is not None and button == self._lit_press[0]:
                face = _WRONG
            pygame.draw.circle(surface, _RIM, (x, y + 1), _RADIUS + 1)
            pygame.draw.circle(surface, face, (x, y), _RADIUS)
            width = text_renderer.text_width(button, FontSettings.SIZE_BODY)
            text_renderer.draw_text(surface, button, (x - width // 2 + 1, y - 3), color=_LETTER,
                                    size=FontSettings.SIZE_BODY)
        size = FontSettings.SIZE_BODY
        middle = (center[0] + _SPREAD + _RADIUS + window.right) // 2
        text = "Wrong!" if self.wrong else ("Watch..." if self._watching or self._pause > 0 else "Your turn!")
        color = _WRONG if self.wrong else _LETTER
        text_renderer.draw_text(surface, text, (middle - text_renderer.text_width(text, size) // 2, window.top + 28),
                                color=color, size=size)
        text = f"Round {self.rounds + 1}"
        text_renderer.draw_text(surface, text, (middle - text_renderer.text_width(text, size) // 2, window.top + 42),
                                color=_LETTER, size=size)
        frame = pygame.Rect(0, 0, _BAR_WIDTH + 4, _BAR_HEIGHT + 4)
        frame.center = pygame.Rect(window.left, window.bottom - 22, window.width, 12).center
        well = draw_frame(surface, frame)
        draw_shaded(surface, well, well.left, round(_BAR_WIDTH * self.left / MinigameSettings.SIMON_SECONDS))
