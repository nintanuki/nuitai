"""Inside walls: a wall tile picks its piece of the wooden frame by where the floor is.

The insides of the houses (Frankie, 10/22) are rooms like
any other, painted in the Workshop: black outside, a ring of wall tiles,
mats inside. A wall tile looks at its neighbors and takes the piece of
Ninja Adventure's simple wall frame (``tiles/interior/walls.png``, 80 by
80, CC0) that faces the floor: the top piece over floor, the side pieces
beside it, a corner where floor touches only diagonally. The black is
the frame's own dark outline color. The game, the Workshop and the
cartridge build all draw walls through here, so they match.
"""

from __future__ import annotations

import os

import pygame

from settings import AssetPaths, GridSettings, OverworldSettings

# The characters drawn here: the wall, and the black around a room.
CHARS: tuple[str, ...] = (OverworldSettings.INSIDE_WALL_CHAR, OverworldSettings.VOID_CHAR)
DARK = (20, 27, 27)

# Where each piece sits in walls.png, in pixels.
PIECES: dict[str, tuple[int, int]] = {
    "top": (48, 0), "bottom": (48, 64), "left": (0, 16), "right": (64, 16),
    "top_left": (0, 0), "top_right": (64, 0), "bottom_left": (0, 64), "bottom_right": (64, 64),
}

_SHEET: pygame.Surface | None = None
_PICTURES: dict[str, pygame.Surface] = {}


def _floor(grid, col: int, row: int) -> bool:
    """Whether a tile is inside the room: on the grid and neither wall nor black."""
    return 0 <= row < len(grid) and 0 <= col < len(grid[row]) and grid[row][col] not in CHARS


def piece(grid, col: int, row: int) -> str | None:
    """Which piece a wall tile takes, or None for black (also every black tile)."""
    if grid[row][col] != OverworldSettings.INSIDE_WALL_CHAR:
        return None
    for name, (dx, dy) in (("top", (0, 1)), ("bottom", (0, -1)), ("left", (1, 0)), ("right", (-1, 0)),
                           ("top_left", (1, 1)), ("top_right", (-1, 1)),
                           ("bottom_left", (1, -1)), ("bottom_right", (-1, -1))):
        if _floor(grid, col + dx, row + dy):
            return name
    return None


def tile(grid, col: int, row: int) -> pygame.Surface:
    """The 16 pixel picture for a wall or black tile."""
    global _SHEET
    name = piece(grid, col, row) or "black"
    if name not in _PICTURES:
        size = GridSettings.TILE_SIZE
        picture = pygame.Surface((size, size), pygame.SRCALPHA)
        picture.fill(DARK)
        if name != "black":
            if _SHEET is None:
                _SHEET = pygame.image.load(os.path.join(AssetPaths.TILES_DIR, "interior", "walls.png"))
            picture.blit(_SHEET, (0, 0), pygame.Rect(*PIECES[name], size, size))
        _PICTURES[name] = picture
    return _PICTURES[name]
