"""The stance switch's icon: the recycle sign in two colors (Frankie, 10/26).

It sits in the letter space before the stance's name on the top row of the
ELEMENT grid, turning a quarter at a time while the cursor is on that row.
The top arrow is the stance the switch goes to, the bottom one the stance held now, each in
its element's three shades, so Kailo's is red and blue and Hina's green and
yellow. 7 by 7 in an 8 by 8 square, the last column and row clear, like a
move's element tag (ui/element_tag.py). After the name come the member's
two element icons, the stance's boxed in yellow as on the party list.
"""

from __future__ import annotations

import pygame

from settings import BattleStageSettings as Stage, ColorSettings
from ui.battle_stage import _small_element_icon
from ui.element_tag import CELL
from ui.item_icon import element_shades

# 1 to 3 the stance switched to, dark to light; 4 to 6 the stance held now.
PIXELS: tuple[str, ...] = (
    "..333.3",
    ".3...33",
    "3...333",
    ".......",
    "555...5",
    "55...5.",
    "5.555..",
)

_CACHE: dict[tuple[str, str, int], pygame.Surface] = {}


def _turned(pixels: tuple[str, ...], turns: int) -> tuple[str, ...]:
    """``pixels`` turned a quarter clockwise ``turns`` times."""
    for _ in range(turns % 4):
        pixels = tuple("".join(row[x] for row in reversed(pixels)) for x in range(len(pixels)))
    return pixels


def switch_icon(to_element: str, from_element: str, turns: int = 0) -> pygame.Surface:
    """The recycle sign from ``from_element``'s stance to ``to_element``'s, in its 8 by 8 square.

    ``turns`` quarter turns clockwise, for the spin while the cursor is on it.
    """
    key = (to_element, from_element, turns % 4)
    if key not in _CACHE:
        shades = element_shades(to_element) + element_shades(from_element)
        surface = pygame.Surface((CELL, CELL), pygame.SRCALPHA)
        for y, row in enumerate(_turned(PIXELS, turns)):
            for x, pixel in enumerate(row):
                if pixel != ".":
                    surface.set_at((x, y), shades[int(pixel) - 1])
        _CACHE[key] = surface
    return _CACHE[key]


def stance_icons(elements, stance_element) -> pygame.Surface:
    """A member's two element icons, the stance's boxed in yellow, as on the party list (D-453).

    The picture starts a pixel above the letters, where the box's top runs.
    """
    size = Stage.PARTY_ICON_SIZE
    surface = pygame.Surface((Stage.PARTY_ICON_PITCH + size + 2, size + 2), pygame.SRCALPHA)
    for index, element in enumerate(elements):
        icon = _small_element_icon(element.value, size)
        left = index * Stage.PARTY_ICON_PITCH
        if icon is not None:
            surface.blit(icon, (left + 1, 1))
        if element is stance_element:
            pygame.draw.rect(surface, ColorSettings.YELLOW, pygame.Rect(left, 0, size + 2, size + 2), 1)
    return surface
