"""Rain over the fight while Spring Rain falls (Frankie, 11/4).

Thin pale streaks slanting down over the stage, above the monsters and under
the turn strip and the windows. Each streak's place is fixed by its number and
moves with the clock, so the rain looks the same every frame at the same moment
and needs no state. In the Super Nintendo's spirit: a handful of short lines, no
blending beyond one see-through layer.
"""

from __future__ import annotations

import pygame

from settings import LightWaveSettings, RainSettings


def render_rain(surface: pygame.Surface, bottom: int, now: float) -> None:
    """Draw the rain down to ``bottom`` (the top of the windows) at clock time ``now``."""
    width = surface.get_width()
    layer = pygame.Surface((width, bottom), pygame.SRCALPHA)
    length, slant = RainSettings.LENGTH, RainSettings.SLANT
    for n in range(RainSettings.DROPS):
        # A fixed scatter per drop: where it starts across, and how far into its fall it is.
        x0 = (n * 73) % (width + bottom // 2)
        phase = ((n * 37) % 100) / 100
        fall = ((now * RainSettings.SPEED / max(1, bottom)) + phase) % 1.0
        y = int(fall * (bottom + length)) - length
        x = x0 - int(fall * bottom * slant)
        pygame.draw.line(layer, RainSettings.COLOR, (x, y), (x - int(length * slant), y + length))
    surface.blit(layer, (0, 0))


def render_light_wave(surface: pygame.Surface, bottom: int, now: float) -> None:
    """Light Wave over the fight (Frankie, 11/4): soft gold specks drifting up from the windows,
    each fading as it rises and twinkling as it goes, down to ``bottom`` at clock time ``now``."""
    width = surface.get_width()
    layer = pygame.Surface((width, bottom), pygame.SRCALPHA)
    r, g, b, alpha = LightWaveSettings.COLOR
    for n in range(LightWaveSettings.SPECKS):
        x = (n * 53) % width + int(3 * ((now * 1.3 + n) % 2 - 1))
        phase = ((n * 41) % 100) / 100
        rise = ((now * LightWaveSettings.SPEED / max(1, bottom)) + phase) % 1.0
        y = bottom - int(rise * bottom)
        fade = int(alpha * min(1.0, 1.4 * (1.0 - rise)))
        if int(now * 6 + n) % 3 == 0:
            fade //= 2
        # A small four-point twinkle: a bright middle and a softer cross.
        layer.fill((r, g, b, fade), (x, y, 2, 2))
        layer.fill((r, g, b, fade // 2), (x - 1, y, 4, 2))
        layer.fill((r, g, b, fade // 2), (x, y - 1, 2, 4))
    surface.blit(layer, (0, 0))
