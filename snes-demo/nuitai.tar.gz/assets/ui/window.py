"""A window: a filled box with a border and rounded corners (D-457).

Final Fantasy VI and Dragon Quest round their windows' corners, so every
window in the game is drawn here, and changing the look is one place.
The inside is a deep ocean gradient rather than black (D-451), the way
Final Fantasy VI fills its windows with blue, tinted by Config's window
color (``systems/config.py``).
"""

from __future__ import annotations

import pygame

from settings import ColorSettings, FontSettings, UISettings
from systems import config
from ui import text_renderer

# Gradient fills already drawn, keyed by size, radius and colours.
_FILLS: dict[tuple, pygame.Surface] = {}


def _gradient_fill(
    size: tuple[int, int],
    radius: int,
    top: tuple[int, int, int],
    bottom: tuple[int, int, int],
) -> pygame.Surface:
    """Return a ``size`` box shaded from ``top`` to ``bottom``, its corners cut round."""
    key = (size, radius, top, bottom)
    cached = _FILLS.get(key)
    if cached is not None:
        return cached
    width, height = size
    fill = pygame.Surface(size, pygame.SRCALPHA)
    for y in range(height):
        share = y / max(1, height - 1)
        color = tuple(round(a + (b - a) * share) for a, b in zip(top, bottom))
        pygame.draw.line(fill, color, (0, y), (width - 1, y))
    mask = pygame.Surface(size, pygame.SRCALPHA)
    pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=radius)
    fill.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    _FILLS[key] = fill
    return fill


def draw_window(
    surface: pygame.Surface,
    rect: pygame.Rect,
    border: tuple[int, int, int] = ColorSettings.WHITE,
    fill: tuple[int, int, int] | None | str = "ocean",
    thickness: int = UISettings.TEXT_BOX_BORDER_THICKNESS,
    radius: int = UISettings.WINDOW_CORNER_RADIUS,
) -> None:
    """Draw a window over ``rect``: the fill, then the border, corners rounded.

    Args:
        surface: Where to draw.
        rect: The window's outer edge.
        border: The border's colour.
        fill: "ocean" for the game's gradient in Config's window color, a colour for a flat fill,
            or None to leave it see-through.
        thickness: The border's width in pixels.
        radius: How round the corners are, in pixels.
    """
    if fill == "ocean":
        surface.blit(
            _gradient_fill(rect.size, radius, *config.window_colors()),
            rect.topleft,
        )
    elif fill is not None:
        pygame.draw.rect(surface, fill, rect, border_radius=radius)
    pygame.draw.rect(surface, border, rect, thickness, border_radius=radius)


def draw_header(
    surface: pygame.Surface,
    label: str,
    help_lines: list[str] | tuple[str, ...] = (),
    corner: str | None = None,
    help_color: tuple[int, int, int] = ColorSettings.WHITE,
) -> None:
    """Draw a menu screen's whole window and Final Fantasy VI's top (Frankie, 10/23).

    The screen is one window; over its top left, a small box with
    ``label``, and under that the help window with up to two
    ``help_lines`` about what the cursor is on. ``corner``, the member
    the screen is about, sits at the top right. The list goes from
    ``UISettings.HEADER_LIST_TOP`` down.
    """

    size = FontSettings.SIZE_BODY
    draw_window(surface, surface.get_rect())
    label_rect = pygame.Rect(UISettings.HEADER_LABEL_RECT)
    help_rect = pygame.Rect(UISettings.HEADER_HELP_RECT)
    draw_window(surface, label_rect)
    draw_window(surface, help_rect)
    x = UISettings.HEADER_TEXT_X
    text_renderer.draw_text(surface, label, (x, label_rect.top + 8), color=ColorSettings.WHITE, size=size)
    if corner:
        text_renderer.draw_text(surface, corner, (label_rect.right + x, label_rect.top + 8),
                                color=ColorSettings.WHITE, size=size)
    for index, line in enumerate(help_lines[:2]):
        text_renderer.draw_text(surface, line, (x, help_rect.top + 8 + index * 16), color=help_color, size=size)


def help_wrap(text: str, width: int | None = None) -> list[str]:
    """``text`` wrapped to the help window's width (or ``width`` pixels), two lines at most.

    Longer text keeps as many whole sentences from the start as fit.
    """
    width = width or UISettings.HEADER_HELP_RECT[2] - 2 * UISettings.HEADER_TEXT_X
    font = text_renderer.get_font(FontSettings.SIZE_BODY)
    sentences = text.replace(". ", ".\n").split("\n")
    while len(sentences) > 1 and len(text_renderer.wrap(" ".join(sentences), font, width)) > 2:
        sentences.pop()
    return text_renderer.wrap(" ".join(sentences), font, width)[:2]
