"""A window: a filled box with a border and rounded corners (D-457).

Final Fantasy VI and Dragon Quest round their windows' corners, so every
window in the game is drawn here, and changing the look is one place.
The inside is a deep ocean gradient rather than black (D-451), the way
Final Fantasy VI fills its windows with blue.
"""

from __future__ import annotations

import pygame

from settings import ColorSettings, UISettings

# Gradient fills already drawn, keyed by size, radius and colours.
_FILLS: dict[tuple, pygame.Surface] = {}


def _gradient_fill(
    size: tuple[int, int],
    radius: int,
    top: tuple[int, int, int],
    bottom: tuple[int, int, int],
) -> pygame.Surface:
    """Return a ``size`` box shaded from ``top`` to ``bottom``, its corners cut round."""
    key = (size, radius, top, bottom)
    cached = _FILLS.get(key)
    if cached is not None:
        return cached
    width, height = size
    fill = pygame.Surface(size, pygame.SRCALPHA)
    for y in range(height):
        share = y / max(1, height - 1)
        color = tuple(round(a + (b - a) * share) for a, b in zip(top, bottom))
        pygame.draw.line(fill, color, (0, y), (width - 1, y))
    mask = pygame.Surface(size, pygame.SRCALPHA)
    pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=radius)
    fill.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    _FILLS[key] = fill
    return fill


def draw_window(
    surface: pygame.Surface,
    rect: pygame.Rect,
    border: tuple[int, int, int] = ColorSettings.WHITE,
    fill: tuple[int, int, int] | None | str = "ocean",
    thickness: int = UISettings.TEXT_BOX_BORDER_THICKNESS,
    radius: int = UISettings.WINDOW_CORNER_RADIUS,
) -> None:
    """Draw a window over ``rect``: the fill, then the border, corners rounded.

    Args:
        surface: Where to draw.
        rect: The window's outer edge.
        border: The border's colour.
        fill: "ocean" for the game's gradient, a colour for a flat fill,
            or None to leave it see-through.
        thickness: The border's width in pixels.
        radius: How round the corners are, in pixels.
    """
    if fill == "ocean":
        surface.blit(
            _gradient_fill(rect.size, radius, UISettings.WINDOW_TOP, UISettings.WINDOW_BOTTOM),
            rect.topleft,
        )
    elif fill is not None:
        pygame.draw.rect(surface, fill, rect, border_radius=radius)
    pygame.draw.rect(surface, border, rect, thickness, border_radius=radius)
