from __future__ import annotations

import asyncio
import os

import pygame
import sys

from crt import CRT
from core.data_loader import DataLoader
from core.scene import SceneStack
from core.scenes.confirm_scene import ConfirmScene
from core.scenes.title_scene import TitleScene
from settings import ColorSettings, ConfirmSettings, InputSettings, ScreenSettings
from systems.audio_manager import AudioManager
from systems.party import Party
from ui.gamepads import Gamepads
from ui.layout import DebugOverlay


class GameManager:
    """Coordinate game state, flow, rendering phases, and input orchestration."""

    def __init__(self, start_fullscreen: bool = False):
        """Initialize pygame, the display, the input cache, and post-processing.

        Args:
            start_fullscreen: Whether to launch directly in fullscreen mode.
        """

        pygame.init()
        self._initialize_audio_mixer()
        # The game draws on ``screen``, a 256 by 224 surface (D-158).
        # ``_present`` enlarges it by ``scale``, a whole number, onto the
        # window, so every game pixel is the same square of window
        # pixels and nothing is smoothed. The CRT pass is skipped in
        # fullscreen, where the player may be on a real CRT (the cabinet).
        self.full_screen = start_fullscreen
        self.scale = 1
        self.origin = (0, 0)
        self.window: pygame.Surface = pygame.display.set_mode((1, 1))
        self.crt: CRT | None = None
        self._open_window()
        pygame.display.set_caption(ScreenSettings.WINDOW_TITLE)
        # The window's icon: the website's nautilus (Frankie, 10/18). The
        # taskbar shortcut uses the same picture (tools/make_shortcut.py).
        icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "assets", "graphics", "app_icon.png")
        if os.path.exists(icon_path):
            pygame.display.set_icon(pygame.image.load(icon_path))
        self.screen = pygame.Surface(ScreenSettings.RESOLUTION)
        self.clock = pygame.time.Clock()

        self.setup_controllers()

        # Audio is data-driven; see settings.AudioSettings for the registry.
        self.audio = AudioManager()

        # Content packs (characters, abilities, enemies, dungeons,
        # dialogue) are read from ``data/`` on demand and cached. Scenes
        # reach into this loader rather than re-reading JSON themselves.
        self.data = DataLoader()

        # Active gameplay state. ``party`` is overwritten by the title
        # screen when the player picks NEW GAME or CONTINUE; until then it
        # is an empty roster so save/load code can rely on it being
        # non-None.
        self.party: Party = Party()
        self.scene_stack = SceneStack(self)
        self.scene_stack.push(TitleScene(self))

    def _initialize_audio_mixer(self) -> None:
        """Initialize pygame's mixer once so AudioManager has a backing device."""
        if pygame.mixer.get_init():
            return
        try:
            pygame.mixer.init()
        except pygame.error as error:
            # Mixer failures are non-fatal; the game keeps running silently.
            # Logged via stderr so it never lands in gameplay output.
            sys.stderr.write(f"Audio mixer initialization failed: {error}\n")

    # -------------------------
    # BOOT / SETUP
    # -------------------------

    def _open_window(self) -> None:
        """Open the window, or the whole screen, at a whole-number scale.

        Windowed, the scale is the largest that leaves room for the
        title bar and the taskbar. Fullscreen, it is the largest that
        fits the desktop, and the game sits centred in black bars.
        """
        width, height = ScreenSettings.RESOLUTION
        if ScreenSettings.WEB:
            # In a browser the page scales the canvas to fit; draw it at 3x.
            self.scale = ScreenSettings.WEB_SCALE
            self.window = pygame.display.set_mode((width * self.scale, height * self.scale))
            self.origin = (0, 0)
            self.crt = CRT(self.window, self.scale)
            return
        desktop_w, desktop_h = pygame.display.get_desktop_sizes()[0]
        if self.full_screen:
            self.scale = max(1, min(desktop_w // width, desktop_h // height))
            self.window = pygame.display.set_mode(
                (desktop_w, desktop_h), pygame.FULLSCREEN
            )
        else:
            self.scale = max(1, min(
                (desktop_w - ScreenSettings.WINDOW_MARGIN_W) // width,
                (desktop_h - ScreenSettings.WINDOW_MARGIN_H) // height,
            ))
            self.window = pygame.display.set_mode(
                (width * self.scale, height * self.scale)
            )
        window_w, window_h = self.window.get_size()
        self.origin = (
            (window_w - width * self.scale) // 2,
            (window_h - height * self.scale) // 2,
        )
        self.crt = CRT(self.window, self.scale)

    def toggle_fullscreen(self) -> None:
        """Switch between the window and the whole screen."""
        self.full_screen = not self.full_screen
        self._open_window()

    def setup_controllers(self) -> None:
        """Open every connected pad; ``Gamepads`` keeps the list current as pads come and go."""
        self.gamepads = Gamepads()

    @property
    def connected_joysticks(self) -> list:
        """Return the connected pads, each answering like an Xbox-numbered joystick."""
        return self.gamepads.devices

    def reset_game(self):
        """Restart the game by replacing the current GameManager with a fresh one.

        This is safer than resetting each subsystem by hand because it reuses
        the same startup path the game uses on first launch.
        """
        new_game_manager = GameManager(start_fullscreen=self.full_screen)
        new_game_manager.run()
        sys.exit()

    def close_game(self) -> None:
        """Close the game process cleanly."""
        pygame.quit()
        sys.exit()

    def return_to_title(self) -> None:
        """Throw away the whole stack and go back to the title screen."""
        self.scene_stack.clear()
        self.scene_stack.push(TitleScene(self))

    # -------------------------
    # QUIT CONFIRMATION
    # -------------------------

    def ask_to_quit(self, closing_window: bool = False) -> None:
        """Put a NO / YES box over the current scene before leaving.

        Dungeon Digger's rule: on the title screen the question is
        "Quit game?"; during play Esc asks "Quit to title?", because
        that is where Esc leads. The window's X always means closing
        the program, so during play it asks "Quit game?" with the
        unsaved-progress warning. Nothing happens if a box is already
        up: Esc is ignored inside it, so the player has to pick.

        Args:
            closing_window: True when the window's X was clicked.
        """
        top = self.scene_stack.top
        if isinstance(top, ConfirmScene):
            return
        if isinstance(top, TitleScene):
            box = ConfirmScene(
                self, ConfirmSettings.TITLE_QUIT_GAME,
                ConfirmSettings.BODY_QUIT_GAME, on_yes=self.close_game,
            )
        elif closing_window:
            box = ConfirmScene(
                self, ConfirmSettings.TITLE_CLOSE_WINDOW,
                ConfirmSettings.BODY_UNSAVED, on_yes=self.close_game,
            )
        else:
            box = ConfirmScene(
                self, ConfirmSettings.TITLE_QUIT_TO_TITLE,
                ConfirmSettings.BODY_UNSAVED, on_yes=self.return_to_title,
            )
        self.audio.play("menu_select")
        self.scene_stack.push(box)

    def quit_combo_pressed(self) -> bool:
        """Return True if START + SELECT + L1 + R1 are held on any controller."""
        required_buttons = InputSettings.JOY_BUTTON_QUIT_COMBO
        for joystick in self.connected_joysticks:
            if all(joystick.get_button(button) for button in required_buttons):
                return True
        return False
    
    # -------------------------
    # INPUT HANDLING
    # -------------------------

    def _handle_keydown(self, event) -> None:
        """Route one keyboard press to the appropriate UI/gameplay handler."""
        # Esc asks before leaving, the way Dungeon Digger does. The
        # controller's four-button chord stays instant: nobody presses
        # it by accident, and the arcade cabinet relies on it.
        if event.key == pygame.K_ESCAPE:
            self.ask_to_quit()

        # F11 fullscreen toggle is global and intentionally falls through so
        # other handlers still see the press.
        if event.key == pygame.K_F11:
            self.toggle_fullscreen()

        # F1 toggles the UI debug overlay (see ui/layout.py). Off by
        # default; when on, every scene that registers debug rects /
        # points will outline them with labels so you can SEE the
        # layout coordinates instead of guessing. Falls through to
        # scenes intentionally.
        if event.key == pygame.K_F1:
            DebugOverlay.toggle()

    def _handle_joybuttondown(self, event) -> None:
        """Route one controller button press."""
        # Catch the multi-button quit chord on press for instant response;
        # the outer per-frame check covers held-state quits.
        if self.quit_combo_pressed():
            self.close_game()

        # BACK is the global fullscreen toggle and falls through.
        if event.button == InputSettings.JOY_BUTTON_BACK:
            self.toggle_fullscreen()

    def _handle_joyhatmotion(self, event) -> None:
        """Route a D-pad direction event."""
        pass

    def _handle_joyaxismotion(self, event) -> None:
        """Route a joystick or trigger motion event."""
        pass

    def _process_events(self) -> None:
        """Drain pygame's event queue and dispatch by event type.

        Global handlers (quit, fullscreen) run first; the same event is
        then forwarded to the active scene so it can react.
        """
        for event in pygame.event.get():
            # Pads arrive as Xbox-numbered joystick events (ui/gamepads.py).
            event = self.gamepads.translate(event)
            if event is None:
                continue
            if event.type == pygame.QUIT:
                self.ask_to_quit(closing_window=True)
                continue
            if event.type == pygame.KEYDOWN:
                self._handle_keydown(event)
            elif event.type == pygame.JOYBUTTONDOWN:
                self._handle_joybuttondown(event)
            elif event.type == pygame.JOYHATMOTION:
                self._handle_joyhatmotion(event)
            elif event.type == pygame.JOYAXISMOTION:
                self._handle_joyaxismotion(event)
            self.scene_stack.handle_event(event)

    # -------------------------
    # MAIN LOOP
    # -------------------------

    def _update_world(self, dt: float) -> None:
        """Advance the active scene by ``dt`` seconds."""
        self.scene_stack.update(dt)

    def _render_frame(self) -> None:
        """Compose one frame: clear, draw scenes, enlarge, apply CRT pass."""
        self.screen.fill(ColorSettings.BG_COLOR)
        self.scene_stack.render_all(self.screen)
        self._present()

    def _present(self) -> None:
        """Enlarge the 256 by 224 screen onto the window by whole pixels."""
        width, height = ScreenSettings.RESOLUTION
        enlarged = pygame.transform.scale(
            self.screen, (width * self.scale, height * self.scale)
        )
        if self.origin != (0, 0):
            self.window.fill(ColorSettings.BLACK)
        self.window.blit(enlarged, self.origin)

        # Apply CRT pass after world/UI rendering.
        if not self.full_screen and self.crt is not None:
            self.crt.draw()

    async def run(self):
        """Run the main game loop until the player quits.

        The loop hands control back once a frame (``asyncio.sleep(0)``)
        so the same code runs in a browser, built by pygbag
        (``tools/web_build.py``); on the desktop the pause costs nothing.
        """
        while True:
            if self.quit_combo_pressed():
                self.close_game()
            dt = self.clock.tick(ScreenSettings.FPS) / 1000.0
            self._process_events()
            self._update_world(dt)
            self.audio.update()
            self._render_frame()
            pygame.display.flip()
            await asyncio.sleep(0)


if __name__ == "__main__":
    game_manager = GameManager()
    asyncio.run(game_manager.run())
