from __future__ import annotations

import asyncio
import os

import pygame
import sys

import emulator
import viewport
from crt import CRT
from core import lore, save, skip_cutscene
from core.data_loader import DataLoader
from core.scene import SceneStack
from core.scenes.title_scene import TitleScene
from settings import AudioSettings, ColorSettings, InputSettings, ScreenSettings
from systems.audio_manager import AudioManager
from systems import config, records
from systems.party import Party
from ui.gamepads import Gamepads
from ui import input_map, text_renderer, touch_pad
from ui.layout import DebugOverlay
from ui.text_box import TextBox


class GameManager:
    """Coordinate game state, flow, rendering phases, and input orchestration."""

    def __init__(self, start_fullscreen: bool = False):
        """Initialize pygame, the display, the input cache, and post-processing.

        Args:
            start_fullscreen: Whether to launch directly in fullscreen mode.
        """

        if ScreenSettings.WEB:
            # In a browser the sound shares a thread with the game, and on a
            # phone a slow frame let pygame's small buffer run dry: crackling.
            # Four times the buffer, about 46 ms, rides out a slow frame.
            pygame.mixer.pre_init(buffer=2048)
        pygame.init()
        self._initialize_audio_mixer()
        # The game draws on ``screen``, a 256 by 224 surface (D-158).
        # ``_present`` enlarges it by ``scale``, a whole number, onto the
        # window, so every game pixel is the same square of window
        # pixels and nothing is smoothed. The CRT pass covers only the
        # enlarged picture, in the window and in fullscreen alike.
        self.full_screen = start_fullscreen
        # Paused (D-575): nothing moves or reacts but the pause press itself.
        self.paused = False
        # Started from the Workshop (``--no-fights``): monsters never start a fight.
        self.no_fights = False
        # The desktop game's emulator tools (emulator.py, Frankie 10/23): the
        # F1 file menu freezes the game while it is open, ~ held fast-forwards,
        # and a short note ("State saved") shows until ``note_until``.
        self.file_menu: emulator.FileMenu | None = None
        self.fast_forward = False
        self.note = ""
        self.note_until = 0
        self.scale = 1
        self.origin = (0, 0)
        # Where the picture sits in the window, and the whole-number step
        # of the sharp bilinear enlarge (viewport.py).
        self.view = pygame.Rect(0, 0, 1, 1)
        self.stage = None
        self.stage_for = None
        self.window: pygame.Surface = pygame.display.set_mode((1, 1))
        self.crt: CRT | None = None
        self._open_window()
        pygame.display.set_caption(ScreenSettings.WINDOW_TITLE)
        # The window's icon: the website's nautilus (Frankie, 10/18). The
        # taskbar shortcut uses the same picture (tools/make_shortcut.py).
        icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "assets", "graphics", "app_icon.png")
        if os.path.exists(icon_path):
            pygame.display.set_icon(pygame.image.load(icon_path))
        self.screen = pygame.Surface(ScreenSettings.RESOLUTION)
        self.clock = pygame.time.Clock()

        self.setup_controllers()

        # Audio is data-driven; see settings.AudioSettings for the registry.
        self.audio = AudioManager()
        # Config's settings last set (Frankie, 10/26), the title's until a save is loaded.
        config.boot(self)

        # Content packs (characters, abilities, enemies, dungeons,
        # dialogue) are read from ``data/`` on demand and cached. Scenes
        # reach into this loader rather than re-reading JSON themselves.
        self.data = DataLoader()

        # Active gameplay state. ``party`` is overwritten by the title
        # screen when the player picks NEW GAME or CONTINUE; until then it
        # is an empty roster so save/load code can rely on it being
        # non-None.
        self.party: Party = Party()
        # A Words page appears once its word is said in any text box (Frankie, 10/26).
        TextBox.on_line = lambda line: lore.hear(self.party, line)
        self.scene_stack = SceneStack(self)
        self.scene_stack.push(TitleScene(self))

    def _initialize_audio_mixer(self) -> None:
        """Initialize pygame's mixer once so AudioManager has a backing device."""
        if pygame.mixer.get_init():
            return
        try:
            pygame.mixer.init()
        except pygame.error as error:
            # Mixer failures are non-fatal; the game keeps running silently.
            # Logged via stderr so it never lands in gameplay output.
            sys.stderr.write(f"Audio mixer initialization failed: {error}\n")

    # -------------------------
    # BOOT / SETUP
    # -------------------------

    def _open_window(self) -> None:
        """Open the window, or the whole screen, at a whole-number scale.

        Windowed, the scale is the largest that leaves room for the
        title bar and the taskbar. Fullscreen, it is the largest that
        fits the desktop, and the game sits centred in black bars.
        """
        width, height = ScreenSettings.RESOLUTION
        if ScreenSettings.WEB:
            # In a browser the page scales the canvas to fit; draw it at 3x.
            self.scale = ScreenSettings.WEB_SCALE
            self.window = pygame.display.set_mode((width * self.scale, height * self.scale))
            self.origin = (0, 0)
            # Off on a phone (Frankie, 10/24): the page stretches the picture
            # by a fraction there, and the scan lines become uneven stripes.
            self.view = pygame.Rect(0, 0, width * self.scale, height * self.scale)
            self.stage = None
            self.stage_for = None
            self.crt = None if touch_pad.on_touch_screen() else CRT(self.window, self.view)
            return
        desktop_w, desktop_h = pygame.display.get_desktop_sizes()[0]
        if self.full_screen:
            self.scale = viewport.whole_factor(*viewport.tv_size(desktop_w, desktop_h))
            self.window = pygame.display.set_mode(
                (desktop_w, desktop_h), pygame.FULLSCREEN
            )
        else:
            self.scale = max(1, min(
                (desktop_w - ScreenSettings.WINDOW_MARGIN_W) // width,
                (desktop_h - ScreenSettings.WINDOW_MARGIN_H) // height,
            ))
            self.window = pygame.display.set_mode(
                (width * self.scale, height * self.scale)
            )
            # The window starts 1 by 1 and grows from its top left
            # corner, so it would spill off the bottom right: centre it.
            # pygame-ce has pygame.Window; plain pygame 2.6 keeps it in
            # _sdl2.video, and a build with neither just leaves it be.
            window_type = getattr(pygame, "Window", None)
            centred = getattr(pygame, "WINDOWPOS_CENTERED", None)
            if window_type is None:
                try:
                    from pygame._sdl2.video import WINDOWPOS_CENTERED as centred
                    from pygame._sdl2.video import Window as window_type
                except ImportError:
                    window_type = None
            if window_type is not None and centred is not None:
                window_type.from_display_module().position = centred
        window_w, window_h = self.window.get_size()
        if self.full_screen:
            self.view = viewport.view_rect(window_w, window_h)
        else:
            self.view = pygame.Rect(0, 0, width * self.scale, height * self.scale)
            self.view.center = (window_w // 2, window_h // 2)
        self.origin = self.view.topleft
        self.stage = None
        self.stage_for = None
        self.crt = CRT(self.window, self.view)

    def toggle_fullscreen(self) -> None:
        """Switch between the window and the whole screen."""
        self.full_screen = not self.full_screen
        self._open_window()

    def setup_controllers(self) -> None:
        """Open every connected pad; ``Gamepads`` keeps the list current as pads come and go."""
        self.gamepads = Gamepads()

    @property
    def connected_joysticks(self) -> list:
        """Return the connected pads, each answering like an Xbox-numbered joystick."""
        return self.gamepads.devices

    def soft_reset(self) -> None:
        """L1 R1 START SELECT: back to the title as if the console had just
        been switched on, at once and with no question (Frankie, 10/23).

        Every scene, the party and its flags, the pause and the sound go;
        only the window, the mute and the saves on disk stay.
        """
        self.scene_stack.clear()
        self.party = Party()
        self.paused = False
        self.file_menu = None
        if pygame.mixer.get_init():
            pygame.mixer.stop()
            self.audio.stop_music()
        self.audio.screen = None
        self.scene_stack.push(TitleScene(self))

    def close_game(self) -> None:
        """Close the game process cleanly."""
        pygame.quit()
        sys.exit()

    def return_to_title(self) -> None:
        """Throw away the whole stack and go back to the title screen.

        Only the demo's last line does this; the player cannot quit to
        the title, as on a Super Nintendo (Frankie, 10/23).
        """
        self.scene_stack.clear()
        self.scene_stack.push(TitleScene(self))

    def toggle_pause(self) -> None:
        """Freeze or unfreeze the game, sound included (D-575)."""
        self.paused = not self.paused
        self._freeze_sound()

    @property
    def frozen(self) -> bool:
        """Nothing moves: the game is paused or the F1 file menu is open."""
        return self.paused or self.file_menu is not None

    def _freeze_sound(self) -> None:
        """Pause the sound while the game is frozen, and let it go after."""
        if not pygame.mixer.get_init():
            return
        if self.frozen:
            pygame.mixer.music.pause()
            pygame.mixer.pause()
        else:
            pygame.mixer.music.unpause()
            pygame.mixer.unpause()

    # -------------------------
    # EMULATOR TOOLS (desktop only)
    # -------------------------

    @property
    def emulator_keys(self) -> bool:
        """The keyboard's emulator hotkeys work in the desktop game only (Frankie, 10/23)."""
        return not ScreenSettings.WEB

    def open_file_menu(self) -> None:
        """F1: freeze the game and open the emulator's file menu."""
        self.file_menu = emulator.FileMenu()
        self._freeze_sound()

    def close_file_menu(self) -> None:
        """Close the file menu; the game runs on unless it is paused."""
        self.file_menu = None
        self._freeze_sound()

    def show_note(self, text: str) -> None:
        """Show a short note in the corner for a moment."""
        self.note = text
        self.note_until = pygame.time.get_ticks() + int(emulator.NOTE_SECONDS * 1000)

    def save_state(self) -> None:
        """F2: save the whole running game in the one state."""
        self.show_note(emulator.save_state(self))

    def load_state(self) -> None:
        """F4: put the game back as the state left it."""
        self.show_note(emulator.load_state(self))

    def save_checkpoint(self) -> None:
        """F6: keep the story so far as a checkpoint, named for the room (core/save.py)."""
        from core.scenes.overworld_scene import OverworldScene
        from core.scenes.save_slot_scene import snapshot

        field = self.scene_stack.find(OverworldScene)
        if field is None:
            self.show_note("No checkpoint here")
            return
        name = save.free_checkpoint_name(field.world.current_cell_name)
        save.save_checkpoint(name, {**snapshot(self), "note": "Made with F6 in the game."})
        self.show_note(f"Checkpoint {name}")

    def choose_file_item(self, item: str) -> None:
        """Do what the file menu's item says, and close the menu."""
        self.close_file_menu()
        if item == "Reset":
            self.soft_reset()
        elif item == "Save State":
            self.save_state()
        elif item == "Load State":
            self.load_state()

    def _screen_point(self, pos: tuple[int, int]) -> tuple[int, int]:
        """A window point as a point on the 256 by 224 game screen."""
        return viewport.to_game(pos, self.view)

    def _handle_file_menu_event(self, event) -> None:
        """While the file menu is open it hears the keyboard and the mouse, nothing else."""
        menu = self.file_menu
        chosen = None
        if event.type == pygame.KEYDOWN:
            chosen = menu.handle_key(event.key)
        elif event.type == pygame.MOUSEMOTION:
            hovered = menu.item_at(self._screen_point(event.pos))
            if hovered is not None:
                menu.cursor = hovered
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            point = self._screen_point(event.pos)
            hovered = menu.item_at(point)
            if hovered is not None:
                chosen = menu.ITEMS[hovered]
            elif not menu.frame().collidepoint(point):
                # A click outside the menu closes it, as an emulator's does.
                chosen = "Resume"
        if chosen is not None:
            self.choose_file_item(chosen)

    def _handle_emulator_key(self, event) -> bool:
        """F1, F2, F4, F6 and ~; return True if the key is used up here."""
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_BACKQUOTE:
                self.fast_forward = False
            return False
        if event.key == pygame.K_F1:
            self.open_file_menu()
        elif event.key == pygame.K_F2:
            self.save_state()
        elif event.key == pygame.K_F4:
            self.load_state()
        elif event.key == pygame.K_F6:
            self.save_checkpoint()
        elif event.key == pygame.K_BACKQUOTE:
            self.fast_forward = True
        else:
            return False
        return True

    def reset_combo_pressed(self) -> bool:
        """Return True if START + SELECT + L1 + R1 are held on any controller."""
        required_buttons = InputSettings.JOY_BUTTON_RESET_COMBO
        for joystick in self.connected_joysticks:
            if all(joystick.get_button(button) for button in required_buttons):
                return True
        return False
    
    # -------------------------
    # INPUT HANDLING
    # -------------------------

    def _handle_keydown(self, event) -> None:
        """Route one keyboard press to the appropriate UI/gameplay handler."""
        # Esc does nothing: no quitting from inside the game, as on a
        # Super Nintendo (Frankie, 10/23).

        # F11 fullscreen toggle is global and intentionally falls through so
        # other handlers still see the press.
        if event.key == pygame.K_F11:
            self.toggle_fullscreen()

        # F3 toggles the UI debug overlay (see ui/layout.py). Off by
        # default; when on, every scene that registers debug rects /
        # points will outline them with labels so you can SEE the
        # layout coordinates instead of guessing. Falls through to
        # scenes intentionally. (F1 is the emulator's file menu.)
        if event.key == pygame.K_F3:
            DebugOverlay.toggle()

        # M mutes and unmutes all sound, anywhere (Frankie, 10/19: he plays at school).
        if event.key == pygame.K_m:
            self.audio.toggle_mute()

    def _handle_joybuttondown(self, event) -> bool:
        """Route one controller button press; return True if it is used up here."""
        # L1 R1 START SELECT held together resets to the title at once,
        # no question, in every build (Frankie, 10/23).
        if self.reset_combo_pressed():
            self.soft_reset()
            return True
        # A chord button pressed while another is held is on its way to
        # the chord, so START does not pause. SELECT alone does nothing:
        # only F11 resizes, the pad does what a Super Nintendo can (Frankie, 10/23).
        chord = InputSettings.JOY_BUTTON_RESET_COMBO
        if event.button in chord and any(
            joystick.get_button(button)
            for joystick in self.connected_joysticks
            for button in chord if button != event.button
        ):
            return True
        return False

    def _handle_joyhatmotion(self, event) -> None:
        """Route a D-pad direction event."""
        pass

    def _handle_joyaxismotion(self, event) -> None:
        """Route a joystick or trigger motion event."""
        pass

    def _process_events(self) -> None:
        """Drain pygame's event queue and dispatch by event type.

        Global handlers (quit, fullscreen) run first; the same event is
        then forwarded to the active scene so it can react.
        """
        # The website's on-screen pad comes first, read from the page (ui/touch_pad.py).
        for event in [*self.gamepads.poll(), *pygame.event.get()]:
            # Pads arrive as Xbox-numbered joystick events (ui/gamepads.py).
            event = self.gamepads.translate(event)
            if event is None:
                continue
            # The window's own close button closes at once (Frankie, 10/23).
            if event.type == pygame.QUIT:
                self.close_game()
                continue
            # The emulator's own keys come before the game's (desktop only).
            if self.emulator_keys:
                if self.file_menu is not None:
                    self._handle_file_menu_event(event)
                    continue
                if event.type in (pygame.KEYDOWN, pygame.KEYUP) and self._handle_emulator_key(event):
                    continue
            if event.type == pygame.KEYDOWN:
                self._handle_keydown(event)
            elif event.type == pygame.JOYBUTTONDOWN:
                if self._handle_joybuttondown(event):
                    continue
            elif event.type == pygame.JOYHATMOTION:
                self._handle_joyhatmotion(event)
            elif event.type == pygame.JOYAXISMOTION:
                self._handle_joyaxismotion(event)
            # START or P pauses anywhere; while paused the scenes hear nothing. In a
            # cutscene it asks to skip it instead (Frankie, 10/28).
            if input_map.is_pause(event):
                if not self.paused and skip_cutscene.available(self) is not None:
                    skip_cutscene.ask(self)
                else:
                    self.toggle_pause()
                continue
            if self.paused:
                continue
            self.scene_stack.handle_event(event)

    # -------------------------
    # MAIN LOOP
    # -------------------------

    def _update_world(self, dt: float) -> None:
        """Advance the active scene by ``dt`` seconds, and count the time played while a game is on."""
        from core.scenes.overworld_scene import OverworldScene  # local: cycle.

        if self.scene_stack.find(OverworldScene) is not None:
            records.add_time(self.party, dt)
        self.scene_stack.update(dt)

    def _advance(self, dt: float) -> None:
        """One frame of the world and its music, unless the game is frozen.

        With ~ held the world runs several steps in the frame, text and
        walking included (desktop only, Frankie 10/23).
        """
        if self.frozen:
            return
        steps = emulator.FAST_FORWARD if self.fast_forward else 1
        for _ in range(steps):
            self._update_world(dt)
            self.audio.update()

    def _render_frame(self) -> None:
        """Compose one frame: clear, draw scenes, enlarge, apply CRT pass."""
        self.screen.fill(ColorSettings.BG_COLOR)
        self.scene_stack.render_all(self.screen)
        if AudioSettings.MUTE:
            self._draw_mute_mark()
        if self.paused:
            self._draw_pause_mark()
        if self.file_menu is not None:
            self.file_menu.render(self.screen)
        if self.note and pygame.time.get_ticks() < self.note_until:
            emulator.draw_note(self.screen, self.note)
        elif self.fast_forward and not self.frozen:
            emulator.draw_note(self.screen, ">>")
        self._present()

    def _draw_pause_mark(self) -> None:
        """Dim the frozen screen and write PAUSED in the middle (D-575)."""
        shade = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 140))
        self.screen.blit(shade, (0, 0))
        letters = text_renderer.render_line("Paused", ColorSettings.WHITE)
        x = (self.screen.get_width() - text_renderer.text_width("Paused")) // 2
        y = (self.screen.get_height() - 8) // 2 - text_renderer.ink_top()
        self.screen.blit(letters, (x, y))

    def _draw_mute_mark(self) -> None:
        """Write MUTE in green in the top right corner while the sound is off (M)."""
        letters = text_renderer.render_line("Mute", ColorSettings.MUTE_MARK)
        width = text_renderer.text_width("Mute")
        x = self.screen.get_width() - width - 2
        top = text_renderer.ink_top()
        pygame.draw.rect(self.screen, ColorSettings.BLACK, (x - 1, 1, width + 2, 10))
        self.screen.blit(letters, (x, 2 - top))

    def _present(self) -> None:
        """Enlarge the 256 by 224 screen onto the window: by whole pixels in
        the window, sharp bilinear at the 4:3 TV shape in fullscreen."""
        if self.stage_for is None:
            self.stage = viewport.make_stage(self.view, self.screen)
            self.stage_for = True
        if self.origin != (0, 0):
            self.window.fill(ColorSettings.BLACK)
        viewport.enlarge(self.screen, self.view, self.window, self.stage)

        # Apply CRT pass after world/UI rendering.
        if self.crt is not None:
            self.crt.draw()

    async def run(self):
        """Run the main game loop until the player quits.

        The loop hands control back once a frame (``asyncio.sleep(0)``)
        so the same code runs in a browser, built by pygbag
        (``tools/web_build.py``); on the desktop the pause costs nothing.
        """
        while True:
            dt = self.clock.tick(ScreenSettings.FPS) / 1000.0
            self._process_events()
            self._advance(dt)
            self._render_frame()
            pygame.display.flip()
            await asyncio.sleep(0)


def parse_args(argv: list[str]):
    """The command line: the Workshop's Play button starts the game in a room.

        python main.py --room beach_west --col 5 --row 6 --no-fights
        python main.py --checkpoint night --room chief_house

    A checkpoint is the story up to some moment (core/save.py); with
    ``--room`` too, the party walks into that room with the story as it was.
    """
    import argparse

    parser = argparse.ArgumentParser(description="Nuitai RPG")
    parser.add_argument("--room", help="skip the title and start in this room")
    parser.add_argument("--col", type=int, help="the tile to stand on, with --row")
    parser.add_argument("--row", type=int)
    parser.add_argument("--checkpoint", help="start from this checkpoint's story")
    parser.add_argument("--no-fights", action="store_true",
                        help="monsters walk the map but never start a fight")
    # Unknown arguments are let through: the browser build may pass its own.
    args, _unknown = parser.parse_known_args(argv)
    return args


# The game's own taskbar identity on Windows, the same ID that
# tools/make_shortcut.py stamps on the shortcut. Without it the window is
# grouped with Python itself, and a pin of it opens IDLE (Frankie, 10/28).
APP_ID = "Nuitai.Game"


def claim_taskbar_identity() -> None:
    """Tell Windows this window is Nuitai, not python.exe."""
    if sys.platform != "win32":
        return
    try:
        import ctypes

        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except (AttributeError, OSError):
        pass


if __name__ == "__main__":
    args = parse_args(sys.argv[1:])
    claim_taskbar_identity()
    game_manager = GameManager()
    game_manager.no_fights = args.no_fights
    if args.checkpoint or args.room:
        from core.scenes.overworld_scene import start_in_room

        if not start_in_room(game_manager, args.room, args.col, args.row, args.checkpoint):
            sys.stderr.write(f"No room {args.room!r} or checkpoint {args.checkpoint!r}; starting at the title.\n")
    try:
        asyncio.run(game_manager.run())
    except SystemExit:
        raise
    except BaseException:
        # A crash leaves its story behind (10/23: the window closed at the pot
        # with nothing to show why). Newest first; Claude reads it.
        import datetime
        import traceback

        log = os.path.join(os.path.dirname(os.path.abspath(__file__)), "crash.log")
        with open(log, "a", encoding="utf-8") as f:
            f.write(f"--- {datetime.datetime.now():%Y-%m-%d %H:%M}\n{traceback.format_exc()}\n")
        raise
