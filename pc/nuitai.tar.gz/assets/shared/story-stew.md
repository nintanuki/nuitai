# Kohuapua

Kailo brings Noelani everything the stew needs, and the two of them make it at the pot in his
house (Frankie, 10/30). Kailo is the cook and leads; Noelani helps and does not teach him
(Frankie, 10/30). At its end Kailo is given the stew as a key item, **Kohuapua**. Every line
here is Claude's draft (10/30), for Frankie to rewrite, in Noelani's dry, teasing younger-cousin voice (a peer, never a parent; Frankie, 11/2) and
Kailo's terse one. The pygame game plays it. How to write a script is at the top of `story.md`.

The stage is Kailo's house: the pot is at 7,7, the fire is two tiles square at 7,9 (7 to 8, 9 to 10), the table two square at 10,7 (10 to 11, 7 to 8), the jar at 11,9. Kailo works at 7,8 between the pot and the fire; Noelani keeps to the east side, at the jar, the table and the fire's far edge, so neither walks through furniture or onto the other. Kailo starts the scene from the tile north of her, 9,9, whichever side he talked from. The stage directions are Claude's (11/2). Noelani is on the stage as `Cousin`, her walk sheet.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Noelani**: hidden while the scene plays, as the room's own
- **Cousin**: Noelani's walk sheet, `Cousin-Walk.png`, on the stage

## Scene

**Room:** kailo_house
**Stand:** Cousin at 9,10 facing up; Kailo at 9,9 facing down

**Noelani:** Not on the floor, Kailo! The boars already ruined one stew.

**Walk:** Kailo to 9,8 to 7,8
**Turn:** Kailo up

**Kailo:** Pot. Fire.

**Turn:** Kailo down
**Walk:** Cousin to 10,10 to 10,9
**Turn:** Cousin right

**Noelani:** Fire's already going. You're slow today.

**Turn:** Kailo up

**Kailo:** Pork and niu first.

**Walk:** Cousin to 9,9 to 9,8
**Turn:** Cousin right
**Wait:** 1

**Noelani:** Chopped. Don't look at me like that, I'm helping.

**Turn:** Cousin to Kailo

**Kailo:** Eggs. Fish. 'Awapuhi, shoyu.

**Noelani:** Look at you, so gentle with an egg. Pity the boars weren't.

**Turn:** Kailo down

**Kailo:** 'Uala. Cover it. Let it braise.

**Noelani:** I'll mind the fire. You stand there and look important.

**Walk:** Cousin to 9,9
**Turn:** Cousin left
**Turn:** Kailo up
**Wait:** 1
**Fade:** out
**Wait:** 2
**Stand:** Kailo at 7,8 facing up; Cousin at 9,9 facing left
**Fade:** in

**Kailo:** Green onion last.

**Noelani:** Pono used to sneak a taste right about now. Every time.

**Turn:** Kailo to Cousin
**Turn:** Cousin to Kailo

**Kailo:** ...He thought I didn't see.

**Noelani:** He saw you seeing. Go on, taste.

**Turn:** Kailo up

**Kailo:** ...Good. He'd have had three bowls.

**Noelani:** Then take it to him. And keep it away from the boars.

**End:** Kailo has the stew.
