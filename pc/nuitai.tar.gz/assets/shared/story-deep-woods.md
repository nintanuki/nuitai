# The deep woods

West out of the log yard the painted map ends and the generated woods begin (Frankie, 10/25); the
temple clearing's north and the lodge square's west lead in too (Frankie, 11/12). The
first time Kailo steps onto any of those edges with Hina or Maika along, they stop him: past here is the deep
forest, Lanu's beasts there are stronger, it is easy to get lost in, and the Great Boar is not in there
(any way in, 11/12; it said north when there was one way in). With Maika along he says it, Hina or not; with Hina alone she does. Each version plays once, and either one unlocks the
Lanu page under Lore. Nobody walks: the lines play where everyone stands, and then Kailo can go on
or turn back.

The games play it. How to write a script is at the top of
`story.md`. Every line here is Claude's draft, for Frankie to rewrite (10/25).

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png

## Hina warns

**Hina:** Kailo, wait! That's the deep forest. Lanu's beasts live in there, and they're much stronger than anything out here. And it's easy to get lost.

**Hina:** Besides, the Great Boar isn't in there.

**Kailo:** ...right.

**End:** Back to the field.

## Hina warns, Maika missing

Her warning at any way in while Maika is missing (his sister's deal made, not found yet): the second line and
Kailo's answer change (Frankie, 11/12; Claude's draft). It counts as her warning, once.

**Hina:** Kailo, wait! That's the deep forest. Lanu's beasts live in there, and they're much stronger than anything out here. And it's easy to get lost.

**Hina:** Besides, the Great Boar isn't in there. Maika might be, though. That sounds like him.

**Kailo:** ...right. Let's find him.

**End:** Back to the field.

## Maika warns

**Maika:** I wouldn't. That's the deep forest. Lanu's beasts roam there, and they don't welcome visitors. Lose the path in there and you may never find it again.

**Maika:** And the Great Boar isn't in there. Lost again, Kailo?

**End:** Back to the field.
