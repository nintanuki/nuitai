# Field lines

The words said on the field, outside the story scenes: Noelani and the stew, the garden, the
hens, digging, fishing, the shops and the rest. They were in the game's settings; since 10/31
they are here, with the scenes, so every line of dialogue is in one place (Frankie). The Workshop's
lines window (L) edits them like a scene.

How to write it:

- `- OFFER_LINES` is the name the game reads the lines under it by. Keep the names as they are.
- A name ending in LINES can have several lines, said in order. Any other name has exactly one.
- `- EDGE_LINES harbor` is one line for one place or one person.
- `**Noelani:** line` shows who says it. Who says a field line is decided by the game, so changing
  the name here does not change the speaker. A line with no name is narration, or said by
  whoever is being talked to (the meal orders, the shop's greeting).
- Words in curly brackets, like `{things}`, are filled in by the game. Keep them.

## The opening cards

- BLURB_LINES
In a world covered by endless water, people live on scattered islands, venturing across the ocean at their own peril.
Colossal sea monsters lurk beneath the surface, unpredictable storms swallow ships, and miracles and oddities are daily routine.
It is a world as beautiful as it is deadly...
Far to the northeast lies a small, verdant island, untouched by the troubles of the wider world. Here live a warmhearted young cook and a headstrong, devout priestess...

## Chopping and picking

- WOOD_LINE
Got {count} {item}.

- FRUIT_LINE
A {item} fell from the tree.

- ROOT_LINE
Found {item} under the tree.

- VILLAGE_CHOP_LINE
Hey! Don't chop down the village trees!

- BANYAN_HISTORY_LINES
**Kailo:** A banyan. Hina says these aren't even from here.
**Hina:** The missionaries planted the first banyan here. Now everyone thinks they've always been here.

## The shops

- BUY_LINE
Aloha! Help yourself!

- SELL_LINE
What'll you sell?

- SOY_HINT_LINES
**Kailo:** Six thousand pule?! I don't have that. Nobody does.
**Kailo:** I'll have to find soy sauce some other way.

## The village

- WATCH_LINES
By watching the villagers spar, Kailo learned a few tricks.
Kailo's strength and agility went up.

- NAP_LINE
The party recovered HP.

- POND_LINE
The party drinks from the cool pond. Everyone is rested.

- PRAY_LINE
The party kneels at the totem and tells the Akua all that has happened.

- REVIVE_LINE
The fallen are back on their feet.

- EDGE_LINES harbor
The rocks are too sharp to climb, and the tide's coming in. Better turn back.

## The hens

- EGG_LINE
Found an Egg.

- NO_EGG_LINE
The hen clucks. No egg yet.

## Fishing

- CAUGHT_LINE
Caught a {fish}.

- MISS_LINE
It got away.

- NIBBLE_LINE
Nothing's biting.

- NORI_LINE
Hooked some Nori.

- PULE_LINE
Reeled in {pule} pule.

- REEL_HINT
Roll the D-pad to reel it in!

- ESCAPED_LINE
It got off the hook.

- RARE_LINE
Kailo hooked something: {item}!

## Digging

- FOUND_LINE
Found {item}

- NOTHING_LINE
Nothing but dirt.

- AGAIN_LINE
Already dug here.

- VILLAGE_LINE
Hey! Don't dig up the village!

- GRASS_LINE
The roots are too thick. Sand digs easier.

## Noelani and the stew

- OFFER_LINES
**Noelani:** I heard what happened. The boars, the pot, all of it. I'll help you cook it. Don't make that face.
**Noelani:** So what goes in?

- LIST_LINE
**Kailo:** We need {things}.

- SEND_LINES
**Noelani:** That's a lot. You fetch, I'll clean up this mess and get the fire going. Deal?

- MISSING_LINE
**Noelani:** Still missing: {things}.

- GIVE_ASK
**Noelani:** Want to hand me what you've got so far? I'll keep it with the rest.

- GIVE_BOX
Give her what you have so far?

- GAVE_LINE
**Noelani:** Got it. Still missing: {things}.

- AFTER_LINE
**Noelani:** Kohuapua's done. Drop it on the way and I'm telling the whole village.

- DUSK_LINE
The sun is going down. Time for Old Pono's wake.

- HINTS fish
**Noelani:** fish of any kind from the harbor, with Ama's rod

- HINTS pork
**Noelani:** pork from a wild boar

- HINTS egg
**Noelani:** an egg from the hens, or from a bird

- HINTS niu
**Noelani:** coconut, from a palm with coconuts on it

- HINTS uala
**Noelani:** 'uala, grown from seed with Hina

- HINTS akai_lau
**Noelani:** akai lau, grown from seed with Hina

- HINTS awapuhi
**Noelani:** 'awapuhi, wild ginger, dug up with the 'O'o, the digging stick

- HINTS soy_sauce
**Noelani:** shoyu, from Maika's sister

## Noelani and the pule

Noelani keeps pule for Kailo. From her second talk on she says one of her own lines (the house
lines in `kailo_house`), then what is here, and a menu opens. Claude's drafts (11/2) for Frankie to rewrite.

The wallet lines at the end (WALLET_*, Frankie's 11/12 decision that Noelani sells the first wallet) are Claude's drafts, for Frankie to rewrite.

- BANK_LEAD_LINE
**Noelani:** And look at that wallet of yours, it's stuffed. Leave me what you don't need and I'll keep it in the jar. I won't even spend it. Much.

- BANK_WHAT_LINE
**Noelani:** What is it, Kailo? I'm elbow deep in something.

- INGREDIENTS_CHOICE
How many ingredients do I have?

- STEW_READY_CHOICE
Ok, I have everything we need.

- STEW_CHOICE
About the stew

- PULE_FIRST_CHOICE
Can you hold some pule for me?

- PULE_CHOICE
About the pule you're holding for me

- NEVER_CHOICE
Never mind

- NEVER_LINE
**Noelani:** Mm-hm. You know where I am.

- BANK_ASK
**Noelani:** I'm holding {held} for you. Want to leave some, or take some back?

- BANK_CHOICES_LINES
Leave pule
Take pule
Never mind

- LEAVE_ASK
How much?

- LEAVE_CHOICES_LINES
10
100
All of it
Never mind

- TAKE_ASK
How much?

- TAKE_CHOICES_LINES
10
100
All you can carry
Never mind

- LEFT
**Noelani:** I'll keep it safe. That's {held} pule with me.

- TOOK
**Noelani:** Here. That leaves {held} pule with me.

- NONE_LEFT
**Noelani:** You've got nothing on you to leave, Kailo.

- NONE_HELD
**Noelani:** I'm not holding anything for you.

- FULL
**Noelani:** Your pouch is already full.

- WALLET_CHOICE
A bigger wallet

- WALLET_OFFER
**Noelani:** I can sell you a {name}. It holds {holds} pule. That's {price} pule, out of what you're carrying.

- WALLET_BOX
Buy the {name} for {price} pule?

- WALLET_SHORT
**Noelani:** You're not carrying {price} pule. Come back when you are.

- WALLET_SOLD
**Noelani:** There. Now you can carry more than a pocketful.

- WALLET_COMPLAINT
**Kailo:** Paying you, in my own house, with my own pule. This is robbery.

## Nori

- FOUND_LINE
Found some Nori.

- NOTHING_LINE
Just foam and sand.

## The garden

- ABILITY_DONE_LINE
Maika does the Maki Hula.

- GROWING_LINE
It is still growing.

- NEEDS_HINA_LINE
This soil can be replanted, but you're bad at gardening.

- NO_SEED_LINE
You need a {item} or a {crop} to plant it.

- ABILITY_LINE
It will grow faster now.

- NO_FARM_SEED_LINE
You need a seed or a crop to plant here.

- WAIT_LINE
**Hina:** It takes a while to grow. Let's go do something else instead of standing here waiting.

- HINA_OFFER_LINE
**Hina:** Don't leave it bare. It should be replanted. I'll show you how.

- MAIKA_OFFER_LINE
**Maika:** Let a wise man dance. My nature magic will make it grow faster.

## Cooking and crafting

- FIND_LINES
Put two together
to find a new recipe.

- FIND_THREE_LINES
Put up to three in
to find a new recipe.

- WITH_LINE
Put {item} with what?

- COOK_ROW
Cook

- ADD_LINE
Add more, or pick Cook.

- PUT_BACK_LINE
Press B to put it back.

- MADE_LINE
Made {item}.

- NEW_RECIPE_LINE
A new recipe!

- NO_MIX_LINES
Those don't go together.
Both are lost.

- DUBIOUS_LINES
Those don't go together.
Kailo made... something.

- ONLY_ONE_LINE
There is only one {item}.

- AWAY_LINE
{crafter} would know about these.

- EMPTY_LINE
Nothing here goes in the pot.

- PICK_LINE
Put two things in the pot.

- NO_MIX_LINE
Those don't go together.

- WATER_LINE
Kailo scoops up some fresh water.

- HEAVY_LINE
**Kailo:** Oof. These canteens are getting heavy.

- REST_LINE
**Kailo:** Let me catch my breath first.

- FULL_LINE
Kailo can't carry any more water.

## Meal orders

- HINT_LINES
I could really go for some {meal} today.
Been thinking about {meal} all morning.
Nothing beats {meal}. ...Not that I have any.
My stomach keeps asking for {meal}.

- ASK_LINE
Is that {meal} on you, Kailo? Could I have it?

- THANKS_LINE
Mahalo! That smells so good.

- GAVE_LINE
Kailo gave away the {meal}.

- ORDERS_ASK
Orders

- PRICES_ASK
Pay {page}/{pages}

- NONE_LINE
No orders at the window.

- MISSING_LINE
No {meal} in the bag.

- SOLD_LINE
Kailo delivered the {meal} to {who} and got {price} pule.

## Joining the party

- JOIN_LINES hina
While she is in your party, the fallen get back up after a win.

- JOIN_LINES maika
While he is in your party, shops charge less.

- JOIN_LINES tawiri
While she is in your party, stats grow faster.

- FIRST_LINES hina
**Hina:** Up, all of you. I'm not carrying anyone home.

- FIRST_LINES kailo
**Kailo:** Eat up. Nobody fights on an empty stomach.

- FIRST_LINES tawiri
**Tawiri:** Hm. You pick things up faster with me around. The last lot I buried never did.

- MAIKA_SHOP_LINES
**Maika:** Leave the prices to me, brother. A friendly face gets a friendly price.

- KAILO_COOK_LINES
**Kailo:** Hm. That smells right. Let's see who eats it first.

## Between the scenes

- WAKE_GIFT_LINE
Kailo received {item}.

- SISTER_SOY_LINE
Kailo got Māla Shoyu!

- JOINED_SHOP_LINE
Still want to buy something, Kailo?

- ASK_LINE
**Hina:** Ready to go to Pono's wake?

- WAKE_JOIN_LINE
Tawiri joined the party. While she is in your party, stats grow faster.

## Landing

- DEMO_END_LINE
This is the end of the demo. The rest of Nuitai is still under construction, but feel free to keep exploring.


## Hina teaches the rows

- LESSON_LINES
**Hina:** See the rows? A move can sit in any of them.
**Hina:** Higher up, it hits or heals harder, but it costs more mana.
**Hina:** Row 2 is twice as strong as row 1.
**Hina:** Put what you use most where you can pay for it. I won't say it twice.

- SLOT_LESSON_LINES
**Hina:** You can change your elements in the middle of a fight, you know.
**Hina:** Choose Equip, then Element. Pick one element, then where it goes.
**Hina:** Swap it with one in the bank, or move it to another row. One change, and that's your turn.

- SLOT_PROMPT
Counter has no open slot. Pick one for it.

## The grove scolds

- SACRED_SCOLD_ALL Hina
**Hina:** Kailo! Not in Lanu's grove. Put that away before she hears you.
**Hina:** Don't you dare. That banyan is older than your grandmother.

- SACRED_SCOLD_ALL Maika
**Maika:** Easy, brother. Nobody cuts in Lanu's grove. Not even the Sages.
**Maika:** Leave the banyan alone. It never did anything to you.

- SACRED_SCOLD_ALL Kailo
**Kailo:** Better not. This is Lanu's grove.
**Kailo:** Not a banyan. Hina would kill me.

## Haggling for soy

- SOY_HAGGLE_LINES
**Maika:** Elder! A wise man like you knows what shoyu is worth. And what a friend is worth.
**Grocer:** Six thousand. It came on a boat.
**Maika:** Six thousand, for the finest stall on the island? A wise man would not insult his own sauce.
**Grocer:** Hmph. Flattery. Three thousand.
**Maika:** Five hundred, and I tell everyone on Māla Iki where to shop.
**Grocer:** Nobody on Māla Iki is coming here. ...Five hundred. And you owe me a good word.
**Maika:** A very good word, elder. Two of them.

## Beds, signs, the inn and the totem

- NAP_BOX
Take a nap?

- INN_ASK
**Innkeeper:** Sleep the night for {price} pule?

- INN_SHORT
**Innkeeper:** That is {price} pule, and you have less. Come back when your pockets are heavier.

- INN_THANKS
**Innkeeper:** Sleep well. The bed on the left is the warmest.

- INN_LINE
You sleep the night through, and wake rested.

- BOAT_ASK
Cook or nap?

- KITCHEN_ASK
What now?

- STERN_ASK
Set sail?

- STERN_NOT_READY
She's not ready to sail yet.

- TOTEM_FIRST_ALL Hina
**Hina:** Kneel, Kailo. Tell the Akua everything that's happened since we last prayed, and they'll remember it for us.
**Hina:** And if anyone's knocked out, the Akua will get them back on their feet.

- TOTEM_FIRST_ALL Kailo
**Kailo:** Every totem on the island listens. Tell the Akua what happened, and they remember it for you.
**Kailo:** And they get anyone who's knocked out back on their feet.

- SAVE_BOX
Save your game?

- NOT_YOUR_BED
**Hina:** Kailo! That's not your bed. If you're tired, go home.

- HINA_BED
**Hina:** Aduh! Wh-what are you doing?! That's my bed! Get away from it!

- NOT_MY_BED
**Kailo:** ...this isn't my bed.

- SIGN_READ_LINES
**Hina:** You can't read it, can you.
**Hina:** It says: "Gone to Pono's wake. Leave your pule in the jar. Stealing is bad."

- SHUT_DOOR
**Kailo:** Nobody's home. Everyone's getting ready for the wake.

- SHUT_DOOR_NIGHT
**Kailo:** Nobody's home. Everyone's at the wake.

- GOT_UP_LINE
{name} got back up.

## Baiting the rod

- BAIT_ON_LINE
Kailo baits the rod.

- BAIT_ALREADY_LINE
The rod is already baited.

- BAIT_NO_ROD_LINE
Kailo has no rod to bait.

## The garden prompts

- SHRUB_PICK_LINE
Picked {count} {item}.

- SHRUB_BARE_LINE
Nothing ripe on it yet.

- REPLANT_BOX
Plant {item}?

- ABILITY_BOX
Do the Maki Hula?

- PLANT_BOX
Plant what?

- LEAVE_CHOICE
Leave it bare

- RAIDED_LINE
The boars tore this one up. Nothing left to pick.

## Cooking

- SICK_LINE
{name} feels sick.

## Meal order prompts

- ASK_BOX
Give {meal}?

- RECEIVED_LINE
Kailo received {item}.

## Around the village

The CLEARING_BANISH_LINES (Hina's Banish hint in the six-Aghoy fight, 11/19) are Claude's draft, for Frankie to rewrite.

- SKIP_ASK
Skip cutscene?

- SISTER_WAITING
**Miki:** Find my brother and tell me where he is. The bottle is yours.

- SISTER_AFTER_LIE
**Miki:** A boat. He always did hate the quiet. I'll catch him at the next island.

- SISTER_AFTER_TRUTH
**Miki:** I'll go and have words with him. Don't wait up.

- CHEST_FOUND
Found {item}.

- CHEST_EMPTY
It's empty.

- KAPA_TALK_LINES
**Trapper:** No kapa for sale. Monsters carry it. Bark cloth, beaten thin.
**Trapper:** Each one has a move drawn on it, step by step. Got a spare? I'll buy it.

- ASK_BOX
Ready to go?

- BOAT_ASK_LINES
**Ama:** Two hundred and fifty koa wood for the hull, boy. Koa and nothing else. Wood won't hold out there.
**Ama:** It grows thick on the lagoon shore. Chop trees and stumps both. Don't know koa? Ask me.
**Ama:** And two thousand pule for the rest. Rope, pitch, sailcloth. None of that grows on trees.

- BOAT_MORE_WOOD
**Ama:** Two hundred and fifty koa wood, boy. You've brought me {have}. The koa's on the lagoon shore.

- BOAT_TAKES_WOOD
**Ama:** Good koa. Your dad would've picked the same trees.

- KOA_CHOICE
What does koa look like?

- BOAT_KOA_LINES
**Ama:** That's koa. Get a good look before you swing at anything.
**Ama:** It grows thick on the lagoon shore. Up the path from the beach, then east over the planks.
**Ama:** Any other tree just gives you wood, and wood won't mend her.

- BOAT_MORE_PULE
**Ama:** Now the two thousand pule. Jobs, hunts, whatever's honest.

- BOAT_PULE_TALK_LINES
**Kailo:** Here. Two thousand.
**Ama:** ...
**Ama:** Put that away. Your dad taught me everything I know, and I never paid him a shell for it.
**Ama:** You'll need every pule for provisions. The sea doesn't feed you, boy. You feed yourself.
**Kailo:** Ama... Mahalo.
**Ama:** Go say your goodbyes. She'll be patched by the time you're done.

- BOAT_MAP_LINES
**Ama:** One more thing before you go. Here, your dad's old sea chart.
**Ama:** I marked Kupulau on it for you. That's the first island, south, with the current at your back.

- BOAT_DONE
**Ama:** She's ready when you are, boy.

- SWAP_TALK_LINES
**Hina:** Aduh. A Sage would be really useful right about now.
**Maika:** This Sage is eating. A wise man never fights on half a plate.
**Hina:** Maika.
**Maika:** Lovely lady, the pork is still warm.
**Hina:** Anyone on the bench can trade places with one of us. That's Swap.
**Hina:** Kailo, you or me?

- CLEARING_CAST_LINES
**Hina:** Aduh! They can bring each other back. We'll be here all day. Go for the ones casting it.

- CLEARING_BANISH_LINES
**Hina:** Aduh, they keep powering themselves up. Banish, my bow's Skill, strips those boosts off whatever it hits.
**Hina:** Let me shoot the one that cast it.

- COUNTER_TALK_LINES
**Kailo:** Hold on. I've been working on something.
**Hina:** Since when?
**Kailo:** Since the last boar knocked me flat. It hits me, I hit back.

- SWAP_GRUMBLE_LINES
**Maika:** Hey! I was still eating.
**Maika:** ...Fine. Somebody save me a plate.

- BOAT_GAVE_WOOD_LINE
Kailo gave Ama {count} {item}.

- COUNTER_LEARNED_LINE
Kailo learned {move}!

## Kaigara

- START
**Gajumaru:** Your... move...

- THINKING_LINES
**Gajumaru:** Ahh... a fine... move...
**Gajumaru:** Let... me... think...
**Gajumaru:** Take... your... time...
**Gajumaru:** Hmm...
**Gajumaru:** Mm...

- KAME_PASSES
**Gajumaru:** I... pass...

- CANNOT taken
A shell is already there.

- CANNOT suicide
That shell would have no air and be taken. Play somewhere else.

- CANNOT ko
Ko. You can't take that back right away. Play somewhere else first.

- SCORE
You {b}, {name} {w}.

- WIN
You win!

- LOSE
{name} wins.

- DRAW
A draw.

- RESIGNED
You resigned.

- BANDARI_START
**Tamo:** Your shell first. Let's see what you've got.

- BANDARI_THINKING_LINES
**Tamo:** Hm. Interesting.
**Tamo:** Oh, you're sly.
**Tamo:** Careful now...
**Tamo:** Hee. Not there.
**Tamo:** Let me see...

- BANDARI_PASSES
**Tamo:** I pass. Your move, or end it.

- STAKE_LABEL
Bet {stake}

- STAKE_ASK
How many kupang?

- STAKE_NO
Not now

- STAKE_NONE
**Tamo:** No kupang, no game. Come back when you have a coin.

- STAKE_INTRO
**Tamo:** Kaigara for kupang! I play up to {max}, you choose. Winner takes the stake.

- STAKE_WIN
**Tamo:** Ha! You take it. {stake} kupang, fair and square.

- STAKE_LOSE
**Tamo:** That's {stake} kupang for me. Shells don't lie.

- STAKE_DRAW
**Tamo:** A draw! Nobody pays. Again, some day.

- STAKE_NO_LINE
**Tamo:** Maybe next time. The board isn't going anywhere.

- BET_ASK
How many pule?

- BET_WON
Kailo won {pule} pule.

- BET_PAID
Kailo paid {pule} pule.

- BET_FULL
The wallet was full. The rest was lost.

## Hina's battle lesson

- ASK
**Hina:** You do remember how to fight, right?

- YES
**Hina:** Good. Get ready.

- NO
**Hina:** ...Really? You lunkhead. Fine, I'll remind you.

- TURN_BAR_LINES
**Hina:** The faces on the right are who goes next. The top one goes now.
**Hina:** What you pick decides how soon you go again. So think, for once.

- ATTACK
**Hina:** Start with Attack. Even you can manage that.

- MISAIM_HINA
**Hina:** Not me! The boars, you lunkhead!

- MISAIM_BACKOUT
**Hina:** If the fishhook lands on me, press B to back out. Try not to need it.

- MISAIM_SELF
**Hina:** Stop hitting yourself!

- STAMINA
**Hina:** Those yellow bars are stamina. Every stroke spends some.

- LIGHT_FIRST
**Hina:** Try a Light attack first. That's Y.

- LIGHT_AGAIN
**Hina:** Ok, try another Light hit.

- LIGHT_MISSED
**Hina:** You missed a Light? Wow. Again, and look at the pig this time.

- MANA_LINES
**Hina:** That blue under your HP is mana. Every hit you land builds it.
**Hina:** Moves like your Sauté and my Heal spend it. Don't waste it.

- STRONG_CHANCE
**Hina:** Each hit you land makes the next likelier. Hold Select to see the odds.

- STRONG_MOVE
**Hina:** Now move down to Strong. Watch your face on the right.

- FACE
**Hina:** See that? Your face went down!

- FATIGUE
**Hina:** Every hit tires you, so you wait longer. Strong tires you most.

- STRONG_GO
**Hina:** But land it and it builds more mana. Strong is A. Go on, swing.

- MISSED
**Hina:** Missed. Strong does that. Don't sulk, keep swinging.

- OTHER_MANA
**Hina:** Defending builds a little mana too, just less than landing hits.

- DEFEND_WHERE
**Hina:** Defend is on the left page of your commands. Press left.

- DEFEND_GO
**Hina:** Now Defend. Go on, humor me.

- FLAME_KICK
**Hina:** That's enough mana. Open Element and show that pig your Sauté!

- HEAL_KAILO
**Hina:** You're bleeding on the taro. Hold still, I'll Heal you.

- HEAL_SELF
**Hina:** Aduh. Fine, I'll Heal myself. Watch how it's done.

- STANCE
**Hina:** I'm hurt, you're fine. Switch to Wai'Kenpō, the guarding stance.

- STANCE_GO
**Hina:** You won't hit as hard, but you can take more hits. Do it.

- STANCE_SHOWN
**Hina:** The yellow box by your name shows your stance. It's Water now.

- WAVE_GUARD
**Hina:** Now Wave Guard. Take hits for me, at half damage. Don't whine.

- ITEM_HINA
**Hina:** It's not my turn to Heal yet, and I'm hurt. Use a {item} on me, quick.

- ITEM_KAILO
**Hina:** You look awful. Not my turn to Heal. Eat a {item}, lunkhead.

- ITEM_KAILO_MANA
**Hina:** You look awful. I'm out of mana. Eat a {item}, lunkhead.

- ITEM_KAILO_STANCE
**Hina:** You look awful. Heal's in my other stance. Eat a {item}.

- ITEM_SELF
**Hina:** No mana to Heal myself. Fine, a {item} it is.

- ITEM_SELF_STANCE
**Hina:** Heal's in my other stance, and there's no time. A {item} it is.

- ITEM_HINA_BURN
**Hina:** Aduh, I'm burned and can't heal. Hand me a Kukui, quick!

- ITEM_KAILO_BURN
**Hina:** You're burning, lunkhead. Healing won't work. Use a Kukui.

- ITEM_SELF_BURN
**Hina:** Aduh, I've been burned, now I can't heal. I need a Kukui.

- BLOCK_LINES
**Hina:** Here they come. Each red bar is one of the pig's hits.
**Hina:** Each bar shows its button. Y is a light hit, X a medium, A a strong.
**Hina:** Press it when it's in the yellow. Closer to the middle hurts less.
**Hina:** Dead center and you take nothing. Not that you'll manage.

- DODGE_PRAISE
**Hina:** Fine. That was good. Don't make it weird.

- NATURE_HEALS
**Hina:** Lanu's beasts keep healing. That's Nature. It burns easily, though.

- TEAM_UP_LINES
**Hina:** Wait. We both have full mana, and we're side by side on the bar.
**Hina:** That means a Combo. Press right on your commands.
**Hina:** It takes every drop of mana we have. Don't mess up your half.

- ESCAPE_LINES
**Hina:** Aduh, this is bad. Not my turn to Heal, and we're both hurt.
**Hina:** Escape is on the left page of your commands.
**Hina:** No shame in living to fight another day. Just don't get used to it.

- ESCAPE_STANCE
**Hina:** Aduh, this is bad. Heal's in my other stance, and we're both hurt.

- ESCAPE_MANA
**Hina:** Aduh, this is bad. I'm out of mana, and we're both hurt.

## Setting sail

- WARNING
We're running out of food, we should find land soon.

- STARVED
The last of the food is gone...

- SHORT_LINE
**Kailo:** This will barely last us to {place}. We should head straight there, no detours.

- NEED_FOOD_LINE
**Kailo:** Not yet. Kupulau is about {trip} days out and we only have food for {have}. I want enough for {need}, in case something goes wrong.

- TOO_WILD
The current here is too strong for the Meialana.

- ASHORE_ASK
Go ashore at {place}?

- LEAVE_ASK
Once you sail, you may not see Kulāiwi again for a long time. Set sail?

- AMA_LINES
**Ama:** Listen, boy. Out there every one of you eats one meal a day.
**Ama:** Fresh fish goes bad in a day. Coconut and 'uala keep for weeks, so eat what spoils first.
**Ama:** Watch how much food you have left. When it runs low, find land or you'll starve out there.
**Ama:** Now go on. Find Melia, and come back home to us.

- LANDFALL_LINE
Landfall at {place}! The land there is not built yet.

## Lanu's grove

- LEFT_ONE
**Sage:** One post is still dry. Lanu is almost fed.

- LEFT_MANY
**Sage:** {left} of Lanu's posts are still dry. Water all five, and I will have something for you.

- ASK
Offer Lanu a cup of water?

- OFFER
**Kailo:** A post for Lanu. I'll leave her a cup of water as an offering.

- DRY
**Kailo:** A post for Lanu. I need a cup of water to leave her an offering.

- DONE
Lanu already has her water here.

- POURED
Kailo poured Lanu a cup of water.

- ENOUGH
The leaves rustle, though there's no wind.

- BLESSING_LINES
**Sage:** You watered all five of Lanu's posts. The trees told me. They tell me everything.
**Sage:** Then she has something for your friend, the one who dances over the sick. Take this to her.

## Heading home

- HOME_ASK
Head back?

- HOME_CHOICE_LINES
Go back
Keep exploring
