# The taro patch

The taro patch, written as a script. The pygame game reads this file (`core/story.py`), so this is the one place the dialogue is written. A draft
scene, not canon: the taro patch, the uncles and the boars are made up. Dialogue is in each
speaker's own accent (D-119); everyone here is eastern.

Three boars are in the patch (Frankie, 11/1): the third, Wild Boar C, runs off west toward Melia and the pot, shown
on screen, and Kailo and Hina fight the other two. The runaway is the one that ruined the stew.

The stew (Frankie, 10/30): the boars knock the pot over as they run into the forest, so Kailo stays to
remake it instead of going to the next island; Kailo cooks it, with Noelani helping, when the player brings the makings
(`systems/stew.py`). Claude's drafts: Melia's line about the pot, and Kailo's "I have a stew to remake"
(his "Change of plans" is Frankie's). Kailo's "I should head home first, maybe Noelani can help" after Hina and Melia leave is Frankie's (10/30).

Losing the fight goes on with the game, never a retry (Frankie, 10/26): Melia drives the boars off,
Kailo stays sunny lying there, and her talk about them plays as after a win, without Hina, who has
already gone home. Claude's drafts, for Frankie to rewrite: Melia's line as she drives them off;
Hina's after her cake in the win, the hint that Kailo should go and get her; and in the loss
everything after "..." but "You lost to a pig." and the boar talk: Kailo's "strong pigs" (Frankie
liked it), "You're so weird", the ruined taro moved to Melia, Kailo's "grow more" (Hina's point
after a win), and Melia's lines about Hina and the wake.

How to write it:

- `**Name:** line` is someone talking. `**Name** (if lid):` only plays if that choice was made;
  `(if hina)` only with Hina in the party, `(if maika)` only with Maika but not Hina, `(if alone)`
  only with Kailo by himself.
- A plain line is narration.
- `**Hina:** (fast) Why do you sages always have to—` types the line out three times as fast,
  in the games. A fast line that ends on a dash is cut off: the next line comes up the moment it
  is typed, with no button (Frankie, 10/23). `(quick)` types it twice as fast, between the usual
  and `(fast)`, and is cut off on a dash the same way (Frankie, 10/25: Hina's line at the wake).
  `(slow)` types it out at a crawl, and the button cannot hurry it, only turn the page once it is
  all out (Frankie, 10/26: the Kame in `story-kaigara.md`).
- `**Name** (if maika along):` plays whenever that one is in the party, whoever leads
  (`story-boar.md`; the games only).
- `**Name** (if maika along and hina along):` plays only when both are; `and` joins any two
  (`story-kaigara.md`; pygame only).
- `**Name** (if maika not along):` plays only when he is not in the party (the wake's ending,
  10/25; pygame reads it, the cartridge not yet).
- `**Name** (if stew saved):` plays only if the taro patch fight was won, `(if stew lost)` only if
  it was lost (the wake, 10/26; pygame reads it, the cartridge not yet).
- `**Choice:**` is followed by the options, each `- text → flag`.
- `**Fight:**` names the party, then `against`, then each enemy as `Name (monster, element)`, or
  `Name (monster, element, sprite)` to draw it as a sprite it is not named after (the wake's Pono,
  drawn as the amaranhig). Ending the line `; preemptive strike` or `; ambush` opens the fight with
  the monsters, or the party, at full fatigue (Frankie, 10/27; pygame reads it, the cartridge not
  yet). The first three named fight; a fourth or more wait on the bench to swap in. The story carries
  on under `## If you win` or `## If you lose`.
- `**End:**` closes the scene.

Stage directions act the scene out on the map, as a Super Nintendo cutscene does (Frankie, 10/23).
The games play them. A tile is its column and row counted from
the top left of the room, from 0 (`5,6`). Several people at once are separated by semicolons.

- `**Room:** beach_west` plays the scene in that room of the map. Kailo is the player.
- `**Stand:** Hina at 11,4 facing down` puts someone on a tile, facing up, down, left or right. `**Stand:** Hina beside Kailo` puts her on a free tile next to him,
  facing the way he does (pygame only; for a room where Kailo stands wherever the player left him).
- `**Swim:** Kailo to the west edge` hops him off the shore into the water on the first step (the swimming hop, with its splash) and swims him on to the stop with his swim frames and stroke sound (Frankie, 11/16; the harbor's jump off the pier). Only Kailo has swim frames.
- `**Walk:** Hina to 11,7 to 5,7` moves someone at a calm walk; `**Run:**` a little faster, only
  for an emergency or a rush (Frankie, 10/26: people in scenes walk unless it is urgent). Each `to` is a stop, reached across first, then up or down. `from 11,4` or `from the east
  edge` puts them there first (an edge in the row or column of the first stop); `to the east edge`
  goes off the map in the row they are in, and off it they are gone. Everyone on one line moves
  together, and the next line waits until they all arrive.
- `**Turn:** Kailo right` turns someone; `**Turn:** Kailo, Melia to Hina` turns them to face her.
- `**Fall:** Body` lays someone down on their tile: their sheet's fifth row if it has one, else
  their standing frame on its side. Standing them again gets them up.
- `**Fade:** out` takes the screen to black, `**Fade:** in` brings it back, as the Super Nintendo's
  brightness does (the wake, Frankie 10/23). A scene can change room while it is black.
- `**Wait:** 1` holds the scene that many seconds, for a pause no one speaks in.
- `**Song:** Voices of the Past` plays one of Frankie's pieces from there on, in place of the
  room's song and the fight's, until the scene's fight is won (Tawiri's theme at the wake, Frankie
  10/26). The name is the file's in `music/snes/`, `voices-of-the-past.it`. Winning the fight
  plays the victory theme as any win does, and the room's song comes back once the victory screen
  closes (Frankie, 10/27). `**Song:** none` stops the music, and nothing plays from there to the
  scene's End, its words on black included (the wake, from the pirates on, Frankie 10/27).
- A direction can be `(if maika along)` like a line, and plays only then.
- Someone on the stage is named for their walk sheet (`<Name>-Walk.png` with the map's people), or
  is Kailo.
- A tile can be past the edge: `from -2,6` starts someone two tiles out, so two arriving together
  do not walk on top of each other.
- The scene's foes can stand on the stage too, under their names in its `**Fight:**` line, as the
  map draws their kind. A walker that only faces left or right turns that way; `facing down` has
  it rooting, head down, bobbing between its frames.

The people of the room (Melia at home) are hidden while their scene is acted out, and everyone but
Kailo leaves when it ends. A scene whose `Room` is the one Kailo is in starts with him where he
stands; in any other room he is not on the map until the scene stands or walks him in, so a cut
to somewhere he is not (Melia taken at the wake) needs no direction for him (Frankie, 10/25); one that ends with him on a doorway, facing out, takes him through the door.
After this scene Hina walks home and is out of the party until Kailo talks to her there
(`story-hina.md`), or catches him up in the gate yard, the room before the Great Boar's (`story-hina-woods.md`).

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Melia**: Lau, art/portraits/melia-portrait-a.png

## Scene


**Room:** beach_west
**Stand:** Kailo at 5,6 facing up

**Kailo:** Stew for the wake tonight... cakes and breadfruit for the next island. If I leave now I'll be back before Melia's done her chores.

**Run:** Melia from the east edge to 10,6

**Melia:** Kailo! KAILO!

**Turn:** Kailo right
**Run:** Melia to 6,6

**Kailo:** I'm right here. What happened?

**Melia:** Those naughty boars are back! Three of them, in the taro patch. They're digging up everything!

**Kailo:** The taro? That patch feeds three houses!

**Stand:** Hina at 11,4 facing down

**Hina:** Then stop shouting and do something about it.

**Turn:** Kailo, Melia to Hina
**Walk:** Hina to 11,7 to 5,7
**Turn:** Hina up; Kailo down

**Hina:** I was coming over for one of your taro cakes. I'd like there to still be taro tomorrow.

**Turn:** Hina to Melia; Melia to Hina

**Hina:** Melia, stay here and keep the gulls off the stew.

**Melia:** Why do I always get the gulls? Let me fight with you.

**Kailo:** It's too dangerous, just stay here and keep them away.

**Melia:** Fine, I'll get some practice with my sling.

**Kailo:** Melia, put that thing away before you break something.

**Melia:** Aww.

**Run:** Kailo to the east edge; Hina to 5,6 to the east edge
**Turn:** Melia up

**Room:** beach_east
**Stand:** Pua'a Hihiu A at 6,7 facing down; Pua'a Hihiu B at 5,8 facing down; Pua'a Hihiu C at 9,8 facing down
**Run:** Kailo from the west edge to 3,6; Hina from -2,6 to 2,6

**Kailo:** Shoo! Shoo!

**Turn:** Pua'a Hihiu A, Pua'a Hihiu B, Pua'a Hihiu C to Kailo

**Pua'a Hihiu A:** SQUEEEE!

**Run:** Pua'a Hihiu C to 8,5 to the west edge

**Fight:** Kailo the Cook, Holy Hina against Pua'a Hihiu A (boar, Lau), Pua'a Hihiu B (boar, Lau); preemptive strike

## If you win

**Room:** beach_east
**Stand:** Kailo at 6,6 facing down; Hina at 8,7 facing left

**Kailo:** Look at this. Half of it's dug up. That's a month of poi, just lying in the mud.

**Hina:** It's not all ruined. Some of those roots are only bruised.

**Kailo:** ...yeah, bruised taro still cooks. I just hate seeing the rest go to waste.

**Walk:** Melia from the west edge to 5,6
**Turn:** Kailo left

**Melia:** Kailo... I'm sorry. The one that ran off. It went right through the stew on its way to the forest. The pot's on its side, and it's all over the sand.

**Kailo:** ...the wake's tonight.

**Melia:** They'll be back, you know.

**Kailo:** How do you know that?

**Melia:** Everybody knows. The Great Boar lives at the top of the woods, and he's the boss of all the boars. He sends the little ones down to steal taro for him, because he's too fat to come get it himself.

**Turn:** Hina to Melia

**Hina:** That is not how boars work.

**Melia:** Then why do they keep coming?

**Turn:** Kailo down

**Kailo:** ...Change of plans. Nobody's going to the next island today. I have a stew to remake, and if there's a boss boar up there, I'm going to go tell him to get his own taro.

**Hina:** Then I'll take my cake now.

**Hina:** I'll be at home. When you figure out you can't do this alone, you know where I live.

**Hina:** Be back before dark. Old Pono's wake is tonight.

**Turn:** Kailo to Melia

**Kailo:** Melia, go back to your chores. And stay near the house, okay? Boars don't care how brave you are.

**Melia:** Aw.

**Walk:** Hina to 8,9 to 3,9 to 3,6 to the west edge; Melia to the west edge

**Kailo:** I should head home first, maybe Noelani can help.

**End:** The end of the test scene.

## If you lose

**Room:** beach_east
**Stand:** Kailo at 6,6 facing down; Pua'a Hihiu A at 9,7 facing down; Pua'a Hihiu B at 10,8 facing down
**Fall:** Kailo
**Wait:** 1
**Run:** Melia from the west edge to 4,6

**Melia:** Hey, pigs! Get away from him, or you get a rock in the snout!

**Turn:** Pua'a Hihiu A, Pua'a Hihiu B to Melia
**Wait:** 0.5
**Run:** Pua'a Hihiu A to the east edge; Pua'a Hihiu B to the east edge
**Walk:** Melia to 5,6
**Turn:** Melia to Kailo

**Melia:** You lost to a pig.

**Kailo:** ...

**Kailo:** ...Those were really strong pigs, though. Good for them.

**Melia:** You're so weird.

**Melia:** And look. Half the taro's dug up. That's a month of poi, just lying in the mud.

**Stand:** Kailo at 6,6 facing left

**Kailo:** Hey, it's not all ruined. We can always grow more, and the bruised ones still cook just fine.

**Melia:** The boars ran right through the stew on their way back to the forest, by the way. The pot's all over the sand.

**Melia:** They'll be back, you know.

**Kailo:** How do you know that?

**Melia:** Everybody knows. The Great Boar lives at the top of the woods, and he's the boss of all the boars. He sends the little ones down to steal taro for him, because he's too fat to come get it himself.

**Turn:** Kailo down

**Kailo:** ...Change of plans. Nobody's going to the next island today. I have a stew to remake, and if there's a boss boar up there, I'm going to go tell him to get his own taro.

**Melia:** Hina already went home. She said if you need a healer, you know where she lives.

**Melia:** And be back before dark. Old Pono's wake is tonight.

**Turn:** Kailo to Melia

**Kailo:** Melia, go back to your chores. Mahalo for the rescue. Don't tell anyone.

**Melia:** Aw.

**Walk:** Melia to the west edge

**Kailo:** I should head home first, maybe Noelani can help.

**End:** The end of the test scene.
