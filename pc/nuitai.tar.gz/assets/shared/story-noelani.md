# Noelani and the wallet

The first time Noelani offers Kailo a wallet with Maika in the party and standing, Maika flirts with
her and she is into it, and Kailo and Hina are appalled (Frankie, 11/12: "Kailo and Hina are like wtf").
Afterward her price for Kailo is the discounted one, Maika's charm working on her as it does on any
seller. It plays once; the pygame game plays it from her bank menu. Noelani's relationship to Kailo is not
stated here on purpose, because canon does not state it. Every line is Claude's draft, for Frankie to rewrite.
Hina's lines play only if she is in the party. How to write a script is at the top of `story.md`.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png

## Scene

**Maika:** Noelani, was it? Forgive me. I thought the sun had come indoors.

**Noelani:** Oh? Go on.

**Kailo:** ...What.

**Maika:** A woman with a jar this tidy and a smile like that should never have to say a full price. Let me say a kinder one.

**Noelani:** Kinder. Mm. Say it slower.

**Hina** (if hina along): (fast) Maika, stop. Stop talking. Why is she smiling at you—

**Kailo:** She's blushing. Why is she blushing?

**Maika:** I'm only being friendly. Friendship is a very fair price.

**Noelani:** Friendly, hm? Fine. It's cheaper for you today, Kailo. Don't make that face.

**End:** Noelani keeps her word.
