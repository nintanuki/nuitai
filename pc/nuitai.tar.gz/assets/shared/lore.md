# Lore pages

The pages under Lore on the Info screen, in pygame and on the cartridge (`game/answers.md`, the
Lore line). Both games read this file: pygame at run time (`core/lore.py`), the cartridge through
`game/snes/tools/make_art.py`. Edit the words here, never in the games.

Each page is drawn from its wiki article in `lore/` and checked against `lore/answers.md`, with
nothing a spoiler: a short summary in the wiki's neutral voice, American spelling. The games show
it in capitals, wrapped to 30 letters a line; two or three screens at most.

Each page is a `##` title (as the list shows it), then three lines:

- **Category:** the row on the Info screen that lists it (Frankie, 10/25): People, Places, Gods,
  Faiths (the faiths and the orders of priests, sages and shamans), Arts (the fighting arts and
  sacred dances, one per stance), Food or Words (everyday words like hello and thank you, each
  page naming the language it is from; Frankie, 10/26). A category with no page found yet is not shown.
- **Unlocks:** when the page appears, silently. `start` is there from New Game. `stance <name>`
  is the first time a member acts in that stance in a fight. `event <name>` is a moment in the
  story: `met_maika` (Maika's scene at his stall), `hina_home` (Hina rejoins at her house, or in the
  woods), `tawiri_joins` (Tawiri joins at the wake), `wake_shaka` (the wake ends, where Hina says Shaka keep
  him), `wake_lanu` (the same, with Maika there to answer her with Lanu), `deep_woods` (Hina or
  Maika warns Kailo off the deep woods west of the log yard, naming Lanu's beasts), `lore_akua`,
  `lore_shaka` and `lore_whirlpool` (asking the loremaster in the chief's house; not built yet). `kaigara_met` (meeting Gajumaru, the Kame in the hunters' lodge), `kaigara` (a game of Kaigara with him ends, won or lost), `kaigara_home`, `kaigara_trip` and `kaigara_what` (asking Gajumaru, the Kame, where he is from, how he got here, and what Kaigara is). `named` is the first time the page's title is said in the Kaigara Kame's scenes, or a name on its optional `**Also:**` line (the same thing in someone's accent), comma separated (Frankie, 10/27). `item <id>` is the first time the party has that item in the bag (Food, Frankie 10/30; Claude's pick). `heard`, for
  Words, is the first time the page's title is said in any line (Frankie, 10/26). Several joined
  by `or` mean whichever comes first.
- **Draft:** `yes` while the words are Claude's, for Frankie to rewrite; `no` once they are his.

Then the page's words, one paragraph.

Not here yet: Shakan Mudras, Ata Kanikani and Wili Hula, the other stances of the
demo's four, have no article in `lore/` to draw from, so acting in them unlocks nothing.

## Kailo

**Category:** People
**Unlocks:** start
**Draft:** yes

Kailo is a young cook of about nineteen from Kulāiwi, in the Māla Iki Islands. He looks after his many younger siblings and cousins and has never left the chain. His father left when Kailo was young to explore the ocean, and Kailo dreams of exploring the world himself. Wasting food upsets him.

## Hina

**Category:** People
**Unlocks:** start
**Draft:** yes

Hina is a young priestess of Māla and a devout follower of the teachings of Shaka. She was born in Kota Emas and raised on Māla Iki. To become the high priestess of her village she must make a pilgrimage to Kota Emas once in her life and pray at its golden temple. She is a vegetarian, as is common among devotees of Lanu.

## Melia

**Category:** People
**Unlocks:** start
**Draft:** yes

Melia is Kailo's cousin, about eight years old, raised in his household on Kulāiwi. Cousins in the household are raised as siblings, so Kailo calls her his sister. She has his thick, wavy red hair, with hazel eyes and freckles.

## Kulāiwi

**Category:** Places
**Unlocks:** start
**Draft:** no

Kulāiwi is a small island in the Māla Iki Islands, beside Māla Iki itself, the largest island of the chain. It has one village, also called Kulāiwi. This is Kailo and Hina's home.

## Māla Iki

**Category:** Places
**Unlocks:** start
**Draft:** yes

Māla Iki, "Little Garden," is the largest island of the Māla Iki Islands, a small chain northeast of the Great Whirlpool. The chain has the mildest weather in Nuitai and has known little war. Most islanders are fishers, weavers or farmers who grow taro and sweet potato, and few sail out of sight of their own shore.

## Lelua

**Category:** Arts
**Unlocks:** stance Lelua
**Draft:** yes

Lelua is the fire dance of the fire dancers of Velafi, a rite honoring Mauga and a fighting art in one. It has almost no blocking or guarding. Its defense is constant motion: spins, feints, flying kicks and somersaults. Devotional dancers turn Mana into fire that bursts from the end of a kick or a punch.

## Wai'Kenpō

**Category:** Arts
**Unlocks:** stance Wai'Kenpō
**Draft:** yes

Wai'Kenpō, "the Way of the Water Fist," is a famous martial art inspired by the flow of water, with a philosophy of self defense over attack. It was developed by devout practitioners of Wai'Ki and has spread throughout Nuitai, but none practice it as well as the Kame.

## Māla Hula

**Category:** Arts
**Unlocks:** stance Māla Hula
**Draft:** yes

Māla Hula is the sacred dance of the Priests of Māla. It is slow and gentle, with turns in circles and arms raised from the ground to the sky, and is danced to help crops grow and wounds heal.

## Kilomi

**Category:** Arts
**Unlocks:** stance Kilomi
**Draft:** yes

Kilomi is the healers' martial art of Māla Iki and Lanuloa, devoted to Lanu. Its healers learn the points where Mana runs through a body and press them open to heal. In a fight they close the same points with open palms and fingertips, numbing a limb or cutting a channeler off from Mana. Its name joins kī, the ti plant, and lomi, to press.

## Maika

**Category:** People
**Unlocks:** event met_maika
**Draft:** yes

Maika is a young Maki Sage of Māla Iki, with white hair and eyes of green and purple. He is well spoken and calm, can be tactless and a little arrogant, and admits when he is wrong. He practices Kilomi, the healers' martial art, and is a vegetarian.

## Maki Sages

**Category:** Faiths
**Unlocks:** event met_maika
**Draft:** yes

The Maki Sages are worshipers of Lanu who broke away from the Priests of Māla a century ago, when the priests took in the Teachings of Shaka. To the Sages, giving the sunlight to Shaka takes from Lanu what was always hers. They live as hermits in the more dangerous forests of Māla Iki and wear green robes marked with a purple spiral, the symbol of Mana. Unlike the peaceful priests, they use their nature magic to fight as well as to heal.

## Māla

**Category:** Faiths
**Unlocks:** event hina_home
**Draft:** yes

Māla is a faith of the eastern seas, born on the Māla Iki Islands. It joins the native worship of Lanu with the teachings of Shaka, brought by Bandari missionaries, and holds that Shaka is an aspect of Lanu. Its followers are pacifists who teach that harmony must be tended like a garden.

## Māla Priests

**Category:** Faiths
**Unlocks:** event hina_home
**Draft:** yes

The Priests of Māla are an old order of Māla Iki whose temple is the forest. They are healers, midwives and teachers, wear robes of green and yellow, and dance slow sacred dances for the growth of crops and the healing of wounds. The Maki Sages broke away from them.

## Tawiri

**Category:** People
**Unlocks:** event tawiri_joins
**Draft:** yes

Tawiri is an old Caller of the dead from the Matua Archipelago, cynical and morbidly funny. One of her eyes is clouded white and blind with age. Her staff doubles as a walking stick, hung with feathers and little skulls.

## Callers

**Category:** Faiths
**Unlocks:** event tawiri_joins
**Draft:** yes

The Callers are the shamans of the Matua Archipelago, who commune with the spirits of the dead. They wear black robes adorned with bones and skulls and are both revered and feared. In Matua their work is not taboo: they prepare the dead, lead funerals and help the grieving say a last goodbye.

## Shaka

**Category:** Gods
**Unlocks:** event wake_shaka or event lore_shaka
**Draft:** yes

Shaka is the founder of the Teachings of Shaka, the faith the Bandari brought to the eastern seas. He was a mortal man who awakened two thousand years ago, and for many he is now represented by the light of the sun. Shakans never picture him. Their art shows only his symbols: the sun, and his sword standing upright in the sand. Māla holds that he is the sunlight of Lanu in human form.

## Akua

**Category:** Gods
**Unlocks:** event lore_akua
**Draft:** yes

The Akua are the gods of Nuitai, great spirits that embody aspects of Mana. The three Akua Nui head the pantheon: Lanu, the goddess of life and nature, Mauga, the goddess of fire and change, and Moanatu, the god of the sea and death. Below them are the Akua Iki, each a piece of a greater Akua, such as Hau the wind and La the sun. They can take mortal form and appear and vanish at will.

## Whirlpool

**Category:** Places
**Unlocks:** event lore_whirlpool
**Draft:** yes

The Great Whirlpool, Te Pito o Nuitai, "the navel of the world," lies at the center of Nuitai. Its currents reach thousands of miles out and shape the tides and weather of the island chains around it. At its edges it is gentle enough to sail, and its current favors clockwise travel, more strongly closer to the center. Further in are rogue waves and hurricane winds, and too far in, no ship can sail back out. Sailors pray to Moanatu before entering its outer currents.

## Lanu

**Category:** Gods
**Unlocks:** event deep_woods or event wake_lanu
**Draft:** yes

Lanu is the Akua of the sky and the forests. Her domain is the energy of all living things: life, light, growth, harmony and the gentle rain. She was once the goddess of the sun as well, but as the teachings of Shaka spread through Māla Iki and Lanuloa, the sun and its light came to be given to him instead. The Maki Sages have never accepted this.

## Aloha

**Category:** Words
**Unlocks:** heard
**Draft:** yes

Aloha means hello in Eastern Nuitai'lo, the island language as it is spoken in Māla Iki and Lanuloa. Easterners also say it for goodbye.

## Mahalo

**Category:** Words
**Unlocks:** heard
**Draft:** yes

Mahalo means thank you in Eastern Nuitai'lo.

## 'Ae

**Category:** Words
**Unlocks:** heard
**Draft:** yes

'Ae means yes in Eastern Nuitai'lo. It sounds like the English word "eye." The mark at the start is a catch in the throat, like the break in "uh-oh."

## 'A'ole

**Category:** Words
**Unlocks:** heard
**Draft:** yes

'A'ole means no in Eastern Nuitai'lo. It is said "ah-OH-leh," with a catch at each mark.

## A hui hou

**Category:** Words
**Unlocks:** heard
**Draft:** yes

A hui hou means goodbye in Eastern Nuitai'lo. Word for word, it is "until we meet again."

## Kia ora

**Category:** Words
**Unlocks:** heard
**Draft:** yes

Kia ora means hello in Matua Nuitai'lo, the island language as it is spoken in Matua. An easterner would say aloha.

## Āe

**Category:** Words
**Unlocks:** heard
**Draft:** yes

Āe means yes in Matua Nuitai'lo. It is close to the eastern 'ae, with a longer first vowel and no catch.

## Kāo

**Category:** Words
**Unlocks:** heard
**Draft:** yes

Kāo means no in Matua Nuitai'lo. An easterner would say 'a'ole.

## Lontar

**Category:** Words
**Unlocks:** heard
**Draft:** yes

A lontar is a book of dried palm leaves, the letters cut in with a knife and rubbed with soot so they show. Lontars are written in the Bandari script, and Bandari moves are taught in them, so only a reader can learn from one. Before the Bandari came, the islands had no writing at all. Most Nuitagata still cannot read; those who can are mostly priests of Shaka and travelers, though that is slowly changing.

## Kapa

**Category:** Words
**Unlocks:** heard
**Draft:** yes

Kapa is bark cloth, beaten thin and painted. Easterners say kapa; in Matua it is tapa. A kapa can show a move in pictures, step by step, so anyone can learn from it without reading. The islands' own fighting arts are passed on this way, or by a teacher in person, never locked behind a foreign script.

## Aduh

**Category:** Words
**Unlocks:** heard
**Draft:** yes

Aduh is what speakers of Bandhasa, the language of the Bandari, say when they are hurt or startled, like "ow" or "oh no." Islanders with Bandari family pick it up at home.

## Kame

**Category:** People
**Unlocks:** event kaigara_met or event kaigara
**Draft:** yes

The Kame are a turtle people from the Kame Kingdom, an island realm in the northwestern seas. They are leaf turtles, with low, ridged shells of orange to dark brown and yellow to reddish heads, and they can pull into their shells. They are strong swimmers, famous healers and martial artists, and eat no meat but what comes from the sea. Their Council of Springs is known for taking whole seasons to decide anything.

## Kaigara

**Category:** Arts
**Unlocks:** event kaigara or event kaigara_what
**Draft:** yes

Kaigara, or Shells, is a strategy game invented by the Kame. Two players take turns putting black and white cowrie shells on a grid drawn in chalk on smooth stone, each trying to surround and capture the other's shells. It takes patience: some Kame have played a single game for years. In Māla Iki it is called Kaikala.

## Kame Kingdom

**Category:** Places
**Unlocks:** named or event kaigara_home
**Also:** Kami Kuku
**Draft:** yes

The Kame Kingdom, which the Kame call Kami Kuku, is an archipelago in the northwestern seas and the home of the Kame. Its green islands are known for sacred caves, clear springs and hidden grottos, guarded by the Wai'Ki Wardens, and giant turtles, the Dai-Kame, swim the seas around it. Medicine is its main export. Its king is rarely seen; the Council of Springs decides most things, slowly.

## Bandar

**Category:** Places
**Unlocks:** named
**Also:** Bandaru, Bena
**Draft:** yes

Bandar is the homeland of the Bandari, a country somewhere far to the west of Nuitai. Bandari settlers sailed east from it eight centuries ago. The way back is now windless and full of colossal sea monsters, and nobody has reached Bandar since. It is known only from chronicles, old art and stories.

## Bandari

**Category:** People
**Unlocks:** named or event kaigara_trip
**Draft:** yes

The Bandari are a seafaring people whose ancestors sailed from Bandar to Nuitai eight centuries ago, under the sun mark of Shaka. Most live in the Matahari Archipelago, where they founded Kota Emas, and in the Bayang Seas. They are known for artistry, learning, seamanship and their faith in the Teachings of Shaka. Their gold coin, the kupang, is valued across the west.

## Kota Emas

**Category:** Places
**Unlocks:** event kaigara_trip
**Draft:** yes

Kota Emas is the largest and most diverse city in Nuitai, on the main island of the Matahari Atoll, behind a lagoon and a barrier reef. Bandari settlers founded it about seven hundred years ago. It is the center of trade and of the worship of Shaka, with the largest temple to him in Nuitai. Hundreds of ships use its lagoon, and its main roads are canals traveled by small boats.

## Coconut

**Category:** Food
**Unlocks:** item niu
**Draft:** yes

The coconut, niu, is the fruit of the coconut palm. Its sweet water is drunk fresh, and its white flesh is eaten or grated into puddings. Palms line nearly every beach in the islands.

## 'Uala

**Category:** Food
**Unlocks:** item uala
**Draft:** yes

'Uala is the sweet potato, a sweet, starchy root baked, steamed or mashed. Island voyagers carried it across the Pacific long ago, and it grows well in poor soil.

## 'Ulu

**Category:** Food
**Unlocks:** item breadfruit
**Draft:** yes

'Ulu is breadfruit, a large green fruit from a tall tree. When cooked it is soft and starchy like bread or potato. One tree feeds a family for years.

## Poi

**Category:** Food
**Unlocks:** item poi
**Draft:** yes

Poi is a smooth paste of pounded taro root and water. It is eaten fresh or left to sour a little, usually with a main dish and a finger or two.

## 'Ulu Poi

**Category:** Food
**Unlocks:** item ulu_poi
**Draft:** yes

'Ulu poi is a paste of mashed breadfruit and water, made like poi from taro. It is a little sweeter and a little thicker.

## Kulolo

**Category:** Food
**Unlocks:** item kulolo
**Draft:** yes

Kulolo is a dense, sweet pudding of grated taro and coconut, baked slowly until it turns dark and chewy. It is served at feasts and given as a gift.

## Laulau

**Category:** Food
**Unlocks:** item laulau
**Draft:** yes

Laulau is pork wrapped in ti leaves and steamed in a bundle until the meat is tender. The leaf is not eaten. It gives the meat its smell.

## 'Inamona

**Category:** Food
**Unlocks:** item inamona
**Draft:** yes

'Inamona is a relish of roasted kukui nuts ground with salt. The nuts are also called candlenuts. It is stirred into fish and seaweed dishes.

## 'Awapuhi

**Category:** Food
**Unlocks:** item awapuhi
**Draft:** yes

'Awapuhi is wild ginger, a plant with a pale root that grows in the earth. The root is sharp and sweet, and was used in cooking and in medicine.

## Akai Lau

**Category:** Food
**Unlocks:** item akai_lau
**Draft:** yes

Akai lau is green onion, a slim plant with long hollow green leaves and a white base. It grows quickly from a seed, and its leaves and bulbs flavor stews and soups.

## Kohuapua

**Category:** Food
**Unlocks:** item kohuapua
**Draft:** yes

Kohuapua is a braise of pork and eggs in coconut, with fish, ginger, shoyu, 'uala and green onion. It is cooked slowly until the sauce goes dark and sweet, and it is served at wakes and feasts. Every family's is a little different, and each swears theirs is the right one.

## 'Awa

**Category:** Food
**Unlocks:** item awa_root or item awa_drink
**Draft:** yes

'Awa is a plant whose root is steeped in water for a bitter, calming drink. It was shared at ceremonies and gatherings.
