# Maika

Maika sells medicine at the market stall in the blocks room (Frankie, 10/25; was the crossroads). Buying
from him no longer makes him join; his sister does (Frankie, 10/30; it was buying something, 10/22).
Meeting him is a scene with faces, not straight into his shop (Frankie, 10/23). The games play it. How
to write a script is at the top of `story.md`. Nobody walks: the lines play where everyone stands.

This file is seven small scenes, each under its own heading, and the games play each one at its
moment. The sister's side, in the hunters' lodge, is `story-sister.md`.

- **The scene** when Kailo first talks to Maika. Then his shop opens, unless his sister has already
  asked Kailo to find him: then **Don't tell her** plays first.
- **Don't tell her**, the first time Kailo talks to him after agreeing with his sister to find him.
  Met first, then the sister: it plays on the next talk; sister first: right after the scene. Then
  his shop opens.
- **If you lied**, the next talk after Kailo told his sister Maika took a boat to the next island.
  At its end Maika joins, with his pop-up ("Maika joined the party. While he is in your party, shops
  charge less."), and his shop is gone.
- **If you lied, after the Great Boar**, the same, once the Great Boar is beaten: Kailo is out for
  ingredients, and Maika knows the forest (Frankie, 11/2; the lines are Claude's draft). Pygame only
  for now; the cartridge plays **If you lied**.
- **Maika asks to come along** (Frankie, 11/11; the lines are Claude's draft), at the end of both lie
  scenes: a yes or no. Yes: he joins, with his pop-up. No: he stays, and every talk to him asks again.
  Pygame only for now; the cartridge's **If you lied** joins him as before.
- **If you told the truth**, the next talk after Kailo told his sister where he is, once. Maika does
  not join, and his shop stays.
- **If you leave**, whenever the shop closes, bought something or not. Talking to him again opens the
  shop straight away.
- **The first planting**, right after the party replants a garden patch with both Maika and Hina
  along (Frankie, 10/24; it was walking into the Great Boar's room, 10/23), which gives his talk of
  gardening its reason. Once. Without Maika, or without Hina, it does not play. If the first lontar talk has not played yet and Kailo is along, it plays here (`ItemSettings.FIRST_TALK`); then Hina calls Maika out either way (Frankie, 11/10).

`(if hina)` plays only with Hina in the party, `(if alone)` only with Kailo by himself (Maika is
not along yet in any scene but the planting).

Claude's drafts, for Frankie to rewrite (10/23): every line here except "Lost? Everyone who finds
me is lost.", "So what brings you all the way out here?", Kailo's "...going after the Great Boar.",
"The Great Boar? He's the other way. You went the wrong way." and Maika's Green Dream line, which are
Frankie's from before. Hina's answer to it is Claude's draft (10/24). Claude's drafts of 10/30: both
new scenes and the two lines opening "If you lied"; Maika's "A wise man never lets a good customer get
lost" became "a good friend" (nobody is a customer on the way in any more), and Frankie's "lovely lady"
line stayed.

## Cast

- **Kailo**: Ahi, art/portraits/kailo-portrait-a.png
- **Hina**: La, art/portraits/hina-portrait-a.png
- **Maika**: Lau, art/portraits/maika-portrait-a.png

## Scene

**Maika:** Aloha! Lost? Everyone who finds me is lost.

**Maika** (if hina): But not everyone who finds me is so lovely. 'Awapuhi, miss? Pressed from the ginger flower this morning. Your hair would shine like moonlight on the reef.

**Hina** (if hina): My hair shines just fine on its own.

**Maika** (if alone): These woods are dangerous for a man alone. A wise man buys medicine.

**End:** His shop opens.

## Don't tell her

**Kailo:** Your sister's at the hunters' lodge. She's looking for you.

**Maika:** Miki. Here. Of course.

**Maika:** Listen, Kailo. A wise man doesn't run away. He relocates. Whatever she offered you for me, don't tell her where I am.

**Hina** (if hina): She's worried about you.

**Maika** (if hina): She is a great many things, Hina, and worried is the least of them.

**Maika:** Think about it. I'm here if you need medicine.

**End:** His shop opens.

## If you lied

**Maika:** A boat to the next island! She'll chase the tide for a week. You've got a gift, Kailo.

**Maika:** So what brings you all the way out here?

**Kailo** (if hina): We're going after the Great Boar.

**Kailo** (if alone): I'm going after the Great Boar.

**Maika:** The Great Boar? He's the other way. You went the wrong way.

**End:** Maika asks to come along.

## If you lied, after the Great Boar

**Maika:** A boat to the next island! She'll chase the tide for a week. You've got a gift, Kailo.

**Maika:** So what brings you all the way out here?

**Kailo** (if hina): We're looking for ingredients. I've got a stew to make.

**Kailo** (if alone): I'm looking for ingredients. I've got a stew to make.

**Maika:** In these woods? You'd walk right past half of them. I know every root and leaf out here.

**End:** Maika asks to come along.

## Maika asks to come along

Pygame only. Plays at the end of both lie scenes, and again on every talk until Kailo says yes
(Frankie, 11/11; Claude's drafts, for Frankie to rewrite).

**Maika** (if hina): A wise man never lets a lovely lady get lost. Or hungry. Or unaccompanied.

**Maika** (if alone): A wise man never lets a good friend get lost. Or hungry.

**Maika:** So. Do you want me along, Kailo? Or shall I go back to my stall and enjoy the quiet?

**Choice:** Does Kailo want Maika to join?

- We'd love to have you. → yes
- Not yet. Soon, okay? → no

**Maika** (if yes): Of course you do. Try not to get us lost.

**Hina** (if yes and hina): Then walk behind us.

**Maika** (if no): No? Hm. A wise man respects a closed door, Kailo. He just stands outside it, looking patient.

**Maika** (if no): Come back when you've remembered how lost you are.

**End:** Maika decides.


## If you told the truth

**Maika:** You told her.

**Hina** (if hina): She's your sister. She came all this way.

**Maika:** And I asked one thing of you, Kailo. One. A wise man remembers who sells him out.

**Maika:** I'm staying right here, thank you. Medicine, if you need it.

**End:** The shop stays.

## If you leave

**Maika:** A hui hou. Come back if you get hurt.

**End:** The shop stays.

## The first planting

**Maika:** Hina, you garden? Here. Plant this on a friend.

**Hina:** On a friend? Fine. But I'm not watering Kailo.

**Kailo** (if kailo along and first lontar due): There's your squiggly marks again.

**Hina** (if kailo along and first lontar due): They're not squiggles, Kailo. It's writing. The Bandari write everything down.

**Hina** (if kailo along and first lontar due): This is a lontar. They dry a palm leaf, scratch the letters in with a knife, and rub soot in so they show.

**Kailo** (if kailo along and first lontar due): So it's a leaf that knows a move.

**Hina** (if kailo along and first lontar due): A leaf that remembers one. Someone wrote down how it's done.

**Kailo** (if kailo along and first lontar due): Do they write recipes?

**Hina** (if kailo along and first lontar due): ...Yes, Kailo. They write recipes.

**Hina:** ...Wait. Maika, how did you know what this was?

**Maika:** Lucky guess.

Hina learned Green Dream!

**End:** Back to the garden.
