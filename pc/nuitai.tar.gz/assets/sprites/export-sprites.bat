@echo off
rem Double-click after saving in Aseprite: writes every .aseprite's frames into its walk folder for the game.
python "%~dp0..\..\..\art\sprites\walkers\export_aseprite.py"
echo.
pause
