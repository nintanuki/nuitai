"""Everything one person says that is not in their room file, for the Workshop's Edit Dialogue window
(Frankie, 11/13: right click a sprite, Edit dialogue, and see literally everything it says).

A person's own fields (``core/dialogue_text.py``) are in their room file. The rest of what they say is
kept elsewhere, so each is found here and shown as one more text box under a label saying when it is said:

* their ask menu (``data/asks/*.json``): the questions you can ask, and the answer to each;
* their shop's greeting (``data/shops/*.json``) and their hunts' lines (``data/bounties/*.json``);
* every row they speak in the story scripts and the field lines (``game/shared/story*.md``), grouped
  by the name the game reads it under (``STAKE_WIN``), or by scene.

An ``Extra`` is one box: ``text`` as shown, ``write(text)`` to put edits where they belong and save them.
Rows are edited in place, so a box keeps its number of lines; adding or removing a line is the Dialogue
editor's job (L). No pygame and no tkinter here: ``workshop_dialogue.py`` is the window.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from typing import Callable

from core import dialogue_editor as de
from core import dialogue_villagers as dv

PLACEHOLDER = de.PLACEHOLDER


@dataclass
class Extra:
    """One box in the window: what it is called, the text in it, and how a changed text is saved."""

    key: str
    heading: str
    text: str
    write: Callable[[str], None]


def _same_placeholders(old: str, new: str) -> None:
    if sorted(PLACEHOLDER.findall(old)) != sorted(PLACEHOLDER.findall(new)):
        names = ", ".join("{" + n + "}" for n in PLACEHOLDER.findall(old)) or "none"
        raise ValueError(f"Keep the words in curly brackets as they are ({names}); the game fills them in.")


def _save(document: de.Document) -> None:
    if document.save():
        raise ValueError("That file was changed somewhere else too. Open the Dialogue editor (L) to choose.")


def _nice(name: str) -> str:
    """``STAKE_WIN`` as ``stake win``; ``- say demand`` style names pass through."""
    return name.removesuffix("_LINES").removesuffix("_ALL").replace("_", " ").lower()


# ----------------------------------------------------------------------
# ROWS OF A SCRIPT
# ----------------------------------------------------------------------


def _rows_box(document: de.Document, rows: list[de.Row], key: str, heading: str) -> Extra:
    """A box of rows' words, one row a line, written back in place."""

    def write(text: str) -> None:
        lines = [" ".join(line.split()) for line in text.splitlines() if line.strip()]
        if len(lines) != len(rows):
            raise ValueError(f"{heading}: keep {len(rows)} line{'s' if len(rows) != 1 else ''} here. "
                             "To add or remove one, use the Dialogue editor (L).")
        for row, words in zip(rows, lines):
            if words != row.text:
                de.edit_row(document, row, row.speaker, words, row.cond)
        _save(document)

    return Extra(key, heading, "\n".join(row.text for row in rows), write)


def _blocks(document: de.Document, scene: de.Scene, speaker: str) -> list[tuple[str, list[de.Row]]]:
    """The rows ``speaker`` says in ``scene``, grouped under the ``- NAME`` they are read by (or none)."""
    blocks: list[tuple[str, list[de.Row]]] = []
    name = ""
    for index in range(scene.start + 1, scene.stop):
        row = de.read_row(index, document.lines[index])
        if row is None:
            continue
        if row.kind == "stage" and row.text.startswith("- "):
            name = row.text[2:].strip()
        elif row.kind == "say" and row.speaker == speaker:
            if not blocks or blocks[-1][0] != name:
                blocks.append((name, []))
            blocks[-1][1].append(row)
    return blocks


def script_extras(speaker: str, library: de.Library) -> list[Extra]:
    out = []
    for file in de.script_files():
        document = library.script(file)
        for scene in de.scenes_of(file, document.lines):
            for name, rows in _blocks(document, scene, speaker):
                if file == de.FIELD_FILE:
                    # The field lines are read by name, so the first row's index is the box's key.
                    heading = f"{scene.title}: {_nice(name)}" if name else scene.title
                else:
                    heading = f"Scene: {scene.title}"
                out.append(_rows_box(document, rows, f"{file}:{rows[0].index}", heading))
    return out


# ----------------------------------------------------------------------
# THE ASK MENU
# ----------------------------------------------------------------------


def _replace_json_values(path: str, key: str, old: list, new: list) -> None:
    """Swap each ``"key": old[i]`` for ``new[i]`` in the file's text, so nothing else in it moves."""
    with open(path, encoding="utf-8", newline="") as f:
        text = f.read()
    escaped = "\\u" in text
    for before, after in zip(old, new):
        if before == after:
            continue
        a = f'"{key}": {json.dumps(before, ensure_ascii=escaped)}'
        b = f'"{key}": {json.dumps(after, ensure_ascii=escaped)}'
        if a not in text:
            raise ValueError(f"{os.path.basename(path)} changed since it was opened. Close this window and open it again.")
        text = text.replace(a, b, 1)
    de._write(path, text)


def ask_extras(person: dict, library: de.Library) -> list[Extra]:
    name = person.get("ask")
    path = dv.path_of(f"asks/{name}.json") if name else ""
    if not name or not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        questions = [q["ask"] for q in json.load(f).get("questions", [])]
    out = []

    def write_questions(text: str) -> None:
        lines = [" ".join(line.split()) for line in text.splitlines() if line.strip()]
        if len(lines) != len(questions):
            raise ValueError(f"Keep {len(questions)} questions here.")
        _replace_json_values(path, "ask", questions, lines)
        questions[:] = lines

    out.append(Extra(f"asks/{name}:questions", "Ask menu: the questions you can pick (one per row)",
                     "\n".join(questions), write_questions))
    document = library.script(f"asks/{name}.json")
    for scene in de.scenes_of(f"asks/{name}.json", document.lines):
        rows = [r for r in de.rows_of(document, scene) if r.kind == "say"]
        if rows:
            out.append(_rows_box(document, rows, f"asks/{name}:{scene.start}", f"Ask menu, you ask \"{scene.title}\": the answer"))
    return out


# ----------------------------------------------------------------------
# A SHOP'S GREETING AND A HUNT BOARD'S LINES
# ----------------------------------------------------------------------


def _read_json(folder: str, name: str) -> tuple[str, dict]:
    path = os.path.join(dv.DATA_DIR, folder, f"{name}.json")
    if not os.path.exists(path):
        return path, {}
    with open(path, encoding="utf-8") as f:
        return path, json.load(f)


def shop_extras(person: dict) -> list[Extra]:
    name = person.get("shop")
    path, data = _read_json("shops", name) if name else ("", {})
    if not data.get("greeting"):
        return []
    state = [data["greeting"]]

    def write(text: str) -> None:
        words = " ".join(text.split())
        if not words:
            raise ValueError("The greeting needs words.")
        _replace_json_values(path, "greeting", state, [words])
        state[0] = words

    return [Extra(f"shops/{name}:greeting", "Shop: what they say as it opens", state[0], write)]


def bounty_extras(person: dict) -> list[Extra]:
    name = person.get("bounties")
    path, data = _read_json("bounties", name) if name else ("", {})
    lines = data.get("lines")
    if not lines:
        return []
    keys = list(lines)

    def show(value) -> str:
        return " | ".join(value) if isinstance(value, list) else value

    def write(text: str) -> None:
        rows = [row.strip() for row in text.splitlines() if row.strip()]
        if len(rows) != len(keys):
            raise ValueError(f"Keep {len(keys)} rows here, one for each line of the hunt board.")
        for key, row in zip(keys, rows):
            body = row.partition(":")[2].strip() if row.partition(":")[0].strip() == key else row
            new = [part.strip() for part in body.split("|")] if isinstance(lines[key], list) else body
            if not new or new == [""]:
                raise ValueError(f"{key} needs words.")
            if isinstance(new, str):
                _same_placeholders(lines[key], new)
            _replace_json_values(path, key, [lines[key]], [new])
            lines[key] = new

    text = "\n".join(f"{key}: {show(value)}" for key, value in lines.items())
    return [Extra(f"bounties/{name}", "Hunts: the keeper's words, one row each (the word before the colon says "
                                      "when; answers sit apart with | between)", text, write)]


# ----------------------------------------------------------------------
# ALL OF IT
# ----------------------------------------------------------------------


def extras_for(person: dict, library: de.Library | None = None) -> list[Extra]:
    """Every box of what ``person`` says outside their room file, in the order the window shows them."""
    library = library or de.Library()
    out = ask_extras(person, library) + shop_extras(person) + bounty_extras(person)
    if person.get("speaker"):
        out += script_extras(person["speaker"], library)
    return out
