"""The rooms of the map, read from ``data/cells/<name>.json``.

The map is screens: every room is one screen of 16 by 14 tiles (D-444),
and walking off an edge puts the party in the room next door. Each room
is its own file, written by the Workshop (``workshop.py``) and read here;
the cartridge build (``game/snes/tools/make_art.py``) reads the same
rooms through this module.

A room file holds:

* ``id``: the room's name, also the file's name.
* ``pos``: ``[cx, cy]`` on the world grid, cx growing east and cy south.
* ``grid``: 14 strings of 16 characters, the tile alphabet below.
* ``people``: who stands in it, each ``col``, ``row``, ``facing`` as
  ``[dx, dy]``, ``sheet`` (a walk sheet's id, ``utils/sprite_files.py``) and,
  for a shopkeeper, the ``shop`` that talking to them opens; ``lines`` (said under ``speaker``) for anyone
  else talked to, one a talk, round and round (Frankie, 10/26), a ``talk`` entry playing whole; ``spar`` for the two villagers sparring in town;
  ``night``, the story scene they ask about at night (Melia and the
  wake, ``StorySettings``); ``home``, kept in the village at night too,
  saying their ``night_lines`` then (Kailo's cousins); ``joins``, the member they are, gone from the
  map while in the party; ``scene``, the story scene talking to them plays
  (Hina at home); ``gone``, a party flag that takes them off the map for good
  (Melia and Keo's day spot, the morning after the jump); ``boat``, Ama's job
  mending the Meialana after the demo. A person blocks like a wall.
* ``monsters``: the monsters seen in it (D-576), each ``col``, ``row`` and
  ``kind`` from ``data/field_monsters/``; ``still`` stands without
  wandering, ``leash`` keeps it within that many tiles of its start (so it cannot
  drift into a corridor that leads to a person), a ``boss`` is gone for good once beaten, ``faces_left`` sets
  which way it looks, and one marked ``night`` walks only at night (the Sigbin in
  Kulāiwi's painted woods, Frankie, 10/28). Everything else comes back when the party walks
  into the room again.
* ``buildings``: the houses and dressing standing on the tiles, each
  ``col``, ``row`` (its top left tile) and ``kind`` from
  ``OverworldSettings.BUILDINGS``. A building blocks every tile it
  covers; a tall one (the Meialana) rises over the tiles behind it
  without blocking them. A chest has the ``item`` it holds, or ``random``, the kind of
  thing picked when it is opened (``ItemSettings.CHEST_RANDOM``), or
  both; ``also`` lists more items, ``picks`` (low, high) how many times
  ``random`` is picked, ``before`` what Kailo says before it opens and
  ``line`` what he says after.
  A bed has an ``owner``; only Kailo's (``TownSettings.OWN_BED``) naps,
  and Hina scolds at any other. A ``totem`` is a save point (Frankie, 10/26). Left out of a file with none.

Tile alphabet, kept in sync with ``OverworldSettings.*_CHAR`` in
[settings.py](../settings.py):

* ``'.'`` walkable floor (grass).
* ``'#'`` wall (a palm over grass).
* ``'~'`` impassable water.
* ``'_'`` walkable sand.
* ``'o'`` the rest stop pond (D-525): blocks like water, and heals and
  heals the standing when faced and confirmed; the knocked out stay down.
* ``'m'`` a market stall (D-571): blocks, and opens the shop when faced
  and confirmed.
* ``'f'`` woven mats, the floor inside a house; ``'w'`` the wall around
  an inside room and ``'v'`` the black around it, both blocking.
* ``'='`` the harbor's pier (Frankie, 10/27): wooden planks over the
  water, walked on like sand (``ui/pier.py`` draws it).
* ``'a'`` ``'b'`` stone stairs (front, side) and ``'c'`` ``'d'`` wood stairs
  (Frankie, 11/5): walked on like sand. A room file's ``stairs`` list makes one lead
  somewhere (the temple's up to the school, Frankie, 11/10): stepping onto it at once
  lands on the ``to_col``, ``to_row`` tile of the ``to`` room, next to the stairs there.

A building with a door (``OverworldSettings.DOORS``) and an ``inside``
leads into that room; ``warps`` lists every way in and out. An inside
room sits on the world grid like any other, far below the map
(``INSIDE_ROW``) and two apart, so no two join.

The module keeps the rooms in five dicts that the rest of the game
imports: ``CELLS`` (name to its 14 by 16 grid of characters), ``PEOPLE``,
``FIELD_MONSTERS`` (name to its list of spots), ``BUILDINGS`` and ``WORLD_LAYOUT``
(``(cx, cy)`` to name). ``load_cells`` fills them in place, so a module
that imported them before a reload sees the new rooms too.
"""

from __future__ import annotations

import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CELLS_DIR = os.path.join(ROOT, "data", "cells")

# The rooms, filled by ``load_cells`` below. Kept as the same dict objects
# for the life of the program, so every importer shares them.
CELLS: dict[str, list[list[str]]] = {}
PEOPLE: dict[str, list[dict]] = {}
FIELD_MONSTERS: dict[str, list[dict]] = {}
BUILDINGS: dict[str, list[dict]] = {}
# Stairs between rooms: room name to its stairs, each ``col``, ``row`` and the ``to`` room with
# the ``to_col``, ``to_row`` it lands on (the tile in front of the stairs up there, so the stairs
# are behind and stepping back onto them goes down). ``facing`` in old files is ignored.
STAIRS: dict[str, list[dict]] = {}
# cx grows east, cy grows south.
WORLD_LAYOUT: dict[tuple[int, int], str] = {}

# Room the player spawns into on a new game. ``OverworldPlayer.__init__``
# uses ``OverworldPlayerSettings.SPAWN_COL`` / ``SPAWN_ROW`` for the
# within-room tile.
START_CELL_POS: tuple[int, int] = (0, 0)
# The world row the insides of buildings sit on.
INSIDE_ROW = 40


class CellFileError(ValueError):
    """A room file is missing something or has the wrong shape."""


def _grid_size() -> tuple[int, int]:
    """Columns and rows of a room, from settings (imported lazily)."""
    from settings import OverworldSettings

    return OverworldSettings.COLS, OverworldSettings.ROWS


def building_footprint(building: dict) -> set[tuple[int, int]]:
    """Every tile a building covers, even those off the room: a house can hang its
    roof off the top (Frankie, 10/29)."""
    from settings import OverworldSettings

    width, height = OverworldSettings.BUILDINGS[building["kind"]][1]
    return {(building["col"] + dx, building["row"] + dy)
            for dx in range(width) for dy in range(height)}


def building_tiles(building: dict) -> set[tuple[int, int]]:
    """Every tile a building covers that is on the room: what blocks, what is drawn on the map."""
    from settings import OverworldSettings

    return {(c, r) for c, r in building_footprint(building)
            if 0 <= c < OverworldSettings.COLS and 0 <= r < OverworldSettings.ROWS}


def blocking_tiles(name: str) -> set[tuple[int, int]]:
    """Every tile the buildings of room ``name`` block (a rug does not)."""
    from settings import OverworldSettings

    tiles: set[tuple[int, int]] = set()
    for building in BUILDINGS.get(name, []):
        if building["kind"] not in OverworldSettings.FLAT_BUILDINGS:
            tiles |= building_tiles(building)
    return tiles


def door_gap(name: str) -> int | None:
    """The column of the gap in an inside room's bottom wall, or None."""
    from settings import OverworldSettings

    bottom = CELLS[name][-1]
    return next((c for c, ch in enumerate(bottom) if ch in OverworldSettings.WALKABLE_CHARS), None)


def room_offset(grid: list[list[str]]) -> tuple[int, int]:
    """How far to draw a room so the part that is not black sits in the middle of the screen.

    An inside room is a smaller room in the black (Frankie, 10/24: centered,
    not in the corner); an outside room has no black, so it stays where it is.
    The game and the cartridge build both place rooms by it.
    """
    from settings import GridSettings, OverworldSettings

    void = OverworldSettings.VOID_CHAR
    cols = [c for row in grid for c, char in enumerate(row) if char != void]
    rows = [r for r, row in enumerate(grid) if any(char != void for char in row)]
    if not cols:
        return 0, 0
    tile_size = GridSettings.TILE_SIZE
    across = (OverworldSettings.COLS - (max(cols) - min(cols) + 1)) * tile_size // 2 - min(cols) * tile_size
    down = (OverworldSettings.ROWS - (max(rows) - min(rows) + 1)) * tile_size // 2 - min(rows) * tile_size
    return across, down


def warps() -> dict[tuple[str, int, int, tuple[int, int]], tuple[str, int, int]]:
    """Every door: ``(room, col, row, facing)`` stepping that way to ``(room, col, row)``.

    In: standing below a building's door, facing up, to the gap in its
    inside room. Out: standing on that gap, facing down, back below the door.
    """
    from settings import OverworldSettings

    found = {}
    for name, spots in BUILDINGS.items():
        for building in spots:
            inside = building.get("inside")
            door = OverworldSettings.DOORS.get(building["kind"])
            if not inside or door is None or inside not in CELLS:
                continue
            gap = door_gap(inside)
            if gap is None:
                continue
            below = (building["col"] + door[0], building["row"] + door[1] + 1)
            bottom = OverworldSettings.ROWS - 1
            found[(name, *below, (0, -1))] = (inside, gap, bottom)
            found[(inside, gap, bottom, (0, 1))] = (name, *below)
    return found


def stair_targets() -> dict[tuple[str, int, int], tuple[str, int, int]]:
    """Every stair that leads somewhere: ``(room, col, row)`` of the stairs to ``(room, col, row)`` to land on.

    Stepping onto the stairs goes at once, up or down; no pushing into the wall (Frankie, 11/10).
    """
    return {(name, stair["col"], stair["row"]): (stair["to"], stair["to_col"], stair["to_row"])
            for name, spots in STAIRS.items() for stair in spots if stair["to"] in CELLS}


def validate_grid(name: str, grid: list[list[str]]) -> None:
    """Fail loudly if ``grid`` is not a full 16 by 14 room.

    Catches the easy authoring mistake of dropping or adding one
    character on a row, which would otherwise misalign the grid
    diagonally as soon as the player steps into that row.
    """
    cols, rows = _grid_size()
    if len(grid) != rows:
        raise CellFileError(f"Room {name!r} has {len(grid)} rows; expected {rows}.")
    for row_index, row in enumerate(grid):
        if len(row) != cols:
            raise CellFileError(
                f"Room {name!r} row {row_index} has {len(row)} cols; expected {cols}."
            )


def cell_path(name: str, directory: str = CELLS_DIR) -> str:
    """The file a room is kept in."""
    return os.path.join(directory, f"{name}.json")


def read_cell_file(path: str) -> dict:
    """Read one room file and check its shape; the grid comes back as rows of characters."""
    with open(path, "r", encoding="utf-8") as f:
        try:
            entry = json.load(f)
        except json.JSONDecodeError as error:
            raise CellFileError(f"{path}: invalid JSON ({error})") from error
    if not isinstance(entry, dict) or "id" not in entry:
        raise CellFileError(f"{path}: missing 'id'")
    name = entry["id"]
    pos = entry.get("pos")
    if not (isinstance(pos, list) and len(pos) == 2):
        raise CellFileError(f"{path}: 'pos' must be [cx, cy]")
    grid_rows = entry.get("grid")
    if not isinstance(grid_rows, list):
        raise CellFileError(f"{path}: 'grid' must be a list of rows")
    grid = [list(row) for row in grid_rows]
    validate_grid(name, grid)
    return {
        "id": name,
        "pos": (int(pos[0]), int(pos[1])),
        "grid": grid,
        "people": list(entry.get("people", [])),
        "monsters": list(entry.get("monsters", [])),
        "buildings": list(entry.get("buildings", [])),
        "stairs": list(entry.get("stairs", [])),
    }


def load_cells(directory: str = CELLS_DIR) -> None:
    """Read every room file in ``directory`` into the module's dicts, in place.

    Two rooms on the same world position is an authoring mistake and
    raises, since the game could only ever reach one of them.
    """
    cells: dict[str, list[list[str]]] = {}
    people: dict[str, list[dict]] = {}
    monsters: dict[str, list[dict]] = {}
    buildings: dict[str, list[dict]] = {}
    stairs: dict[str, list[dict]] = {}
    layout: dict[tuple[int, int], str] = {}
    if os.path.isdir(directory):
        for file_name in sorted(os.listdir(directory)):
            if not file_name.endswith(".json"):
                continue
            entry = read_cell_file(os.path.join(directory, file_name))
            name = entry["id"]
            if entry["pos"] in layout:
                raise CellFileError(
                    f"Rooms {layout[entry['pos']]!r} and {name!r} both sit at {entry['pos']}."
                )
            cells[name] = entry["grid"]
            people[name] = entry["people"]
            monsters[name] = entry["monsters"]
            buildings[name] = entry["buildings"]
            stairs[name] = entry["stairs"]
            layout[entry["pos"]] = name
    for shared, fresh in ((CELLS, cells), (PEOPLE, people),
                          (FIELD_MONSTERS, monsters), (BUILDINGS, buildings),
                          (STAIRS, stairs), (WORLD_LAYOUT, layout)):
        shared.clear()
        shared.update(fresh)


def cell_to_dict(name: str) -> dict:
    """The room as it is written to its file."""
    pos = next((pos for pos, who in WORLD_LAYOUT.items() if who == name), None)
    if pos is None:
        raise KeyError(f"Room {name!r} has no position.")
    entry = {
        "id": name,
        "pos": list(pos),
        "grid": ["".join(row) for row in CELLS[name]],
        "people": PEOPLE.get(name, []),
        "monsters": FIELD_MONSTERS.get(name, []),
    }
    if BUILDINGS.get(name):
        entry["buildings"] = BUILDINGS[name]
    if STAIRS.get(name):
        entry["stairs"] = STAIRS[name]
    return entry


def _format(entry: dict) -> str:
    """Write a room file so a person can read it: one grid row per line, one thing per line."""
    lines = ["{", f'  "id": {json.dumps(entry["id"])},', f'  "pos": {json.dumps(entry["pos"])},',
             '  "grid": [']
    rows = entry["grid"]
    for index, row in enumerate(rows):
        comma = "," if index < len(rows) - 1 else ""
        lines.append(f"    {json.dumps(row)}{comma}")
    lines.append("  ],")
    for key in ("people", "monsters", "buildings", "stairs"):
        if key not in entry:
            continue
        things = entry[key]
        if not things:
            lines.append(f'  "{key}": [],')
            continue
        lines.append(f'  "{key}": [')
        for index, thing in enumerate(things):
            comma = "," if index < len(things) - 1 else ""
            lines.append(f"    {json.dumps(thing)}{comma}")
        lines.append("  ],")
    lines[-1] = lines[-1].rstrip(",")
    lines.append("}")
    return "\n".join(lines) + "\n"


def save_cell(name: str, directory: str = CELLS_DIR) -> str:
    """Write one room to its file, with LF line endings on every machine; returns the path."""
    validate_grid(name, CELLS[name])
    os.makedirs(directory, exist_ok=True)
    path = cell_path(name, directory)
    with open(path, "wb") as f:
        f.write(_format(cell_to_dict(name)).encode("utf-8"))
    return path


load_cells()
