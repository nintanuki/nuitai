"""The demo's two story scenes, read from the scripts in ``game/shared/``.

``story.md`` (the taro patch), ``story-hina.md`` and
``story-hina-woods.md`` (Hina joining, in her house or catching up), ``story-maika.md`` (meeting Maika,
in six small scenes), ``story-sister.md`` (his sister in the hunters' lodge), ``story-deep-woods.md`` (Hina or Maika warning Kailo off the deep woods), ``story-sage-village.md`` (Maika turning the party back from the Maki Sages' village), ``story-great-boar.md`` (the question before his fight), ``story-boar.md`` (the Great
Boar falls), ``story-tusk.md`` (Kailo gives Melia the tusk), ``story-kaigara.md`` (the Kame's shell game) and ``story-wake.md`` (Old Pono's wake) are the one place their
dialogue is written (the rules for writing a script are at the top
of ``story.md``). This module turns a script into
steps and walks them; ``OverworldScene`` shows each step over the field
(the text box, the choice box, the fight) and does what the demo adds
around them (the demo line in ``game/answers.md``).

Only what the demo plays is read: the scene, ``If you win`` and ``If you
lose``, and the stage directions that act it out on the map (``Room``,
``Stand``, ``Walk``, ``Run``, ``Turn``, ``Fall``, ``core/staging.py``
plays them; ``Fade`` and ``Wait``, the overworld).
The place, background, music and card are the browser's.
"""

from __future__ import annotations

import os
import re
from typing import Any

from core.shared import SHARED_DIR, by_id
from settings import KaigaraSettings, UISettings

# The demo's scenes by name, and the script each is read from.
SCRIPTS: dict[str, str] = {
    "taro_patch": "story.md",
    "wake": "story-wake.md",
    "hina_joins": "story-hina.md",
    "hina_woods": "story-hina-woods.md",
    # One file, four scenes: after ``#`` the heading a scene starts under;
    # without one, the file's ``## Scene`` up to its next heading.
    "maika_meets": "story-maika.md",
    "maika_joins": "story-maika.md#If you lied",
    "maika_leaves": "story-maika.md#If you leave",
    "maika_seed": "story-maika.md#The first planting",
    "deep_woods_hina": "story-deep-woods.md#Hina warns",
    "deep_woods_maika": "story-deep-woods.md#Maika warns",
    "sage_village_maika": "story-sage-village.md#Maika along",
    "sage_village_stall": "story-sage-village.md#Maika at his stall",
    "great_boar_ready": "story-great-boar.md",
    "boar_falls": "story-boar.md",
    "melia_tusk": "story-tusk.md",
}
# The Kaigara Kame's scenes (10/27), kept out of ``SCRIPTS``, whose scenes the
# cartridge's stage gives a bit each (at most 16); its art build compiles these after them.
PYGAME_SCRIPTS: dict[str, str] = {
    # Maika's recruiting, rebuilt on his sister (Frankie, 10/30); the cartridge is caught up later.
    "maika_asks": "story-maika.md#Don't tell her",
    "maika_cross": "story-maika.md#If you told the truth",
    "maika_joins_late": "story-maika.md#If you lied, after the Great Boar",  # Frankie, 11/2
    "maika_invites": "story-maika.md#Maika asks to come along",  # yes or no, asked until yes (Frankie, 11/11)
    "after_jump": "story-after-jump.md",  # after the demo: Ama's rescue, the chief's hut (Frankie, 10/31)
    "stew_cooks": "story-stew.md",  # Noelani and Kailo cook the stew (Frankie, 10/30)
    "noelani_charmed": "story-noelani.md",  # Maika flirts with Noelani over the wallet (Frankie, 11/12)
    "maika_east": "story-maika.md#East way",  # before he goes missing, the way east out of his room (Frankie, 11/12)
    "maika_clearing": "story-maika.md#The clearing",  # found in the deep forest, the Kapre fight, "don't tell her" (Frankie, 11/12)
    "deep_woods_hina_missing": "story-deep-woods.md#Hina warns, Maika missing",
    "sister_asks": "story-sister.md",
    "sister_report": "story-sister.md#The report",
    "kaigara_meet": "story-kaigara.md",
    "kaigara_menu": "story-kaigara.md#His questions",
    "kaigara_home": "story-kaigara.md#Where he is from",
    "kaigara_trip": "story-kaigara.md#How he got here",
    "kaigara_what": "story-kaigara.md#What Kaigara is",
    "kaigara_first_win": "story-kaigara.md#The first win",
    "kaigara_win": "story-kaigara.md#You win",
    "kaigara_lose": "story-kaigara.md#He wins",
    "kaigara_draw": "story-kaigara.md#A draw",
}

WIN, LOSE = "If you win", "If you lose"
# What every scene knows before it starts, who is along (``party_flag``):
# ``(if hina)`` lines play with Hina in the party, ``(if maika)`` with
# Maika but not Hina, ``(if alone)`` with Kailo by himself.
WITH_HINA, WITH_MAIKA, ALONE = "hina", "maika", "alone"

# The stage directions (``_stage``).
STAGE_DIRECTIONS = ("Room", "Stand", "Walk", "Run", "Turn", "Fade", "Wait", "Fall", "Song")
# A line that starts with this types out fast (``"fast"`` on its step).
FAST = "(fast)"
# A line that starts with this types quicker than usual but not fast, and is
# cut off on a dash like a fast one (Frankie, 10/25: Hina's at the wake).
QUICK = "(quick)"
# A line that starts with this types out slowly, and the button cannot hurry
# it (``"hold"`` on its step): the Kame (Frankie, 10/26).
SLOW = "(slow)"
# The facings a direction word names, as (dx, dy).
FACINGS: dict[str, tuple[int, int]] = {"down": (0, 1), "up": (0, -1), "left": (-1, 0), "right": (1, 0)}
# An edge of the room as a stop: one tile past it, the other coordinate
# None (the row or column the walker is in).
EDGES: dict[str, tuple[int | None, int | None]] = {
    "east": (16, None), "west": (-1, None), "north": (None, -1), "south": (None, 14),
}


def _element(word: str) -> str:
    """An element as the battle names it: the eastern Ahi is the battle's Afi."""
    word = word.lower()
    return "afi" if word == "ahi" else word


def _sprite_for(name: str, monster: str) -> str:
    """A foe named after a sprite gets that sprite ("Wicked Dwende"), else its monster's first."""
    sprite_of: dict[str, str] = {}
    sprites: set[str] = set()
    for encounter in by_id("encounters").values():
        for entry in encounter["enemies"]:
            sprite_of.setdefault(entry["monster"], entry.get("sprite"))
            sprites.add(entry.get("sprite"))
    slug = re.sub(r"\s+[A-Z]$", "", name.strip()).lower().replace(" ", "_")
    return slug if slug in sprites else sprite_of.get(monster, monster)


def _place(words: str) -> tuple[int | None, int | None]:
    """A tile, ``"5,6"``, or an edge, ``"the east edge"``."""
    words = words.strip()
    edge = re.fullmatch(r"the (\w+) edge", words)
    if edge:
        return EDGES[edge[1]]
    col, row = words.split(",")
    return int(col), int(row)


def _stage(who: str, rest: str) -> dict[str, Any]:
    """A stage direction as a step (the rules at the top of ``story.md``).

    ``{"room"}``; ``{"fade"}``, ``"out"`` or ``"in"``; ``{"wait"}``, seconds;
    ``{"song"}``, the name of one of Frankie's pieces in ``music/snes/``;
    ``{"fall"}``, the names; ``{"stand"}``, ``{"move"}`` (with ``"run"``) and
    ``{"turn"}`` each hold a list, one entry per person on the line:
    ``{"who", "col", "row", "facing"}``; ``{"who", "start", "stops"}``
    (``start`` None to set off from where they are); ``{"who", "facing"}``
    or ``{"who", "toward"}``.
    """
    if who == "Room":
        return {"room": rest.strip()}
    if who == "Fade":
        return {"fade": rest.strip()}
    if who == "Wait":
        return {"wait": float(rest)}
    if who == "Song":
        # Its file's name: "Voices of the Past" is voices-of-the-past.it.
        return {"song": re.sub(r"[^a-z0-9]+", "-", rest.strip().lower()).strip("-")}
    if who == "Fall":
        return {"fall": re.split(r",\s*", rest.strip())}
    entries: list[dict[str, Any]] = []
    for part in rest.split(";"):
        part = part.strip()
        if who == "Stand":
            m = re.fullmatch(r"(.+?) at (-?\d+),(-?\d+) facing (\w+)", part)
            entries.append({"who": m[1], "col": int(m[2]), "row": int(m[3]), "facing": FACINGS[m[4]]})
        elif who == "Turn":
            names, target = re.fullmatch(r"(.+?) (to .+|up|down|left|right)", part).groups()
            for name in re.split(r",\s*", names):
                if target.startswith("to "):
                    entries.append({"who": name, "toward": target[3:]})
                else:
                    entries.append({"who": name, "facing": FACINGS[target]})
        else:
            m = re.fullmatch(r"(.+?)(?: from (.+?))? to (.+)", part)
            stops = [_place(stop) for stop in m[3].split(" to ")]
            start = None
            if m[2]:
                col, row = _place(m[2])
                # From an edge: in the row or column of the first stop.
                start = (stops[0][0] if col is None else col, stops[0][1] if row is None else row)
            entries.append({"who": m[1], "start": start, "stops": stops})
    key = {"Stand": "stand", "Turn": "turn"}.get(who, "move")
    step: dict[str, Any] = {key: entries}
    if key == "move":
        step["run"] = who == "Run"
    return step


# A fight line's ending, ``; preemptive strike`` or ``; ambush``: who starts at full fatigue (Frankie, 10/27).
OPENINGS = {"preemptive strike": "preemptive", "ambush": "ambush"}


def read_script(text: str) -> list[dict[str, Any]]:
    """Turn a script into steps.

    A step is one of: ``{"say", "text"}`` someone talking (with ``"if"``
    when it plays only after a choice), ``{"text"}`` narration,
    ``{"choice", "options"}`` with ``(label, flag)`` pairs,
    ``{"fight"}`` the enemies as ``BattleScene`` takes them,
    ``{"label"}`` where ``If you win`` or ``If you lose`` starts,
    ``{"end"}``, and the stage directions (``_stage``), which also carry
    ``"if"`` when they play only for some.
    """
    steps: list[dict[str, Any]] = []
    section = None
    choice = None
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("# "):
            continue
        if line.startswith("## "):
            section = line[3:]
            if section not in ("Cast", "Scene", "Foes"):
                steps.append({"label": section})
            continue
        if section in (None, "Cast", "Foes"):
            continue
        if choice is not None and line.startswith("- "):
            label, _, flag = line[2:].partition("→")
            choice["options"].append((label.strip(), flag.strip()))
            continue
        choice = None
        match = re.match(r"\*\*(.+?)(?::\*\*|\*\*\s*\(if ([\w ]+?)\):)\s*(.*)", line)
        if not match:
            steps.append({"text": line})
            continue
        who, flag, rest = match[1], match[2], match[3]
        if who in ("Place", "Background", "Music", "Card"):
            continue
        if who in STAGE_DIRECTIONS:
            step = _stage(who, rest)
            if flag:
                step["if"] = flag
            steps.append(step)
        elif who == "End":
            steps.append({"end": rest})
        elif who == "Choice":
            choice = {"choice": rest, "options": []}
            steps.append(choice)
        elif who == "Fight":
            rest, _, opening = rest.partition(";")
            foes = rest.partition(" against ")[2]
            steps.append({"opening": OPENINGS.get(opening.strip().lower()), "fight": [
                {"id": f"story_{index}", "name": name.strip(), "monster": monster,
                 "element": _element(element), "sprite": sprite or _sprite_for(name, monster)}
                for index, (name, monster, element, sprite)
                in enumerate(re.findall(r"([^,(]+?)\s*\((\w+),\s*(\w+)(?:,\s*(\w+))?\)", foes))
            ]})
        else:
            step = {"say": who, "text": rest}
            if rest.startswith(FAST):
                step["text"], step["fast"] = rest[len(FAST):].strip(), True
            elif rest.startswith(SLOW):
                step["text"], step["hold"] = rest[len(SLOW):].strip(), True
                step["speed"] = KaigaraSettings.SLOW_CHARS_PER_SECOND
            elif rest.startswith(QUICK):
                step["text"], step["fast"] = rest[len(QUICK):].strip(), True
                step["speed"] = UISettings.TYPEWRITER_CHARS_PER_SECOND * UISettings.QUICK_TEXT_TIMES
            if flag:
                step["if"] = flag
            steps.append(step)
    return steps


def script(name: str) -> str:
    """The file (and ``#`` heading) scene ``name`` is read from."""
    return SCRIPTS[name] if name in SCRIPTS else PYGAME_SCRIPTS[name]


def load(name: str) -> list[dict[str, Any]]:
    """The steps of the demo scene ``name`` (``SCRIPTS``).

    A file of several scenes (``story-maika.md``) is cut at its headings:
    ``If you win`` and ``If you lose`` belong to the scene above them, any
    other heading starts a scene of its own.
    """
    source, _, part = script(name).partition("#")
    with open(os.path.join(SHARED_DIR, source), encoding="utf-8") as f:
        steps = read_script(f.read())
    if part:
        steps = steps[next(k for k, step in enumerate(steps) if step.get("label") == part) + 1:]
    end = next((k for k, step in enumerate(steps) if step.get("label") not in (None, WIN, LOSE)), len(steps))
    return steps[:end]


def party_flag(party) -> str:
    """The flag a scene starts with, who is along: Hina, else Maika, else nobody (``WITH_HINA``)."""
    if party.find("hina") is not None:
        return WITH_HINA
    return WITH_MAIKA if party.find("maika") is not None else ALONE


def cast(name: str) -> list[str]:
    """The names in the ``## Cast`` of scene ``name``: who it may put on the map."""
    with open(os.path.join(SHARED_DIR, script(name).partition("#")[0]), encoding="utf-8") as f:
        lines = [line.strip() for line in f]
    section, names = None, []
    for line in lines:
        if line.startswith("## "):
            section = line[3:]
        elif section == "Cast" and line.startswith("- **"):
            names.append(line[4:].split("**")[0])
    return names


class StoryRunner:
    """Walk one scene's steps: what to show next, a choice made, a fight's end.

    ``next_step`` hands back the next step to show, skipping lines whose
    choice was not made and any ``skip`` test the demo adds, and None once
    the part being played is over (an ``End``, or the next ``If you...``).
    """

    def __init__(self, name: str, skip=None) -> None:
        """Start scene ``name`` at its top.

        Args:
            name: A key of ``SCRIPTS``.
            skip: Called with a step; True leaves it out (the demo's own
                tests, such as a line that needs someone in the party).
        """
        self.name = name
        self.steps = load(name)
        self.index = 0
        self.flags: set[str] = set()
        self.part = "scene"          # "scene", then WIN or LOSE after the fight
        self._fight_at: int | None = None
        self.ended = ""              # the words of the End the scene reached ("TO BE CONTINUED")
        self.song: str | None = None   # a Song playing over the scene, until its fight is won
        self._skip = skip or (lambda step: False)

    def next_step(self) -> dict[str, Any] | None:
        """The next step to show, or None when this part has ended."""
        while self.index < len(self.steps):
            step = self.steps[self.index]
            self.index += 1
            if "label" in step or "end" in step:
                self.ended = step.get("end", "")
                self.index = len(self.steps)
                return None
            if step.get("if") and not self._holds(step["if"]):
                continue
            if self._skip(step):
                continue
            if "fight" in step:
                self._fight_at = self.index - 1
            return step
        return None

    def _holds(self, flag: str) -> bool:
        """Whether a step's ``if`` holds: "maika not along" holds without "maika along";
        "maika along and hina along" when both do (the Kaigara Kame's, 10/27)."""
        if " and " in flag:
            return all(self._holds(part) for part in flag.split(" and "))
        if " not " in flag:
            return flag.replace(" not ", " ") not in self.flags
        return flag in self.flags

    def choose(self, flag: str) -> None:
        """Remember a choice, for the lines that play only after it."""
        self.flags.add(flag)

    def fought(self, won: bool) -> None:
        """Carry on at ``If you win`` or ``If you lose``; a win ends the scene's Song."""
        self.part = WIN if won else LOSE
        if won:
            self.song = None
        self.index = next(
            index + 1 for index, step in enumerate(self.steps) if step.get("label") == self.part
        )

    def retry(self) -> None:
        """Back to the fight, to try it again (after losing it)."""
        self.part = "scene"
        self.index = self._fight_at if self._fight_at is not None else 0
