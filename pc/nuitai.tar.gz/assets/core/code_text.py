"""The words the game's own code holds, found and changed in place, for the Workshop's Game text window (Frankie, 11/22).

Most of what a player reads is in data files the Workshop opens: the story scripts and the field lines
(``game/shared/story*.md``), the rooms and menus (``data/``), ``battle.json``. What is left is in the
code: item and Skill names, the quest log, the battle's messages, the menus' labels. This module lists
those, each by where it is (``settings.py``, the class or function it sits in, and which words there),
and writes a changed one back into the file, in its own place, so no line of code moves and nothing is
kept in two places. The key of a piece of text is its place, not its words, so it stays the same when
someone rewrites the words.

What counts as a piece of text: a string in the code that has a space and letters in it (a sentence
or a name), or one capitalized word (a label), that is not a key, a file name, a flag, a docstring, an
error message or a test. ``f"..."`` strings count; their ``{parts}`` must stay as they are. Saving
checks the whole file still reads as code, and refuses a change that loses a ``{part}`` or a ``%s``.

No pygame and no tkinter here.
"""

from __future__ import annotations

import ast
import io
import os
import re
import tokenize
from dataclasses import dataclass

PYGAME_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# What is scanned: the game's own code. Not the tests, the tools, the Workshop (its words are for Frankie
# and no one else), the browser build, the design mockups or the saved checkpoints.
SKIP_DIRS = ("tests", "tools", "workshop", "web", "docs", "checkpoints", "assets", "data", "previews", "saves", "__pycache__")
SKIP_FILES = {
    "visual_test_text.py",        # a test screen
    "emulator.py",                # the playtest emulator's own menu
    os.path.join("core", "workshop.py"),
    os.path.join("core", "dialogue_editor.py"),
    os.path.join("core", "dialogue_villagers.py"),
    os.path.join("core", "code_text.py"),
    os.path.join("core", "story.py"),            # which script scene is which: names of files and headings
    os.path.join("core", "scene_select.py"),     # the playtest version's scene list
    os.path.join("core", "dialogue_text.py"),    # the Workshop's labels for a person's lines
    os.path.join("systems", "heard.py"),         # the sound test's track names, which are file names
    os.path.join("core", "game_text.py"),
}
# A call whose first string is a name, never words.
NAME_CALLS = {"get", "pop", "getattr", "hasattr", "setattr", "open", "join", "startswith", "endswith", "split", "rsplit",
              "partition", "rpartition", "count", "index", "find", "encode", "decode", "SysFont", "Font", "exists", "isfile",
              "isdir", "listdir", "import_module", "getenv", "environ", "setdefault", "add_argument", "compile", "match",
              "search", "fullmatch", "sub", "strip", "lstrip", "rstrip", "lower", "upper", "format_map", "load", "dump",
              "one", "many", "keyed", "warn", "print", "debug", "info", "error", "exception", "write", "makedirs", "mkdir", "remove", "save", "set_caption"}
# A keyword whose string is a name or a setting, never words (``help=``, ``text=``, ``label=`` are words).
NAME_KEYWORDS = {"key", "id", "kind", "mode", "flag", "event", "scene", "icon", "sprite", "sheet", "font", "anchor", "align",
                 "color", "path", "encoding", "file", "name", "speaker", "element", "type", "item", "move", "stance",
                 "member", "target", "room", "action", "state", "tag", "category", "group", "source", "owner", "who"}
IDENTIFIER_WORD = re.compile(r"^[a-z0-9_:.\-/\\]+$")
FLAG_LIKE = re.compile(r"^[a-z_]+:")
LABEL = re.compile(r"^[A-Z][A-Za-zĀāĒēĪīŌōŪū'’\-]{1,24}$")
PLACEHOLDERS = re.compile(r"\{[^{}]*\}|%[-+0#]*\d*(?:\.\d+)?[sdifxXc]")


@dataclass(frozen=True)
class CodeText:
    """One piece of words in the code."""

    file: str           # relative to game/pygame, forward slashes
    scope: str          # the class or function it sits in: ``ItemSettings``, ``quest_log``, ``(module)``
    number: int         # which one in that scope, from 0, in the order they are written
    text: str           # the words as they would show (an f-string's ``{parts}`` kept in)
    fstring: bool
    start: tuple[int, int]   # (line, byte column) of the literal, from the start
    end: tuple[int, int]

    @property
    def key(self) -> str:
        return f"{self.file}::{self.scope}#{self.number}"


def code_files() -> list[str]:
    """Every file scanned, relative to ``game/pygame`` with forward slashes, in a steady order."""
    found = []
    for folder, dirs, files in os.walk(PYGAME_DIR):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith("."))
        for name in sorted(files):
            if not name.endswith(".py"):
                continue
            relative = os.path.relpath(os.path.join(folder, name), PYGAME_DIR)
            if relative in SKIP_FILES or relative.startswith(("test_", "make_")):
                continue
            found.append(relative.replace(os.sep, "/"))
    return found


def _wordlike(text: str) -> bool:
    """Whether a string is words a player could read, rather than a key, a path or a flag."""
    s = text.strip()
    if not s or not re.search(r"[^\W\d_]{2}", s):
        return False
    if " " not in s:
        if not LABEL.match(s) or s.upper() == s:
            return False
        return not (len(s) > 8 and re.search(r"[a-z][A-Z]", s))    # a class's name, not a label
    if re.search(r"\.(md|json|png|py|ogg|mp3|wav|txt)", s) or FLAG_LIKE.match(s) or s.startswith(('  "', "'", '"')) or '":' in s:
        return False
    tokens = s.split()
    if all(IDENTIFIER_WORD.match(t) for t in tokens) and any(("_" in t or ":" in t) for t in tokens):
        return False
    return True


def _parents(tree: ast.AST) -> dict[ast.AST, ast.AST]:
    return {child: parent for parent in ast.walk(tree) for child in ast.iter_child_nodes(parent)}


def _called(parent: ast.AST) -> str:
    func = getattr(parent, "func", None)
    if isinstance(func, ast.Attribute):
        return func.attr
    return getattr(func, "id", "")


def _skipped(node: ast.AST, parents: dict[ast.AST, ast.AST]) -> bool:
    """Whether this string is code's own, not a player's."""
    parent = parents.get(node)
    if isinstance(parent, ast.Dict) and node in parent.keys:
        return True
    if isinstance(parent, (ast.Subscript, ast.Compare, ast.Expr, ast.JoinedStr, ast.FormattedValue)):
        return True
    if isinstance(parent, ast.Call) and node is (parent.args[0] if parent.args else None) and _called(parent) in NAME_CALLS:
        return True
    if isinstance(parent, ast.keyword) and (parent.arg in NAME_KEYWORDS or _called(parents.get(parent)) in NAME_CALLS):
        return True
    cursor = parent
    while cursor is not None:
        if isinstance(cursor, (ast.Raise, ast.Assert, ast.JoinedStr)):
            return True
        cursor = parents.get(cursor)
    return False


def _scope(node: ast.AST, parents: dict[ast.AST, ast.AST]) -> str:
    names = []
    cursor = parents.get(node)
    while cursor is not None:
        if isinstance(cursor, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            names.append(cursor.name)
        cursor = parents.get(cursor)
    return ".".join(reversed(names)) or "(module)"


def _read(relative: str) -> bytes:
    with open(os.path.join(PYGAME_DIR, *relative.split("/")), "rb") as f:
        return f.read()


def scan(relative: str, source: bytes | None = None) -> list[CodeText]:
    """The pieces of words in one file, in the order they are written."""
    raw = _read(relative) if source is None else source
    try:
        tree = ast.parse(raw)
    except SyntaxError:
        return []
    parents = _parents(tree)
    notes = _annotation_ids(tree)
    docstrings = set()
    for n in ast.walk(tree):
        if isinstance(n, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and n.body \
                and isinstance(n.body[0], ast.Expr) and isinstance(getattr(n.body[0], "value", None), ast.Constant):
            docstrings.add(id(n.body[0].value))
    nodes: list[tuple[ast.AST, str, bool]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and id(node) not in docstrings:
            if id(node) not in notes and not _skipped(node, parents) and _wordlike(node.value):
                nodes.append((node, node.value, False))
        elif isinstance(node, ast.JoinedStr) and not _skipped_fstring(node, parents):
            literal = "".join(v.value for v in node.values if isinstance(v, ast.Constant) and isinstance(v.value, str))
            if _wordlike(literal) or (literal.strip() and " " in literal.strip() and re.search(r"[^\W\d_]{3}", literal)):
                inner = _fstring_inner(raw, node)
                if inner is not None:
                    nodes.append((node, inner, True))
    nodes.sort(key=lambda item: (item[0].lineno, item[0].col_offset))
    counts: dict[str, int] = {}
    found = []
    for node, text, fstring in nodes:
        scope = _scope(node, parents)
        number = counts.get(scope, 0)
        counts[scope] = number + 1
        found.append(CodeText(relative, scope, number, text, fstring, (node.lineno, node.col_offset),
                              (node.end_lineno, node.end_col_offset)))
    return found


def _annotation_ids(tree: ast.AST) -> set[int]:
    """The ids of every node inside a type annotation: ``"Party"`` there is a type, not a word."""
    found: set[int] = set()
    for node in ast.walk(tree):
        notes = []
        if isinstance(node, ast.arg) and node.annotation is not None:
            notes.append(node.annotation)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.returns is not None:
            notes.append(node.returns)
        elif isinstance(node, ast.AnnAssign):
            notes.append(node.annotation)
        for note in notes:
            found.update(id(n) for n in ast.walk(note))
    return found


def _skipped_fstring(node: ast.JoinedStr, parents: dict[ast.AST, ast.AST]) -> bool:
    parent = parents.get(node)
    if isinstance(parent, (ast.Subscript, ast.Compare, ast.Expr)) or (isinstance(parent, ast.keyword)
                                                                     and parent.arg in NAME_KEYWORDS):
        return True
    if isinstance(parent, ast.Call) and node in parent.args[:1] and _called(parent) in NAME_CALLS:
        return True
    cursor = parent
    while cursor is not None:
        if isinstance(cursor, (ast.Raise, ast.Assert, ast.JoinedStr)):
            return True
        cursor = parents.get(cursor)
    return False


def _fstring_inner(raw: bytes, node: ast.JoinedStr) -> str | None:
    """An f-string's words as written (between its quotes), or None when it is not a plain one-line
    ``f"..."``; its escapes (``\\n``) stay as written."""
    if node.lineno != node.end_lineno:
        return None
    line = raw.split(b"\n")[node.lineno - 1]
    piece = line[node.col_offset:node.end_col_offset].decode("utf-8")
    match = re.fullmatch(r"([fF])(\"|')(.*)\2", piece)
    if match is None:
        return None
    return match[3]


def all_texts() -> list[CodeText]:
    found = []
    for relative in code_files():
        found.extend(scan(relative))
    return found


# ----------------------------------------------------------------------
# WRITING ONE BACK
# ----------------------------------------------------------------------


class CodeTextError(ValueError):
    """A change that cannot be written: said in plain words, for the window."""


def placeholders(text: str) -> list[str]:
    return sorted(PLACEHOLDERS.findall(text))


def _literal(text: str, fstring: bool) -> str:
    """The code for ``text``: a double-quoted string, kept as typed for an f-string."""
    if fstring:
        return 'f"' + text.replace('"', '\\"') + '"' if '"' not in text.replace('\\"', "") else 'f"' + text + '"'
    out = ['"']
    for ch in text:
        out.append({"\\": "\\\\", '"': '\\"', "\n": "\\n", "\r": "\\r", "\t": "\\t"}.get(ch, ch))
    out.append('"')
    return "".join(out)


def _offsets(raw: bytes) -> list[int]:
    """The byte where each line starts."""
    starts = [0]
    for line in raw.splitlines(keepends=True):
        starts.append(starts[-1] + len(line))
    return starts


def _has_comment(raw: bytes, first: tuple[int, int], last: tuple[int, int]) -> bool:
    """Whether a comment sits inside a string's span (a string split over lines with notes between)."""
    if first[0] == last[0]:
        return False
    chunk = raw.decode("utf-8").splitlines(keepends=True)[first[0] - 1:last[0]]
    try:
        for token in tokenize.generate_tokens(io.StringIO("(" + "".join(chunk).lstrip() + ")").readline):
            if token.type == tokenize.COMMENT:
                return True
    except (tokenize.TokenError, IndentationError):
        return False
    return False


def replace(relative: str, edits: dict[str, tuple[str, str]]) -> None:
    """Write several changes into one file. ``edits`` maps a key to (the words it had when the window opened,
    the words now). Raises ``CodeTextError`` and writes nothing if any change is refused."""
    raw = _read(relative)
    pieces = {piece.key: piece for piece in scan(relative, raw)}
    spans = []
    for key, (was, now) in edits.items():
        piece = pieces.get(key)
        if piece is None:
            raise CodeTextError(f"{key} is not in {relative} any more; the code changed since the window opened.")
        if piece.text != was:
            raise CodeTextError(f"These words in {relative} changed since the window opened: '{piece.text[:40]}...' "
                                "Your change is kept here; reopen the window to see the new words.")
        if placeholders(was) != placeholders(now):
            raise CodeTextError(f"'{now[:40]}...' lost or changed a part the game fills in. Keep every "
                                f"{', '.join(placeholders(was)) or 'part'} exactly as it was.")
        if "\n" in now and not piece.fstring and "\n" not in was and "\\n" not in was:
            pass
        if _has_comment(raw, piece.start, piece.end):
            raise CodeTextError(f"These words in {relative} are split over lines with a comment between; "
                                "edit them in the file.")
        spans.append((piece, now))
    starts = _offsets(raw)
    result = raw
    for piece, now in sorted(spans, key=lambda item: item[0].start, reverse=True):
        a = starts[piece.start[0] - 1] + piece.start[1]
        b = starts[piece.end[0] - 1] + piece.end[1]
        literal = _literal(now, piece.fstring)
        result = result[:a] + literal.encode("utf-8") + result[b:]
    try:
        ast.parse(result)
    except SyntaxError as error:
        raise CodeTextError(f"That would break {relative} ({error.msg}, line {error.lineno}). Nothing was written; "
                            "a double quote or a backslash in the words may need a backslash before it.") from error
    after = {piece.key: piece.text for piece in scan(relative, result)}
    for piece, now in spans:
        if after.get(piece.key) != now:
            raise CodeTextError(f"The change to '{now[:40]}...' did not come out as typed. Nothing was written; "
                                "if it has a backslash or a quote, check it.")
    path = os.path.join(PYGAME_DIR, *relative.split("/"))
    handle = open(path, "wb")
    with handle:
        handle.write(result)
