"""The setup behind Select on the title (Frankie, 11/18): a test game started at any scene.

Select picks a scene (``core/scene_select.py``) and then lets Frankie change what the player has there:
who is in the party, their stats, Elements, Skills and the bag. Nothing here is a table of "what the
player has at scene X". The defaults are that scene played up to through the game's own code
(``scene_select.defaults``), so they follow the story wherever the story changes; this file only edits
the party that comes back, with the game's own rules for stat caps, slots and learning.

No window needed: ``setup_scene.py`` draws it, this is what it changes, and ``tests/test_setup.py``
checks it alone. ``party()`` is the party to start with, the two toggles (Max medicine, Max HP) applied
on top of the edits.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from core import scene_select
from core.elements import LABELS
from core.factories import first_loadout, known_moves
from core.shared import by_id, short_name, skill_for
from core.stats import STAT_KEYS
from settings import ItemSettings, MasterySettings, SetupSettings, StatSettings, WalletSettings
from systems import battle_bag, mastery
from systems.loadout import checked, open_slots
from systems.party import Party, PartyMember

if TYPE_CHECKING:
    from main import GameManager

BANK = "bank"   # a move known and not slotted


def _copy(party: Party) -> Party:
    return Party.from_dict(party.to_dict())


class Setup:
    """The edits made on top of one scene's defaults."""

    def __init__(self, gm: "GameManager", index: int = 0) -> None:
        self.gm = gm
        self._defaults: dict[int, dict] = {}   # a scene's played-up-to party, kept so changing back is quick
        self.max_medicine = False
        self.max_hp = False
        self.edited = False
        self.index = -1
        self.party = Party()
        self.order: list[str] = []
        self.roster: list[str] = []
        self.choose(index)

    # ------------------------------------------------------------------
    # THE SCENE
    # ------------------------------------------------------------------

    def choose(self, index: int) -> None:
        """Pick scene ``index``: everything goes back to what the game has there."""
        self.index = index % len(scene_select.beats())
        self.reset()

    def reset(self) -> None:
        """Put every edit and both toggles back to the scene's defaults."""
        if self.index not in self._defaults:
            self._defaults[self.index] = scene_select.defaults(self.gm, self.index).to_dict()
        self.party = Party.from_dict(self._defaults[self.index])
        self.max_medicine = self.max_hp = self.edited = False
        self.order = [m.id for m in self.party.members] + [m.id for m in self.party.away]
        self.roster = list(self.order)   # the heroes in the order they joined: what left and right step through
        # Everyone is somewhere in ``order`` (the party first, then who is away); the party is its first
        # ``in_party`` of them. Slots are by position, so a hero can be moved up and down.
        self.in_party = len(self.party.members)

    @property
    def scene(self) -> str:
        return scene_select.beat_names()[self.index]

    # ------------------------------------------------------------------
    # THE PARTY: who is in, who fights
    # ------------------------------------------------------------------

    def heroes(self) -> list[str]:
        """Every hero who has joined by this scene (in the party or away), in the order they stand now."""
        return list(self.order)

    def slot_count(self) -> int:
        return len(self.order)

    def slot(self, slot: int) -> str | None:
        """The hero in ``slot``, or None for an empty one."""
        return self.order[slot] if slot < self.in_party else None

    def slot_name(self, slot: int) -> str:
        """The slot's label: the first three fight, the rest wait on the bench (D-196)."""
        if slot < SetupSettings.FIGHTERS:
            return f"Fights {slot + 1}"
        return "Bench" if self.slot_count() - SetupSettings.FIGHTERS < 2 else f"Bench {slot - SetupSettings.FIGHTERS + 1}"

    def cycle_slot(self, slot: int, step: int) -> bool:
        """Put the next (``step`` 1) or last hero in ``slot``, swapping with whoever stood there.

        The first slot is always someone (the leader walks the field); the others may be empty, and then
        that hero is away, as Hina is at home after the taro patch. Returns False if nothing changed.
        """
        if self.slot_count() <= 1:
            return False
        here = self.slot(slot)
        choices: list[str | None] = list(self.roster)
        if slot > 0:
            choices.append(None)
        # The party seats first, then the away ones: the heroes in order, then an empty seat.
        at = choices.index(here) if here in choices else 0
        new = choices[(at + step) % len(choices)]
        if new == here:
            return False
        seated = [self.slot(i) for i in range(self.slot_count())]
        if new is None:
            seated[slot] = None
        else:
            other = seated.index(new) if new in seated else None
            if other == 0 and here is None:
                return False   # the leader cannot be swapped out for an empty seat
            if other is not None:
                seated[other] = here
            seated[slot] = new
        away = [h for h in self.order if h not in seated]
        party = [h for h in seated if h is not None]
        self.order = party + away
        self.in_party = len(party)
        self.edited = True
        return True

    def _roster(self) -> dict[str, PartyMember]:
        return {m.id: m for m in self.party.members + self.party.away}

    def member(self, hero: str) -> PartyMember:
        return self._roster()[hero]

    # ------------------------------------------------------------------
    # STATS
    # ------------------------------------------------------------------

    @staticmethod
    def growth_cap() -> int:
        """The most a stat's growth can be: its base plus its growth never passes the cap (a fight's rise stops there)."""
        return SetupSettings.STAT_CAP - StatSettings.BASE_POINTS

    def grow(self, hero: str, key: str, step: int) -> bool:
        """Raise or lower ``hero``'s ``key`` growth by ``step``, between nothing and the cap; False at an end."""
        member = self.member(hero)
        now = member.growth.get(key, 0)
        new = max(0, min(self.growth_cap(), now + step))
        if new == now:
            return False
        self._set_growth(member, key, new)
        self.edited = True
        return True

    @staticmethod
    def _set_growth(member: PartyMember, key: str, growth: int) -> None:
        """Set the growth and keep the hit points the same share of the new maximum (full stays full)."""
        was_full = member.current_hp >= member.max_hp
        member.growth[key] = growth
        member.refresh_stats()
        member.current_hp = member.max_hp if was_full else min(member.current_hp, member.max_hp)

    def points(self, hero: str) -> dict[str, int]:
        """The stat scores shown: the elements, growth and weapon, out of a fight."""
        member = self.member(hero)
        return {k: member.stats[k] for k in STAT_KEYS}

    # ------------------------------------------------------------------
    # ELEMENTS: what each can know, and where it sits
    # ------------------------------------------------------------------

    def flags(self) -> dict[str, bool]:
        return self.party.flags

    def slots(self) -> list[int]:
        """How many slots are open in each tier at this scene (``systems/loadout.open_slots``, the bosses beaten)."""
        return open_slots(self.party.flags)

    def learnable(self, hero: str) -> list[dict]:
        """Every Element ``hero`` can have in this game: what they start with, what they have learned, and
        what an element item (a lontar or a kapa) teaches them. Skills take no slot and are not here."""
        member = self.member(hero)
        moves = by_id("moves")
        ids = [m["id"] for m in known_moves(hero, member.elements, self.party.flags)]
        from core.scenes.inventory_scene import can_learn  # local: cycle.

        for item, (_, move_id) in ItemSettings.SHELLS.items():
            if move_id not in ids and move_id in moves and can_learn(member, item):
                ids.append(move_id)
        return [moves[i] for i in ids if i in moves]

    def starts_with(self, hero: str, move_id: str) -> bool:
        """Whether ``move_id`` is one the hero always has (the shared file's ``demo_moves``), never un-learned."""
        return move_id in by_id("characters").get(hero, {}).get("demo_moves", {})

    def known_ids(self, hero: str) -> set[str]:
        member = self.member(hero)
        return {m["id"] for m in known_moves(hero, member.elements, self.party.flags)}

    def loadout(self, hero: str) -> dict[str, int]:
        """``hero``'s slots as the fight will make them: move id to tier."""
        member = self.member(hero)
        return checked(member.loadout, known_moves(hero, member.elements, self.party.flags),
                       first_loadout(hero, self.party.flags), self.slots())

    def where(self, hero: str, move_id: str) -> int | str | None:
        """A move's place: its tier 1 to 7, ``BANK``, or None when not learned."""
        if move_id not in self.known_ids(hero):
            return None
        return self.loadout(hero).get(move_id, BANK)

    def places(self, hero: str, move_id: str) -> list[int | str | None]:
        """Where ``move_id`` may go for ``hero``, in the order left and right step through them: not learned
        (only for what they do not start with), the bank, then every tier with a slot free."""
        loadout = self.loadout(hero)
        mine = loadout.get(move_id)
        used: dict[int, int] = {}
        for tier in loadout.values():
            used[tier] = used.get(tier, 0) + 1
        out: list[int | str | None] = []
        if not self.starts_with(hero, move_id):
            out.append(None)
        out.append(BANK)
        for tier, room in enumerate(self.slots(), start=1):
            if used.get(tier, 0) < room or tier == mine:
                out.append(tier)
        return out

    def move_to(self, hero: str, move_id: str, place: int | str | None) -> None:
        """Learn, bank, slot or un-learn ``move_id`` for ``hero``."""
        member = self.member(hero)
        loadout = self.loadout(hero)
        flag = f"{hero}_learned_{move_id}"
        loadout.pop(move_id, None)
        if place is None:
            self.party.flags.pop(flag, None)
        else:
            if not self.starts_with(hero, move_id):
                self.party.flags[flag] = True
            if place != BANK:
                loadout[move_id] = int(place)
        member.loadout = loadout
        self.edited = True

    def step_move(self, hero: str, move_id: str, step: int) -> bool:
        """Turn ``move_id``'s place on by ``step`` places; False if there is nowhere else."""
        places = self.places(hero, move_id)
        now = self.where(hero, move_id)
        if len(places) < 2:
            return False
        at = places.index(now) if now in places else 0
        self.move_to(hero, move_id, places[(at + step) % len(places)])
        return True

    def stance_name(self, hero: str, stance: int | None = None) -> str:
        """The element of ``hero``'s stance, by name."""
        member = self.member(hero)
        stances = by_id("characters").get(hero, {}).get("stances", [])
        stance = member.stance if stance is None else stance
        element = stances[stance]["element"] if 0 <= stance < len(stances) else member.elements[0]
        return LABELS.get(element, element)

    def flip_stance(self, hero: str) -> None:
        """The stance ``hero`` starts a fight in: the other one."""
        member = self.member(hero)
        member.stance = 1 - member.stance
        self.edited = True

    # ------------------------------------------------------------------
    # SKILLS: the weapon in hand and how well each weapon type is known
    # ------------------------------------------------------------------

    def weapon_types(self, hero: str) -> list[str]:
        return mastery.weapon_types(hero)

    def weapons(self, hero: str) -> list[str | None]:
        """The weapons ``hero`` may hold: the shared file's weapons of their three types, then empty hands."""
        types = set(self.weapon_types(hero))
        from core.shared import SHARED  # local: as the file's other tables

        out: list[str | None] = [w["id"] for w in SHARED["weapons"] if w["type"] in types]
        member = self.member(hero)
        if member.weapon and member.weapon not in out:
            out.insert(0, member.weapon)
        return out + [None]

    def step_weapon(self, hero: str, step: int) -> bool:
        """Hold the next weapon (a test setup has no shop to buy it in, so it is simply held); the stats follow it."""
        member = self.member(hero)
        choices = self.weapons(hero)
        if len(choices) < 2:
            return False
        at = choices.index(member.weapon) if member.weapon in choices else len(choices) - 1
        member.weapon = choices[(at + step) % len(choices)]
        member.refresh_stats()
        member.current_hp = min(member.current_hp, member.max_hp)
        self.edited = True
        return True

    def level(self, hero: str, type_id: str) -> int:
        return mastery.level_for(self.member(hero).mastery.get(type_id, 0))

    def set_level(self, hero: str, type_id: str, step: int) -> bool:
        """Raise or lower the weapon type's level by ``step``, 1 to the top; the EXP is the level's own start."""
        member = self.member(hero)
        now = self.level(hero, type_id)
        new = max(1, min(MasterySettings.MAX_LEVEL, now + step))
        if new == now:
            return False
        member.mastery[type_id] = mastery.total_for(new)
        self.edited = True
        return True

    def skill_name(self, hero: str, type_id: str) -> str:
        """The Skill that weapon type gives ``hero``, or ""."""
        skill = skill_for(hero, type_id)
        return skill["name"] if skill else ""

    # ------------------------------------------------------------------
    # THE BAG
    # ------------------------------------------------------------------

    CATEGORIES = ("Medicine", "Meals", "Ingredients", "Elements", "Seeds", "Materials", "Loot", "Special", "Key Items")

    def items(self, category: str) -> list[str]:
        """Every item the game has in ``category``, in the order of ``ItemSettings.NAMES``."""
        from core.scenes.inventory_scene import category_of  # local: cycle.

        return [i for i in ItemSettings.NAMES
                if category_of(i) == category and i not in ("fish", "battle_bag", *WalletSettings.ITEMS)]

    def count(self, item: str) -> int:
        return self.party.inventory.get(item, 0)

    def add_item(self, item: str, step: int) -> bool:
        """Add or take ``step`` of ``item``, between none and the stack limit; False at an end."""
        now = self.count(item)
        new = max(0, min(SetupSettings.STACK_LIMIT, now + step))
        if new == now:
            return False
        if new:
            self.party.inventory[item] = new
        else:
            del self.party.inventory[item]
        self.edited = True
        return True

    @staticmethod
    def medicine() -> list[str]:
        """Every healing and reviving item: the plant medicine and what raises the fallen."""
        from core.scenes.inventory_scene import category_of  # local: cycle.

        return [i for i in ItemSettings.NAMES if category_of(i) == "Medicine"] + list(ItemSettings.REVIVES)

    # ------------------------------------------------------------------
    # THE PARTY TO START WITH
    # ------------------------------------------------------------------

    def party_to_start(self) -> Party:
        """A party with every edit and both toggles applied, for ``scene_select.start``. The edits stay as they are."""
        party = _copy(self.party)
        members = {m.id: m for m in party.members + party.away}
        party.members = [members[h] for h in self.order[:self.in_party]]
        party.away = [members[h] for h in self.order[self.in_party:]]
        if self.max_medicine:
            for item in self.medicine():
                party.inventory[item] = SetupSettings.STACK_LIMIT
            # Every fighter's battle bag full of it, a Life Totem among the Noni, then the shared bag topped up.
            for member in party.members:
                for item in ("life_totem", *["noni"] * battle_bag.size(member)):
                    if battle_bag.room(member) > 0:
                        battle_bag.give(party, member, item)
            for item in self.medicine():
                party.inventory[item] = SetupSettings.STACK_LIMIT
        if self.max_hp:
            for member in party.members + party.away:
                member.growth["hp"] = self.growth_cap()
                member.refresh_stats()
                member.current_hp = member.max_hp
        return party

    def start(self) -> None:
        """Begin the game: the scene, with what is set here when anything is."""
        changed = self.edited or self.max_medicine or self.max_hp
        scene_select.start(self.gm, self.index, self.party_to_start() if changed else None)
