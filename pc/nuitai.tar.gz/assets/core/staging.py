"""A story scene acted out on the map, as a Super Nintendo cutscene (Frankie, 10/23).

The script's stage directions (the rules at the top of
``game/shared/story.md``, read by ``core/story.py``) put people on the
room's tiles, walk or run them along their stops and turn them to face
each other. ``OverworldScene`` holds one ``Stage`` while a scene that has
a ``Room`` plays: it does each direction when its turn comes, waits while
anyone is moving, and draws everyone on the stage in place of the player.
Kailo is the player: when the scene ends he stays where the stage left
him, and everyone else leaves. Someone who falls (``Fall``) lies on their
tile: their sheet's fifth row if it has one (Pono's body, the dwende gone
from it), else their standing frame turned on its side. The scene's foes stand on it under their
fight names, drawn as the map draws their kind (``entities/field_monster.py``).
"""

from __future__ import annotations

import os

import pygame

from entities.walker_art import walker_frames
from settings import AssetPaths, GridSettings, OverworldPlayerSettings, OverworldSettings, StorySettings
from utils import sprite_files

# Each walk sheet's frames by facing column, loaded on first use; [] if missing.
_SHEETS: dict[str, list[list[pygame.Surface]]] = {}
# Each walk sheet's fallen frame, loaded with it; None if missing.
_FALLEN: dict[str, pygame.Surface | None] = {}


def _frames(name: str) -> list[list[pygame.Surface]]:
    """``[facing column][frame]`` of someone's walk sheet: Kailo's is the player's."""
    if name not in _SHEETS and walker_frames(name):
        _SHEETS[name] = walker_frames(name)
        _FALLEN[name] = pygame.transform.rotate(_SHEETS[name][0][0], 90)
    if name not in _SHEETS:
        path = AssetPaths.PLAYER_SHEET if name == StorySettings.PLAYER else sprite_files.sheet_path(f"{name}-Walk")
        _SHEETS[name] = []
        _FALLEN[name] = None
        if os.path.exists(path):
            sheet = pygame.image.load(path)
            if pygame.display.get_surface() is not None:
                sheet = sheet.convert_alpha()
            size = GridSettings.TILE_SIZE
            _SHEETS[name] = [
                [sheet.subsurface(pygame.Rect(c * size, f * size, size, size))
                 for f in range(min(OverworldPlayerSettings.WALK_FRAMES, sheet.get_height() // size))]
                for c in range(sheet.get_width() // size)
            ]
            fallen_row = OverworldPlayerSettings.WALK_FRAMES
            _FALLEN[name] = (sheet.subsurface(pygame.Rect(0, fallen_row * size, size, size))
                             if sheet.get_height() > fallen_row * size
                             else pygame.transform.rotate(_SHEETS[name][0][0], 90))
    return _SHEETS[name]


def toward(source: tuple[int, int], target: tuple[int, int]) -> tuple[int, int]:
    """The facing from one tile to another: across when it is at least as far as up or down."""
    dx, dy = target[0] - source[0], target[1] - source[1]
    if abs(dx) >= abs(dy) and dx:
        return (1 if dx > 0 else -1, 0)
    return (0, 1 if dy > 0 else -1) if dy else (0, 1)


class Actor:
    """Someone on the stage: their tile, facing, and the steps still to take.

    A foe has ``kind``, its field monster kind: its frames face right and
    are flipped to face left; facing down it roots, bobbing between them.
    """

    def __init__(self, name: str, col: int, row: int, facing: tuple[int, int], kind: dict | None = None) -> None:
        self.name = name
        self.kind = kind
        self.clock = 0.0                         # seconds on the stage, for the rooting
        self.col, self.row = col, row
        self.facing = facing
        self.path: list[tuple[int, int]] = []   # the tiles to step onto, one at a time
        self.seconds = 0.0                       # a step's length
        self.progress = 0.0                      # into the step under way, 0 to 1
        self.steps = 0                           # steps taken, so the feet alternate
        self.fallen = False                      # lying on their tile (``Fall``)

    def off(self) -> bool:
        """Past the room's edge: gone."""
        return not (0 <= self.col < OverworldSettings.COLS and 0 <= self.row < OverworldSettings.ROWS)

    def set_off(self, stops: list, seconds: float) -> None:
        """Walk to each stop in turn, across first, then up or down."""
        col, row = self.col, self.row
        for stop_col, stop_row in stops:
            stop_col = col if stop_col is None else stop_col
            stop_row = row if stop_row is None else stop_row
            while col != stop_col:
                col += 1 if stop_col > col else -1
                self.path.append((col, row))
            while row != stop_row:
                row += 1 if stop_row > row else -1
                self.path.append((col, row))
        self.seconds = seconds
        self.progress = 0.0

    def update(self, dt: float) -> None:
        """Slide along the path."""
        self.clock += dt
        if not self.path:
            return
        target = self.path[0]
        self.facing = (target[0] - self.col, target[1] - self.row)
        self.progress += dt / self.seconds
        if self.progress < 1.0:
            return
        self.col, self.row = self.path.pop(0)
        self.steps += 1
        # What is left of this frame carries into the next step.
        self.progress = self.progress - 1.0 if self.path else 0.0

    def render(self, surface: pygame.Surface) -> None:
        """Draw at the in-between pixel, the walk frame for the step under way."""
        if self.off() and not self.path:
            return
        size = GridSettings.TILE_SIZE
        x, y = self.col * size, self.row * size
        frame = 0
        if self.path:
            x += int((self.path[0][0] - self.col) * size * self.progress)
            y += int((self.path[0][1] - self.row) * size * self.progress)
            per_step = OverworldPlayerSettings.FRAMES_PER_STEP
            frame = (self.steps % 2) * per_step + min(per_step - 1, int(self.progress * per_step))
        if self.kind is not None:
            self._render_foe(surface, x, y)
            return
        frames = _frames(self.name)
        if not frames:
            return
        if self.fallen:
            surface.blit(_FALLEN[self.name], (OverworldSettings.X + x, OverworldSettings.Y + y))
            return
        column = frames[OverworldPlayerSettings.SHEET_COLUMNS.get(self.facing, 0) % len(frames)]
        surface.blit(column[frame % len(column)], (OverworldSettings.X + x, OverworldSettings.Y + y))


    def _render_foe(self, surface: pygame.Surface, x: int, y: int) -> None:
        """A foe as the map draws its kind: on its tile's bottom edge, its middle on the tile's."""
        from entities.field_monster import _frames as foe_frames  # local: the map's monsters load late

        frames = foe_frames(self.kind)
        if not frames:
            return
        if self.path:
            frame = frames[int(self.progress * len(frames)) % len(frames)]
        elif self.facing == (0, 1):
            frame = frames[int(self.clock / StorySettings.ROOT_SECONDS) % len(frames)]
        else:
            frame = frames[0]
        if self.facing == (-1, 0):
            frame = pygame.transform.flip(frame, True, False)
        size = GridSettings.TILE_SIZE
        surface.blit(frame, (OverworldSettings.X + x + (size - frame.get_width()) // 2,
                             OverworldSettings.Y + y + size - frame.get_height()))


class Stage:
    """Everyone a scene has put on the map, and the moves under way."""

    def __init__(self, cast: list[str], foes: dict[str, dict] | None = None) -> None:
        """A stage for a scene whose ``## Cast`` is ``cast``: the room's people of that name are hidden.

        ``foes`` are the scene's foes by fight name, each its field monster kind.
        """
        self.cast = set(cast)
        self.foes = foes or {}
        self.actors: dict[str, Actor] = {}

    def _actor(self, name: str, col: int, row: int, facing: tuple[int, int]) -> Actor:
        # A lettered boar that is not in the fight (Wild Boar C, who runs off) is drawn as its kin.
        kind = self.foes.get(name) or next(
            (k for foe, k in self.foes.items() if foe.rstrip("ABCDEFGH ") == name.rstrip("ABCDEFGH ") != name), None)
        self.actors[name] = Actor(name, col, row, facing, kind)
        return self.actors[name]

    def busy(self) -> bool:
        """Someone is still moving."""
        return any(actor.path for actor in self.actors.values())

    def do(self, step: dict) -> None:
        """Play one stage direction (``core/story.py``'s ``_stage``)."""
        if "stand" in step:
            for entry in step["stand"]:
                self._actor(entry["who"], entry["col"], entry["row"], entry["facing"])
        elif "fall" in step:
            for name in step["fall"]:
                if name in self.actors:
                    self.actors[name].fallen = True
        elif "turn" in step:
            for entry in step["turn"]:
                actor = self.actors.get(entry["who"])
                if actor is None:
                    continue
                if "toward" in entry and entry["toward"] in self.actors:
                    other = self.actors[entry["toward"]]
                    actor.facing = toward((actor.col, actor.row), (other.col, other.row))
                    if actor.kind is not None and actor.facing[0] == 0:
                        # A side walker keeps to its side: left or right of whoever it faces.
                        actor.facing = (-1, 0) if other.col < actor.col else (1, 0)
                elif "facing" in entry:
                    actor.facing = entry["facing"]
        elif "move" in step:
            ms = StorySettings.RUN_STEP_MS if step["run"] else StorySettings.WALK_STEP_MS
            for entry in step["move"]:
                actor = self.actors.get(entry["who"])
                if entry["start"] is not None:
                    actor = self._actor(entry["who"], *entry["start"], (0, 1))
                if actor is not None:
                    slow = StorySettings.CANE_WALKERS.get(entry["who"], 0)
                    actor.set_off(entry["stops"], max(ms, slow) / 1000.0)

    def update(self, dt: float) -> None:
        for actor in self.actors.values():
            actor.update(dt)

    def hides(self, person: dict) -> bool:
        """A person of the room the scene plays instead (Melia at home)."""
        return person.get("speaker") in self.cast

    def render(self, surface: pygame.Surface) -> None:
        """Everyone on the stage, Kailo last, so whoever walks into him goes behind."""
        for name, actor in self.actors.items():
            if name != StorySettings.PLAYER:
                actor.render(surface)
        if StorySettings.PLAYER in self.actors:
            self.actors[StorySettings.PLAYER].render(surface)
