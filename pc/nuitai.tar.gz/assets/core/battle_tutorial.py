"""Hina's tutorial in the taro patch fight (Frankie, 10/26).

As the fight opens Hina asks if Kailo remembers how to fight. No is on
top and chosen, so mashing confirm gets the lessons; skipping them takes
a step down to Yes (Frankie, 10/26), and cancel does nothing here. Yes
plays the fight with no lessons; no gets "lunkhead" and her reminders.

The first lesson is always the warm-up, on Kailo's first turn whoever
acts first (Kailo always goes first in this fight, Frankie, 11/4): the turn order bar, Attack, the stroke points (stamina), then
one Light at a time: try a Light, and once it lands try another; a Light
that misses gets an insult and a try again, as often as it misses. The
first one landed shows the mana it builds. After the second, the chance
on Strong that every landed stroke has raised; then she has him move to
Strong himself watching the bar, and only once the cursor rests there
"See that? Your face went down!", the fatigue it shows, and Strong. Last,
that Defend builds a little mana too (where it is comes later, below:
Frankie, 10/27, the 10/27 Let's Play never found it).

After that she steps in only when a move is really there, each once:
Heal when Hina can and someone is hurt; an item when someone is low and
Hina cannot Heal now; Flame Kick when Kailo can; Defend on any turn of
theirs after those, left of the commands; and, once he has done
Flame Kick, the switch to Wai'Kenpō when Hina is hurt and he is fine,
where the screen shows the stance, then Wave Guard on his next turn if
he has it. Hina never switches her own stance. The first time the block
meter comes up she holds the fight and says how to block (Frankie, 10/31).
A lesson whose moment never comes waits, kept on the save, for the first
later fight where it does (game/answers.md, Frankie 10/26; built 11/3).

Escape lives only in later fights (``later``): no question, never a boss
or story fight, once ever (a party flag). When Kailo and Hina are both low
and her Heal is not there she says so, and the cursor moves to Escape on
the page left of the commands, nothing forced (game/answers.md).

She talks in short boxes, and every one is closed with confirm before
the player acts (Frankie, 10/26), so no box ever covers what they pick,
the target arrows over the boars above all. A box that only talks holds
the fight; a lesson's last box holds the player, and once it is closed
the dim and the lock stay on, the cursor held on what she means: cancel,
the side pages (Equip, Escape, Defend, Swap) and anything else in the
menu are out of reach. A box comes back only when the lesson moves on.
Picking an enemy is free, but there is no backing out of it. The screen
dims to half but for one area at a time, and her box, the field's text
box with her face, sits at the top, or at the bottom when what she
points at is up there. On the cartridge the dim is color math halving
everything outside one window, the box left out of it.

The tutorial lives in its ``BattleScene``; what it never reached is kept
on the save (``LESSONS_LEFT_FLAG``) for later fights, Kailo and Hina both in the party.
"""

from __future__ import annotations

from collections import deque
from typing import TYPE_CHECKING, Any, Callable

import pygame

from core.events import AbilityUsedEvent, StanceEvent
from settings import (
    BattleSettings,
    FontSettings,
    ItemSettings,
    LoadoutSettings,
    ScreenSettings,
    TutorialSettings as T,
    UISettings,
)
from ui import input_map, text_renderer
from ui.text_box import TextBox
from ui.window import draw_window

if TYPE_CHECKING:
    from core.scenes.battle_scene import BattleScene
    from systems.battle import Combatant

# The rows of the battle scene's menus a lesson points at.
_ATTACK_ROW, _ELEMENT_ROW, _ITEM_ROW = 0, 2, 3
_STROKE_ROWS = {"light": 0, "strong": 2}
_STROKE_ELEMENT_ROW = 3
# Her question's rows: NO on top, where the cursor starts.
_NO_ROW, _YES_ROW = 0, 1
# The taro patch's lessons, done before a later fight starts.
_TARO_LESSONS = ("warm_up", "mana", "heal", "item", "flame_kick", "defend", "stance", "block")
# The lessons that wait for a later fight when the taro patch never reached them;
# the warm-up and mana belong to the first fight only.
_CARRIED = ("heal", "item", "flame_kick", "defend", "stance", "block")
# Where a line points: a function returning the area to leave lit, or None.
Light = Callable[[], "pygame.Rect | None"]


class HinaTutorial:
    """Hina's question, her lessons and their locks, for one fight."""

    def __init__(self, scene: "BattleScene", later: bool = False, escape: bool = False) -> None:
        self.scene = scene
        self.active = True
        # A later fight (``later``): no question; the lessons the taro patch never
        # reached (kept on the save), and the escape lesson if ``escape``.
        self.later = later
        self.escape = escape
        # Lessons are on once the player says they do not remember.
        self.lessons = later
        left = set(scene.gm.party.flags.get(T.LESSONS_LEFT_FLAG, ())) if later else set()
        self.done: set[str] = (set(_TARO_LESSONS) - left) if later else set()
        if later and not escape:
            self.done.add("escape")
        # The lesson holding the player now: its name, whose turn, the
        # move it is about, and for the warm-up its stage and the stroke
        # points and hits at the stage's start.
        self.step: dict[str, Any] | None = None
        # Boxes that only talk, each with what it points at, said in turn.
        self._talks: deque[tuple[str, Light | None]] = deque()
        # The line a lesson's lock opens with, and whether its box is still
        # up; the player acts only once it is closed.
        self._lock_line: str | None = None
        self._lock_open = False
        self._asking = True
        self._choice = _NO_ROW
        # Kailo has done Flame Kick this fight; the stance lesson waits on it.
        self.kicked = False
        # Kailo switched in the lesson: show where the stance shows, then
        # Wave Guard on his next turn.
        self._stance_switched = False
        self._guard_next = False
        # After the escape lesson's lines, the cursor goes to Escape once.
        self._escape_cursor = False
        # Her box, as wide as the screen, and the line it shows.
        self.box = TextBox()
        self._shown: str | None = None
        self._asking = not later
        if not later:
            self._talk(T.ASK)
        self._sync_box()

    # ------------------------------------------------------------------
    # LINES
    # ------------------------------------------------------------------

    def _talk(self, line: str, light: Light | None = None) -> None:
        """Queue a box that only talks, lighting ``light`` while it is up."""
        self._talks.append((line, light))

    def _line(self) -> str | None:
        """Return the line her box should show now."""
        if self._talks:
            return self._talks[0][0]
        return self._lock_line if self.step is not None and self._lock_open else None

    def _sync_box(self) -> None:
        """Put the line due up in her box, typing it from the start when it changes."""
        line = self._line()
        if line == self._shown:
            return
        if line is not None and self.scene.stage.numbers_up():
            # A new box waits until the numbers have floated away, so it never
            # covers the hit it is about (Frankie, 11/3, from Mark's playtest).
            if self._shown is not None:
                self._shown = None
                self.box.clear()
            return
        self._shown = line
        self.box.clear()
        if line is not None:
            self.box.push(line, speaker=T.SPEAKER)

    def _typed(self) -> bool:
        """Return True once the line showing has typed out."""
        return not self.box.is_done() and self.box.is_page_complete()

    def holds(self) -> bool:
        """Return True while the fight waits on her: the question, or a box that only talks."""
        return self.active and bool(self._talks)

    def stop(self) -> None:
        """End the tutorial: the fight is over, won or lost.

        With her lessons on, the ones whose moment never came wait on the
        save for a later fight (game/answers.md, Frankie 10/26).
        """
        if self.active and self.lessons:
            self._keep_left()
        self.active = False
        self.step = None
        self._talks.clear()
        self._lock(None)
        self._sync_box()

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> bool:
        """Take the input her box needs, and block what a lesson locks.

        Returns:
            True when the event is used or blocked; the scene then leaves it.
        """
        if not self.active:
            return False
        self._sync_box()
        audio = self.scene.gm.audio
        if self._talks:
            if not self._typed():
                if input_map.is_confirm(event):
                    self.box.advance()
            elif self._asking:
                if input_map.is_up(event) or input_map.is_down(event):
                    self._choice = 1 - self._choice
                    audio.play("menu_move")
                elif input_map.is_confirm(event):
                    audio.play("menu_select")
                    self._talks.popleft()
                    self._answer(self._choice == _YES_ROW)
            elif input_map.is_confirm(event):
                self._talks.popleft()
            self._sync_box()
            return True
        if self.step is None or not self._commanding():
            return False
        if self._lock_open:
            # Her box is up: confirm types it out, then closes it.
            if not self._typed():
                if input_map.is_confirm(event):
                    self.box.advance()
            elif input_map.is_confirm(event):
                self._lock_open = False
                self._sync_box()
            return True
        kind, _ = self._target()
        if self.scene._pending_command is not None and kind != "ally":
            # Choosing the enemy is free; backing out of it is not.
            return input_map.is_cancel(event)
        if kind == "bar":
            # On the way to Strong: up and down only, nothing picked yet.
            return not (input_map.is_up(event) or input_map.is_down(event))
        if kind == "page_left":
            # On the way to Defend: left only.
            return not input_map.is_left(event)
        self._hold_cursor()
        return not input_map.is_confirm(event)

    def _answer(self, remembers: bool) -> None:
        """Yes: no lessons at all. No: "lunkhead", and the lessons are on."""
        self._asking = False
        self.lessons = not remembers
        if remembers:
            # Yes means Hina teaches nothing, in this fight or any later one (Frankie, 11/4): every
            # once-ever lesson is marked taught. The dodge praise answers her dodge lesson, so it is marked too (Frankie, 11/4).
            flags = self.scene.gm.party.flags
            # The ELEMENT screen's row explanation is a hint too (Frankie, 11/6).
            for flag in (T.TEAM_UP_FLAG, T.NATURE_HEALS_FLAG, T.ESCAPE_FLAG, T.DODGE_PRAISE_FLAG, LoadoutSettings.LESSON_FLAG,
                         LoadoutSettings.SLOT_LESSON_FLAG):
                flags[flag] = True
            flags.pop(T.LESSONS_LEFT_FLAG, None)
        if not remembers:
            self.scene.gm.audio.play("scold_nag")  # Hina's "lunkhead" (Frankie, 11/11)
        self._talk(T.YES if remembers else T.NO)

    def block_started(self) -> None:
        """The block meter is up: the first time, with her lessons on, she says how it works."""
        if not self.active or not self.lessons or "block" in self.done:
            return
        self.done.add("block")
        self._keep_left()
        for line in T.BLOCK:
            self._talk(line, self._meter_window)

    def saw(self, events: list[Any]) -> None:
        """Note what the fight did: Kailo's Flame Kick, his switch to another stance."""
        for event in events:
            if isinstance(event, AbilityUsedEvent) and event.user_id == "kailo" and event.ability_id == "flame_kick":
                self.kicked = True
            if isinstance(event, StanceEvent) and self.step is not None and self.step["name"] == "stance":
                self._stance_switched = True

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        """Type her lines, and start, move on or end the lessons."""
        if not self.active:
            return
        scene = self.scene
        battle = scene.battle
        if battle.is_over:
            self.stop()
            return
        self._sync_box()
        self.box.update(dt)
        if self.step is not None and self._commanding():
            self._hold_cursor()
        if self._talks:
            return
        if self.step is not None and (
            battle.current_actor is not self.step["actor"] or not battle.is_awaiting_command()
        ):
            # The turn is over: the move was made, or the turn ended
            # some other way (a counter felled the one striking). Strong
            # can be the chain's last stroke, after Lights that missed.
            if self.step["name"] == "warm_up" and self.step["stage"] == "strong":
                self._talk(T.OTHER_MANA)
            self._end_step()
        if self._stance_switched and not scene._events and scene.text_box.is_done():
            # Kailo is in Wai'Kenpō: where that shows, before the next turn.
            self._stance_switched = False
            self._guard_next = True
            self._talk(T.STANCE_SHOWN, lambda: scene.stage.stance_icons_rect("kailo"))
        if self._escape_cursor and not self._talks and self._commanding():
            self._escape_cursor = False
            self._point_at_escape()
        if not self._talks and self._commanding():
            if self.step is None:
                self._start_lesson()
            if self.step is not None and self.step["name"] == "warm_up":
                self._warm_up(dt)
            if self.step is not None:
                self._hold_cursor()
        self._sync_box()

    def _commanding(self) -> bool:
        """Return True while the player picks, with no list Hina does not mean open."""
        scene = self.scene
        return not scene._battle_finished and scene._can_command() and scene.list_menu is None

    def _end_step(self) -> None:
        """The lesson is over, done or cut short; it never comes again."""
        self.done.add(self.step["name"])
        self.step = None
        self._lock(None)
        self._keep_left()

    def _keep_left(self) -> None:
        """Keep on the save the lessons still to come, in the taro patch's order."""
        if not self.lessons:
            return
        left = [name for name in _CARRIED if name not in self.done]
        self.scene.gm.party.flags[T.LESSONS_LEFT_FLAG] = left

    def _lock(self, line: str | None) -> None:
        """Open the lock's box with ``line``, up until confirm closes it."""
        self._lock_line = line
        self._lock_open = line is not None

    def _lesson(self, name: str, line: str, **step: Any) -> None:
        """Start lesson ``name`` on the one acting, its box saying ``line``."""
        self.step = {"name": name, "actor": self.scene.battle.current_actor, **step}
        self._lock(line)

    def _start_lesson(self) -> None:
        """Start the lesson whose moment this is, if one is."""
        scene = self.scene
        if not self.lessons or scene._pending_command is not None or any(
            menu is not None for menu in (scene.ability_menu, scene.item_menu)
        ):
            return
        battle = scene.battle
        actor = battle.current_actor
        kailo, hina = self._member("kailo"), self._member("hina")
        if "warm_up" not in self.done:
            if kailo is None or not kailo.alive:
                self.done.add("warm_up")
            elif actor is kailo and not battle.chaining:
                self._lesson("warm_up", T.ATTACK, stage="attack")
                bar = self._turn_bar
                for line in T.TURN_BAR:
                    self._talk(line, bar)
                return
            else:
                return
        if (
            self.later and self.escape and "escape" not in self.done and actor is not None and actor.is_party
            and not battle.chaining and scene.stroke_menu is None and self._dire()
        ):
            # Suggested, never forced: her lines, then the cursor on Escape.
            self.done.add("escape")
            scene.gm.party.flags[T.ESCAPE_FLAG] = True
            lines = list(T.ESCAPE)
            if hina is not None and not any(m["id"] == "cure" for m in battle.moves_for(hina)):
                # Heal is in her other stance, not out of mana (Frankie, 11/3), as with the item lesson.
                lines[0] = T.ESCAPE_STANCE
            elif actor is hina:
                # Her turn and no mana: she says so, else it is not her turn yet (Frankie, 11/6).
                lines[0] = T.ESCAPE_MANA
            for line in lines:
                self._talk(line, self._commands_window)
            self._escape_cursor = True
            return
        if self._guard_next and actor is kailo:
            self._guard_next = False
            if self._can_use(actor, "kailo", "sentinel"):
                self._lesson("wave_guard", T.WAVE_GUARD, move="sentinel")
                return
        hurt = [c for c in battle.party if c.alive and c.hp < c.max_hp]
        can_heal = self._can_use(actor, "hina", "cure")
        if "heal" not in self.done and can_heal and hurt:
            hurt_kailo = kailo in hurt
            self._lesson("heal", T.HEAL_KAILO if hurt_kailo else T.HEAL_SELF, move="cure")
            return
        low = [c for c in battle.party if c.alive and c.hp < c.max_hp * T.ITEM_LOW_BELOW]
        item = self._heal_item()
        if "item" not in self.done and low and item and not can_heal and scene.stroke_menu is None:
            who = min(low, key=lambda c: c.hp / c.max_hp)
            # The fight menu calls the shared stack "Noni", not the bag's "Noni Pulu".
            name = "Noni" if item == "noni" else ItemSettings.NAMES.get(item, item)
            line = T.ITEM_KAILO if who is not hina else T.ITEM_SELF if actor is hina else T.ITEM_HINA
            if line is T.ITEM_KAILO and actor is hina:
                # Her turn and no mana, not "not her turn yet" (Frankie, 11/6).
                line = T.ITEM_KAILO_MANA
            if line in (T.ITEM_SELF, T.ITEM_KAILO_MANA) and not any(m["id"] == "cure" for m in battle.moves_for(hina)):
                # Heal is in her other stance, not out of mana (Frankie, 11/3, from Mark's Episode 3).
                line = T.ITEM_SELF_STANCE if line is T.ITEM_SELF else T.ITEM_KAILO_STANCE
            if "burn" in who.statuses:
                # A burn blocks every heal, so the Kukui, or nothing (Frankie, 11/4, Mark's Episode 4).
                if scene.gm.party.inventory.get("kukui", 0) <= 0:
                    line = None
                else:
                    name = ItemSettings.NAMES["kukui"]
                    line = (T.ITEM_KAILO_BURN if who is not hina else T.ITEM_SELF_BURN if actor is hina
                            else T.ITEM_HINA_BURN)
            if line is not None:
                self._lesson("item", line.format(item=name),
                             item=name, ally=who.id)
                return
        if "flame_kick" not in self.done and self._can_use(actor, "kailo", "flame_kick"):
            self._lesson("flame_kick", T.FLAME_KICK, move="flame_kick")
            return
        if "defend" not in self.done and actor is not None and actor.is_party and not battle.chaining:
            self._lesson("defend", T.DEFEND_GO)
            self._talk(T.DEFEND_WHERE, self._commands_window)
            return
        if (
            "stance" not in self.done and self.kicked and actor is kailo
            and hina is not None and hina.alive and hina.hp < hina.max_hp * T.STANCE_HINA_BELOW
            and kailo.hp > kailo.max_hp * T.STANCE_KAILO_ABOVE
            and kailo.stance_element is not None and kailo.stance_element.value == "afi"
            and battle.other_stance(kailo) is not None
        ):
            self._lesson("stance", T.STANCE_GO, move=None)
            self._talk(T.STANCE, self._lock_light)

    def _dire(self) -> bool:
        """Kailo and Hina both standing and low, and her Heal not there now (items do not count)."""
        battle = self.scene.battle
        kailo, hina = self._member("kailo"), self._member("hina")
        if kailo is None or hina is None or not kailo.alive or not hina.alive:
            return False
        if any(c.hp >= c.max_hp * T.ESCAPE_LOW_BELOW for c in (kailo, hina)):
            return False
        cure = next((m for m in battle.moves_for(hina) if m["id"] == "cure"), None)
        return cure is None or not battle.can_afford(hina, cure)

    def _point_at_escape(self) -> None:
        """Turn to the page left of the commands and rest the cursor on Escape."""
        scene = self.scene
        if scene.ability_menu is not None or scene.item_menu is not None or scene._pending_command is not None:
            return
        if scene._page != -1:
            if scene._page != 0:
                scene._back_to_commands()
            scene._turn_page(-1)
        menu = scene.side_menu
        if menu is not None:
            menu.cursor = next((k for k, item in enumerate(menu.items) if item.label == "Escape"), menu.cursor)

    def _heal_item(self) -> str | None:
        """Return the first healing item the party has, as the Item menu lists them, or None."""
        if self.scene.battle.noni > 0:
            return "noni"
        bag = self.scene.gm.party.inventory
        return next((item for item in ItemSettings.HEALS if item != "noni" and bag.get(item, 0) > 0), None)

    def _can_use(self, actor: "Combatant | None", who: str, move_id: str) -> bool:
        """Return True when ``who`` is acting and has ``move_id`` now: in this stance, with the mana."""
        battle = self.scene.battle
        if actor is None or actor.id != who:
            return False
        move = next((m for m in battle.moves_for(actor) if m["id"] == move_id), None)
        return move is not None and battle.can_afford(actor, move)

    def _member(self, member_id: str) -> "Combatant | None":
        return next((c for c in self.scene.battle.party if c.id == member_id), None)

    def _warm_up(self, dt: float) -> None:
        """Move the warm-up on: Attack, one Light at a time, the move to Strong, Strong."""
        scene = self.scene
        step = self.step
        if scene._pending_command is not None:
            return
        chain = scene.battle._chain or {"points": 0, "landed": 0, "target": None}
        # The landed count starts over on a new enemy (Battle.submit_stroke), so a
        # stroke landed is one more than before on the same enemy, or any on a new one.
        before = step.get("landed", 0) if chain["target"] == step.get("target") else 0
        if chain["landed"] and "mana" not in self.done:
            self.done.add("mana")
            row = lambda: scene.stage.party_row_rect("kailo")  # noqa: E731
            for line in T.MANA:
                self._talk(line, row)
        if step["stage"] == "attack" and scene.stroke_menu is not None:
            step.update(stage="light", points=chain["points"], landed=chain["landed"],
                        target=chain["target"], lights=0)
            self._talk(T.STAMINA, scene._points_rect)
            self._lock(T.LIGHT_FIRST)
        elif step["stage"] == "light" and chain["points"] > step["points"]:
            # A Light was struck: a try again after a miss, another after
            # the first lands, the move to Strong after the second.
            landed = chain["landed"] > before
            step.update(points=chain["points"], landed=chain["landed"], target=chain["target"])
            if not landed:
                self._lock(T.LIGHT_MISSED)
                return
            step["lights"] += 1
            if step["lights"] == 1:
                self._lock(T.LIGHT_AGAIN)
                return
            if scene.battle.chain_points_left < BattleSettings.STROKES["strong"]["points"]:
                # So many misses that Strong no longer fits.
                self._end_step()
                self._talk(T.OTHER_MANA)
                return
            step.update(stage="strong_move", beat=0.0)
            self._talk(T.STRONG_CHANCE, self._strong_row)
            self._lock(T.STRONG_MOVE)
        elif step["stage"] == "strong_move" and not self._lock_open:
            # His face moves on the bar as the cursor does; once the cursor
            # rests on Strong, a beat later, she points it out.
            if scene.stroke_menu is None or scene.stroke_menu.cursor != _STROKE_ROWS["strong"]:
                step["beat"] = 0.0
                return
            step["beat"] += dt
            if step["beat"] >= T.FACE_BEAT:
                step.update(stage="strong", points=chain["points"], landed=chain["landed"],
                            target=chain["target"])
                self._talk(T.FACE, self._turn_bar)
                self._talk(T.FATIGUE, self._turn_bar)
                self._lock(T.STRONG_GO)
        elif step["stage"] == "strong" and chain["points"] - step["points"] >= 3:
            missed = chain["landed"] == before
            self._end_step()
            if missed:
                self._talk(T.MISSED)
            self._talk(T.OTHER_MANA)

    # ------------------------------------------------------------------
    # THE LOCK
    # ------------------------------------------------------------------

    def _target(self) -> tuple[str, Any]:
        """Return where the lesson points now.

        One of ("command", row), ("stroke", row), ("cell", (row, col)),
        ("grid_row", row), ("item", row), ("ally", index in the targets) or
        ("bar", None): the turn order bar, the cursor free to move.
        """
        scene = self.scene
        step = self.step
        name = step["name"]
        if name == "defend":
            menu = scene.side_menu
            if scene._page == -1 and menu is not None:
                return "side", next(k for k, item in enumerate(menu.items) if item.label == "Defend")
            return "page_left", None
        if name == "warm_up":
            if step["stage"] == "attack":
                return "command", _ATTACK_ROW
            if step["stage"] == "strong_move":
                return "bar", None
            return "stroke", _STROKE_ROWS[step["stage"]]
        if name == "item":
            if scene._pending_command is not None:
                ids = [c.id for c in scene._target_pool]
                return "ally", ids.index(step["ally"]) if step["ally"] in ids else 0
            if scene.item_menu is not None:
                labels = [item.label for item in scene.item_menu.items]
                return "item", next((k for k, label in enumerate(labels) if label.startswith(step["item"])), 0)
            return "command", _ITEM_ROW
        if scene.ability_menu is not None:
            grid = scene.ability_menu
            for r, row in enumerate(grid.rows):
                for c, cell in enumerate(row.cells):
                    if cell is None:
                        continue
                    data_id = cell.data["id"] if cell.data is not None else None
                    if data_id == step["move"]:
                        # The stance switch has no move: its row as a whole.
                        return ("grid_row", r) if data_id is None else ("cell", (r, c))
        if scene.stroke_menu is not None:
            return "stroke", _STROKE_ELEMENT_ROW
        return "command", _ELEMENT_ROW

    def _hold_cursor(self) -> None:
        """Keep the cursor on what she means, on the first page of commands."""
        scene = self.scene
        kind, where = self._target()
        if kind == "cell":
            scene.ability_menu.row, scene.ability_menu.col = where
        elif kind == "grid_row":
            scene.ability_menu.row, scene.ability_menu.col = where, 0
        elif kind == "item":
            scene.item_menu.cursor = where
        elif kind == "ally":
            scene._target_cursor = where
        elif kind == "stroke" and scene.stroke_menu is not None:
            scene.stroke_menu.cursor = where
        elif kind == "side":
            scene.side_menu.cursor = where
        elif kind == "page_left" and scene._page == 1:
            scene._back_to_commands()
        elif kind == "command" and scene.stroke_menu is None and scene.ability_menu is None:
            if scene._page != 0:
                scene._back_to_commands()
            scene.command_menu.cursor = where

    def _lock_light(self) -> pygame.Rect | None:
        """The area a lesson's lock points at, while the player picks, or None."""
        scene = self.scene
        if self.step is None or not self._commanding():
            return None
        kind, where = self._target()
        if kind == "ally":
            return scene.stage.party_row_rect(scene._target_pool[where].id)
        if kind == "bar":
            return self._turn_bar()
        if kind == "page_left":
            return self._commands_window()
        if kind == "side":
            return scene._menu_row_rect(scene.side_menu, where)
        if scene._pending_command is not None:
            return None
        if kind == "cell":
            return scene._grid_cell_rect(scene.ability_menu, *where)
        if kind == "grid_row":
            return scene._grid_row_rect(scene.ability_menu, where)
        if kind == "item":
            return scene._menu_row_rect(scene.item_menu, where)
        if kind == "stroke" and scene.stroke_menu is not None:
            return scene._menu_row_rect(scene.stroke_menu, where)
        if kind == "command" and scene.stroke_menu is None and scene.ability_menu is None:
            return scene._menu_row_rect(scene.command_menu, where)
        return None

    def _strong_row(self) -> pygame.Rect | None:
        """Strong in the stroke list, its hit chance and all."""
        if self.scene.stroke_menu is None:
            return None
        return self.scene._menu_row_rect(self.scene.stroke_menu, _STROKE_ROWS["strong"])

    def _commands_window(self) -> pygame.Rect | None:
        """The window the commands are in, at the bottom left."""
        return pygame.Rect(0, ScreenSettings.HEIGHT - UISettings.TEXT_BOX_HEIGHT,
                           UISettings.COMMAND_PANEL_WIDTH, UISettings.TEXT_BOX_HEIGHT)

    def _meter_window(self) -> pygame.Rect | None:
        """The block meter, in the window the commands were in."""
        return self._commands_window()

    def _turn_bar(self) -> pygame.Rect | None:
        """The turn order bar, all of it that is drawn."""
        return self.scene.stage.turn_bar_rect(1 + BattleSettings.TURN_ORDER_LENGTH)

    def _highlight(self) -> pygame.Rect | None:
        """The one area left lit now, or None."""
        if self._talks:
            light = self._talks[0][1]
            return light() if light is not None else None
        return self._lock_light()

    # ------------------------------------------------------------------
    # RENDER
    # ------------------------------------------------------------------

    def render(self, surface: pygame.Surface) -> None:
        """Dim all but the highlight, then her box, and the yes/no."""
        if not self.active:
            return
        self._sync_box()
        lit = self._highlight()
        if lit is not None:
            dim_except(surface, lit)
        if self.box.is_done():
            return
        # Her box at the top, or at the bottom when what she points at is up there.
        height = self.box.height
        top = surface.get_height() - height if lit is not None and lit.top < height else 0
        self.box.render(surface.subsurface(pygame.Rect(0, top, ScreenSettings.WIDTH, height)))
        if self._asking and self._talks and self._typed():
            self._render_yes_no(surface)

    def _render_yes_no(self, surface: pygame.Surface) -> None:
        """Yes and No in a small window under her box, at the right."""
        row = text_renderer.line_height(FontSettings.SIZE_BODY)
        pad = UISettings.TEXT_BOX_PADDING
        rect = pygame.Rect(
            ScreenSettings.WIDTH - T.CHOICE_WIDTH, self.box.height,
            T.CHOICE_WIDTH, 2 * pad + 2 * row,
        )
        draw_window(surface, rect)
        for index, word in enumerate(T.ANSWERS):
            y = rect.top + pad + index * row
            if index == self._choice:
                text_renderer.draw_pointer(surface, (rect.left + pad + 6, y + FontSettings.SIZE_BODY // 2))
            text_renderer.draw_text(surface, word, (rect.left + pad + 12, y), size=FontSettings.SIZE_BODY)


def dim_except(surface: pygame.Surface, lit: pygame.Rect) -> None:
    """Halve the brightness of ``surface`` outside ``lit``: color math outside one window."""
    lit = lit.clip(surface.get_rect())
    keep = surface.subsurface(lit).copy()
    shade = pygame.Surface(surface.get_size())
    shade.fill(T.DIM)
    surface.blit(shade, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
    surface.blit(keep, lit.topleft)
