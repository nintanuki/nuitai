"""Lore, under Data: short spoiler-free pages that unlock silently (Frankie, 10/23).

The pages are ``game/shared/lore.md``, which the cartridge reads too
(``game/snes/tools/make_art.py``), so the words cannot disagree. Each page
says when it appears: ``start`` from New Game, ``stance <name>`` the first
time a member acts in that stance in a fight, ``event <name>`` at a moment
in the story, ``heard`` the first time a Words page's word is said, ``named``
the first time the page's title, or a name in its ``**Also:**`` line, is said
while ``naming`` is on (the Kaigara Kame's talk, Frankie 10/27). Several,
joined by ``or``, mean whichever comes first. An
unlocked page is a party flag, so it saves with the game. Each page is in
one of ``CATEGORIES``, a row of its own on Data (Frankie, 10/25).
"""

from __future__ import annotations

import os
import re
from typing import TYPE_CHECKING

from core.shared import SHARED_DIR
from ui import notices

if TYPE_CHECKING:
    from systems.party import Party

LORE_PATH = os.path.join(SHARED_DIR, "lore.md")
# Data's rows for the pages, in order, each with its help line (30 letters
# at most, for the cartridge). Frankie named People, Places, Food and Gods
# (10/25) and Words (10/26); Faiths and Arts hold the rest.
CATEGORIES = (
    ("People", "The people you have met."),
    ("Places", "The islands and the seas."),
    ("Food", "What the islands eat."),
    ("Gods", "The Akua and the divine."),
    ("Faiths", "Faiths and holy orders."),
    ("Arts", "Fighting arts and dances."),
    ("Words", "Everyday words and sayings."),
)


def read_pages(path: str = LORE_PATH) -> list[dict[str, str]]:
    """Every page in the file, in order: its title, when it unlocks, its words."""
    with open(path, encoding="utf-8") as f:
        text = f.read()
    pages = []
    # The pages start at the first title after the notes at the top.
    for block in re.split(r"^## ", text, flags=re.M)[1:]:
        title, _, rest = block.partition("\n")
        unlock = re.search(r"^\*\*Unlocks:\*\* *(.+)$", rest, re.M)
        category = re.search(r"^\*\*Category:\*\* *(.+)$", rest, re.M)
        also = re.search(r"^\*\*Also:\*\* *(.+)$", rest, re.M)
        words = [line for line in rest.splitlines() if line.strip() and not line.startswith("**")]
        pages.append({"title": title.strip(), "unlock": unlock.group(1).strip() if unlock else "start",
                      "category": category.group(1).strip() if category else "", "text": " ".join(words),
                      "also": [n.strip() for n in also.group(1).split(",")] if also else []})
    return pages


PAGES = read_pages()


def _flag(page: dict[str, str]) -> str:
    return "lore:" + page["title"]


def _find(party: "Party", page: dict[str, str]) -> None:
    """Unlock ``page``; the first time, post a small "Lore page added" notice with a chime (Frankie, 11/12)."""
    if party.flags.get(_flag(page)):
        return
    party.flags[_flag(page)] = True
    if page["unlock"] != "start":
        notices.post_notice(f"Lore page added: {page['title']}", sound="hit_sparkle_1")


def unlocked(party: "Party", category: str | None = None) -> list[dict[str, str]]:
    """The pages the party has, in the file's order; only ``category``'s when given."""
    return [p for p in PAGES if (p["unlock"] == "start" or party.flags.get(_flag(p)))
            and category in (None, p["category"])]


def in_category(category: str) -> list[dict[str, str]]:
    """Every page in ``category``, found or not."""
    return [p for p in PAGES if p["category"] == category]


def categories_found(party: "Party") -> list[tuple[str, str]]:
    """The categories with a page found, each with its help line: the others stay hidden."""
    return [(name, line) for name, line in CATEGORIES if unlocked(party, name)]


# Whether a line said now finds the ``named`` pages: on while the Kaigara Kame's
# scenes play (core/scenes/overworld_scene.py), off otherwise.
naming = False


def _said(word: str, line: str) -> bool:
    """Whether ``word`` is said in ``line``, a whole word, any case."""
    return re.search(r"(?<![\w'])" + re.escape(word) + r"(?![\w'])", line, re.I) is not None


def hear(party: "Party", line: str) -> None:
    """Unlock every Words page whose word is said in ``line`` (Frankie, 10/26), and while
    ``naming`` is on every ``named`` page whose title or other name is (Frankie, 10/27)."""
    for page in PAGES:
        when = page["unlock"].split(" or ")
        if "heard" in when and _said(page["title"], line):
            _find(party, page)
        elif naming and "named" in when and any(_said(name, line) for name in [page["title"], *page["also"]]):
            _find(party, page)


def unlock(party: "Party", when: str) -> None:
    """Unlock every page that appears ``when`` (``stance Lelua``, ``event hina_home``), silently."""
    for page in PAGES:
        if when in page["unlock"].split(" or "):
            _find(party, page)


def unlock_items(party: "Party") -> None:
    """Unlock the pages that appear with an item, ``item niu``, once the bag has it (Food, Frankie 10/30)."""
    for page in PAGES:
        if party.flags.get(_flag(page)):
            continue
        for when in page["unlock"].split(" or "):
            if when.startswith("item ") and party.inventory.get(when[5:], 0) > 0:
                _find(party, page)
