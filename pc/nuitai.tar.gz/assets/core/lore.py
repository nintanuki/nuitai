"""Lore, under Data: short spoiler-free pages that unlock silently (Frankie, 10/23).

The pages are ``game/shared/lore.md``, which the cartridge reads too
(``game/snes/tools/make_art.py``), so the words cannot disagree. Each page
says when it appears: ``start`` from New Game, ``stance <name>`` the first
time a member acts in that stance in a fight, ``event <name>`` at a moment
in the story, ``heard`` the first time a Words page's word is said, ``named``
the first time the page's title, or a name in its ``**Also:**`` line, is said
while ``naming`` is on (the Kaigara Kame's talk, Frankie 10/27). ``mentioned``
the same, but in every line of dialogue all game (People and Food, Māla; Frankie 11/13). Several,
joined by ``or``, mean whichever comes first. An
unlocked page is a party flag, so it saves with the game. Each page is in
one of ``CATEGORIES``, a row of its own on Data (Frankie, 10/25).
"""

from __future__ import annotations

import os
import re
from typing import TYPE_CHECKING

from core.shared import SHARED_DIR
from ui import notices

if TYPE_CHECKING:
    from systems.party import Party

LORE_PATH = os.path.join(SHARED_DIR, "lore.md")
# Data's rows for the pages, in order, each with its help line (30 letters
# at most, for the cartridge). Frankie named People, Places, Food and Gods
# (10/25) and Words (10/26); Faiths and Arts hold the rest.
CATEGORIES = (
    ("People", "The people you have met."),
    ("Places", "The islands and the seas."),
    ("Food", "What the islands eat."),
    ("Gods", "The Akua and the divine."),
    ("Faiths", "Faiths and holy orders."),
    ("Arts", "Fighting arts and dances."),
    ("Words", "Everyday words and sayings."),
)
# Words is the Glossary on Info, lifted out of Lore (Frankie, 11/13); its pages are still lore pages.
GLOSSARY = "Words"


def read_pages(path: str = LORE_PATH) -> list[dict[str, str]]:
    """Every page in the file, in order: its title, when it unlocks, its words."""
    with open(path, encoding="utf-8") as f:
        text = f.read()
    pages = []
    # The pages start at the first title after the notes at the top.
    for block in re.split(r"^## ", text, flags=re.M)[1:]:
        title, _, rest = block.partition("\n")
        unlock = re.search(r"^\*\*Unlocks:\*\* *(.+)$", rest, re.M)
        category = re.search(r"^\*\*Category:\*\* *(.+)$", rest, re.M)
        also = re.search(r"^\*\*Also:\*\* *(.+)$", rest, re.M)
        words = [line for line in rest.splitlines() if line.strip() and not line.startswith("**")]
        pages.append({"title": title.strip(), "unlock": unlock.group(1).strip() if unlock else "start",
                      "category": category.group(1).strip() if category else "", "text": " ".join(words),
                      "also": [n.strip() for n in also.group(1).split(",")] if also else []})
    return pages


PAGES = read_pages()


def _flag(page: dict[str, str]) -> str:
    return "lore:" + page["title"]


def _find(party: "Party", page: dict[str, str]) -> None:
    """Unlock ``page``; the first time, post a small silent notice, "Word learned" for a Words page and
    "Lore page added" for any other (Frankie, 11/13)."""
    if party.flags.get(_flag(page)):
        return
    party.flags[_flag(page)] = True
    if page["unlock"] != "start":
        lead = "Word learned" if page["category"] == GLOSSARY else "Lore page added"
        notices.post_notice(f"{lead}: {page['title']}")


def unlocked(party: "Party", category: str | None = None) -> list[dict[str, str]]:
    """The pages the party has, in the file's order; only ``category``'s when given."""
    return [p for p in PAGES if (p["unlock"] == "start" or party.flags.get(_flag(p)))
            and category in (None, p["category"])]


def in_category(category: str) -> list[dict[str, str]]:
    """Every page in ``category``, found or not."""
    return [p for p in PAGES if p["category"] == category]


def newest(party: "Party", category: str | None = None, *, lore_only: bool = False) -> dict[str, str] | None:
    """The page found last (flags keep the order they were set in), from ``category`` if given; ``lore_only``
    leaves out the Words. A page that was there from New Game counts only when none was found since."""
    found = [p for p in unlocked(party, category) if not (lore_only and p["category"] == GLOSSARY)]
    for key in reversed([k for k in party.flags if k.startswith("lore:")]):
        for page in found:
            if _flag(page) == key:
                return page
    return found[-1] if found else None


def categories_found(party: "Party") -> list[tuple[str, str]]:
    """The categories with a page found, each with its help line: the others stay hidden."""
    return [(name, line) for name, line in CATEGORIES if unlocked(party, name)]


# Whether a line said now finds the ``named`` pages: on while the Kaigara Kame's
# scenes play (core/scenes/overworld_scene.py), off otherwise.
naming = False


def _said(word: str, line: str) -> bool:
    """Whether ``word`` is said in ``line``, a whole word, any case."""
    return re.search(r"(?<![\w'])" + re.escape(word) + r"(?![\w'])", line, re.I) is not None


def _names(page: dict[str, str]) -> list[str]:
    return [page["title"], *page["also"]]


def _spans(name: str, line: str) -> list[tuple[int, int]]:
    """Where ``name`` is said in ``line``: a whole word, any case, with an 's after it allowed.
    An apostrophe before it means a different word ('Ulu, breadfruit, is not Ulu, the chief)."""
    pattern = r"(?<![\w'])" + re.escape(name) + r"(?:'s)?(?![\w'])"
    return [m.span() for m in re.finditer(pattern, line, re.I)]


def _mentioned(line: str) -> list[dict[str, str]]:
    """The ``mentioned`` pages whose name is said in ``line``. The longest name wins a stretch
    of the line, whatever page it is on, so Māla Iki is not Māla and 'Ulu Poi is not Poi."""
    found = []
    for page in PAGES:
        for name in _names(page):
            found += [(e - b, b, e, page) for b, e in _spans(name, line)]
    taken: list[tuple[int, int]] = []
    pages = []
    for _, b, e, page in sorted(found, key=lambda f: -f[0]):
        if any(b < te and tb < e for tb, te in taken):
            continue
        taken.append((b, e))
        if "mentioned" in page["unlock"].split(" or ") and page not in pages:
            pages.append(page)
    return pages


def hear(party: "Party", line: str) -> None:
    """Unlock every Words page whose word is said in ``line`` (Frankie, 10/26), every
    ``mentioned`` page whose name is (Frankie, 11/13), and while ``naming`` is on every
    ``named`` page whose title or other name is (Frankie, 10/27)."""
    for page in PAGES:
        when = page["unlock"].split(" or ")
        if "heard" in when and _said(page["title"], line):
            _find(party, page)
        elif naming and "named" in when and any(_said(name, line) for name in _names(page)):
            _find(party, page)
    for page in _mentioned(line):
        _find(party, page)


def unlock(party: "Party", when: str) -> None:
    """Unlock every page that appears ``when`` (``stance Lelua``, ``event hina_home``), silently."""
    for page in PAGES:
        if when in page["unlock"].split(" or "):
            _find(party, page)


def unlock_items(party: "Party") -> None:
    """Unlock the pages that appear with an item, ``item niu``, once the bag has it (Food, Frankie 10/30)."""
    for page in PAGES:
        if party.flags.get(_flag(page)):
            continue
        for when in page["unlock"].split(" or "):
            if when.startswith("item ") and party.inventory.get(when[5:], 0) > 0:
                _find(party, page)
