"""Every word the player reads that the lines window does not open, found and changed in place (Frankie, 11/22).

The Workshop's Dialogue editor opens the story scripts, the field lines and what each person and menu
says (``core/dialogue_editor.py``, ``core/dialogue_villagers.py``). This is the rest, for the Workshop's
Game text window (``workshop/texts.py``), in four kinds of place, none of them moved:

* **json**: the signs, a person's menu and requests, a menu's question titles, the hunts, the shops'
  greetings, the recipes' help, and ``battle.json``'s names, descriptions
  and help lines (``JSON_SOURCES`` says which fields are words and which are numbers or notes);
* **md**: the Lore and Glossary pages' words (``game/shared/lore.md``);
* **code**: item, Skill and menu names, the quest log, the battle's messages and the rest the code holds
  (``core/code_text.py``).

A change is written in its own place, the one string only, and every other byte of the file stays as it
was (a JSON file is edited at the string's place in the text, not written out again). A name or key is
never offered here: ids, flags, speakers, and anything the game uses to find something.

``catalog()`` is every piece of text; ``save(changes)`` writes the changed ones; ``uncovered_json()`` lists
any words in the data files that nothing opens, which ``tests/test_game_text.py`` keeps empty.

No pygame and no tkinter here.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, replace as _replace

from core import code_text
from core.dialogue_editor import _write
from core.shared import SHARED_DIR

PYGAME_DIR = code_text.PYGAME_DIR
DATA_DIR = os.path.join(PYGAME_DIR, "data")
STRING = re.compile(r'"(?:[^"\\]|\\.)*"')
PLACEHOLDERS = code_text.PLACEHOLDERS


class TextError(ValueError):
    """A change that cannot be written, said in plain words."""


@dataclass(frozen=True)
class Entry:
    """One piece of words."""

    kind: str           # "json", "md" or "code"
    group: str          # the heading it is listed under
    file: str           # json and md: a path from game/pygame; code: the same, with forward slashes
    key: str            # where in the file: a JSON path as text, a lore page's title, or code's place
    label: str          # who or what it is, for the list
    text: str
    context: str = ""   # one more line to tell it apart: the code around it, the page's category
    risky: bool = False  # the code also uses these exact words to find something: change with care

    @property
    def ident(self) -> tuple[str, str]:
        return (self.file, self.key)


# ----------------------------------------------------------------------
# JSON: WHICH FIELDS ARE WORDS
# ----------------------------------------------------------------------

# A pattern is a path of keys; ``*`` matches any key or list place. A match must be a string.
# Names, ids, flags and numbers are not listed; the speaker of a line (the first of a pair) is not either.
CELL_WORDS = (
    ("buildings", "*", "look", "*", 1),                  # a sign, a board, a barrel: what it says when examined
    ("buildings", "*", "before"),                        # what Kailo says looking at it before something happened
    ("people", "*", "menu", "ask"),                      # the question over a person's menu
    ("people", "*", "menu", "choices", "*", 0),          # a menu's answers
    ("people", "*", "raise", "*"),                       # the priest's words when raising the fallen
    ("people", "*", "request", "asks", "*"),             # a request: what is asked
    ("people", "*", "request", "thanks", "*"),
    ("people", "*", "request", "after"),
    ("people", "*", "request", "after_wake", "*"),
)
ASK_WORDS = (
    ("questions", "*", "ask"),                           # the question's title in the menu
    ("hina_meets", "*", 1),                              # what is said when Hina walks in first
    ("questions", "*", "with_hina", "*", 1),             # an answer when Hina is with Kailo
)
# battle.json: the names, descriptions and help the player sees. Every ``about`` and ``*_about`` there is a
# note for Frankie and Claude (who decided what, and when), never shown; numbers and ids are not words.
BATTLE_WORDS = (
    ("characters", "*", "name"), ("characters", "*", "role"),
    ("moves", "*", "name"), ("moves", "*", "description"), ("moves", "*", "help"),
    ("rules", "pound_moves", "*", "description"), ("rules", "dance_moves", "*", "description"),
    ("weapon_types", "*", "name"),
    ("weapons", "*", "name"), ("weapons", "*", "about"),
    ("relics", "*", "name"), ("relics", "*", "about"),
    ("cooking", "dishes", "*", "description"),
    ("monsters", "*", "name"),
    ("combos", "*", "name"), ("combos", "*", "description"),
    ("bestiary", "*", "name"), ("bestiary", "*", "description"),
    ("encounters", "*", "enemies", "*", "name"),
)

# (group, folder under data/ or a path from game/pygame, file pattern or None, words, how to describe one)
JSON_SOURCES = (
    ("Signs, menus and requests in rooms", "data/cells", CELL_WORDS, "cell"),
    ("Menu questions (Ask about...)", "data/asks", ASK_WORDS, "ask"),
    ("The hunters' lodge", "data/bounties", (("lines", "*"), ("lines", "choices", "*"), ("lines", "take_choices", "*"), ("posts", "*", "name"), ("posts", "*", "what"),
                                              ("posts", "*", "offer"), ("posts", "*", "paid")), "plain"),
    ("Shops", "data/shops", (("greeting",),), "plain"),
    ("Recipes", "data/crafting", (("recipes", "*", "about"), ("groups", "*", "about")), "plain"),
    ("Battle: names, descriptions and help", "../shared/battle.json", BATTLE_WORDS, "battle"),
    # The words that make up the generated weapons' and relics' names. A material's name and a relic type are not
    # here: the wearers' list and the unique names find them by those exact words.
    ("Gear names and what a weapon's bonus says", "../shared/item-names.json", (
        ("weapons", "benefits", "*", "word"), ("weapons", "benefits", "*", "help"), ("weapons", "penalties", "*", "help"),
        ("weapons", "unique", "*", "name"), ("relics", "unique", "*", "name")), "names"),
)
# Words in data files that are deliberately not offered, with the reason: the test checks this list is all there is.
NOT_WORDS = {
    "about": "a note for Frankie and Claude, never shown",
    "_about": "a note for Frankie and Claude, never shown",
    "speaker": "who is talking: the name over the box, and what finds the person (the Dialogue editor picks it)",
    "sheet": "a picture's name",
}
# A shop's or generated place's ``name`` in its file: the game never reads it (the room names are in settings.py).
UNREAD_NAME_FOLDERS = ("shops", "generated")
# Files that hold words nothing shows: stubs of the first engine layer (the opening cards are in story-field.md).
NOT_SHOWN = ("data/dungeons/demo_room.json", "data/dialogue/opening.json")
# Fields the game never reads, though the file has words in them (battle.json's are for the cartridge and the wiki):
# a monster's ``form``, a stance's ``about``, a Scold ``reactions`` text,
# the Wrath ``trait`` text, ``weapon_types.one``, ``rules.cook_dishes``.



def _matches(path: tuple, pattern: tuple) -> bool:
    return len(path) == len(pattern) and all(p == "*" or p == q for p, q in zip(pattern, path))


def _json_tokens(text: str) -> list[tuple[int, int]]:
    return [(m.start(), m.end()) for m in STRING.finditer(text)]


def _json_order(value, path: tuple = ()):
    """Every string of a JSON value in the order it is written: (path, is it a key)."""
    if isinstance(value, dict):
        for key, inner in value.items():
            yield path + (key,), True
            yield from _json_order(inner, path + (key,))
    elif isinstance(value, list):
        for k, inner in enumerate(value):
            yield from _json_order(inner, path + (k,))
    elif isinstance(value, str):
        yield path, False


def _json_places(text: str, data) -> dict[tuple, tuple[int, int]]:
    """Where each string value sits in the file's text, by its path."""
    spans = _json_tokens(text)
    order = list(_json_order(data))
    if len(spans) != len(order):
        raise TextError("This file has a string the Workshop cannot place; it was not changed.")
    return {path: span for (path, is_key), span in zip(order, spans) if not is_key}


def _json_key(path: tuple) -> str:
    return json.dumps(list(path), ensure_ascii=False)


def _describe(kind: str, data, path: tuple, file: str) -> str:
    """Who or what a piece of words belongs to, in a few plain words."""
    name = os.path.splitext(os.path.basename(file))[0]
    if kind == "cell" and path[0] == "people":
        person = data["people"][path[1]]
        who = person.get("speaker") or person.get("sheet", "?")
        what = ".".join(str(p) for p in path[2:])
        if path[2] == "menu":
            what = "menu question" if path[3] == "ask" else f"menu answer {path[4] + 1}"
        elif path[2] == "request":
            what = "request: " + (path[3] if len(path) == 4 else f"{path[3]} {path[4] + 1}")
        return f"{name}: {who} at {person['col']},{person['row']}: {what}"
    if kind == "cell":
        thing = data["buildings"][path[1]]
        return f"{name}: {thing.get('kind', 'thing')} at {thing.get('col', '?')},{thing.get('row', '?')}: " \
               + ("what it says" if path[2] == "look" else "before")
    if kind == "ask":
        if path[0] == "hina_meets":
            return f"{name}: when Hina walks in, line {path[1] + 1}"
        question = data["questions"][path[1]]
        if path[2] == "ask":
            return f"{name}: question {path[1] + 1} (its title in the menu)"
        return f"{name}: answer to '{question['ask'][:30]}' with Hina, line {path[3] + 1}"
    if kind == "battle":
        node = data
        parts = []
        for p in path[:-1]:
            node = node[p]
            if isinstance(node, dict) and isinstance(node.get("id"), str) and node.get("id") not in parts:
                parts.append(node["id"])
        top = path[1] if path[0] == "rules" else path[0]
        return f"{top} {' / '.join(parts)}: {path[-1]}".replace("  ", " ")
    return f"{name}: {'.'.join(str(p) for p in path)}"


def _json_files(source: str) -> list[str]:
    full = os.path.normpath(os.path.join(PYGAME_DIR, source))
    if os.path.isfile(full):
        return [full]
    return [os.path.join(full, f) for f in sorted(os.listdir(full)) if f.endswith(".json")]


def json_entries() -> list[Entry]:
    found = []
    for group, source, words, kind in JSON_SOURCES:
        for path in _json_files(source):
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            for where, text in _json_strings(data):
                if any(_matches(where, pattern) for pattern in words) and text.strip():
                    found.append(Entry("json", group, _relative(path), _json_key(where),
                                       _describe(kind, data, where, path), text))
    return found


def _json_strings(value, path: tuple = ()):
    for where, is_key in _json_order(value, path):
        if not is_key:
            yield where, _at(value, where[len(path):])


def _at(value, path: tuple):
    for p in path:
        value = value[p]
    return value


def _relative(path: str) -> str:
    return os.path.relpath(path, PYGAME_DIR).replace(os.sep, "/")


def _absolute(relative: str) -> str:
    return os.path.normpath(os.path.join(PYGAME_DIR, *relative.split("/")))


# ----------------------------------------------------------------------
# LORE AND GLOSSARY
# ----------------------------------------------------------------------

LORE_PATH = os.path.join(SHARED_DIR, "lore.md")


def _lore_pages(lines: list[str]) -> list[tuple[str, str, int, int]]:
    """(title, category, first line, last line + 1) of each page's words in the file's lines."""
    pages = []
    title = category = ""
    first = last = None
    for k, raw in enumerate(lines + ["## "]):
        line = raw.rstrip("\r\n")
        if line.startswith("## "):
            if title and first is not None:
                pages.append((title, category, first, last + 1))
            title, category, first, last = line[3:].strip(), "", None, None
        elif line.startswith("**Category:**"):
            category = line[len("**Category:**"):].strip()
        elif line.strip() and not line.startswith("**") and title:
            if first is None:
                first = k
            last = k
    return pages


def lore_entries() -> list[Entry]:
    with open(LORE_PATH, encoding="utf-8", newline="") as f:
        lines = f.read().splitlines(keepends=True)
    found = []
    for title, category, first, stop in _lore_pages(lines):
        text = " ".join(line.strip() for line in lines[first:stop] if line.strip())
        group = "Glossary (Words)" if category == "Words" else "Lore pages"
        found.append(Entry("md", group, _relative(LORE_PATH), title, f"{category}: {title}", text, f"Lore page, {category}"))
    return found


# ----------------------------------------------------------------------
# CODE
# ----------------------------------------------------------------------


def _identity_words() -> set[str]:
    """Words the code also uses as a name to find something (a dict key, a heading of the field lines): changing
    them in one place and not the other would break the game, so the window warns."""
    names: set[str] = set()
    import ast
    for relative in code_text.code_files():
        try:
            tree = ast.parse(code_text._read(relative))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Dict):
                names.update(k.value for k in node.keys if isinstance(k, ast.Constant) and isinstance(k.value, str))
            elif isinstance(node, ast.Subscript) and isinstance(node.slice, ast.Constant) and isinstance(node.slice.value, str):
                names.add(node.slice.value)
            elif isinstance(node, ast.Compare):
                for side in [node.left, *node.comparators]:
                    if isinstance(side, ast.Constant) and isinstance(side.value, str):
                        names.add(side.value)
                    elif isinstance(side, (ast.Tuple, ast.List, ast.Set)):
                        names.update(e.value for e in side.elts if isinstance(e, ast.Constant) and isinstance(e.value, str))
    try:
        with open(os.path.join(SHARED_DIR, "story-field.md"), encoding="utf-8") as f:
            names.update(line[3:].strip() for line in f if line.startswith("## "))
    except OSError:
        pass
    return names


def code_entries() -> list[Entry]:
    texts = code_text.all_texts()
    identity = _identity_words()
    sources: dict[str, list[str]] = {}
    found = []
    for item in texts:
        if item.file not in sources:
            sources[item.file] = code_text._read(item.file).decode("utf-8").splitlines()
        line = sources[item.file][item.start[0] - 1].strip()
        found.append(Entry("code", f"In the code: {item.file}", item.file, item.key,
                           f"{item.scope} ({item.file}, line {item.start[0]})", item.text, line[:160],
                           risky=item.text in identity or item.text.partition(": ")[0] in identity))
    return found


# ----------------------------------------------------------------------
# THE CATALOG, AND SAVING
# ----------------------------------------------------------------------


def catalog() -> list[Entry]:
    return [*json_entries(), *lore_entries(), *code_entries()]


def placeholders(text: str) -> list[str]:
    return sorted(PLACEHOLDERS.findall(text))


def _check_placeholders(was: str, now: str, where: str) -> None:
    if placeholders(was) != placeholders(now):
        raise TextError(f"{where}: the words lost or changed a part the game fills in. Keep every "
                        f"{', '.join(placeholders(was)) or 'part'} exactly as it was.")


def _save_json(path: str, edits: dict[str, tuple[str, str]]) -> None:
    with open(path, encoding="utf-8", newline="") as f:
        text = f.read()
    data = json.loads(text)
    places = _json_places(text, data)
    escaped = "\\u" in text          # keep each file's way with accented letters
    changes = []
    for key, (was, now) in edits.items():
        where = tuple(json.loads(key))
        if where not in places or _at(data, where) != was:
            raise TextError(f"These words in {_relative(path)} changed since the window opened; reopen it.")
        _check_placeholders(was, now, os.path.basename(path))
        changes.append((places[where], json.dumps(now, ensure_ascii=escaped)))
    for (a, b), literal in sorted(changes, reverse=True):
        text = text[:a] + literal + text[b:]
    json.loads(text)            # still a file the game can read
    _write(path, text)


def _save_lore(edits: dict[str, tuple[str, str]]) -> None:
    with open(LORE_PATH, encoding="utf-8", newline="") as f:
        lines = f.read().splitlines(keepends=True)
    ending = "\r\n" if lines and lines[0].endswith("\r\n") else "\n"
    pages = {title: (first, stop) for title, _c, first, stop in _lore_pages(lines)}
    for title, (was, now) in sorted(edits.items(), key=lambda item: -pages.get(item[0], (0, 0))[0]):
        if title not in pages:
            raise TextError(f"The page '{title}' is not in the lore file any more; reopen the window.")
        first, stop = pages[title]
        if " ".join(line.strip() for line in lines[first:stop] if line.strip()) != was:
            raise TextError(f"The page '{title}' changed since the window opened; reopen it.")
        if "\n" in now.strip():
            raise TextError("A lore page is one paragraph: no new lines.")
        lines[first:stop] = [now.strip() + ending]
    _write(LORE_PATH, "".join(lines))


def save(changes: dict[tuple[str, str], tuple[str, str]], kinds: dict[tuple[str, str], str]) -> list[str]:
    """Write changed words. ``changes`` maps (file, key) to (the words when the window opened, the words now);
    ``kinds`` says which kind each is. Every file is checked before any is written; returns the files written.
    Raises ``TextError`` (nothing written) with the reason in plain words."""
    by_file: dict[tuple[str, str], dict[str, tuple[str, str]]] = {}
    for (file, key), pair in changes.items():
        if pair[0] != pair[1]:
            by_file.setdefault((kinds[(file, key)], file), {})[key] = pair
    written = []
    # Check all first (a dry run on every file), then write.
    for (kind, file), edits in by_file.items():
        try:
            _dry_run(kind, file, edits)
        except (code_text.CodeTextError, TextError) as error:
            raise TextError(str(error)) from error
    for (kind, file), edits in by_file.items():
        if kind == "json":
            _save_json(_absolute(file), edits)
        elif kind == "md":
            _save_lore(edits)
        else:
            code_text.replace(file, edits)
        written.append(file)
    return written


def _dry_run(kind: str, file: str, edits: dict[str, tuple[str, str]]) -> None:
    if kind == "json":
        path = _absolute(file)
        with open(path, encoding="utf-8", newline="") as f:
            text = f.read()
        data = json.loads(text)
        places = _json_places(text, data)
        for key, (was, now) in edits.items():
            where = tuple(json.loads(key))
            if where not in places or _at(data, where) != was:
                raise TextError(f"These words in {file} changed since the window opened; reopen it.")
            _check_placeholders(was, now, file)
    elif kind == "md":
        for key, (was, now) in edits.items():
            _check_placeholders(was, now, key)
            if "\n" in now.strip():
                raise TextError("A lore page is one paragraph: no new lines.")
    else:
        for key, (was, now) in edits.items():
            _check_placeholders(was, now, key)


# ----------------------------------------------------------------------
# WHAT NOTHING OPENS
# ----------------------------------------------------------------------


def uncovered_json() -> list[str]:
    """Words in the data files that neither this window nor the lines window opens: ``file: path: start of the
    words``. Empty when the Workshop edits every sentence in ``data/``. The lines window's own fields are
    named here (``dialogue_villagers``), so they are not reported."""
    from core import dialogue_villagers as villagers
    opened = {(e.file, e.key) for e in json_entries()}
    missing = []
    skipped_fields = ("lines", "night_lines", "flag_lines", "say", "gift", "first")
    for folder in sorted(os.listdir(DATA_DIR)):
        directory = os.path.join(DATA_DIR, folder)
        if not os.path.isdir(directory):
            continue
        for path in _json_files(directory):
            relative = _relative(path)
            if relative in NOT_SHOWN:
                continue
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            for where, text in _json_strings(data):
                if len(text.split()) < 3 or (relative, _json_key(where)) in opened:
                    continue
                if where == ("name",) and folder in UNREAD_NAME_FOLDERS:
                    continue
                if any(isinstance(p, str) and (p in NOT_WORDS or p.endswith("_about")) for p in where):
                    continue
                if folder == "cells" and (len(where) > 2 and where[0] == "people" and where[2] in skipped_fields):
                    continue
                if folder == "asks" and len(where) > 2 and where[0] == "questions" and where[2] == "lines":
                    continue
                if text.startswith(("beaten:", "chest:")):
                    continue
                missing.append(f"{relative}: {'.'.join(str(p) for p in where)}: {text[:50]}")
    del villagers
    return missing
