"""The element system — single source of truth.

The world of Nuitai runs on six elements arranged in two interlocking
triangles, each with a clockwise "beats" relationship:

    Material triangle:  Fire -> Nature -> Water -> Fire
    Spiritual triangle: Light -> Shadow -> Spirit -> Light

If A beats B, an A-aligned attack hits B for ``ADVANTAGE_MULTIPLIER``
damage and a B-aligned attack hits A for ``DISADVANTAGE_MULTIPLIER``.
Same-element and cross-triangle pairings are neutral
(``NEUTRAL_MULTIPLIER``). Per-combatant resistances or immunities to
specific elements (e.g. "this shadow enemy is immune to shadow status
effects") will be authored case-by-case in content data, not imposed
as a global rule here.

Element math only fires for attacks that *carry* an element. Basic
attacks from party members are non-elemental and bypass the table
entirely (see ``docs/ARCHITECTURE.md`` for the rules). Enemy basic
attacks currently keep their element until the upcoming
physical/special split lands.

Every other module that needs element math imports from this file.
Do not duplicate the table.
"""

from __future__ import annotations

from enum import Enum

from core.shared import SHARED


class Element(Enum):
    """The six elements of Nuitai.

    The ids are the in-world words the lore uses (Afi, Lau, Wai, La,
    Ata, Mana) and never change. The player always reads the English
    name, ``label`` (Frankie, 10/23).
    """

    # In the official order (Frankie, 11/12).
    LAU = "lau"     # Nature / leaf. Material.
    AFI = "afi"     # Fire. Material.
    WAI = "wai"     # Water. Material.
    ATA = "ata"     # Shadow / decay. Spiritual.
    MANA = "mana"   # Spirit / breath. Spiritual.
    LA = "la"       # Light / sun. Spiritual.

    @property
    def label(self) -> str:
        """The name a player reads, "Fire" for ``AFI``."""
        return LABELS[self.value]


# What the player reads for each element id, in menus, messages and help
# lines (Frankie, 10/23). Running prose lowercases it: "8 physical fire damage."
LABELS: dict[str, str] = {
    "afi": "Fire", "lau": "Nature", "wai": "Water",
    "la": "Light", "ata": "Shadow", "mana": "Spirit",
}


def label(element: Element | str) -> str:
    """The English name for ``element`` or its id; "" for none."""
    if isinstance(element, Element):
        return element.label
    return LABELS.get(element or "", "")


# Damage multipliers. Living in this module means a designer tweaking
# combat feel changes one number, not five.
# The two multipliers and the table come from the shared battle file,
# so the browser game uses the same ones.
ADVANTAGE_MULTIPLIER = float(SHARED["elements"]["advantage"])
DISADVANTAGE_MULTIPLIER = float(SHARED["elements"]["disadvantage"])
NEUTRAL_MULTIPLIER = 1.0


# attacker -> defender it beats. Two closed triangles.
_BEATS: dict[Element, Element] = {
    Element(attacker): Element(defender)
    for attacker, defender in SHARED["elements"]["beats"].items()
}


def beats(attacker: Element, defender: Element) -> bool:
    """Return True if ``attacker``'s element strongly beats ``defender``'s.

    Args:
        attacker: The element of the incoming attack.
        defender: The element of the receiving combatant.

    Returns:
        True for an advantageous matchup, False otherwise (including
        neutral matchups across triangles).
    """
    return _BEATS.get(attacker) is defender


def damage_multiplier(attacker: Element, defender: Element) -> float:
    """Return the damage scalar for an ``attacker`` element vs a ``defender``.

    Args:
        attacker: The element of the incoming attack.
        defender: The element of the receiving combatant.

    Returns:
        ``ADVANTAGE_MULTIPLIER`` if attacker beats defender,
        ``DISADVANTAGE_MULTIPLIER`` if defender beats attacker, otherwise
        ``NEUTRAL_MULTIPLIER`` (including same-element pairings).
    """
    if beats(attacker, defender):
        return ADVANTAGE_MULTIPLIER
    if beats(defender, attacker):
        return DISADVANTAGE_MULTIPLIER
    return NEUTRAL_MULTIPLIER
