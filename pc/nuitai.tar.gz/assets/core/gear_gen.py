"""Generated weapons and relics (game/answers.md, the weapon effects line; Frankie, 11/6; built 11/17).

A weapon's name is its benefit's word and its type's word ("Strong Tool"); a unique name
replaces it for every weapon with that benefit and type, whatever the penalty (the Frying Pan).
A relic's name is its material and its type. This builds every one of them from
``game/shared/item-names.json`` and the fixed lists in ``battle.json``, so a monster can drop one and a
chest or shop can hold one: the bag keeps an id, and ``by_id("weapons")`` and ``by_id("relics")`` know
it like any other (``core/shared.py`` adds them at load, after the fixed ones).

Only a benefit and a penalty that are stats work yet (``weapon_benefit`` and ``weapon_penalty``), so
those are the only ones made. Every name is 12 characters or fewer, the space counted; a longer one
("Smart Boomerang") is left out, as the unique names are kept for them.
Nothing here imports ``settings`` (``core/shared.py`` runs first).
"""

from __future__ import annotations

import unicodedata
from typing import Any

MOST_CHARACTERS = 12  # The longest generated name, the space counted (Frankie, 11/6).
WEAPON_ABOUT = "Found along the way, not made to order."
RELIC_ABOUT = "Found along the way."


def _ascii(word: str) -> str:
    """A word as lower case letters only: "Tūhua" is "tuhua"."""
    plain = unicodedata.normalize("NFD", word).encode("ascii", "ignore").decode()
    return "".join(ch for ch in plain.lower() if ch.isalpha())


def weapons(fixed: list[dict[str, Any]], names: dict[str, Any]) -> list[dict[str, Any]]:
    """Every generated weapon: each type, each stat benefit, each different stat penalty.

    Args:
        fixed: The weapons already in the shared file; one with the same type, benefit and penalty
            stands in for the generated one, so it is not made twice.
        names: ``item-names.json``.
    """
    spec = names["weapons"]
    benefits = [b for b in spec["benefits"] if b["kind"] == "stat"]
    penalties = [p for p in spec["penalties"] if p["kind"] == "stat"]
    unique = {(u["type"], u["benefit"]): u["name"] for u in spec["unique"]}
    taken = {(w["type"], w.get("benefit"), w.get("penalty")) for w in fixed if w.get("benefit")}
    made = []
    for type_id, type_word in spec["types"].items():
        for benefit in benefits:
            name = unique.get((type_id, benefit["id"])) or f"{benefit['word']} {type_word}"
            if len(name) > MOST_CHARACTERS:
                continue
            for penalty in penalties:
                if penalty["id"] == benefit["id"] or (type_id, benefit["id"], penalty["id"]) in taken:
                    continue
                made.append({"id": f"gen_{type_id}_{benefit['id']}_{penalty['id']}", "name": name, "type": type_id,
                             "benefit": benefit["id"], "penalty": penalty["id"], "about": WEAPON_ABOUT,
                             "generated": True})
    return made


def relics(fixed: list[dict[str, Any]], names: dict[str, Any]) -> list[dict[str, Any]]:
    """Every generated relic: each material in each type, a unique name where there is one."""
    spec = names["relics"]
    unique = {(u["material"], u["type"]): u["name"] for u in spec["unique"]}
    taken = {(r["material"], r["type"]) for r in fixed}
    made = []
    for material in spec["materials"]:
        for part in spec["types"]:
            for type_word in part["types"]:
                if (material["name"], type_word) in taken:
                    continue
                name = unique.get((material["name"], type_word)) or f"{material['name']} {type_word}"
                if len(name) > MOST_CHARACTERS:
                    continue
                made.append({"id": f"gen_{_ascii(material['name'])}_{_ascii(type_word)}", "name": name,
                             "type": type_word, "material": material["name"], "element": material["element"],
                             "about": RELIC_ABOUT, "generated": True})
    return made
