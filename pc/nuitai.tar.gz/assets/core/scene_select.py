"""Scene select (Frankie, 10/25): any beat of the demo, without playing up to it.

Every beat is one entry in ``BEATS`` below. A beat is reached by playing the
demo up to it through the game's own code, the way a player would: the
story scenes are paged through, their fights won, Hina visited, Maika's
shop bought from, the Great Boar beaten, the tusk handed over. Nothing is
set by hand, so a beat follows the story wherever the story changes. The
acts are played in ``ACTS`` order; a beat names the last one it needs
(``after``), any it leaves out (``without``: the wake without Maika) and
where Kailo then stands (``stand``: room, col, row, facing),
or is left where the last scene put him.

A new beat is one entry: a name, an ``after`` and a ``stand``. A beat that
needs a step the story does not play yet is one new act in ``ACTS`` too.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from settings import AudioSettings, StewSettings, StorySettings
from ui import input_map

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import Party
    from core.scenes.overworld_scene import OverworldScene


# The demo's beats, in story order. ``new_game`` is the title's own New Game;
# ``after`` the last act played; ``stand`` where Kailo is put afterwards;
# ``without`` the acts left out; ``until_fight`` plays the wake to its fight, wins it
# and stops there. The wake plays differently without Maika (the plate, not Shaka and
# Lanu), so it and the kidnapping are here both ways (Frankie, 10/25).
BEATS: tuple[dict, ...] = (
    {"name": "The opening", "new_game": True},
    # Talking to her plays her scene.
    {"name": "Hina joins", "after": "taro_patch", "stand": ("hina_house", 10, 8, (0, -1))},
    {"name": "Free roaming by day", "after": "hina_joins"},
    # Maika found in his clearing in the Lost Woods: his talk, the six Aghoy, the fight won, "don't tell her" (Frankie, 11/15).
    {"name": "Maika's clearing", "after": "maika_deal", "stand": ("maika_clearing", 8, 3, (0, -1))},
    {"name": "Before the Great Boar", "after": "stocked", "stand": ("boar_meadow", 7, 12, (0, -1))},
    # Frankie's test of the boss fight (11/11): the same party and bag as the line above, Maika along,
    # Counter not yet learned, and the fight begun at once, as walking into the Great Boar and fighting does.
    {"name": "Great Boar fight", "after": "stocked", "stand": ("boar_meadow", 7, 12, (0, -1)),
     "boar_fight": True},
    {"name": "Night after the boar", "after": "great_boar"},
    # Talking to Melia hands over the tusk.
    {"name": "The tusk", "after": "great_boar", "stand": ("beach_west", 6, 6, (-1, 0))},
    # The tusk is hers: one step east, into the chief's room, and Hina asks about the wake (10/25).
    {"name": "The wake", "after": "tusk", "stand": ("beach_west", 15, 6, (1, 0))},
    {"name": "The wake, no Maika", "after": "tusk", "without": ("maika_deal", "maika_joins"),
     "stand": ("beach_west", 15, 6, (1, 0))},
    # The wake's fight won: what comes after it, the kidnapping.
    {"name": "The kidnapping", "after": "wake", "until_fight": True},
    {"name": "The kidnapping, no Maika", "after": "wake", "without": ("maika_deal", "maika_joins"), "until_fight": True},
    # After the demo (Frankie, 10/31), in the desktop game: Ama pulls Kailo out, as it starts;
    # then the morning after the chief's hut, Ama's boat job waiting at the harbor.
    {"name": "After the jump", "after": "wake", "after_demo": True},
    {"name": "The morning after", "after": "after_jump", "after_demo": True},
    # After the demo: the Meialana ready, Kailo on the pier facing her; A, then Sail (10/31).
    {"name": "Setting sail", "after": "boat_ready", "stand": ("harbor", 5, 10, (0, -1))},
    # The same party landed at Kupulau, on its pier below the Meialana (Frankie, 11/1).
    {"name": "Kupulau", "after": "boat_ready", "stand": ("kupulau_harbor", 5, 10, (0, -1))},
    # To explore the sea and check the map (Frankie, 11/2): already out of Kulāiwi, no food eaten, no monsters.
    {"name": "Free sailing", "after": "boat_ready", "stand": ("harbor", 5, 10, (0, -1)), "free_sailing": True},
    # A preview, not decided (Frankie, 11/8): the swirl into a fight, played at once on the beach with a boar.
    {"name": "Fight swirl (preview)", "after": "hina_joins", "stand": ("beach_west", 8, 6, (-1, 0)),
     "swirl_preview": True},
)

# Frames the field may run to finish one act before giving up (a scene that never ends).
_FRAME_LIMIT = 20000


def beats() -> list[dict]:
    """The beats this game has: the website's demo leaves out those after it (``StorySettings.DEMO_ONLY``)."""
    return [beat for beat in BEATS if not (beat.get("after_demo") and StorySettings.DEMO_ONLY)]


def beat_names() -> list[str]:
    """The beats' names, in story order, for the menu."""
    return [beat["name"] for beat in beats()]


def start(gm: "GameManager", index: int, party: "Party | None" = None) -> None:
    """Throw away the stack and begin the game at beat ``index`` of ``beats()``.

    ``party`` is a setup made on the Setup menu (Frankie, 11/18): the game starts with exactly it, in
    place of what the beat's own play would give. None starts the beat as it always did.
    """
    beat = beats()[index]
    if beat.get("new_game"):
        from core.scenes.title_scene import TitleScene  # local: cycle.

        TitleScene.new_game(gm)
        if party is not None:
            gm.party = party
        return
    # Quiet while it plays: every scene's sounds would come at once.
    muted, AudioSettings.MUTE = AudioSettings.MUTE, True
    try:
        scene = play_to(gm, beat)
        if party is None:
            prepare(gm, beat)
        else:
            gm.party = party   # already prepared: its defaults came from ``defaults``
    finally:
        AudioSettings.MUTE = muted
    stand = beat.get("stand")
    if stand is not None:
        put(scene, *stand)
    scene._room_sound()
    if beat.get("boar_fight"):
        _begin_boar_fight(gm, scene)
    if beat.get("swirl_preview"):
        from core.scenes.battle_scene import BattleScene, compose_fight  # local: cycle.
        from ui import fight_swirl

        battle = BattleScene(gm, enemies=compose_fight(gm.data.load("field_monsters")["boar"]),
                             in_town=False, can_escape=True)
        fight_swirl.arm(gm, battle)
        gm.scene_stack.push(battle)
    if beat.get("free_sailing"):
        scene._set_sail()


def prepare(gm: "GameManager", beat: dict) -> None:
    """What a beat sets on the party after its play, before the scene opens: Counter not yet learned
    for the boar fight, the free-sailing flags. It is part of the beat's defaults (Frankie, 11/18)."""
    if beat.get("boar_fight"):
        _prepare_boar_fight(gm)
    if beat.get("free_sailing"):
        # Set here and nowhere else; it rides in this game's flags, so a save made now is the
        # free-sailing game and a normal one never has it.
        from settings import SailingSettings  # local: as the rest of the field

        gm.party.flags[SailingSettings.FREE_FLAG] = True
        gm.party.flags[SailingSettings.LEAVE_FLAG] = True


def defaults(gm: "GameManager", index: int) -> "Party":
    """What the player would have at beat ``index``: a new party, exactly as ``start`` would leave it.

    The beat is played to its end through the game's own code on a stack of its own, so the title and the
    menu on the real stack, and the game's party, are left as they were (Frankie, 11/18).
    """
    from core.scenes.title_scene import build_default_party  # local: cycle.
    from systems.party import Party  # local: as above

    beat = beats()[index]
    if beat.get("new_game"):
        return build_default_party()
    real_stack, real_party, muted = gm.scene_stack._stack, gm.party, AudioSettings.MUTE
    gm.scene_stack._stack = []
    AudioSettings.MUTE = True
    try:
        play_to(gm, beat)
        prepare(gm, beat)
        return Party.from_dict(gm.party.to_dict())
    finally:
        gm.scene_stack._stack, gm.party, AudioSettings.MUTE = real_stack, real_party, muted


def play_to(gm: "GameManager", beat: dict) -> "OverworldScene":
    """A new game played up to ``beat``'s last act; the field it ends on, on the stack alone."""
    from core.scenes.overworld_scene import OverworldScene  # local: cycle.
    from core.scenes.title_scene import build_default_party  # local: cycle.

    gm.party = build_default_party()
    scene = OverworldScene(gm)
    gm.scene_stack.clear()
    gm.scene_stack.push(scene)
    names = [name for name, _ in ACTS]
    last = names.index(beat["after"])
    for name, act in ACTS[:last + 1]:
        if name in beat.get("without", ()):
            continue
        act(gm, scene, beat.get("until_fight", False) and name == beat["after"])
    return scene


def put(scene: "OverworldScene", room: str, col: int, row: int, facing: tuple[int, int]) -> None:
    """Stand Kailo in ``room`` at ``col``, ``row``, facing ``facing``."""
    from core.overworld_cells import WORLD_LAYOUT  # local: as the rest of the field

    scene.world.go_to(next(pos for pos, name in WORLD_LAYOUT.items() if name == room))
    scene.player.from_dict({"col": col, "row": row, "facing": list(facing)})


# ---------------------------------------------------------------------------
# PLAYING: the field run a frame at a time, its text paged through
# ---------------------------------------------------------------------------

def _confirm():
    import pygame

    return pygame.event.Event(pygame.KEYDOWN, key=input_map.confirm_key(), mod=0, unicode="")


def _down():
    import pygame

    return pygame.event.Event(pygame.KEYDOWN, key=pygame.K_DOWN, mod=0, unicode="")


def _win(gm: "GameManager", battle) -> None:
    """Every foe down and the fight won, then left, as its last line closing does."""
    for foe in battle.battle.enemies:
        foe.hp = 0
    battle.battle._outcome = "victory"
    battle._sync_party_state_back()
    gm.scene_stack.pop()


def _play(gm: "GameManager", scene: "OverworldScene", until_fight: bool = False,
          until_scene: str | None = None, answer: int = 0) -> None:
    """Run the field until the story is over and its text closed, winning its fights.

    Stops early when something else waits on top (a shop, a question), or,
    with ``until_fight``, just after a fight is won, or, with ``until_scene``,
    as that scene begins. A question gets its ``answer``th answer (the first by default).
    """
    from core.scenes.battle_scene import BattleScene  # local: cycle.
    from core.scenes.choice_scene import ChoiceScene  # local: cycle.

    for _ in range(_FRAME_LIMIT):
        top = gm.scene_stack.top
        if isinstance(top, BattleScene):
            _win(gm, top)
            if until_fight:
                return
            continue
        if isinstance(top, ChoiceScene):
            for _ in range(answer):
                top.handle_event(_down())
            top.handle_event(_confirm())
            continue
        if top is not scene:
            return
        if until_scene is not None and scene.story is not None and scene.story.name == until_scene:
            return
        if scene.text_box.is_done() and scene.story is None and scene.stage is None and scene._after_text is None:
            return
        scene.text_box.update(10.0)
        scene.text_box.advance()
        scene.update(1 / 60)
    raise RuntimeError("scene select: the story did not finish")


def _talk(gm: "GameManager", scene: "OverworldScene", room: str, speaker: str) -> None:
    """Walk up to whoever in ``room`` is ``speaker`` (from below) and talk to them."""
    put(scene, room, 0, 0, (0, -1))
    person = next(p for p in scene.world.people if p.get("speaker", p.get("sheet")) == speaker)
    put(scene, room, person["col"], person["row"] + 1, (0, -1))
    scene.handle_event(_confirm())


# ---------------------------------------------------------------------------
# THE ACTS, in story order
# ---------------------------------------------------------------------------

def _taro_patch(gm, scene, until_fight=False) -> None:
    """The opening scene to its end: Hina goes home."""
    scene.begin_story("taro_patch")
    _play(gm, scene)


def _hina_joins(gm, scene, until_fight=False) -> None:
    """Her house: talking to her plays her scene, and she joins."""
    put(scene, "hina_house", 10, 8, (0, -1))
    scene.handle_event(_confirm())
    _play(gm, scene)
    _give(gm, PANTRY)   # the stall's basics, for Kailo's pot


def _find_maika(gm, scene) -> None:
    """Kailo walks up to Maika in his clearing and talks to him; the scene plays to its end (Frankie, 11/15)."""
    put(scene, "maika_clearing", 8, 3, (0, -1))   # below him, facing up
    scene.handle_event(_confirm())
    _play(gm, scene)


def _maika_deal(gm, scene, until_fight=False) -> None:
    """His sister's deal in the lodge: Maika is gone from his stall, digging in the Lost Woods."""
    _talk(gm, scene, "hunters_lodge", "Miki")
    _play(gm, scene)


def _maika_joins(gm, scene, until_fight=False) -> None:
    """Finding him in the clearing, his shop, the lie to her, and he joins.

    Buying from him no longer makes him join (Frankie, 10/30); the second answer to
    his sister's question is the lie, which is the way to him.
    """
    from core.scenes.shop_scene import ShopScene  # local: cycle.

    # He is gone from his stall once the deal is made: found in the clearing, the Aghoy fight won (Frankie, 11/12).
    _find_maika(gm, scene)
    _talk(gm, scene, "maikas_glade", "Maika")
    _play(gm, scene)
    if not isinstance(gm.scene_stack.top, ShopScene):
        raise RuntimeError("scene select: Maika's shop did not open")
    gm.scene_stack.pop()
    _play(gm, scene)
    _talk(gm, scene, "hunters_lodge", "Miki")
    _play(gm, scene, answer=1)   # her question: the lie is the second answer (the truth is the first, Frankie, 11/11)
    _talk(gm, scene, "maikas_glade", "Maika")
    _play(gm, scene)


# What the party would have bought and learned by the lodge visit (Frankie, 11/1: a scene starts
# with what the player would own after playing to it). Claude's picks from the lodge's shelf and
# the pantry: Hina's bow, Maika's spear, Kailo's wraps, the two lontars read, a day's cooking.
PANTRY = {"taro": 3, "water": 2, "wheat": 2, "egg": 2}
LODGE_BAG = {"hamaya": 1, "kapa_wraps": 1, "ihe": 1, "salt": 2, "mackerel": 2}
LODGE_LEARNED = ("kailo_learned_counter_guard", "maika_learned_drain")


def _give(gm: "GameManager", items: dict[str, int]) -> None:
    for item, count in items.items():
        gm.party.inventory[item] = gm.party.inventory.get(item, 0) + count


def _stocked(gm, scene, until_fight=False) -> None:
    """The lodge's shelf: bow, spear and wraps in the bag, the two lontars read, some salt and fish."""
    bag = dict(LODGE_BAG)
    if gm.party.find("maika") is None:
        del bag["ihe"]   # the spear is for Maika; without him nobody bought it
    _give(gm, bag)
    for flag in LODGE_LEARNED:
        if flag.split("_")[0] == "kailo" or gm.party.find("maika") is not None:
            gm.party.flags[flag] = True
    if gm.party.find("maika") is not None:
        # Maika is past the boardwalk: this player fought the toll Nuno and won his slot (Frankie, 11/12).
        gm.party.flags["beaten:Nuno sa Tulay"] = True


def _great_boar(gm, scene, until_fight=False) -> None:
    """His room, his fight won, and the scene after: it is night, the tusk in the bag."""
    # The stew gates the night (Frankie, 10/30): this scene starts with it made.
    gm.party.flags[StewSettings.MADE_FLAG] = True
    put(scene, StorySettings.SEED_ROOM, 7, 12, (0, -1))
    scene._place_monsters()
    boss = next(m for m in scene.monsters if m.spot.get("boss"))
    scene._start_fight(boss)
    _play(gm, scene)


def _prepare_boar_fight(gm: "GameManager") -> None:
    """Counter is Kailo's to learn at the fight's start (the lodge's lontar gave it in ``_stocked``)."""
    from settings import StorySettings as S  # as above

    gm.party.flags.pop(S.COUNTER_FLAG, None)
    kailo = gm.party.find(S.COUNTER_LEARNER)
    if kailo is not None and kailo.loadout:
        kailo.loadout = {move: row for move, row in kailo.loadout.items() if move != S.COUNTER_MOVE}
    if kailo is not None:
        # A fresh party has an open slot left, so Counter would slot itself and Hina's slotting lesson
        # would never play. Fill it with Flambé, so Counter has no room and the lesson always fires.
        # Scene select only: a real playthrough never comes through here (Frankie, 11/12).
        from core.factories import first_loadout  # as above
        from core.shared import by_id
        from systems.loadout import learn, open_slots

        gm.party.flags["kailo_learned_flambe"] = True
        kailo.loadout = learn(kailo.loadout, by_id("moves")["flambe"], first_loadout(kailo.id, gm.party.flags),
                              open_slots(gm.party.flags))


def _begin_boar_fight(gm: "GameManager", scene: "OverworldScene") -> None:
    """The Great Boar fight at once, as walking into the Great Boar and fighting does."""
    scene._place_monsters()
    scene._start_fight(next(m for m in scene.monsters if m.spot.get("boss")))


def _tusk(gm, scene, until_fight=False) -> None:
    """Melia at night: Kailo gives her the tusk."""
    put(scene, "beach_west", 6, 6, (-1, 0))  # beside Melia at night (she stands at col 5)
    scene.handle_event(_confirm())
    _play(gm, scene)


def _wake(gm, scene, until_fight=False) -> None:
    """YES to Hina: the wake, to its end or, ``until_fight``, to its fight won."""
    put(scene, StorySettings.ASK_ROOM, 8, 7, (0, 1))
    scene.begin_story(StorySettings.WAKE_SCENE)
    _play(gm, scene, until_fight, until_scene=StorySettings.AFTER_JUMP_SCENE)


def _after_jump(gm, scene, until_fight=False) -> None:
    """After the demo: the rescue and the chief's hut, played on from the wake, to the next morning."""
    _play(gm, scene)


def _boat_ready(gm, scene, until_fight=False) -> None:
    """The Meialana fixed and stocked, ready to sail (Frankie, 10/31). The boat quest
    and the goodbyes are not built, so this sets what they will: the boat ready, Ama's
    map, and a few days of food as the village's goodies for the road (Claude's pick)."""
    from settings import MapSettings, SailingSettings  # local, as above

    scene._card, scene._dark = None, 0.0   # past the demo's last card and its black screen
    gm.party.flags[SailingSettings.READY_FLAG] = True
    gm.party.flags[MapSettings.HAS_MAP_FLAG] = True
    gm.party.inventory[MapSettings.ITEM] = 1
    for item, count in SailingSettings.TEST_PROVISIONS.items():
        gm.party.inventory[item] = gm.party.inventory.get(item, 0) + count


ACTS: tuple[tuple[str, Callable], ...] = (
    ("taro_patch", _taro_patch),
    ("hina_joins", _hina_joins),
    ("maika_deal", _maika_deal),
    ("maika_joins", _maika_joins),
    ("stocked", _stocked),
    ("great_boar", _great_boar),
    ("tusk", _tusk),
    ("wake", _wake),
    ("after_jump", _after_jump),
    ("boat_ready", _boat_ready),
)
