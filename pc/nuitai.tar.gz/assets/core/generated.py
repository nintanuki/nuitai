"""Generated places: rooms made fresh from a seed, different every game (D-731).

The map has two kinds of room. Named places (the town, the boss's field)
are painted in the Workshop and kept in ``data/cells/``; they never
change. A generated place is a stretch of the map described in
``data/generated/<id>.json`` and built when a game starts, so every
playthrough walks a different one. The objective, the boss and the kinds
of monster stay the same, because those are set in the description and
in the named rooms around it; only the layout moves.

A description gives:

* ``entered_from``: the named rooms the party walks in from; the
  rooms beside them are the shallow end.
* ``area``: the world-grid slots the place may use, ``x`` and ``y`` as
  ``[low, high]``. The game skips any painted room in the area: the
  place takes it over, and the room's file stays for the Workshop.
* ``leave``: slots in the area the place leaves alone, as ``[x, y]``,
  so a painted room there stays and the place grows around it (the
  clearing north of the harbor, Frankie 11/4); left out, none.
* ``skip``: slots in the area with no room at all, sea off the map (Frankie, 11/12); left out, none.
* ``rooms``: ``[fewest, most]`` rooms to build.
* ``loops``: how many extra doorways to add after the paths are made, so
  the place is not only one branching path.
* ``trees``: ``clumps`` of palms per room as ``[fewest, most]``, and
  ``deeper``, how many more a room at the far end gets.
* ``shrub_chance``: the odds a room has a wild pineapple shrub (Frankie, 11/12), stood on open
  ground where it shuts nothing off.
* ``spring_chance`` and ``pond_chance``: the odds a room has a healing
  pond, or a small pool of water.
* ``pack``: more slots in every monster's fight, so its own kind comes in bigger
  groups (Kupulau, Frankie 11/1); left out, none.
* ``set_piece``: a hand-made room stamped into one slot of the place (Frankie, 11/12: Maika's clearing),
  as ``{"piece": name, "min_depth": 0..1}``. The room's file is ``data/generated/pieces/<name>.json``, a
  grid with a doorway on every side. Its slot is picked from the seed among those no painted room opens
  into and at least ``min_depth`` in from the ways in; every doorway that joins a neighbor is made to
  match the piece's, and every one facing nothing becomes trees. If a slot leaves the place with a room
  that cannot be walked to from some way in, the next slot is tried (``build``).
* ``chests``: Lost Woods chests (Frankie, 11/15), as ``{"count": [fewest, most], "min_depth": 0..1,
  "tiers": [4, 5]}``: that many chests, each in a different room at least ``min_depth`` in (the Maika
  piece's room never), on open ground where it shuts nothing off and no monster stands. A chest's tier is
  the first of ``tiers`` in the nearer half of that stretch, the second in the far half. They are
  placed from their own seed, so they never move the rest of the place.
* ``monsters_per_room`` as ``[fewest, most]``, and ``monsters``: bands of
  ``depth`` (0 at the way in, 1 at the far end) each with the ``kinds``
  from ``data/field_monsters/`` that walk there, by weight.

How a place is built, in plain steps:

1. Which slots are rooms. A random tree is grown over every free slot,
   then rooms are pruned off its ends until the count is right. A slot
   that a named room has a doorway into is never pruned, so every door
   from a named room leads somewhere.
2. Doorways. Two rooms joined in the tree get a two-tile gap in the
   palms between them, at the same spot on both sides. A side facing a
   named room copies that room's gaps.
3. Inside a room. Clumps of palms, maybe a pond or a spring, then a sand
   trail dug from every doorway to the middle so nothing is ever shut
   off, then any grass the trail cannot reach is filled with palms.
4. Monsters, on open grass away from the doorways, harder the further
   in the room is, and every kind the description lists at least once.

The same seed always builds the same place. The seed is kept in the save,
so a loaded game walks the woods it left.
"""

from __future__ import annotations

import json
import os
import random

from core import overworld_cells as cells
from settings import BackgroundSettings, OverworldSettings, ToolSettings

GENERATED_DIR = os.path.join(cells.ROOT, "data", "generated")

WALL = OverworldSettings.WALL_CHAR
FLOOR = OverworldSettings.FLOOR_CHAR
SAND = OverworldSettings.PATH_CHAR   # the trails are path dirt, inland, never beach (Frankie, 11/24)
WATER = OverworldSettings.FRESH_CHAR  # a wood's pond is fresh (Frankie, 11/16)
SPRING = OverworldSettings.SPRING_CHAR
WALKABLE = (FLOOR, SAND, OverworldSettings.SAND_CHAR)   # the hand-made rooms' beach doorways count too
COLS, ROWS = OverworldSettings.COLS, OverworldSettings.ROWS

# (dx, dy) to the room next door, and the name of that side.
SIDES: dict[str, tuple[int, int]] = {"north": (0, -1), "south": (0, 1), "west": (-1, 0), "east": (1, 0)}
OPPOSITE = {"north": "south", "south": "north", "west": "east", "east": "west"}

# The rooms the last ``install`` put in, so the next one can take them out.
INSTALLED: set[str] = set()


def load_places(directory: str = GENERATED_DIR) -> list[dict]:
    """Every place description in ``directory``, in file order."""
    places = []
    if os.path.isdir(directory):
        for file_name in sorted(os.listdir(directory)):
            if file_name.endswith(".json"):
                with open(os.path.join(directory, file_name), "r", encoding="utf-8") as f:
                    places.append(json.load(f))
    return places


PIECES_DIR = os.path.join(GENERATED_DIR, "pieces")


def load_piece(name: str, directory: str = PIECES_DIR) -> dict:
    """A set piece: ``id``, ``grid`` (rows of characters as lists), ``people``, ``monsters``, ``buildings``."""
    with open(os.path.join(directory, f"{name}.json"), "r", encoding="utf-8") as f:
        piece = json.load(f)
    piece["grid"] = [list(row) for row in piece["grid"]]
    return piece


# ----------------------------------------------------------------------
# EDGES
# ----------------------------------------------------------------------

def edge_tiles(side: str) -> list[tuple[int, int]]:
    """The (col, row) tiles along one side of a room, in order."""
    if side == "north":
        return [(c, 0) for c in range(COLS)]
    if side == "south":
        return [(c, ROWS - 1) for c in range(COLS)]
    if side == "west":
        return [(0, r) for r in range(ROWS)]
    return [(COLS - 1, r) for r in range(ROWS)]


def open_spots(grid: list[list[str]], side: str) -> list[int]:
    """Which places along a side are walkable, counted along that side."""
    return [i for i, (c, r) in enumerate(edge_tiles(side)) if grid[r][c] in WALKABLE]


def _inside(col: int, row: int, side: str) -> tuple[int, int]:
    """The tile one step into the room from an edge tile."""
    dx, dy = SIDES[side]
    return col - dx, row - dy


# ----------------------------------------------------------------------
# WHICH SLOTS ARE ROOMS
# ----------------------------------------------------------------------

def area_slots(place: dict) -> set[tuple[int, int]]:
    """Every world-grid slot in the place's area, but the ones it leaves alone."""
    (x0, x1), (y0, y1) = place["area"]["x"], place["area"]["y"]
    leave = {tuple(slot) for slot in place.get("leave", [])} | {tuple(slot) for slot in place.get("skip", [])}
    return {(x, y) for x in range(x0, x1 + 1) for y in range(y0, y1 + 1)} - leave


def _grow(free: set, required: set, rng: random.Random, target: int):
    """One random tree over ``free``, pruned toward ``target`` rooms; returns (slots, joins)."""
    start = min(required) if required else min(free)
    tree: set[frozenset] = set()
    seen = {start}
    frontier = [start]
    while frontier:
        slot = frontier[rng.randrange(len(frontier))]
        options = [
            (slot[0] + dx, slot[1] + dy) for dx, dy in SIDES.values()
            if (slot[0] + dx, slot[1] + dy) in free and (slot[0] + dx, slot[1] + dy) not in seen
        ]
        if not options:
            frontier.remove(slot)
            continue
        nxt = rng.choice(options)
        tree.add(frozenset((slot, nxt)))
        seen.add(nxt)
        frontier.append(nxt)
    slots = set(seen)
    while len(slots) > target:
        ends = [s for s in slots if s not in required
                and sum(1 for j in tree if s in j) <= 1]
        if not ends:
            break
        cut = rng.choice(sorted(ends))
        slots.discard(cut)
        tree = {j for j in tree if cut not in j}
    return slots, tree


def _plan(place: dict, rng: random.Random, layout: dict, grids: dict):
    """Pick the slots and the doorways between them.

    Returns ``(slots, joins, fixed_doors)``: the chosen slots, the pairs
    of slots joined by a doorway, and for each slot the sides that face a
    named room with a doorway, mapped to that room's open spots.
    """
    free = area_slots(place)

    fixed_doors: dict[tuple[int, int], dict[str, list[int]]] = {}
    for slot in free:
        for side, (dx, dy) in SIDES.items():
            neighbor = layout.get((slot[0] + dx, slot[1] + dy))
            if neighbor is None:
                continue
            # A gap with a sign or a chest standing in it is no doorway (the docks' ends).
            shut = cells.blocking_tiles(neighbor)
            spots = [i for i in open_spots(grids[neighbor], OPPOSITE[side])
                     if edge_tiles(OPPOSITE[side])[i] not in shut]
            if spots:
                fixed_doors.setdefault(slot, {})[side] = spots
    required = set(fixed_doors)

    # A random tree over the free slots, grown from one required slot,
    # then ends that no named room needs pruned until the count is right.
    # A tree whose needed part alone is too big is grown again.
    target = rng.randint(*place["rooms"])
    for _ in range(20):
        slots, tree = _grow(free, required, rng, target)
        if len(slots) <= target:
            break
    # A few extra doorways between rooms side by side.
    extra = [
        frozenset((a, (a[0] + dx, a[1] + dy)))
        for a in sorted(slots) for dx, dy in ((1, 0), (0, 1))
        if (a[0] + dx, a[1] + dy) in slots and frozenset((a, (a[0] + dx, a[1] + dy))) not in tree
    ]
    rng.shuffle(extra)
    joins = tree | set(extra[: place.get("loops", 0)])
    return slots, joins, fixed_doors


def _depths(slots: set, joins: set, starts: set) -> dict[tuple[int, int], float]:
    """How far in each room is, 0 at the doors from named rooms and 1 at the far end."""
    distance = {s: 0 for s in starts if s in slots}
    queue = list(distance)
    while queue:
        slot = queue.pop(0)
        for join in joins:
            if slot in join:
                (other,) = join - {slot}
                if other not in distance:
                    distance[other] = distance[slot] + 1
                    queue.append(other)
    far = max(distance.values(), default=0) or 1
    return {s: distance.get(s, 0) / far for s in slots}


# ----------------------------------------------------------------------
# ONE ROOM
# ----------------------------------------------------------------------

def _room(place: dict, rng: random.Random, doors: dict[str, list[int]], depth: float) -> list[list[str]]:
    """Build one room's grid with doorways at ``doors`` (side to open spots)."""
    grid = [[WALL] * COLS for _ in range(ROWS)]
    for r in range(1, ROWS - 1):
        for c in range(1, COLS - 1):
            grid[r][c] = FLOOR

    # Palms in clumps, more of them deeper in.
    low, high = place["trees"]["clumps"]
    clumps = rng.randint(low, high) + round(place["trees"].get("deeper", 0) * depth)
    for _ in range(clumps):
        cc, cr = rng.randint(2, COLS - 3), rng.randint(2, ROWS - 3)
        radius = rng.choice((0, 1, 1, 2))
        for r in range(cr - radius, cr + radius + 1):
            for c in range(cc - radius, cc + radius + 1):
                if 1 <= r < ROWS - 1 and 1 <= c < COLS - 1 and rng.random() < 0.75:
                    grid[r][c] = WALL

    # Maybe a small pool, maybe a healing spring.
    if rng.random() < place.get("pond_chance", 0):
        pc, pr = rng.randint(3, COLS - 5), rng.randint(3, ROWS - 5)
        for r in (pr, pr + 1):
            for c in (pc, pc + 1):
                grid[r][c] = WATER
    if rng.random() < place.get("spring_chance", 0):
        grid[rng.randint(3, ROWS - 4)][rng.randint(3, COLS - 4)] = SPRING

    # Doorways, and a sand trail from each one to the middle.
    hub = (rng.randint(6, 9), rng.randint(5, 8))
    starts = []
    for side, spots in doors.items():
        tiles = edge_tiles(side)
        for i in spots:
            c, r = tiles[i]
            grid[r][c] = SAND
            starts.append(_inside(c, r, side))
    for c, r in starts:
        while (c, r) != hub:
            grid[r][c] = SAND
            dc, dr = hub[0] - c, hub[1] - r
            if rng.random() < 0.3:
                # Wander a step sideways, so the trail is not a ruler line.
                if dc and rng.random() < 0.5:
                    dr = rng.choice((-1, 1))
                    dc = 0
                elif dr:
                    dc = rng.choice((-1, 1))
                    dr = 0
            if dc and (not dr or rng.random() < 0.5):
                c += 1 if dc > 0 else -1
            elif dr:
                r += 1 if dr > 0 else -1
            c = min(max(c, 1), COLS - 2)
            r = min(max(r, 1), ROWS - 2)
        grid[r][c] = SAND

    # Grass the trail cannot reach becomes palms. A spring beside the
    # reachable ground stays; one shut in by palms is useless, so it goes.
    reach = _reachable(grid, hub)
    for r in range(ROWS):
        for c in range(COLS):
            if grid[r][c] in WALKABLE and (c, r) not in reach:
                grid[r][c] = WALL
            if grid[r][c] == SPRING and not any(
                (c + dx, r + dy) in reach for dx, dy in SIDES.values()
            ):
                grid[r][c] = WALL
    return grid


def _shrubs(grid: list[list[str]], rng: random.Random, chance: float, taken: set) -> list[dict]:
    """Maybe one wild pineapple shrub (Frankie, 11/12), on open grass where it shuts nothing off.

    Tried on a few random grass tiles away from the edge; the first one whose loss leaves every
    other open tile reachable takes it, so the woods always lead back out.
    """
    if rng.random() >= chance:
        return []
    tiles = [(c, r) for r in range(2, ROWS - 2) for c in range(2, COLS - 2) if grid[r][c] == FLOOR]
    rng.shuffle(tiles)
    for c, r in tiles[:12]:
        if (c, r) not in taken and _still_joined(grid, (c, r), taken):
            return [{"col": c, "row": r, "kind": "shrub"}]
    return []


# Every healing spring has Lanu's post beside it, so the post says a spring is near; the Lanu sage
# tells it, not the post (Frankie, 11/4).
SPRING_POST_LOOK = [["Kailo", "Another cup left out for Lanu."]]


def _spring_posts(grid: list[list[str]]) -> list[dict]:
    """Stand Lanu's post beside each spring in ``grid``, without shutting anything off.

    A palm next to the spring is cleared for it first; failing that, an open tile
    whose loss leaves every other open tile reachable. No dice, so the woods a
    save remembers come out the same.
    """
    posts = []
    taken: set[tuple[int, int]] = set()
    springs = [(c, r) for r in range(ROWS) for c in range(COLS) if grid[r][c] == SPRING]
    around = [(dx, dy) for dy in (-1, 0, 1) for dx in (-1, 0, 1) if (dx, dy) != (0, 0)]
    for c, r in springs:
        spots = [(c + dx, r + dy) for dx, dy in around
                 if 1 <= c + dx < COLS - 1 and 1 <= r + dy < ROWS - 1 and (c + dx, r + dy) not in taken]
        spot = next(((x, y) for x, y in spots if grid[y][x] == WALL), None)
        if spot is not None:
            grid[spot[1]][spot[0]] = FLOOR
        else:
            spot = next(((x, y) for x, y in spots if grid[y][x] in WALKABLE
                         and _still_joined(grid, (x, y), taken)), None)
        if spot is None:
            continue
        taken.add(spot)
        posts.append({"col": spot[0], "row": spot[1], "kind": "lanu_post", "look": SPRING_POST_LOOK})
    return posts


def _still_joined(grid: list[list[str]], blocked: tuple[int, int], taken: set[tuple[int, int]]) -> bool:
    """Whether every open tile and spring can still be reached with ``blocked`` (and ``taken``) shut."""
    shut = taken | {blocked}
    open_tiles = {(c, r) for r in range(ROWS) for c in range(COLS)
                  if grid[r][c] in WALKABLE and (c, r) not in shut}
    if not open_tiles:
        return False
    start = min(open_tiles)
    seen, queue = {start}, [start]
    while queue:
        c, r = queue.pop()
        for dx, dy in SIDES.values():
            n = (c + dx, r + dy)
            if n in open_tiles and n not in seen:
                seen.add(n)
                queue.append(n)
    springs_ok = all(any((c + dx, r + dy) in seen for dx, dy in SIDES.values())
                     for r in range(ROWS) for c in range(COLS) if grid[r][c] == SPRING)
    return seen == open_tiles and springs_ok


def _reachable(grid: list[list[str]], start: tuple[int, int]) -> set[tuple[int, int]]:
    """Every walkable tile a party can walk to from ``start``."""
    seen = {start}
    queue = [start]
    while queue:
        c, r = queue.pop()
        for dx, dy in SIDES.values():
            n = (c + dx, r + dy)
            if 0 <= n[0] < COLS and 0 <= n[1] < ROWS and n not in seen and grid[n[1]][n[0]] in WALKABLE:
                seen.add(n)
                queue.append(n)
    return seen


def _monsters(place: dict, rng: random.Random, grid: list[list[str]],
              doors: dict[str, list[int]], depth: float) -> list[dict]:
    """Stand this room's monsters on open grass, away from the doorways."""
    band = _band(place, depth)
    kinds, weights = zip(*sorted(band["kinds"].items()))
    near_door = set()
    for side, spots in doors.items():
        for i in spots:
            c, r = edge_tiles(side)[i]
            near_door |= {(c + dx, r + dy) for dx in range(-3, 4) for dy in range(-3, 4)}
    open_tiles = [
        (c, r) for r in range(2, ROWS - 2) for c in range(2, COLS - 2)
        if grid[r][c] == FLOOR and (c, r) not in near_door
    ]
    rng.shuffle(open_tiles)
    spots: list[dict] = []
    count = rng.randint(*place["monsters_per_room"])
    for c, r in open_tiles:
        if len(spots) >= count:
            break
        if any(abs(c - s["col"]) < 3 and abs(r - s["row"]) < 3 for s in spots):
            continue
        spots.append({"col": c, "row": r, "kind": rng.choices(kinds, weights)[0]})
        if place.get("pack"):
            spots[-1]["pack"] = place["pack"]
    return spots


# ----------------------------------------------------------------------
# A WHOLE PLACE
# ----------------------------------------------------------------------

def piece_order(place: dict, seed: int, slots: set, fixed_doors: dict, depth: dict) -> list[tuple[int, int]]:
    """The slots the place's set piece may take, in the order they are tried (the seed's pick first).

    Never a slot a painted room opens into, since its doorways are the painted room's. Slots at least
    ``min_depth`` in come first; the shallower ones only follow.
    """
    spec = place["set_piece"]
    able = sorted(s for s in slots if s not in fixed_doors)
    deep = [s for s in able if depth[s] >= spec.get("min_depth", 0.0)]
    random.Random(f"{place['id']}:{seed}:piece").shuffle(deep)
    return deep + [s for s in able if s not in deep]


def _stamp(piece: dict, slot: tuple[int, int], joins: set, doors: dict) -> list[list[str]]:
    """The piece's grid for ``slot``: its doorways kept where a join leaves it (both rooms are told),
    trees where it faces nothing."""
    grid = [row[:] for row in piece["grid"]]
    for side, (dx, dy) in SIDES.items():
        other = (slot[0] + dx, slot[1] + dy)
        spots = open_spots(piece["grid"], side)
        if frozenset((slot, other)) in joins:
            doors[slot][side] = spots
            doors[other][OPPOSITE[side]] = spots
        else:
            doors[slot].pop(side, None)
            for i in spots:
                col, row = edge_tiles(side)[i]
                grid[row][col] = WALL
    return grid


def generate(place: dict, seed: int, layout: dict | None = None,
             grids: dict | None = None, piece_try: int = 0) -> list[dict]:
    """Build every room of ``place`` from ``seed``, around the named rooms.

    ``layout`` and ``grids`` are the named rooms (position to name, name
    to grid); they default to the rooms loaded from ``data/cells/``.
    Returns room entries shaped like a room file's (``id``, ``pos``,
    ``grid``, ``people``, ``monsters``).
    """
    layout = cells.WORLD_LAYOUT if layout is None else layout
    grids = cells.CELLS if grids is None else grids
    area = area_slots(place)
    layout = {pos: name for pos, name in layout.items() if pos not in area}
    rng = random.Random(f"{place['id']}:{seed}")
    slots, joins, fixed_doors = _plan(place, rng, layout, grids)
    entrances = {
        slot for slot in slots for side, (dx, dy) in SIDES.items()
        if side in fixed_doors.get(slot, {})
        and layout.get((slot[0] + dx, slot[1] + dy)) in place.get("entered_from", [])
    }
    depth = _depths(slots, joins, entrances or set(fixed_doors))

    # One doorway spot per join, shared by both rooms.
    doors: dict[tuple[int, int], dict[str, list[int]]] = {s: dict(fixed_doors.get(s, {})) for s in slots}
    for join in sorted(joins, key=sorted):
        a, b = sorted(join)
        side = "east" if b[0] > a[0] else "south"
        length = COLS if side == "south" else ROWS
        at = rng.randint(2, length - 4)
        doors[a][side] = [at, at + 1]
        doors[b][OPPOSITE[side]] = [at, at + 1]

    # The set piece (Maika's clearing) takes one slot; the seed picks it, ``piece_try`` moves on to the next.
    piece, piece_at, piece_grid = None, None, None
    if place.get("set_piece"):
        order = piece_order(place, seed, slots, fixed_doors, depth)
        if order:
            piece = load_piece(place["set_piece"]["piece"])
            piece_at = order[piece_try % len(order)]
            piece_grid = _stamp(piece, piece_at, joins, doors)

    rooms = []
    for index, slot in enumerate(sorted(slots, key=lambda s: (-s[1], s[0])), start=1):
        if slot == piece_at:
            rooms.append({
                "id": piece["id"], "pos": slot, "grid": piece_grid,
                "people": [dict(p) for p in piece.get("people", [])],
                "monsters": [dict(m) for m in piece.get("monsters", [])],
                "buildings": [dict(b) for b in piece.get("buildings", [])],
                "depth": depth[slot],
            })
            continue
        grid = _room(place, rng, doors[slot], depth[slot])
        posts = _spring_posts(grid)
        taken = {(post["col"], post["row"]) for post in posts}
        for shrub in _shrubs(grid, rng, place.get("shrub_chance", 0), taken):
            if (shrub["col"], shrub["row"]) not in taken:
                posts.append(shrub)
        # The monsters stand anywhere but on a post.
        ground = [row[:] for row in grid]
        for post in posts:
            ground[post["row"]][post["col"]] = WALL
        rooms.append({
            "id": f"{place['id']}_{index}",
            "pos": slot,
            "grid": grid,
            "people": [],
            "monsters": _monsters(place, rng, ground, doors[slot], depth[slot]),
            "buildings": posts,
            "depth": depth[slot],
        })
    _every_kind(place, rooms)
    _chests(place, seed, rooms, piece_at)
    for room in rooms:
        del room["depth"]
    return rooms


def _chests(place: dict, seed: int, rooms: list[dict], piece_at: tuple[int, int] | None) -> None:
    """Put the place's ``chests`` in rooms far enough in (see the module's description)."""
    spec = place.get("chests")
    if not spec:
        return
    rng = random.Random(f"{place['id']}:chests:{seed}")
    low, high = spec["tiers"][0], spec["tiers"][-1]
    wanted = rng.randint(*spec["count"])
    order = [r for r in rooms if r["pos"] != piece_at]
    rng.shuffle(order)
    order.sort(key=lambda r: r["depth"] < spec.get("min_depth", 0))   # the deep enough first
    placed = 0
    for room in order:
        if placed >= wanted:
            break
        grid = room["grid"]
        taken = {(b["col"], b["row"]) for b in room["buildings"]} | {(m["col"], m["row"]) for m in room["monsters"]}
        tiles = [(c, r) for r in range(2, ROWS - 2) for c in range(2, COLS - 2) if grid[r][c] == FLOOR and (c, r) not in taken
                 and not any(abs(c - t[0]) + abs(r - t[1]) <= 1 for t in taken)]
        rng.shuffle(tiles)
        for c, r in tiles[:20]:
            if _still_joined(grid, (c, r), taken):
                far = room["depth"] >= (spec.get("min_depth", 0) + 1) / 2
                room["buildings"].append({"col": c, "row": r, "kind": "chest", "tier": high if far else low})
                placed += 1
                break


def _band(place: dict, depth: float) -> dict:
    """The monster band a room this far in draws from."""
    return next((b for b in place["monsters"] if b["depth"][0] <= depth <= b["depth"][1]),
                place["monsters"][-1])


def _every_kind(place: dict, rooms: list[dict]) -> None:
    """Make sure every kind the place lists walks somewhere in it.

    The lodge's bounties are posted one after another and only move on when
    one is done, so a kind the dice left out (a woods with no kapre)
    would stop them for good. A missing kind takes the place of a monster
    in the deepest room whose band has it, one of a kind there is more
    than one of. No dice, so the same seed still builds the same woods.
    """
    kinds = sorted({k for band in place["monsters"] for k in band["kinds"]})
    for kind in kinds:
        counts: dict[str, int] = {}
        for room in rooms:
            for m in room["monsters"]:
                counts[m["kind"]] = counts.get(m["kind"], 0) + 1
        if counts.get(kind):
            continue
        for room in sorted(rooms, key=lambda r: (-r["depth"], r["id"])):
            if kind not in _band(place, room["depth"])["kinds"]:
                continue
            spare = next((m for m in room["monsters"] if counts[m["kind"]] > 1), None)
            if spare is not None:
                spare["kind"] = kind
                break


def reachable_rooms(layout: dict, grids: dict, start: tuple[int, int]) -> set[str]:
    """Every room the party can reach on foot from the middle of ``start``'s room."""
    seen = set()
    queue = [(start, (COLS // 2, ROWS // 2))]
    while queue:
        pos, (c, r) = queue.pop()
        if (pos, c, r) in seen:
            continue
        seen.add((pos, c, r))
        for dx, dy in SIDES.values():
            nc, nr, npos = c + dx, r + dy, pos
            if not (0 <= nc < COLS and 0 <= nr < ROWS):
                npos = (pos[0] + dx, pos[1] + dy)
                if npos not in layout:
                    continue
                nc, nr = nc % COLS, nr % ROWS
            if grids[layout[npos]][nr][nc] in WALKABLE + (OverworldSettings.PIER_CHAR,):
                queue.append((npos, (nc, nr)))
    return {layout[pos] for pos, _, _ in seen}


def as_walked(grids: dict, painted: list[str], koi: bool = True) -> dict:
    """``grids`` with the ``painted`` rooms as the party walks them, with the ko'i or (``koi`` False) without;
    the grids given are not changed.

    As the game has it: with the ko'i a tree or stump chops anywhere but on a room's edge, in the village and in
    Lanu's grove, where it stands like a wall. A tree placed with a kind is a tree like any other, and
    every other building blocks (one that comes and goes, by night or by the story, is left out).
    """
    grids = dict(grids)
    for name in painted:
        grid = [list(row) for row in grids[name]]
        shut = set()
        for building in cells.BUILDINGS.get(name, []):
            if building["kind"] in OverworldSettings.TREE_BUILDINGS:
                grid[building["row"]][building["col"]] = WALL
            elif (building["kind"] not in OverworldSettings.FLAT_BUILDINGS
                  and not building.get("night") and not building.get("when")):
                shut |= cells.building_tiles(building)
        if koi and name not in BackgroundSettings.TOWN_ROOMS and name != ToolSettings.GROVE:
            for r in range(1, ROWS - 1):
                for c in range(1, COLS - 1):
                    if grid[r][c] in (WALL, OverworldSettings.STUMP_CHAR):
                        grid[r][c] = FLOOR
        for c, r in shut:
            grid[r][c] = WALL
        grids[name] = grid
    return grids


def _walkable_back(place: dict, rooms: list[dict], layout: dict, grids: dict) -> bool:
    """True if every room of ``rooms`` leads back to the room the place is entered from.

    The party must never be stuck in a generated place (no field ability
    is ever needed there), so this is checked before anyone walks in.
    """
    layout = dict(layout)
    grids = dict(grids)
    for room in rooms:
        layout[room["pos"]] = room["id"]
        grids[room["id"]] = room["grid"]
    # The ways in may have trees across them (the Great Boar's room, Frankie 11/20), so the painted rooms
    # are walked as the ko'i's holder finds them.
    made = {room["id"] for room in rooms}
    grids = as_walked(grids, [name for name in layout.values() if name not in made])
    # Every way in is a way out (Frankie, 11/12: the temple's north and the lodge's west too), so the
    # place must lead back out by each of them, not only the first one found.
    ways = [pos for pos, name in sorted(layout.items()) if name in place.get("entered_from", [])]
    if not ways:
        return True
    for way_out in ways:
        reached = reachable_rooms(layout, grids, way_out)
        if not all(room["id"] in reached for room in rooms):
            return False
    return True


def build(place: dict, seed: int, named: dict, grids: dict) -> tuple[list[dict], int, int]:
    """The place's rooms for ``seed`` that can all be walked back out of, with how many tries it took.

    A slot for the set piece that leaves a room shut off is passed over for the next slot (the same
    layout), and only when every slot has failed is the whole place built again from the next seed,
    which the save never needs to know about. Returns ``(rooms, seeds_used, pieces_used)``, the last
    two counting from 0.
    """
    tries = 0
    for attempt in range(20):
        for piece_try in range(PIECE_TRIES):
            rooms = generate(place, seed + attempt * 7919, named, grids, piece_try)
            if _walkable_back(place, rooms, named, grids):
                return rooms, attempt, piece_try
            tries += 1
            if not place.get("set_piece"):
                break
    return rooms, 19, tries


# How many slots a set piece is tried in before the place is built from another seed.
PIECE_TRIES = 6


def install(seed: int) -> None:
    """Build every generated place from ``seed`` into the game's rooms.

    Takes out the rooms the last call put in first, so a new game or a
    loaded one replaces the woods instead of stacking a second copy, and
    takes out any painted room standing in a place's area.
    """
    for name in INSTALLED:
        cells.CELLS.pop(name, None)
        cells.PEOPLE.pop(name, None)
        cells.FIELD_MONSTERS.pop(name, None)
        cells.BUILDINGS.pop(name, None)
    for pos in [pos for pos, name in cells.WORLD_LAYOUT.items() if name in INSTALLED]:
        del cells.WORLD_LAYOUT[pos]
    INSTALLED.clear()
    for place in load_places():
        area = area_slots(place)
        for pos in [pos for pos in cells.WORLD_LAYOUT if pos in area]:
            name = cells.WORLD_LAYOUT.pop(pos)
            cells.CELLS.pop(name, None)
            cells.PEOPLE.pop(name, None)
            cells.FIELD_MONSTERS.pop(name, None)
        named = {pos: name for pos, name in cells.WORLD_LAYOUT.items()}
        # A place that would leave a room shut off tries its set piece in the next slot, then is built
        # again from the next seed; the save keeps the first seed, so this is repeatable.
        rooms, _, _ = build(place, seed, named, cells.CELLS)
        for room in rooms:
            name = room["id"]
            cells.CELLS[name] = room["grid"]
            cells.PEOPLE[name] = room["people"]
            cells.FIELD_MONSTERS[name] = room["monsters"]
            cells.BUILDINGS[name] = room.get("buildings", [])
            cells.WORLD_LAYOUT[room["pos"]] = name
            INSTALLED.add(name)
