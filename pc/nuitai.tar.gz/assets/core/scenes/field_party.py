"""The field menu's Party screen (Frankie, 11/21), laid out as Super Mario RPG's party switch.

The three who fight are small windows stacked down the left (green borders), the bench, room for four, small windows stacked
down the right (cyan borders), each with the member's sprite, name and HP. The space left under the fighters, bottom left,
is the text window. A picks someone up: they ride the hook, their own window fades, and A on another member trades their
places, from the fighters to the bench or within the fighters (the first three's order is the order they fight in); A on the
same one puts them back, B puts them back too. Y flips the stance the member under the hook starts fights in. B goes back.
Left and right cross between the two stacks. The rules are the old Party page's.
"""

from __future__ import annotations

import pygame

from core.factories import stance_numbers
from core.scenes.field_menu_main import M, blit32
from core.scenes.field_menu_pages import Page
from core.shared import by_id, short_name
from ui import input_map, text_renderer
from ui.field_menu_kit import GRAY, RED, WHITE, YELLOW, box, text
from utils.graphics import load_party_sheet

GREEN, CYAN = (92, 196, 106), (110, 200, 232)
CW, CH, PITCH = 112, 42, 46
LX, RX = M, 256 - M - CW
BENCH = 4
FIGHTERS = 3


class PartyScreen(Page):
    """The hook's place is an index into ``party.members``: 0 to 2 fight, 3 up to 6 wait."""

    full = True

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        self.cursor = min(menu.member, max(0, len(self.gm.party.members) - 1))
        self.held: int | None = None
        self.last_hook: pygame.Rect | None = None

    # -- input -------------------------------------------------------------------------------------

    def handle(self, event) -> str | None:
        members = self.gm.party.members
        audio = self.gm.audio
        fighters = min(FIGHTERS, len(members))
        if input_map.is_cancel(event):
            if self.held is not None:
                self.held = None
                audio.play("menu_move")
                return None
            return "back"
        if not members:
            return None
        bench = min(BENCH, len(members) - fighters)
        if input_map.is_up(event) or input_map.is_down(event):
            step = -1 if input_map.is_up(event) else 1
            if self.cursor < fighters:
                self.cursor = (self.cursor + step) % fighters
            elif bench:
                self.cursor = fighters + (self.cursor - fighters + step) % bench
            audio.play("menu_move")
        elif input_map.is_left(event) and self.cursor >= fighters:
            self.cursor = min(self.cursor - fighters, fighters - 1)
            audio.play("menu_move")
        elif input_map.is_right(event) and self.cursor < fighters and bench:
            self.cursor = fighters + min(self.cursor, bench - 1)
            audio.play("menu_move")
        elif input_map.is_tool(event):
            member = members[self.cursor]
            if len(by_id("characters").get(member.id, {}).get("stances", [])) > 1:
                member.stance = 1 - member.stance
                audio.play("menu_select")
        elif input_map.is_confirm(event):
            audio.play("menu_select")
            if self.held is None:
                self.held = self.cursor
            elif self.held == self.cursor:
                self.held = None
            else:
                members[self.held], members[self.cursor] = members[self.cursor], members[self.held]
                self.held = None
        return None

    # -- drawing -------------------------------------------------------------------------------------

    def _spot(self, index: int) -> tuple[int, int]:
        if index < FIGHTERS:
            return LX, M + index * PITCH
        return RX, M + (index - FIGHTERS) * PITCH

    def _window(self, surface, member, x: int, y: int, border, lit: bool, ghost: bool) -> None:
        box(surface, x, y, CW, CH, border=border)
        if member is None:
            return
        if lit:
            cell = pygame.Surface((CW - 12, CH - 10), pygame.SRCALPHA)
            cell.fill((255, 255, 255, 36))
            surface.blit(cell, (x + 6, y + 5))
        sheet = load_party_sheet(f"{member.id}_idle")
        if sheet and sheet[0]:
            frame = sheet[0][0]
            image = frame.subsurface(frame.get_bounding_rect()).copy()
            if ghost:
                image.set_alpha(90)
            surface.blit(image, (x + 24 - image.get_width() // 2, y + 5 + (32 - image.get_height())))
        down = member.current_hp <= 0
        color = GRAY if ghost else (RED if down else WHITE)
        _, shown, top = stance_numbers(member)
        text(surface, short_name(member.id), x + 46, y + 9, color)
        text(surface, "KO" if down else f"{shown}/{top}", x + 46, y + 23, color)

    def render(self, surface, lay, active) -> None:
        members = self.gm.party.members
        fighters = min(FIGHTERS, len(members))
        for slot in range(FIGHTERS + BENCH):
            member = members[slot] if slot < len(members) else None
            if slot < FIGHTERS:
                x, y = LX, M + slot * PITCH
                border = GREEN
            else:
                x, y = RX, M + (slot - FIGHTERS) * PITCH
                border = CYAN
            lit = slot == self.cursor and member is not None
            self._window(surface, member, x, y, border, lit, ghost=self.held is not None and not lit)
        helpy = M + FIGHTERS * PITCH
        box(surface, M, helpy, CW, 224 - M - helpy)
        words = ("Press A on someone to trade places." if self.held is not None else
                 "Press A on someone, then A on another to swap. Press Y to change a stance.")
        for row, line in enumerate(text_renderer.wrap(words, text_renderer.get_font(8), CW - 12)):
            text(surface, line, M + 6, helpy + 8 + row * 11, WHITE)
        x, y = self._spot(self.cursor)
        if self.held is not None and self.held < len(members):
            blit32(surface, members[self.held].id, x + 8, y - 24)      # the one picked up rides the hook
        self.last_hook = text_renderer.draw_pointer(surface, (x + 8, y + 16), YELLOW, from_screen_top=True)
