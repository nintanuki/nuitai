"""GAME OVER, after the party falls in a fight that is not a story fight.

Done the Final Fantasy VI way (Frankie, 10/24): a dark screen with the
words, a short pause, then any button goes to the title, where the player
loads the last save. Everything since that save is lost: the game is
already thrown away when this screen opens, so nothing of it reaches the
next load. Story fights never come here; losing one plays it again, but Maika's Kapre fight in the clearing
(Frankie, 11/12) ends here, a plain game over.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from settings import ColorSettings, FontSettings, GameOverSettings, ScreenSettings
from systems.party import Party
from ui import text_renderer

if TYPE_CHECKING:
    from main import GameManager


def game_over(gm: "GameManager") -> None:
    """Throw the lost game away and show GAME OVER in its place."""
    gm.scene_stack.clear()
    gm.party = Party()
    gm.audio.stop_music()
    gm.scene_stack.push(GameOverScene(gm))


class GameOverScene(Scene):
    """The dark screen; any button, after the pause, goes to the title."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Start the pause."""
        super().__init__(gm)
        self._held = 0.0

    def handle_event(self, event: pygame.event.Event) -> None:
        """Any key or button once the pause is over: the title, as the console just switched on."""
        if self._held < GameOverSettings.HOLD_SECONDS:
            return
        if event.type in (pygame.KEYDOWN, pygame.JOYBUTTONDOWN):
            self.gm.soft_reset()

    def update(self, dt: float) -> None:
        """Count the pause."""
        self._held += dt

    def render(self, surface: pygame.Surface) -> None:
        """The words in the middle of a black screen."""
        surface.fill(ColorSettings.BLACK)
        size = FontSettings.SIZE_HEADING
        width = text_renderer.text_width(GameOverSettings.TEXT, size)
        x = (ScreenSettings.WIDTH - width) // 2
        y = (ScreenSettings.HEIGHT - text_renderer.line_height(size)) // 2
        text_renderer.draw_text(surface, GameOverSettings.TEXT, (x, y), size=size)
