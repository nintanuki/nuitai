"""The field menu's main screen and its shared pieces (Frankie, 11/21): Final Fantasy VI's layout in Super Mario RPG's
floating windows.

The party stands on the field, darkened, and the windows float over it: an 8 pixel margin round the screen, 6 pixel gaps,
each window only as big as what it holds. One small window per fighter on the left (the 32 by 32 battle sprite, the
name, HP now over max, the two elements with the starting stance boxed); at the right the commands as a plain white list,
and under it one window with the pule, the kupang and the time of day, stacked. The pictures are in
``game/pygame/docs/design/menu-mockup/`` (``1a-main-menu-field``); the measures here are theirs.
"""

from __future__ import annotations

import pygame

from core.factories import stance_numbers
from core.shared import by_id, short_name
from settings import BattleSettings, ColorSettings
from ui import field_menu_kit as kit
from ui import text_renderer
from ui.field_menu_kit import GRAY, RED, WHITE, YELLOW, box, text, width
from ui.window import draw_window
from utils.graphics import load_element_icon, load_party_sheet

M, G = 8, 6                      # the margin round the screen, the gap between windows
SHADE = (4, 12, 30, 150)         # what darkens the field behind the windows
COMMANDS = ("Items", "Element", "Equip", "Status", "Party", "Info", "Config")
CMD_ROW = 16
MEMBER_W, MEMBER_H = 140, 62
TOP = 13                         # the first window's top: the three and their gaps are centred on the screen


def darken(surface: pygame.Surface) -> None:
    """The field the menu floats over, dimmed."""
    shade = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
    shade.fill(SHADE)
    surface.blit(shade, (0, 0))


_SPRITE32: dict[str, pygame.Surface | None] = {}


def sprite32(member_id: str) -> pygame.Surface | None:
    """The member's battle idle pose cut to its pixels, which is at most 32 by 32."""
    if member_id not in _SPRITE32:
        sheet = load_party_sheet(f"{member_id}_idle")
        _SPRITE32[member_id] = (sheet[0][0].subsurface(sheet[0][0].get_bounding_rect()).copy()
                                if sheet and sheet[0] else None)
    return _SPRITE32[member_id]


def blit32(surface: pygame.Surface, member_id: str, x: int, y: int) -> None:
    """The sprite centred in the 32 by 32 square at ``(x, y)``."""
    image = sprite32(member_id)
    if image is not None:
        surface.blit(image, (x + (32 - image.get_width()) // 2, y + (32 - image.get_height()) // 2))


def start_element(member):
    stances = by_id("characters").get(member.id, {}).get("stances", [])
    return stances[member.stance]["element"] if stances and 0 <= member.stance < len(stances) else None


def member_y(index: int) -> int:
    return TOP + index * (MEMBER_H + G)


def party_tip(index: int, spot: str, slot: int = 0) -> tuple[int, int]:
    """Where the hook's tip hangs on a fighter's window: ``sprite``, ``name`` or ``element`` (with its ``slot``)."""
    x, y = M, member_y(index)
    if spot == "sprite":
        return x + 8, y + 34
    if spot == "name":
        return x + 44, y + 16
    return x + 50 + 2 + slot * 26 - 1, y + 36 + 14


def draw_member(surface: pygame.Surface, member, x: int, y: int, held: bool = False) -> None:
    """One fighter's window at ``(x, y)``; ``held`` outlines it (the one picked up to swap places)."""
    box(surface, x, y, MEMBER_W, MEMBER_H)
    if held:
        pygame.draw.rect(surface, YELLOW, (x - 1, y - 1, MEMBER_W + 2, MEMBER_H + 2), 1, border_radius=3)
    blit32(surface, member.id, x + 10, y + 15)
    _, shown, top = stance_numbers(member)
    down = member.current_hp <= 0
    tx = x + 50
    text(surface, short_name(member.id), tx, y + 10, RED if down else WHITE)
    text(surface, "KO" if down else f"HP {shown}/{top}", tx, y + 22, RED if down else WHITE)
    start = start_element(member)
    for slot, element in enumerate(member.elements):
        icon = load_element_icon(element)
        ix, iy = tx + 2 + slot * 26, y + 36
        if icon is not None:
            surface.blit(icon, (ix, iy))
        if element == start:
            pygame.draw.rect(surface, YELLOW, (ix - 2, iy - 2, 22, 22), 2, border_radius=2)


def command_rect() -> pygame.Rect:
    x = M + MEMBER_W + G
    return pygame.Rect(x, TOP, 256 - M - x, M + len(COMMANDS) * CMD_ROW)


def wallet_rows(party) -> list[tuple[str, str]]:
    """What the money window shows, top to bottom: (icon name, words); the time only once the clock runs."""
    from systems import daytime

    rows = [("pule", f"{party.pule}"), ("kupang", f"{party.kupang}")]
    if daytime.running(party):
        rows.append(("sky", daytime.clock_text(party)))
    return rows


def draw_main(surface: pygame.Surface, party, fighters: list, cursor: int, active: bool = True,
              party_hook: tuple | None = None, held: int | None = None) -> None:
    """The main screen: the fighters, the commands with the hook on ``cursor``, the wallet and the time."""
    from systems import daytime
    from ui.item_icon import sky_icon

    for index, member in enumerate(fighters[:BattleSettings.FIGHTERS]):
        draw_member(surface, member, M, member_y(index), held=index == held)
    cmd = command_rect()
    box(surface, cmd.x, cmd.y, cmd.w, cmd.h)
    for index, word in enumerate(COMMANDS):
        text(surface, word, cmd.x + 22, cmd.y + 8 + index * CMD_ROW)
    wallet = wallet_rows(party)
    wy = cmd.bottom + G
    box(surface, cmd.x, wy, cmd.w, 12 + 20 * len(wallet))
    for index, (kind, words) in enumerate(wallet):
        y = wy + 6 + index * 20
        if kind == "sky":
            surface.blit(sky_icon(daytime.daylight(party)), (cmd.x + 8, y + 5))
        else:
            icon = load_element_icon(kind)
            if icon is not None:
                surface.blit(icon, (cmd.x + 8, y))
        full = kind == "pule" and party.pule >= party.pule_max      # a full wallet turns the pule green (11/14)
        text(surface, words, cmd.right - 9, y + 5, ColorSettings.ELEMENT_ARROW if full else WHITE, right=True)
    if party_hook is not None:
        text_renderer.draw_pointer(surface, party_tip(*party_hook), YELLOW)
    elif active:
        text_renderer.draw_pointer(surface, (cmd.x + 16, cmd.y + 8 + cursor * CMD_ROW + 4), YELLOW)
