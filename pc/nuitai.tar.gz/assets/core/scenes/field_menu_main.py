"""The field menu's main screen and its shared pieces (Frankie, 11/21): Final Fantasy VI's layout in Super Mario RPG's
floating windows.

The party stands on the field, darkened, and the windows float over it: an 8 pixel margin round the screen, 6 pixel gaps,
each window only as big as what it holds. One small window per fighter on the left (the 32 by 32 battle sprite, the
name, HP now over max, the two elements with the starting stance boxed); at the right the commands as a plain white list,
and under it one window with the pule, the kupang and the time of day, stacked. The pictures are in
``game/pygame/docs/design/menu-mockup/`` (``1a-main-menu-field``); the measures here are theirs.
"""

from __future__ import annotations

import functools

import pygame

from core.factories import stance_numbers
from core.shared import by_id, short_name
from settings import BattleSettings, ColorSettings
from ui import field_menu_kit as kit
from ui import text_renderer
from ui.field_menu_kit import GRAY, RED, WHITE, YELLOW, box, text, width
from ui.window import draw_window
from utils.graphics import load_element_icon, load_party_sheet

M, G = 8, 6                      # the margin round the screen, the gap between windows
SHADE = (4, 12, 30, 150)         # what darkens the field behind the windows
COMMANDS = ("Items", "Element", "Equip", "Status", "Party", "Info", "Config")
CMD_ROW = 16
MEMBER_H = 62
TOP = 13                         # the first window's top: the three and their gaps are centred on the screen
TEXT_DX = 50                     # a fighter's name and HP, from its window's left
PAD = 9                          # the room right of the widest thing in a fighter's window
SIDE = 6                         # the right column's room inside each edge (Frankie, 11/23: thinner)
ICON = 16                        # the wallet's icon column: each icon centred in it
ICON_GAP = 4                     # from the icon column to the widest words


@functools.cache
def layout() -> tuple[int, int, int]:
    """The left edge, a fighter window's width and the right column's width (Frankie, 11/23).

    Each window is only as wide as the widest thing it can hold, with PAD past it: a fighter's
    longest name or HP at its most, the right column's wallet with the time at its widest; then
    the whole group is centred on the screen.
    """
    widest = max([text_renderer.text_width("HP 999/999")]
                 + [text_renderer.text_width(short_name(c)) for c in by_id("characters")])
    member_w = TEXT_DX + widest + PAD
    times = ("12:00 PM", "10:00 AM")   # the widest the clock gets
    right_w = max(SIDE + ICON + ICON_GAP + max(text_renderer.text_width(t) for t in times) + SIDE,
                  _hook_block() + 2 * SIDE)
    left = (256 - member_w - G - right_w) // 2
    return left, member_w, right_w


def _hook_block() -> int:
    """How wide the commands are as a block: the hook, the gap, the widest command."""
    return _HOOK_LEFT + _HOOK_TEXT + max(text_renderer.text_width(word) for word in COMMANDS)


_HOOK_LEFT = 8                   # the hook reaches this far left of its tip
_HOOK_TEXT = 6                   # from the tip to where a command's word starts


def darken(surface: pygame.Surface) -> None:
    """The field the menu floats over, dimmed."""
    shade = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
    shade.fill(SHADE)
    surface.blit(shade, (0, 0))


_SPRITE32: dict[str, pygame.Surface | None] = {}


def sprite32(member_id: str) -> pygame.Surface | None:
    """The member's battle idle pose cut to its pixels, which is at most 32 by 32."""
    if member_id not in _SPRITE32:
        sheet = load_party_sheet(f"{member_id}_idle_stance1") or load_party_sheet(f"{member_id}_idle")   # the fight idle (Frankie, 11/22)
        _SPRITE32[member_id] = (sheet[0][0].subsurface(sheet[0][0].get_bounding_rect()).copy()
                                if sheet and sheet[0] else None)
    return _SPRITE32[member_id]


def blit32(surface: pygame.Surface, member_id: str, x: int, y: int) -> None:
    """The sprite centred in the 32 by 32 square at ``(x, y)``."""
    image = sprite32(member_id)
    if image is not None:
        surface.blit(image, (x + (32 - image.get_width()) // 2, y + (32 - image.get_height()) // 2))


def start_element(member):
    stances = by_id("characters").get(member.id, {}).get("stances", [])
    return stances[member.stance]["element"] if stances and 0 <= member.stance < len(stances) else None


def member_y(index: int) -> int:
    return TOP + index * (MEMBER_H + G)


def party_tip(index: int, spot: str, slot: int = 0) -> tuple[int, int]:
    """Where the hook's tip hangs on a fighter's window: ``sprite``, ``name`` or ``element`` (with its ``slot``)."""
    x, y = layout()[0], member_y(index)
    if spot == "sprite":
        return x + 8, y + 34
    if spot == "name":
        return x + TEXT_DX - 6, y + 16
    return x + TEXT_DX + 2 + slot * 26 - 1, y + 36 + 14


def draw_member(surface: pygame.Surface, member, x: int, y: int, held: bool = False) -> None:
    """One fighter's window at ``(x, y)``; ``held`` outlines it (the one picked up to swap places)."""
    member_w = layout()[1]
    box(surface, x, y, member_w, MEMBER_H)
    if held:
        pygame.draw.rect(surface, YELLOW, (x - 1, y - 1, member_w + 2, MEMBER_H + 2), 1, border_radius=3)
    blit32(surface, member.id, x + 10, y + 15)
    _, shown, top = stance_numbers(member)
    down = member.current_hp <= 0
    tx = x + TEXT_DX
    text(surface, short_name(member.id), tx, y + 10, RED if down else WHITE)
    text(surface, "KO" if down else f"HP {shown}/{top}", tx, y + 22, RED if down else WHITE)
    start = start_element(member)
    for slot, element in enumerate(member.elements):
        icon = load_element_icon(element)
        ix, iy = tx + 2 + slot * 26, y + 36
        if icon is not None:
            surface.blit(icon, (ix, iy))
        if element == start:
            pygame.draw.rect(surface, YELLOW, (ix - 2, iy - 2, 22, 22), 2, border_radius=2)


def command_rect() -> pygame.Rect:
    left, member_w, right_w = layout()
    return pygame.Rect(left + member_w + G, TOP, right_w, M + len(COMMANDS) * CMD_ROW)


def command_tip_x() -> int:
    """The hook's tip: the hook and the commands centred in their window as one block."""
    cmd = command_rect()
    return cmd.x + (cmd.w - _hook_block()) // 2 + _HOOK_LEFT


def wallet_rows(party) -> list[tuple[str, str]]:
    """What the money window shows, top to bottom: (icon name, words); the time only once the clock runs."""
    from systems import daytime

    rows = [("pule", f"{party.pule}"), ("kupang", f"{party.kupang}")]
    if daytime.running(party):
        rows.append(("sky", daytime.clock_text(party)))
    return rows


def draw_main(surface: pygame.Surface, party, fighters: list, cursor: int, active: bool = True,
              party_hook: tuple | None = None, held: int | None = None) -> None:
    """The main screen: the fighters, the commands with the hook on ``cursor``, the wallet and the time."""
    from systems import daytime
    from ui.item_icon import sky_icon

    for index, member in enumerate(fighters[:BattleSettings.FIGHTERS]):
        draw_member(surface, member, layout()[0], member_y(index), held=index == held)
    cmd = command_rect()
    box(surface, cmd.x, cmd.y, cmd.w, cmd.h)
    for index, word in enumerate(COMMANDS):
        text(surface, word, command_tip_x() + _HOOK_TEXT, cmd.y + 8 + index * CMD_ROW)
    wallet = wallet_rows(party)
    wy = cmd.bottom + G
    box(surface, cmd.x, wy, cmd.w, 12 + 20 * len(wallet))
    for index, (kind, words) in enumerate(wallet):
        y = wy + 6 + index * 20
        icon = sky_icon(daytime.daylight(party)) if kind == "sky" else load_element_icon(kind)
        if icon is not None:
            # Every icon centred in one column, and up and down on its words' line (Frankie, 11/23).
            box_rect = icon.get_bounding_rect()
            surface.blit(icon, (cmd.x + SIDE + (ICON - box_rect.width) // 2 - box_rect.x,
                                y + 5 + 3 - box_rect.height // 2 - box_rect.y))
        full = kind == "pule" and party.pule >= party.pule_max      # a full wallet turns the pule green (11/14)
        text(surface, words, cmd.right - SIDE, y + 5, ColorSettings.ELEMENT_ARROW if full else WHITE, right=True)
    if party_hook is not None:
        text_renderer.draw_pointer(surface, party_tip(*party_hook), YELLOW)
    elif active:
        text_renderer.draw_pointer(surface, (command_tip_x(), cmd.y + 8 + cursor * CMD_ROW + 4), YELLOW)
