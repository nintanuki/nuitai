"""Battle scene: hosts a ``Battle`` and a ``BattleView``.

The scene owns no rules. It builds a ``Battle`` from content data,
asks it to advance, and plays the events it gets back one at a time so
that each line of narration appears together with the change it
describes (an HP number dropping, a status appearing).

What the fighters look like and how they move is ``ui.battle_stage``.
The scene hands it each event as that event's line comes up, so a
monster shakes at the moment the text says it was hit.

Each frame:

* Narration on screen holds for a moment and then advances on its own;
  confirm advances it at once.
* When nothing is left to narrate and a party member's turn is waiting,
  the bottom HUD becomes a command panel: Attack / Skill / Element /
  Item on the left, the party's rows with their mana on the right. Skill
  is the member's signature command, labeled by its name (D-692); only
  Kailo's Cook works yet, the rest grey. Left turns to a page with
  Equip (Weapon or Element), Defend and Escape, right to one with Team Up (only while a
  Team Up is open) and Swap (D-455, the battle menu line in
  ``game/answers.md``).
  Cook (Frankie, 11/4) lists the meals made at the pot outside a fight;
  after the stir the meal is served to the whole party at the start of his
  next turn (``Battle.submit_cook``), and a hit before then ruins it.
  Attack picks an enemy and opens the stroke menu: Light, Medium and
  Strong strokes (1, 2 and 3 of the turn's 7 points, shown top right),
  and Element. Each stroke that lands builds mana, which Element spends
  (D-213 to D-220). After a stroke, cancel goes back to the commands
  with the points left (D-578): Attack strikes on, and Element, Defend or
  Item ends the turn; Swap is grey until the next turn. Ability and Item open submenus;
  anything aimed at someone enters target selection with a pulsing
  arrow on the fighter. There is no help line (D-450).
* Otherwise ``battle.start_turn()`` is called to move to the next turn.

The strip across the top shows who acts next. While the player moves
through the menus it previews the order as it would be if they took
the highlighted action: the wait is the turn's fatigue (D-328), so a
long chain of strokes brings the next turn later.
"""

from __future__ import annotations

import random
import time
from collections import deque
from typing import TYPE_CHECKING, Any

import pygame

from core.events import (
    AbilityUsedEvent,
    ComboUsedEvent,
    AttackEvent,
    BattleEndedEvent,
    BlockStartEvent,
    CombatantDefeatedEvent,
    DamageEvent,
    DodgeEvent,
    HealEvent,
    RevivedEvent,
    MissEvent,
    StanceEvent,
    SummonEvent,
    StrokeEvent,
    SwapEvent,
)
from core import lore
from core.elements import Element
from core.battle_tutorial import HinaTutorial, dim_except
from core.factories import (
    combatant_from_monster_data,
    combatant_from_party_member,
    first_loadout,
    known_moves,
    stance_numbers,
)
from core.scene import Scene
from core.scenes.battle_swap import ElementSwap
from core.scenes.inventory_scene import item_help
from systems import battle_bag
from core.scenes.game_over_scene import game_over
from core.scenes.victory_scene import Fighter, VictoryReport, VictoryScene
from core.shared import by_id, short_name, skill_for
from core.stats import monster_hp
from settings import (
    SwimSettings,
    AudioSettings,
    BattleSettings,
    BattleStageSettings,
    BlockSettings,
    LoadoutSettings,
    MinigameSettings,
    ColorSettings,
    FontSettings,
    InputSettings,
    ItemSettings,
    ScreenSettings,
    StorySettings,
    TutorialSettings,
    UISettings,
    VictorySettings,
)
from systems import bounties, config, cooking, diet, loot, mastery
from systems.loadout import help_lines, learn, open_slots
from systems.battle import Battle, Combatant
from systems.timed_block import BlockMeter
from systems.passives import after_victory, growth_step
from ui import input_map, text_renderer
from ui.battle_stage import BattleStage
from ui.battle_view import BattleView
from ui.block_meter import BlockMeterView
from ui.paddle_meter import PaddleMeter
from ui.spin_meter import SpinMeter
from ui.banish_meter import BanishMeter
from ui.pound_meter import PoundMeter
from ui.escape_meter import EscapeMeter
from ui.rhythm_meter import RhythmMeter
from ui.dance_meter import DanceMeter
from ui.simon_meter import SimonMeter, button_of
from ui.stir_meter import StirMeter
from ui.rain import render_light_wave, render_rain
from ui.vine_meter import VineMeter
from ui.sun_meter import PunchMeter
from ui.banish_meter import TapMeter
from ui.element_tag import tag_elements
from ui.grid_menu import GridCell, GridMenu, GridRow, short_move_name
from ui.item_icon import FOOD, item_icon
from ui.stance_icon import pair_icons, stance_icons, switch_icon
from ui.menu import Menu, MenuItem
from ui.notice_bar import NoticeBar
from ui.text_box import TextBox
from ui.window import draw_window
from utils.backgrounds import render_template

if TYPE_CHECKING:
    from main import GameManager
    from systems.party import PartyMember


# Encounters a fight with no named encounter rolls, for the tools (the
# map's fights come from field monsters, D-576). Every fight whose
# monsters use only rules this game has. The Dwende and Amaranhig fight
# needs zombie and the Kaperosa needs doom, so they wait.
_DEMO_ENCOUNTER_IDS: tuple[str, ...] = (
    "beast_pack", "mages", "shades", "great_boar",
)

# Index of each row in the top-level command menu.
_ATTACK_ROW, _TECH_ROW, _ABILITY_ROW, _ITEM_ROW = range(4)
# The Skills built in this game, by move id; the rest are on paper and grey.
# Which one a member has is the weapon type in hand (Frankie, 10/31).
_SKILLS_BUILT: tuple[str, ...] = ("cook", "scold", "charm", "call_the_dead", "paddle", "pound", "banish", "dance",
                                  "vault", "wili", "moepapa")

# The stroke menu's rows: the three strokes, then Element (D-455). Cancel ends the
# chain once a stroke has been swung (Frankie, 10/18).
_STROKE_KINDS: tuple[str, ...] = ("light", "medium", "strong")
_STROKE_ABILITY_ROW = 3
# What Memory notes when the stance switch was the last pick on the grid.
_SWITCH = "switch"
# The page arrows at the sides of the four commands (Frankie, 11/4): small solid triangles.
_PAGE_ARROW_W, _PAGE_ARROW_H = 4, 7


def _draw_page_arrow(surface: pygame.Surface, x: int, mid_y: int, pointing_right: bool,
                     color: tuple[int, int, int]) -> None:
    """Draw one page arrow, its point at the side it pages to."""
    half = _PAGE_ARROW_H // 2
    tip, back = (x + _PAGE_ARROW_W - 1, x) if pointing_right else (x, x + _PAGE_ARROW_W - 1)
    pygame.draw.polygon(surface, color, [(back, mid_y - half), (tip, mid_y), (back, mid_y + half)])


def _food(item: str) -> bool:
    """Whether ``item`` is eaten: an ingredient or a dish (Frankie, 11/3), not medicine or a totem."""
    return item in FOOD or item in ItemSettings.INGREDIENTS


def compose_fight(kind: dict[str, Any]) -> list[dict[str, Any]]:
    """The enemies a field monster brings into its fight (D-576).

    A boss names its fight (``encounter``). An ordinary monster always
    brings its ``lead``; each of its ``extra_slots`` is then filled one
    time in ``join_chance`` by a companion picked by weight (so how many come
    goes by the kind's own ``extra_slots``: aghoy up to three, a kapre never
    more than one). Repeats are
    lettered, Wild Boar A and Wild Boar B, the way the shared fights name them.

    Args:
        kind: The monster's ``data/field_monsters`` entry.

    Returns:
        Enemy entries shaped like the shared file's, ready for
        ``BattleScene(enemies=...)``.
    """
    templates = {
        entry["id"]: entry
        for encounter in by_id("encounters").values()
        for entry in encounter["enemies"]
    }
    if "encounter" in kind:
        return list(by_id("encounters")[kind["encounter"]]["enemies"])
    picks = [kind["lead"]]
    companions = kind.get("companions", {})
    for _ in range(kind.get("extra_slots", 0)):
        if companions and random.random() < kind.get("join_chance", 0.0):
            picks += random.choices(list(companions), weights=list(companions.values()))
    # A monster too big for company of its own kind (``BattleSettings.ONE_PER_FIGHT``, the kapre) comes once.
    kept: list[str] = []
    for pick in picks:
        monster = templates[pick]["monster"]
        if monster in BattleSettings.ONE_PER_FIGHT and any(templates[k]["monster"] == monster for k in kept):
            continue
        kept.append(pick)
    picks = kept
    # A mixed fight keeps to ``MIXED_MAX``.
    if len({templates[p]["monster"] for p in picks}) > 1:
        picks = picks[:BattleSettings.MIXED_MAX]
    # The shared names end in " A" where a fight holds several; strip it,
    # then letter again only what repeats here.
    bases = [templates[pick]["name"].removesuffix(" A") for pick in picks]
    entries = []
    for index, (pick, base) in enumerate(zip(picks, bases)):
        entry = dict(templates[pick])
        if bases.count(base) > 1:
            letter = "ABCDEFGH"[bases[:index].count(base)]
            entry["name"] = f"{base} {letter}"
        else:
            entry["name"] = base
        entry["id"] = f"{pick}_{index}"
        entries.append(entry)
    return entries


def _build_enemies(
    encounter_id: str | None = None, entries: list[dict[str, Any]] | None = None,
) -> tuple[list[Combatant], dict[str, str | None], set[str], list[dict[str, Any]]]:
    """Build the monsters for one encounter.

    Args:
        encounter_id: Which fight. None rolls one of the demo fights.
        entries: The enemies themselves, from ``compose_fight``; when
            given, ``encounter_id`` is not used.

    Returns:
        The monsters, each one's picture name keyed by its id, the ids
        of those that float (ghosts and flyers), and each monster's
        entry in the shared file, in the same order, for what it drops.
    """
    if entries is None:
        entries = by_id("encounters")[
            encounter_id or random.choice(_DEMO_ENCOUNTER_IDS)
        ]["enemies"]
    monsters = by_id("monsters")
    combatants = [
        combatant_from_monster_data(entry, monsters[entry["monster"]])
        for entry in entries
    ]
    sprites = {entry["id"]: entry.get("sprite") for entry in entries}
    floating = {entry["id"] for entry in entries if entry.get("floats")}
    kinds = [monsters[entry["monster"]] for entry in entries]
    return combatants, sprites, floating, kinds


def roll_drops(
    kinds: list[dict[str, Any]], rng: random.Random | None = None, burning: list[bool] | None = None,
    casts: list[set[str]] | None = None, who: tuple[str, ...] | None = None,
) -> tuple[int, dict[str, int]]:
    """What the beaten monsters leave behind (Frankie, 11/6; built 11/17, ``systems/loot.py``).

    One roll per monster over the drop categories, so each leaves one thing or nothing, and never
    pule: the first number returned is always 0, kept so the victory screen's shape does not change.
    The Great Boar always leaves his tusk too, a key item outside the roll (``ItemSettings.KEY_DROPS``).
    ``casts`` is the move ids each monster slotted and cast (one set per monster, in ``kinds`` order), the only
    elements that can drop (Frankie, 11/15); ``who`` is whose types the gear is for (``loot.owners``).

    Returns:
        0 pule, and the items found by id with their counts.
    """
    rng = rng or random.Random()
    items: dict[str, int] = {}

    def found(item: str | None) -> None:
        if item:
            items[item] = items.get(item, 0) + 1

    for number, kind in enumerate(kinds):
        if kind.get("id") in ItemSettings.KEY_DROPS:
            found(ItemSettings.KEY_DROPS[kind["id"]])
        cast = casts[number] if casts is not None and number < len(casts) else ()
        found(loot.roll(kind, rng, who, cast, bool(burning and burning[number])))
    return 0, items


def _pound_button(event: pygame.event.Event, hat_before: tuple[int, int], wanted: str) -> str | None:
    """The button a press is for Pound, or None (Frankie, 10/31).

    The stick counts too: some pads send their D-pad as a stick, and a held
    tilt is passed on only once (``ui.gamepads``), so it cannot repeat. On
    the D-pad only a newly pressed direction counts, so rolling onto a corner
    does not press the held one again; a corner pressed from the middle is
    the direction the move wants next, if it is one of the two.
    """
    if event.type == pygame.JOYHATMOTION:
        (x, y), (bx, by) = event.value, hat_before
        new = []
        if x and x != bx:
            new.append("LEFT" if x < 0 else "RIGHT")
        if y and y != by:
            new.append("UP" if y > 0 else "DOWN")
        if not new:
            return None
        return wanted if wanted in new else new[0]
    for test, name in ((input_map.is_up, "UP"), (input_map.is_down, "DOWN"), (input_map.is_left, "LEFT"),
                       (input_map.is_right, "RIGHT"), (input_map.is_confirm, "A"), (input_map.is_cancel, "B")):
        if test(event):
            return name
    return None


class BattleScene(Scene):
    """A turn-based encounter scene."""

    OPAQUE = True
    # The swirl in from the map, while it plays (ui/fight_swirl.py); None otherwise.
    swirl = None

    def __init__(
        self, gm: "GameManager", encounter_id: str | None = None,
        enemies: list[dict[str, Any]] | None = None, can_escape: bool = True,
        in_town: bool = False, story: bool = False, tutorial: bool = False, cast_lesson: bool = False,
        music: str | None = None, swap_lesson: str | None = None,
        opening: str | None = None, timed_blocks: bool | None = None,
        at_sea: bool = False, opening_blow: str | None = None,
        win_flag: str | None = None, underwater: bool = False,
    ) -> None:
        """Build the battle from the party and an encounter.

        Args:
            gm: The game manager.
            encounter_id: A fight from the shared battle file. None
                rolls one of the demo fights at random.
            enemies: The enemies themselves, from ``compose_fight``,
                for a fight a field monster starts (D-576).
            can_escape: False for a story fight: Escape is gray (D-041).
            in_town: True for a fight in town, which stands on the beach;
                anywhere else it stands in the jungle (Frankie, 10/23).
            at_sea: True for a fight started at sea, which stands on the open
                ocean (Frankie, 11/1).
            underwater: True for a fight a swimmer starts: fire does nothing and
                Cook is grey (Frankie, 11/17).
            story: True for a story fight. Losing one plays it again;
                losing any other is game over (D-148).
            tutorial: True for the taro patch fight: Hina asks if Kailo
                remembers how to fight, and reminds him (core/battle_tutorial.py).
            win_flag: A party flag a win sets, before the slots are counted, for a story fight that opens an
                element slot though its monsters are not unique (Maika's six Aghoy, Frankie, 11/15).
            music: The scene's Song, played instead of the fight's (Tawiri's
                theme at the wake, Frankie 10/26). A win still plays the
                victory theme, and the field's song comes back once the
                victory screen closes (Frankie, 10/27).
            swap_lesson: Who on the bench Hina and they talk the player
                through swapping in, on the first turn, then the swap forced:
                the player picks who sits out; swapped in, they grumble (Maika
                at the wake, Frankie 10/30). Whoever ``StorySettings.SWAP_LOCKED``
                names cannot be swapped out of that fight.
            opening: "preemptive" or "ambush": who was caught from behind
                or the side, and starts with full fatigue (Frankie, 10/27).
            opening_blow: The id of a fighter whose field strike hit the monster: they land one
                Strong stroke on it at once, before the first turn (Frankie, 11/14).
            timed_blocks: Whether a monster's plain strokes open the timed
                block meter. None follows ``BlockSettings.ENABLED``, off in
                headless runs.
        """
        super().__init__(gm)
        self.can_escape = can_escape
        self.story = story
        self._win_flag = win_flag
        self.backdrop = "sea" if at_sea else "beach" if in_town else "jungle"
        # Once the Great Boar is beaten it is night, until the morning after the jump (Frankie, 11/1).
        flags = gm.party.flags
        if self.backdrop != "sea" and flags.get(StorySettings.NIGHT_FLAG) and not flags.get(StorySettings.AFTER_JUMP_FLAG):
            self.backdrop += "_night"
        self.moves = by_id("moves")
        # Noni is a Party-level resource that persists across
        # battles. If the inventory entry is missing entirely (old
        # save, never been to a battle), fall back to the new-game
        # starter count so the player isn't silently emptied out.
        # Items are in each member's battle bag now (Frankie, 11/12); battle.noni mirrors the
        # acting member's Noni (_sync_noni).
        starting_noni = 0
        enemies, sprites, floating, self._kinds = _build_enemies(encounter_id, enemies)
        # Words said and narration shown before the first turn, in this order.
        self._sayings: deque[tuple[str, str]] = deque()
        self._after_talk: deque[str | tuple[str, str]] = deque()
        self._jingle_due = False  # The learned jingle waits for the talk before it.
        # Counter in the bank: the move the player must slot before the first turn (Frankie, 11/11),
        # and the seconds the picker stays deaf once up.
        self._forced_slot: str | None = None
        self._swap: ElementSwap | None = None   # The element swap screen, while Equip, Element is open (Frankie, 11/12).
        self._learn_counter_at_the_boar()
        # A won fight's victory screen (Frankie, 10/26): what it shows, built
        # as the fight ends, the hold before it opens, and whether it has.
        self.victory: VictoryReport | None = None
        self._victory_hold = 0.0
        self._victory_shown = False
        # A fight with a boss in it plays the boss songs (music.json); a
        # boss is a monster marked `boss` in the shared file. The Great Boar's own
        # fight has Frankie's Boss Battle 1 (11/11); a scene's Song still wins.
        self._music = music or (
            "great_boar_fight" if any(foe.id == "great_boar" for foe in enemies)
            else "boss" if any(foe.boss for foe in enemies) else "battle")
        self._won_music = "victory"
        self._swap_lesson = swap_lesson
        # The six-Aghoy fight: Hina's line on the first Green Dream or Revive an enemy casts (Frankie, 11/15).
        self._cast_lesson = cast_lesson
        # At the wake Tawiri stays in (Frankie, 10/30).
        self._swap_locked = StorySettings.SWAP_LOCKED if swap_lesson else None
        # The first three fight; the rest wait on the bench (D-196).
        everyone = [combatant_from_party_member(m, self.gm.party.flags) for m in self.gm.party.members]
        weapons = by_id("weapons")
        for member, combatant in zip(self.gm.party.members, everyone):
            held = weapons.get(member.weapon or "")
            combatant.weapon = held["name"] if held else None
        # The knocked out stay down between fights (Frankie, 10/26); with the
        # first three all down, the first standing one on the bench steps in.
        if not any(c.alive for c in everyone[:BattleSettings.FIGHTERS]):
            standing = next((c for c in everyone if c.alive), None)
            if standing is not None:
                at = everyone.index(standing)
                everyone[0], everyone[at] = standing, everyone[0]
        self.battle = Battle(
            party_combatants=everyone[:BattleSettings.FIGHTERS],
            enemy_combatants=enemies,
            moves=self.moves,
            noni=starting_noni,
            bench=everyone[BattleSettings.FIGHTERS:],
            combos=by_id("combos"),
            opening=opening,
        )
        self.battle.underwater = underwater
        # Pono's Corpse is fought at night, however the scene was reached (Frankie, 11/1).
        if any(c.id == "ponos_corpse" for c in enemies) and not self.backdrop.endswith("_night") and self.backdrop != "sea":
            self.backdrop += "_night"
        # Tawiri's party passive: stats grow faster (systems/passives.py).
        self.battle.growth["step"] = growth_step(self.gm.party)
        # Timed blocks (Frankie, 10/30): off in headless runs (BlockSettings.ENABLED).
        self.battle.timed_blocks = BlockSettings.ENABLED if timed_blocks is None else timed_blocks
        self.meter: BlockMeterView | None = None
        # Kailo's Paddle while A is being mashed (Frankie, 10/31).
        self.paddle: PaddleMeter | None = None
        # Hina's Banish while the bow is drawn (Frankie, 10/31).
        self.banish: BanishMeter | None = None
        # Maika's and Tawiri's Wili while the pad is spun (Frankie, 11/1).
        self.spin: SpinMeter | None = None
        # Kailo's Pound while its buttons are being pressed (Frankie, 10/31).
        self.pound: PoundMeter | None = None
        # The minigames of 11/1 (Frankie): Cook's stir, Scold's mash, Charm's Simon, Vault's
        # jump, Call's beat and Moepapa's tap; what each hands the battle when it is done.
        self.minigame: Any = None
        self._minigame_done: Any = None
        self._skill_listing = False  # True while the list menu holds Cook's meals or Pound's moves.
        self._team_up_listing = False  # True while the list menu holds the Team Ups.
        self._team_up_partners: list[Combatant] = []  # Each Team Up row's partner, in order.
        self._pound_hat = (0, 0)     # The D-pad as last seen, so Pound counts only new presses.
        self._block_attacker = ""
        self._meter_age = 0.0   # seconds the parry meter has been open
        self._block_target = ("", "")
        # Narration goes in the left part of the window, with the commands; the party's
        # rows stay visible on the right while it plays.
        self.text_box = TextBox(
            width=UISettings.COMMAND_PANEL_WIDTH, x=UISettings.COMMAND_PANEL_X,
        )
        # "Went up!" lines show along the top without stopping the fight (D-526).
        self.notices = NoticeBar(pygame.Rect(UISettings.NOTICE_RECT))
        if opening in BattleSettings.OPENING_WORDS:
            self.notices.push(BattleSettings.OPENING_WORDS[opening])
        self.view = BattleView(self.text_box, self.notices)
        self.stage = BattleStage(
            self.battle.party, self.battle.enemies, sprites, floating,
            bench=self.battle.bench, lineup=lambda: self.battle.lineup,
        )
        # Events the battle has produced but the screen has not shown yet.
        self._events: deque[Any] = deque()
        # HP as currently shown. It trails the battle's real HP until
        # the damage or heal event that changed it has been narrated.
        self._shown_hp: dict[str, int] = {
            c.id: c.hp
            for c in self.battle.party + self.battle.bench + self.battle.enemies
        }
        # Seconds the current finished line has been on screen.
        self._narration_held = 0.0
        # Seconds left before the next event plays: each stroke gets a
        # beat of its own, since strokes have no line to wait on.
        self._beat = 0.0
        self._turn_pause_due = False
        # True once the counter at the head of the queue has had its beat.
        self._counter_held = False
        self._striker: str | None = None   # Who swung last, so a hit sounds like their weapon (D-151).
        self._dodge_streak = 0       # Perfect dodges in a row, for Hina's grudging line (Frankie, 11/4).
        # Seconds the meter stays up after a kick back on it, so its number reads (Frankie, 11/2).
        self._kick_hold = 0.0
        self._rise_held = False   # the beat before a Green Dream rise has been waited
        self._just_fell: str | None = None
        # Seconds the fight's first commands stay deaf once up, so a press
        # still meant for walking (up wraps Attack round to Item, left opens
        # the drawer) does not pick for the player (playtest, 10/28).
        self._settle = BattleSettings.FIRST_COMMANDS_SETTLE
        self._battle_finished = False
        self.command_menu = Menu(
            items=[
                MenuItem("Attack", self._on_attack),
                MenuItem("", self._on_tech),
                MenuItem("Element", self._on_open_abilities),
                MenuItem("Item", self._on_open_items),
            ],
        )
        # Which page of commands shows: -1 Equip, Defend and Escape, 0 the four
        # commands, 1 Team Up and Swap (D-455). Built when turned to.
        self._page = 0
        self._select_held = False      # Select held over a command: the window saying what it does.
        self._why: tuple[str, float] | None = None  # A greyed row's reason and its seconds left (Frankie, 11/4).
        self.side_menu: Menu | None = None
        # Equip, Team Up and Swap open a list that takes the window.
        self.list_menu: Menu | None = None
        # The Attack's stroke menu, open from the first target pick until
        # the turn ends.
        self.stroke_menu: Menu | None = None
        self._chain_target_id: str | None = None
        self.ability_menu: GridMenu | None = None
        # The stance switch's sign colors, (to, from), while its row is on the grid,
        # and whether the window over its name, asking to switch, is open.
        self._switch_pair: tuple[str, str] | None = None
        self._switch_open = False
        # The held stance's move rows, put aside while the window previews the other's.
        self._held_rows: list[GridRow] | None = None
        self.item_menu: Menu | None = None
        self._pending_command: dict[str, Any] | None = None
        self._target_pool: list[Combatant] = []
        self._target_cursor: int = 0
        self.tutorial = HinaTutorial(self) if tutorial else None
        if tutorial:
            # The tutorial fight always opens on Kailo's turn (Frankie, 11/4): the dice never give Hina the first.
            for c in self.battle.party:
                if c.id == "kailo":
                    c.counter = min(x.counter for x in self.battle.party + self.battle.enemies) - 0.001
        both = {"kailo", "hina"} <= {c.id for c in self.battle.party}
        escape = (can_escape and not story and self._music not in ("boss", "great_boar_fight")
                  and not self.gm.party.flags.get(TutorialSettings.ESCAPE_FLAG))
        if self.tutorial is None and both and (escape or self.gm.party.flags.get(TutorialSettings.LESSONS_LEFT_FLAG)):
            # A later fight: the lessons the taro patch never reached, and escape
            # (game/answers.md, Frankie 10/26).
            self.tutorial = HinaTutorial(self, later=True, escape=escape)
        # Who grumbles once swapped in, after the swap lesson.
        self._swap_complaint: str | None = None
        # A line someone says in the fight takes a box across the bottom, the
        # field's size, until it is closed with confirm (Frankie, 10/27); each
        # waits for the narration before it to finish.
        self.talk_box = TextBox()
        if opening_blow is not None:
            self._dispatch(self.battle.field_strike(opening_blow))

    def _learn_counter_at_the_boar(self) -> None:
        """Kailo learns Counter on his own at the Great Boar's start, once (Frankie, 11/10).

        He says he has been working on something; Hina, if she is along, asks
        since when. The move goes in his lowest open slot, else the bank, and
        the talk plays before the first turn.
        """
        party = self.gm.party
        flags = party.flags
        kailo = party.find(StorySettings.COUNTER_LEARNER)
        if (kailo is None or flags.get(StorySettings.COUNTER_FLAG)
                or not any(k.get("id") == StorySettings.COUNTER_BOSS for k in self._kinds)):
            return
        flags[StorySettings.COUNTER_FLAG] = True
        move = by_id("moves")[StorySettings.COUNTER_MOVE]
        kailo.loadout = learn(kailo.loadout, move, first_loadout(kailo.id, flags), open_slots(flags))
        hina = party.find("hina") is not None
        for speaker, line, needs_hina in StorySettings.COUNTER_TALK:
            if hina or not needs_hina:
                self._sayings.append((speaker, line))
        self._after_talk.append(StorySettings.COUNTER_LEARNED_LINE.format(move=move['name']))
        self._jingle_due = True
        if kailo.loadout is not None and move["id"] not in kailo.loadout:
            # No open slot: it is in the bank. Only a player who has her lesson to follow is walked through
            # slotting it, after her lines (Frankie, 11/11, 11/12). One who said they remember, or who has
            # no Hina along, gets nothing: no prompt, no lock, Counter banked like any element learned
            # with the slots full ("no tutorial is better than half of one"). The silent lock Frankie hit
            # on 11/13 was this branch forcing the slot with a bare prompt for a player who remembers.
            if hina and not flags.get(LoadoutSettings.SLOT_LESSON_FLAG):
                self._forced_slot = move["id"]
                flags[LoadoutSettings.SLOT_LESSON_FLAG] = True
                for speaker, line in LoadoutSettings.SLOT_LESSON:
                    self._after_talk.append((short_name(speaker), line.format(command=LoadoutSettings.SLOT_COMMAND)))

    def on_enter(self) -> None:
        """Play the fight's music, the boss songs if a boss is here; victory keeps its own."""
        if self.gm.audio.screen != self._won_music:
            self.gm.audio.play_screen(self._music)

    # ------------------------------------------------------------------
    # COMMAND HANDLERS
    # ------------------------------------------------------------------

    def _on_attack(self) -> None:
        """Choose the enemy to strike, then open the stroke menu.

        Mid-chain too: backing out and choosing Attack again may pick any
        living enemy, and the points left carry over (Frankie, 11/4).
        """
        standing = [c for c in self.battle.enemies if c.alive]
        if len(standing) == 1:
            # One enemy: no pointer, straight to the strokes (Frankie, 11/3, Mark's playtest).
            self._chain_target_id = standing[0].id
            self._open_stroke_menu()
            return
        self._begin_targeting({"kind": "chain"}, pool="foe")

    def _open_stroke_menu(self) -> None:
        """Open the stroke menu: three strokes, then Element.

        The strokes' labels, with their chance to land, are written each
        frame by ``_refresh_command_labels``.
        """
        items = [
            MenuItem("", lambda kind=kind: self._on_stroke(kind))
            for kind in _STROKE_KINDS
        ]
        items += [
            MenuItem("Element", self._on_open_abilities, help=BattleSettings.HELP["Element"]),
        ]
        self.stroke_menu = Menu(items=items, on_cancel=self._cancel_stroke_menu)

    def _on_stroke(self, kind: str) -> None:
        """Swing a stroke at the chosen enemy, or pick a new one if it fell."""
        target = self._stroke_target()
        if target is None:
            standing = [c for c in self.battle.enemies if c.alive]
            if len(standing) == 1:
                # One enemy left: the stroke goes to it, no pointer in between, so the
                # press meant for the stroke never lands on a target step (Frankie, 11/3,
                # Mark's playtest wasted a stroke there).
                self._chain_target_id = standing[0].id
                self._dispatch(self.battle.submit_stroke(kind, standing[0].id))
                return
            self._begin_targeting({"kind": "stroke", "stroke": kind}, pool="foe")
            return
        self._dispatch(self.battle.submit_stroke(kind, target.id))

    def _stroke_target(self) -> Any:
        """Return the living enemy the strokes go to: the one picked last, or None."""
        picked = next((c for c in self.battle.enemies
                       if c.id == self._chain_target_id and c.alive), None)
        return picked or self.battle.chain_target()

    def _cancel_stroke_menu(self) -> None:
        """Back out to the commands; Attack again opens the pointer (Frankie, 11/4)."""
        self.stroke_menu = None
        if not self.battle.chaining:
            self._chain_target_id = None

    def _on_defend(self) -> None:
        """Defend at once; it has no target."""
        self._back_to_commands()
        self._dispatch(self.battle.submit_defend())

    # ------------------------------------------------------------------
    # Skill: KAILO'S COOK
    # ------------------------------------------------------------------

    def _held_skill(self, actor: Any) -> dict[str, Any] | None:
        """The Skill ``actor`` has with the weapon type in hand, or None.

        Each character has three, one per weapon type, and only the one
        for the type held works (Frankie, 10/31). Holding nothing they can
        use, they have none.
        """
        if actor is None or actor.weapon_type is None:
            return None
        return skill_for(actor.id, actor.weapon_type)

    def _on_tech(self) -> None:
        """The signature command, the Skill of the weapon type in hand.

        Scold, Charm, Paddle and Banish pick an enemy; Call ends the turn at once;
        Cook lists the meals made at home, Pound his moves.
        """
        skill = self._held_skill(self.battle.current_actor)
        if skill is None or skill["id"] not in _SKILLS_BUILT:
            return
        if skill["id"] in ("scold", "charm", "paddle", "banish", "vault"):
            self._begin_targeting({"kind": skill["id"]}, pool="foe")
        elif skill["id"] == "wili":
            # No target to pick: the time starts, each turn of the pad is a cast at a random enemy (_run_wili, Frankie, 11/1).
            self.spin = SpinMeter(self.battle.current_actor.mana, self._ease("wili"))
        elif skill["id"] == "pound":
            self._on_open_pound()
        elif skill["id"] == "dance":
            self._on_open_dance()
        elif skill["id"] == "call_the_dead":
            if self.battle.spirit_out:
                return
            # Alternate A and B in her own rhythm; the tighter, the stronger the spirit (Frankie, 11/1).
            self._start_minigame(RhythmMeter(self._ease("call_the_dead")),
                                 lambda m: self.battle.submit_call(m.quality))
        elif skill["id"] == "moepapa":
            # One tap on the shrinking circle, drawn on the middle enemy; the curse reaches them all (Frankie, 11/1).
            standing = [c for c in self.battle.enemies if c.alive]
            if not standing:
                return
            middle = standing[len(standing) // 2].id
            self._start_minigame(TapMeter(middle, self._ease("moepapa")),
                                 lambda m: self.battle.submit_moepapa(m.share or 0.0))
        else:
            self._on_open_cook()

    def _cook_mixes(self) -> dict[str, tuple[str, ...] | None]:
        """Each meal made at the pot outside a fight, to what Cook would put in for it, None when he cannot."""
        from core.scenes.craft_scene import found, ingredients  # local: cycle.

        actor = self.battle.current_actor
        level = self.battle._mastery_level(actor)
        have = ingredients(self.gm)
        eaters = [c.id for c in self.battle.party if c.alive]
        meals = [r["id"] for r in found(self.gm) if r["id"] not in ItemSettings.INGREDIENTS]
        return {dish: cooking.battle_mix(dish, have, level, eaters) for dish in meals}

    def _on_open_cook(self) -> None:
        """List the meals made at the pot outside a fight; the player picks one (Frankie, 11/4).

        The game picks what goes in (``cooking.battle_mix``): one the bag cannot make
        is grey. Nothing on the list until a meal has been cooked at home.
        """
        mixes = self._cook_mixes()
        if not mixes:
            return
        self.list_menu = Menu(
            items=[MenuItem(ItemSettings.NAMES.get(d, d), lambda d=d, m=m: self._on_cook_chosen(d, m),
                            enabled=m is not None,
                            color=None if m is not None else ColorSettings.GRAY,
                            help=item_help(d) or None,
                            why=None if m is not None else self._cook_needs(d))
                   for d, m in mixes.items()],
            on_cancel=self._close_list_menu,
        )
        self._skill_listing = True

    def _cook_needs(self, dish: str) -> str:
        """Why a meal is grey in Cook: what its recipe needs that the bag lacks (Frankie, 11/4)."""
        recipe = next((r for r in cooking.recipes() if r["id"] == dish), None)
        if recipe is None:
            return "The bag cannot make it now."
        bag = dict(self.gm.party.inventory)
        missing = []
        for part in recipe["from"]:
            if bag.get(part, 0) > 0:
                bag[part] -= 1
            else:
                missing.append(ItemSettings.NAMES.get(part, part))
        if not missing:
            return "The bag cannot make it now."
        named = " and ".join([", ".join(missing[:-1]), missing[-1]] if len(missing) > 1 else missing)
        return f"Needs {named}."

    def _on_cook_chosen(self, dish: str, parts: tuple[str, ...]) -> None:
        """Take what goes in from the bag (below tool level 7), then stir, steady, not fast (Frankie, 11/1)."""
        self._close_list_menu()
        if self.battle._mastery_level(self.battle.current_actor) < MinigameSettings.COOK_KEEP_LEVEL:
            bag = self.gm.party.inventory
            for item in parts:
                bag[item] -= 1
                if bag[item] <= 0:
                    del bag[item]
        self._start_minigame(StirMeter(dish, self._ease("cook")),
                             lambda m: self.battle.submit_cook(dish, m.quality, parts))

    def _on_open_pound(self) -> None:
        """List the Pound moves Kailo has learned by his handwraps level (Frankie, 10/31)."""
        moves = self.battle.pound_moves(self.battle.current_actor)
        self.list_menu = Menu(
            items=[MenuItem(m["name"], lambda m=m: self._on_pound_chosen(m), help=m.get("description")) for m in moves],
            on_cancel=self._close_list_menu,
        )
        self._skill_listing = True

    def _luck_share(self, target: Any) -> float:
        """The share of Paddle's or Pound's clock a lucky enemy leaves, or the luckiest enemy standing
        for one that hits them all (Frankie, 11/1, in place of the dodge roll)."""
        if target is None:
            luck = max((c.points["evasion"] for c in self.battle.enemies if c.alive), default=0)
        else:
            luck = target.points["evasion"]
        return BattleSettings.skill_seconds(1.0, luck)

    def _on_pound_chosen(self, move: dict[str, Any]) -> None:
        """Pick the enemy, or start the buttons at once for a move that hits them all."""
        self._close_list_menu()
        if move["target"] == "all":
            self.pound = PoundMeter(move, None, ease=self._ease("pound") * self._luck_share(None))
        else:
            self._begin_targeting({"kind": "pound", "move": move}, pool="foe")

    def _on_open_dance(self) -> None:
        """List the Dance moves Hina has learned by her fan level (Frankie, 10/31)."""
        moves = self.battle.dance_moves(self.battle.current_actor)
        self.list_menu = Menu(
            items=[MenuItem(m["name"], lambda m=m: self._on_dance_chosen(m), help=m.get("description")) for m in moves],
            on_cancel=self._close_list_menu,
        )
        self._skill_listing = True

    def _on_dance_chosen(self, move: dict[str, Any]) -> None:
        """Pick the ally, or start the buttons at once for a move that reaches them all."""
        self._close_list_menu()
        if move["target"] == "all":
            # A rhythm game on four rows (Frankie, 11/1).
            self._start_dance(move, None)
        else:
            self._begin_targeting({"kind": "dance", "move": move}, pool="ally")

    def _on_open_abilities(self) -> None:
        """Open the active member's techniques as a grid (D-450).

        On top, the switch: the stance the member is in, in its element's
        colour, after the two-color recycle sign and before the member's
        element icons, the stance's boxed (Frankie, 10/26; it builds a mana, D-285).
        A on it opens a window over the name asking for the other stance.
        Under it one row per mana cost that has something in this stance,
        three slots across, greyed while the meter is short of the row.
        Revive is greyed while nobody is down. The cursor opens on the
        cheapest move, or with Memory on the last thing picked here.
        """
        actor = self.battle.current_actor
        if actor is None:
            return
        rows: list[GridRow] = []
        other = self.battle.other_stance(actor)
        self._switch_open = False
        self._switch_pair = None
        self._held_rows = None
        if other is not None:
            held = actor.stances[actor.stance]
            style = ColorSettings.ELEMENT_TEXT_STYLES.get(held["element"], {})
            self._switch_pair = (other["element"], held["element"])
            rows.append(GridRow("", [GridCell(
                held["name"],
                self._open_switch_window,
                color=style.get("color"), glow=style.get("glow"),
                glow_radius=style.get("glow_radius", 3),
                glow_alpha=style.get("glow_alpha", 90),
                tag=switch_icon(*self._switch_pair),
                after=stance_icons(actor.elements, actor.stance_element),
                help=held.get("about"),
            )]))
        rows += self._move_rows(actor)
        if not rows:
            return
        grid = GridMenu(rows, on_cancel=self._close_ability_menu)
        grid.row, grid.col = (1 if other is not None and len(rows) > 1 else 0), 0
        if config.current.cursor == "Memory":
            picked = config.current.element_cursors.get(actor.id)
            for r, row in enumerate(rows):
                for c, cell in enumerate(row.cells):
                    if cell is not None and picked == (cell.data["id"] if cell.data is not None else _SWITCH):
                        grid.row, grid.col = r, c
        self.ability_menu = grid

    def _remember_element(self, picked: str) -> None:
        """Note the move (or the switch) the one acting picked from the grid, for Memory."""
        actor = self.battle.current_actor
        if actor is not None:
            config.current.element_cursors[actor.id] = picked

    def _open_switch_window(self) -> None:
        """A on the switch: the window over the stance's name, asking for the other one."""
        self._switch_open = True
        self._preview_stance(True)

    def _preview_stance(self, on: bool) -> None:
        """While the window flashes, the moves below are the other stance's; B puts them back (Frankie, 10/26)."""
        actor = self.battle.current_actor
        grid = self.ability_menu
        if actor is None or grid is None or self._switch_pair is None:
            return
        if on:
            self._held_rows = grid.rows[1:]
            grid.rows[1:] = self._move_rows(actor, 1 - actor.stance)
        elif self._held_rows is not None:
            grid.rows[1:] = self._held_rows
            self._held_rows = None

    def _move_rows(self, actor: Combatant, stance: int | None = None) -> list[GridRow]:
        """One grid row per mana cost with something in the stance (the one held, or ``stance``).

        Three slots across, each move in its element's colour, greyed
        while the meter is short of it; Revive greyed while nobody is down.
        """
        from systems.loadout import open_slots  # local, as the slot check below

        rows: list[GridRow] = []
        moves = self.battle.moves_for(actor, stance)
        party = self.gm.party
        slots = open_slots(party.flags if party is not None else None)
        for row in range(1, LoadoutSettings.ROWS + 1):
            here = [m for m in moves if self.battle.row_of(actor, m) == row]
            # A dash only for a slot that is open and empty (Frankie, 11/5): not for a locked
            # slot, nor for one holding the other stance's move.
            empty = 0
            if actor.loadout is not None:
                taken = sum(1 for r in actor.loadout.values() if r == row)
                empty = max(0, slots[row - 1] - taken)
            if not here and not empty:
                continue
            cells: list[GridCell | None] = []
            for move in here:
                style = ColorSettings.ELEMENT_TEXT_STYLES.get(move["element"], {})
                cells.append(GridCell(
                    short_move_name(move),
                    lambda move=move: self._on_ability_chosen(move),
                    # A raising element can be aimed at an enemy too (Frankie, 11/3), so it is never greyed for want of the fallen.
                    enabled=self.battle.can_afford(actor, move),
                    why=None if self.battle.can_afford(actor, move)
                    else f"Needs {row} mana.",
                    color=style.get("color"), glow=style.get("glow"),
                    glow_radius=style.get("glow_radius", 3),
                    glow_alpha=style.get("glow_alpha", 90),
                    gradient=self._name_gradient(actor, move),
                    data=move,
                    # Its sentence and its number in this row, the burn chance too, as on the Element screen (Frankie, 11/4).
                    help=" ".join(help_lines(move, row, actor.points)) or None,
                ))
            cells += [None] * min(empty, LoadoutSettings.PER_ROW - len(cells))
            rows.append(GridRow(
                str(row), cells,
                BattleStageSettings.COLOR_MANA if actor.mana >= row else ColorSettings.GRAY,
            ))
        return rows

    def _on_stance_chosen(self) -> None:
        """Switch stance; it ends the turn."""
        self._remember_element(_SWITCH)
        self._switch_open = False
        self.ability_menu = None
        self._dispatch(self.battle.submit_stance())

    def _on_ability_chosen(self, move: dict[str, Any]) -> None:
        """Use a move with no target at once; otherwise choose a target."""
        self._remember_element(move["id"])
        self.ability_menu = None
        if move["target"] == "none":
            self._dispatch(self.battle.submit_move(move["id"]))
            return
        # Any element can aim at either side (Frankie, 11/3): its own side first, then the other.
        self._begin_targeting(
            {"kind": "move", "move_id": move["id"]}, pool=move["target"], either=True
        )

    def _close_ability_menu(self) -> None:
        """Back out of the ability submenu to the command menu."""
        self._switch_open = False
        self.ability_menu = None

    def _actor_member(self):
        """The ``PartyMember`` whose turn it is, whose battle bag the Item command lists (Frankie, 11/12)."""
        actor = self.battle.current_actor
        return self.gm.party.find(actor.id) if actor is not None else None

    def _bag_counts(self) -> dict[str, int]:
        """What the acting member's battle bag holds, each item with its count."""
        member = self._actor_member()
        return battle_bag.counts(member) if member is not None else {}

    def _sync_noni(self) -> None:
        """Make the engine's Noni count the acting member's own (Frankie, 11/12: items are per bag)."""
        self.battle.noni = self._bag_counts().get("noni", 0)

    def _spend_item(self, item_id: str) -> None:
        """Use up one of ``item_id`` from the acting member's battle bag, emptying that slot."""
        member = self._actor_member()
        if member is not None:
            battle_bag.spend(member, item_id)

    def _on_open_items(self) -> None:
        """Open the item submenu: only the acting member's own battle bag (Frankie, 11/12).

        Two Noni Pulu are one row, "Noni x2": the same list as before, from the bag's counts.
        """
        items = []
        held = self._bag_counts()
        self._sync_noni()
        if held.get("noni", 0) > 0:
            items.append(MenuItem(f"Noni x{held['noni']}", self._on_noni_chosen, help=item_help("noni")))
        for item_id in ItemSettings.HEALS:
            count = held.get(item_id, 0)
            if item_id != "noni" and count > 0:
                items.append(MenuItem(f"{ItemSettings.NAMES[item_id]} x{count}",
                                      lambda item_id=item_id: self._on_dish_chosen(item_id),
                                      help=item_help(item_id) or None))
        for item_id in ItemSettings.CURES:
            count = held.get(item_id, 0)
            if count > 0:
                items.append(MenuItem(f"{ItemSettings.NAMES[item_id]} x{count}",
                                      lambda item_id=item_id: self._on_cure_chosen(item_id),
                                      help=item_help(item_id) or None))
        for item_id in ItemSettings.REVIVES:
            count = held.get(item_id, 0)
            # Usable on a fallen ally or on any enemy (Frankie, 11/3), so it shows whenever it is in the bag.
            if count > 0:
                items.append(MenuItem(f"{ItemSettings.NAMES[item_id]} x{count}",
                                      lambda item_id=item_id: self._on_revive_chosen(item_id),
                                      help=item_help(item_id) or None))
        shells = held.get(ItemSettings.SEER_SHELL, 0)
        if shells > 0:
            items.append(MenuItem(f"Seer's Shell x{shells}", self._on_seer_shell_chosen,
                                  help=item_help(ItemSettings.SEER_SHELL) or None))
        bombs = held.get(ItemSettings.SMOKE_BOMB, 0)
        if bombs > 0:
            # Only where Escape is allowed (Frankie, 11/12): no running from a boss or a story fight.
            items.append(MenuItem(f"Smoke Bomb x{bombs}", self._on_smoke_bomb_chosen,
                                  enabled=self.can_escape, why="No running from this one.",
                                  help=item_help(ItemSettings.SMOKE_BOMB) or None))
        if not items:
            return
        self.item_menu = Menu(items=items, on_cancel=self._close_item_menu)

    def _on_dish_chosen(self, item_id: str) -> None:
        """Start choosing who gets the dish from the bag."""
        self.item_menu = None
        self._begin_targeting({"kind": "dish", "item": item_id}, pool="ally_or_foe")

    def _on_cure_chosen(self, item_id: str) -> None:
        """Start choosing who gets the plant that cures."""
        self.item_menu = None
        self._begin_targeting({"kind": "cure", "item": item_id}, pool="ally_or_foe")

    def _on_revive_chosen(self, item_id: str) -> None:
        """Start choosing which fallen ally gets the item that raises them."""
        self.item_menu = None
        self._begin_targeting({"kind": "revive", "item": item_id}, pool="fallen_or_foe")

    def _on_seer_shell_chosen(self) -> None:
        """Start choosing which enemy to look at through the shell."""
        self.item_menu = None
        self._begin_targeting({"kind": "seer_shell"}, pool="foe")

    def _on_smoke_bomb_chosen(self) -> None:
        """Throw a Smoke Bomb: the one acting gets away at once, with no target to pick."""
        self.item_menu = None
        self._back_to_commands()
        self._spend_item(ItemSettings.SMOKE_BOMB)
        self._dispatch(self.battle.submit_smoke_bomb())

    def _on_noni_chosen(self) -> None:
        """Start choosing who gets the Noni."""
        self.item_menu = None
        self._begin_targeting({"kind": "noni"}, pool="ally_or_foe")

    def _close_item_menu(self) -> None:
        """Back out of the item submenu to the command menu."""
        self.item_menu = None

    # ------------------------------------------------------------------
    # THE SIDE PAGES (D-455)
    # ------------------------------------------------------------------

    def _turn_page(self, step: int) -> bool:
        """Turn to the page left (-1) or right (+1) of this one, if there is one."""
        page = self._page + step
        if page not in (-1, 0, 1):
            return False
        self._page = page
        self.side_menu = None
        if page == -1:
            self.side_menu = Menu(items=[
                MenuItem("Equip", self._on_open_equip,
                         enabled=bool(self._spare_weapons()) or self._can_slot(),
                         why="Nothing to change."),
                MenuItem("Defend", self._on_defend),
                MenuItem("Escape", self._on_escape, enabled=self.can_escape,
                         why="No running from this one."),
            ], on_cancel=self._back_to_commands)
        elif page == 1:
            items = []
            actor = self.battle.current_actor
            if self.battle.combos_for(actor):
                items.append(MenuItem("Combo", self._on_open_combos))
            else:
                # Always shown, grey when none is open (Frankie, 11/4).
                items.append(MenuItem("Combo", lambda: None, enabled=False,
                                      why=("These two have no Combo."
                                           if self.battle.partner_without_combo(actor) is not None
                                           else "No partner for a Combo.")))
            bench = any(c.alive for c in self.battle.bench)
            items.append(MenuItem(
                "Swap", self._on_open_swap,
                # No swapping once a stroke is swung (D-578).
                enabled=(bench and not self.battle.chaining and actor.id != self._swap_locked),
                why=("Nobody is waiting to swap in." if not bench
                     else "Not after a stroke." if self.battle.chaining else "Not again until the next turn."),
            ))
            self.side_menu = Menu(items=items, on_cancel=self._back_to_commands)
        return True

    def _back_to_commands(self) -> None:
        """Back to the page of four commands."""
        self._page = 0
        self.side_menu = None

    def _spare_weapons(self) -> list[dict[str, Any]]:
        """Return the weapons the one acting could take up instead of their own.

        Only what the party carries that they can use, the Equip screen's
        pool (Frankie, 10/24; it was every weapon of their types, the
        browser's Free Battle list).
        """
        from core.scenes.equip_scene import candidates

        actor = self.battle.current_actor
        member = self.gm.party.find(actor.id) if actor is not None and self.gm.party else None
        if member is None:
            return []
        weapons = by_id("weapons")
        return [weapons[w] for w in candidates(self.gm.party, member, "weapon") if w != member.weapon]

    def _can_slot(self) -> bool:
        """Return True when the one acting may move an element now: never once a stroke is swung."""
        return bool(self._slot_choices()) and not self.battle.chaining

    def _on_open_equip(self) -> None:
        """Equip's two choices (Frankie, 11/11): Weapon, the swap from the bag, and Element, the move
        of one element; each ends the turn and builds 1 mana."""
        self.list_menu = Menu(
            items=[
                MenuItem("Weapon", self._on_open_weapons, enabled=bool(self._spare_weapons()),
                         why="No other weapon in the bag.", help=BattleSettings.HELP["Equip Weapon"]),
                MenuItem(LoadoutSettings.SLOT_COMMAND, self._on_open_slot, enabled=self._can_slot(),
                         why="Not after a stroke." if self.battle.chaining else "Nothing to move.",
                         help=BattleSettings.HELP["Equip Element"]),
            ],
            on_cancel=self._close_list_menu,
        )
        self.list_menu.cursor = next((k for k, item in enumerate(self.list_menu.items) if item.enabled), 0)

    def _on_open_weapons(self) -> None:
        """List the weapons to change to, each with its icon."""
        self.list_menu = Menu(
            items=[
                MenuItem(w["name"], lambda w=w: self._on_weapon_chosen(w), tag=item_icon(w["id"]),
                         help=item_help(w["id"]) or None)
                for w in self._spare_weapons()
            ],
            on_cancel=self._on_open_equip,
        )

    def _on_weapon_chosen(self, weapon: dict[str, Any]) -> None:
        """Change weapons: the new one from the bag, the old one into it. It ends the turn."""
        from core.equipment import weapon_multipliers
        from core.scenes.equip_scene import put_on

        self._close_list_menu()
        self._back_to_commands()
        member = self.gm.party.find(self.battle.current_actor.id)
        put_on(self.gm.party, member, "weapon", weapon["id"])
        self._dispatch(self.battle.submit_weapon(
            weapon["name"], weapon_multipliers(weapon["id"]), mastery.type_held(member.id, weapon["id"])))

    def _on_escape(self) -> None:
        """Try to run."""
        self._back_to_commands()
        # Alternate L and R in a steady rhythm; Speed is the ease, the steadier the likelier (Frankie, 11/4).
        self._start_minigame(EscapeMeter(self.battle.escape_ease()),
                             lambda m: self.battle.submit_escape(m.quality))

    def _on_open_combos(self) -> None:
        """List the Team Ups open now (Frankie, 11/1: once "combos"): each name, then its two
        element icons, and beside the list the two partners' mana (Frankie's drawing, 11/4)."""
        actor = self.battle.current_actor
        items = []
        for combo, partner in self.battle.combos_for(actor):
            items.append(MenuItem(
                combo["name"], lambda combo=combo, partner=partner: self._on_combo_chosen(combo, partner),
                enabled=self.battle.can_pay_combo(actor, partner),
                after=pair_icons(combo["elements"]),
                help=combo.get("description"),
                help_icon=pair_icons(combo["elements"]),
            ))
        self.list_menu = Menu(items=items, on_cancel=self._close_list_menu)
        self._team_up_partners = [partner for _, partner in self.battle.combos_for(actor)]
        self._team_up_listing = True

    def _on_combo_chosen(self, combo: dict[str, Any], partner: Combatant) -> None:
        """Strike at once if the combo hits everyone; otherwise choose the enemy."""
        self._close_list_menu()
        if combo["id"] == "light_wave":
            # Light Wave, two games in a row (Frankie, 11/4): the seals call the light, the stir spreads the water.
            self._back_to_commands()
            self._start_light_wave(partner.id)
            return
        if combo["id"] == "spring_rain":
            # Spring Rain, two games in a row (Frankie, 11/4): the dance calls the rain, the stir spreads it.
            self._back_to_commands()
            self._start_spring_rain(partner.id)
            return
        if combo["target"] == "none":
            self._back_to_commands()
            self._dispatch(self.battle.submit_combo(combo["id"], partner.id))
            return
        self._begin_targeting(
            {"kind": "combo", "combo_id": combo["id"], "partner_id": partner.id},
            pool="foe",
        )

    # ------------------------------------------------------------------
    # SLOTTING AN ELEMENT IN A FIGHT (Frankie, 11/11)
    # ------------------------------------------------------------------

    def _banked_elements(self, actor: Combatant | None = None) -> list[dict[str, Any]]:
        """Return the elements the one acting knows that sit in the bank, not in a slot."""
        actor = actor or self.battle.current_actor
        member = self.gm.party.find(actor.id) if actor is not None and self.gm.party else None
        if member is None or actor.loadout is None:
            return []
        return [m for m in known_moves(member.id, member.elements, self.gm.party.flags)
                if m["id"] not in actor.loadout]

    def _slot_choices(self) -> list[dict[str, Any]]:
        """Return the elements one swap can move: the bank's and the slotted ones (not a character's own move).

        The bank works like a tier with room for all (Frankie, 11/11), so a slotted one can always go there.
        """
        actor = self.battle.current_actor
        if actor is None or actor.loadout is None:
            return []
        slotted = [self.moves[mid] for mid in actor.loadout if mid in self.moves and not self.moves[mid].get("signature")]
        return self._banked_elements() + slotted

    def _name_gradient(self, actor: Combatant, move: dict[str, Any]) -> tuple[str, str | None] | None:
        """A two-element move's pair of elements, for its name's gradient (Frankie, 11/13); None for one element."""
        member = self.gm.party.find(actor.id) if self.gm.party else None
        pair = tag_elements(move, member.elements if member is not None else actor.elements)
        return pair if pair[1] is not None else None

    def _on_open_slot(self) -> None:
        """Equip, Element: straight to the one screen of every tier and the bank (Frankie, 11/12)."""
        actor = self.battle.current_actor
        member = self.gm.party.find(actor.id)
        known = known_moves(member.id, member.elements, self.gm.party.flags)
        forced = self._forced_slot if self._guiding_slot() else None
        self._swap = ElementSwap(known, actor.loadout, open_slots(self.gm.party.flags), member.elements,
                                 mana=actor.mana, start=forced, forced=forced)
        self.list_menu = None

    def _handle_swap(self, event: pygame.event.Event) -> None:
        """The swap screen's buttons: the cursor, A to pick up or put down, B to put back or leave."""
        swap = self._swap
        if swap.handle(event):
            self.gm.audio.play("menu_move")
            return
        if input_map.is_confirm(event):
            result = swap.confirm()
        elif input_map.is_cancel(event):
            result = swap.cancel()
        else:
            return
        if result.kind == "left":
            self._swap = None
            self._on_open_equip()
            self.gm.audio.play("menu_move")
        elif result.kind == "cant":
            self.gm.audio.play("cant")
        elif result.kind == "moved":
            self._slot_done(result)
        else:
            self.gm.audio.play("menu_select" if result.kind == "picked" else "menu_move")

    def _slot_done(self, result: Any) -> None:
        """One change was made: the one acting takes it, the turn ends, 1 mana is built."""
        actor = self.battle.current_actor
        self._forced_slot = None
        self._swap = None
        self.gm.party.find(actor.id).loadout = dict(result.loadout)
        self._back_to_commands()
        self._dispatch(self.battle.submit_slot(result.loadout, result.move["name"], banked=result.banked))

    # Counter in the bank at the Great Boar: on Kailo's first turn the player walks the path Hina names
    # with their own hands, Equip, Element, Counter, a slot, the rest of the menu out of reach, the way
    # the taro patch's lessons hold the cursor (Frankie, 11/12; it was the rows opened for them, 11/11).
    # It is a swap like any other, so it ends his turn.

    def _guiding_slot(self) -> bool:
        """Return True while Kailo must slot Counter now and the player is picking."""
        actor = self.battle.current_actor
        return (self._forced_slot is not None and actor is not None
                and actor.id == StorySettings.COUNTER_LEARNER and not self._battle_finished
                and self._can_command() and self.talk_box.is_done())

    def _slot_guide_step(self) -> tuple[str, int]:
        """Where the path points now: the page left of the commands, Equip's list, then the two presses on the screen."""
        if self._swap is not None:
            return ("pick", 0) if self._swap.held is None else ("place", 0)
        if self.list_menu is not None:
            labels = [item.label for item in self.list_menu.items]
            return "list", labels.index(LoadoutSettings.SLOT_COMMAND) if LoadoutSettings.SLOT_COMMAND in labels else 0
        if self._page == -1 and self.side_menu is not None:
            return "side", next(k for k, item in enumerate(self.side_menu.items) if item.label == "Equip")
        return "page_left", 0

    def _hold_slot_cursor(self) -> None:
        """Keep the cursor on the next step of the path."""
        kind, row = self._slot_guide_step()
        if kind == "pick":
            self._swap.go_to(self._forced_slot)
        elif kind == "place" and self._swap.rows[self._swap.row].tier is None:
            self._swap.row, self._swap.col = 0, 0    # off the bank, onto tier 1's first slot
        elif kind == "side":
            self.side_menu.cursor = row
        elif kind == "list":
            self.list_menu.cursor = row
        elif kind == "page_left" and self._page != 0:
            self._back_to_commands()

    def _guide_slot_event(self, event: pygame.event.Event) -> bool:
        """Block every press off the path; True when ``event`` is used up here."""
        if not self._guiding_slot():
            return False
        kind, _ = self._slot_guide_step()
        if kind == "pick":
            # The cursor sits on Counter in the bank; only A moves on.
            self._hold_slot_cursor()
            return not input_map.is_confirm(event)
        if kind == "place":
            # Any tier slot will do; there is no backing out, and the bank is not the answer.
            if input_map.is_confirm(event):
                return self._swap.rows[self._swap.row].tier is None or self._swap.under == self._forced_slot
            return input_map.is_cancel(event)
        if kind == "page_left":
            return not input_map.is_left(event)
        self._hold_slot_cursor()
        return not input_map.is_confirm(event)

    def _slot_guide_light(self, surface: pygame.Surface) -> pygame.Rect:
        """The one area left bright while the path is walked."""
        kind, row = self._slot_guide_step()
        if kind == "pick":
            cell = self._swap.cell_rect(self._forced_slot, self._hud_rect(surface).top)
            return cell.inflate(6, 6) if cell is not None else self._hud_rect(surface)
        if kind == "place":
            return self._hud_rect(surface)
        if kind == "side":
            return self._menu_row_rect(self.side_menu, row, surface)
        if kind == "list":
            return self._menu_row_rect(self.list_menu, row, surface)
        return self._command_rect(surface)

    def _on_open_swap(self) -> None:
        """List who waits on the bench."""
        self.list_menu = Menu(
            items=[
                MenuItem(short_name(c.id), lambda c=c: self._on_swap_chosen(c.id), enabled=c.alive)
                for c in self.battle.bench
            ],
            on_cancel=self._close_list_menu,
        )

    def _on_swap_chosen(self, bench_id: str) -> None:
        """Bring the bench member in; the turn is theirs."""
        self._close_list_menu()
        self._back_to_commands()
        self._dispatch(self.battle.submit_swap(bench_id))

    def _close_list_menu(self) -> None:
        """Back out of the Equip, Team Up, Swap, Cook or Pound list to its page."""
        self.list_menu = None
        self._team_up_listing = False
        self._skill_listing = False

    def _dispatch(self, events: list[Any]) -> None:
        """Queue the battle's events to be played back one at a time."""
        self._events.extend(events)
        self.stage.hold_icons(events)
        if self.tutorial is not None:
            self.tutorial.saw(events)
        # A member acting in a stance unlocks its art's Lore page (Frankie, 10/23).
        members = {c.id: c for c in self.battle.party + self.battle.bench}
        for ev in events:
            who = ev.attacker_id if isinstance(ev, StrokeEvent) else ev.user_id if isinstance(ev, AbilityUsedEvent) else None
            if who in members and members[who].stances:
                lore.unlock(self.gm.party, "stance " + members[who].stances[members[who].stance]["name"])
        self._teach_cast(events)
        if not self.battle.is_awaiting_command():
            # The turn is over: the next one opens on the commands.
            self.stroke_menu = None
            self.ability_menu = None
            self.list_menu = None
            self._swap = None
            self._back_to_commands()
            self._chain_target_id = None
        if any(isinstance(ev, BattleEndedEvent) for ev in events):
            self._sync_party_state_back()

    def _sync_party_state_back(self) -> None:
        """Write battle-mutated state back onto the persistent ``Party``.

        Called once, when the battle produces its ``BattleEndedEvent``.
        Pushes each party combatant's HP back onto the matching
        ``PartyMember`` so damage carries into the overworld and the
        next save, and writes the Noni left back onto
        ``Party.inventory``.

        A lost fight is the exception: the party walks away at full
        HP, so a lost story fight can be fought again, and the lost
        taro patch goes on with the game rested, Melia having driven
        the boars off (Frankie, 10/26). Any other lost fight is game
        over, which throws all of this away.
        """
        lost = self.battle.outcome == "defeat"
        won = self.battle.outcome == "victory"
        fighters: list[Fighter] = []
        for combatant in self.battle.party + self.battle.bench + self.battle.escaped:
            member = self.gm.party.find(combatant.id)
            if member is None:
                continue
            # What grew in the fight stays grown (D-498), so the member's
            # stats, max HP included, are worked out again first.
            member.growth = dict(combatant.growth)
            member.meters = dict(combatant.meters)
            member.mastery = dict(combatant.mastery)
            member.refresh_stats()
            # The stance is whatever was last set, a fight's switch included;
            # there is no default (Frankie, 10/28).
            if combatant.stances:
                member.stance = combatant.stance
            # The fight's max HP follows the stance (D-365); the share of
            # it is what carries back out.
            share = combatant.hp / max(1, combatant.max_hp)
            member.current_hp = (
                member.max_hp if lost
                else max(0, min(round(share * member.max_hp), member.max_hp))
            )
            if won and combatant in self.battle.party:
                fighters.append(self._fighter(member, combatant))
        # Noni used came out of the acting member's battle bag at the time (Frankie, 11/12).
        # What a scolded monster gave away is the party's, won or lost.
        for item in self.battle.gifts:
            self.gm.party.inventory[item] = self.gm.party.inventory.get(item, 0) + 1
        if won:
            party = self.gm.party
            pule = party.pule
            items = self._collect_drops()
            # Hina's and Kailo's party passives (systems/passives.py).
            lines = after_victory(party)
            # A weapon type that rose a level (Frankie, 10/30): one short line each.
            for combatant in self.battle.party + self.battle.bench + self.battle.escaped:
                for type_id, level in combatant.mastery_ups.items():
                    lines.append((None, f"{short_name(combatant.id)}: {mastery.type_name(type_id)} mastery Lv {level}!"))
            # A fight won with nobody left standing (a last blow that cost the
            # striker too): the first gets up with 1 HP, so the map is never
            # walked by a party all knocked out.
            if all(m.current_hp <= 0 for m in party.members):
                party.members[0].current_hp = 1
                lines.append((None, f"{short_name(party.members[0].id)} gets back up."))
            for fighter in fighters:
                fighter.hp_after = stance_numbers(party.find(fighter.member_id))[1]
            self.victory = VictoryReport(
                fighters=fighters, items=items, pule=(pule, party.pule),
                kupang=(party.kupang, party.kupang), lines=lines,
            )
        # A weapon changed in the fight stays changed (D-462).
        by_name = {w["name"]: w["id"] for w in by_id("weapons").values()}
        for combatant in self.battle.party + self.battle.bench + self.battle.escaped:
            member = self.gm.party.find(combatant.id)
            if member is not None and combatant.weapon in by_name:
                member.weapon = by_name[combatant.weapon]
        # A swap in the fight carries over: whoever ended it fighting
        # stays in the first three.
        order = [c.id for c in self.battle.lineup + self.battle.bench]
        self.gm.party.members.sort(
            key=lambda m: order.index(m.id) if m.id in order else len(order)
        )
        # Every monster beaten gets its bestiary page (D-458).
        from core.scenes.bestiary_scene import beaten_flag, record_sightings  # local: cycle.
        from systems.loadout import open_slots

        slots_before = open_slots(self.gm.party.flags)
        # What each showed is seen for good: the elements it cast and the stances it stood in (Frankie, 11/15).
        for enemy in self.battle.enemies:
            record_sightings(self.gm.party.flags, enemy.kind, enemy.casts, enemy.stances_seen)
        for enemy in self.battle.enemies:
            if not enemy.alive and not enemy.gone:
                self.gm.party.flags[beaten_flag(enemy.name)] = True
        if won and self._win_flag:
            self.gm.party.flags[self._win_flag] = True
        # A boss beaten opens one more element slot for the whole party (Frankie, 11/1).
        slots_after = open_slots(self.gm.party.flags)
        if self.victory is not None and slots_after != slots_before:
            self.victory.opened = (slots_after, [now - was for was, now in zip(slots_before, slots_after)])
        # And counts toward a hunters' lodge bounty, if one is taken (Frankie, 10/26).
        if self.battle.outcome == "victory":
            from systems import records  # local: a battle won is counted for the Records screen (Frankie, 11/13).

            records.win_battle(self.gm.party)
            for board in self.gm.data.load("bounties").values():
                # A taken hunt whose boss just fell says so on the victory screen, so the player never forgets it (Frankie, 10/28).
                told = bounties.record(self.gm.party, board)
                if told and self.victory is not None:
                    self.victory.lines.append((None, told))

    def _collect_drops(self) -> dict[str, int]:
        """Add what the monsters left to the party; return the items, for the victory screen."""
        # Only an element a beaten monster had slotted and cast can drop (Frankie, 11/15).
        casts = [(c.casts & set(c.loadout or ())) if not c.alive and not c.gone else set()
                 for c in self.battle.enemies]
        who = loot.owners(self.gm.party.flags, [m.id for m in self.gm.party.members])
        pule, items = roll_drops(self._kinds, burning=[c.died_burning for c in self.battle.enemies], casts=casts, who=who)
        self.gm.party.pule += pule
        for item_id, count in items.items():
            self.gm.party.inventory[item_id] = self.gm.party.inventory.get(item_id, 0) + count
        return items

    @staticmethod
    def _fighter(member: "PartyMember", combatant: Combatant) -> Fighter:
        """One who fought, for the victory screen: their stats before what grew in the fight, and after.

        Both in the stance they start a fight in, as the field menu shows them.
        """
        after, hp, top = stance_numbers(member)
        grown = dict(combatant.grown)
        kept = member.growth
        member.growth = {key: points - grown.get(key, 0) for key, points in kept.items()}
        try:
            before = stance_numbers(member)[0]
        finally:
            member.growth = kept
        return Fighter(member.id, before, after, hp, top, hp, grown)

    # ------------------------------------------------------------------
    # TARGETING
    # ------------------------------------------------------------------

    def _begin_targeting(self, pending: dict[str, Any], pool: str, either: bool = False) -> None:
        """Enter target selection over the living foes or allies, or the fallen ones.

        With ``either`` the other side's living follow (Frankie, 11/3: elements aim at either side).
        """
        side = self.battle.enemies if pool == "foe" else self.battle.party
        # Items can be used on enemies too (Frankie, 11/3): the allies first, then the living foes.
        foes = [c for c in self.battle.enemies if c.alive] if pool.endswith("_or_foe") or (
            either and pool != "foe") else []
        if either and pool == "foe":
            foes = [c for c in self.battle.party if c.alive and not c.aloft]
        if pool in ("fallen", "fallen_or_foe"):
            candidates = [c for c in side if not c.alive] + foes
        elif pool == "other":
            # Another ally, not the one acting (Nectar).
            actor = self.battle.current_actor
            candidates = [c for c in side if c.alive and not c.aloft and c is not actor]
        else:
            # Maika up on his Vault cannot be picked (Frankie, 11/2).
            candidates = [c for c in side if c.alive and not c.aloft] + foes
        if not candidates:
            return
        self._pending_command = pending
        self._target_pool = candidates
        # Every pointer starts at the top, a heal's too: the game does not choose for
        # the player (Frankie, 11/3; a heal's went to the first one hurt).
        self._target_cursor = 0

    def _on_target_confirmed(self) -> None:
        """Submit the pending command against the highlighted target."""
        if not self._pending_command or not self._target_pool:
            return
        target = self._target_pool[self._target_cursor]
        cmd = self._pending_command
        said: list[tuple[str, str]] = []
        if cmd["kind"] == "dish" and target.is_party:
            outcome, said = diet.respond(target.id, cmd["item"], [c.id for c in self.battle.party if c.alive])
            if outcome == "refuse":
                # They will not eat it (Frankie, 11/2): they say so, nothing is spent, pick again.
                self.gm.audio.play("cant")
                for speaker, line in said:
                    self._say(short_name(speaker), line)
                return
        self._clear_targeting()
        for speaker, line in said:
            self._say(short_name(speaker), line)
        if cmd["kind"] == "chain":
            self._chain_target_id = target.id
            self._open_stroke_menu()
        elif cmd["kind"] == "stroke":
            self._chain_target_id = target.id
            self._dispatch(self.battle.submit_stroke(cmd["stroke"], target.id))
        elif cmd["kind"] == "move":
            # A move that takes from an enemy and gives to someone (Drain,
            # Osmose, Borrowed Life) asks for the second one next.
            give_to = self.battle.move(cmd["move_id"]).get("give_to")
            if give_to and "from_id" not in cmd:
                self._begin_targeting({**cmd, "from_id": target.id}, pool=give_to)
                if self._pending_command is not None:
                    return
                self._dispatch(self.battle.submit_move(cmd["move_id"], target.id))
                return
            if "from_id" in cmd:
                self._dispatch(self.battle.submit_move(cmd["move_id"], cmd["from_id"], target.id))
            else:
                self._dispatch(self.battle.submit_move(cmd["move_id"], target.id))
        elif cmd["kind"] == "noni":
            self._sync_noni()
            self._spend_item("noni")   # the engine counts one down and reports the rest (Frankie, 11/12)
            self._dispatch(self.battle.submit_noni(target.id))
        elif cmd["kind"] == "dish":
            self._spend_item(cmd["item"])
            if target.is_party and diet.sickens(target.id, cmd["item"]):
                self._dispatch(self.battle.submit_bag_sick(ItemSettings.NAMES[cmd["item"]], target.id, _food(cmd["item"])))
                return
            self._dispatch(self.battle.submit_bag_heal(
                ItemSettings.NAMES[cmd["item"]], ItemSettings.HEALS[cmd["item"]], target.id, _food(cmd["item"])))
        elif cmd["kind"] == "cure":
            self._spend_item(cmd["item"])
            self._dispatch(self.battle.submit_bag_cure(
                ItemSettings.NAMES[cmd["item"]], ItemSettings.CURES[cmd["item"]], target.id, _food(cmd["item"])))
        elif cmd["kind"] == "revive":
            self._spend_item(cmd["item"])
            self._dispatch(self.battle.submit_bag_revive(
                ItemSettings.NAMES[cmd["item"]], ItemSettings.REVIVES[cmd["item"]], target.id, _food(cmd["item"])))
        elif cmd["kind"] == "scold":
            # Mash A; the presses for the full sulk come from Willpower against the monster's (Frankie, 11/1).
            needed = max(MinigameSettings.SCOLD_PRESSES_LEAST, min(MinigameSettings.SCOLD_PRESSES_MOST, round(
                MinigameSettings.SCOLD_PRESSES / self._ease("scold", target.id))))
            self.gm.audio.play("scold_nag")
            self._start_minigame(
                PaddleMeter(target.id, seconds=MinigameSettings.SCOLD_SECONDS, most=2 * needed,
                            label="Scold!", needed=needed, done_label="Told off!"),
                lambda m, t=target.id, n=needed: self.battle.submit_scold(t, m.presses, n))
        elif cmd["kind"] == "charm":
            # Simon on A, B, X and Y; every round right charms longer (Frankie, 11/1).
            self._start_minigame(SimonMeter(target.id, self._ease("charm", target.id), play=self.gm.audio.play),
                                 lambda m, t=target.id: self.battle.submit_charm(t, m.rounds))
        elif cmd["kind"] == "vault":
            # Banish's circles, one try: held too long, he misses (Frankie, 11/1).
            self._start_minigame(
                BanishMeter(target.id, self._ease("vault", target.id), seconds=MinigameSettings.VAULT_SECONDS,
                            draw_seconds=MinigameSettings.VAULT_DRAW_SECONDS, one_shot=True),
                lambda m, t=target.id: self.battle.submit_vault(t, 0.0 if m.failed else (m.share or 0.0)))
        elif cmd["kind"] == "paddle":
            # The clock starts; each A until it runs out is a hit (_run_paddle). Strength sets the time and
            # a lucky enemy takes some off (both Frankie, 11/1).
            self.paddle = PaddleMeter(target.id, seconds=BattleSettings.PADDLE_SECONDS
                                      * self._ease("paddle", target.id) * self._luck_share(target))
        elif cmd["kind"] == "banish":
            # The time starts; hold A to draw, let go to shoot (_run_banish, Frankie, 10/31).
            # Intelligence against the monster's sets how fast the circle shrinks (Frankie, 11/1).
            self.banish = BanishMeter(target.id, self._ease("banish", target.id))
        elif cmd["kind"] == "pound":
            # The clock starts; the buttons are pressed against it (_run_pound).
            self.pound = PoundMeter(cmd["move"], target.id,
                                    ease=self._ease("pound", target.id) * self._luck_share(target))
        elif cmd["kind"] == "dance":
            # Hina's Dance, a rhythm game on four rows (Frankie, 11/1).
            self._start_dance(cmd["move"], target.id)
        elif cmd["kind"] == "seer_shell":
            self._spend_item(ItemSettings.SEER_SHELL)
            self._dispatch(self.battle.submit_seer_shell(target.id))
        elif cmd["kind"] == "combo" and cmd["combo_id"] == "vine_whip":
            # Pōhuehue, two games in a row (Frankie, 11/3): the dance grows the vine, the spin cracks it.
            self._back_to_commands()
            self._start_pohuehue(cmd["partner_id"], target.id)
        elif cmd["kind"] == "combo" and cmd["combo_id"] == "solar_fist":
            # Tinju Surya, two games in a row (Frankie, 11/3): the seals light the fist, the tap throws it.
            self._back_to_commands()
            self._start_tinju_surya(cmd["partner_id"], target.id)
        elif cmd["kind"] == "combo":
            self._back_to_commands()
            self._dispatch(self.battle.submit_combo(
                cmd["combo_id"], cmd["partner_id"], target.id
            ))

    def _cancel_targeting(self) -> None:
        """Leave target selection and reopen the menu it came from."""
        cmd = self._pending_command
        self._clear_targeting()
        if cmd is None:
            return
        if cmd["kind"] == "move":
            self._on_open_abilities()
        elif cmd["kind"] in ("noni", "seer_shell", "dish", "cure"):
            self._on_open_items()
        elif cmd["kind"] == "combo":
            self._on_open_combos()

    def _clear_targeting(self) -> None:
        """Forget the pending command and its target list."""
        self._pending_command = None
        self._target_pool = []
        self._target_cursor = 0

    def _move_target_cursor(self, direction: int) -> None:
        """Step the target cursor, wrapping at either end."""
        if not self._target_pool:
            return
        self._target_cursor = (
            self._target_cursor + direction
        ) % len(self._target_pool)

    # ------------------------------------------------------------------
    # PLAYBACK
    # ------------------------------------------------------------------

    def _can_command(self) -> bool:
        """Return True when the player may pick a command right now."""
        return self._commands_up() and self._settle <= 0

    def _commands_up(self) -> bool:
        """Return True when the commands are on screen, waiting on the player."""
        return (
            self.battle.is_awaiting_command()
            and not self._events
            and self._beat <= 0
            and self.text_box.is_done()
            and not self._talking()
            and self.paddle is None
            and self.pound is None
            and self.banish is None
            and self.spin is None
            and self.minigame is None
        )

    def _play_events(self) -> None:
        """Show queued events until one puts a line on screen or a stroke swings."""
        while self._events and self.text_box.is_done() and self._beat <= 0 and not self._talking():
            # A counter waits a beat after the blow it answers (Frankie, 10/28).
            ahead = self._events[0]
            if (isinstance(ahead, DamageEvent) and ahead.cause == "counter"
                    and not self._counter_held):
                self._counter_held = True
                self._beat = BattleSettings.COUNTER_BEAT_SECONDS
                break
            # Green Dream: the fall is seen, then a beat, then the rise with its sound and flourish (Frankie, 11/17).
            if isinstance(ahead, RevivedEvent) and ahead.target_id == self._just_fell and not self._rise_held:
                self._rise_held = True
                self._beat = BattleSettings.RISE_BEAT_SECONDS
                break
            event = self._events.popleft()
            if isinstance(event, RevivedEvent):
                self._rise_held = False
            # Only a rise straight after its own fall waits the beat; a Life Totem or Revive does not.
            self._just_fell = event.combatant_id if isinstance(event, CombatantDefeatedEvent) else None
            if isinstance(event, (AttackEvent, StrokeEvent)):
                self._striker = event.attacker_id
            elif isinstance(event, AbilityUsedEvent):
                self._striker = event.user_id
            if isinstance(event, DamageEvent) and event.cause == "counter":
                self._counter_held = False
                if self.meter is not None:
                    self._kick_hold = BlockSettings.LINGER_SECONDS
            if isinstance(event, BlockStartEvent):
                # The meter takes the commands' place until the strokes are caught or missed.
                self.meter = BlockMeterView(BlockMeter(event.strokes, event.zone, event.speed, event.perfect))
                self._meter_age = 0.0
                self._block_attacker = event.attacker_id
                self._block_target = (event.target_id, event.target_name)
                if self.tutorial is not None:
                    self.tutorial.block_started()
                break
            if isinstance(event, DamageEvent):
                self._shown_hp[event.target_id] -= event.amount
                self._count_dodges(event)
                if event.timed != "perfect":
                    self._damage_sounds(event)
            elif isinstance(event, HealEvent):
                self._shown_hp[event.target_id] += event.amount
                if event.amount > 0:  # a heal of nothing makes no sound (Frankie, 11/5)
                    self._hit_sound("hit_sparkle")
                    self._hint_nature_heals(event)
            elif isinstance(event, SummonEvent):
                # A monster the Great Boar's Squeal called takes its place in the line (Frankie, 10/28).
                called = next((c for c in self.battle.enemies if c.id == event.combatant_id), None)
                if called is not None:
                    self._shown_hp[called.id] = called.hp
                    self.stage.join(called)
                else:
                    # Tawiri's spirit takes a fourth row, or leaves it (Frankie, 10/25).
                    spirit = next((c for c in self.battle.party if c.id == event.combatant_id), None)
                    if event.joined and spirit is not None:
                        self._shown_hp[spirit.id] = spirit.hp
                    self.stage.summon(spirit if event.joined else None, event.combatant_id)
            elif isinstance(event, RevivedEvent):
                self._shown_hp[event.target_id] = event.hp
                self._hit_sound("hit_sparkle")
            elif isinstance(event, (DodgeEvent, MissEvent)):
                self._hit_sound("hit_miss")
            elif isinstance(event, StanceEvent):
                # A new stance moves max HP and keeps the share (D-365).
                for c in self.battle.party:
                    if c.id == event.combatant_id:
                        self._shown_hp[c.id] = c.hp
            elif isinstance(event, BattleEndedEvent):
                self._battle_finished = True
                if self.battle.outcome == "victory":
                    self.gm.audio.play_screen(self._won_music)
            # A win says nothing here: the victory screen tells it (Frankie, 10/26).
            if not (isinstance(event, BattleEndedEvent) and self.victory is not None):
                self.view.consume(event)
            self.stage.consume(event)
            self._beat_for_silent(event)
            if isinstance(event, SwapEvent) and event.in_id == self._swap_complaint:
                self._swap_complaint = None
                for speaker, line in StorySettings.SWAP_GRUMBLE:
                    self._say(speaker, line)
            if isinstance(event, StrokeEvent):
                # Paddle's hits come rapidfire (Frankie, 10/31), Wili's at half that speed (Frankie, 11/1).
                self._beat = (BattleSettings.PADDLE_BEAT_SECONDS if event.stroke == "Paddle"
                              else BattleSettings.WILI_BEAT_SECONDS if event.stroke == "Wili"
                              else BattleSettings.STROKE_BEAT_SECONDS)

    def _beat_for_silent(self, event: Any) -> None:
        """A number or name box with no text line still gets its own beat (Frankie, 11/17).

        With the "uses" and "takes damage" lines gone nothing held the queue, so a whole action's
        events played in one frame: the enemy answered the instant the player hit, and every hit's
        number appeared at once.
        """
        if not self.text_box.is_done():
            return  # a line is up and holds the queue by itself
        beat = 0.0
        if isinstance(event, DamageEvent) and event.amount > 0:
            beat = BattleSettings.HIT_BEAT_SECONDS
        elif isinstance(event, HealEvent) and event.amount > 0:
            beat = BattleSettings.HIT_BEAT_SECONDS
        elif isinstance(event, AttackEvent) and event.move_name:
            beat = BattleSettings.SKILL_BEAT_SECONDS
        elif isinstance(event, AbilityUsedEvent):
            element = self.stage.charge_element(event)
            if element is not None:
                self.gm.audio.play(f"charge_{element}")   # the charge-up, then the element (Frankie, 11/17)
                beat = BattleSettings.CHARGE_BEAT_SECONDS
            else:
                beat = BattleSettings.SKILL_BEAT_SECONDS
        elif isinstance(event, ComboUsedEvent):
            beat = BattleSettings.SKILL_BEAT_SECONDS
        self._beat = max(self._beat, beat)

    def _run_meter(self, dt: float) -> None:
        """Slide the bars, and let each stroke swing and land as its bar does (Frankie, 10/30).

        A bar reaching the zone starts the monster's swing; the stroke lands when the
        press decides it, or as the bar leaves the zone if there was none. If the
        character falls the battle drops the other strokes and the meter goes at once.
        """
        meter = self.meter.meter
        meter.update(dt)
        self.meter.update(dt)
        self._meter_age += dt
        for _ in meter.entries():
            target_id, target_name = self._block_target
            self.stage.consume(StrokeEvent(self._block_attacker, "", target_id, target_name, ""))
        for index, result in meter.landings():
            # The monster's own swings start as their bars arrive (above); a parry's counterattack swings now.
            events = [e for e in self.battle.block_stroke(result, meter.grade_of(index))
                      if not (isinstance(e, StrokeEvent) and e.attacker_id == self._block_attacker)]
            self._dispatch(events)
            if not self.battle.is_awaiting_block():
                # The battle has done with the strokes: a fall ends the meter early.
                if not all(b.landed for b in meter.bars):
                    self.meter = None
                    return
        # The last stroke's kick back lands while its bar is still up (Frankie, 11/2).
        self._kick_hold = max(0.0, self._kick_hold - dt)
        if (meter.done and self._kick_hold <= 0
                and not any(isinstance(e, DamageEvent) and e.cause == "counter" for e in self._events)):
            self.meter = None

    def _ease(self, skill_id: str, target_id: str | None = None) -> float:
        """How easy the acting member's game for ``skill_id`` is, by the stats (Frankie, 11/1)."""
        return self.battle.skill_ease(self.battle.current_actor, skill_id, target_id)

    def _start_dance(self, move: dict[str, Any], target_id: str | None) -> None:
        """Hina's Dance: the move's steps on four rows, and it heals by how much was got (Frankie, 11/1)."""
        self._start_minigame(DanceMeter(move, target_id, self._ease("dance")),
                             lambda m: self.battle.submit_dance(m.move["id"], m.target_id, m.share))

    def _start_pohuehue(self, partner_id: str, target_id: str) -> None:
        """Pōhuehue: the vine danced up, then spun and cracked; it hits by how both went (Frankie, 11/3)."""
        dance = DanceMeter({"id": "pohuehue", "name": "Grow the vine!"}, target_id)

        def spin(danced: DanceMeter) -> list[Any]:
            self._start_minigame(VineMeter("vine_whip", partner_id, target_id, danced.share),
                                 lambda m: self.battle.submit_combo(m.combo_id, m.partner_id, m.target_id, m.quality))
            return []

        self._start_minigame(dance, spin)

    def _start_spring_rain(self, partner_id: str) -> None:
        """Spring Rain: the nature partner's dance calls the rain, then the water partner stirs it
        round like Cook's stir; the heal goes by how both went (Frankie, 11/4; games the player knows)."""
        dance = DanceMeter({"id": "spring_rain", "name": "Call the rain!"}, None)

        def stir(danced: DanceMeter) -> list[Any]:
            self._start_minigame(StirMeter("spring_rain", self._ease("cook")),
                                 lambda m: self.battle.submit_combo(
                                     "spring_rain", partner_id, None, 0.5 + 0.25 * danced.share + 0.25 * m.quality))
            return []

        self._start_minigame(dance, stir)

    def _start_light_wave(self, partner_id: str) -> None:
        """Light Wave: the light partner's hand seals, as Tinju Surya starts, then the water partner
        stirs like Cook's stir; the shield goes by how both went (Frankie, 11/4; games the player knows)."""
        seals = SimonMeter(None, play=self.gm.audio.play)

        def stir(sealed: SimonMeter) -> list[Any]:
            share = sealed.rounds / MinigameSettings.SIMON_ROUNDS
            self._start_minigame(StirMeter("light_wave", self._ease("cook")),
                                 lambda m: self.battle.submit_combo(
                                     "light_wave", partner_id, None, 0.5 + 0.25 * share + 0.25 * m.quality))
            return []

        self._start_minigame(seals, stir)

    def _start_tinju_surya(self, partner_id: str, target_id: str) -> None:
        """Tinju Surya: the hand seals, then the punch; it hits by how both went (Frankie, 11/3)."""
        seals = SimonMeter(target_id, play=self.gm.audio.play)

        def punch(sealed: SimonMeter) -> list[Any]:
            self._start_minigame(PunchMeter("solar_fist", partner_id, target_id, sealed.rounds),
                                 lambda m: self.battle.submit_combo(m.combo_id, m.partner_id, m.target_id, m.quality))
            return []

        self._start_minigame(seals, punch)

    def _start_minigame(self, meter: Any, done: Any) -> None:
        """Put ``meter`` in the commands' window; ``done(meter)`` gives the battle its result when it ends."""
        self.minigame, self._minigame_done = meter, done

    def _run_minigame(self, dt: float) -> None:
        """Run the minigame's clock; when it is done, the Skill lands by how it went."""
        meter = self.minigame
        meter.update(dt)
        if meter.done:
            done, self.minigame, self._minigame_done = self._minigame_done, None, None
            self._dispatch(done(meter))

    def _minigame_input(self, event: pygame.event.Event) -> None:
        """Pass a press to the minigame up, with its sound."""
        meter = self.minigame
        audio = self.gm.audio
        if isinstance(meter, VineMeter):
            if input_map.is_confirm(event):
                audio.play("perfect" if meter.crack() else "menu_select")
            elif meter.handle(event):
                audio.play("menu_move")
        elif isinstance(meter, StirMeter):
            if meter.handle(event):
                audio.play("menu_move")
        elif isinstance(meter, PaddleMeter):
            if input_map.is_confirm(event) and meter.press():
                audio.play("menu_move")
        elif isinstance(meter, SimonMeter):
            button = button_of(event)
            if button is not None:
                meter.press(button)    # It plays its own sounds.
        elif isinstance(meter, BanishMeter):
            if input_map.is_confirm(event):
                meter.hold()
            elif input_map.is_confirm_up(event):
                meter.release()
        elif isinstance(meter, EscapeMeter):
            button = "L" if input_map.is_l1(event) else "R" if input_map.is_r1(event) else None
            if button is not None:
                audio.play("menu_move" if meter.press(button) else "cant")
        elif isinstance(meter, RhythmMeter):
            button = "A" if input_map.is_confirm(event) else "B" if input_map.is_cancel(event) else None
            if button is not None:
                audio.play("menu_move" if meter.press(button) else "cant")
        elif isinstance(meter, DanceMeter):
            button = button_of(event) or _pound_button(event, self._pound_hat, meter.wanted())
            if event.type == pygame.JOYHATMOTION:
                self._pound_hat = event.value
            if button is not None:
                result = meter.press(button)
                audio.play("perfect" if result == "perfect" else "menu_move" if result == "good" else "cant")
        elif isinstance(meter, TapMeter):
            if input_map.is_confirm(event):
                meter.tap()
                audio.play("menu_select" if meter.share else "cant")

    def _run_paddle(self, dt: float) -> None:
        """Run Paddle's clock; when it is up, every press is swung at once."""
        self.paddle.update(dt)
        if self.paddle.done:
            meter, self.paddle = self.paddle, None
            self._dispatch(self.battle.submit_paddle(meter.target_id, meter.presses))

    def _run_wili(self, dt: float) -> None:
        """Run Wili's clock; when it is up, every turn of the pad is cast at once."""
        self.spin.update(dt)
        if self.spin.done:
            meter, self.spin = self.spin, None
            self._dispatch(self.battle.submit_wili(meter.rotations))

    def _run_banish(self, dt: float) -> None:
        """Run Banish's time and draw; when the arrow flies or the time is up, it lands."""
        self.banish.update(dt)
        if self.banish.done:
            meter, self.banish = self.banish, None
            self._dispatch(self.battle.submit_banish(meter.target_id, meter.share or 0.0))

    def _run_pound(self, dt: float) -> None:
        """Run Pound's clock; when the buttons are done or the time is up, the move lands."""
        self.pound.update(dt)
        if self.pound.done:
            pound, self.pound = self.pound, None
            submit = self.battle.submit_dance if pound.skill == "dance" else self.battle.submit_pound
            self._dispatch(submit(pound.move["id"], pound.target_id, pound.share))

    def _press_block(self) -> None:
        """Confirm on the meter: the sound and word for how it landed."""
        result = self.meter.meter.press()
        if result == "perfect":
            self.gm.audio.play("perfect")
            self.meter.parried()   # "Parried!" rises above the bar, on the perfect press only (Frankie, 11/10)
        elif result == "catch":
            self.gm.audio.play("clank")   # in the yellow, not perfect: no word, a clank, and less damage (Frankie, 11/11)
        elif result == "miss":
            self.gm.audio.play("cant")

    def _damage_sounds(self, event: DamageEvent) -> None:
        """How the blow landed, then its element just after it (D-151).

        A plain blow, whoever swings and whatever they hold, draws from one shared pool of physical
        hit sounds (Frankie, 11/11); a spell is magic, which plain blows never use; a monster, a
        poison tick and the rest are plain punches. The element, if the blow has one, follows a
        moment later.
        """
        if event.cause == "spell":
            kind = "hit_magic"
        elif event.cause in ("hit", "stroke", "counter"):
            kind = random.choice(AudioSettings.PHYSICAL_HIT_POOL)
        else:
            kind = "hit_punch"
        if kind in AudioSettings.HIT_KINDS_ONE_TAKE:
            self.gm.audio.play(kind)
        else:
            self._hit_sound(kind)
        if event.element is not None and event.amount > 0:
            self.gm.audio.play(f"elem_{event.element.value}", delay=AudioSettings.ELEMENT_SOUND_DELAY)

    def _hit_sound(self, kind: str) -> None:
        """Play one of the three takes of a hit sound."""
        take = random.randint(1, AudioSettings.HIT_TAKES)
        self.gm.audio.play(f"{kind}_{take}")

    def _hint_nature_heals(self, event: HealEvent) -> None:
        """Hina's one boar hint, the first time a nature monster heals (Frankie, 11/3)."""
        flags = self.gm.party.flags
        if event.amount <= 0 or flags.get(TutorialSettings.NATURE_HEALS_FLAG):
            return
        healed = next((c for c in self.battle.enemies if c.id == event.target_id), None)
        if healed is None or Element.LAU not in (healed.element, getattr(healed, "stance_element", None), *healed.elements):
            return
        if not any(c.id == "hina" and c.alive for c in self.battle.party):
            return
        flags[TutorialSettings.NATURE_HEALS_FLAG] = True
        self._say("Hina", TutorialSettings.NATURE_HEALS)

    def _teach_team_up(self) -> None:
        """Hina's Team Up lesson, the first time one is open with her in it, once ever
        (Frankie, 11/3, after Mark's playtest: nothing in the game taught it)."""
        flags = self.gm.party.flags
        if flags.get(TutorialSettings.TEAM_UP_FLAG) or self._battle_finished or not self._commands_up():
            return
        if self.stroke_menu is not None or self.list_menu is not None or self._pending_command is not None:
            return
        if self.tutorial is not None and (not self.tutorial.later or self.tutorial.step is not None):
            # Never in the taro patch, which has lessons enough, nor over another lesson.
            return
        actor = self.battle.current_actor
        if actor is None or not actor.is_party:
            return
        partners = [p for _, p in self.battle.combos_for(actor) if self.battle.can_pay_combo(actor, p)]
        if not any("hina" in (actor.id, p.id) for p in partners):
            return
        flags[TutorialSettings.TEAM_UP_FLAG] = True
        for line in TutorialSettings.TEAM_UP:
            self._say("Hina", line)

    def _count_dodges(self, event: DamageEvent) -> None:
        """Three perfect dodges in a row and Hina, if she is fighting, admits it, once ever
        (Frankie, 11/4: the first time only, a party flag so it survives fights and saves)."""
        if event.cause != "stroke" or not any(c.id == event.target_id for c in self.battle.party + self.battle.bench):
            return
        self._dodge_streak = self._dodge_streak + 1 if event.timed == "perfect" else 0
        flags = self.gm.party.flags
        if (self._dodge_streak >= TutorialSettings.DODGE_PRAISE_AFTER and not flags.get(TutorialSettings.DODGE_PRAISE_FLAG)
                and any(c.id == "hina" and c.alive for c in self.battle.party)):
            flags[TutorialSettings.DODGE_PRAISE_FLAG] = True
            self._say("Hina", TutorialSettings.DODGE_PRAISE)

    def _say(self, speaker: str, line: str) -> None:
        """Have ``speaker`` say ``line`` in the full-width box, once the narration before it is done."""
        self._sayings.append((speaker, line))

    def _talking(self) -> bool:
        """Return True while a said line is up or waiting its turn."""
        return bool(self._sayings) or not self.talk_box.is_done()

    def _hold_narration(self, dt: float) -> None:
        """Advance a finished line by itself after a short hold."""
        if self.text_box.is_done() or not self.text_box.is_page_complete():
            self._narration_held = 0.0
            return
        self._narration_held += dt
        if self._narration_held >= BattleSettings.NARRATION_HOLD_SECONDS:
            self._narration_held = 0.0
            self.text_box.advance()

    def _track_select(self, event: pygame.event.Event) -> None:
        """Note Select going down and up, for the help window (Frankie, 11/1)."""
        if input_map.is_select(event):
            self._select_held = True
        elif (event.type == pygame.KEYUP and event.key in input_map.SELECT_KEYS) or (
                event.type == pygame.JOYBUTTONUP and event.button == InputSettings.JOY_BUTTON_BACK):
            self._select_held = False

    def _help_text(self) -> str | None:
        """What the highlighted row does, or None when it has no words (and while a target is picked).

        On the command pages that is ``BattleSettings.HELP`` (the Skill row, its Skill's words); in a sub menu the
        row's own ``help``: an element's description, the stance's ``about``, an item's field help line.
        """
        if self._pending_command is not None:
            return None
        if self._swap is not None:
            return None     # the swap screen writes its own help
        sub = self.list_menu or self.item_menu or self.ability_menu or self.stroke_menu
        if sub is not None:
            if self._switch_open:
                return None
            row = sub.current if isinstance(sub, GridMenu) else sub.items[sub.cursor] if sub.items else None
            return row.help if row is not None else None
        menu = self.side_menu or self.command_menu
        label = menu.items[menu.cursor].label
        if menu is self.command_menu and menu.cursor == _TECH_ROW:
            skill = self._held_skill(self.battle.current_actor)
            if skill is None:
                return BattleSettings.HELP["No Skill"]
            return f"{skill['name']}: {skill.get('description', '')} {BattleSettings.HELP['Skill']}"
        return BattleSettings.HELP.get(label)

    def _help_icon(self) -> pygame.Surface | None:
        """The picture before Select's words: a Team Up row's two element icons, else None."""
        if self._pending_command is not None or self.list_menu is None or not self.list_menu.items:
            return None
        return self.list_menu.items[self.list_menu.cursor].help_icon

    def _say_why(self, menu: Any) -> None:
        """A on a greyed row: a small box saying why, for a moment (Frankie, 11/4: no text box to close)."""
        items = getattr(menu, "items", None)
        row = items[menu.cursor] if items and 0 <= getattr(menu, "cursor", -1) < len(items) else None
        if row is None and isinstance(menu, GridMenu):
            row = menu.current  # the Element list's greyed move (Mark's Episode 6: A on FlmKick said nothing)
        if row is not None and not row.enabled and row.why:
            self._why = (row.why, BattleSettings.WHY_SECONDS)
            self.gm.audio.play("cant")

    def _render_why(self, surface: pygame.Surface) -> None:
        """The reason box over the fight, where Select's words go."""
        if self._why is None:
            return
        edge = UISettings.TEXT_BOX_BORDER_THICKNESS + 4
        width = ScreenSettings.WIDTH - 16
        lines = text_renderer.wrap(self._why[0], text_renderer.get_font(FontSettings.SIZE_BODY), width - 2 * edge)
        step = text_renderer.line_height(FontSettings.SIZE_BODY)
        window = pygame.Rect(8, 0, width, len(lines) * step + 2 * edge)
        window.bottom = self._hud_rect(surface).top - 4
        draw_window(surface, window)
        for n, line in enumerate(lines):
            text_renderer.draw_text(surface, line, (window.left + edge, window.top + edge + n * step),
                                    color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY)

    def _render_help(self, surface: pygame.Surface) -> None:
        """While Select is held, a window over the fight saying what the highlighted command does."""
        text = self._help_text()
        if text is None:
            return
        icon = self._help_icon()
        indent = icon.get_width() + 4 if icon is not None else 0
        edge = UISettings.TEXT_BOX_BORDER_THICKNESS + 4
        width = ScreenSettings.WIDTH - 16
        lines = text_renderer.wrap(text, text_renderer.get_font(FontSettings.SIZE_BODY), width - 2 * edge - indent)
        step = text_renderer.line_height(FontSettings.SIZE_BODY)
        window = pygame.Rect(8, 0, width, len(lines) * step + 2 * edge)
        window.bottom = self._hud_rect(surface).top - 4
        draw_window(surface, window)
        if icon is not None:
            surface.blit(icon, (window.left + edge, window.top + edge))
        for n, line in enumerate(lines):
            text_renderer.draw_text(surface, line, (window.left + edge + indent, window.top + edge + n * step),
                                    color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY)

    def _render_team_up_sign(self, surface: pygame.Surface) -> None:
        """On the four commands, a page arrow at each side; the right one flashes yellow when a
        Team Up is open (Frankie, 11/4; it was a "Team Up >" sign on Item's row).

        Open means both partners can pay for it too, not just that their
        stances make one; any two different stances make one (Frankie, 11/2).
        """
        rect = self._command_rect(surface)
        border = UISettings.TEXT_BOX_BORDER_THICKNESS
        mid_y = rect.top + rect.height // 2
        left_x = rect.left + border + 2
        right_x = rect.right - border - 2 - _PAGE_ARROW_W
        _draw_page_arrow(surface, left_x, mid_y, False, ColorSettings.WHITE)
        actor = self.battle.current_actor
        open_now = actor is not None and any(self.battle.can_pay_combo(actor, partner)
                                             for _, partner in self.battle.combos_for(actor))
        flash_on = not int(time.monotonic() * UISettings.SWITCH_FLASH_HZ * 2) % 2
        color = ColorSettings.YELLOW if open_now and flash_on else ColorSettings.WHITE
        _draw_page_arrow(surface, right_x, mid_y, True, color)

    def _preview_wait(self) -> float | None:
        """Return the wait the highlighted action would cost, for the strip.

        None means nothing specific is highlighted yet (the cursor is on
        Attack or Ability before the choice), and the strip guesses.
        """
        battle = self.battle
        if self._pending_command is not None:
            kind = self._pending_command["kind"]
            if kind in ("chain", "stroke"):
                return None
            if kind == "combo":
                return battle.preview_wait("combo")
            if kind in ("scold", "charm", "paddle", "banish", "pound", "dance", "vault"):
                return battle.preview_wait("tech")
            if kind == "move" and self.moves[self._pending_command["move_id"]].get("signature"):
                return battle.preview_wait("tech")
            return battle.preview_wait("item" if kind in ("noni", "seer_shell", "dish", "cure") else "move")
        if self.ability_menu is not None or self._swap is not None:
            return battle.preview_wait("move")
        if self.item_menu is not None:
            return battle.preview_wait("item")
        if self.list_menu is not None:
            if self._skill_listing:
                return battle.preview_wait("tech")
            return battle.preview_wait("move" if self._page == 1 else "defend")
        if self.side_menu is not None:
            label = self.side_menu.items[self.side_menu.cursor].label
            if label in ("Equip", "Defend", "Escape"):
                return battle.preview_wait("defend")
            return battle.preview_wait("combo") if label == "Combo" else None
        if self.stroke_menu is not None:
            row = self.stroke_menu.cursor
            if row < len(_STROKE_KINDS):
                points = BattleSettings.STROKES[_STROKE_KINDS[row]]["points"]
                return battle.preview_wait("attack") + points * BattleSettings.STROKE_WAIT
            return None
        row = self.command_menu.cursor
        if row == _TECH_ROW and self.command_menu.items[_TECH_ROW].enabled:
            return battle.preview_wait("tech")
        if row == _ITEM_ROW:
            return battle.preview_wait("item")
        return None

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Advance narration, or drive the menus and target cursor."""
        if self.swirl is not None:
            return  # The swirl in (ui/fight_swirl.py) takes no buttons.
        self._track_select(event)
        # A greyed row's reason goes away on any button (Frankie, 11/4).
        if self._why is not None and event.type in (pygame.KEYDOWN, pygame.JOYBUTTONDOWN, pygame.JOYHATMOTION):
            self._why = None
            return
        # Hina's box, and what her lesson locks, come first.
        if self.tutorial is not None and self.tutorial.handle_event(event):
            return
        if self._guide_slot_event(event):
            return
        if self.meter is not None:
            # A press as the meter opens is left over from the menu or the text before it: not counted,
            # so it cannot spend the first arrow (Frankie, 11/14).
            if input_map.is_confirm(event) and self._meter_age >= BlockSettings.OPEN_GRACE_SECONDS:
                self._press_block()
            return
        if self.minigame is not None:
            self._minigame_input(event)
            return
        if self.paddle is not None:
            if input_map.is_confirm(event) and self.paddle.press():
                self.gm.audio.play("menu_move")
            return
        if self.spin is not None:
            if self.spin.handle(event):
                self.gm.audio.play("menu_move")
            return
        if self.banish is not None:
            if input_map.is_confirm(event):
                self.banish.hold()
            elif input_map.is_confirm_up(event):
                self.banish.release()
            return
        if self.pound is not None:
            if self.pound.done:
                # The last button is in, the move lands next frame: a key let go in between is nothing
                # (a quick tap's key-up crashed the game, Frankie 11/12).
                return
            button = _pound_button(event, self._pound_hat, self.pound.buttons[self.pound.pressed])
            if event.type == pygame.JOYHATMOTION:
                self._pound_hat = event.value
            if button is not None:
                self.gm.audio.play("menu_move" if self.pound.press(button) else "cant")
            return
        if not self.talk_box.is_done():
            if input_map.is_confirm(event):
                self.talk_box.advance()
            return
        if not self.text_box.is_done():
            if input_map.is_confirm(event):
                self._narration_held = 0.0
                self.text_box.advance()
            return
        if self._battle_finished or not self._can_command():
            return
        if self._pending_command is not None:
            if input_map.is_cancel(event):
                self._cancel_targeting()
                self.gm.audio.play("menu_move")
            elif input_map.is_up(event) or input_map.is_left(event):
                self._move_target_cursor(-1)
                self.gm.audio.play("menu_move")
            elif input_map.is_down(event) or input_map.is_right(event):
                self._move_target_cursor(1)
                self.gm.audio.play("menu_move")
            elif input_map.is_confirm(event):
                self.gm.audio.play("menu_select")
                self._on_target_confirmed()
            return
        if self._switch_open and self.ability_menu is not None:
            # The window over the stance's name: A switches, B backs out to the row.
            if input_map.is_confirm(event):
                self.gm.audio.play("menu_select")
                self._on_stance_chosen()
            elif input_map.is_cancel(event):
                self._switch_open = False
                self._preview_stance(False)
                self.gm.audio.play("menu_move")
            return
        if self._swap is not None:
            self._handle_swap(event)
            return
        if input_map.is_cancel(event):
            if self.list_menu is not None:
                self.list_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.side_menu is not None:
                self.side_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.item_menu is not None:
                self.item_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.ability_menu is not None:
                self.ability_menu.cancel()
                self.gm.audio.play("menu_move")
            elif self.stroke_menu is not None:
                self.stroke_menu.cancel()
                self.gm.audio.play("menu_move")
            return
        on_pages = (
            self.list_menu is None and self.item_menu is None
            and self.ability_menu is None and self.stroke_menu is None
        )
        if on_pages and (input_map.is_left(event) or input_map.is_right(event)):
            if self._turn_page(-1 if input_map.is_left(event) else 1):
                self.gm.audio.play("menu_move")
            return
        active_menu = (
            self.list_menu or self.item_menu or self.ability_menu
            or self.stroke_menu or self.side_menu or self.command_menu
        )
        if input_map.is_up(event):
            if active_menu.move_up():
                self.gm.audio.play("menu_move")
        elif input_map.is_down(event):
            if active_menu.move_down():
                self.gm.audio.play("menu_move")
        elif isinstance(active_menu, GridMenu) and input_map.is_left(event):
            if active_menu.move_left():
                self.gm.audio.play("menu_move")
        elif isinstance(active_menu, GridMenu) and input_map.is_right(event):
            if active_menu.move_right():
                self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            if active_menu is self.command_menu or active_menu is self.side_menu:
                self._remember_commands(active_menu)
            if active_menu.confirm():
                self.gm.audio.play("menu_select")
            else:
                self._say_why(active_menu)

    # ------------------------------------------------------------------
    # CONFIG'S CURSOR (Frankie, 10/26)
    # ------------------------------------------------------------------

    def _open_commands(self) -> None:
        """A turn starts: the commands open on Attack, or with Memory where this one left them."""
        actor = self.battle.current_actor
        self._refresh_command_labels()
        page, row = (0, 0)
        if config.current.cursor == "Memory" and actor is not None:
            page, row = config.current.cursors.get(actor.id, (0, 0))
        self._back_to_commands()
        if self._forced_slot is not None and actor is not None and actor.id == StorySettings.COUNTER_LEARNER:
            return    # The first page, Attack under the cursor; the path to Counter's slot starts with left.
        if page != 0:
            self._turn_page(page)
        menu = self.side_menu if page != 0 else self.command_menu
        if menu is None or not 0 <= row < len(menu.items) or not menu.items[row].enabled:
            # Gone or grayed since (no Noni left, no spare weapon): the page's first row it can.
            menu = menu or self.command_menu
            row = next((i for i, item in enumerate(menu.items) if item.enabled), 0)
        menu.cursor = row
        self._teach_swap()

    def _teach_cast(self, events: list[Any]) -> None:
        """Once: an enemy casts Green Dream or Revive, and Hina, if she is fighting, says what it means."""
        if not self._cast_lesson:
            return
        mine = {c.id for c in self.battle.party + self.battle.bench}
        if not any(isinstance(ev, AbilityUsedEvent) and ev.ability_id in StorySettings.CLEARING_CAST_MOVES
                   and ev.user_id not in mine for ev in events):
            return
        self._cast_lesson = False
        if any(c.id == "hina" and c.alive for c in self.battle.party):
            for speaker, line in StorySettings.CLEARING_CAST_TALK:
                self._say(speaker, line)

    def _teach_swap(self) -> None:
        """Once, on the first turn with them on the bench: Hina and they talk, then the swap is forced.

        The page with Swap opens and a list of who sits out takes the window,
        everyone fighting but the one locked in, the cursor on Hina; it cannot
        be backed out of (Frankie, 10/30).
        """
        who = self._swap_lesson
        if who is None or not any(c.id == who and c.alive for c in self.battle.bench):
            return
        self._swap_lesson = None
        self._swap_complaint = who
        for speaker, line in StorySettings.SWAP_TALK:
            self._say(speaker, line)
        self._back_to_commands()
        self._turn_page(1)
        swap = next((i for i, item in enumerate(self.side_menu.items) if item.label == "Swap"), 0)
        self.side_menu.cursor = swap
        out = [c for c in self.battle.party if c.alive and c.id != self._swap_locked]
        self.list_menu = Menu(
            items=[MenuItem(short_name(c.id), lambda c=c: self._on_forced_swap(who, c.id)) for c in out],
            on_cancel=lambda: None,
        )
        self.list_menu.cursor = next(
            (i for i, c in enumerate(out) if c.id == StorySettings.SWAP_OUT_CURSOR), 0)

    def _on_forced_swap(self, bench_id: str, out_id: str) -> None:
        """The swap lesson's pick: ``bench_id`` comes in for ``out_id``."""
        self._close_list_menu()
        self._back_to_commands()
        self._dispatch(self.battle.submit_swap(bench_id, out_id))

    def _remember_commands(self, menu: Menu) -> None:
        """Note the page and row the one acting picked from, for Memory."""
        actor = self.battle.current_actor
        if actor is not None:
            config.current.cursors[actor.id] = (self._page, menu.cursor)

    # ------------------------------------------------------------------
    # RENDER
    # ------------------------------------------------------------------

    def render(self, surface: pygame.Surface) -> None:
        """Draw the fighters, the turn strip, and the bottom window.

        The window is split: commands or narration on the left, the
        party's rows on the right. The Ability and Item submenus take
        the whole window while they are open.
        """
        swirl = self.swirl
        if swirl is not None and not swirl.opening:
            swirl.render_close(surface)
            return
        self._render_fight(surface)
        if swirl is not None:
            swirl.cover(surface)  # The fight comes through the spiral's arms (ui/fight_swirl.py).

    def _render_fight(self, surface: pygame.Surface) -> None:
        """The fight's own picture, whole."""
        render_template(self.backdrop, surface)
        surface.scroll(0, BattleStageSettings.BACKDROP_DY)  # The backdrop sits 28 up (Frankie, 11/11); the HUD hides the rows left below.
        actor = self.battle.current_actor
        active_id = actor.id if actor is not None else None
        target = (
            self._target_pool[self._target_cursor]
            if self._pending_command is not None and self._target_pool
            else None
        )
        self.stage.render_enemies(
            surface, self._shown_hp, active_id, target,
        )
        waiting = active_id if self.battle.is_awaiting_command() else None
        self.stage.render_party_sprites(surface, self._shown_hp, waiting)
        if any(c.alive and c.statuses.get("rain") for c in self.battle.party):
            render_rain(surface, self._hud_rect(surface).top, time.monotonic())
        if any(c.alive and c.statuses.get("wave") for c in self.battle.party):
            render_light_wave(surface, self._hud_rect(surface).top, time.monotonic())
        self._render_turn_strip(surface, target)
        commanding = not self._battle_finished and self._commands_up()
        submenu = (
            (self._swap or self.list_menu or self.item_menu or self.ability_menu)
            if commanding else None
        )
        self._render_hud_frame(surface, split=submenu is None)
        picking = commanding and target is not None and target.is_party
        if submenu is None:
            self.stage.render_party(
                surface, self._shown_hp, active_id, target, picking=picking,
            )
        aiming = (
            commanding and submenu is None and target is not None
            and not target.is_party
        )
        if aiming:
            self._render_target_name(surface, target)
        elif picking:
            self._render_pending_name(surface)
        elif commanding and self._swap is not None:
            self._swap.render(surface, self._hud_rect(surface))
        elif commanding:
            self._render_menu(
                surface,
                submenu or self.stroke_menu or self.side_menu or self.command_menu,
            )
            if submenu is None and self.stroke_menu is not None:
                self._render_points(surface)
            if (submenu is None and self.stroke_menu is None and self.side_menu is None
                    and self.battle.current_actor is not None):
                self._render_team_up_sign(surface)
            if self._select_held:
                self._render_help(surface)
            else:
                self._render_why(surface)

        elif self.meter is not None:
            self.meter.render(surface, self._command_rect(surface))
        elif self.paddle is not None:
            # The A button and the time, in the window the commands were in (Frankie, 10/31).
            self.paddle.render(surface, self._command_rect(surface))
        elif self.spin is not None:
            # The pad going round and the time, in the window the commands were in (Frankie, 11/1).
            self.spin.render(surface, self._command_rect(surface))
        elif self.banish is not None:
            # The A button and the time below; the two circles on the enemy (Frankie, 10/31).
            self.banish.render(surface, self._command_rect(surface))
            center = self.stage.enemy_center(self.banish.target_id)
            if center is not None:
                self.banish.render_rings(surface, center)
        elif self.pound is not None:
            # The buttons and the time, in the same window (Frankie, 10/31).
            self.pound.render(surface, self._command_rect(surface))
        elif self.minigame is not None:
            # The 11/1 minigames, in the same window; the circles on the enemy for Vault and Moepapa.
            self.minigame.render(surface, self._command_rect(surface))
            if hasattr(self.minigame, "render_rings"):
                center = self.stage.enemy_center(self.minigame.target_id)
                if center is not None:
                    self.minigame.render_rings(surface, center)
        else:
            self.text_box.render(surface)
        self.stage.render_floaters(surface)
        self.notices.render(surface)
        if not self.talk_box.is_done():
            height = self.talk_box.height
            self.talk_box.render(surface.subsurface(
                pygame.Rect(0, surface.get_height() - height, ScreenSettings.WIDTH, height)))
        if self._guiding_slot():
            dim_except(surface, self._slot_guide_light(surface))
        if self.tutorial is not None:
            self.tutorial.render(surface)

    def _render_target_name(self, surface: pygame.Surface, target: Combatant) -> None:
        """While a monster is aimed at, the left window shows its name (Frankie, 10/18)."""
        rect = self._command_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        text_renderer.draw_text(
            surface, target.name,
            (rect.left + pad + UISettings.MENU_LABEL_OFFSET + UISettings.MENU_HOOK_ROOM, rect.top + pad),
            color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
            max_width=UISettings.COMMAND_PANEL_WIDTH - 2 * pad - UISettings.MENU_LABEL_OFFSET,
        )

    def _pending_name(self) -> str:
        """Return what the one acting is about to use on an ally, with the count left of an item."""
        cmd = self._pending_command or {}
        kind = cmd.get("kind")
        if kind == "noni":
            return f"Noni x{self._bag_counts().get('noni', 0)}"
        if kind in ("dish", "cure"):
            return f"{ItemSettings.NAMES[cmd['item']]} x{self._bag_counts().get(cmd['item'], 0)}"
        if kind == "move":
            return short_move_name(self.battle.move(cmd["move_id"]))
        if kind == "combo":
            return by_id("combos").get(cmd["combo_id"], {}).get("name", "")
        return ""

    def _render_pending_name(self, surface: pygame.Surface) -> None:
        """While an ally is picked, the left window shows what they get, its cursor grey.

        Like the field menu's Items, where the item's cursor greys while the
        member's cursor is yellow, so it cannot pass for the commands
        (the 10/26 Let's Play pressed confirm on it, thinking it was them).
        """
        rect = self._command_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        x = rect.left + pad + UISettings.MENU_LABEL_OFFSET + UISettings.MENU_HOOK_ROOM
        text_renderer.draw_pointer(
            surface, (x - UISettings.MENU_LABEL_OFFSET, rect.top + pad + FontSettings.SIZE_BODY // 2),
            ColorSettings.GRAY,
        )
        text_renderer.draw_text(
            surface, self._pending_name(), (x, rect.top + pad),
            color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
            max_width=UISettings.COMMAND_PANEL_WIDTH - 2 * pad - UISettings.MENU_LABEL_OFFSET,
        )

    def _render_turn_strip(
        self, surface: pygame.Surface, target: Combatant | None = None
    ) -> None:
        """Draw who acts now and who acts next, as a column of small pictures (D-453).

        While a monster is aimed at, its pictures there get the target arrow too.
        """
        actor = self.battle.current_actor
        if actor is None or self.battle.is_over:
            return
        wait = self._preview_wait() if self._commands_up() else None
        upcoming = self.battle.upcoming(BattleSettings.TURN_ORDER_LENGTH, wait)
        self.stage.render_turn_order(surface, [actor] + upcoming)
        if target is not None and not target.is_party:
            self.stage.render_turn_target(surface, [actor] + upcoming, target)

    def _command_rect(self, surface: pygame.Surface) -> pygame.Rect:
        """Return the left half of the bottom window, where the commands, the narration and the meters go.

        The party's names and HP are the right half (Frankie, 11/12: the flip left the window as it was).
        """
        rect = self._hud_rect(surface)
        return pygame.Rect(rect.left + UISettings.COMMAND_PANEL_X, rect.top,
                           UISettings.COMMAND_PANEL_WIDTH, rect.height)

    def _menu_left(self, menu: Any, surface: pygame.Surface | None = None) -> int:
        """Return the x a menu's window starts at: the whole window's for a submenu, else the left half's."""
        surface = surface or self.gm.screen
        whole = menu is not None and (menu is self.list_menu or menu is self.item_menu or menu is self.ability_menu)
        return self._hud_rect(surface).left if whole else self._command_rect(surface).left

    def _hud_rect(self, surface: pygame.Surface) -> pygame.Rect:
        """Return the bottom window's rectangle."""
        return pygame.Rect(
            0,
            surface.get_height() - UISettings.TEXT_BOX_HEIGHT,
            ScreenSettings.WIDTH,
            UISettings.TEXT_BOX_HEIGHT,
        )

    def _render_hud_frame(self, surface: pygame.Surface, split: bool) -> None:
        """Draw the bottom window, or two side by side when split (D-457)."""
        rect = self._hud_rect(surface)
        if not split:
            draw_window(surface, rect)
            return
        commands = self._command_rect(surface)
        party = rect.copy()
        party.left = commands.right
        party.width = rect.right - commands.right
        draw_window(surface, commands)
        draw_window(surface, party)

    def _render_menu(self, surface: pygame.Surface, menu: Menu | GridMenu) -> None:
        """Draw ``menu`` in the window, from its top-left corner."""
        rect = self._hud_rect(surface)
        left = self._menu_left(menu, surface)
        pad = UISettings.TEXT_BOX_PADDING
        self._refresh_command_labels()
        if isinstance(menu, GridMenu):
            row_height = UISettings.ABILITY_MENU_ROW_HEIGHT
            if menu is self.ability_menu and self._switch_pair is not None:
                # The sign turns only while the cursor is on its row.
                turns = int(time.monotonic() * UISettings.SWITCH_SPIN_HZ) if menu.row == 0 else 0
                menu.rows[0].cells[0].tag = switch_icon(*self._switch_pair, turns)
            menu.render(
                surface,
                (left + pad + UISettings.MENU_LABEL_OFFSET, rect.top + pad),
                row_height=row_height,
                max_rows=(rect.height - 2 * pad) // row_height,
                label_width=UISettings.ABILITY_LABEL_WIDTH,
                col_width=UISettings.ABILITY_COL_WIDTH,
                font_size=FontSettings.SIZE_BODY,
            )
            if menu is self.ability_menu and self._switch_open:
                self._render_switch_window(surface)
            return
        row_height = UISettings.COMMAND_MENU_ROW_HEIGHT
        # Rows with an icon (the Weapon list's) draw it before the name and the cursor
        # before the icon, so the list moves right by the widest icon to keep both in the window.
        tags = max((item.tag.get_width() for item in menu.items if item.tag is not None), default=0)
        menu.render(
            surface,
            (left + pad + UISettings.MENU_LABEL_OFFSET + UISettings.MENU_HOOK_ROOM + tags
             - (UISettings.STROKE_MENU_NUDGE if menu is self.stroke_menu else 0),
             self._menu_top(surface, menu)),
            font_size=FontSettings.SIZE_BODY,
            row_height=row_height,
            max_rows=(rect.height - 2 * pad) // row_height,
        )
        if menu is self.list_menu and self._team_up_listing:
            self._render_team_up_mana(surface, rect)

    def _render_team_up_mana(self, surface: pygame.Surface, rect: pygame.Rect) -> None:
        """Beside the Team Up list, the one acting and the partner of the row under the cursor,
        each name over their mana as pips: lit up to what they have, dim for what is missing,
        so a grey row shows who is short without words (Frankie's drawing, 11/4)."""
        actor = self.battle.current_actor
        cursor = self.list_menu.cursor if self.list_menu is not None else 0
        partners = self._team_up_partners
        if actor is None or not 0 <= cursor < len(partners):
            return
        pad = UISettings.TEXT_BOX_PADDING
        size = FontSettings.SIZE_BODY
        pip_w, pip_h = UISettings.TEAM_UP_PIP_SIZE
        gap = UISettings.TEAM_UP_PIP_GAP
        cap = BattleSettings.MANA_CAP
        block_w = cap * (pip_w + gap) - gap
        line = size + 2 + pip_h + 6
        x = rect.right - pad - block_w
        y = rect.top + (rect.height - 2 * line + 6) // 2
        for member in (actor, partners[cursor]):
            short = member.mana < BattleSettings.COMBO_MANA
            text_renderer.draw_text(surface, short_name(member.id).upper(), (x, y),
                                    ColorSettings.GRAY if short else ColorSettings.WHITE, size=size)
            for pip in range(cap):
                color = BattleStageSettings.COLOR_MANA if pip < member.mana else UISettings.TEAM_UP_PIP_EMPTY
                surface.fill(color, (x + pip * (pip_w + gap), y + size + 2, pip_w, pip_h))
            y += line

    def _switch_window_rect(self, surface: pygame.Surface) -> pygame.Rect:
        """Return the small window just over the stance's name on the grid's top row."""
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        edge = UISettings.TEXT_BOX_BORDER_THICKNESS + 2
        cell_x = rect.left + pad + UISettings.MENU_LABEL_OFFSET + UISettings.ABILITY_LABEL_WIDTH
        actor = self.battle.current_actor
        names = [stance["name"] for stance in actor.stances] if actor is not None else []
        width = max((text_renderer.text_width(name, FontSettings.SIZE_BODY) for name in names), default=0)
        return pygame.Rect(cell_x - edge, rect.top + pad - edge,
                           width + 2 * edge, FontSettings.SIZE_BODY + 2 * edge)

    def _render_switch_window(self, surface: pygame.Surface) -> None:
        """Draw the window over the stance's name, the other stance's name flashing in its colour."""
        actor = self.battle.current_actor
        other = self.battle.other_stance(actor) if actor is not None else None
        if other is None:
            return
        window = self._switch_window_rect(surface)
        draw_window(surface, window)
        if int(time.monotonic() * UISettings.SWITCH_FLASH_HZ * 2) % 2 == 0:
            style = ColorSettings.ELEMENT_TEXT_STYLES.get(other["element"], {})
            edge = UISettings.TEXT_BOX_BORDER_THICKNESS + 2
            text_renderer.draw_text(
                surface, other["name"], (window.left + edge, window.top + edge),
                style.get("color") or ColorSettings.WHITE, size=FontSettings.SIZE_BODY,
                glow=style.get("glow"), glow_radius=style.get("glow_radius", 3),
                glow_alpha=style.get("glow_alpha", 90),
            )

    def _menu_top(self, surface: pygame.Surface, menu: Menu) -> int:
        """Return the y of a list menu's first row in the window.

        A menu that fits sits centred top to bottom (Frankie, 10/18);
        a longer one starts at the top and scrolls.
        """
        rect = self._hud_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        row_height = UISettings.COMMAND_MENU_ROW_HEIGHT
        border = UISettings.TEXT_BOX_BORDER_THICKNESS
        inner = rect.height - 2 * border
        block = (len(menu.items) - 1) * row_height + FontSettings.LETTER_WIDTH
        return (
            rect.top + border + (inner - block) // 2
            if len(menu.items) * row_height <= rect.height - 2 * pad
            else rect.top + pad
        )

    def _menu_row_rect(self, menu: Menu, index: int, surface: pygame.Surface | None = None) -> pygame.Rect:
        """Return the area of a list menu's row in the left window, its cursor included (Hina's highlight)."""
        surface = surface or self.gm.screen
        pad = UISettings.TEXT_BOX_PADDING
        y = self._menu_top(surface, menu) + index * UISettings.COMMAND_MENU_ROW_HEIGHT
        width = UISettings.COMMAND_PANEL_WIDTH - 2 * pad - UISettings.POINTS_BAR_WIDTH - 2
        return pygame.Rect(self._menu_left(menu, surface) + pad - 2, y - 4, width, UISettings.COMMAND_MENU_ROW_HEIGHT)

    def _grid_cell_rect(self, grid: GridMenu, row: int, col: int) -> pygame.Rect:
        """Return the area of one cell of the technique grid, its cursor included (Hina's highlight)."""
        rect = self._hud_rect(self.gm.screen)
        pad = UISettings.TEXT_BOX_PADDING
        x = (rect.left + pad + UISettings.MENU_LABEL_OFFSET + UISettings.ABILITY_LABEL_WIDTH
             + col * UISettings.ABILITY_COL_WIDTH)
        y = rect.top + pad + (row - grid._first_shown) * UISettings.ABILITY_MENU_ROW_HEIGHT
        return pygame.Rect(x - UISettings.MENU_LABEL_OFFSET - 3, y - 4,
                           UISettings.ABILITY_COL_WIDTH - 3, UISettings.ABILITY_MENU_ROW_HEIGHT)

    def _grid_row_rect(self, grid: GridMenu, row: int) -> pygame.Rect:
        """Return the area of a whole row of the technique grid (Hina's highlight)."""
        rect = self._hud_rect(self.gm.screen)
        pad = UISettings.TEXT_BOX_PADDING
        y = rect.top + pad + (row - grid._first_shown) * UISettings.ABILITY_MENU_ROW_HEIGHT
        return pygame.Rect(rect.left + pad - 2, y - 4, rect.width - 2 * pad + 4, UISettings.ABILITY_MENU_ROW_HEIGHT)

    def _points_rect(self) -> pygame.Rect:
        """Return the area of the stroke points' standing bar (Hina's highlight)."""
        rect = self._command_rect(self.gm.screen)
        pad = UISettings.TEXT_BOX_PADDING
        x = rect.right - pad - UISettings.POINTS_BAR_WIDTH + 2
        return pygame.Rect(x - 2, rect.top + pad - 2, UISettings.POINTS_BAR_WIDTH + 4, rect.height - 2 * pad + 4)

    def _render_points(self, surface: pygame.Surface) -> None:
        """Draw the stroke points left this turn as a standing bar at the panel's right edge.

        One segment a point, filled from the bottom, yellow while unspent.
        """
        rect = self._command_rect(surface)
        pad = UISettings.TEXT_BOX_PADDING
        total = BattleSettings.STROKE_POINTS
        left = self.battle.chain_points_left
        gap = UISettings.POINTS_BAR_GAP
        segment = (rect.height - 2 * pad + gap) // total - gap
        x = rect.right - pad - UISettings.POINTS_BAR_WIDTH + 2
        bottom = rect.bottom - pad
        for index in range(total):
            top = bottom - (index + 1) * segment - index * gap
            color = ColorSettings.YELLOW if index < left else UISettings.POINTS_BAR_SPENT
            pygame.draw.rect(
                surface, color,
                pygame.Rect(x, top, UISettings.POINTS_BAR_WIDTH, segment),
            )

    def _refresh_command_labels(self) -> None:
        """Grey out Item when nothing is left to use, and write the stroke rows.

        Each stroke reads "1 LIGHT  95%": its points, its name, its chance
        to land on the target. A stroke that no longer fits is grey; one
        that spends the last points, ending the turn, is yellow
        (Frankie, 10/18).
        """
        self.command_menu.items[_ITEM_ROW].enabled = bool(self._bag_counts())
        # Every enemy down but one waiting to rise (Green Dream): Attack had no one to point at and
        # did nothing, with no word (Completionists Episode 3, 11/17). Grey it and say why.
        attack = self.command_menu.items[_ATTACK_ROW]
        attack.enabled = any(c.alive for c in self.battle.enemies)
        attack.why = None if attack.enabled else "No enemy is standing to hit."
        # Skill by its name (D-692), the one for the weapon type in hand
        # (Frankie, 10/31); a Skill still on paper shows grey.
        skill = self._held_skill(self.battle.current_actor)
        tech = self.command_menu.items[_TECH_ROW]
        tech.label = skill["name"] if skill else "Skill"
        # In mana debt, no Skill until it is built back to 0 (Frankie, 11/1 late).
        # Nobody cooks underwater (Frankie, 11/17).
        wet = skill is not None and skill["id"] == "cook" and self.battle.underwater
        tech.why = SwimSettings.NO_COOK_WHY if wet else None
        tech.enabled = (skill is not None and skill["id"] in _SKILLS_BUILT and not wet
                        and self.battle.can_use_skill(self.battle.current_actor)
                        # One spirit at a time: Call waits until it is gone (Frankie, 11/2).
                        and not (skill["id"] == "call_the_dead" and self.battle.spirit_out))
        if self.stroke_menu is not None:
            left = self.battle.chain_points_left
            lightest = BattleSettings.STROKES["light"]["points"]
            target = self._stroke_target()
            for row, kind in enumerate(_STROKE_KINDS):
                stroke = BattleSettings.STROKES[kind]
                item = self.stroke_menu.items[row]
                item.enabled = stroke["points"] <= left
                item.color = (
                    ColorSettings.YELLOW if left - stroke["points"] < lightest else None
                )
                chance = (
                    f"{round(100 * self.battle.stroke_chance(kind, target)):>3}%"
                    if target is not None else ""
                )
                item.label = f"{stroke['points']} {stroke['name']:<6}{chance}"
            # A cursor left on a stroke that no longer fits drops to the
            # heaviest that does, so confirm never lands on grey (the 10/26
            # Let's Play sat on Strong with 1 point left and thought it froze).
            cursor = self.stroke_menu.cursor
            if cursor < len(_STROKE_KINDS) and not self.stroke_menu.items[cursor].enabled:
                fits = [row for row in range(len(_STROKE_KINDS)) if self.stroke_menu.items[row].enabled]
                if fits:
                    self.stroke_menu.cursor = fits[-1]

    # ------------------------------------------------------------------
    # UPDATE
    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        """Play narration, start the next turn, and leave when done."""
        if self.swirl is not None:
            self.swirl.update(dt)
            if self.swirl.done:
                self.swirl = None
            return
        self.text_box.update(dt)
        if self._sayings and self.text_box.is_done() and self.talk_box.is_done():
            speaker, line = self._sayings.popleft()
            self.talk_box.push(line, speaker=speaker)
            if speaker == "Hina" and line == TutorialSettings.DODGE_PRAISE:
                self.gm.audio.play("scold_nag")  # Nagging Mumble with her grudging praise (Frankie, 11/11)
        elif self._after_talk and not self._talking() and self.text_box.is_done():
            if self._jingle_due:
                self._jingle_due = False
                self.gm.audio.play("learned")
            line = self._after_talk.popleft()
            if isinstance(line, tuple):
                self._say(*line)
            else:
                self.text_box.push(line)
        self.talk_box.update(dt)
        self.notices.update(dt)
        if self._why is not None:
            self._why = (self._why[0], self._why[1] - dt) if self._why[1] > dt else None
        self.stage.update(dt, self._shown_hp)
        self._beat = max(0.0, self._beat - dt)
        if self._settle > 0 and self._commands_up():
            self._settle -= dt
        self._hold_narration(dt)
        if self._guiding_slot():
            self._hold_slot_cursor()
        if self.tutorial is not None and self.tutorial.holds():
            # The fight waits while Hina asks or talks.
            self.tutorial.update(dt)
            return
        self._play_events()
        if self.meter is not None:
            self._run_meter(dt)
            return
        if self.paddle is not None:
            self._run_paddle(dt)
        if self.spin is not None:
            self._run_wili(dt)
        if self.banish is not None:
            self._run_banish(dt)
        if self.pound is not None:
            self._run_pound(dt)
            return
        if self.minigame is not None:
            self._run_minigame(dt)
            return
        if self.tutorial is not None:
            # Before the next turn starts, so a word between turns comes first.
            self.tutorial.update(dt)
            if self.tutorial.holds():
                return
        self._teach_team_up()
        if (
            not self.battle.is_over
            and not self.battle.is_awaiting_command()
            and not self.battle.is_awaiting_block()
            and not self._events
            and self._beat <= 0
            and self.text_box.is_done()
            and not self.stage.numbers_hopping()  # the last number lands before the next turn (Frankie, 11/17)
            and not self._talking()
            and not self._after_talk
        ):
            if self._turn_pause_due:
                # A beat between turns, a little longer than between hits (Frankie, 11/17).
                self._turn_pause_due = False
                self._beat = BattleSettings.TURN_BEAT_SECONDS
                return
            self._turn_pause_due = True
            self._dispatch(self.battle.start_turn())
            if self.battle.is_awaiting_command():
                self._open_commands()
            self._play_events()
        if self._battle_finished and self.victory is not None and self.text_box.is_done():
            # Won: a moment on the fallen field, then the victory screen;
            # once it closes, back to the field.
            if self._victory_shown:
                self.gm.scene_stack.pop()
                return
            self._victory_hold += dt
            if self._victory_hold >= VictorySettings.HOLD_SECONDS:
                self._victory_shown = True
                self.gm.scene_stack.push(VictoryScene(self.gm, self.victory))
            return
        if self._battle_finished and self.text_box.is_done() and self.notices.is_done():
            if self.battle.outcome == "defeat" and not self.story:
                # After "The party has fallen.": GAME OVER, then the title (D-148).
                game_over(self.gm)
                return
            self.gm.scene_stack.pop()
