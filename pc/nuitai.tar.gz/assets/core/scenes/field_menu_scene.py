"""The field menu, Final Fantasy VI's commands in Super Mario RPG's floating windows (Frankie, 11/21).

The main screen (``field_menu_main.py``): the party on the field, darkened, a small window per fighter, the
commands as a plain list with the hook on one, and a window with the pule, the kupang and the time. A or right opens
the command under the hook; B closes the menu. Up and down move the hook, which wraps.

Items is one screen of its own (``field_items.py``). The other commands, Element, Equip, Status, Party, Info and
Config, keep the pages they had under the tabs (``field_menu_pages.py``) until they are redesigned: the three who
fight in a column on the left and the page on the right, the open command's name across the top. Where the hook can
be on one of those (``focus``): in the **page**, or on the **column** (left from a page's left edge moves it there:
up and down pick a member, A opens that member's page, A on another on the Party page swaps their places, Y flips
the stance a member starts a fight in; right or B goes back). B on a page closes it, back to the commands.

Each page wraps the scene that held that screen's rules before, so every action the old menu had still works.

Run it: the X button on the field (``overworld_scene``) opens it.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from core.shared import by_id
from settings import BattleSettings, ColorSettings, FontSettings
from ui import input_map, text_renderer
from ui import field_menu_kit as kit
from ui import hook_nav
from core.scenes import field_menu_main as main_screen

if TYPE_CHECKING:
    from main import GameManager

TABS = main_screen.COMMANDS            # the commands, in the order the list shows them
FOCUS_COLUMN, FOCUS_MAIN, FOCUS_PAGE, FOCUS_PARTY = "column", "main", "page", "party"
NO_COLUMN = ("Info", "Config")          # these two do not involve the party


class FieldMenuScene(Scene):
    """The field menu."""

    @property
    def OPAQUE(self) -> bool:
        """The field shows through (darkened) on the main screen and Items; an old page fills the screen."""
        return not (self.focus in (FOCUS_MAIN, FOCUS_PARTY) or (self.page is not None and self.page.full))

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        from core.scenes import field_menu_pages as pages

        self._pages = pages
        self.tab = 0
        self.focus = FOCUS_MAIN
        self.member = 0                  # the member the pages are about, a place in ``gm.party.members``
        self._order_from: int | None = None
        self._spot = ("name", 0)         # on the main screen's party: where the hook is on the member (spot, element slot)
        self._column_from = FOCUS_PAGE   # where the hook goes back to from the column
        self.page = None                 # the open tab's page while the hook is in it
        self._previews: dict[str, object] = {}   # pages at rest, drawn while the hook is on the column with no page open
        self.lay = kit.Layout(gm)

    # ------------------------------------------------------------------
    # WHO
    # ------------------------------------------------------------------

    def fighters(self) -> list:
        """The three who fight, the only ones the column shows."""
        return self.gm.party.members[:BattleSettings.FIGHTERS]

    def member_obj(self):
        members = self.gm.party.members
        return members[min(self.member, len(members) - 1)] if members else None

    def sync_member(self, member) -> None:
        """A page switched member (L1, R1): follow it."""
        members = self.gm.party.members
        for index, one in enumerate(members):
            if one is member:
                self.member = index

    # ------------------------------------------------------------------
    # PAGES
    # ------------------------------------------------------------------

    def _preview_page(self, name: str):
        """The tab's page as it looks at rest, for drawing while the hook is on the tabs or the column."""
        if name not in self._previews:
            self._previews[name] = self._pages.make_page(name, self, preview=True)
        return self._previews[name]

    def _open_page(self) -> None:
        self._previews.clear()
        self.page = self._pages.make_page(TABS[self.tab], self)
        self.focus = FOCUS_PAGE
        self.gm.audio.play("menu_select")

    def _reopen_page(self) -> None:
        """Rebuild the open page for the member just picked."""
        if self.page is not None:
            self.page.close()
            self.page = self._pages.make_page(TABS[self.tab], self)

    def _close_page(self) -> None:
        if self.page is not None:
            self.page.close()
        self.page = None
        self._previews.clear()
        self.focus = FOCUS_MAIN

    def on_exit(self) -> None:
        """Whatever the open page was holding (Config's buttons) is let go."""
        if self.page is not None:
            self.page.close()
            self.page = None

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    clock: float | None = None        # a test or a still sets the idle's time; None is the real clock

    def update(self, dt: float) -> None:
        if self.page is not None:
            self.page.update(dt)

    def handle_event(self, event: pygame.event.Event) -> None:
        if self.focus == FOCUS_PAGE and self.page is not None:
            if input_map.is_left(event) and self.page.wants_column() and self.fighters():
                # left goes to the member's row nearest the hook, measured on screen (Frankie, 11/13)
                self._column_from = FOCUS_PAGE
                self.focus = FOCUS_COLUMN
                before = self.member
                near = hook_nav.nearest(self.page.hook_pos(), "left", self._column_anchors())
                self.member = near if near is not None else min(self.member, len(self.fighters()) - 1)
                if self.member != before:
                    self._previews.clear()
                    self._reopen_page()
                self.gm.audio.play("menu_move")
                return
            result = self.page.handle(event)
            if result == "back":
                self.gm.audio.play("menu_select")
                self._close_page()
            elif result == "column" and self.fighters():
                self._column_from = FOCUS_PAGE
                self.focus = FOCUS_COLUMN
                self.member = len(self.fighters()) - 1
                self._previews.clear()
                self._reopen_page()
                self.gm.audio.play("menu_move")
            return
        if self.focus == FOCUS_COLUMN:
            self._handle_column(event)
            return
        if self.focus == FOCUS_PARTY:
            self._handle_party(event)
            return
        self._handle_main(event)

    def _handle_party(self, event: pygame.event.Event) -> None:
        """The hook on the main screen's party windows (Frankie, 11/21). Each window has four places: the sprite, the name
        and HP, and the two elements. Left and right move across them (right from the name or the last element goes back
        to the commands); up and down go through the rows, the name then the elements of each member. Y flips the starting
        stance from anywhere on the window; A on an element picks it as the starting stance, A on the sprite opens their
        Status page, A on the name swaps places: A on one, then A on another (Claude's keys, 11/21). B drops a swap
        in hand, else goes back to the commands."""
        audio = self.gm.audio
        count = len(self.fighters())
        member = self.fighters()[self.member]
        spot, slot = self._spot
        if input_map.is_cancel(event):
            if self._order_from is not None:
                self._order_from = None
            else:
                self.focus = FOCUS_MAIN
            audio.play("menu_move")
        elif input_map.is_left(event):
            if spot == "name" or (spot == "element" and slot == 0):
                self._spot = ("sprite", 0)
            elif spot == "element":
                self._spot = ("element", slot - 1)
            else:
                return
            audio.play("menu_move")
        elif input_map.is_right(event):
            if spot == "sprite":
                self._spot = ("name", 0)
            elif spot == "element" and slot < len(member.elements) - 1:
                self._spot = ("element", slot + 1)
            else:
                self.focus = FOCUS_MAIN
            audio.play("menu_move")
        elif input_map.is_up(event):
            if spot == "element":
                self._spot = ("name", 0)
            elif self.member > 0:
                self.member -= 1
                prior = self.fighters()[self.member]
                self._spot = ("element", 0) if spot == "name" and prior.elements else (spot, 0)
            audio.play("menu_move")
        elif input_map.is_down(event):
            if spot == "name" and member.elements:
                self._spot = ("element", 0)
            elif spot == "element" and self.member < count - 1:
                self.member += 1
                self._spot = ("name", 0)
            elif spot != "element" and self.member < count - 1:
                self.member += 1
            audio.play("menu_move")
        elif input_map.is_tool(event):
            self._flip_stance(member)
        elif input_map.is_confirm(event):
            if spot == "element":
                self._pick_stance(member, slot)
            elif spot == "sprite":
                self._order_from = None
                self.tab = TABS.index("Status")
                self._open_page()
            else:
                members = self.gm.party.members
                audio.play("menu_select")
                if self._order_from is None:
                    self._order_from = self.member
                else:
                    first, self._order_from = self._order_from, None
                    if first != self.member:
                        members[first], members[self.member] = members[self.member], members[first]

    def _stances(self, member) -> list:
        return by_id("characters").get(member.id, {}).get("stances", [])

    def _flip_stance(self, member) -> None:
        if len(self._stances(member)) > 1:
            member.stance = 1 - member.stance
            self.gm.audio.play("menu_select")

    def _pick_stance(self, member, slot: int) -> None:
        """A on an element: the stance that element belongs to is the one they start in."""
        if slot >= len(member.elements):
            return
        for index, stance in enumerate(self._stances(member)):
            if stance.get("element") == member.elements[slot]:
                member.stance = index
                self.gm.audio.play("menu_select")
                return

    def _handle_main(self, event: pygame.event.Event) -> None:
        """The hook on the command list: up and down move it, A or right opens the command, B closes the menu."""
        audio = self.gm.audio
        count = len(TABS)
        if input_map.is_cancel(event):
            audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif input_map.is_up(event):
            self.tab = (self.tab - 1) % count
            audio.play("menu_move")
        elif input_map.is_down(event):
            self.tab = (self.tab + 1) % count
            audio.play("menu_move")
        elif input_map.is_left(event) and self.fighters():
            self.focus, self.member, self._spot = FOCUS_PARTY, 0, ("name", 0)
            audio.play("menu_move")
        elif input_map.is_confirm(event) or input_map.is_right(event):
            self._open_page()

    def _handle_column(self, event: pygame.event.Event) -> None:
        """The hook on the column: pick a member, order the three, flip a stance."""
        audio = self.gm.audio
        count = len(self.fighters())
        if input_map.is_cancel(event):
            if self._order_from is not None:
                self._order_from = None
            else:
                self._leave_column()
            audio.play("menu_move")
        elif input_map.is_right(event):
            self._order_from = None
            self._enter_page_from_column()
        elif input_map.is_tool(event):
            member = self.fighters()[self.member]
            if len(by_id("characters").get(member.id, {}).get("stances", [])) > 1:
                member.stance = 1 - member.stance
                audio.play("menu_select")
        elif input_map.is_up(event):
            if self.member == 0:
                self._order_from = None       # nothing above the first member
            else:
                self.member -= 1
                self._previews.clear()
                self._reopen_page()
            audio.play("menu_move")
        elif input_map.is_down(event):
            if self.member < count - 1:
                self.member += 1
                self._previews.clear()
                self._reopen_page()
                audio.play("menu_move")
            else:
                # the last member: the page may have something directly below the column (Equip's bar)
                page = self.page if self.page is not None else self._preview_page(TABS[self.tab])
                if page.below_column():
                    self._order_from = None
                    if self.page is None:
                        self._open_page()
                    self.page.enter_below_column()
                    self.focus = FOCUS_PAGE
                    audio.play("menu_move")
        elif input_map.is_confirm(event) and TABS[self.tab] != "Party":
            # Ordering is the Party tab's alone; on every other tab A on a member opens that member's page (11/13).
            self._order_from = None
            self._enter_page_from_column()
        elif input_map.is_confirm(event):
            members = self.gm.party.members
            audio.play("menu_select")
            if self._order_from is None:
                self._order_from = self.member
            else:
                first, self._order_from = self._order_from, None
                if first != self.member:
                    members[first], members[self.member] = members[self.member], members[first]

    def _column_anchors(self) -> list:
        """Where the hook hangs on each of the column's rows: (member place, (x, y))."""
        return [(i, (self.lay.text_x - 6, kit.row_y(i) + 12)) for i in range(len(self.fighters()))]

    def _enter_page_from_column(self) -> None:
        """Right from the column goes to what is level with the member's row on the right (Frankie, 11/13)."""
        origin = self._column_anchors()[min(self.member, len(self.fighters()) - 1)][1]
        if self.page is None:
            self._open_page()
        else:
            self.focus = FOCUS_PAGE
            self.gm.audio.play("menu_move")
        near = hook_nav.nearest(origin, "right", self.page.anchors())
        if near is not None:
            self.page.enter(near)

    def _leave_column(self) -> None:
        """Back to where the hook came from: the page it left, else the commands."""
        self.focus = FOCUS_PAGE if self.page is not None else FOCUS_MAIN
        self._previews.clear()

    # ------------------------------------------------------------------
    # DRAWING
    # ------------------------------------------------------------------

    def render(self, surface: pygame.Surface) -> None:
        stack = getattr(self.gm.scene_stack, "_stack", [])
        if not stack or stack[0] is self:
            surface.fill((0, 0, 0))            # nothing under the menu to show through
        if self.focus in (FOCUS_MAIN, FOCUS_PARTY):
            main_screen.darken(surface)
            on_party = self.focus == FOCUS_PARTY
            main_screen.draw_main(surface, self.gm.party, self.fighters(), self.tab,
                                  party_hook=(self.member, *self._spot) if on_party else None,
                                  held=self._order_from)
            return
        name = TABS[self.tab]
        page = self.page if self.page is not None else self._preview_page(name)
        if page.full:
            main_screen.darken(surface)
            page.render(surface, self.lay, active=True)
            page.render_over(surface)
            return
        surface.fill((0, 0, 0))
        kit.draw_tabs(surface, name, lit=False)         # the open command's name across the top
        show_column = name not in NO_COLUMN
        lit_member = page.column_member() if page is not None else None
        if show_column:
            kit.draw_column(surface, self.lay, self.fighters(), lit_member if lit_member is not None else self.member,
                            hook_row=self._column_hook(page),
                            marked=(lit_member if lit_member is not None else self.member) if page.shows_member else None,
                            seconds=self.clock,
                            held=self._order_from if self.focus == FOCUS_COLUMN else page.column_held())
        page.render(surface, self.lay, active=self.focus == FOCUS_PAGE)
        kit.draw_bottom(surface, self.gm.party, self.bottom_content(page), active=self.focus == FOCUS_PAGE)
        page.render_over(surface)

    def bottom_content(self, page=None) -> tuple:
        """What the bottom window shows: the page's words only while the hook is on the page, so it goes back
        to the money the moment the hook leaves an item for the tabs or the column. Every tab, one place."""
        page = page if page is not None else self.page
        if self.focus != FOCUS_PAGE or page is None:
            return ("money",)
        return page.bottom()

    def _column_hook(self, page) -> int | None:
        """Which column row the hook is on, if it is on the column."""
        if self.focus == FOCUS_COLUMN:
            return self.member
        if self.focus == FOCUS_PAGE and self.page is not None:
            return self.page.column_hook()
        return None
