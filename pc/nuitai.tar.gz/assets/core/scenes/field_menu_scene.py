"""The field menu, Dragon Quest VIII's way (Frankie, 11/13): tabs across the top, the party always on the left.

Seven tabs, Items, Element, Equip, Status, Party, Info and Config, each an icon (the 16 by 16 files in
``assets/ui/tabs``, Frankie redraws them), the open one with its word. The three who fight stay in a column
on the left on every tab and only the right side changes. A full width window along the bottom says what the
hook is on, or shows the money while it is not on an item.

Where the hook can be (``focus``): on the **column**, on the **tabs**, or in the **page** of the open tab.
Open on the tabs. Down from the tabs lands on the first member in the column, and right from there opens
the page (on Info and Config, which have no column, down opens the page); A opens it at once. L and R change the tab from anywhere in the menu (Frankie, 11/13). On the tabs, left and
right move between them; down or A opens the page; B steps back one, page to tabs, tabs to closing the menu.
Left from a page's left edge (or from the first tab) moves the hook onto the column: up and down pick a member
(who the pages are about), A picks one and A on another swaps their places (the first three fight), Y
flips the stance a member starts a fight in; right or B goes back to where the hook came from.

The pages are in ``field_menu_pages.py``; each wraps the scene that held that screen's rules before, so
every action the old menu had still works, only the drawing is new.

Run it: the X button on the field (``overworld_scene``) opens it.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from core.shared import by_id
from settings import BattleSettings, ColorSettings, FontSettings
from ui import input_map, text_renderer
from ui import field_menu_kit as kit
from ui import hook_nav

if TYPE_CHECKING:
    from main import GameManager

TABS = ("Items", "Element", "Equip", "Status", "Party", "Info", "Config")
FOCUS_COLUMN, FOCUS_TABS, FOCUS_PAGE = "column", "tabs", "page"
NO_COLUMN = ("Info", "Config")          # these two do not involve the party


class FieldMenuScene(Scene):
    """The tabbed field menu."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        from core.scenes import field_menu_pages as pages

        self._pages = pages
        self.tab = 0
        self.focus = FOCUS_TABS
        self.member = 0                  # the member the pages are about, a place in ``gm.party.members``
        self._order_from: int | None = None
        self._column_from = FOCUS_TABS   # where the hook goes back to from the column
        self.page = None                 # the open tab's page while the hook is in it
        self._previews: dict[str, object] = {}   # the tabs' pages at rest, drawn while the hook is on the tabs
        self.lay = kit.Layout(gm)

    # ------------------------------------------------------------------
    # WHO
    # ------------------------------------------------------------------

    def fighters(self) -> list:
        """The three who fight, the only ones the column shows."""
        return self.gm.party.members[:BattleSettings.FIGHTERS]

    def member_obj(self):
        members = self.gm.party.members
        return members[min(self.member, len(members) - 1)] if members else None

    def sync_member(self, member) -> None:
        """A page switched member (L1, R1): follow it."""
        members = self.gm.party.members
        for index, one in enumerate(members):
            if one is member:
                self.member = index

    # ------------------------------------------------------------------
    # PAGES
    # ------------------------------------------------------------------

    def _preview_page(self, name: str):
        """The tab's page as it looks at rest, for drawing while the hook is on the tabs or the column."""
        if name not in self._previews:
            self._previews[name] = self._pages.make_page(name, self, preview=True)
        return self._previews[name]

    def _open_page(self) -> None:
        self._previews.clear()
        self.page = self._pages.make_page(TABS[self.tab], self)
        self.focus = FOCUS_PAGE
        self.gm.audio.play("menu_select")

    def change_tab(self, step: int) -> None:
        """L and R: the next or last tab, from anywhere; an open page closes and the new tab's opens."""
        was_page = self.focus == FOCUS_PAGE
        if self.page is not None:
            self.page.close()
            self.page = None
        self.tab = (self.tab + step) % len(TABS)
        self._previews.clear()
        self._order_from = None
        self.gm.audio.play("menu_move")
        if was_page:
            self.page = self._pages.make_page(TABS[self.tab], self)
            self.focus = FOCUS_PAGE
        elif self.focus == FOCUS_COLUMN and TABS[self.tab] in NO_COLUMN:
            self.focus = FOCUS_TABS
        elif self.focus == FOCUS_COLUMN and self._column_from == FOCUS_PAGE:
            self._column_from = FOCUS_TABS

    def _reopen_page(self) -> None:
        """Rebuild the open page for the member just picked."""
        if self.page is not None:
            self.page.close()
            self.page = self._pages.make_page(TABS[self.tab], self)

    def _close_page(self) -> None:
        if self.page is not None:
            self.page.close()
        self.page = None
        self._previews.clear()
        self.focus = FOCUS_TABS

    def on_exit(self) -> None:
        """Whatever the open page was holding (Config's buttons) is let go."""
        if self.page is not None:
            self.page.close()
            self.page = None

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        if self.page is not None:
            self.page.update(dt)

    def handle_event(self, event: pygame.event.Event) -> None:
        if (input_map.is_l1(event) or input_map.is_r1(event)) and not (
                self.page is not None and self.page.blocking()):
            self.change_tab(-1 if input_map.is_l1(event) else 1)
            return
        if self.focus == FOCUS_PAGE and self.page is not None:
            if input_map.is_left(event) and self.page.wants_column() and self.fighters():
                # left goes to the member's row nearest the hook, measured on screen (Frankie, 11/13)
                self._column_from = FOCUS_PAGE
                self.focus = FOCUS_COLUMN
                before = self.member
                near = hook_nav.nearest(self.page.hook_pos(), "left", self._column_anchors())
                self.member = near if near is not None else min(self.member, len(self.fighters()) - 1)
                if self.member != before:
                    self._previews.clear()
                    self._reopen_page()
                self.gm.audio.play("menu_move")
                return
            if self.page.handle(event) == "back":
                self.gm.audio.play("menu_select")
                self._close_page()
            return
        if self.focus == FOCUS_COLUMN:
            self._handle_column(event)
            return
        self._handle_tabs(event)

    def _handle_tabs(self, event: pygame.event.Event) -> None:
        audio = self.gm.audio
        if input_map.is_cancel(event):
            audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif input_map.is_left(event):
            if self.tab == 0:
                if self.fighters():
                    self._column_from = FOCUS_TABS
                    self.focus = FOCUS_COLUMN
                    self.member = min(self.member, len(self.fighters()) - 1)
                    audio.play("menu_move")
            else:
                self.tab -= 1
                self._previews.clear()
                audio.play("menu_move")
        elif input_map.is_right(event):
            if self.tab < len(TABS) - 1:
                self.tab += 1
                self._previews.clear()
                audio.play("menu_move")
        elif input_map.is_down(event) and TABS[self.tab] not in NO_COLUMN and self.fighters():
            # Down from the tabs lands on the first member in the column; right from there opens the page.
            self._column_from = "tabs_down"
            self.focus = FOCUS_COLUMN
            self.member = 0
            audio.play("menu_move")
        elif input_map.is_down(event) or input_map.is_confirm(event):
            self._open_page()

    def _handle_column(self, event: pygame.event.Event) -> None:
        """The hook on the column: pick a member, order the three, flip a stance."""
        audio = self.gm.audio
        count = len(self.fighters())
        if input_map.is_cancel(event):
            if self._order_from is not None:
                self._order_from = None
            else:
                self._leave_column()
            audio.play("menu_move")
        elif input_map.is_right(event):
            self._order_from = None
            self._enter_page_from_column()
        elif input_map.is_tool(event):
            member = self.fighters()[self.member]
            if len(by_id("characters").get(member.id, {}).get("stances", [])) > 1:
                member.stance = 1 - member.stance
                audio.play("menu_select")
        elif input_map.is_up(event):
            if self.member == 0:
                # nothing above the first member but the tabs
                self._order_from = None
                self.focus = FOCUS_TABS
            else:
                self.member -= 1
                self._previews.clear()
                self._reopen_page()
            audio.play("menu_move")
        elif input_map.is_down(event):
            if self.member < count - 1:
                self.member += 1
                self._previews.clear()
                self._reopen_page()
                audio.play("menu_move")
        elif input_map.is_confirm(event):
            members = self.gm.party.members
            audio.play("menu_select")
            if self._order_from is None:
                self._order_from = self.member
            else:
                first, self._order_from = self._order_from, None
                if first != self.member:
                    members[first], members[self.member] = members[self.member], members[first]

    def _column_anchors(self) -> list:
        """Where the hook hangs on each of the column's rows: (member place, (x, y))."""
        return [(i, (self.lay.text_x - 6, kit.row_y(i) + 12)) for i in range(len(self.fighters()))]

    def _enter_page_from_column(self) -> None:
        """Right from the column goes to what is level with the member's row on the right (Frankie, 11/13)."""
        origin = self._column_anchors()[min(self.member, len(self.fighters()) - 1)][1]
        if self.page is None:
            self._open_page()
        else:
            self.focus = FOCUS_PAGE
            self.gm.audio.play("menu_move")
        near = hook_nav.nearest(origin, "right", self.page.anchors())
        if near is not None:
            self.page.enter(near)

    def _leave_column(self) -> None:
        """Back to where the hook came from: the page it left, else the tabs."""
        self.focus = FOCUS_PAGE if self._column_from == FOCUS_PAGE and self.page is not None else FOCUS_TABS
        self._previews.clear()

    # ------------------------------------------------------------------
    # DRAWING
    # ------------------------------------------------------------------

    def render(self, surface: pygame.Surface) -> None:
        surface.fill((6, 21, 43))
        name = TABS[self.tab]
        kit.draw_tabs(surface, name, lit=self.focus == FOCUS_TABS)
        show_column = name not in NO_COLUMN
        page = self.page if self.page is not None else self._preview_page(name)
        lit_member = page.column_member() if page is not None else None
        if show_column:
            kit.draw_column(surface, self.lay, self.fighters(), lit_member if lit_member is not None else self.member,
                            hook_row=self._column_hook(page),
                            held=self._order_from if self.focus == FOCUS_COLUMN else page.column_held())
        page.render(surface, self.lay, active=self.focus == FOCUS_PAGE)
        kit.draw_bottom(surface, self.gm.party, page.bottom(), active=self.focus == FOCUS_PAGE)
        page.render_over(surface)

    def _column_hook(self, page) -> int | None:
        """Which column row the hook is on, if it is on the column."""
        if self.focus == FOCUS_COLUMN:
            return self.member
        if self.focus == FOCUS_PAGE and self.page is not None:
            return self.page.column_hook()
        return None
