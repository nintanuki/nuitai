"""Quests, under Info: the log of what the player has been asked to do (Frankie, 11/12).

Drawn in Data's layout like Lore's lists: a box saying Quests, the help
window with the short description of the quest under the hook, then a row
per quest. The open ones come first and the finished ones below, in gray
with Done on the right. The hunts are rows of the same list, each starting
"Hunt: ". What is on it is ``systems/quests.py``'s, read from the story flags.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from settings import ColorSettings, FontSettings, ScreenSettings, UISettings
from systems import quests
from ui import input_map, text_renderer
from ui.window import draw_header
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager

_LIST_TOP_Y = UISettings.HEADER_LIST_TOP
_LIST_LEFT_X = 16 + UISettings.MENU_HOOK_ROOM
_RIGHT_X = ScreenSettings.RESOLUTION[0] - 16
_ROW_HEIGHT = 16
# A hunt's name ("Hunt: five nuno sa punso, 0/5") runs to the window's inside edge, as Lore's titles do.
NAME_RIGHT_X = 248
_DONE = "Done"
EMPTY = ("No quests yet.", "Talk to people and look around.")


class QuestScene(Scene):
    """The quest list; up and down move, cancel goes back to Info."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        self._cursor = 0

    def entries(self) -> list[quests.Quest]:
        """The log as it stands now: read afresh from the flags each time."""
        return quests.log(self.gm.party, self.gm.data.load("bounties").values())

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move the cursor, or go back."""
        count = len(self.entries())
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif count and (input_map.is_up(event) or input_map.is_down(event)):
            self._cursor = (self._cursor + (-1 if input_map.is_up(event) else 1)) % count
            self.gm.audio.play("menu_move")

    def help_lines(self, entries: list[quests.Quest]) -> list[str]:
        """The description of the quest under the hook, two lines at most."""
        if not entries:
            return list(EMPTY)
        font = text_renderer.get_font(FontSettings.SIZE_BODY)
        width = _RIGHT_X - UISettings.HEADER_TEXT_X
        return text_renderer.wrap(entries[self._cursor].text, font, width)[:2]

    def render(self, surface: pygame.Surface) -> None:
        """The top boxes with the description, and a row per quest."""
        render_scene_background(self, surface)
        entries = self.entries()
        self._cursor = min(self._cursor, max(0, len(entries) - 1))
        draw_header(surface, "Quests", self.help_lines(entries))
        size = FontSettings.SIZE_BODY
        for index, quest in enumerate(entries):
            y = _LIST_TOP_Y + index * _ROW_HEIGHT
            color = ColorSettings.GRAY if quest.done else ColorSettings.WHITE
            text_renderer.draw_text(surface, quest.name, (_LIST_LEFT_X, y), color=color, size=size)
            if quest.done:
                text_renderer.draw_text(surface, _DONE, (_RIGHT_X - text_renderer.text_width(_DONE, size), y),
                                        color=color, size=size)
            if index == self._cursor:
                text_renderer.draw_pointer(surface, (_LIST_LEFT_X - 4, y + 3))
