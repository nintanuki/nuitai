"""The field menu's Status screen (Frankie, 11/21): the calm layout from before the tabs in the floating style, one
member at a time.

Two windows and a line of help. On top the member: sprite, name, HP and the two element icons, the one they start fights
in boxed in yellow, with the L and R buttons at the edges to change member. In the big window below, the eight stats with
their growth meters on the left; on the right a small preview of the member's element grid (a solid color for a one-element
move, split on the diagonal for a two-element one, an empty slot black, a slot not yet open not drawn) above the "EXP to
next" bar, which keeps the last stat when the hook is up on an icon. No job title, no Skill (Skills belong to weapons)
and no stance names: the icons stand for the stances, and the hook on an icon says which stance it is.

Up and down move over the stats; up from the first reaches the icons. A on an icon makes it the stance they start in; A on
a stat flips the stance, as the old page did, and Y flips it from anywhere. The rules are ``PartyScene``'s.
"""

from __future__ import annotations

import pygame

from core.factories import first_loadout, known_moves, stance_numbers
from core.scenes.field_element import shoulder
from core.scenes.field_menu_main import M, G, blit32
from core.scenes.field_menu_pages import Page
from core.scenes.party_scene import _STAT_ROWS, draw_notches, exp_points
from core.shared import by_id, short_name
from settings import ColorSettings, FontSettings, UISettings
from systems.battle import _GROWTH
from systems.loadout import checked, open_slots, slot_grid
from ui import input_map, text_renderer
from ui.element_tag import tag_elements
from ui.field_menu_kit import GRAY, WHITE, YELLOW, box, more_arrow, paged, text, width
from utils.graphics import load_element_icon

SIZE = FontSettings.SIZE_BODY
W = 256 - 2 * M
TOP_H, DESC_H = 36, 28
BODY_Y = M + TOP_H + G
DESC_Y = 224 - M - DESC_H
BODY_H = DESC_Y - 4 - BODY_Y
EXP_FRAME, EXP_FILL, EXP_TEXT = (200, 164, 106), (150, 36, 24), (240, 226, 192)
HELP = {
    "hp": "Each point adds ten HP.",
    "strength": "Makes physical hits stronger.",
    "magic": "Boosts magic and healing.",
    "vitality": "Cuts damage from weapons.",
    "spirit": "Cuts damage from magic.",
    "speed": "Your turns come sooner.",
    "accuracy": "More of your hits land.",
    "evasion": "You dodge more attacks.",
}


class StatusScreen(Page):
    """Zones: ``stat`` (the hook on a stat) and ``icon`` (on one of the two element icons)."""

    full = True

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        self.member = menu.member_obj()
        self.zone = "stat"
        self.row = 0                          # the stat the hook is on, kept while it is on an icon
        self.icon = 0
        self.last_hook: pygame.Rect | None = None

    def _stances(self) -> list:
        return by_id("characters").get(self.member.id, {}).get("stances", [])

    def _flip(self) -> None:
        if len(self._stances()) > 1:
            self.member.stance = 1 - self.member.stance
            self.gm.audio.play("menu_select")

    def _switch(self, step: int) -> None:
        members = self.gm.party.members
        if len(members) < 2:
            return
        index = next((i for i, m in enumerate(members) if m is self.member), 0)
        self.member = members[(index + step) % len(members)]
        self.menu.sync_member(self.member)
        self.icon = min(self.icon, max(0, len(self.member.elements) - 1))
        self.gm.audio.play("menu_move")

    # -- input -------------------------------------------------------------------------------------

    def handle(self, event) -> str | None:
        audio = self.gm.audio
        if input_map.is_cancel(event):
            return "back"
        if input_map.is_l1(event) or input_map.is_r1(event):
            self._switch(-1 if input_map.is_l1(event) else 1)
        elif input_map.is_tool(event):
            self._flip()
        elif self.zone == "stat":
            if input_map.is_up(event):
                if self.row == 0 and self.member.elements:
                    self.zone, self.icon = "icon", 0
                else:
                    self.row = (self.row - 1) % len(_STAT_ROWS)
                audio.play("menu_move")
            elif input_map.is_down(event):
                self.row = (self.row + 1) % len(_STAT_ROWS)
                audio.play("menu_move")
            elif input_map.is_confirm(event):
                self._flip()
        else:
            count = len(self.member.elements)
            if input_map.is_left(event) or input_map.is_right(event):
                self.icon = (self.icon + (-1 if input_map.is_left(event) else 1)) % max(1, count)
                audio.play("menu_move")
            elif input_map.is_down(event):
                self.zone = "stat"
                audio.play("menu_move")
            elif input_map.is_confirm(event):
                element = self.member.elements[self.icon]
                for index, stance in enumerate(self._stances()):
                    if stance.get("element") == element:
                        self.member.stance = index
                        audio.play("menu_select")
        return None

    # -- the help ------------------------------------------------------------------------------------

    def help_text(self) -> str:
        if self.zone == "icon":
            element = self.member.elements[self.icon]
            for stance in self._stances():
                if stance.get("element") == element:
                    return stance["name"]
            return ""
        return HELP.get(_STAT_ROWS[self.row][0], "")

    # -- drawing -------------------------------------------------------------------------------------

    def render(self, surface, lay, active) -> None:
        member = self.member
        icon_at = self._draw_top(surface)
        self._draw_body(surface)
        box(surface, M, DESC_Y, W, DESC_H)
        rows, more = paged(text_renderer.wrap(self.help_text(), text_renderer.get_font(SIZE), W - 20))
        for n, line in enumerate(rows):
            text(surface, line, M + 10, DESC_Y + 5 + n * 12, WHITE)
        if more:
            more_arrow(surface, 256 - M - 18, DESC_Y + DESC_H - 9)
        if self.zone == "icon" and icon_at:
            tip = (icon_at[self.icon] - 8, M + 14)
        else:
            tip = (M + 10, BODY_Y + 8 + self.row * 16 + 4)
        self.last_hook = text_renderer.draw_pointer(surface, tip, YELLOW, from_screen_top=True)

    def _draw_top(self, surface) -> list[int]:
        member = self.member
        box(surface, M, M, W, TOP_H)
        left, right = shoulder("L"), shoulder("R")
        by = M + (TOP_H - 11) // 2
        if left is not None:
            surface.blit(left, (M + 4, by))
        if right is not None:
            surface.blit(right, (256 - M - 4 - right.get_width(), by))
        _, shown, top = stance_numbers(member)
        name, hp = short_name(member.id), f"HP {shown}/{top}"
        group = 32 + 6 + width(hp) + 12 + 18 + 8 + 18
        x0 = 128 - group // 2
        blit32(surface, member.id, x0, M + 2)
        text(surface, name, x0 + 38, M + 7)
        text(surface, hp, x0 + 38, M + 19)
        stances = self._stances()
        start = stances[member.stance]["element"] if stances else None
        x = x0 + 38 + width(hp) + 12
        found = []
        for element in member.elements:
            icon = load_element_icon(element)
            if icon is None:
                continue
            surface.blit(icon, (x, M + 9))
            if element == start:
                pygame.draw.rect(surface, YELLOW, (x - 2, M + 7, icon.get_width() + 4, icon.get_height() + 4), 2)
            found.append(x)
            x += icon.get_width() + 8
        return found

    def _draw_body(self, surface) -> None:
        member = self.member
        box(surface, M, BODY_Y, W, BODY_H)
        lx, top_y = M + 12, BODY_Y + 8
        points, _, _ = stance_numbers(member)
        for row, (key, label) in enumerate(_STAT_ROWS):
            y = top_y + row * 16
            if self.zone == "stat" and row == self.row:
                shade = pygame.Surface((136, 14), pygame.SRCALPHA)
                shade.fill((255, 255, 255, 36))
                surface.blit(shade, (M + 6, y - 2))
            text_renderer.draw_text(surface, label, (lx, y), size=SIZE, **ColorSettings.STAT_EDGE_STYLES[key])
            text(surface, str(points.get(key, 0)), lx + 119, y, WHITE, right=True)
            lit = int(exp_points(member, key)) * 10 // int(_GROWTH["meter"])
            draw_notches(surface, (lx, y + 10), lit, ColorSettings.STAT_TEXT_STYLES[key]["color"])
        self._draw_grid(surface, lx + 119 + 16, top_y)
        key, label = _STAT_ROWS[self.row]
        rx, ry = lx + 119 + 16, top_y + 5 * 16
        text(surface, "EXP to next", rx, ry, GRAY)
        text_renderer.draw_text(surface, label, (rx, ry + 14), size=SIZE, **ColorSettings.STAT_EDGE_STYLES[key])
        frame = pygame.Rect(rx, ry + 28, 256 - M - 8 - rx, 12)
        full = int(_GROWTH["meter"])
        pts = min(int(exp_points(member, key)), full)
        pygame.draw.rect(surface, (0, 0, 0), frame)
        inner = frame.inflate(-2, -2)
        inner.width = round(inner.width * pts / full)
        if inner.width:
            pygame.draw.rect(surface, EXP_FILL, inner)
        pygame.draw.rect(surface, EXP_FRAME, frame, 1)
        words = f"{pts}/{full}"
        text(surface, words, frame.centerx - width(words) // 2, frame.top + 2, EXP_TEXT)

    def _draw_grid(self, surface, area_x: int, top_y: int) -> None:
        """The small 3 by 7 preview of the element grid."""
        member = self.member
        flags = self.gm.party.flags
        slots = open_slots(flags)
        known = known_moves(member.id, member.elements, flags)
        loadout = checked(member.loadout, known, first_loadout(member.id, flags), slots)
        grid = slot_grid(loadout, known, slots)
        area_w = 256 - M - 8 - area_x
        cw, ch, gap = 25, 8, 2
        gx = area_x + (area_w - (3 * cw + 2 * gap)) // 2
        gy = top_y + (5 * 16 - 6 - (7 * ch + 6 * gap)) // 2
        fills = UISettings.SLOT_FILL_COLORS
        for r, cells in enumerate(grid[:7]):
            for c in range(min(3, slots[r] if r < len(slots) else 0)):       # a slot not yet open is not drawn
                move = cells[c] if c < len(cells) else None
                rect = pygame.Rect(gx + c * (cw + gap), gy + r * (ch + gap), cw, ch)
                pygame.draw.rect(surface, (0, 0, 0), rect)
                if move is not None:
                    first, second = tag_elements(move, member.elements)
                    pygame.draw.rect(surface, fills[first], rect)
                    if second:
                        pygame.draw.polygon(surface, fills[second], [(rect.right - 1, rect.top),
                                                                     (rect.right - 1, rect.bottom - 1),
                                                                     (rect.left, rect.bottom - 1)])
                pygame.draw.rect(surface, (200, 208, 230), rect, 1)
