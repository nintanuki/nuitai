"""The seven pages of the field menu (``field_menu_scene.py``), one per tab.

Each page holds the scene that kept that screen's rules before (the inventory, the loadout, equip, status,
the config and the info list) and hands it the keys, so every action the old menu had still works; the page
only draws the screen anew, on the right of the party column. A page says who is lit in the column
(``column_member``), where the hook is on it, and what the bottom window shows (``bottom``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.factories import first_loadout, known_moves, stance_numbers
from core.shared import by_id, short_name, skill_for
from core.stats import STAT_SHORT
from settings import BattleStageSettings, ColorSettings, ItemSettings, LoadoutSettings, MasterySettings, UISettings
from systems import battle_bag, mastery, records
from systems.loadout import checked, open_slots, slot_grid
from ui import field_menu_kit as kit
from ui import input_map, text_renderer
from ui.element_tag import tag_elements
from ui.field_menu_kit import (CYAN, GRAY, ITEMS_C, WHITE, YELLOW, box, hook, more_arrow, text, width)
from ui.flex import flex_widths
from ui.item_icon import item_icon, kind_surface, weapon_kind
from ui.window import help_wrap
from utils.graphics import load_element_icon

if TYPE_CHECKING:
    from core.scenes.field_menu_scene import FieldMenuScene

# An item's name in the color of its category.
CATEGORY_COLORS = {
    "Meals": (232, 160, 80), "Ingredients": (150, 200, 110), "Medicine": (92, 196, 106), "Elements": (230, 90, 110),
    "Seeds": (200, 230, 120), "Materials": (190, 160, 120), "Weapons": (159, 196, 232), "Relics": (180, 139, 232),
    "Special": (180, 139, 232), "Key Items": (60, 200, 200),
}


def make_page(name: str, menu: "FieldMenuScene", preview: bool = False):
    """The page for tab ``name``. ``preview`` builds it only to be drawn at rest: nothing is started."""
    return PAGES[name](menu, preview)


class Page:
    """What every page has; a page that holds a scene says what its rules say."""

    def __init__(self, menu: "FieldMenuScene", preview: bool = False) -> None:
        self.menu = menu
        self.gm = menu.gm
        self.preview = preview

    def handle(self, event: pygame.event.Event) -> str | None:
        """Take a key; "back" gives the hook back to the tabs."""
        return None

    def update(self, dt: float) -> None:
        pass

    def close(self) -> None:
        pass

    def blocking(self) -> bool:
        """True while a talk box or a message holds the keys, so L and R do not change the tab under it."""
        return False

    def wants_column(self) -> bool:
        """Whether left moves the hook onto the party column now (a page keeps left where it uses it)."""
        return False

    def hook_pos(self) -> tuple[int, int]:
        """Where the hook hangs on screen now, for working out which way is nearest (``ui/hook_nav.py``)."""
        return (self.menu.lay.lx - 6, 40)

    def anchors(self) -> list:
        """The places the hook can land on coming from the column on the left: (key, (x, y))."""
        return []

    def enter(self, key) -> None:
        """Put the hook on the place ``anchors`` named ``key``."""

    def column_member(self) -> int | None:
        """The fighter lit in the column (a place among the first three), None if it is someone waiting."""
        index = self.menu.member
        return index if index < 3 else None

    def column_hook(self) -> int | None:
        return None

    def column_held(self) -> int | None:
        return None

    def render(self, surface: pygame.Surface, lay: kit.Layout, active: bool) -> None:
        pass

    def render_over(self, surface: pygame.Surface) -> None:
        """What goes over everything, a talk box."""

    def bottom(self) -> tuple:
        return ("money",)


def _lines(words: str, room: int = 232) -> list[str]:
    return text_renderer.wrap(words, text_renderer.get_font(kit.SIZE), room)[:2]


# ======================================================================================
# ITEMS
# ======================================================================================

class ItemsPage(Page):
    """The member's battle bag on top, the shared bag under it (Frankie, 11/12, 11/13). The hook goes down the
    shared list; up from its first item to the category row (left and right flip category), up again into the
    member's bag, where A gives an item back. A on an item a fight can use asks Use or Give to; Give to and
    Use go to the column."""

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        from core.scenes.inventory_scene import InventoryScene

        self.inv = InventoryScene(self.gm)
        self.on_cat = False       # the hook on the category row
        self.zone = "list"        # "list" the shared bag, "bag" the member's own
        self.bag_cursor = 0
        self._fix()

    # -- state ----------------------------------------------------------------------------

    def _names(self) -> list[str]:
        """The categories with something in, but the Battle Bags one: the member's bag is always on top."""
        from core.scenes.inventory_scene import BAGS

        return [name for name in self.inv.categories() if name != BAGS]

    def _fix(self) -> None:
        """Keep a category open while there is one, the cursor inside its list."""
        names = self._names()
        if not names:
            self.inv.category = None
            return
        if self.inv.category not in names:
            self.inv.category = names[0]
            self.inv._item_cursor = 0
        rows = self.inv._rows()
        self.inv._item_cursor = min(self.inv._item_cursor, max(0, len(rows) - 1))

    def _rows(self) -> list[tuple[str, int]]:
        return self.inv._rows() if self.inv.category else []

    def blocking(self) -> bool:
        inv = self.inv
        return (not inv.text_box.is_done()) or inv._message is not None

    # -- where the hook is, for moving by position ----------------------------------------------

    def _list_first(self) -> int:
        return max(0, self.inv._item_cursor - 4)

    def hook_pos(self) -> tuple[int, int]:
        lx = self.menu.lay.lx - 6
        if self.zone == "bag":
            return (lx, 42 + (self.bag_cursor - max(0, self.bag_cursor - 3)) * 11)
        if self.on_cat:
            return (lx, 112)
        return (lx, 126 + (self.inv._item_cursor - self._list_first()) * 12)

    def anchors(self) -> list:
        lx = self.menu.lay.lx - 6
        member = self.menu.member_obj()
        found = []
        slots = battle_bag.size(member) if member is not None else 0
        for row in range(min(4, slots)):
            found.append((("bag", row), (lx, 42 + row * 11)))
        if self.inv.category:
            found.append((("cat",), (lx, 112)))
        first = self._list_first()
        for i, _row in enumerate(self._rows()[first:first + 5]):
            found.append((("item", first + i), (lx, 126 + i * 12)))
        return found

    def enter(self, key) -> None:
        if key[0] == "bag":
            self.zone, self.on_cat, self.bag_cursor = "bag", False, key[1]
        elif key[0] == "cat":
            self.zone, self.on_cat = "list", True
        else:
            self.zone, self.on_cat = "list", False
            self.inv._item_cursor = key[1]

    def wants_column(self) -> bool:
        """Left from an item row, or from the member's bag, goes to the column; on the category row it flips."""
        return not self._busy() and not self.on_cat

    def _busy(self) -> bool:
        inv = self.inv
        return (not inv.text_box.is_done()) or inv._message is not None or inv._choice is not None or inv._using is not None

    def _bag_member(self):
        inv = self.inv
        members = self.gm.party.members
        if inv._using is not None and inv._giving:
            return members[inv._member_cursor % len(members)]
        return self.menu.member_obj()

    # -- input ----------------------------------------------------------------------------

    def update(self, dt: float) -> None:
        self.inv.update(dt)

    def handle(self, event) -> str | None:
        inv = self.inv
        audio = self.gm.audio
        if self._busy():
            if inv._choice is not None and (input_map.is_up(event) or input_map.is_down(event)):
                inv._choice_cursor = (inv._choice_cursor + (-1 if input_map.is_up(event) else 1)) % len(inv._choice)
                audio.play("menu_move")
            else:
                inv.handle_event(event)
            self._fix()
            return None
        if input_map.is_cancel(event):
            if self.zone == "bag":
                self.zone = "list"
                self.on_cat = True
                audio.play("menu_move")
                return None
            return "back"
        member = self.menu.member_obj()
        if self.zone == "bag":
            slots = battle_bag.size(member)
            if input_map.is_up(event):
                self.bag_cursor = (self.bag_cursor - 1) % slots
                audio.play("menu_move")
            elif input_map.is_down(event):
                if self.bag_cursor >= slots - 1:
                    self.zone, self.on_cat = "list", True
                else:
                    self.bag_cursor += 1
                audio.play("menu_move")
            elif input_map.is_confirm(event):
                if self.bag_cursor < len(member.bag):
                    battle_bag.take_back(self.gm.party, member, member.bag[self.bag_cursor])
                    audio.play("menu_select")
                    self._fix()
                else:
                    audio.play("menu_move")
            return None
        names = self._names()
        rows = self._rows()
        if (input_map.is_left(event) or input_map.is_right(event)) and self.on_cat:
            if names:
                step = -1 if input_map.is_left(event) else 1
                inv.category = names[(names.index(inv.category) + step) % len(names)] if inv.category in names else names[0]
                inv._item_cursor = 0
                audio.play("menu_move")
        elif input_map.is_up(event):
            if self.on_cat or not rows:
                self.zone = "bag"
                self.on_cat = False
                self.bag_cursor = battle_bag.size(member) - 1
            elif inv._item_cursor == 0:
                self.on_cat = True
            else:
                inv._item_cursor -= 1
            audio.play("menu_move")
        elif input_map.is_down(event):
            if self.on_cat:
                self.on_cat = False
            elif rows and inv._item_cursor < len(rows) - 1:
                inv._item_cursor += 1
            audio.play("menu_move")
        elif input_map.is_confirm(event):
            if self.on_cat or not rows:
                return None
            inv.handle_event(event)
            self._fix()
        return None

    # -- drawing --------------------------------------------------------------------------

    def column_member(self) -> int | None:
        inv = self.inv
        if inv._using is not None:
            index = inv._member_cursor
            return index if index < 3 else None
        return super().column_member()

    def column_hook(self) -> int | None:
        inv = self.inv
        if inv._using is not None and inv._member_cursor < 3:
            return inv._member_cursor
        return None

    def _item_row(self, surface, item_id: str, x: int, y: int, color, dim: bool = False) -> None:
        icon = item_icon(item_id)
        if icon is not None:
            if dim:
                icon = icon.copy()
                icon.set_alpha(110)
            surface.blit(icon, (x, y))
        text(surface, ItemSettings.NAMES.get(item_id, item_id), x + 10, y, color)

    def render(self, surface, lay, active) -> None:
        inv = self.inv
        rx, lx, right = lay.rx, lay.lx, lay.right
        member = self._bag_member()
        # the member's bag: the count at its top right, four rows
        box(surface, rx, 30, lay.rw, 58)
        if member is not None:
            slots = battle_bag.size(member)
            text(surface, f"{len(member.bag)}/{slots}", right, 36, ITEMS_C, right=True)
            first = max(0, self.bag_cursor - 3) if self.zone == "bag" and active else 0
            ghost = inv._using if inv._using is not None and inv._giving else None
            for row in range(4):
                slot = first + row
                y = 38 + row * 11
                if slot >= slots:
                    break
                if slot < len(member.bag):
                    item_id = member.bag[slot]
                    self._item_row(surface, item_id, lx, y, CATEGORY_COLORS.get(_category(item_id), WHITE))
                elif ghost and slot == len(member.bag):
                    kit.dashed(surface, pygame.Rect(lx - 3, y - 2, 110, 12))
                    self._item_row(surface, ghost, lx, y, tuple(c // 2 for c in CATEGORY_COLORS.get(_category(ghost), WHITE)), dim=True)
                else:
                    text(surface, "-", lx + 10, y, GRAY)
                if active and self.zone == "bag" and slot == self.bag_cursor and not self._busy():
                    hook(surface, lx - 6, y)
            if slots > first + 4:
                more_arrow(surface, right - 8, 81)
        # the shared bag
        box(surface, rx, 88, lay.rw, 102)
        text(surface, "Shared bag", lx, 96, ITEMS_C)
        category = inv.category
        if category:
            names = self._names()
            arrows = "< {} >" if len(names) > 1 else "{}"
            text(surface, arrows.format(category), lx, 108, CATEGORY_COLORS.get(category, WHITE))
        rows = self._rows()
        first = max(0, inv._item_cursor - 4)
        for i, (item_id, count) in enumerate(rows[first:first + 5]):
            y = 122 + i * 12
            on = first + i == inv._item_cursor
            self._item_row(surface, item_id, lx, y, CATEGORY_COLORS.get(category, WHITE))
            text(surface, f"x{count}", right, y, right=True)
        if len(rows) > first + 5:
            more_arrow(surface, right - 8, 182)
        if active and self.zone == "list" and not self._busy():
            if self.on_cat:
                hook(surface, lx - 6, 108)
            elif rows:
                hook(surface, lx - 6, 122 + (inv._item_cursor - first) * 12)
        if inv._choice is not None:
            box(surface, rx, 138, lay.rw, 52)
            for i, word in enumerate(inv._choice):
                text(surface, word, lx, 150 + i * 16)
            hook(surface, lx - 6, 150 + inv._choice_cursor * 16)
        # someone waiting: the hook on the column cannot reach them, so a small window names them
        if inv._using is not None and inv._member_cursor >= 3:
            waiting = self.gm.party.members[inv._member_cursor]
            box(surface, rx, 150, lay.rw, 26)
            text(surface, short_name(waiting.id), lx, 159)
            hook(surface, lx - 6, 159)

    def bottom(self) -> tuple:
        inv = self.inv
        if inv._message is not None:
            return ("help", _lines(inv._message))
        if self._busy():
            return ("money",)
        rows = self._rows()
        if self.zone == "list" and not self.on_cat and rows:
            from core.scenes.inventory_scene import item_help

            return ("help", _lines(item_help(rows[inv._item_cursor][0])))
        if self.zone == "bag":
            member = self.menu.member_obj()
            if member is not None and self.bag_cursor < len(member.bag):
                from core.scenes.inventory_scene import item_help

                return ("help", _lines(item_help(member.bag[self.bag_cursor])))
        return ("money",)

    def render_over(self, surface) -> None:
        if not self.inv.text_box.is_done():
            self.inv.text_box.render(surface)


def _category(item_id: str) -> str:
    from core.scenes.inventory_scene import category_of

    return category_of(item_id)


# ======================================================================================
# ELEMENT
# ======================================================================================

SLOT_ROW = 16                 # the real grid's row pitch: slot boxes share their edges
SMALLEST = 28                 # a collapsed slot's width
GRID_COLUMNS = 3              # a tier holds three slots at most; the grid is three wide


def letters_that_fit(short: str, width_px: int) -> str:
    """As many letters of a move's short name as fit in a collapsed slot ``width_px`` wide: four in an equal
    third, one in a square."""
    return short[:max(1, (width_px - 4) // 8)]


def slot_box(surface, left: int, y: int, col_w: int, tint, label: str, color=WHITE, tag: str = "") -> pygame.Rect:
    """One slot as the element menu draws it: the first element's triangle top left, the second's (grey when
    there is none) bottom right, the slot's own wash between, the short name between the triangles."""
    box_rect = pygame.Rect(left, y - (SLOT_ROW - 8) // 2, col_w + 1, SLOT_ROW + 1)
    inner = box_rect.inflate(-2, -2)
    if tint is None:
        pygame.draw.rect(surface, UISettings.SLOT_EMPTY_FILL, inner)
    else:
        first, second = tint
        fills = UISettings.SLOT_FILL_COLORS
        wash = pygame.Surface(inner.size, pygame.SRCALPHA)
        ends = (fills[first], fills[second or first])
        for step in range(inner.width):
            t = step / max(1, inner.width - 1)
            shade = tuple(int(a + (b - a) * t) for a, b in zip(*ends))
            wash.fill((*shade, UISettings.SLOT_WASH_ALPHA), (step, 0, 1, inner.height))
        surface.blit(wash, inner.topleft)
        leg = inner.height
        lft, top, rgt, bot = inner.left, inner.top, inner.right - 1, inner.bottom - 1
        pygame.draw.polygon(surface, fills[first], [(lft, top), (lft + leg - 1, top), (lft, top + leg - 1)])
        pygame.draw.polygon(surface, fills[second] if second else ColorSettings.GRAY,
                            [(rgt, bot), (rgt - leg + 1, bot), (rgt, bot - leg + 1)])
    pygame.draw.rect(surface, UISettings.SLOT_BOX_COLOR, box_rect, 1)
    if label:
        x = box_rect.left + inner.height // 2 + 2
        text_renderer.draw_text(surface, label, (x + 1, y + 1), (0, 0, 0), size=kit.SIZE)
        text_renderer.draw_text(surface, label, (x, y), color, size=kit.SIZE)
    elif tag and tint is not None:
        # as many letters of the short name as fit at this width, white, centered between the triangles; a square is
        # 15 pixels inside its border, so there one letter, flush to it (clipped to the box, never into the next slot)
        clip = surface.get_clip()
        surface.set_clip(box_rect.inflate(-1, 0))
        x = inner.centerx - 4 * len(tag) + (1 if len(tag) % 2 else 0)
        for i, letter in enumerate(tag):
            text_renderer.draw_text(surface, letter, (x + i * 8 + 1, y + 1), (0, 0, 0), size=kit.SIZE)
            text_renderer.draw_text(surface, letter, (x + i * 8, y), WHITE, size=kit.SIZE)
        surface.set_clip(clip)
    return box_rect


class ElementPage(Page):
    """Frankie's loadout (``LoadoutScene``'s rules): the stance on top, the tiers and the bank as boxes that
    share the window's width; the one under the hook stretches to its full entry."""

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        from core.scenes.loadout_scene import LoadoutScene

        flags = self.gm.party.flags
        flag = LoadoutSettings.LESSON_FLAG
        seen = flags.get(flag)
        if preview:
            flags[flag] = True            # drawing it at rest must not start Hina's lesson
        try:
            self.scene = LoadoutScene(self.gm, menu.member_obj())
        finally:
            if preview:
                if seen is None:
                    flags.pop(flag, None)
                else:
                    flags[flag] = seen

    def update(self, dt: float) -> None:
        self.scene.update(dt)

    def blocking(self) -> bool:
        return not self.scene.text_box.is_done()

    def wants_column(self) -> bool:
        return self.scene.text_box.is_done() and self.scene.grid.col == 0 and self.scene.held is None

    def _row_y(self, index: int) -> int:
        grid = self.scene.grid
        hidden = 1 if self.scene.stances else 0
        first = grid._slide_window(7, hidden)
        return 70 + (index - first) * SLOT_ROW

    def hook_pos(self) -> tuple[int, int]:
        rx = self.menu.lay.rx
        grid = self.scene.grid
        if self.scene.stances and grid.row == 0:
            return (rx + 4, 42)
        return (rx + 24, self._row_y(grid.row))

    def anchors(self) -> list:
        rx = self.menu.lay.rx
        grid = self.scene.grid
        hidden = 1 if self.scene.stances else 0
        first = grid._slide_window(7, hidden)
        found = [(0, (rx + 4, 42))] if self.scene.stances else []
        for index in range(max(first, hidden), min(len(grid.rows), first + 7)):
            found.append((index, (rx + 24, self._row_y(index))))
        return found

    def enter(self, key) -> None:
        grid = self.scene.grid
        grid.row = key
        cols = [c for c, cell in enumerate(grid.rows[key].cells) if cell is not None]
        grid.col = cols[0] if cols else 0

    def handle(self, event) -> str | None:
        sc = self.scene
        if sc.text_box.is_done() and input_map.is_cancel(event) and sc.held is None:
            return "back"
        sc.handle_event(event)
        return None

    def render(self, surface, lay, active) -> None:
        sc = self.scene
        member = sc.member
        rx, lx = lay.rx, lay.lx
        box(surface, rx, 30, lay.rw, 24)
        if sc.stances:
            stance = sc.stances[member.stance]
            style = ColorSettings.ELEMENT_TEXT_STYLES.get(stance["element"], {})
            # the stance's name in its color, then the two element icons at the right with a gap between
            text_renderer.draw_text(surface, stance["name"], (rx + 8, 38), size=kit.SIZE, **style)
            icons = [load_element_icon(e) for e in member.elements]
            span = sum(i.get_width() for i in icons if i is not None) + 2 * (len(icons) - 1)
            x = lay.right - span
            for element, icon in zip(member.elements, icons):
                if icon is None:
                    continue
                surface.blit(icon, (x, 33))
                if element == stance["element"]:
                    pygame.draw.rect(surface, YELLOW, (x - 1, 32, icon.get_width() + 2, icon.get_height() + 2), 1)
                x += icon.get_width() + 2
            if active and sc.grid.row == 0:
                hook(surface, rx + 4, 38)
        box(surface, rx, 54, lay.rw, 136)
        grid = sc.grid
        hidden = 1 if sc.stances else 0
        max_rows = 7
        first = grid._slide_window(max_rows, hidden)
        left, right = rx + 22, 248       # an even margin right and left, inside the window
        for offset, row in enumerate(grid.rows[first:first + max_rows]):
            index = first + offset
            y = 66 + offset * SLOT_ROW
            if index < hidden:
                continue
            if row.label:
                text(surface, row.label, rx + 6, y, row.label_color or WHITE)
            cells = list(row.cells)
            if row.label in ("B", "") and index > 0:
                # the bank: every slot shows, empty ones black, as the tiers' do
                cells += [None] * (GRID_COLUMNS - len(cells))
            on_row = active and index == grid.row
            cursor = grid.col if on_row and grid.col < len(cells) else None
            held_move = _move_of(cells[cursor]) if cursor is not None else None
            total = right - left
            # Three columns, every slot the same size. In the row the hook is on, a slot that holds a move takes
            # all the width the row has: the others shrink to squares, their corner triangles meeting, and a
            # locked slot's space goes to it too, so the row ends where the rows below end. The full name shows
            # if it fits, else the short one. Other rows keep their three equal columns and their locked gaps.
            label_text = ""
            drawn = cells[:GRID_COLUMNS]
            if held_move is not None:
                square = SLOT_ROW
                widths = [square] * len(drawn)
                widths[cursor] = total - square * (len(drawn) - 1)
                full = held_move["name"]
                label_text = full if width(full) + 16 <= widths[cursor] else cells[cursor].label
            else:
                widths = flex_widths(total, GRID_COLUMNS, None, 0, SMALLEST)
            x = left
            for col, cell in enumerate(cells[:GRID_COLUMNS]):
                move = _move_of(cell) if cell is not None else None
                tint = tag_elements(move, member.elements) if move else None
                expanded = col == cursor and held_move is not None
                color = YELLOW if sc.held is not None and expanded else WHITE
                rect = slot_box(surface, x, y, widths[col], tint, label_text if expanded else "", color,
                                tag="" if expanded or not move else letters_that_fit(cell.label, widths[col]))
                if col == cursor:
                    text_renderer.draw_pointer(surface, (rect.left + 2, rect.bottom - 5), YELLOW)
                x += widths[col]

    def bottom(self) -> tuple:
        lines, color = self.scene._footer()
        if not lines:
            return ("money",)
        return ("help", lines, color)

    def render_over(self, surface) -> None:
        if not self.scene.text_box.is_done():
            self.scene.text_box.render(surface)


def _move_of(cell):
    """The move a grid cell holds, or None for an empty slot."""
    data = cell.data if cell is not None else None
    return data[2] if data is not None and len(data) > 2 else None


# ======================================================================================
# EQUIP
# ======================================================================================

class EquipPage(Page):
    """Equip, Remove and Mastery as a bar along the bottom; Weapon and Relic and the stats above; while a slot is
    being filled, the list and the stats now and then (``EquipScene``'s rules)."""

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        from core.scenes.equip_scene import EquipScene

        self.scene = EquipScene(self.gm, menu.member_obj())

    def handle(self, event) -> str | None:
        sc = self.scene
        if sc.state == "command" and input_map.is_cancel(event):
            return "back"
        if sc.state in ("mastery", "type") and (input_map.is_left(event) or input_map.is_right(event)):
            return None        # who is shown is picked on the column, not here
        sc.handle_event(event)
        return None

    def wants_column(self) -> bool:
        sc = self.scene
        return (sc.state == "command" and sc.command == 0) or sc.state in ("slot", "mastery", "type")

    def hook_pos(self) -> tuple[int, int]:
        sc = self.scene
        lx = self.menu.lay.lx - 6
        if sc.state == "command":
            return (22 + (0, 72, 158)[sc.command], 207)
        if sc.state == "slot":
            return (lx, 41 + sc.slot * 20)
        if sc.state == "list":
            return (lx, 53 + (sc.pick - max(0, sc.pick - 2)) * 11)
        return (lx, 96 + (sc.type_row * 34 if sc.state == "mastery" else 0))

    def anchors(self) -> list:
        lx = self.menu.lay.lx - 6
        return [(0, (lx, 41)), (1, (lx, 61))]

    def enter(self, key) -> None:
        sc = self.scene
        sc.state, sc.removing, sc.slot = "slot", False, key

    # -- drawing --------------------------------------------------------------------------

    def _slots(self, surface, lay, hooked: int | None) -> None:
        from core.scenes.equip_scene import SLOTS

        sc = self.scene
        box(surface, lay.rx, 30, lay.rw, 52)
        for i, (slot, label) in enumerate((("weapon", "Weapon"), ("relic", "Relic"))):
            y = 37 + i * 20
            text(surface, label, lay.lx, y, CYAN)
            worn = getattr(sc.member, slot)
            if worn:
                icon = item_icon(worn)
                if icon is not None:
                    surface.blit(icon, (lay.lx + 6, y + 10))
                text(surface, ItemSettings.NAMES.get(worn, worn), lay.lx + 16, y + 10)
            if hooked == i:
                hook(surface, lay.lx - 6, y)

    def _stats(self, surface, lay, top: int, then: dict | None = None) -> None:
        from core.scenes.equip_scene import numbers

        sc = self.scene
        now = numbers(sc.member, sc.member.weapon)
        keys = [("max_hp", "HP"), *STAT_SHORT.items()]
        if then is None:
            for n, (key, label) in enumerate(keys):
                if n == 0:
                    x, y = lay.lx, top
                else:
                    x, y = lay.lx + ((n - 1) % 2) * 70, top + 12 + ((n - 1) // 2) * 11
                text(surface, label, x, y, CYAN)
                text(surface, str(now[key]), x + 42, y, right=True)
            return
        for n, (key, label) in enumerate(keys):
            y = top + n * 10
            text(surface, label, lay.lx, y, CYAN)
            text(surface, str(now[key]), lay.lx + 56, y, right=True)
            color = (YELLOW if then[key] > now[key] else ColorSettings.STAT_DROP if then[key] < now[key] else WHITE)
            pygame.draw.polygon(surface, color, [(lay.lx + 64, y + 1), (lay.lx + 68, y + 4), (lay.lx + 64, y + 7)])
            text(surface, str(then[key]), lay.lx + 100, y, color, right=True)

    def _type_row(self, surface, lay, y: int, type_id: str) -> None:
        sc = self.scene
        exp = sc.member.mastery.get(type_id, 0)
        level = mastery.level_for(exp)
        top = level >= MasterySettings.MAX_LEVEL
        surface.blit(kind_surface(weapon_kind(type_id)), (lay.lx, y))
        text(surface, mastery.type_name(type_id), lay.lx + 10, y)
        text(surface, f"Lv {level}", lay.right, y, YELLOW if top else WHITE, right=True)
        from core.scenes.party_scene import draw_notches

        step = mastery.progress(exp)
        draw_notches(surface, (lay.lx + 10, y + 11), 10 if step is None else step[0] * 10 // step[1],
                     YELLOW if top else ColorSettings.STAT_TEXT_STYLES["strength"]["color"])
        text(surface, "MAX" if step is None else f"{step[0]}/{step[1]}", lay.right, y + 15,
             YELLOW if top else GRAY, right=True)

    def render(self, surface, lay, active) -> None:
        from core.scenes.equip_scene import (SLOTS, _bonus_line, _learned_by_level, candidates, numbers)

        sc = self.scene
        state = sc.state
        if state == "list":
            box(surface, lay.rx, 30, lay.rw, 56)
            text(surface, "Weapon" if SLOTS[sc.slot] == "weapon" else "Relic", lay.lx, 37, CYAN)
            choices = sc._choices()
            first = max(0, sc.pick - 2)
            for n, item_id in enumerate(choices[first:first + 3]):
                y = 49 + n * 11
                icon = item_icon(item_id)
                if icon is not None:
                    surface.blit(icon, (lay.lx, y))
                worn = getattr(sc.member, SLOTS[sc.slot])
                text(surface, ItemSettings.NAMES.get(item_id, item_id), lay.lx + 10, y, GRAY if item_id == worn else WHITE)
                if first + n == sc.pick:
                    hook(surface, lay.lx - 6, y)
            if len(choices) > first + 3:
                more_arrow(surface, lay.right - 8, 80)
            box(surface, lay.rx, 86, lay.rw, 104)
            highlighted = sc._highlighted()
            weapon = highlighted if highlighted and SLOTS[sc.slot] == "weapon" else sc.member.weapon
            self._stats(surface, lay, 92, then=numbers(sc.member, weapon))
            return
        self._slots(surface, lay, sc.slot if state == "slot" else None)
        box(surface, lay.rx, 82, lay.rw, 108)
        if state in ("command", "slot"):
            self._stats(surface, lay, 92)
        elif state == "mastery":
            for index, type_id in enumerate(mastery.weapon_types(sc.member.id)):
                y = 92 + index * 34
                self._type_row(surface, lay, y, type_id)
                if index == sc.type_row:
                    hook(surface, lay.lx - 6, y)
        elif state == "type":
            type_id = mastery.weapon_types(sc.member.id)[sc.type_row]
            self._type_row(surface, lay, 92, type_id)
            hook(surface, lay.lx - 6, 92)
            level = mastery.level_for(sc.member.mastery.get(type_id, 0))
            skill = skill_for(sc.member.id, type_id)
            # what the Skill does is in the bottom window (it needs the room); here, its name, the strokes'
            # bonus now and what the Skill has learned so far, never what is still to come
            text(surface, "Skill", lay.lx, 119, CYAN)
            text(surface, skill["name"] if skill else "None", lay.lx + 48, 119)
            text(surface, "Strokes", lay.lx, 131, CYAN)
            text(surface, _bonus_line(level).replace("Damage", "Dmg"), lay.lx, 141)
            learned = [(at, name) for at, name in (_learned_by_level(skill["id"]) if skill else []) if at <= level]
            for row, (at, name) in enumerate(learned[:3]):
                text(surface, f"Lv {at}", lay.lx, 155 + row * 10, CYAN)
                text(surface, name, lay.lx + 40, 155 + row * 10)

    def bottom(self) -> tuple:
        from core.equipment import description, trade_line, with_english
        from core.scenes.equip_scene import SLOTS, equip_help

        sc = self.scene
        if sc.state == "type":
            from core.shared import skill_for as _skill_for

            type_id = mastery.weapon_types(sc.member.id)[sc.type_row]
            skill = _skill_for(sc.member.id, type_id)
            return ("help", help_wrap(skill.get("description", ""), 232) if skill else ["No Skill yet."])
        if sc.state in ("command", "mastery"):
            return ("bar", ("Equip", "Remove", "Mastery"), 2 if sc.state != "command" else sc.command)
        if sc.state == "slot":
            worn = getattr(sc.member, SLOTS[sc.slot])
            if sc.removing:
                return ("help", ["Take it off."])
            return ("help", equip_help(worn) or ["Nothing worn."])
        return ("help", equip_help(sc._highlighted()))

    def column_member(self) -> int | None:
        index = next((i for i, m in enumerate(self.gm.party.members) if m is self.scene.member), 0)
        return index if index < 3 else None


# ======================================================================================
# STATUS
# ======================================================================================

class StatusPage(Page):
    """The eight stats with their EXP notches; the Skill and the EXP to the next point along the bottom
    (``PartyScene``'s rules: up and down pick a stat, A switches the stance they start in)."""

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        from core.scenes.party_scene import PartyScene

        self.scene = PartyScene(self.gm, cursor=menu.member)

    def handle(self, event) -> str | None:
        if input_map.is_cancel(event):
            return "back"
        if input_map.is_left(event) or input_map.is_right(event):
            return None        # who is shown is picked on the column
        self.scene.handle_event(event)
        return None

    def wants_column(self) -> bool:
        return True

    def hook_pos(self) -> tuple[int, int]:
        return (self.menu.lay.lx - 6, 58 + self.scene._stat_row * 16)

    def anchors(self) -> list:
        lx = self.menu.lay.lx - 6
        return [(row, (lx, 58 + row * 16)) for row in range(8)]

    def enter(self, key) -> None:
        self.scene._stat_row = key

    def _member(self):
        members = self.gm.party.members
        return members[self.scene._cursor % len(members)]

    def column_member(self) -> int | None:
        index = self.scene._cursor
        return index if index < 3 else None

    def render(self, surface, lay, active) -> None:
        from core.scenes.party_scene import _STAT_ROWS, draw_notches, exp_points
        from systems.battle import _GROWTH

        member = self._member()
        box(surface, lay.rx, 30, lay.rw, 160)
        # the open element slots, a box each, a row a tier
        flags = self.gm.party.flags
        slots = open_slots(flags)
        known = known_moves(member.id, member.elements, flags)
        loadout = checked(member.loadout, known, first_loadout(member.id, flags), slots)
        from ui.element_tag import tag_color

        for r, cells in enumerate(slot_grid(loadout, known, slots)):
            for c, move in enumerate(cells):
                bx, by = lay.right - 38 + c * 12, 36 + r * 7
                if move is None:
                    pygame.draw.rect(surface, (120, 124, 132), (bx, by, 10, 5))
                else:
                    first, second = tag_elements(move, member.elements)
                    if second is None:
                        pygame.draw.rect(surface, tag_color(first), (bx, by, 10, 5))
                    else:
                        pygame.draw.rect(surface, tag_color(first), (bx, by, 5, 5))
                        pygame.draw.rect(surface, tag_color(second), (bx + 5, by, 5, 5))
                pygame.draw.rect(surface, (200, 208, 230), (bx, by, 10, 5), 1)
        points, _, _ = stance_numbers(member)
        for row, (key, label) in enumerate(_STAT_ROWS):
            y = 54 + row * 16
            text_renderer.draw_text(surface, label, (lay.lx, y), size=kit.SIZE, **ColorSettings.STAT_EDGE_STYLES[key])
            text(surface, str(points.get(key, 0)), lay.right - 4, y, right=True)
            lit = int(exp_points(member, key)) * 10 // _GROWTH["meter"]
            draw_notches(surface, (lay.lx, y + 10), lit, ColorSettings.STAT_TEXT_STYLES[key]["color"])
            if active and row == self.scene._stat_row:
                hook(surface, lay.lx - 6, y)

    def bottom(self) -> tuple:
        return ("status", self._member(), self.scene._stat_row)


# ======================================================================================
# PARTY
# ======================================================================================

class PartyPage(Page):
    """Who fights and who waits: the three in the column, everyone else in a list. A picks one, A on another
    trades their places, from different groups or the same (the first three's order is the order they fight in)."""

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        self.cursor = min(menu.member, len(self.gm.party.members) - 1)
        self.held: int | None = None

    def handle(self, event) -> str | None:
        members = self.gm.party.members
        audio = self.gm.audio
        fighters = min(3, len(members))
        if input_map.is_cancel(event):
            if self.held is not None:
                self.held = None
                audio.play("menu_move")
                return None
            return "back"
        if not members:
            return None
        bench = len(members) - fighters
        if input_map.is_up(event) or input_map.is_down(event):
            step = -1 if input_map.is_up(event) else 1
            if self.cursor < fighters:
                self.cursor = (self.cursor + step) % fighters
            elif bench:
                self.cursor = fighters + (self.cursor - fighters + step) % bench
            audio.play("menu_move")
        elif input_map.is_left(event) and self.cursor >= fighters:
            self.cursor = min(self.cursor - fighters, fighters - 1)
            audio.play("menu_move")
        elif input_map.is_right(event) and self.cursor < fighters and bench:
            self.cursor = fighters + min(self.cursor, bench - 1)
            audio.play("menu_move")
        elif input_map.is_confirm(event):
            audio.play("menu_select")
            if self.held is None:
                self.held = self.cursor
            elif self.held == self.cursor:
                self.held = None
            else:
                members[self.held], members[self.cursor] = members[self.cursor], members[self.held]
                self.held = None
        return None

    def anchors(self) -> list:
        lx = self.menu.lay.lx - 4
        members = self.gm.party.members
        return [(3 + i, (lx, 62 + i * 32)) for i in range(len(members[3:7]))]

    def enter(self, key) -> None:
        self.cursor = key

    def column_member(self) -> int | None:
        return self.cursor if self.cursor < 3 else None

    def column_hook(self) -> int | None:
        return self.cursor if self.cursor < 3 else None

    def column_held(self) -> int | None:
        return self.held if self.held is not None and self.held < 3 else None

    def render(self, surface, lay, active) -> None:
        members = self.gm.party.members
        box(surface, lay.rx, 30, lay.rw, 160)
        text(surface, "Waiting", lay.lx - 4, 38, CYAN)
        for i, member in enumerate(members[3:7]):
            index = 3 + i
            y = 52 + i * 32
            sprite = kit.member_sprite(member.id)
            if sprite is not None:
                surface.blit(sprite, (lay.lx + 4, y + 14 - sprite.get_height() // 2))
            if self.held == index:
                pygame.draw.rect(surface, YELLOW, (lay.lx + 2, y - 2, 32, 30), 1)
            text(surface, short_name(member.id), lay.lx + 40, y + 6, ColorSettings.RED if member.current_hp <= 0 else WHITE)
            _, shown, top = stance_numbers(member)
            text(surface, f"{shown}/{top}", lay.lx + 40, y + 17)
            if active and self.cursor == index:
                hook(surface, lay.lx - 4, y + 10)

    def bottom(self) -> tuple:
        if self.held is not None:
            return ("help", ["Who trades places?"])
        return ("help", _lines("A picks one, then A on another swaps them."))


# ======================================================================================
# INFO
# ======================================================================================

class InfoPage(Page):
    """Bestiary, Lore and Quests (``DataScene``'s rows, each opening its own screen), then the time played
    and the steps."""

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        from core.scenes.data_scene import DataScene

        self.scene = DataScene(self.gm)

    def handle(self, event) -> str | None:
        if input_map.is_cancel(event):
            return "back"
        self.scene.handle_event(event)
        return None

    def render(self, surface, lay, active) -> None:
        sc = self.scene
        box(surface, 0, 30, 256, 124)
        for i, (name, *_rest) in enumerate(sc.rows()):
            y = 48 + i * 24
            text(surface, name, 28, y)
            if active and i == sc._cursor:
                hook(surface, 22, y)
        # Time and Steps, each on one line: the yellow label at the left, the number at the right of it
        box(surface, 0, 154, 256, 36)
        text(surface, "Time", 12, 162, YELLOW)
        text(surface, records.time_text(self.gm.party), 244, 162, right=True)
        text(surface, "Steps", 12, 174, YELLOW)
        text(surface, str(records.steps(self.gm.party)), 244, 174, right=True)

    def bottom(self) -> tuple:
        rows = self.scene.rows()
        return ("help", help_wrap(rows[self.scene._cursor][1], 232))


# ======================================================================================
# CONFIG
# ======================================================================================

class ConfigPage(Page):
    """The nine settings (``ConfigScene``'s rules: left and right change one, a slider repeats when held)."""

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        from core.scenes.config_scene import ConfigScene

        self.scene = ConfigScene(self.gm)
        self._entered = False
        if not preview:
            self.scene.on_enter()
            self._entered = True

    def close(self) -> None:
        if self._entered:
            self.scene.on_exit()
            self._entered = False

    def update(self, dt: float) -> None:
        self.scene.update(dt)

    def handle(self, event) -> str | None:
        if input_map.is_cancel(event):
            return "back"
        self.scene.handle_event(event)
        return None

    def render(self, surface, lay, active) -> None:
        from core.scenes.config_scene import NAMES, RED, GREEN, BLUE

        sc = self.scene
        box(surface, 0, 30, 256, 160)
        for row, name in enumerate(NAMES):
            y = 40 + row * 16
            text(surface, name, 18, y)
            if row in (RED, GREEN, BLUE):
                sc._render_slider(surface, row, y)
            else:
                text(surface, sc.value(row), 128, y)
            if active and row == sc._cursor:
                hook(surface, 12, y)

    def bottom(self) -> tuple:
        return ("help", help_wrap(self.scene.help_line(), 232))


PAGES = {"Items": ItemsPage, "Element": ElementPage, "Equip": EquipPage, "Status": StatusPage,
         "Party": PartyPage, "Info": InfoPage, "Config": ConfigPage}
