"""The seven pages of the field menu (``field_menu_scene.py``), one per tab.

Each page holds the scene that kept that screen's rules before (the inventory, the loadout, equip, status,
the config and the info list) and hands it the keys, so every action the old menu had still works; the page
only draws the screen anew, on the right of the party column. A page says who is lit in the column
(``column_member``), where the hook is on it, and what the bottom window shows (``bottom``).
"""

from __future__ import annotations

import unicodedata
from typing import TYPE_CHECKING

import pygame

from core.factories import first_loadout, known_moves, stance_numbers
from core.shared import by_id, short_name, skill_for
from core.stats import STAT_SHORT
from settings import BattleStageSettings, ColorSettings, FontSettings, ItemSettings, LoadoutSettings, MasterySettings, UISettings
from systems import battle_bag, daytime, mastery, records
from systems.loadout import checked, open_slots, slot_grid
from ui.slot_cell import PITCH_X, PITCH_Y, draw_cell
from ui import field_menu_kit as kit
from ui import input_map, text_renderer
from ui.element_tag import tag_elements
from ui.field_menu_kit import (CYAN, GRAY, ITEMS_C, WHITE, YELLOW, box, hook, more_arrow, text, width)
from ui.flex import flex_widths
from ui.item_icon import item_icon, kind_surface, weapon_kind
from ui.window import help_wrap
from utils.graphics import load_element_icon

if TYPE_CHECKING:
    from core.scenes.field_menu_scene import FieldMenuScene

# An item's name in the color of its category.
CATEGORY_COLORS = {
    "Meals": (232, 160, 80), "Ingredients": (150, 200, 110), "Medicine": (92, 196, 106), "Elements": (230, 90, 110),
    "Seeds": (200, 230, 120), "Materials": (190, 160, 120), "Weapons": (159, 196, 232), "Relics": (180, 139, 232),
    "Special": (180, 139, 232), "Key Items": (60, 200, 200),
}


def make_page(name: str, menu: "FieldMenuScene", preview: bool = False):
    """The page for tab ``name``. ``preview`` builds it only to be drawn at rest: nothing is started."""
    if name == "Items":
        from core.scenes.field_items import ItemsScreen    # local: it builds on this module

        return ItemsScreen(menu, preview)
    if name == "Info":
        from core.scenes.field_info import InfoScreen

        return InfoScreen(menu, preview)
    if name == "Party":
        from core.scenes.field_party import PartyScreen

        return PartyScreen(menu, preview)
    if name == "Status":
        from core.scenes.field_status import StatusScreen

        return StatusScreen(menu, preview)
    if name == "Equip":
        from core.scenes.field_equip import EquipScreen

        return EquipScreen(menu, preview)
    if name == "Config":
        from core.scenes.field_config import ConfigScreen

        return ConfigScreen(menu, preview)
    if name == "Element":
        from core.scenes.field_element import ElementScreen

        return ElementScreen(menu, preview)
    return PAGES[name](menu, preview)


class Page:
    """What every page has; a page that holds a scene says what its rules say."""

    full = False                  # True for a page that draws the whole screen, with no column or bottom window (Items)
    shows_member = False          # True when the right side shows one member's own things: that member is marked

    def __init__(self, menu: "FieldMenuScene", preview: bool = False) -> None:
        self.menu = menu
        self.gm = menu.gm
        self.preview = preview

    def handle(self, event: pygame.event.Event) -> str | None:
        """Take a key; "back" gives the hook back to the tabs."""
        return None

    def update(self, dt: float) -> None:
        pass

    def close(self) -> None:
        pass

    def blocking(self) -> bool:
        """True while a talk box or a message holds the keys, so L and R do not change the tab under it."""
        return False

    def wants_column(self) -> bool:
        """Whether left moves the hook onto the party column now (a page keeps left where it uses it)."""
        return False

    def hook_pos(self) -> tuple[int, int]:
        """Where the hook hangs on screen now, for working out which way is nearest (``ui/hook_nav.py``)."""
        return (self.menu.lay.lx - 6, 40)

    def anchors(self) -> list:
        """The places the hook can land on coming from the column on the left: (key, (x, y))."""
        return []

    def enter(self, key) -> None:
        """Put the hook on the place ``anchors`` named ``key``."""

    def below_column(self) -> bool:
        """Whether something sits directly below the column on screen, which down from the last member reaches
        (Frankie, 11/13); only Equip's bar does."""
        return False

    def enter_below_column(self) -> None:
        """Put the hook on what ``below_column`` says is there."""

    def column_member(self) -> int | None:
        """The fighter lit in the column (a place among the first three), None if it is someone waiting."""
        index = self.menu.member
        return index if index < 3 else None

    def column_hook(self) -> int | None:
        return None

    def column_held(self) -> int | None:
        return None

    def render(self, surface: pygame.Surface, lay: kit.Layout, active: bool) -> None:
        pass

    def render_over(self, surface: pygame.Surface) -> None:
        """What goes over everything, a talk box."""

    def bottom(self) -> tuple:
        return ("money",)


def _lines(words: str, room: int = 232) -> list[str]:
    return text_renderer.wrap(words, text_renderer.get_font(kit.SIZE), room)[:2]


# ======================================================================================
# ITEMS
# ======================================================================================

# Short item names for the Items list beside the party, which has room for 10 letters, the space counted (Frankie,
# 11/21: a seed shows its stat's three letters, "WIL Seed"; the full name is English where it can be, the short form
# takes the Hawaiian word where that saves space, else an abbreviation). Claude's picks, not decided. A dish keeps its
# first word's start ("Grill", "Toast", "Bake") so the pair reads the same way everywhere. Generated weapons and relics
# are not listed here: ``short_item_name`` builds theirs.
SHORT_ITEM_NAMES = {
    "mortar_pestle": "Mortar",
    "roast_breadfruit": "Roast 'Ulu",
    "seer_shell": "Seer Shell", "water": "Water",
    "grilled_eel": "Grill Eel", "grilled_pineapple": "Grill Pine", "grilled_akai_lau": "Grill Akai",
    "cooked_fish": "Grill Fish", "toasted_nori": "Toast Nori", "toasted_wheat": "Toast Wht",
    "baked_ti_root": "Bake Ti Rt",
    "baked_uala": "Bake 'Uala", "roast_coconut": "Roast Niu", "coconut_water": "Niu Water",
    "cured_uala": "Cure 'Uala", "cured_breadfruit": "Cure 'Ulu", "cured_pineapple": "Cure Pine",
    "cured_wheat": "Cure Wht", "cured_akai_lau": "Cure Akai",
    "mixed_vegetables": "Veggie Mix", "vegetable_soup": "Veg Soup",
    "nuno_toenail": "Nuno Nail", "grave_cloth": "Grv Cloth", "red_feather": "Red Feath", "gold_feather": "Gold Feath",
    "long_tongue": "Long Tong", "sirena_scale": "Sirena Scl", "ghoul_tooth": "Ghoul Tth",
    "wallet_1": "Lauhala", "wallet_3": "Shark Pch", "wallet_6": "Chief Box", "battle_bag": "Bag Upgrd",
    "puaa_anana": "Pua'a Ana", "golden_gohei": "Gold Gohei", "siapo_wraps": "Siapo Wrap", "faavao_bow": "Faavao Bow",
    "gen_niu_flower": "Ilang",
}

# A relic is its material and its type ("Pearl Shield"). Over 10 letters, the macrons and 'okina go first ("Lava Kupee"),
# then the material is cut to its first three letters ("Pea Putong").
_MATERIALS = ("Lava", "Honu", "Ananá", "Pearl", "Tūhua")


def _relic_short(full: str) -> str:
    material, _, kind = full.partition(" ")
    if material not in _MATERIALS:
        return full
    plain = unicodedata.normalize("NFD", full)
    plain = "".join(c for c in plain if not unicodedata.combining(c)).replace("'", "")
    if len(plain) <= 10:
        return plain
    return f"{material[:3]} {kind}"


def short_item_name(item_id: str, full: str) -> str:
    """The short form of an item's name (10 letters or fewer, the space counted) for the narrow Items list.

    A seed shows its stat's three letters ("WIL Seed"); a lontar its move's short name; a generated weapon its stat's
    three letters and its type word ("Hearty Sword" is "VIT Sword"); the rest a picked short name, else the full name.
    """
    stat = ItemSettings.SEEDS.get(item_id)
    if stat is not None:
        return f"{STAT_SHORT[stat]} Seed"
    if item_id in ItemSettings.SHELLS:
        full = UISettings.MOVE_SHORT_NAMES.get(full, full)
    if item_id in SHORT_ITEM_NAMES:
        return SHORT_ITEM_NAMES[item_id]
    if item_id.startswith("gen_") and len(full) > 10:
        parts = item_id.split("_")                   # gen_<type>_<benefit>_<penalty>
        if len(parts) >= 3 and parts[2] in STAT_SHORT and " " in full:
            return f"{STAT_SHORT[parts[2]]} {full.split(' ', 1)[1]}"
    return _relic_short(full) if len(full) > 10 else full


def _category(item_id: str) -> str:
    from core.scenes.inventory_scene import category_of

    return category_of(item_id)


# ======================================================================================
# ELEMENT
# ======================================================================================

SLOT_ROW = 16                 # the real grid's row pitch: slot boxes share their edges
SMALLEST = 28                 # a collapsed slot's width
GRID_COLUMNS = 3              # a tier holds three slots at most; the grid is three wide


def letters_that_fit(short: str, width_px: int) -> str:
    """As many letters of a move's short name as fit in a collapsed slot ``width_px`` wide: four in an equal
    third, one in a square."""
    return short[:max(1, (width_px - 4) // 8)]


def slot_box(surface, left: int, y: int, col_w: int, tint, label: str, color=WHITE, tag: str = "") -> pygame.Rect:
    """One slot as the element menu draws it: the first element's triangle top left, the second's (grey when
    there is none) bottom right, the slot's own wash between, the short name between the triangles."""
    box_rect = pygame.Rect(left, y - (SLOT_ROW - 8) // 2, col_w + 1, SLOT_ROW + 1)
    inner = box_rect.inflate(-2, -2)
    if tint is None:
        pygame.draw.rect(surface, UISettings.SLOT_EMPTY_FILL, inner)
    else:
        first, second = tint
        fills = UISettings.SLOT_FILL_COLORS
        wash = pygame.Surface(inner.size, pygame.SRCALPHA)
        ends = (fills[first], fills[second or first])
        for step in range(inner.width):
            t = step / max(1, inner.width - 1)
            shade = tuple(int(a + (b - a) * t) for a, b in zip(*ends))
            wash.fill((*shade, UISettings.SLOT_WASH_ALPHA), (step, 0, 1, inner.height))
        surface.blit(wash, inner.topleft)
        leg = inner.height
        lft, top, rgt, bot = inner.left, inner.top, inner.right - 1, inner.bottom - 1
        pygame.draw.polygon(surface, fills[first], [(lft, top), (lft + leg - 1, top), (lft, top + leg - 1)])
        pygame.draw.polygon(surface, fills[second] if second else ColorSettings.GRAY,
                            [(rgt, bot), (rgt - leg + 1, bot), (rgt, bot - leg + 1)])
    pygame.draw.rect(surface, UISettings.SLOT_BOX_COLOR, box_rect, 1)
    if label:
        x = box_rect.left + inner.height // 2 + 2
        text_renderer.draw_text(surface, label, (x + 1, y + 1), (0, 0, 0), size=kit.SIZE)
        text_renderer.draw_text(surface, label, (x, y), color, size=kit.SIZE)
    elif tag and tint is not None:
        # as many letters of the short name as fit at this width, white, centered between the triangles; a square is
        # 15 pixels inside its border, so there one letter, flush to it (clipped to the box, never into the next slot)
        clip = surface.get_clip()
        surface.set_clip(box_rect.inflate(-1, 0))
        x = inner.centerx - 4 * len(tag) + (1 if len(tag) % 2 else 0)
        for i, letter in enumerate(tag):
            text_renderer.draw_text(surface, letter, (x + i * 8 + 1, y + 1), (0, 0, 0), size=kit.SIZE)
            text_renderer.draw_text(surface, letter, (x + i * 8, y), WHITE, size=kit.SIZE)
        surface.set_clip(clip)
    return box_rect


def _move_of(cell):
    """The move a grid cell holds, or None for an empty slot."""
    data = cell.data if cell is not None else None
    return data[2] if data is not None and len(data) > 2 else None


# ======================================================================================
# EQUIP
# ======================================================================================

# ======================================================================================
# STATUS
# ======================================================================================

# ======================================================================================
# PARTY
# ======================================================================================

# ======================================================================================
# INFO
# ======================================================================================

PEEK_LEFT, PEEK_RIGHT = 110, 244      # the peek's room: right of the divider, inside the window
PEEK_LINES = 8                        # lines of 12 pixels from y 44; more are cut with the "more" arrow
DIVIDER_X = 102
DIVIDER = (90, 120, 160)


def fit(words: str, room: int = PEEK_RIGHT - PEEK_LEFT) -> str:
    """``words`` cut to end in ".." where they would run past ``room`` pixels."""
    if width(words) <= room:
        return words
    while words and width(words + "..") > room:
        words = words[:-1]
    return words.rstrip() + ".."


def _two_lines(words: str) -> list[str]:
    """``words`` wrapped to the peek's room on two lines at most, the second ending in ".." if it is cut."""
    wrapped = text_renderer.wrap(words, text_renderer.get_font(kit.SIZE), PEEK_RIGHT - PEEK_LEFT)
    if len(wrapped) > 2:
        wrapped = [wrapped[0], fit(" ".join(wrapped[1:]))]
    return wrapped


def peek_lines(party, row: str, quest_log=()) -> list[tuple[str, tuple]]:
    """What the peek shows for the Info row ``row`` (Frankie, 11/13): lines of (words, color), left aligned; the
    Records peek is drawn apart (``records_peek``). Every line fits between ``PEEK_LEFT`` and ``PEEK_RIGHT``."""
    from core import lore

    lines: list[tuple[str, tuple]] = []
    if row == "Quests":
        for heading, color, quests in (("Open", WHITE, [q for q in quest_log if not q.done]),
                                       ("Done", GRAY, [q for q in quest_log if q.done])):
            if quests:
                lines.append((heading, YELLOW))
                for q in quests:
                    lines += [(part, color) for part in _two_lines(q.name)]
        return lines or [("None yet", GRAY)]
    if row == "Bestiary":
        latest = records.latest_beaten(party)
        title, extra = "Latest", [latest] if latest else []
    elif row == "Glossary":
        page = lore.newest(party, lore.GLOSSARY)
        title, extra = "Latest", [page["title"]] if page else []
    else:
        page = lore.newest(party, lore_only=True)
        title, extra = "Newest", [page["title"], page["category"]] if page else []
    if not extra:
        return [("None yet", GRAY)]
    font = text_renderer.get_font(kit.SIZE)
    named = text_renderer.wrap(extra[0], font, PEEK_RIGHT - PEEK_LEFT)[:3]
    return [(title, YELLOW)] + [(line, WHITE) for line in named] + [(fit(w), GRAY) for w in extra[1:]]


# ======================================================================================
# CONFIG
# ======================================================================================

PAGES: dict = {}
