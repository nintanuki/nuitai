"""Pick an exact number: the shop's quantity picker in the text box's place (Frankie, 11/15).

Noelani's "How much?" uses it to leave pule with her or take it back. It counts the way the
shop does (``ui/quantity.py``): Up and Down one, Left adds ten, Right takes ten off, from 0 up to
``most``. A confirms with what is shown, B backs out; either pops the scene, then calls
``on_pick`` with the number, or with None when B was pressed.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

import pygame

from core.scene import Scene
from settings import ColorSettings, FontSettings, ScreenSettings, UISettings
from ui import input_map, text_renderer
from ui.quantity import stepped
from ui.text_box import TextBox
from ui.window import draw_window

if TYPE_CHECKING:
    from main import GameManager

_INDENT = 16


class CountScene(Scene):
    """Pick a number from 0 to ``most``; pops itself, then calls ``on_pick`` with it (None if cancelled)."""

    OPAQUE = False

    def __init__(self, gm: "GameManager", question: str, most: int,
                 on_pick: Callable[[int | None], None]) -> None:
        super().__init__(gm)
        self.question = question
        self.most = max(0, most)
        self.on_pick = on_pick
        self.count = 0

    def handle_event(self, event: pygame.event.Event) -> None:
        """Count with the arrows; confirm picks the number, cancel picks none."""
        if input_map.is_textbox_flip(event):
            TextBox.flip()
        elif input_map.is_confirm(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
            self.on_pick(self.count)
        elif input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
            self.on_pick(None)
        else:
            count = stepped(event, self.count, 0, self.most)
            if count != self.count:
                self.count = count
                self.gm.audio.play("menu_move")

    def render(self, surface: pygame.Surface) -> None:
        """The question in yellow, then the number with the cursor, in the window along the bottom."""
        pad = UISettings.TEXT_BOX_PADDING
        row = text_renderer.line_height(FontSettings.SIZE_BODY)
        font = text_renderer.get_font(FontSettings.SIZE_BODY)
        question = text_renderer.wrap(self.question, font, ScreenSettings.WIDTH - 2 * pad, spoken=True)
        height = max(UISettings.TEXT_BOX_HEIGHT, 2 * pad + row * (len(question) + 1))
        rect = pygame.Rect(0, TextBox.top_for(surface.get_height(), height), ScreenSettings.WIDTH, height)
        draw_window(surface, rect, see_through=True)
        x, y = rect.left + pad, rect.top + pad
        for line in question:
            text_renderer.draw_text(surface, line, (x, y), color=ColorSettings.YELLOW,
                                    size=FontSettings.SIZE_BODY, spoken=True)
            y += row
        text_renderer.draw_pointer(surface, (x + _INDENT - UISettings.MENU_LABEL_OFFSET + 4, y + FontSettings.SIZE_BODY // 2))
        text_renderer.draw_text(surface, f"{self.count:,} / {self.most:,}", (x + _INDENT, y),
                                size=FontSettings.SIZE_BODY, spoken=True)
