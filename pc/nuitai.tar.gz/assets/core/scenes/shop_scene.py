"""The SHOP screen, Final Fantasy VI's (Frankie, 10/24; it was a big title, D-571).

Pushed by [core/scenes/overworld_scene.py](overworld_scene.py) when the
player faces a market stall and presses confirm. On top, the seller's
name and their line; under it Buy, Sell and Exit with the party's pule;
along the bottom the party's portraits, lit if they can use the item
under the cursor and faded if not, L1 and R1 sliding to the rest when
there are more than fit.

Buy lists the stall's stock with its prices (less while Maika is along,
his party passive), and at the right the pule, how many the party owns
and how many are worn. While buying, the seller's line box grows to two
lines and says what the item under the cursor does, as Final Fantasy
VI's help line does (Frankie, 10/24). Confirm asks how many, as the booklet
says and Final Fantasy VI does: up and down count one at a time, left adds ten and right takes ten off (Frankie, 11/12), as many as
the pule pays for, the total under Owned; confirm buys them, cancel goes back
to the list (playtest, 10/28). A price the party cannot pay is a quiet bump. Sell lists the bag across the whole width (the longest
names need it), each with how many and what one fetches; tools and key items are not
listed (Frankie, 11/9); what the demo gives only once is gray with no price (``sell_price``), and so is what this
shop does not buy: each shop buys only its own kind (Frankie, 10/28), its
``buys`` in the shop file, the kinds ``sell_kind`` names. No shop buys a
meal. Cancel goes back to Buy, Sell and Exit, and from there walks away.

What a shop sells is in ``data/shops/<id>.json``: its ``seller``, its
``greeting``, and its rows. A row marked ``once`` (Kailo's lontar, the
Ananá relics) is sold only one time: bought, it is gone from the stall
for good (the party flag ``sold:<item>``). Prices are in pule, since the
fights are in the islands and the shells are the money there (D-476,
D-524). Rows are 12 pixels apart, as on the Equip screen.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

import pygame

from core import lore
from core.data_loader import DataLoader
from core.equipment import can_hold, slot_of
from core.scene import Scene
from systems import passives
from systems.passives import standing
from systems import lontar_talk
from core.shared import short_name
from systems import battle_bag
from settings import ColorSettings, FontSettings, ItemSettings, PassiveSettings, ShopSettings, StorySettings, UISettings, WalletSettings
from ui import input_map, text_renderer
from ui.element_tag import CELL
from ui.item_icon import item_icon
from ui.scroll_mark import draw_list_marks
from ui.text_box import TextBox
from ui.window import draw_window, help_wrap
from utils.backgrounds import render_scene_background
from utils.graphics import load_element_icon, load_portrait

if TYPE_CHECKING:
    from main import GameManager


SIZE = FontSettings.SIZE_BODY
_text = text_renderer.draw_text_at
ROW = 12
COMMANDS = ("Buy", "Sell", "Exit")
_COMMAND_X = (24, 72, 128)
_NAME_RECT = pygame.Rect(0, 0, 80, 24)
_LINE_RECT = pygame.Rect(80, 0, 176, 24)
_COMMAND_RECT = pygame.Rect(0, 24, 168, 24)
_MONEY_RECT = pygame.Rect(168, 24, 88, 24)
_EMPTY_RECT = pygame.Rect(0, 48, 256, 120)
# Walking up, the top two boxes are a line taller too, for a greeting in two lines ("E komo mai!" and the keeper's own question).
_TALK_NAME_RECT = pygame.Rect(0, 0, 80, 32)
_TALK_LINE_RECT = pygame.Rect(80, 0, 176, 32)
_TALK_COMMAND_RECT = pygame.Rect(0, 32, 168, 24)
_TALK_MONEY_RECT = pygame.Rect(168, 32, 88, 24)
_TALK_EMPTY_RECT = pygame.Rect(0, 56, 256, 112)
_LIST_RECT = pygame.Rect(0, 24, 256, 144)
_PARTY_RECT = pygame.Rect(0, 168, 256, 56)
_ROWS_TOP = 36
# Buying, the top two boxes are a line taller for the help's second line, and the list starts lower.
_BUY_NAME_RECT = pygame.Rect(0, 0, 80, 32)
_BUY_LINE_RECT = pygame.Rect(80, 0, 176, 32)
_BUY_LIST_RECT = pygame.Rect(0, 32, 256, 136)
_BUY_ROWS_TOP = 44
_HELP_X = 88                 # The help's words, on the 8 pixel grid for the cartridge; lines a row apart.
_HELP_WIDTH = 160
_ITEM_X = 32                 # Room for the fishhook cursor (11/2). A name; its icon a letter before.
_BUY_PRICE_RIGHT = 160
_PANEL_X = 176               # Buy's right side: the pule, Owned and Equipped.
_RIGHT = 248
_SELL_COUNT_RIGHT = 208
_BUY_ROWS = 10
_SELL_ROWS = 10
_BUY_MARK_X = 168            # The scroll arrows: past Buy's prices (Frankie, 10/24),
_SELL_MARK_X = 216           # and in Sell between the count and the price, past the longest name.
_PORTRAITS = 4               # Faces that fit along the bottom.
_SELL_ROW = "\x00sell"       # The last row of the Sell list once something is chosen: "Sell chosen" (Frankie, 11/5).
_CONFIRM_RECT = pygame.Rect(40, 72, 176, 56)
_MEMBER_RECT = pygame.Rect(16, 64, 224, 88)   # Whose bag grows, over the Buy list (Frankie, 11/12).
_MEMBER_ROWS = 5
_PORTRAIT_X, _PORTRAIT_STEP, _PORTRAIT_Y = 12, 60, 172

# The cartridge still draws the old layout from these (snes/tools/make_art.py) until it catches
# up with this one (the TODO's shop item); nothing in pygame uses them.
_HEADING_POSITION = (8, 8)
_GREETING_POSITION = (8, 28)
_LIST_TOP_Y = 56
_LIST_LEFT_X = 24  # Room for the fishhook cursor (11/2).
_PRICE_RIGHT_X = 240
_PURSE_RECT = pygame.Rect(0, 176, 256, 48)


def _has_soy_sauce(party) -> bool:
    """Whether Kailo already has soy sauce, from Miki or any way: carried, or given to Noelani for the stew,
    or the stew made (Frankie, 11/12: then the grocer's price needs no complaint)."""
    from systems import stew  # local, as elsewhere in the field code
    return bool(party.inventory.get(StorySettings.SOY_SAUCE, 0) or stew.given(party).get(StorySettings.SOY_SAUCE, 0)
                or stew.made(party))


class ShopScene(Scene):
    """A stall: buy from its stock or sell from the bag."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", shop_id: str) -> None:
        """Bind this scene to the host game manager and one shop.

        Args:
            gm: The host game manager. ``gm.party`` pays and carries.
            shop_id: The shop's id in ``data/shops/``.
        """
        super().__init__(gm)
        self.shop = gm.data.load("shops")[shop_id]
        self.state = "command"     # "command", "buy" or "sell".
        self._count = 0            # How many to buy while choosing; 0 while not.
        self._command = 0
        self._cursor = 0
        self._first_face = 0
        self.text_box = TextBox()  # a talk over the shop: Kailo's hint, the haggling
        self._bought: tuple[str, float] | None = None  # "Bought 2 Taro." and its seconds left
        # Selling is picked in bulk, then confirmed once (Frankie, 11/5): item id to how many are chosen.
        self._cart: dict[str, int] = {}
        self._confirming = False   # The final yes or no, with the total, is up.
        self._yes = False          # Its cursor; it opens on No, so a mashed A sells nothing.
        self._bag_row: dict | None = None   # A battle bag row waiting for the member who gets it (Frankie, 11/12).
        self._member = 0                    # Its cursor.
        # The first shop opened with Maika standing: he says he will get a better price (Frankie, 10/29).
        party = gm.party
        if standing(party, "maika") and not party.flags.get(passives.said_flag("maika")):
            party.flags[passives.said_flag("maika")] = True
            self._talk(PassiveSettings.MAIKA_SHOP)

    def _stock(self) -> list[dict]:
        """The stall's rows in ``shop_order``, without what was sold once."""
        rows = [row for row in stock_rows(self.gm.party, self.shop) if not sold_out(self.gm.party, row)]
        return sorted(rows, key=lambda row: shop_order(row["item"]))

    def _bag(self) -> list[str]:
        """What the party carries, in ``shop_order``, for selling; tools and key items are left out (Frankie, 11/9)."""
        return sorted((item for item, count in self.gm.party.inventory.items()
                       if count > 0 and not is_key_item(item)), key=shop_order)

    def _rows(self) -> list:
        if self.state == "buy":
            return self._stock()
        return self._bag() + ([_SELL_ROW] if self._cart else [])

    def cart_total(self) -> int:
        """What the chosen items fetch together in this shop."""
        return sum((sell_price(item, self.shop) or 0) * count for item, count in self._cart.items())

    def _sell_cart(self) -> str:
        """Sell everything chosen, at once; say what went, as "Sold 2 Taro for 10."."""
        party = self.gm.party
        total, sold = 0, 0
        names = []
        for item, count in list(self._cart.items()):
            for _ in range(count):
                price = sell_price(item, self.shop)
                if sell(party, item, self.shop):
                    total += price or 0
                    sold += 1
            names.append(f"{count} {ItemSettings.NAMES.get(item, item)}")
        self._cart = {}
        # One line in the top window, so with more than one kind it counts them.
        what = names[0] if len(names) == 1 else f"{sold} items"
        return f"Sold {what} for {total}."

    def price(self, row: dict) -> int:
        """What ``row`` costs this party: less while Maika is with them (his party passive)."""
        return row_price(self.gm.party, row)

    def most(self, row: dict) -> int:
        """How many of ``row`` the party could buy now: what the pule pays for, one of a ``once`` row."""
        can = self.gm.party.pule // self.price(row)
        return min(can, 1 if row.get("once") or row.get("wallet") or row.get("battle_bag") else ShopSettings.MOST_AT_ONCE)

    def _buy(self, row: dict, count: int = 1) -> bool:
        """Buy ``count`` of ``row``'s item if the party can pay; say whether it did."""
        party = self.gm.party
        if count < 1 or party.pule < self.price(row) * count:
            return False
        party.pule -= self.price(row) * count
        if row.get("wallet"):   # the bought wallet replaces the last, and the cap grows (Frankie, 11/12)
            party.set_wallet(WalletSettings.ITEMS.index(row["item"]))
            self._cursor = min(self._cursor, max(0, len(self._stock()) - 1))
            return True
        party.inventory[row["item"]] = party.inventory.get(row["item"], 0) + count
        if row["item"] in ItemSettings.SHELLS and row["item"] not in ItemSettings.KAPAS:
            self._talk(lontar_talk.take(party))  # the first lontar talk (Frankie, 11/10)
        if row.get("once"):
            party.flags[f"sold:{row['item']}"] = True
            self._cursor = min(self._cursor, max(0, len(self._stock()) - 1))
        return True

    def bag_price(self, member, row: dict) -> int | None:
        """What the next battle bag costs for ``member`` (the Maika discount included), None if none is left."""
        nxt = battle_bag.next_size(member, row.get("up_to"))
        return None if nxt is None else row_price(self.gm.party, {"price": nxt[3]})

    def _buy_bag(self, row: dict, member) -> bool:
        """Buy ``member`` the bag one size up if the party can pay; what was inside stays (Frankie, 11/12)."""
        party = self.gm.party
        price = self.bag_price(member, row)
        if price is None or party.pule < price:
            return False
        party.pule -= price
        battle_bag.set_tier(member, member.bag_tier + 1)
        return True

    def _handle_member(self, event: pygame.event.Event) -> None:
        """Choosing whose bag grows: up and down move, confirm buys, cancel goes back."""
        members = self.gm.party.members
        if input_map.is_cancel(event):
            self._bag_row = None
            self.gm.audio.play("menu_move")
        elif input_map.is_up(event) or input_map.is_down(event):
            self._member = (self._member + (-1 if input_map.is_up(event) else 1)) % len(members)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            member = members[self._member]
            if self._buy_bag(self._bag_row, member):
                self._bought = (f"Bought {battle_bag.tier_name(member)} for {short_name(member.id)}.",
                                ShopSettings.BOUGHT_SECONDS)
                self._bag_row = None
                self._cursor = min(self._cursor, max(0, len(self._stock()) - 1))
                self.gm.audio.play("menu_select")
            else:
                self.gm.audio.play("menu_move")

    def _render_member(self, surface: pygame.Surface) -> None:
        """The members over the list, each with the bag they carry and the next one's price."""
        draw_window(surface, _MEMBER_RECT)
        members = self.gm.party.members
        first = max(0, min(self._member - _MEMBER_ROWS + 1, len(members) - _MEMBER_ROWS))
        for index, member in enumerate(members[first:first + _MEMBER_ROWS], start=first):
            y = _MEMBER_RECT.y + 8 + (index - first) * 16
            price = self.bag_price(member, self._bag_row)
            color = ColorSettings.WHITE if price is not None and self.gm.party.pule >= price else ColorSettings.GRAY
            _text(surface, short_name(member.id), _MEMBER_RECT.x + 24, y, color)
            # Each member's own next bag and its price, or "Not sold here" once past what this shop sells
            # (Frankie, 11/12: members can be at different sizes).
            nxt = battle_bag.next_size(member, self._bag_row.get("up_to"))
            if nxt is not None:
                _text(surface, nxt[1], _MEMBER_RECT.x + 80, y, color)
                _text(surface, str(price), _MEMBER_RECT.right - 12, y, color, right=True)
            else:
                _text(surface, "Not sold here", _MEMBER_RECT.x + 80, y, color)
            if index == self._member:
                _draw_pointer(surface, (_MEMBER_RECT.x + 20, y + 3))

    def _talk(self, lines) -> None:
        """Play ``lines`` (speaker, text) in the text box; the list waits until they are read."""
        for speaker, text in lines:
            self.text_box.push(text, speaker=speaker)

    def _on_row(self) -> None:
        """The cursor is on a row (Frankie, 10/30): soy sauce talks the first time it is.

        Without Maika Kailo says he cannot pay it; with him along he and the
        grocer haggle, once, and the price drops to the row's ``talked_price``.
        """
        party = self.gm.party
        rows = self._rows() if self.state == "buy" else []
        if not rows or rows[min(self._cursor, len(rows) - 1)].get("talks_down") is None:
            return
        row = rows[min(self._cursor, len(rows) - 1)]
        if standing(party, row["talks_down"]):
            if not party.flags.get(ShopSettings.SOY_HAGGLE_FLAG):
                party.flags[ShopSettings.SOY_HAGGLE_FLAG] = True
                self._talk(ShopSettings.SOY_HAGGLE)
        elif not party.flags.get(ShopSettings.SOY_HINT_FLAG) and not _has_soy_sauce(party):
            party.flags[ShopSettings.SOY_HINT_FLAG] = True
            self._talk(ShopSettings.SOY_HINT)

    def _highlighted(self) -> str | None:
        """The item under the cursor, in the Buy or Sell list."""
        rows = self._rows() if self.state != "command" else []
        if not rows:
            return None
        row = rows[min(self._cursor, len(rows) - 1)]
        if row == _SELL_ROW:
            return None
        return row["item"] if isinstance(row, dict) else row

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Pick Buy, Sell or Exit; in a list, move, buy or sell, or go back."""
        if not self.text_box.is_done():
            if input_map.is_confirm(event):
                self.text_box.advance()
            return
        if input_map.is_l1(event) or input_map.is_r1(event):
            last = max(0, len(self.gm.party.members) - _PORTRAITS)
            step = -1 if input_map.is_l1(event) else 1
            if 0 <= self._first_face + step <= last:
                self._first_face += step
                self.gm.audio.play("menu_move")
        elif self.state == "command":
            self._handle_command(event)
        else:
            self._handle_list(event)

    def _handle_command(self, event: pygame.event.Event) -> None:
        if input_map.is_left(event) or input_map.is_right(event):
            step = -1 if input_map.is_left(event) else 1
            self._command = (self._command + step) % len(COMMANDS)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            self.gm.audio.play("menu_select")
            if COMMANDS[self._command] == "Exit":
                self.gm.scene_stack.pop()
            else:
                self.state, self._cursor = COMMANDS[self._command].lower(), 0
                self._cart, self._confirming = {}, False
                if self.state == "buy":
                    lore.hear(self.gm.party, ShopSettings.BUY_LINE)
                    self._on_row()
        elif input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()

    def _handle_list(self, event: pygame.event.Event) -> None:
        rows = self._rows()
        if self._bag_row is not None:
            self._handle_member(event)
            return
        if self._confirming:
            self._handle_confirm(event)
            return
        if self._count:
            self._handle_count(event, rows[min(self._cursor, len(rows) - 1)])
            return
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.state, self._cart = "command", {}
        elif rows and (input_map.is_up(event) or input_map.is_down(event)):
            step = -1 if input_map.is_up(event) else 1
            self._cursor = (self._cursor + step) % len(rows)
            self.gm.audio.play("menu_move")
            self._on_row()
        elif rows and input_map.is_confirm(event):
            row = rows[min(self._cursor, len(rows) - 1)]
            if self.state == "buy" and row.get("battle_bag"):
                # Ask whose bag it is for; the cursor starts on the first who can take the next size.
                done = self.most(row) > 0
                if done:
                    self._bag_row = row
                    members = self.gm.party.members
                    self._member = next((n for n, m in enumerate(members) if self.bag_price(m, row) is not None), 0)
            elif self.state == "buy":
                done = self.most(row) > 0
                self._count = 1 if done else 0
            elif row == _SELL_ROW:
                self._confirming, self._yes = True, False
                done = True
            else:
                # Pick how many to sell, the same picker buying uses; it opens on what is already chosen.
                done = sell_price(row, self.shop) is not None
                self._count = max(1, self._cart.get(row, 0)) if done else 0
            self.gm.audio.play("menu_select" if done else "menu_move")

    def _handle_confirm(self, event: pygame.event.Event) -> None:
        """The one final yes or no: left and right choose, confirm answers, cancel is No."""
        if input_map.is_left(event) or input_map.is_right(event):
            self._yes = not self._yes
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            if self._yes:
                self._bought = (self._sell_cart(), ShopSettings.BOUGHT_SECONDS)
                self._cursor = 0
            self._confirming = False
            self.gm.audio.play("menu_select")
        elif input_map.is_cancel(event):
            self._confirming = False
            self.gm.audio.play("menu_move")

    def _handle_count(self, event: pygame.event.Event, row) -> None:
        """Choosing how many: up and down count by one, left and right by ten, confirm buys them (or, selling, chooses them), cancel goes back."""
        selling = self.state == "sell"
        most = self.gm.party.inventory.get(row, 0) if selling else self.most(row)
        if input_map.is_cancel(event):
            self._count = 0
            self.gm.audio.play("menu_move")
        elif input_map.is_up(event) or input_map.is_down(event):
            count = self._count + (1 if input_map.is_up(event) else -1)
            if (0 if selling else 1) <= count <= most:
                self._count = count
                self.gm.audio.play("menu_move")
        elif input_map.is_left(event) or input_map.is_right(event):
            # Left adds ten, Right takes ten off (Frankie, 11/12; Right is Claude's pick, the mirror of Left),
            # stopping at the most there is or the least allowed.
            count = self._count + (10 if input_map.is_left(event) else -10)
            count = max(0 if selling else 1, min(most, count))
            if count != self._count:
                self._count = count
                self.gm.audio.play("menu_move")
        elif selling and input_map.is_confirm(event):
            # Chosen, not sold yet; none takes it off the list again.
            if self._count:
                self._cart[row] = self._count
            else:
                self._cart.pop(row, None)
            self._count = 0
            self.gm.audio.play("menu_select")
        elif input_map.is_confirm(event):
            if self._buy(row, self._count):
                # One line in the top window for a moment, never a box to close (Frankie, 11/4,
                # after Mark's Episode 2 bought by mistake and never knew what).
                name = ItemSettings.NAMES.get(row["item"], row["item"])
                self._bought = (f"Bought {self._count} {name}.", ShopSettings.BOUGHT_SECONDS)
            self._count = 0
            self.gm.audio.play("menu_select")

    def update(self, dt: float) -> None:
        """Type out a talk; let the "Bought" line run out."""
        self.text_box.update(dt)
        if self._bought is not None:
            words, left = self._bought
            self._bought = (words, left - dt) if left > dt else None

    def render(self, surface: pygame.Surface) -> None:
        """The seller and their line, then Buy, Sell and Exit or a list, then the party."""
        render_scene_background(self, surface)
        surface.fill(ColorSettings.BLACK)
        lines = {"command": self.shop.get("greeting", ""), "buy": ShopSettings.BUY_LINE, "sell": ShopSettings.SELL_LINE}
        buying = self.state == "buy"
        talking = self.state == "command"
        draw_window(surface, _BUY_NAME_RECT if buying else _TALK_NAME_RECT if talking else _NAME_RECT)
        _text(surface, self.shop.get("seller", ""), _NAME_RECT.x + 12, 8, ColorSettings.LABEL_CYAN)
        draw_window(surface, _BUY_LINE_RECT if buying else _TALK_LINE_RECT if talking else _LINE_RECT)
        helps = shop_help(self._highlighted()) if buying else help_wrap(lines["command"], _HELP_WIDTH) if talking else []
        if self.state != "command" and self._bought is not None:
            helps = [self._bought[0]]
        for row, words in enumerate(helps):
            _text(surface, words, _HELP_X, 8 + row * ROW)
        if not helps:
            _text(surface, lines[self.state], _LINE_RECT.x + 12, 8)
        if self.state == "command":
            draw_window(surface, _TALK_COMMAND_RECT)
            for x, word in zip(_COMMAND_X, COMMANDS):
                _text(surface, word, x, 40)
            _draw_pointer(surface, (_COMMAND_X[self._command] - 4, 40 + 3))
            draw_window(surface, _TALK_MONEY_RECT)
            _draw_pule(surface, self.gm.party.pule, _RIGHT, 40, ColorSettings.WHITE)
            draw_window(surface, _TALK_EMPTY_RECT)
        elif self.state == "buy":
            self._render_buy(surface)
        else:
            self._render_sell(surface)
        self._render_party(surface)
        if self._confirming:
            self._render_confirm(surface)
        if self._bag_row is not None:
            self._render_member(surface)
        if not self.text_box.is_done():
            self.text_box.render(surface)

    def _first_row(self, shown: int) -> int:
        return max(0, self._cursor - shown + 1)

    def _render_buy(self, surface: pygame.Surface) -> None:
        """The stock and prices at the left; the pule, Owned and Equipped at the right."""
        draw_window(surface, _BUY_LIST_RECT)
        stock = self._stock()
        first = self._first_row(_BUY_ROWS)
        for index, row in enumerate(stock[first:first + _BUY_ROWS], start=first):
            y = _BUY_ROWS_TOP + (index - first) * ROW
            color = ColorSettings.WHITE if self.gm.party.pule >= self.price(row) else ColorSettings.GRAY
            draw_item_name(surface, row["item"], _ITEM_X - CELL, y, color)
            # The Bag Upgrade row shows no price: each member's differs, shown when picking who (Frankie, 11/12).
            if not row.get("battle_bag"):
                _text(surface, str(self.price(row)), _BUY_PRICE_RIGHT, y, color, right=True)
            if index == self._cursor:
                _draw_pointer(surface, (_ITEM_X - CELL - 4, y + 3))
        draw_list_marks(surface, _BUY_MARK_X, _BUY_ROWS_TOP, ROW, first, _BUY_ROWS, len(stock))
        _draw_pule(surface, self.gm.party.pule, _RIGHT, _BUY_ROWS_TOP, ColorSettings.WHITE)
        item = self._highlighted()
        if item is None:
            return
        _text(surface, "Owned", _PANEL_X, _BUY_ROWS_TOP + 2 * ROW, ColorSettings.LABEL_CYAN)
        _text(surface, str(self.gm.party.inventory.get(item, 0)), _RIGHT, _BUY_ROWS_TOP + 3 * ROW, right=True)
        slot = slot_of(item)
        if slot:
            worn = sum(getattr(member, slot) == item for member in self.gm.party.members)
            _text(surface, "Equipped", _PANEL_X, _BUY_ROWS_TOP + 4 * ROW, ColorSettings.LABEL_CYAN)
            _text(surface, str(worn), _RIGHT, _BUY_ROWS_TOP + 5 * ROW, right=True)
        if self._count:
            row = self._stock()[min(self._cursor, len(self._stock()) - 1)]
            _text(surface, "How many", _PANEL_X, _BUY_ROWS_TOP + 7 * ROW, ColorSettings.LABEL_CYAN)
            _text(surface, f"x{self._count}", _PANEL_X, _BUY_ROWS_TOP + 8 * ROW, ColorSettings.YELLOW)
            _draw_pule(surface, self.price(row) * self._count, _RIGHT, _BUY_ROWS_TOP + 9 * ROW, ColorSettings.WHITE)

    def _render_sell(self, surface: pygame.Surface) -> None:
        """The bag across the whole width: name, how many, what one fetches; the pule at the bottom."""
        draw_window(surface, _LIST_RECT)
        bag = self._rows()
        first = self._first_row(_SELL_ROWS)
        for index, item in enumerate(bag[first:first + _SELL_ROWS], start=first):
            y = _ROWS_TOP + (index - first) * ROW
            if item == _SELL_ROW:
                _text(surface, "Sell chosen", _ITEM_X, y, ColorSettings.YELLOW)
                _draw_pule(surface, self.cart_total(), _RIGHT, y, ColorSettings.YELLOW)
            else:
                price = sell_price(item, self.shop)
                color = ColorSettings.WHITE if price is not None else ColorSettings.GRAY
                draw_item_name(surface, item, _ITEM_X - CELL, y, color)
                # How many are chosen, over how many the bag holds, once any are.
                picking = bool(self._count) and index == self._cursor
                chosen = self._count if picking else self._cart.get(item, 0)
                owned = self.gm.party.inventory[item]
                if chosen or picking:
                    _text(surface, f"{chosen}/{owned}", _SELL_COUNT_RIGHT, y, ColorSettings.YELLOW, right=True)
                else:
                    _text(surface, f"x{owned}", _SELL_COUNT_RIGHT, y, color, right=True)
                _text(surface, str(price) if price is not None else "-", _RIGHT, y, color, right=True)
            if index == self._cursor:
                _draw_pointer(surface, (_ITEM_X - CELL - 4, y + 3))
        draw_list_marks(surface, _SELL_MARK_X, _ROWS_TOP, ROW, first, _SELL_ROWS, len(bag))
        _draw_pule(surface, self.gm.party.pule, _RIGHT, _LIST_RECT.bottom - 16, ColorSettings.WHITE)

    def _render_confirm(self, surface: pygame.Surface) -> None:
        """The final question over the list: what the chosen things fetch, and Yes or No."""
        draw_window(surface, _CONFIRM_RECT)
        count = sum(self._cart.values())
        _text(surface, f"Sell {count} for", _CONFIRM_RECT.x + 12, _CONFIRM_RECT.y + 8)
        _draw_pule(surface, self.cart_total(), _CONFIRM_RECT.right - 12, _CONFIRM_RECT.y + 8, ColorSettings.YELLOW)
        for index, word in enumerate(("Yes", "No")):
            x = _CONFIRM_RECT.x + 48 + index * 56
            _text(surface, word, x, _CONFIRM_RECT.y + 32)
            if self._yes == (index == 0):
                _draw_pointer(surface, (x - 4, _CONFIRM_RECT.y + 32 + 3))

    def _render_party(self, surface: pygame.Surface) -> None:
        """The faces along the bottom: lit if they can use the item under the cursor, faded if not."""
        draw_window(surface, _PARTY_RECT)
        item = self._highlighted()
        members = self.gm.party.members
        for slot, member in enumerate(members[self._first_face:self._first_face + _PORTRAITS]):
            x = _PORTRAIT_X + slot * _PORTRAIT_STEP
            surface.blit(load_portrait(member.id), (x, _PORTRAIT_Y))
            if item is not None and slot_of(item) and not can_hold(member.id, item):
                shade = pygame.Surface((UISettings.PORTRAIT_SIZE, UISettings.PORTRAIT_SIZE), pygame.SRCALPHA)
                shade.fill((0, 0, 0, 150))
                surface.blit(shade, (x, _PORTRAIT_Y))
        # More along the row than fit: small arrows at the ends, L1 and R1 slide.
        if self._first_face > 0:
            pygame.draw.polygon(surface, ColorSettings.WHITE, [(4, 196), (8, 192), (8, 200)])
        if self._first_face + _PORTRAITS < len(members):
            pygame.draw.polygon(surface, ColorSettings.WHITE, [(252, 196), (248, 192), (248, 200)])


def shop_help(item_id: str | None) -> list[str]:
    """What ``item_id`` does, wrapped to the seller's line box: two lines, the Items screen's words."""
    from core.scenes.inventory_scene import item_help

    if not item_id:
        return []
    short = _weapon_trade(item_id) or _relic_trade(item_id)
    if short:
        # The seller's box is narrow, so "Raises Willpower but lowers Vitality." never fit
        # after the English word and the shop said only "Fan." (Frankie, 11/3, Mark's playtest).
        return help_wrap(short, _HELP_WIDTH)
    return help_wrap(item_help(item_id), _HELP_WIDTH)


def _weapon_trade(item_id: str) -> str:
    """A weapon's English word and its trade in the fewest words, "Fan. Willpower up, Vitality down."; else ""."""
    from core.equipment import with_english
    from core.shared import by_id
    from core.stats import STAT_NAMES

    weapon = by_id("weapons").get(item_id)
    if not weapon:
        return ""
    up, down = STAT_NAMES.get(weapon.get("benefit", "")), STAT_NAMES.get(weapon.get("penalty", ""))
    trade = ", ".join(filter(None, [f"{up} up" if up else "", f"{down} down" if down else ""]))
    return with_english(item_id, f"{trade}.") if trade else ""


def _relic_trade(item_id: str) -> str:
    """A relic's English word and its trade in the fewest words, "Bracer. Fire resist, nature weak."; else "".

    The relic's whole line never fit the seller's box either, and the shop said only "Bracer."
    (Frankie, 11/5, Mark's Episode 5), as weapons did before ``_weapon_trade``."""
    from core.equipment import label, relic, resists, with_english

    if not relic(item_id):
        return ""
    pairs = resists(item_id)
    resisted = [label(e).lower() for e, sign in pairs if sign > 0]
    weak = [label(e).lower() for e, sign in pairs if sign < 0]
    trade = ", ".join([f"{e} resist" for e in resisted] + [f"{e} weak" for e in weak])
    return with_english(item_id, f"{trade[:1].upper()}{trade[1:]}.") if trade else ""


def item_name(item_id: str) -> str:
    """What an item is called in the bag and the shops (``ItemSettings.NAMES``)."""
    return ItemSettings.NAMES.get(item_id, item_id)


def shop_order(item_id: str) -> tuple[int, str, str]:
    """Where ``item_id`` goes in a shop's Buy and Sell lists (Frankie, 11/10): by the bag's
    category, in the order Items lists them, then by full name, A to Z. A leading "The",
    diacritics and the okina or apostrophe are ignored, so Ko'i sorts as Koi."""
    from core.scenes.inventory_scene import CATEGORIES, category_of

    order = list(CATEGORIES)
    category = category_of(item_id)
    rank = order.index(category) if category in order else len(order)
    return rank, sort_name(item_name(item_id)), item_id


def sort_name(name: str) -> str:
    """``name`` as it sorts: lower case, no leading "The", accents, okina or apostrophes."""
    import unicodedata

    plain = unicodedata.normalize("NFKD", name)
    plain = "".join(c for c in plain if not unicodedata.combining(c))
    plain = re.sub("[ʻʼ‘’'`]", "", plain).casefold().strip()
    return re.sub(r"^the\s+", "", plain)


def draw_item_name(surface: pygame.Surface, item_id: str, x: int, y: int, color) -> None:
    """``item_id``'s icon in the letter space at ``x``, its name after it (Frankie, 10/24).

    A lontar shows its move's short name, as the element grid does, so Nature Blast
    does not run into its price (Frankie, 11/10: NatBlst, WavFist).
    """
    icon = item_icon(item_id)
    if icon is not None:
        surface.blit(icon, (x, y))
    name = item_name(item_id)
    if item_id in ItemSettings.SHELLS:
        name = UISettings.MOVE_SHORT_NAMES.get(name, name)
    text_renderer.draw_text(surface, name, (x + CELL, y), color=color, size=FontSettings.SIZE_BODY)


_SHOPS = DataLoader()


def sell_kind(item_id: str) -> str:
    """Which kind of thing ``item_id`` is to a buyer (Frankie, 10/28): "weapon", "relic",
    "loot" (what monsters drop), "meal", "medicine", "ingredient" (fish among them),
    "lontar", or "goods" for the rest (seeds, a Seer's Shell)."""
    from core.shared import by_id
    from ui.item_icon import FOOD, MEDICINE

    if item_id in ItemSettings.SHELLS:
        return "lontar"
    if item_id in by_id("weapons"):
        return "weapon"
    if item_id in by_id("relics"):
        return "relic"
    if item_id in ItemSettings.LOOT:
        return "loot"
    if item_id in FOOD:
        return "meal"
    if item_id in MEDICINE:
        return "medicine"
    if item_id in ItemSettings.INGREDIENTS or item_id in ItemSettings.FISH or item_id == ItemSettings.WATER:
        return "ingredient"
    return "goods"


def buys(shop: dict | None, item_id: str) -> bool:
    """Whether ``shop`` buys ``item_id``: only its own kind (its ``buys``), never a meal."""
    if sell_kind(item_id) == "meal":
        return False
    return shop is None or "buys" not in shop or sell_kind(item_id) in shop["buys"]


def is_key_item(item_id: str) -> bool:
    """Whether ``item_id`` is a key item or a field tool, which no shop lists or buys."""
    from systems.tools import is_tool

    return item_id in ItemSettings.KEY_ITEMS or is_tool(item_id)


def sell_price(item_id: str, shop: dict | None = None) -> int | None:
    """What a shop pays for one ``item_id`` (Frankie, 10/24), or None when it cannot be sold.

    Anything the demo gives again sells: a shop's item for a share of its
    lowest price, a seed or a dropped weapon or relic for its own price. A
    row sold ``once``, the starting gear, a chest's item and a meal never do,
    and with ``shop`` given, only what that shop buys (``buys``).
    """
    from settings import ShopSettings

    if not buys(shop, item_id) or is_key_item(item_id):  # a key item is never sold
        return None

    rows = [row for shop in _SHOPS.load("shops").values() for row in shop["stock"] if row.get("item") == item_id]
    if any(row.get("once") or row.get("talks_down") for row in rows):  # soy sauce is no one's to resell
        return None
    if rows:
        return int(min(row["price"] for row in rows) * ShopSettings.SELL_SHARE)
    return ShopSettings.SELL_PRICES.get(item_id)


def sell(party, item_id: str, shop: dict | None = None) -> bool:
    """Sell one ``item_id`` from the bag, to ``shop`` if given; say whether it was sold."""
    price = sell_price(item_id, shop)
    if price is None or party.inventory.get(item_id, 0) < 1:
        return False
    party.inventory[item_id] -= 1
    if party.inventory[item_id] <= 0:
        del party.inventory[item_id]
    party.pule += price
    return True


def stock_rows(party, shop: dict) -> list[dict]:
    """The rows a shop offers this party right now.

    A row ``{"next_battle_bag": true, "up_to": N}`` (Frankie, 11/12) offers the battle bag one size
    up from the member's, whichever member is asked for when it is bought; the Trapper sells the first size up (Frankie, 11/12).

    A row ``{"next_wallet": true, "up_to": N}`` is never a fixed item (Frankie, 11/12): it is
    always the wallet one tier above the one the party owns, so a tier is never skipped and one
    already passed is never offered. ``up_to`` is the highest tier this shop is meant to sell;
    once the party owns that or more, the row is gone.
    """
    rows = []
    for row in shop.get("stock", []):
        if row.get("next_battle_bag"):
            # The next size up of the battle bag, for one member (Frankie, 11/12): the row shows the
            # cheapest any member could buy; the member is asked at the buying. None to buy: no row.
            costs = [nxt[3] for member in party.members
                     if (nxt := battle_bag.next_size(member, row.get("up_to"))) is not None]
            if costs:
                rows.append({"item": "battle_bag", "price": min(costs), "battle_bag": True,
                             "up_to": row.get("up_to")})
            continue
        if not row.get("next_wallet"):
            rows.append(row)
            continue
        wallet = next_wallet_row(party, row.get("up_to"))
        if wallet is not None:
            rows.append(wallet)
    return rows


def next_wallet_row(party, up_to: int | None = None) -> dict | None:
    """The wallet one tier above the one the party owns, as a stall row, or None (Frankie, 11/12).

    ``up_to`` is the highest tier the seller is meant to sell. Shared by every seller of wallets:
    the shops' ``next_wallet`` rows and Noelani's bank menu (Frankie, 11/12).
    """
    tier = party.wallet_tier + 1
    if tier <= min(len(WalletSettings.TIERS) - 1 if up_to is None else up_to, len(WalletSettings.TIERS) - 1):
        item, _name, _holds, cost = WalletSettings.TIERS[tier]
        return {"item": item, "price": cost, "wallet": True}
    return None


def sold_out(party, row: dict) -> bool:
    """Whether ``row`` is sold only once and already was."""
    return bool(row.get("once")) and bool(party.flags.get(f"sold:{row['item']}"))


def shop_price(party, price: int) -> int:
    """A price in pule, less while Maika is in the party and standing (ShopSettings.CHARM_DISCOUNT)."""
    from settings import ShopSettings
    from systems.passives import standing

    if not standing(party, "maika"):
        return price
    return max(1, round(price * (1 - ShopSettings.CHARM_DISCOUNT)))


def row_price(party, row: dict) -> int:
    """What a stall row costs this party.

    A row with ``talks_down`` (soy sauce, Frankie 10/30) has a scripted price:
    its own ``price`` (1000, more than the wallet holds) until that member is
    standing in the party and the haggle has been played, then its
    ``talked_price`` (500), charm discount or not.
    """
    member = row.get("talks_down")
    if member is None:
        return shop_price(party, row["price"])
    haggled = party.flags.get(ShopSettings.SOY_HAGGLE_FLAG) and standing(party, member)
    return row["talked_price"] if haggled else row["price"]


def _draw_pule(surface: pygame.Surface, amount: int, right: int, y: int, color) -> None:
    """``amount`` right-aligned at ``right``, the shell icon before it (D-476)."""
    text = str(amount)
    left = right - text_renderer.text_width(text, FontSettings.SIZE_BODY)
    text_renderer.draw_text(surface, text, (left, y), color=color, size=FontSettings.SIZE_BODY)
    icon = load_element_icon("pule")
    if icon is not None:
        surface.blit(icon, (left - icon.get_width() - 4, y - 4))


def _draw_pointer(surface: pygame.Surface, tip: tuple[int, int]) -> None:
    """The cursor, the fishhook, at ``tip``."""
    text_renderer.draw_pointer(surface, tip)
