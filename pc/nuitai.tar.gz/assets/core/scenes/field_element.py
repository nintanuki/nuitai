"""The field menu's Element screen (Frankie, 11/21): one member at a time, in floating windows over the darkened field.

Three windows: the member across the top (sprite, name and HP, their two element icons with the starting stance boxed in
yellow, and the Super Nintendo L and R buttons at the edges, which switch member), the grid of rows (only the real
rows, no bank row, as Chrono Cross has it; every row the member has open is drawn), and the description along the
bottom, short.

* **A on an empty slot** pops up every element the member knows to pick from; one already in a row is dimmed with its
  row (R1, R2...) and picking it moves it here.
* **A on a filled slot** hooks its element to carry; A on another slot puts it there, swapping with what was in it; B
  puts it back.
* **X on a filled slot** pops up the same list to replace it with the pick; the old one goes where the new came from
  if it can sit there, else it is simply not slotted.
* **Y** flips the member's starting stance. **L and R** switch member. B goes back to the commands.

An element not in a tier needs no bank: it just lives in the list. The rules are the old page's, ``LoadoutScene`` and
``systems.loadout`` (which tier a move can sit in, the slots the story has opened, the numbers by tier, Hina's lesson).
"""

from __future__ import annotations

from pathlib import Path

import pygame

from core.factories import stance_numbers
from core.scenes.field_menu_main import M, G, blit32
from core.scenes.field_menu_pages import Page, slot_box
from core.shared import short_name
from settings import BattleStageSettings, FontSettings, LoadoutSettings
from systems.loadout import help_lines, reach
from ui import input_map, text_renderer
from ui.element_tag import tag_elements
from ui.field_menu_kit import GRAY, WHITE, YELLOW, box, more_arrow, paged, text, width, rows_top
from ui.grid_menu import short_move_name
from utils.graphics import load_element_icon

SIZE = FontSettings.SIZE_BODY
TOP_H = 36                        # the member's window
DESC_H = 36
ROW = 16
SLOT_W = 74                       # three slots fill the grid window
LEFT = M + 12
PAD = 12                          # the grid window's height beyond its rows
LIST_W = 136                      # the pick list
LIST_ROWS = 7
RED = (255, 110, 100)
_BUTTONS: dict[str, pygame.Surface | None] = {}


def shoulder(letter: str) -> pygame.Surface | None:
    """The SNES shoulder button, L or R (drawn by ``docs/design/menu-mockup/menu_mockup.py``)."""
    if letter not in _BUTTONS:
        path = Path(__file__).resolve().parents[2] / "assets" / "ui" / f"button-{letter}.png"
        _BUTTONS[letter] = pygame.image.load(str(path)).convert_alpha() if path.exists() else None
    return _BUTTONS[letter]


class ElementScreen(Page):
    """The Element screen; zones: ``grid`` and ``pick`` (the list, to fill an empty slot or replace a filled one)."""

    full = True

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        from core.scenes.loadout_scene import LoadoutScene

        flags = self.gm.party.flags
        flag = LoadoutSettings.LESSON_FLAG
        seen = flags.get(flag)
        if preview:
            flags[flag] = True            # drawing it at rest must not start Hina's lesson
        try:
            self.scene = LoadoutScene(self.gm, menu.member_obj())
        finally:
            if preview:
                if seen is None:
                    flags.pop(flag, None)
                else:
                    flags[flag] = seen
        self.zone = "grid"
        self.tier = 0                     # the cursor: a place in ``tiers()`` and a column in it
        self.col = 0
        self.mode = "fill"                # what the list is for: "fill" an empty slot, "replace" a filled one
        self.pick = 0
        self.pick_top = 0
        self.last_hook: pygame.Rect | None = None

    # -- the member's tiers --------------------------------------------------------------------

    def tiers(self) -> list[tuple[int, list]]:
        """The tiers drawn: (its number, a move per slot, None for an empty slot). A tier with no slot open is not drawn
        (Frankie, 11/1)."""
        sc = self.scene
        loadout = sc.member.loadout or {}
        found = []
        for row in range(1, LoadoutSettings.ROWS + 1):
            moves = [m for m in sc.known if loadout.get(m["id"]) == row]
            cells = moves + [None] * max(0, sc.slots[row - 1] - len(moves))
            if cells:
                found.append((row, cells))
        return found

    def _here(self) -> tuple[int, dict | None]:
        """The tier number and the move under the hook (None for an empty slot)."""
        tiers = self.tiers()
        if not tiers:
            return 1, None
        self.tier = min(self.tier, len(tiers) - 1)
        row, cells = tiers[self.tier]
        self.col = min(self.col, len(cells) - 1)
        return row, cells[self.col]

    def blocking(self) -> bool:
        return not self.scene.text_box.is_done()

    def update(self, dt: float) -> None:
        self.scene.update(dt)

    # -- input -----------------------------------------------------------------------------------

    def handle(self, event) -> str | None:
        sc = self.scene
        audio = self.gm.audio
        if not sc.text_box.is_done():
            if input_map.is_confirm(event):
                sc.text_box.advance()
            return None
        if self.zone == "pick":
            self._handle_pick(event)
            return None
        if input_map.is_cancel(event):
            if sc.held is not None:
                sc.held = None
                audio.play("menu_move")
                return None
            return "back"
        if input_map.is_l1(event) or input_map.is_r1(event):
            sc.held = None
            sc._switch(-1 if input_map.is_l1(event) else 1)
            self.menu.sync_member(sc.member)
            self.tier = self.col = 0
            return None
        if input_map.is_tool(event):
            sc._toggle_stance()
            audio.play("menu_select")
            return None
        tiers = self.tiers()
        if not tiers:
            return None
        if input_map.is_up(event) or input_map.is_down(event):
            self.tier = (self.tier + (-1 if input_map.is_up(event) else 1)) % len(tiers)
            self.col = min(self.col, len(tiers[self.tier][1]) - 1)
            audio.play("menu_move")
        elif input_map.is_left(event) or input_map.is_right(event):
            count = len(tiers[self.tier][1])
            self.col = (self.col + (-1 if input_map.is_left(event) else 1)) % count
            audio.play("menu_move")
        elif input_map.is_confirm(event):
            self._confirm()
        elif input_map.is_menu(event):
            self._replace()
        return None

    def _confirm(self) -> None:
        sc = self.scene
        row, move = self._here()
        if sc.held is not None:
            held = sc.held
            if move is not None and move["id"] == held["id"]:
                sc.held = None                    # put back where it came from
            elif row not in reach(held) or sc.slots[row - 1] == 0:
                self.gm.audio.play("menu_move")   # it does not fit here (the help says so)
            else:
                sc._put(row, swap_with=move)
                self.gm.audio.play("menu_select")
            return
        self.gm.audio.play("menu_select")
        if move is None:
            self._open_list("fill")
        else:
            sc.held = move

    def _replace(self) -> None:
        """X on a filled slot: the list, to replace it."""
        if self._here()[1] is not None and self.scene.held is None:
            self.gm.audio.play("menu_select")
            self._open_list("replace")

    def _open_list(self, mode: str) -> None:
        self.mode, self.zone = mode, "pick"
        self.pick = self.pick_top = 0

    def _listed(self) -> list:
        return self.scene.known

    def _handle_pick(self, event) -> None:
        sc = self.scene
        audio = self.gm.audio
        known = self._listed()
        if input_map.is_cancel(event):
            self.zone = "grid"
            audio.play("menu_move")
        elif input_map.is_up(event) or input_map.is_down(event):
            if known:
                self.pick = (self.pick + (-1 if input_map.is_up(event) else 1)) % len(known)
                if self.pick < self.pick_top:
                    self.pick_top = self.pick
                elif self.pick >= self.pick_top + LIST_ROWS:
                    self.pick_top = self.pick - LIST_ROWS + 1
                audio.play("menu_move")
        elif input_map.is_confirm(event) and known:
            move = known[self.pick]
            row, current = self._here()
            if row not in reach(move):
                audio.play("menu_move")
                return
            self.zone = "grid"
            if current is not None and current["id"] == move["id"]:
                return
            sc.held = move
            sc._put(row, swap_with=current if self.mode == "replace" else None)
            sc.held = None
            audio.play("menu_select")

    # -- what the help says ------------------------------------------------------------------------

    def help_lines(self) -> list[tuple[str, tuple]]:
        sc = self.scene
        row, move = self._here()
        points = sc._points()
        if self.zone == "pick" and self._listed():
            picked = self._listed()[self.pick]
            if row not in reach(picked):
                return [("It does not fit here.", RED)]
            return [(line, WHITE) for line in help_lines(picked, row, points)]
        if sc.held is not None:
            if row not in reach(sc.held):
                return [("It does not fit here.", RED)]
            return [(line, YELLOW) for line in help_lines(sc.held, row, points)]
        if move is None:
            return [("Nothing here yet.", WHITE), ("A: choose an element", GRAY)]
        return [(line, WHITE) for line in help_lines(move, row, points)]

    # -- drawing ---------------------------------------------------------------------------------

    def render(self, surface, lay, active) -> None:
        self._draw_top(surface)
        gy, gh = self._draw_grid(surface)
        self._draw_help(surface)
        if self.zone == "pick":
            self._draw_list(surface, gy)

    def _draw_top(self, surface) -> None:
        sc = self.scene
        member = sc.member
        box(surface, M, M, 256 - 2 * M, TOP_H)
        left, right = shoulder("L"), shoulder("R")
        if left is not None:
            surface.blit(left, (M + 4, M + (TOP_H - 11) // 2))
        if right is not None:
            surface.blit(right, (256 - M - 4 - right.get_width(), M + (TOP_H - 11) // 2))
        _, shown, top = stance_numbers(member)
        name, hp = short_name(member.id), f"{shown}/{top}"
        room = max(width(name), width(hp))
        group = 32 + 6 + room + 10 + 18 + 6 + 18
        x0 = 128 - group // 2
        blit32(surface, member.id, x0, M + (TOP_H - 32) // 2)
        text(surface, name, x0 + 38, M + 9)
        text(surface, hp, x0 + 38, M + 21)
        start = sc.stances[member.stance]["element"] if sc.stances else None
        x = x0 + 38 + room + 10
        for element in member.elements:
            icon = load_element_icon(element)
            if icon is None:
                continue
            surface.blit(icon, (x, M + 9))
            if element == start:
                pygame.draw.rect(surface, YELLOW, (x - 2, M + 7, icon.get_width() + 4, icon.get_height() + 4), 2)
            x += icon.get_width() + 6

    def _draw_grid(self, surface) -> tuple[int, int]:
        sc = self.scene
        tiers = self.tiers()
        gy = M + TOP_H + G
        gh = len(tiers) * ROW + PAD
        box(surface, M, gy, 256 - 2 * M, gh)
        hook_at = None
        here_row, here_move = self._here()
        for index, (row, cells) in enumerate(tiers):
            y = gy + 9 + index * ROW
            text(surface, str(row), M + 4, y, BattleStageSettings.COLOR_MANA)
            for col, move in enumerate(cells):
                under = self.zone == "grid" and (index, col) == (self.tier, self.col)
                color = WHITE
                if sc.held is not None and move is not None and move["id"] == sc.held["id"]:
                    move = None                    # lifted out of its slot: it is empty while carried
                if sc.held is not None and under:
                    move, color = sc.held, YELLOW   # the carried element rides in the slot under the hook
                tint = tag_elements(move, sc.member.elements) if move else None
                label = ""
                if move:
                    label = move["name"] if width(move["name"]) + 18 <= SLOT_W else short_move_name(move)
                rect = slot_box(surface, LEFT + col * SLOT_W, y, SLOT_W, tint, label, color)
                if (index, col) == (self.tier, self.col):
                    hook_at = rect
        if self.zone == "grid" and hook_at is not None:
            self.last_hook = text_renderer.draw_pointer(surface, (hook_at.left + 6, hook_at.bottom - 8), YELLOW,
                                                        from_screen_top=True)
        return gy, gh

    def _draw_list(self, surface, gy: int) -> None:
        sc = self.scene
        known = self._listed()
        shown = known[self.pick_top:self.pick_top + LIST_ROWS]
        px, py = 256 - M - LIST_W, gy - 2
        box(surface, px, py, LIST_W, len(shown) * ROW + 14)
        loadout = sc.member.loadout or {}
        tip = None
        for i, move in enumerate(shown):
            y = py + 9 + i * ROW
            rect = slot_box(surface, px + 6, y, LIST_W - 34, tag_elements(move, sc.member.elements), move["name"], WHITE)
            if move["id"] in loadout:
                dim = pygame.Surface(rect.size, pygame.SRCALPHA)
                dim.fill((0, 0, 0, 150))
                surface.blit(dim, rect.topleft)
                text(surface, f"R{loadout[move['id']]}",px + LIST_W - 22, y, GRAY)
            if self.pick_top + i == self.pick:
                tip = rect
        if tip is not None:
            self.last_hook = text_renderer.draw_pointer(surface, (tip.left + 6, tip.bottom - 8), YELLOW,
                                                        from_screen_top=True)

    def _draw_help(self, surface) -> None:
        y = 224 - M - DESC_H
        box(surface, M, y, 256 - 2 * M, DESC_H)
        font = text_renderer.get_font(SIZE)
        rows = []
        for words, color in self.help_lines():
            for line in text_renderer.wrap(words, font, 256 - 2 * M - 20):
                rows.append((line, color))
        rows, more = paged(rows)
        top = rows_top(y, DESC_H, len(rows))
        for n, (line, color) in enumerate(rows):
            text(surface, line, M + 8, top + n * 12, color)
        if more:
            more_arrow(surface, 256 - M - 18, y + DESC_H - 10)

    def render_over(self, surface) -> None:
        if not self.scene.text_box.is_done():
            self.scene.text_box.render(surface)
