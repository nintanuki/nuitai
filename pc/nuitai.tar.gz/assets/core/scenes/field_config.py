"""The field menu's Config screens (Frankie, 11/21): floating windows over the darkened field, the settings grouped by
kind with one color to a group.

* **The settings:** Cursor and Message speed (orange), Window color (blue, with a swatch of the color and a ``>``), then
  Sound, A and B, X and Y (green), the hooked setting's help along the bottom.
* **Window color** opens its own screen: Window red, green, blue and opacity as sliders with their numbers, Default
  color, and a sample window under them that shows the change as it is made.

Left and right change a setting, A steps it on, B goes back (from the window color screen to the settings, from the
settings to the commands). The settings and what they do, the saving when the screen closes, and the buttons swap that
holds only after leaving are ``ConfigScene``'s (``systems/config.py``); this draws and steers them.
"""

from __future__ import annotations

import pygame

from core.scenes.field_menu_main import M
from core.scenes.field_menu_pages import Page
from core.scenes.config_scene import (AB, BLUE, CURSOR, DEFAULT, GREEN, OPACITY, RED, SOUND, SPEED, XY,
                                      _BAR_COLORS, _OPACITY_COLOR, ConfigScene)
from settings import ColorSettings, FontSettings
from systems import config
from ui import input_map, text_renderer
from ui.field_menu_kit import WHITE, YELLOW, box, text

ORANGE, BLUE_C, GREEN_C = (240, 168, 48), (159, 196, 232), (92, 196, 106)     # one color to a kind
W = 256 - 2 * M
ROW = 16
VALUE_X = M + 24 + 118
COLOR = "color"                       # the row that opens the window color screen
MAIN_ROWS = (CURSOR, SPEED, COLOR, SOUND, AB, XY)
COLOR_ROWS = (RED, GREEN, BLUE, OPACITY, DEFAULT)
KIND = {CURSOR: ORANGE, SPEED: ORANGE, COLOR: BLUE_C, SOUND: GREEN_C, AB: GREEN_C, XY: GREEN_C,
        RED: BLUE_C, GREEN: BLUE_C, BLUE: BLUE_C, OPACITY: BLUE_C, DEFAULT: BLUE_C}
LABELS = {CURSOR: "Cursor", SPEED: "Message speed", COLOR: "Window color", SOUND: "Sound", AB: "A and B",
          XY: "X and Y", RED: "Window red", GREEN: "Window green", BLUE: "Window blue", OPACITY: "Window opacity",
          DEFAULT: "Default color"}
GROUPS = ((CURSOR, SPEED), (COLOR,), (SOUND, AB, XY))      # the windows of the settings screen, top to bottom


class ConfigScreen(Page):
    """The Config screens. ``screen`` is ``main`` or ``color``."""

    full = True

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        self.scene = ConfigScene(self.gm)
        self._entered = False
        if not preview:
            self.scene.on_enter()
            self._entered = True
        self.screen = "main"
        self.at = 0
        self.last_hook: pygame.Rect | None = None

    def close(self) -> None:
        if self._entered:
            self.scene.on_exit()
            self._entered = False

    def update(self, dt: float) -> None:
        self.scene.update(dt)

    def rows(self) -> tuple:
        return MAIN_ROWS if self.screen == "main" else COLOR_ROWS

    def row(self):
        return self.rows()[self.at]

    # -- input -------------------------------------------------------------------------------------

    def handle(self, event) -> str | None:
        audio = self.gm.audio
        rows = self.rows()
        if input_map.is_cancel(event):
            if self.screen == "color":
                self.screen, self.at = "main", MAIN_ROWS.index(COLOR)
                audio.play("menu_move")
                self.scene._held = 0
                return None
            return "back"
        if input_map.is_up(event) or input_map.is_down(event):
            self.at = (self.at + (-1 if input_map.is_up(event) else 1)) % len(rows)
            self.scene._held = 0
            audio.play("menu_move")
            return None
        row = self.row()
        if row == COLOR:
            if input_map.is_confirm(event) or input_map.is_right(event):
                self.screen, self.at = "color", 0
                audio.play("menu_select")
            return None
        if input_map.is_left(event) or input_map.is_right(event) or input_map.is_confirm(event):
            self.scene._cursor = row                 # the scene's rules work on the row it is told of
            self.scene.handle_event(event)
        return None

    # -- what the help says --------------------------------------------------------------------------

    def help_text(self) -> str:
        row = self.row()
        if row == COLOR:
            return "Opens the screen where you change the color and clearness of the windows."
        self.scene._cursor = row
        return self.scene.help_line()

    # -- drawing -------------------------------------------------------------------------------------

    def render(self, surface, lay, active) -> None:
        self.scene._cursor = self.row() if self.row() != COLOR else CURSOR
        if self.screen == "main":
            tip = self._draw_main(surface)
        else:
            tip = self._draw_color(surface)
        self._draw_help(surface)
        self.last_hook = text_renderer.draw_pointer(surface, tip, YELLOW, from_screen_top=True)

    def _band(self, surface, ry: int) -> None:
        shade = pygame.Surface((W - 12, 12), pygame.SRCALPHA)
        shade.fill((255, 255, 255, 36))
        surface.blit(shade, (M + 6, ry - 2))

    def _draw_main(self, surface) -> tuple[int, int]:
        y = M
        tip = (M + 16, M + 12)
        for group in GROUPS:
            h = 8 + len(group) * ROW
            box(surface, M, y, W, h)
            for i, row in enumerate(group):
                ry = y + 8 + i * ROW
                text(surface, LABELS[row], M + 24, ry, KIND[row])
                if row == COLOR:
                    sw = pygame.Rect(VALUE_X, ry, 40, 10)
                    pygame.draw.rect(surface, tuple(c << 3 for c in config.current.window), sw)
                    pygame.draw.rect(surface, WHITE, sw, 1)
                    text(surface, ">", M + W - 18, ry, WHITE)
                else:
                    shown = self.scene.value(row)
                    text(surface, f"< {shown} >" if row == SPEED else shown, VALUE_X, ry, WHITE)
                if row == self.row():
                    self._band(surface, ry)
                    tip = (M + 16, ry + 4)
            y += h + 6
        return tip

    def _draw_color(self, surface) -> tuple[int, int]:
        h = 8 + len(COLOR_ROWS) * ROW
        box(surface, M, M, W, h)
        tip = (M + 16, M + 12)
        for i, row in enumerate(COLOR_ROWS):
            ry = M + 8 + i * ROW
            text(surface, LABELS[row], M + 24, ry, KIND[row])
            if row != DEFAULT:
                self._bar(surface, row, ry)
                text(surface, self.scene.value(row), M + W - 10, ry, WHITE, right=True)
            if row == self.row():
                self._band(surface, ry)
                tip = (M + 16, ry + 4)
        sy = M + h + 6
        box(surface, M, sy, W, 40)           # a window in the color and opacity now set, so the sliders show what they do
        text(surface, "Sample", M + 24, sy + 8, BLUE_C)
        text(surface, "Windows look like this.", M + 24, sy + 24, WHITE)
        return tip

    def _bar(self, surface, row: int, ry: int) -> None:
        if row == OPACITY:
            step, most, color = config.current.opacity, len(config.OPACITIES) - 1, _OPACITY_COLOR
        else:
            step, most, color = config.current.window[row - RED], config.STEPS - 1, _BAR_COLORS[row - RED]
        w = 54
        pygame.draw.rect(surface, ColorSettings.DARK_GRAY, (VALUE_X, ry + 1, w, 6))
        pygame.draw.rect(surface, color, (VALUE_X, ry + 1, round(step * w / most), 6))

    def _draw_help(self, surface) -> None:
        font = text_renderer.get_font(FontSettings.SIZE_BODY)
        lines = text_renderer.wrap(self.help_text(), font, 256 - 2 * M - 12)
        h = 36 if len(lines) <= 2 else 48
        y = 224 - M - h
        box(surface, M, y, 256 - 2 * M, h)
        for n, line in enumerate(lines[:3]):
            text(surface, line, M + 8, y + 8 + n * 12, WHITE)
