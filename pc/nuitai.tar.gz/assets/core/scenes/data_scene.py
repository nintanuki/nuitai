"""Info: Bestiary, Lore and Quests, as Final Fantasy VI keeps its Data (Frankie, 10/23, 11/12).

The field menu's Info (``DataScene``) is a small list of three rows
(Frankie, 11/12): Bestiary, the creatures beaten; Lore, everything about the
world; and Quests, the log (``quest_scene.py``). The field menu has no room
for three more commands, so Info opens this list (Claude's call, 11/12).
Lore opens ``LoreIndexScene``: a row per lore category with a page found so
far, People, Places and the rest (``core/lore.py``; Frankie, 10/25), each
opening Lore's list of that category's pages (``lore_scene.py``). The time
played and the steps moved to the field menu (Frankie, 10/25). A row is a
name, a help line, and a screen to open.

Final Fantasy VI's layout: a small box saying Data, the help line under
it for the row the cursor is on, the list below.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

import pygame

from core import lore
from core.scene import Scene
from settings import ColorSettings, FontSettings, ScreenSettings, UISettings
from ui import input_map, text_renderer
from ui.window import draw_header
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager

_LIST_TOP_Y = UISettings.HEADER_LIST_TOP
_LIST_LEFT_X = 16 + UISettings.MENU_HOOK_ROOM  # Room for the hook by the window's edge.
_VALUE_RIGHT_X = ScreenSettings.RESOLUTION[0] - 16
_ROW_HEIGHT = 16
# Each row's name and help line, the lore categories' first; the cartridge
# reads them too, so a help line fits its window in capitals, 30 letters at most.
BESTIARY = ("Bestiary", "Every creature beaten.")
# The cartridge reads ROWS for the lore rows and their help lines (make_art).
ROWS = lore.CATEGORIES + (BESTIARY,)
LORE = ("Lore", "The world, its gods and people.")
QUESTS = ("Quests", "What you have been asked to do.")
INFO_ROWS = (BESTIARY, LORE, QUESTS)


class DataScene(Scene):
    """Info: Bestiary, Lore and Quests (Frankie, 11/12); confirm opens one."""

    OPAQUE = True
    TITLE = "Info"

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        self._cursor = 0

    def rows(self) -> list[tuple[str, str, str | None, Callable[[], None] | None]]:
        """Each row: its name, its help line, its number (None for a screen) and what confirm opens."""
        return [(BESTIARY[0], BESTIARY[1], None, self._open_bestiary),
                (LORE[0], LORE[1], None, self._open_lore_index),
                (QUESTS[0], QUESTS[1], None, self._open_quests)]

    def _open_bestiary(self) -> None:
        """Push the bestiary: a page per creature the party has beaten."""
        from core.scenes.bestiary_scene import BestiaryScene  # local: cycle.

        self.gm.scene_stack.push(BestiaryScene(self.gm))

    def _open_lore_index(self) -> None:
        """Push Lore's list of categories."""
        self.gm.scene_stack.push(LoreIndexScene(self.gm))

    def _open_quests(self) -> None:
        """Push the quest log."""
        from core.scenes.quest_scene import QuestScene  # local: cycle.

        self.gm.scene_stack.push(QuestScene(self.gm))

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move the cursor, open a row, or go back."""
        rows = self.rows()
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif input_map.is_up(event) or input_map.is_down(event):
            self._cursor = (self._cursor + (-1 if input_map.is_up(event) else 1)) % len(rows)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            opens = rows[self._cursor][3]
            if opens is not None:
                self.gm.audio.play("menu_select")
                opens()

    def render(self, surface: pygame.Surface) -> None:
        """The top boxes with the help line, and a row per screen."""
        render_scene_background(self, surface)
        rows = self.rows()
        draw_header(surface, self.TITLE, [rows[self._cursor][1]])
        size = FontSettings.SIZE_BODY
        for index, (name, _, value, _) in enumerate(rows):
            y = _LIST_TOP_Y + index * _ROW_HEIGHT
            text_renderer.draw_text(surface, name, (_LIST_LEFT_X, y), color=ColorSettings.WHITE, size=size)
            if value is not None:
                text_renderer.draw_text(surface, value, (_VALUE_RIGHT_X - text_renderer.text_width(value, size), y),
                                        color=ColorSettings.WHITE, size=size)
            if index == self._cursor:
                text_renderer.draw_pointer(surface, (_LIST_LEFT_X - 4, y + 3))


class LoreIndexScene(DataScene):
    """Lore's list of categories with a page found; confirm opens that category's pages."""

    TITLE = "Lore"

    def rows(self) -> list[tuple[str, str, str | None, Callable[[], None] | None]]:
        """A row per lore category with a page found."""
        return [(name, line, None, lambda name=name: self._open_category(name))
                for name, line in lore.categories_found(self.gm.party)]

    def _open_category(self, category: str) -> None:
        """Push Lore: the pages of ``category`` found so far (core/lore.py)."""
        from core.scenes.lore_scene import LoreScene  # local: cycle.

        self.gm.scene_stack.push(LoreScene(self.gm, category))
