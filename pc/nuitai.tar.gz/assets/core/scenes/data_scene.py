"""Info: Quests, Bestiary, Glossary, Lore and Records, as Final Fantasy VI keeps its Data (Frankie, 10/23, 11/13).

The field menu's Info (``DataScene``) is a small list of five rows
(Frankie, 11/13), in this order: Quests, the log (``quest_scene.py``);
Bestiary, the creatures beaten; Glossary, the words learned (the Words
category of Lore, lifted out of it); Lore, everything else about the world;
and Records, what the party has done (``RecordsScene``). The field menu has
no room for five more commands, so Info opens this list (Claude's call,
11/12). Lore opens ``LoreIndexScene``: a row per lore category with a page
found so far, People, Places and the rest but Words (``core/lore.py``;
Frankie, 10/25), each opening Lore's list of that category's pages
(``lore_scene.py``). The time played and the steps moved to the field menu
(Frankie, 10/25). A row is a name, a help line, and a screen to open.

Final Fantasy VI's layout: a small box saying Data, the help line under
it for the row the cursor is on, the list below.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

import pygame

from core import lore
from core.scene import Scene
from settings import ColorSettings, FontSettings, ScreenSettings, UISettings
from systems import records
from ui import input_map, text_renderer
from ui.window import draw_header
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager

_LIST_TOP_Y = UISettings.HEADER_LIST_TOP
_LIST_LEFT_X = 16 + UISettings.MENU_HOOK_ROOM  # Room for the hook by the window's edge.
_VALUE_RIGHT_X = ScreenSettings.RESOLUTION[0] - 16
_ROW_HEIGHT = 16
# Each row's name and help line, the lore categories' first; the cartridge
# reads them too, so a help line fits its window in capitals, 30 letters at most.
BESTIARY = ("Bestiary", "Every creature beaten.")
LORE = ("Lore", "The world, its gods and people.")
QUESTS = ("Quests", "What you have been asked to do.")
GLOSSARY = ("Glossary", "Words you have learned.")
RECORDS = ("Records", "What your party has done.")
# Info's rows, in order (Frankie, 11/13).
INFO_ROWS = (QUESTS, BESTIARY, GLOSSARY, LORE, RECORDS)
# The cartridge reads ROWS for the lore rows and their help lines (make_art).
ROWS = lore.CATEGORIES + (BESTIARY, GLOSSARY, RECORDS)


class DataScene(Scene):
    """Info: Quests, Bestiary, Glossary, Lore and Records (Frankie, 11/13); confirm opens one."""

    OPAQUE = True
    TITLE = "Info"

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        self._cursor = 0

    def rows(self) -> list[tuple[str, str, str | None, Callable[[], None] | None]]:
        """Each row: its name, its help line, its number (None for a screen) and what confirm opens."""
        return [(QUESTS[0], QUESTS[1], None, self._open_quests),
                (BESTIARY[0], BESTIARY[1], None, self._open_bestiary),
                (GLOSSARY[0], GLOSSARY[1], None, self._open_glossary),
                (LORE[0], LORE[1], None, self._open_lore_index),
                (RECORDS[0], RECORDS[1], None, self._open_records)]

    def _open_bestiary(self) -> None:
        """Push the bestiary: a page per creature the party has beaten."""
        from core.scenes.bestiary_scene import BestiaryScene  # local: cycle.

        self.gm.scene_stack.push(BestiaryScene(self.gm))

    def _open_glossary(self) -> None:
        """Push the words learned: Lore's list of the Words category."""
        from core.scenes.lore_scene import LoreScene  # local: cycle.

        self.gm.scene_stack.push(LoreScene(self.gm, lore.GLOSSARY))

    def _open_lore_index(self) -> None:
        """Push Lore's list of categories."""
        self.gm.scene_stack.push(LoreIndexScene(self.gm))

    def _open_records(self) -> None:
        """Push the records: what the party has done, in counts."""
        self.gm.scene_stack.push(RecordsScene(self.gm))

    def _open_quests(self) -> None:
        """Push the quest log."""
        from core.scenes.quest_scene import QuestScene  # local: cycle.

        self.gm.scene_stack.push(QuestScene(self.gm))

    def handle_event(self, event: pygame.event.Event) -> None:
        """Move the cursor, open a row, or go back."""
        rows = self.rows()
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif input_map.is_up(event) or input_map.is_down(event):
            self._cursor = (self._cursor + (-1 if input_map.is_up(event) else 1)) % len(rows)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            opens = rows[self._cursor][3]
            if opens is not None:
                self.gm.audio.play("menu_select")
                opens()

    def render(self, surface: pygame.Surface) -> None:
        """The top boxes with the help line, and a row per screen."""
        render_scene_background(self, surface)
        rows = self.rows()
        draw_header(surface, self.TITLE, [rows[self._cursor][1]])
        size = FontSettings.SIZE_BODY
        for index, (name, _, value, _) in enumerate(rows):
            y = _LIST_TOP_Y + index * _ROW_HEIGHT
            text_renderer.draw_text(surface, name, (_LIST_LEFT_X, y), color=ColorSettings.WHITE, size=size)
            if value is not None:
                text_renderer.draw_text(surface, value, (_VALUE_RIGHT_X - text_renderer.text_width(value, size), y),
                                        color=ColorSettings.WHITE, size=size)
            if index == self._cursor:
                text_renderer.draw_pointer(surface, (_LIST_LEFT_X - 4, y + 3))


class LoreIndexScene(DataScene):
    """Lore's list of categories with a page found; confirm opens that category's pages."""

    TITLE = "Lore"

    def rows(self) -> list[tuple[str, str, str | None, Callable[[], None] | None]]:
        """A row per lore category with a page found."""
        return [(name, line, None, lambda name=name: self._open_category(name))
                for name, line in lore.categories_found(self.gm.party) if name != lore.GLOSSARY]

    def _open_category(self, category: str) -> None:
        """Push Lore: the pages of ``category`` found so far (core/lore.py)."""
        from core.scenes.lore_scene import LoreScene  # local: cycle.

        self.gm.scene_stack.push(LoreScene(self.gm, category))


class RecordsScene(Scene):
    """Records: labeled counts of what the party has done (Frankie, 11/13); only B does anything."""

    OPAQUE = True
    TITLE = "Records"

    def rows(self) -> list[tuple[str, int]]:
        """Each count with its label."""
        return records.counts(self.gm.party)

    def handle_event(self, event: pygame.event.Event) -> None:
        """Go back."""
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()

    def render(self, surface: pygame.Surface) -> None:
        """The top boxes, then a label at the left and its number at the right."""
        render_scene_background(self, surface)
        draw_header(surface, self.TITLE, [RECORDS[1]])
        size = FontSettings.SIZE_BODY
        for index, (label, number) in enumerate(self.rows()):
            y = _LIST_TOP_Y + index * _ROW_HEIGHT
            text_renderer.draw_text(surface, label, (_LIST_LEFT_X, y), color=ColorSettings.YELLOW, size=size)
            words = str(number)
            text_renderer.draw_text(surface, words, (_VALUE_RIGHT_X - text_renderer.text_width(words, size), y),
                                    color=ColorSettings.WHITE, size=size)
