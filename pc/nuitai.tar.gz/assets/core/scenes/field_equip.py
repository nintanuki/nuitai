"""The field menu's Equip screen (Frankie, 11/21): the layout from before the tabs in the new floating style, one member
at a time.

Top to bottom: the member's window (the 32 by 32 sprite, Weapon and Relic with their icons, the L and R buttons at its
edges, which change the member); Equip and Mastery (whichever is open has its word in yellow); then two windows side
by side, the list of what can go in the slot and the stats by their three letters; and the description along the bottom.
There is no Remove: equipping exchanges, and a dash row at the end of the list takes the item off.

It opens straight on Weapon with the stats plain. A opens the list, where each stat shows what it is now and what it would
be (a rise in yellow, a drop in red) so nothing jumps; relics show the elements they resist or are weak to under the
member. Up from Weapon goes to the Equip and Mastery words; Mastery shows the member's weapon types and A on one shows
its Skill and the rest, as the old page did. The rules are ``EquipScene``'s (what can be held, what wearing does).
"""

from __future__ import annotations

import pygame

from core.equipment import element_changes
from core.scenes.equip_scene import (SLOTS, _bonus_line, _learned_by_level, candidates, equip_help, numbers, put_on)
from core.scenes.field_element import shoulder
from core.scenes.field_items import item_row
from core.scenes.field_menu_main import M, G, blit32
from core.scenes.field_menu_pages import Page
from core.scenes.party_scene import draw_notches
from core.shared import skill_for
from core.stats import STAT_SHORT
from settings import ColorSettings, ItemSettings, MasterySettings
from systems import mastery
from ui import input_map, text_renderer
from ui.battle_stage import element_icon
from ui.field_menu_kit import GRAY, WHITE, YELLOW, box, more_arrow, text
from ui.item_icon import item_icon, kind_surface, weapon_kind
from ui.window import help_wrap

CYAN = ColorSettings.LABEL_CYAN
DROP = ColorSettings.STAT_DROP
W = 256 - 2 * M
CHAR_H, CMD_H, DESC_H = 44, 20, 28
CMD_Y = M + CHAR_H + G
BIG_Y = CMD_Y + CMD_H + G
DESC_Y = 224 - M - DESC_H
BIG_H = DESC_Y - G - BIG_Y
LIST_W = 128
ROWS = 8                                   # rows the list shows before it scrolls
PITCH = 10
SHORT = [("max_hp", "HP"), *STAT_SHORT.items()]
WORDS = (("Equip", 60), ("Mastery", 140))


class EquipScreen(Page):
    """Zones: ``slot`` (the hook on Weapon or Relic), ``list`` (choosing), ``command`` (on Equip or Mastery),
    ``mastery`` (on a weapon type) and ``type`` (one opened)."""

    full = True

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        self.member = menu.member_obj()
        self.zone = "slot"
        self.slot = 0                       # 0 Weapon, 1 Relic
        self.pick = 0
        self.word = 0                       # 0 Equip, 1 Mastery: the one that is open
        self.type_row = 0
        self.last_hook: pygame.Rect | None = None

    # -- the list --------------------------------------------------------------------------------

    def choices(self) -> list:
        """What can go in the slot, the worn one first, and a last empty row that takes the item off."""
        return candidates(self.gm.party, self.member, SLOTS[self.slot]) + [None]

    def _hovered(self) -> str | None:
        choices = self.choices()
        return choices[self.pick] if self.zone == "list" and self.pick < len(choices) else None

    # -- input -----------------------------------------------------------------------------------

    def handle(self, event) -> str | None:
        audio = self.gm.audio
        if input_map.is_l1(event) or input_map.is_r1(event):
            self._switch(-1 if input_map.is_l1(event) else 1)
            return None
        return getattr(self, f"_zone_{self.zone}")(event)

    def _switch(self, step: int) -> None:
        members = self.gm.party.members
        if len(members) < 2:
            return
        index = next((i for i, m in enumerate(members) if m is self.member), 0)
        self.member = members[(index + step) % len(members)]
        self.menu.sync_member(self.member)
        self.pick = 0
        self.type_row = min(self.type_row, max(0, len(mastery.weapon_types(self.member.id)) - 1))
        self.gm.audio.play("menu_move")

    def _zone_slot(self, event) -> str | None:
        audio = self.gm.audio
        if input_map.is_cancel(event):
            return "back"
        if input_map.is_down(event):
            if self.slot == 0:
                self.slot = 1
            else:
                self.zone, self.word = "command", 0
            audio.play("menu_move")
        elif input_map.is_up(event):
            if self.slot == 1:
                self.slot = 0
            else:
                self.zone, self.word = "command", 0
            audio.play("menu_move")
        elif input_map.is_confirm(event):
            self.zone, self.pick = "list", 0
            audio.play("menu_select")
        return None

    def _zone_list(self, event) -> str | None:
        audio = self.gm.audio
        choices = self.choices()
        if input_map.is_cancel(event):
            self.zone = "slot"
            audio.play("menu_move")
        elif input_map.is_up(event) or input_map.is_down(event):
            self.pick = (self.pick + (-1 if input_map.is_up(event) else 1)) % len(choices)
            audio.play("menu_move")
        elif input_map.is_confirm(event):
            put_on(self.gm.party, self.member, SLOTS[self.slot], choices[self.pick])       # None takes it off
            self.zone = "slot"
            audio.play("menu_select")
        return None

    def _zone_command(self, event) -> str | None:
        audio = self.gm.audio
        if input_map.is_cancel(event):
            return "back"
        if input_map.is_left(event) or input_map.is_right(event):
            self.word = 1 - self.word
            audio.play("menu_move")
        elif input_map.is_down(event) or input_map.is_confirm(event):
            if self.word == 0:
                self.zone, self.slot = "slot", 0
            else:
                held = mastery.type_held(self.member.id, self.member.weapon)
                types = mastery.weapon_types(self.member.id)
                self.type_row = types.index(held) if held in types else 0
                self.zone = "mastery"
            audio.play("menu_select")
        elif input_map.is_up(event):
            self.zone, self.slot = "slot", 1
            audio.play("menu_move")
        return None

    def _zone_mastery(self, event) -> str | None:
        audio = self.gm.audio
        count = len(mastery.weapon_types(self.member.id))
        if input_map.is_cancel(event):
            self.zone, self.word = "command", 1
            audio.play("menu_move")
        elif input_map.is_up(event) and self.type_row == 0:
            self.zone, self.word = "command", 1
            audio.play("menu_move")
        elif count and (input_map.is_up(event) or input_map.is_down(event)):
            self.type_row = (self.type_row + (-1 if input_map.is_up(event) else 1)) % count
            audio.play("menu_move")
        elif count and input_map.is_confirm(event):
            self.zone = "type"
            audio.play("menu_select")
        return None

    def _zone_type(self, event) -> str | None:
        if input_map.is_cancel(event) or input_map.is_confirm(event):
            self.zone = "mastery"
            self.gm.audio.play("menu_select")
        return None

    # -- what the help says --------------------------------------------------------------------------

    def help_lines(self) -> list[str]:
        return [line for words in self._help_words() for line in help_wrap(words, 232)]

    def _help_words(self) -> list[str]:
        z = self.zone
        if z == "command":
            return (["Change the weapon and relic a member carries."] if self.word == 0 else
                    ["See how skilled a member is with each kind of weapon."])
        if z == "mastery":
            return ["Press A to see more about this kind of weapon."]
        if z == "type":
            type_id = mastery.weapon_types(self.member.id)[self.type_row]
            skill = skill_for(self.member.id, type_id)
            return [skill.get("description", "")] if skill else ["This kind of weapon has no Skill yet."]
        if z == "list":
            item = self._hovered()
            return [" ".join(equip_help(item))] if item else ["Takes off what is equipped."]
        worn = getattr(self.member, SLOTS[self.slot])
        return [" ".join(equip_help(worn))] if worn else ["Nothing is equipped here."]

    # -- drawing -------------------------------------------------------------------------------------

    def render(self, surface, lay, active) -> None:
        z = self.zone
        hover = self._hovered() if self.slot == 1 else None
        self._draw_member(surface, hover)
        self._draw_words(surface)
        if z in ("mastery", "type"):
            self._draw_mastery(surface)
        else:
            self._draw_list_and_stats(surface)
        self._draw_help(surface)
        self._draw_hook(surface)

    def _band(self, surface, x, y, w, h=10) -> None:
        shade = pygame.Surface((w, h), pygame.SRCALPHA)
        shade.fill((255, 255, 255, 36))
        surface.blit(shade, (x, y))

    def _draw_member(self, surface, relic_hint) -> None:
        box(surface, M, M, W, CHAR_H)
        left, right = shoulder("L"), shoulder("R")
        if left is not None:
            surface.blit(left, (M - 4, M + 17))
        if right is not None:
            surface.blit(right, (M + W + 4 - right.get_width(), M + 17))
        blit32(surface, self.member.id, M + 28, M + 6)
        for i, slot in enumerate(SLOTS):
            y = M + 9 + i * 14
            text(surface, "Weapon" if slot == "weapon" else "Relic", M + 66, y, CYAN)
            worn = getattr(self.member, slot)
            if worn:
                icon = item_icon(worn)
                if icon is not None:
                    surface.blit(icon, (M + 118, y))
                text(surface, ItemSettings.NAMES.get(worn, worn), M + 130, y)
        if relic_hint:        # what the hooked relic resists (a green arrow up) and is weak to (a red one down)
            x = M + 130
            for element, direction in element_changes(relic_hint):
                icon = element_icon(element)
                if icon is not None:
                    surface.blit(icon, (x, M + 33))
                ay = M + 33
                pts = ([(x + 10, ay + 7), (x + 14, ay + 7), (x + 12, ay + 3)] if direction > 0
                       else [(x + 10, ay + 3), (x + 14, ay + 3), (x + 12, ay + 7)])
                pygame.draw.polygon(surface, ColorSettings.ELEMENT_ARROW if direction > 0 else DROP, pts)
                x += 28

    def _draw_words(self, surface) -> None:
        box(surface, M, CMD_Y, W, CMD_H)
        open_word = 1 if self.zone in ("mastery", "type") or (self.zone == "command" and self.word == 1) else 0
        for i, (word, x) in enumerate(WORDS):
            text(surface, word, x, CMD_Y + 6, YELLOW if i == open_word else WHITE)

    def _draw_list_and_stats(self, surface) -> None:
        member = self.member
        box(surface, M, BIG_Y, LIST_W, BIG_H)
        rows = self.choices()
        first = max(0, self.pick - ROWS + 1) if self.zone == "list" else 0
        worn = getattr(member, SLOTS[self.slot])
        for n, item in enumerate(rows[first:first + ROWS]):
            y = BIG_Y + 7 + n * PITCH
            if self.zone == "list" and first + n == self.pick:
                self._band(surface, M + 6, y - 1, LIST_W - 12)
            if item is None:
                text(surface, "-", M + 30, y)
            else:
                item_row(surface, item, M + 14, y, GRAY if item == worn else WHITE, room=98)
        if len(rows) > first + ROWS:
            more_arrow(surface, M + LIST_W - 16, BIG_Y + BIG_H - 9)
        sx = M + LIST_W + G
        sw = 256 - M - sx
        box(surface, sx, BIG_Y, sw, BIG_H)
        now = numbers(member, member.weapon)
        hovered = self._hovered()
        then = None
        if self.zone == "list":
            weapon = hovered if hovered and SLOTS[self.slot] == "weapon" else (
                None if hovered is None and SLOTS[self.slot] == "weapon" else member.weapon)
            then = numbers(member, weapon)
        for n, (key, label) in enumerate(SHORT):
            y = BIG_Y + 7 + n * PITCH
            text(surface, label, sx + 8, y, CYAN)
            text(surface, str(now[key]), sx + 58, y, right=True)
            if then is None:
                continue
            color = YELLOW if then[key] > now[key] else DROP if then[key] < now[key] else WHITE
            pygame.draw.polygon(surface, color, [(sx + 63, y + 1), (sx + 67, y + 4), (sx + 63, y + 7)])
            text(surface, str(then[key]), sx + sw - 8, y, color, right=True)

    def _draw_type_row(self, surface, y: int, type_id: str, x: int) -> None:
        exp = self.member.mastery.get(type_id, 0)
        level = mastery.level_for(exp)
        top = level >= MasterySettings.MAX_LEVEL
        surface.blit(kind_surface(weapon_kind(type_id)), (x, y))
        text(surface, mastery.type_name(type_id), x + 10, y)
        text(surface, f"Lv {level}", M + W - 16, y, YELLOW if top else WHITE, right=True)
        step = mastery.progress(exp)
        draw_notches(surface, (x + 10, y + 11), 10 if step is None else step[0] * 10 // step[1],
                     YELLOW if top else ColorSettings.STAT_TEXT_STYLES["strength"]["color"])
        text(surface, "MAX" if step is None else f"{step[0]}/{step[1]}", M + W - 16, y + 11,
             YELLOW if top else GRAY, right=True)

    def _draw_mastery(self, surface) -> None:
        box(surface, M, BIG_Y, W, BIG_H)
        types = mastery.weapon_types(self.member.id)
        if self.zone == "mastery":
            for i, type_id in enumerate(types):
                y = BIG_Y + 9 + i * 26
                self._draw_type_row(surface, y, type_id, M + 20)
                if i == self.type_row:
                    self._band(surface, M + 6, y - 2, W - 12, 12)
            return
        type_id = types[self.type_row]
        self._draw_type_row(surface, BIG_Y + 6, type_id, M + 20)
        level = mastery.level_for(self.member.mastery.get(type_id, 0))
        skill = skill_for(self.member.id, type_id)
        y = BIG_Y + 32
        text(surface, "Skill", M + 20, y, CYAN)
        text(surface, skill["name"] if skill else "None", M + 68, y)
        text(surface, "Strokes", M + 20, y + 12, CYAN)
        text(surface, _bonus_line(level).replace("Damage", "Dmg"), M + 20, y + 24)
        learned = [(at, name) for at, name in (_learned_by_level(skill["id"]) if skill else []) if at <= level]
        for row, (at, name) in enumerate(learned[:3]):
            text(surface, f"Lv {at}", M + 20, y + 38 + row * 10, CYAN)
            text(surface, name, M + 60, y + 38 + row * 10)

    def _draw_help(self, surface) -> None:
        box(surface, M, DESC_Y, W, DESC_H)
        for r, line in enumerate(self.help_lines()[:2]):
            text(surface, line, M + 12, DESC_Y + 5 + r * 12)

    def _draw_hook(self, surface) -> None:
        z = self.zone
        if z == "slot":
            tip = (M + 60, M + 9 + self.slot * 14 + 4)
        elif z == "command":
            tip = (WORDS[self.word][1] - 6, CMD_Y + 10)
        elif z == "list":
            first = max(0, self.pick - ROWS + 1)
            tip = (M + 6, BIG_Y + 7 + (self.pick - first) * PITCH + 4)
        elif z == "mastery":
            tip = (M + 12, BIG_Y + 9 + self.type_row * 26 + 4)
        else:
            tip = (M + 12, BIG_Y + 6 + 4)
        self.last_hook = text_renderer.draw_pointer(surface, tip, YELLOW, from_screen_top=True)
