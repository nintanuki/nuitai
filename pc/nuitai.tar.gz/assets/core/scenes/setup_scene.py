"""Setup, what Select opens on the title (Frankie, 11/18): a test game started at any scene.

Six pages, turned with L and R: Start (the scene, two quick toggles, Start itself), Party (who is in
and who fights), Stats, Elements, Skills and Bag. Up and down move the hook, left and right change the
row it is on, confirm on a number adds ten, B goes back to the title. Every default is what the game
itself gives at the chosen scene (``core/setup_state.py``); choosing another scene puts everything back
to that scene's defaults. A row with a list behind it (the scene) opens it on confirm.

The hook is the Config screen's one fishhook, and the list slides to keep it in view in both directions
(``window_first``); a list that does not fit shows the scroll arrows.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Callable

import pygame

from core import scene_select
from core.scene import Scene
from core.setup_state import BANK, Setup
from core.shared import by_id, short_name
from core.stats import STAT_KEYS, STAT_NAMES
from settings import ColorSettings, FontSettings, MasterySettings, ScreenSettings, SetupSettings, StatSettings, UISettings
from systems import mastery
from ui import input_map, text_renderer
from ui.scroll_mark import draw_list_marks
from ui.window import draw_header, help_wrap
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager

_LIST_TOP_Y = UISettings.HEADER_LIST_TOP
_LIST_LEFT_X = 24      # room for the fishhook
_VALUE_RIGHT_X = 232   # values end here, so a long scene name and a short number both line up
_ROW_HEIGHT = 16
_MARK_X = 246
# Rows that fit between the list's top and the bottom of the screen.
ROWS_SHOWN = (ScreenSettings.HEIGHT - _LIST_TOP_Y) // _ROW_HEIGHT

START, PARTY, STATS, ELEMENTS, SKILLS, BAG = range(6)
_ON, _OFF = ColorSettings.GREEN, ColorSettings.GRAY


def window_first(cursor: int, first: int, shown: int, total: int) -> int:
    """The first row of a list of ``total`` rows, ``shown`` at a time, so the cursor row is in view.

    Slides only as far as it must, in either direction, and never past either end."""
    if total <= shown:
        return 0
    if cursor < first:
        first = cursor
    elif cursor >= first + shown:
        first = cursor - shown + 1
    return max(0, min(first, total - shown))


@dataclass
class Row:
    """One row of a page: its label, its value at the right, and what changes it."""

    label: str
    value: str = ""
    help: str = ""
    color: tuple[int, int, int] | None = None        # the label's color
    value_color: tuple[int, int, int] | None = None
    step: Callable[[int], bool] | None = None        # left (-1) and right (+1); True if it changed
    confirm: Callable[[], bool] | None = None        # A; None steps on by one, as right does
    jump: Callable[[], bool] | None = None           # A on a number: adds ten
    repeat: bool = False                              # held left or right, it goes on by itself
    fade: bool = False                                # shown gray: a zero or an empty seat


class SetupScene(Scene):
    """SETUP: pick a scene, change what the player has there, start."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        self.setup = Setup(gm, 0)
        self.page = START
        self.cursors = [0] * len(SetupSettings.PAGES)
        self.firsts = [0] * len(SetupSettings.PAGES)
        # The hero on the Stats, Elements and Skills pages, and the group on the Bag page.
        self.hero = 0
        self.group = 0
        # The scene list, open over the Start page.
        self.listing = False
        self.list_cursor = 0
        self.list_first = 0
        self._held = 0
        self._held_for = 0.0

    # ------------------------------------------------------------------
    # THE PAGES: each is a list of rows, rebuilt from the setup every time it is drawn or changed
    # ------------------------------------------------------------------

    def rows(self) -> list[Row]:
        return (self._start_rows, self._party_rows, self._stats_rows, self._element_rows,
                self._skill_rows, self._bag_rows)[self.page]()

    def _hero_id(self) -> str:
        heroes = self.setup.heroes()
        self.hero = max(0, min(self.hero, len(heroes) - 1))
        return heroes[self.hero]

    def _hero_row(self, help: str = "") -> Row:
        hero = self._hero_id()
        return Row("Hero", short_name(hero), help or "Left and right pick who. Away ones can be set up too.",
                   step=self._pick_hero, confirm=lambda: self._pick_hero(1))

    def _pick_hero(self, step: int) -> bool:
        count = len(self.setup.heroes())
        if count < 2:
            return False
        self.hero = (self.hero + step) % count
        self.cursors[self.page] = min(self.cursors[self.page], len(self.rows()) - 1)
        return True

    # Start ------------------------------------------------------------

    def _start_rows(self) -> list[Row]:
        s = self.setup

        def scene_step(step: int) -> bool:
            s.choose(s.index + step)
            self.hero = 0
            return True

        def toggle(name: str) -> Callable[[int], bool]:
            def flip(_step: int = 1) -> bool:
                setattr(s, name, not getattr(s, name))
                return True
            return flip

        flip_medicine, flip_hp = toggle("max_medicine"), toggle("max_hp")
        return [
            Row("Scene", s.scene, "Left and right pick a scene; A lists them. The rest fills in to match.",
                color=ColorSettings.LABEL_CYAN, step=scene_step, confirm=self._open_list),
            Row("Max medicine", "On" if s.max_medicine else "Off",
                "Every healing and reviving item at its limit, and every battle bag full.",
                step=flip_medicine, confirm=flip_medicine, value_color=_ON if s.max_medicine else _OFF),
            Row("Max HP", "On" if s.max_hp else "Off",
                "Everyone at full HP, with Vitality at its cap.",
                step=flip_hp, confirm=flip_hp, value_color=_ON if s.max_hp else _OFF),
            Row("Put back", "", "Back to what the game has at this scene.", confirm=self._put_back),
            Row("Start", "", "Begin the game here, as set.", color=ColorSettings.YELLOW, confirm=self._start),
        ]

    def _open_list(self) -> bool:
        self.listing = True
        self.list_cursor = self.setup.index
        self.list_first = window_first(self.list_cursor, 0, ROWS_SHOWN, len(scene_select.beat_names()))
        return True

    def _put_back(self) -> bool:
        self.setup.reset()
        return True

    def _start(self) -> bool:
        self.setup.start()
        return False   # the stack is new: nothing left to sound over

    # Party ------------------------------------------------------------

    def _party_rows(self) -> list[Row]:
        s = self.setup
        rows = []
        for slot in range(s.slot_count()):
            hero = s.slot(slot)
            rows.append(Row(
                s.slot_name(slot), short_name(hero) if hero else "Away",
                "Kailo leads. The first three fight; the rest wait on the bench." if slot == 0 else
                ("Left and right pick who. An empty seat sends them away." if slot else ""),
                color=ColorSettings.LABEL_CYAN,
                step=lambda step, slot=slot: s.cycle_slot(slot, step),
                confirm=lambda slot=slot: s.cycle_slot(slot, 1), fade=hero is None,
            ))
        return rows

    # Stats ------------------------------------------------------------

    def _stats_rows(self) -> list[Row]:
        s = self.setup
        hero = self._hero_id()
        member = s.member(hero)
        points = s.points(hero)
        rows = [self._hero_row()]
        for key in STAT_KEYS:
            grown = member.growth.get(key, 0)
            help = f"Base {StatSettings.BASE_POINTS}, up to {SetupSettings.STAT_CAP}. Left and right change it."
            if key == "hp":
                help = f"Max HP {member.max_hp}. " + help
            rows.append(Row(
                STAT_NAMES[key], f"{points[key]}" + (f" +{grown}" if grown else ""), help,
                color=ColorSettings.STAT_EDGE_STYLES[key]["color"],
                step=lambda step, key=key, hero=hero: s.grow(hero, key, step),
                jump=lambda key=key, hero=hero: s.grow(hero, key, SetupSettings.COUNT_JUMP),
                repeat=True,
            ))
        return rows

    # Elements ---------------------------------------------------------

    def _element_rows(self) -> list[Row]:
        s = self.setup
        hero = self._hero_id()
        member = s.member(hero)
        slots = ", ".join(str(n) for n in s.slots() if n)
        rows = [self._hero_row(f"Open slots by row: {slots}.")]
        rows.append(Row(
            "Stance", s.stance_name(hero), "The stance they start a fight in.",
            step=lambda _step, hero=hero: (s.flip_stance(hero), True)[1],
            confirm=lambda hero=hero: (s.flip_stance(hero), True)[1]))
        for move in s.learnable(hero):
            place = s.where(hero, move["id"])
            value = "Not learned" if place is None else ("Bank" if place == BANK else f"Row {place}")
            rows.append(Row(
                move["name"], value, (move.get("description") or "")[:64],
                step=lambda step, hero=hero, mid=move["id"]: s.step_move(hero, mid, step),
                confirm=lambda hero=hero, mid=move["id"]: s.step_move(hero, mid, 1),
                fade=place is None,
            ))
        return rows

    # Skills -----------------------------------------------------------

    def _skill_rows(self) -> list[Row]:
        s = self.setup
        hero = self._hero_id()
        member = s.member(hero)
        weapon = by_id("weapons").get(member.weapon or "", {}).get("name", "Empty hands")
        rows = [self._hero_row("A Skill comes with the weapon type held and how well it is known.")]
        rows.append(Row("Weapon", weapon, "What they hold. It changes their stats and which Skill they have.",
                        step=lambda step, hero=hero: s.step_weapon(hero, step),
                        confirm=lambda hero=hero: s.step_weapon(hero, 1)))
        for type_id in s.weapon_types(hero):
            skill = s.skill_name(hero, type_id)
            level = s.level(hero, type_id)
            rows.append(Row(
                mastery.type_name(type_id), f"{skill + ' ' if skill else ''}Lv {level}",
                f"Skill {skill}. Left and right change the level, 1 to {MasterySettings.MAX_LEVEL}." if skill
                else f"Left and right change the level, 1 to {MasterySettings.MAX_LEVEL}.",
                step=lambda step, hero=hero, t=type_id: s.set_level(hero, t, step),
                jump=lambda hero=hero, t=type_id: s.set_level(hero, t, 1), repeat=False,
            ))
        return rows

    # Bag --------------------------------------------------------------

    def _bag_rows(self) -> list[Row]:
        s = self.setup
        from settings import ItemSettings  # local: as the field does

        categories = Setup.CATEGORIES
        self.group %= len(categories)
        rows = [Row("Group", categories[self.group], "Left and right pick a group of items.",
                    step=self._pick_group, confirm=lambda: self._pick_group(1))]
        for item in s.items(categories[self.group]):
            count = s.count(item)
            rows.append(Row(
                ItemSettings.NAMES.get(item, item), str(count),
                f"Up to {SetupSettings.STACK_LIMIT}. Left and right change it; A adds {SetupSettings.COUNT_JUMP}.",
                step=lambda step, item=item: s.add_item(item, step),
                jump=lambda item=item: s.add_item(item, SetupSettings.COUNT_JUMP),
                repeat=True, fade=count == 0,
            ))
        return rows

    def _pick_group(self, step: int) -> bool:
        self.group = (self.group + step) % len(Setup.CATEGORIES)
        self.cursors[BAG] = min(self.cursors[BAG], len(self.rows()) - 1)
        return True

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Hook up and down, left and right change, A confirms, L and R turn the page, B goes back."""
        if self.listing:
            self._handle_list(event)
            return
        if input_map.is_cancel(event) or input_map.is_select(event):
            self.gm.audio.play("menu_move")
            self.gm.scene_stack.pop()
        elif input_map.is_l1(event) or input_map.is_r1(event):
            step = -1 if input_map.is_l1(event) else 1
            self.page = (self.page + step) % len(SetupSettings.PAGES)
            self.cursors[self.page] = min(self.cursors[self.page], len(self.rows()) - 1)
            self._held = 0
            self.gm.audio.play("menu_move")
        elif input_map.is_up(event) or input_map.is_down(event):
            rows = self.rows()
            self.cursors[self.page] = (self.cursors[self.page] + (-1 if input_map.is_up(event) else 1)) % len(rows)
            self._held = 0
            self.gm.audio.play("menu_move")
        elif input_map.is_left(event) or input_map.is_right(event):
            step = -1 if input_map.is_left(event) else 1
            row = self.current()
            if row.step is not None and row.step(step):
                self.gm.audio.play("menu_move")
            if row.repeat:
                self._held, self._held_for = step, 0.0
        elif input_map.is_confirm(event):
            row = self.current()
            act = row.jump or row.confirm or (lambda: row.step is not None and row.step(1))
            if act():
                self.gm.audio.play("menu_select")

    def current(self) -> Row:
        rows = self.rows()
        self.cursors[self.page] = max(0, min(self.cursors[self.page], len(rows) - 1))
        return rows[self.cursors[self.page]]

    def _handle_list(self, event: pygame.event.Event) -> None:
        names = scene_select.beat_names()
        if input_map.is_cancel(event) or input_map.is_select(event):
            self.listing = False
            self.gm.audio.play("menu_move")
        elif input_map.is_up(event) or input_map.is_down(event):
            self.list_cursor = (self.list_cursor + (-1 if input_map.is_up(event) else 1)) % len(names)
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            self.setup.choose(self.list_cursor)
            self.hero = 0
            self.listing = False
            self.gm.audio.play("menu_select")

    def update(self, dt: float) -> None:
        """A number held left or right keeps going."""
        if not self._held or self.listing:
            return
        dx, _ = input_map.read_held_direction(getattr(self.gm, "connected_joysticks", []))
        row = self.current()
        if dx != self._held or not row.repeat or row.step is None:
            self._held = 0
            return
        self._held_for += dt
        while self._held_for >= SetupSettings.REPEAT_WAIT:
            self._held_for -= SetupSettings.REPEAT_STEP
            if not row.step(self._held):
                self._held = 0
                return

    # ------------------------------------------------------------------
    # DRAWING
    # ------------------------------------------------------------------

    def render(self, surface: pygame.Surface) -> None:
        """The header with the page and a help line, then the rows with the hook on one of them."""
        render_scene_background(self, surface)
        if self.listing:
            self._render_list(surface)
            return
        rows = self.rows()
        row = self.current()
        number = f"{self.page + 1}/{len(SetupSettings.PAGES)}"
        draw_header(surface, SetupSettings.PAGES[self.page], help_wrap(row.help) if row.help else (),
                    corner=f"L R pages {number}")
        cursor = self.cursors[self.page]
        first = self.firsts[self.page] = window_first(cursor, self.firsts[self.page], ROWS_SHOWN, len(rows))
        size = FontSettings.SIZE_BODY
        for offset, item in enumerate(rows[first:first + ROWS_SHOWN]):
            y = _LIST_TOP_Y + offset * _ROW_HEIGHT
            self._draw_row(surface, item, y, first + offset == cursor, size)
        draw_list_marks(surface, _MARK_X, _LIST_TOP_Y, _ROW_HEIGHT, first, ROWS_SHOWN, len(rows))

    def _draw_row(self, surface: pygame.Surface, row: Row, y: int, hooked: bool, size: int) -> None:
        color = ColorSettings.GRAY if row.fade and row.color is None else (row.color or ColorSettings.WHITE)
        text_renderer.draw_text(surface, row.label, (_LIST_LEFT_X, y), color=color, size=size)
        if row.value:
            value_color = row.value_color or (ColorSettings.GRAY if row.fade else ColorSettings.WHITE)
            width = text_renderer.text_width(row.value, size)
            text_renderer.draw_text(surface, row.value, (_VALUE_RIGHT_X - width, y), color=value_color, size=size)
        if hooked:
            text_renderer.draw_pointer(surface, (_LIST_LEFT_X - 4, y + size // 2), ColorSettings.YELLOW)

    def _render_list(self, surface: pygame.Surface) -> None:
        """The scene list, which slides to keep the hook in view."""
        names = scene_select.beat_names()
        draw_header(surface, "Scene", help_wrap("Pick where the game starts. B goes back."), corner="")
        self.list_first = window_first(self.list_cursor, self.list_first, ROWS_SHOWN, len(names))
        size = FontSettings.SIZE_BODY
        for offset, name in enumerate(names[self.list_first:self.list_first + ROWS_SHOWN]):
            index = self.list_first + offset
            y = _LIST_TOP_Y + offset * _ROW_HEIGHT
            color = ColorSettings.YELLOW if index == self.setup.index else ColorSettings.WHITE
            text_renderer.draw_text(surface, name, (_LIST_LEFT_X, y), color=color, size=size)
            if index == self.list_cursor:
                text_renderer.draw_pointer(surface, (_LIST_LEFT_X - 4, y + size // 2), ColorSettings.YELLOW)
        draw_list_marks(surface, _MARK_X, _LIST_TOP_Y, _ROW_HEIGHT, self.list_first, ROWS_SHOWN, len(names))
