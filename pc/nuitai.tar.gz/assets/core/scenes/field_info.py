"""The field menu's Info screens (Frankie, 11/21): floating windows over the darkened field.

**The overview:** the five sections in a window on the left, a peek at the hooked one on the right, the journey (time
played, steps, the hour, the date) in a strip under them, the section's help along the bottom. A on a section opens it to
the whole screen, since it holds the most reading; B comes back.

* **Quests:** a list, each marked Open or Done; A on one gives it a page: the portrait of who asked, the label "Quest giver"
  and their name, a paragraph telling the quest, and a count with a bar only when the quest counts something.
* **Bestiary:** a page per creature beaten, turned with L and R (the SNES buttons) with a page count. At the left the sprite,
  HP, kind, its element icons (a "?" until seen), its slots as a small unlabeled grid, and below it the scrollable list of
  the elements and Skills it can have (a "?" until seen); the description at the right.
* **Glossary and Lore:** the words and pages found, as lists and pages, in the same style. **Records:** the counts.

What is discovered and the counts are the old screens' (``DataScene``, ``QuestScene``, ``BestiaryScene``, ``LoreScene``,
``systems/records.py``); this draws them.
"""

from __future__ import annotations

import pygame

from core import lore
from core.scenes import bestiary_scene as bs
from core.scenes.data_scene import INFO_ROWS
from core.scenes.field_element import shoulder
from core.scenes.field_menu_main import M, G
from core.scenes.field_menu_pages import Page, short_item_name
from core.shared import by_id
from settings import ColorSettings, FontSettings, UISettings
from systems import daytime, quests, records
from ui import input_map, text_renderer
from ui.field_menu_kit import GRAY, WHITE, YELLOW, box, more_arrow, text, width
from ui.item_icon import season_icon, sky_icon
from ui.slot_cell import PITCH_X, PITCH_Y, draw_cell
from utils.graphics import load_element_icon, load_monster_sprite, speaker_face

W = 256 - 2 * M
SIZE = FontSettings.SIZE_BODY
PLACES = {"Quests": (240, 168, 48), "Bestiary": (230, 90, 110), "Glossary": (159, 196, 232),
          "Lore": (180, 139, 232), "Records": (92, 196, 106)}       # one color a section
TAN = (200, 170, 120)
LIST_W, TOP_H = 92, 120
JOURNEY_Y, JOURNEY_H = M + TOP_H + G, 40
RX = M + LIST_W + G
RW = 256 - M - RX
DESC_H = 36
DESC_Y = 224 - M - DESC_H
LIST_ROWS = 7
DESC_ROWS = 13                     # lines of a bestiary description the window shows: (180 - 16) // 12
PAGE_ROWS = 13                     # lines of a lore page: the same window


def _font():
    return text_renderer.get_font(SIZE)


def _wrap(words: str, room: int) -> list[str]:
    return text_renderer.wrap(words, _font(), room)


def _fit(words: str, room: int) -> str:
    if width(words) <= room:
        return words
    while words and width(words + "..") > room:
        words = words[:-1]
    return words.rstrip() + ".."


def _say(surface, words: str, x: int, y: int, color=WHITE) -> None:
    """Words with the names as written (Ama, not AMA), for a quest page's giver and story."""
    text_renderer.draw_text(surface, words, (x, y), color=color, size=SIZE, spoken=True)


def _band(surface, x, y, w, h=12) -> None:
    shade = pygame.Surface((w, h), pygame.SRCALPHA)
    shade.fill((255, 255, 255, 36))
    surface.blit(shade, (x, y))


class InfoScreen(Page):
    """Zones: ``rows`` (the overview), ``quests``, ``quest`` (one quest's page), ``bestiary``, ``lore_index``,
    ``lore_list``, ``lore_page`` and ``records``."""

    full = True

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        self.zone = "rows"
        self.at = 0                       # the section the hook is on in the overview
        self.cursor = 0                   # the hook in a list, or the page shown
        self.top = 0                      # the first row of a list shown
        self.scroll = 0                   # a scrolled block, the bestiary's list or a lore page
        self.dscroll = 0                  # the bestiary's description, scrolled a line at a time
        self.pane = "desc"                # which bestiary window up and down move: "desc" or "list" (A swaps)
        self.category: str | None = None
        self.pages: list = []
        self.last_hook: pygame.Rect | None = None
        self._entries_cache: list | None = None

    # -- what there is -------------------------------------------------------------------------------

    def quest_log(self) -> list:
        return quests.log(self.gm.party, self.gm.data.load("bounties").values())

    def beasts(self) -> list:
        if self._entries_cache is None:
            flags = self.gm.party.flags
            self._entries_cache = [e for e in bs._entries() if flags.get(bs.beaten_flag(e["name"]))]
        return self._entries_cache

    # -- input -------------------------------------------------------------------------------------

    def handle(self, event) -> str | None:
        return getattr(self, f"_zone_{self.zone}")(event)

    def _move(self, count: int, event, wrap: bool = True) -> bool:
        """Up and down over ``count`` rows, scrolling the list window to keep the hook in it."""
        if not count or not (input_map.is_up(event) or input_map.is_down(event)):
            return False
        step = -1 if input_map.is_up(event) else 1
        self.cursor = (self.cursor + step) % count
        if self.cursor < self.top:
            self.top = self.cursor
        elif self.cursor >= self.top + LIST_ROWS:
            self.top = self.cursor - LIST_ROWS + 1
        self.gm.audio.play("menu_move")
        return True

    def _zone_rows(self, event) -> str | None:
        audio = self.gm.audio
        if input_map.is_cancel(event):
            return "back"
        if input_map.is_up(event) or input_map.is_down(event):
            self.at = (self.at + (-1 if input_map.is_up(event) else 1)) % len(INFO_ROWS)
            audio.play("menu_move")
        elif input_map.is_confirm(event) or input_map.is_right(event):
            name = INFO_ROWS[self.at][0]
            self.cursor = self.top = self.scroll = 0
            audio.play("menu_select")
            if name == "Quests":
                self.zone = "quests"
            elif name == "Bestiary":
                self._entries_cache = None
                self.zone = "bestiary"
            elif name == "Glossary":
                self._open_pages(lore.GLOSSARY)
            elif name == "Lore":
                self.zone = "lore_index"
            else:
                self.zone = "records"
        return None

    def _back_to_rows(self) -> None:
        self.zone = "rows"
        self.gm.audio.play("menu_select")

    # quests
    def _zone_quests(self, event) -> str | None:
        log = self.quest_log()
        if input_map.is_cancel(event):
            self._back_to_rows()
        elif self._move(len(log), event):
            pass
        elif input_map.is_confirm(event) and log:
            self.zone = "quest"
            self.gm.audio.play("menu_select")
        return None

    def _zone_quest(self, event) -> str | None:
        log = self.quest_log()
        if input_map.is_cancel(event) or input_map.is_confirm(event):
            self.zone = "quests"
            self.gm.audio.play("menu_select")
        elif log and (input_map.is_l1(event) or input_map.is_r1(event) or input_map.is_left(event)
                      or input_map.is_right(event)):
            back = input_map.is_l1(event) or input_map.is_left(event)
            self.cursor = (self.cursor + (-1 if back else 1)) % len(log)
            self.gm.audio.play("menu_move")
        return None

    # bestiary
    def _zone_bestiary(self, event) -> str | None:
        beasts = self.beasts()
        if input_map.is_cancel(event):
            self._back_to_rows()
        elif beasts and (input_map.is_l1(event) or input_map.is_r1(event) or input_map.is_left(event)
                         or input_map.is_right(event)):
            back = input_map.is_l1(event) or input_map.is_left(event)
            self.cursor = (self.cursor + (-1 if back else 1)) % len(beasts)
            self.scroll = self.dscroll = 0
            self.gm.audio.play("menu_move")
        elif beasts and input_map.is_confirm(event):
            self.pane = "list" if self.pane == "desc" else "desc"       # which window up and down scroll
            self.gm.audio.play("menu_select")
        elif beasts and (input_map.is_up(event) or input_map.is_down(event)):
            up = input_map.is_up(event)
            if self.pane == "desc":
                room = len(self._desc_lines(beasts[self.cursor]))
                if up and self.dscroll > 0:
                    self.dscroll -= 1
                    self.gm.audio.play("menu_move")
                elif not up and self.dscroll + DESC_ROWS < room:
                    self.dscroll += 1
                    self.gm.audio.play("menu_move")
            else:
                rows = self._beast_list(beasts[self.cursor])
                if up and self.scroll > 0:
                    self.scroll -= 1
                    self.gm.audio.play("menu_move")
                elif not up and self.scroll + 4 < len(rows):
                    self.scroll += 1
                    self.gm.audio.play("menu_move")
        return None

    # glossary and lore
    def _open_pages(self, category: str | None) -> None:
        self.category = category
        self.pages = lore.unlocked(self.gm.party, category)
        self.cursor = self.top = self.scroll = 0
        self.zone = "lore_list"

    def _zone_lore_index(self, event) -> str | None:
        found = [name for name, _ in lore.categories_found(self.gm.party) if name != lore.GLOSSARY]
        if input_map.is_cancel(event):
            self._back_to_rows()
        elif self._move(len(found), event):
            pass
        elif input_map.is_confirm(event) and found:
            self.gm.audio.play("menu_select")
            self._open_pages(found[self.cursor])
            self.zone = "lore_list"
        return None

    def _zone_lore_list(self, event) -> str | None:
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            if self.category == lore.GLOSSARY:
                self.zone = "rows"
            else:
                self.zone, self.cursor, self.top = "lore_index", 0, 0
        elif self._move(len(self.pages), event):
            pass
        elif input_map.is_confirm(event) and self.pages:
            self.zone, self.scroll = "lore_page", 0
            self.gm.audio.play("menu_select")
        return None

    def _zone_lore_page(self, event) -> str | None:
        from core.scenes.lore_scene import TEXT_ROWS, page_lines

        count = len(self.pages)
        if input_map.is_cancel(event):
            self.zone = "lore_list"
            self.gm.audio.play("menu_select")
        elif count and (input_map.is_l1(event) or input_map.is_r1(event) or input_map.is_left(event)
                        or input_map.is_right(event)):
            back = input_map.is_l1(event) or input_map.is_left(event)
            self.cursor = (self.cursor + (-1 if back else 1)) % count
            self.scroll = 0
            self.gm.audio.play("menu_move")
        elif input_map.is_up(event) and self.scroll > 0:
            self.scroll -= 1
            self.gm.audio.play("menu_move")
        elif input_map.is_down(event) and self.scroll + PAGE_ROWS < len(self._lore_lines()):
            self.scroll += 1
            self.gm.audio.play("menu_move")
        return None

    def _zone_records(self, event) -> str | None:
        if input_map.is_cancel(event) or input_map.is_confirm(event):
            self._back_to_rows()
        return None

    # -- help ----------------------------------------------------------------------------------------

    def help_text(self) -> str:
        return INFO_ROWS[self.at][1] if self.zone == "rows" else ""

    # -- drawing -------------------------------------------------------------------------------------

    def render(self, surface, lay, active) -> None:
        tip = getattr(self, f"_draw_{self.zone}")(surface)
        if tip is not None:
            self.last_hook = text_renderer.draw_pointer(surface, tip, YELLOW, from_screen_top=True)

    def _header(self, surface, title: str, color, right: str = "", x: int = M, w: int = W) -> None:
        box(surface, x, M, w, 22)
        text(surface, title, x + 12, M + 7, color)
        if right:
            text(surface, right, x + w - 12, M + 7, WHITE, right=True)

    # the overview
    def _draw_rows(self, surface):
        party = self.gm.party
        box(surface, M, M, LIST_W, TOP_H)
        for i, (name, _help) in enumerate(INFO_ROWS):
            y = M + 10 + i * 20
            if i == self.at:
                _band(surface, M + 6, y - 2, LIST_W - 12)
            text(surface, name, M + 16, y, PLACES[name] if i == self.at else WHITE)
        box(surface, RX, M, RW, TOP_H)
        row = INFO_ROWS[self.at][0]
        x, inner = RX + 10, RW - 20
        if row == "Records":
            for n, (label, value) in enumerate(records.counts(party)[:5]):
                y = M + 12 + n * 20
                text(surface, label, x, y, YELLOW)
                text(surface, str(value), RX + RW - 10, y, WHITE, right=True)
        elif row == "Quests":
            log = self.quest_log()
            y = M + 10
            for heading, color, items in (("Open", WHITE, [q for q in log if not q.done]),
                                          ("Done", GRAY, [q for q in log if q.done])):
                if not items:
                    continue
                if y < M + TOP_H - 10:
                    text(surface, heading, x, y, YELLOW)
                y += 14
                for q in items:                     # one line a quest, cut with ".." so a long name never wraps out of the window
                    if y < M + TOP_H - 10:
                        text(surface, _fit(q.name, inner), x, y, color)
                    y += 12
                y += 4
            if not log:
                text(surface, "None yet", x, M + 10, GRAY)
        else:
            if row == "Bestiary":
                latest = records.latest_beaten(party)
                title, extra = "Latest", [latest] if latest else []
            elif row == "Glossary":
                page = lore.newest(party, lore.GLOSSARY)
                title, extra = "Latest", [page["title"]] if page else []
            else:
                page = lore.newest(party, lore_only=True)
                title, extra = "Newest", [page["title"], page["category"]] if page else []
            if not extra:
                text(surface, "None yet", x, M + 10, GRAY)
            else:
                text(surface, title, x, M + 10, YELLOW)
                for n, line in enumerate(_wrap(extra[0], inner)[:3]):
                    text(surface, line, x, M + 24 + n * 12, WHITE)
                for n, line in enumerate(extra[1:]):
                    text(surface, _fit(line, inner), x, M + 24 + 36 + n * 12, GRAY)
        # the journey
        box(surface, M, JOURNEY_Y, W, JOURNEY_H)
        x1, x2 = M + 10, 256 - M - 10
        text(surface, "Time", x1, JOURNEY_Y + 8, YELLOW)
        text(surface, records.time_text(party), M + 92, JOURNEY_Y + 8, right=True)
        text(surface, "Steps", x1, JOURNEY_Y + 24, YELLOW)
        text(surface, str(records.steps(party)), M + 92, JOURNEY_Y + 24, right=True)
        if daytime.running(party):
            hour = daytime.clock_text(party)
            surface.blit(sky_icon(daytime.daylight(party)), (x2 - width(hour) - 13, JOURNEY_Y + 7))
        else:
            hour = "--:--"
        text(surface, hour, x2, JOURNEY_Y + 8, right=True)
        date = records.date_text(party)
        text(surface, date, x2, JOURNEY_Y + 24, right=True)
        surface.blit(season_icon(records.season(party)), (x2 - width(date) - 13, JOURNEY_Y + 23))
        box(surface, M, DESC_Y, W, DESC_H)
        for n, line in enumerate(_wrap(self.help_text(), W - 20)[:2]):
            text(surface, line, M + 10, DESC_Y + 8 + n * 12, WHITE)
        return (M + 6, M + 10 + self.at * 20 + 4)

    # quests
    def _draw_quests(self, surface):
        log = self.quest_log()
        color = PLACES["Quests"]
        self._header(surface, "Quests", color, f"{sum(1 for q in log if not q.done)} open")
        ly = M + 22 + G
        rows = log[self.top:self.top + LIST_ROWS]
        box(surface, M, ly, W, max(1, len(rows)) * 16 + 16)
        if not log:
            text(surface, "No quests yet.", M + 16, ly + 10, GRAY)
            return None
        for i, quest in enumerate(rows):
            y = ly + 10 + i * 16
            if self.top + i == self.cursor:
                _band(surface, M + 6, y - 2, W - 12)
            text(surface, _fit(quest.name, W - 80), M + 16, y, GRAY if quest.done else WHITE)
            text(surface, "Done" if quest.done else "Open", 256 - M - 12, y, GRAY if quest.done else YELLOW, right=True)
        if self.top > 0:
            more_arrow(surface, 256 - M - 22, ly + 2)
        if len(log) > self.top + LIST_ROWS:
            more_arrow(surface, 256 - M - 22, ly + len(rows) * 16 + 6)
        return (M + 8, ly + 10 + (self.cursor - self.top) * 16 + 4)

    def _draw_quest(self, surface):
        log = self.quest_log()
        self.cursor = min(self.cursor, max(0, len(log) - 1))
        if not log:
            return None
        q = log[self.cursor]
        color = PLACES["Quests"]
        box(surface, M, M, W, 64)
        face = speaker_face(q.giver) if q.giver else None
        tx = M + 66 if face is not None else M + 12
        if face is not None:
            surface.blit(face, (M + 8, M + 8))
        text(surface, _fit(q.name, 256 - M - tx - 8), tx, M + 10, GRAY if q.done else color)
        text(surface, "Quest giver", tx, M + 30, YELLOW)
        _say(surface, q.giver or "Someone", tx, M + 44)
        lines = text_renderer.wrap(q.story or q.text, _font(), W - 20, spoken=True)
        sy = M + 64 + G
        box(surface, M, sy, W, len(lines) * 12 + 16)
        for n, line in enumerate(lines):
            _say(surface, line, M + 10, sy + 8 + n * 12)
        if q.count is not None:
            cy = sy + len(lines) * 12 + 16 + G
            label, have, total = q.count
            box(surface, M, cy, W, 40)
            text(surface, label, M + 10, cy + 8, YELLOW)
            text(surface, f"{have} / {total}", M + W - 10, cy + 8, WHITE, right=True)
            bx, bw = M + 10, W - 20
            pygame.draw.rect(surface, (20, 30, 50), (bx, cy + 24, bw, 8))
            pygame.draw.rect(surface, color, (bx, cy + 24, bw * have // max(1, total), 8))
            pygame.draw.rect(surface, WHITE, (bx, cy + 24, bw, 8), 1)
        return None

    # bestiary
    def _beast_list(self, entry: dict) -> list[tuple[str, tuple]]:
        """The elements and Skills it can have: a name once seen, a "?" until then."""
        monster = entry["monster"]
        flags = self.gm.party.flags
        moves = by_id("moves")
        rows = []
        for move_id in monster.get("pool", ()):
            if move_id not in moves:
                continue
            seen = flags.get(bs.seen_cast_flag(monster["id"], move_id))
            rows.append((moves[move_id]["name"], WHITE) if seen else ("?", GRAY))
        for skill in monster.get("skills", ()):
            seen = flags.get(bs.seen_cast_flag(monster["id"], skill.get("kind", skill["name"])))
            rows.append((skill["name"], TAN) if seen else ("?", GRAY))
        return rows

    def _draw_bestiary(self, surface):
        color = PLACES["Bestiary"]
        beasts = self.beasts()
        box(surface, M, M, W, 22)
        if not beasts:
            text(surface, "Bestiary", M + 40, M + 7, color)
            text(surface, "Nothing beaten yet.", M + 10, M + 36, GRAY)
            return None
        self.cursor = min(self.cursor, len(beasts) - 1)
        entry = beasts[self.cursor]
        monster = entry["monster"]
        left, right = shoulder("L"), shoulder("R")
        if left is not None:
            surface.blit(left, (M + 8, M + 6))
        if right is not None:
            surface.blit(right, (M + W - 8 - right.get_width(), M + 6))
        text(surface, entry["name"], M + 40, M + 7, color)
        text(surface, f"{self.cursor + 1}/{len(beasts)}", M + W - 40, M + 7, GRAY, right=True)
        top, lw, sh = M + 22 + G, 104, 116
        box(surface, M, top, lw, sh)
        loaded = load_monster_sprite(entry.get("sprite"))
        if loaded is not None:
            sprite = loaded[0]
            rect = sprite.get_bounding_rect()
            surface.blit(sprite.subsurface(rect), (M + 8 + max(0, 48 - rect.width) // 2, top + 8 + max(0, 48 - rect.height)))
        # its slots: a small unlabeled grid with room for 3 by 7, a cell for each that is open
        gx, gy = M + 62, top + 8
        for r, cells in enumerate(bs.slot_rows(monster.get("slots", 0))):
            for c, _ in enumerate(cells):
                draw_cell(surface, (gx + c * PITCH_X, gy + r * PITCH_Y))
        flags = self.gm.party.flags
        stances = monster.get("stances") or []
        seen = [e for e in stances if flags.get(bs.seen_stance_flag(monster["id"], e))]
        hps = [bs.stance_hp(monster, e) for e in (seen or stances[:1])] if stances else [bs.stance_hp(monster, None)]
        text(surface, "HP " + "/".join(str(h) for h in hps), M + 8, top + 62, WHITE)
        kind = "Boss" if monster.get("boss") else "Beast" if monster.get("beast") else ""
        if kind:
            text(surface, kind, M + 8, top + 74, YELLOW if kind == "Boss" else TAN)
        x = M + 8
        for element in entry["elements"]:
            if element in stances and not flags.get(bs.seen_stance_flag(monster["id"], element)):
                icon = bs._unseen_icon()
            else:
                icon = load_element_icon(element)
            if icon is not None:
                surface.blit(icon, (x, top + 90))
                x += icon.get_width() + 6
        ly = top + sh + G
        lh = 224 - M - ly
        rows = self._beast_list(entry)
        both = len(rows) > 4 and len(self._desc_lines(entry)) > DESC_ROWS
        box(surface, M, ly, lw, lh, border=YELLOW if both and self.pane == "list" else WHITE)
        self.scroll = max(0, min(self.scroll, max(0, len(rows) - 4)))
        for n, (name, col) in enumerate(rows[self.scroll:self.scroll + 4]):
            text(surface, _fit(name, lw - 28), M + 10, ly + 6 + n * 12, col)
        if self.scroll > 0:
            more_arrow(surface, M + lw - 16, ly + 3)
        if len(rows) > self.scroll + 4:
            more_arrow(surface, M + lw - 16, 224 - M - 12)
        rx = M + lw + G
        rw = 256 - M - rx
        both = len(rows) > 4 and len(self._desc_lines(entry)) > DESC_ROWS       # A picks the window only when both scroll
        box(surface, rx, top, rw, 224 - M - top, border=YELLOW if both and self.pane == "desc" else WHITE)
        lines = self._desc_lines(entry)
        self.dscroll = max(0, min(self.dscroll, max(0, len(lines) - DESC_ROWS)))
        for n, line in enumerate(lines[self.dscroll:self.dscroll + DESC_ROWS]):
            text(surface, line, rx + 8, top + 8 + n * 12, WHITE)
        if self.dscroll > 0:
            more_arrow(surface, rx + rw - 16, top + 3)
        if len(lines) > self.dscroll + DESC_ROWS:
            more_arrow(surface, rx + rw - 16, 224 - M - 12)
        return None

    def _desc_lines(self, entry: dict) -> list[str]:
        return _wrap(entry["description"], 256 - M - (M + 104 + G) - 16)

    # glossary and lore
    def _draw_lore_index(self, surface):
        found = [(name, line) for name, line in lore.categories_found(self.gm.party) if name != lore.GLOSSARY]
        color = PLACES["Lore"]
        self._header(surface, "Lore", color)
        ly = M + 22 + G
        box(surface, M, ly, W, max(1, len(found)) * 16 + 16)
        if not found:
            text(surface, "Nothing found yet.", M + 16, ly + 10, GRAY)
            return None
        for i, (name, _line) in enumerate(found):
            y = ly + 10 + i * 16
            if i == self.cursor:
                _band(surface, M + 6, y - 2, W - 12)
            text(surface, name, M + 16, y, WHITE)
        box(surface, M, DESC_Y, W, DESC_H)
        for n, line in enumerate(_wrap(found[min(self.cursor, len(found) - 1)][1], W - 20)[:2]):
            text(surface, line, M + 10, DESC_Y + 8 + n * 12, WHITE)
        return (M + 8, ly + 10 + self.cursor * 16 + 4)

    def _draw_lore_list(self, surface):
        title = self.category or "Lore"
        color = PLACES["Glossary" if self.category == lore.GLOSSARY else "Lore"]
        total = len(lore.in_category(self.category)) if self.category else len(lore.PAGES)
        self._header(surface, title, color, f"{len(self.pages)} of {total}")
        ly = M + 22 + G
        rows = self.pages[self.top:self.top + LIST_ROWS]
        box(surface, M, ly, W, max(1, len(rows)) * 16 + 16)
        if not self.pages:
            text(surface, "None found yet.", M + 16, ly + 10, GRAY)
            return None
        for i, page in enumerate(rows):
            y = ly + 10 + i * 16
            if self.top + i == self.cursor:
                _band(surface, M + 6, y - 2, W - 12)
            text(surface, _fit(page["title"], W - 40), M + 16, y, WHITE)
        if self.top > 0:
            more_arrow(surface, 256 - M - 22, ly + 2)
        if len(self.pages) > self.top + LIST_ROWS:
            more_arrow(surface, 256 - M - 22, ly + len(rows) * 16 + 6)
        return (M + 8, ly + 10 + (self.cursor - self.top) * 16 + 4)

    def _lore_lines(self) -> list[str]:
        from core.scenes.lore_scene import FACE_ROOM, page_face

        page = self.pages[self.cursor]
        room = W - 20 - (FACE_ROOM if page_face(page) is not None else 0)
        return _wrap(page["text"], room)

    def _draw_lore_page(self, surface):
        from core.scenes.lore_scene import page_face

        if not self.pages:
            return None
        self.cursor = min(self.cursor, len(self.pages) - 1)
        page = self.pages[self.cursor]
        color = PLACES["Glossary" if self.category == lore.GLOSSARY else "Lore"]
        box(surface, M, M, W, 22)
        left, right = shoulder("L"), shoulder("R")
        if left is not None:
            surface.blit(left, (M + 8, M + 6))
        if right is not None:
            surface.blit(right, (M + W - 8 - right.get_width(), M + 6))
        text(surface, _fit(page["title"], W - 120), M + 40, M + 7, color)
        text(surface, f"{self.cursor + 1}/{len(self.pages)}", M + W - 40, M + 7, GRAY, right=True)
        top = M + 22 + G
        box(surface, M, top, W, 224 - M - top)
        lines = self._lore_lines()
        self.scroll = max(0, min(self.scroll, max(0, len(lines) - PAGE_ROWS)))
        for n, line in enumerate(lines[self.scroll:self.scroll + PAGE_ROWS]):
            text(surface, line, M + 10, top + 8 + n * 12, WHITE)
        face = page_face(page)
        if face is not None:
            surface.blit(face, (M + W - 10 - face.get_width(), top + 8))
        if self.scroll > 0:
            more_arrow(surface, M + W - 18, top + 2)
        if self.scroll + PAGE_ROWS < len(lines):
            more_arrow(surface, M + W - 18, 224 - M - 12)
        return None

    # records
    def _draw_records(self, surface):
        color = PLACES["Records"]
        self._header(surface, "Records", color)
        ly = M + 22 + G
        counts = records.counts(self.gm.party)
        box(surface, M, ly, W, len(counts) * 16 + 16)
        for i, (label, value) in enumerate(counts):
            y = ly + 10 + i * 16
            text(surface, label, M + 16, y, YELLOW)
            text(surface, str(value), 256 - M - 12, y, WHITE, right=True)
        return None
