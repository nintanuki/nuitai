"""At sea: the Meialana steered across the to-scale map (Frankie, 10/31; the
sailing line in ``game/answers.md``; the rules are ``systems/sailing.py``).

The sea fills the whole screen, scrolled to keep the boat in the middle, at
``SailingSettings.TILE_PIXELS`` a tile. The d-pad steers, diagonals too; the
current adds its push while she moves, so sailing with it is faster. Moving
is what passes the days: each day everyone aboard eats, and a window in the
corner shows how many days the food reaches. When it reaches no further than
the nearest port, a warning says to turn back; running out is a game over.

Place names show only for places Kailo has been or someone marked on his map.
Bumping the coast near a port asks to go ashore. Monsters swim near the boat,
and running into one starts a fight.
"""

from __future__ import annotations

import math
import os
import random
from typing import TYPE_CHECKING, Callable

import pygame

from core.scene import Scene
from settings import ColorSettings, FontSettings, SailingSettings, ScreenSettings
from systems import sailing
from ui import input_map, text_renderer
from ui.text_box import TextBox
from ui.window import draw_window

if TYPE_CHECKING:
    from main import GameManager

_tiles: tuple[list[pygame.Surface], bytes, int] | None = None
_boat: pygame.Surface | None = None


def tiles() -> tuple[list[pygame.Surface], bytes, int]:
    """The sea's tile pictures, 8 by 8 each, as the to-scale map draws them, and the
    grid of which tile goes where (one byte a tile, row by row) and its width; loaded once."""
    global _tiles
    if _tiles is None:
        art = pygame.image.load(os.path.join(sailing.HERE, "assets", "graphics", "sea_tiles.png"))
        size = art.get_height()
        pictures = [art.subsurface((n * size, 0, size, size)).copy() for n in range(art.get_width() // size)]
        kinds = pygame.image.load(os.path.join(sailing.HERE, "assets", "graphics", "sea_kinds.png"))
        _tiles = (pictures, pygame.image.tobytes(kinds, "P"), kinds.get_width())
    return _tiles


def boat_picture() -> pygame.Surface | None:
    """The Meialana shrunk by a whole number to a tile's width, 16 by 13, or None if it is missing.

    The map editor's icon for the boat (Frankie, 11/2): the harbor's picture,
    every seventh pixel kept, nothing redrawn or smoothed.
    """
    global _boat
    if _boat is None:
        try:
            big = pygame.image.load(os.path.join(sailing.HERE, "assets", "graphics", "buildings", "meialana.png"))
        except (pygame.error, FileNotFoundError):
            return None
        factor = -(-big.get_width() // SailingSettings.BOAT_WIDTH)
        _boat = pygame.transform.scale(big, (big.get_width() // factor, big.get_height() // factor))
    return _boat


class SeaScene(Scene):
    """The open sea. ``on_ashore(place)`` runs after this scene pops at a port."""

    OPAQUE = True

    def __init__(self, gm: "GameManager", start: str, on_ashore: Callable[[str], None],
                 lines: tuple[str, ...] = ()) -> None:
        super().__init__(gm)
        self.sea = sailing.sea()
        self.x, self.y = self.sea.water_near(self.sea.spots[start])
        self.on_ashore = on_ashore
        self.facing_left = False
        self.clock = 0.0          # seconds sailed today
        self.lines = list(lines)  # pages of text waiting for A, shown one at a time
        self.after_lines: Callable[[], None] | None = None
        self.warned = False       # the turn-back warning comes once a voyage
        self.box = TextBox()      # the line showing, paged by the text box so none is cut off
        self._boxed = False
        self.grace = SailingSettings.GRACE_SECONDS
        self.left_port = start    # no asking to go ashore where she just left, until she moves off
        self.monsters: list[list[float]] = []
        self._fighting = None
        sailing.go_ashore(gm.party, start)

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        if self.lines and (input_map.is_confirm(event) or input_map.is_cancel(event)):
            self._show_line()
            if not self.box.is_page_complete() or self.box.has_more():
                self.box.advance()    # finish typing, or turn the page
                return
            self.lines.pop(0)
            self._boxed = False
            self.box.clear()
            if not self.lines and self.after_lines is not None:
                then, self.after_lines = self.after_lines, None
                then()

    # ------------------------------------------------------------------
    # UPDATE
    # ------------------------------------------------------------------

    def on_enter(self) -> None:
        """Back from a fight: the monster that started it is gone."""
        if self._fighting is not None:
            monster, battle = self._fighting
            self._fighting = None
            if monster in self.monsters and getattr(battle.battle, "outcome", None) == "victory":
                self.monsters.remove(monster)
            self.grace = SailingSettings.GRACE_SECONDS

    def _show_line(self) -> None:
        """Put the first waiting line in the text box, "Name: words" as that speaker's."""
        if self._boxed or not self.lines:
            return
        self._boxed = True
        name, colon, words = self.lines[0].partition(": ")
        if colon and name.isalpha():
            self.box.push(words, speaker=name)
        else:
            self.box.push(self.lines[0])

    def update(self, dt: float) -> None:
        self.gm.audio.play_screen("title")   # the title's music, the waves baked under it
        if self.lines:
            self._show_line()
            self.box.update(dt)
            return
        self.grace = max(0.0, self.grace - dt)
        dx, dy = input_map.read_held_direction(getattr(self.gm, "connected_joysticks", []))
        self.sail(dx, dy, dt)   # never still: with no steering she drifts with the current
        self._swim(dt)

    def sail(self, dx: int, dy: int, dt: float) -> None:
        """Steer ``dx``, ``dy`` for ``dt`` seconds: her own speed that way plus the current."""
        if dx:
            self.facing_left = dx < 0
        days = dt / SailingSettings.SECONDS_PER_DAY
        length = math.hypot(dx, dy) or 1.0
        speed = self.sea.boat_speed()
        cx, cy = self.sea.current(self.x, self.y)
        vx, vy = dx / length * speed + cx, dy / length * speed + cy
        bumped = False
        nx = self.x + vx * days
        if self.sea.sailable(nx, self.y):
            self.x = nx
        else:
            bumped = True
        ny = self.y + vy * days
        if self.sea.sailable(self.x, ny):
            self.y = ny
        else:
            bumped = True
        if bumped:
            self._at_coast(nx, ny)
        self._pass_time(dt)

    def _pass_time(self, dt: float) -> None:
        """Count the day; at its end everyone eats, and the warning is checked."""
        self.clock += dt
        party = self.gm.party
        while self.clock >= SailingSettings.SECONDS_PER_DAY:
            self.clock -= SailingSettings.SECONDS_PER_DAY
            if not sailing.eat_a_day(party):
                self._starve()
                return
        name, tiles = self.sea.nearest_port(self.x, self.y)
        if self.left_port and tiles > SailingSettings.REACH + 1:
            self.left_port = None
        danger = sailing.should_warn(party, self.x, self.y)
        if danger and not self.warned:
            self.warned = True
            self.lines.append(SailingSettings.WARNING)

    def _starve(self) -> None:
        from core.scenes.game_over_scene import game_over  # local: as the battle does

        self.lines = [SailingSettings.STARVED]
        self.after_lines = lambda: game_over(self.gm)

    def _at_coast(self, nx: float, ny: float) -> None:
        """The boat pushed against something: the coast near a port asks to go ashore,
        the inner current says it is too strong."""
        if self.sea.zone(nx, ny) > SailingSettings.INNERMOST_ZONE:
            if not self.lines:
                self.lines.append(SailingSettings.TOO_WILD)
            return
        name, tiles = self.sea.nearest_port(self.x, self.y)
        if tiles > SailingSettings.REACH or name == self.left_port:
            return
        from core.scenes.choice_scene import ChoiceScene  # local: as the field does

        def pick(index: int) -> None:
            self.left_port = name   # not asked again until she moves off
            if index != 0:
                return
            if name in SailingSettings.BUILT_PORTS:
                self.ashore(name)
            else:
                # A port with no land built yet (Māla Iki) only says so.
                sailing.go_ashore(self.gm.party, name)
                self.lines.append(SailingSettings.LANDFALL_LINE.format(place=name))

        self.gm.scene_stack.push(ChoiceScene(
            self.gm, SailingSettings.ASHORE_ASK.format(place=name), ["Yes", "No"], pick, cancel=1))

    def ashore(self, place: str) -> None:
        """Landfall at ``place``: off the sea, and the field takes it from there."""
        sailing.go_ashore(self.gm.party, place)
        self.gm.scene_stack.pop()
        self.on_ashore(place)

    def _swim(self, dt: float) -> None:
        """The monsters: kept to ``MONSTERS`` near the boat, drifting; touching one is a fight."""
        if sailing.free(self.gm.party):
            self.monsters = []   # free sailing: none swim, none fight
            return
        roam = SailingSettings.ROAM
        self.monsters = [m for m in self.monsters if math.hypot(m[0] - self.x, m[1] - self.y) < roam * 1.5]
        tries = 0
        while len(self.monsters) < SailingSettings.MONSTERS and tries < 20:
            tries += 1
            angle = random.uniform(0, 2 * math.pi)
            reach = random.uniform(roam * 0.6, roam)
            mx, my = self.x + math.cos(angle) * reach, self.y + math.sin(angle) * reach
            if self.sea.sailable(mx, my):
                heading = random.uniform(0, 2 * math.pi)
                self.monsters.append([mx, my, heading])
        for m in self.monsters:
            if random.random() < dt * 0.5:
                m[2] += random.uniform(-1.0, 1.0)
            nx = m[0] + math.cos(m[2]) * SailingSettings.DRIFT * dt
            ny = m[1] + math.sin(m[2]) * SailingSettings.DRIFT * dt
            if self.sea.sailable(nx, ny):
                m[0], m[1] = nx, ny
            else:
                m[2] += math.pi
        if self.grace > 0 or self._fighting is not None:
            return
        for m in self.monsters:
            if math.hypot(m[0] - self.x, m[1] - self.y) < SailingSettings.HIT:
                self._fight(m)
                return

    def _fight(self, monster: list[float]) -> None:
        from core.scenes.battle_scene import BattleScene, compose_fight  # local: cycle

        battle = BattleScene(self.gm, enemies=compose_fight({"encounter": SailingSettings.MONSTER_FIGHT}),
                             at_sea=True)
        self._fighting = (monster, battle)
        self.gm.scene_stack.push(battle)

    # ------------------------------------------------------------------
    # RENDER
    # ------------------------------------------------------------------

    def screen_of(self, x: float, y: float) -> tuple[int, int]:
        """Where sea tile position ``x``, ``y`` is on the screen, the boat in the middle."""
        px = SailingSettings.TILE_PIXELS
        return (int(ScreenSettings.WIDTH / 2 + (x - self.x) * px),
                int(ScreenSettings.HEIGHT / 2 + (y - self.y) * px))

    def render(self, surface: pygame.Surface) -> None:
        self._render_sea(surface)
        self._render_names(surface)
        self._render_monsters(surface)
        self._render_boat(surface)
        self._render_food(surface)
        if self.lines:
            self._render_line(surface)

    def _render_sea(self, surface: pygame.Surface) -> None:
        """The tiles round the boat, each its picture from the to-scale map, as big as on it."""
        px = SailingSettings.TILE_PIXELS
        pictures, grid, width = tiles()
        height = len(grid) // width
        edge = pictures[self.sea.kinds.index("beyond")]   # past the map's edge: the world's edge
        cols = ScreenSettings.WIDTH // px + 3
        rows = ScreenSettings.HEIGHT // px + 3
        left = int(math.floor(self.x - cols / 2))
        top = int(math.floor(self.y - rows / 2))
        sx, sy = self.screen_of(left, top)
        for row in range(top, top + rows):
            for col in range(left, left + cols):
                inside = 0 <= col < width and 0 <= row < height
                tile = pictures[grid[row * width + col]] if inside else edge
                surface.blit(tile, (sx + (col - left) * px, sy + (row - top) * px))

    def _render_names(self, surface: pygame.Surface) -> None:
        """Names of the places known, over their spots."""
        for name, (col, row) in self.sea.spots.items():
            if not sailing.known(self.gm.party, name):
                continue
            x, y = self.screen_of(col + 0.5, row + 0.5)
            width = text_renderer.text_width(name)
            if -width < x < ScreenSettings.WIDTH + width and -16 < y < ScreenSettings.HEIGHT + 16:
                text_renderer.draw_text(surface, name, (x - width // 2, y - 30),
                                        color=SailingSettings.LABEL_COLOR, glow=ColorSettings.BLACK)

    def _render_monsters(self, surface: pygame.Surface) -> None:
        """Each monster as a dark fin."""
        for mx, my, _ in self.monsters:
            x, y = self.screen_of(mx, my)
            pygame.draw.polygon(surface, SailingSettings.FIN_COLOR, [(x - 4, y + 3), (x + 4, y + 3), (x + 1, y - 5)])

    def _render_boat(self, surface: pygame.Surface) -> None:
        x, y = ScreenSettings.WIDTH // 2, ScreenSettings.HEIGHT // 2
        boat = boat_picture()
        if boat is None:
            surface.fill(SailingSettings.DOT_COLOR, (x - 3, y - 3, 6, 6))
            return
        if self.facing_left:
            boat = pygame.transform.flip(boat, True, False)
        surface.blit(boat, (x - boat.get_width() // 2, y - boat.get_height() + 4))

    def _render_food(self, surface: pygame.Surface) -> None:
        """The corner window: how many days the food reaches, and the days out."""
        party = self.gm.party
        food = sailing.food_left(party)
        lines = [f"{SailingSettings.FOOD_LABEL} {food} {'day' if food == 1 else 'days'}",
                 f"At sea {int(party.flags.get(sailing.DAY_FLAG, 0))}"]
        height = text_renderer.line_height(FontSettings.SIZE_BODY)
        width = max(text_renderer.text_width(line) for line in lines)
        box = pygame.Rect(6, 6, width + 16, height * len(lines) + 12)
        draw_window(surface, box)
        for n, line in enumerate(lines):
            text_renderer.draw_text(surface, line, (box.x + 8, box.y + 6 + n * height))

    def _render_line(self, surface: pygame.Surface) -> None:
        """The text box across the bottom; A turns its pages and closes it."""
        self._show_line()
        self.box.render(surface)
