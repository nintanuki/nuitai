"""The woven box in the Meialana's cabin: storage (Frankie, 11/26).

Any item in the shared bag can be put in and taken out again; key items stay in the bag. What is in the box
is ``Party.stored``, saved with the game. Left and right turn between Put in (the bag) and Take out (the box),
up and down move, A moves the item under the cursor, asking how many when there is more than one, and B
closes the box.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from core.scene import Scene
from core.scenes.count_scene import CountScene
from core.scenes.shop_scene import draw_item_name, shop_order
from settings import BoxSettings, ColorSettings, FontSettings, ItemSettings, ScreenSettings
from ui import input_map, text_renderer
from ui.scroll_mark import draw_list_marks
from ui.window import draw_window

if TYPE_CHECKING:
    from main import GameManager

PUT, TAKE = 0, 1
_TABS = pygame.Rect(0, 0, ScreenSettings.WIDTH, 28)
_LIST = pygame.Rect(0, 28, ScreenSettings.WIDTH, ScreenSettings.HEIGHT - 28)
_ROW = 14
_ROWS = 12


class BoxScene(Scene):
    """Move items between the bag and the box."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        self.tab = PUT
        self.cursor = 0

    def items(self) -> list[str]:
        """What the open tab lists, in the shops' order; the bag's key items are never listed."""
        party = self.gm.party
        held = party.inventory if self.tab == PUT else party.stored
        return sorted((item for item, count in held.items()
                       if count > 0 and not (self.tab == PUT and item in ItemSettings.KEY_ITEMS)), key=shop_order)

    def move(self, item: str, count: int) -> None:
        """Move ``count`` of ``item`` out of the open tab's side into the other."""
        party = self.gm.party
        source, target = (party.inventory, party.stored) if self.tab == PUT else (party.stored, party.inventory)
        count = min(count, source.get(item, 0))
        if count <= 0:
            return
        source[item] -= count
        if source[item] <= 0:
            del source[item]
        target[item] = target.get(item, 0) + count
        self.cursor = max(0, min(self.cursor, len(self.items()) - 1))

    def handle_event(self, event: pygame.event.Event) -> None:
        items = self.items()
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif input_map.is_left(event) or input_map.is_right(event):
            self.tab = TAKE if self.tab == PUT else PUT
            self.cursor = 0
            self.gm.audio.play("menu_move")
        elif items and (input_map.is_up(event) or input_map.is_down(event)):
            self.cursor = (self.cursor + (1 if input_map.is_down(event) else -1)) % len(items)
            self.gm.audio.play("menu_move")
        elif items and input_map.is_confirm(event):
            self.gm.audio.play("menu_select")
            self._pick(items[self.cursor])

    def _pick(self, item: str) -> None:
        party = self.gm.party
        held = (party.inventory if self.tab == PUT else party.stored)[item]
        if held == 1:
            self.move(item, 1)
            return
        self.gm.scene_stack.push(CountScene(self.gm, BoxSettings.HOW_MANY.format(item=ItemSettings.NAMES.get(item, item)),
                                            held, lambda count: self.move(item, count or 0)))

    def render(self, surface: pygame.Surface) -> None:
        """The two tabs across the top, then the open one's items and how many of each."""
        surface.fill(ColorSettings.BLACK)
        draw_window(surface, _TABS)
        size = FontSettings.SIZE_BODY
        for tab, label, x in ((PUT, BoxSettings.PUT, 24), (TAKE, BoxSettings.TAKE, 144)):
            color = ColorSettings.YELLOW if tab == self.tab else ColorSettings.GRAY
            text_renderer.draw_text(surface, label, (x, 9), color=color, size=size)   # the open one yellow: one hook only
        draw_window(surface, _LIST)
        items = self.items()
        top = _LIST.y + 10
        if not items:
            empty = BoxSettings.NOTHING_TO_PUT if self.tab == PUT else BoxSettings.EMPTY
            text_renderer.draw_text(surface, empty, (24, top), color=ColorSettings.GRAY, size=size)
            return
        held = self.gm.party.inventory if self.tab == PUT else self.gm.party.stored
        first = max(0, min(self.cursor - _ROWS + 1, len(items) - _ROWS))
        for index, item in enumerate(items[first:first + _ROWS], start=first):
            y = top + (index - first) * _ROW
            draw_item_name(surface, item, 16, y, ColorSettings.WHITE)
            amount = f"x{held[item]}"
            text_renderer.draw_text(surface, amount, (232 - text_renderer.text_width(amount, size), y), size=size)
            if index == self.cursor:
                text_renderer.draw_pointer(surface, (12, y + size // 2))
        draw_list_marks(surface, 244, top, _ROW, first, _ROWS, len(items))
