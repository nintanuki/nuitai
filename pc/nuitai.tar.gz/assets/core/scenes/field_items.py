"""The field menu's Items screen (Frankie, 11/21): one screen, party on the left, the shared bag on the right.

Final Fantasy VI's commands in Super Mario RPG's floating windows, and Super Mario RPG's way of handing an item
over: the item is carried on the hook. The pictures are in ``game/pygame/docs/design/menu-mockup/`` (``items-a``,
``items-c``, ``5-reach-member-bag``); the measures here are theirs.

* The party in small windows at the left (battle sprite, name, HP, the bag's count), the shared bag at the right
  under its category header (``< >``), and the help along the bottom, with a blue "Lasts N days at sea" for voyage
  food (``systems.sailing.keeps``).
* **A on an item hooks it**: its row dims and the item rides on the hook, which swings across to a member. A on that
  member asks Use or Give beside them; only Use is asked of what a fight cannot use. B drops the item back.
* **With nothing hooked, A on a member opens their bag** beside them: A on an item there offers Use and Take (B is back); Take sends it
  back to the shared bag; B goes back to the member.
* There is one hook, hung from the top of the screen (``text_renderer.draw_pointer(from_screen_top=True)``), swinging
  from window to window; it may rest over an item's icon or a member's sprite, covering it.

The rules (what a heal, a lontar, a seed or a Give does, who can take what, the lines said) are the old Items screen's,
``InventoryScene``: this screen carries the item and hands it the member (``InventoryScene.pick_member``).
"""

from __future__ import annotations

import pygame

from core.factories import stance_numbers
from core.scenes.field_menu_main import M, G, blit32
from core.scenes.field_menu_pages import CATEGORY_COLORS, Page, short_item_name
from core.shared import short_name
from settings import ColorSettings, FontSettings, ItemSettings, UISettings
from systems import battle_bag
from systems.sailing import keeps
from ui import input_map, text_renderer
from ui.field_menu_kit import GRAY, ITEMS_C, RED, WHITE, YELLOW, box, more_arrow, paged, text, width, rows_top
from ui.item_icon import item_icon

SEA = ColorSettings.LABEL_CYAN
PW, PH = 104, 51                   # a member's window
PX = M
SIDE = PX + PW + G                 # the right-hand column starts here
LW = 256 - M - SIDE
HEAD_H = 22
LY = M + HEAD_H + G                # the list's top, under the category header
LIST_BOTTOM = M + 3 * PH + 2 * G   # the list ends level with the third member's window
ROWS = 8                           # item rows the list shows
ROW = 16
SHOWN = 3                          # members shown at once; the window scrolls over more
NAME_ROOM = 80                     # ten letters: a longer name uses the short-name list in this narrow list
TEXT_X = PX + 36                   # a member's words start here, close to the sprite so the hook can sit on it
DESC_H = 36
SIZE = FontSettings.SIZE_BODY


def _band(surface: pygame.Surface, x: int, y: int, w: int, h: int = 12) -> None:
    shade = pygame.Surface((w, h), pygame.SRCALPHA)
    shade.fill((255, 255, 255, 36))
    surface.blit(shade, (x, y))


def _dim(color: tuple) -> tuple:
    return tuple(c // 3 for c in color)


def item_name(item_id: str, room: int = NAME_ROOM) -> str:
    """An item's name as this narrow list shows it: the full name, or the short-name list's when it is over ten letters."""
    name = ItemSettings.NAMES.get(item_id, item_id)
    if item_id in ItemSettings.SHELLS:       # a lontar shows its move's short name, as the shops do (11/17)
        name = UISettings.MOVE_SHORT_NAMES.get(name, name)
    if width(name) > room:
        name = short_item_name(item_id, name)
    return name


def fitted_name(item_id: str, room: int = NAME_ROOM) -> str:
    """``item_name``, cut short as a last resort for a long name that has no short form yet, so no name ever runs out
    of its window (Frankie's rule is a short form for every name over ten letters; most have none yet)."""
    name = item_name(item_id, room)
    while len(name) > 1 and width(name) > room:
        name = name[:-1]
    return name


def item_row(surface: pygame.Surface, item_id: str, x: int, y: int, color, dim: bool = False,
             room: int = NAME_ROOM) -> None:
    """An item's icon at ``x`` and its name 12 pixels on."""
    icon = item_icon(item_id)
    if icon is not None:
        if dim:
            icon = icon.copy()
            icon.set_alpha(110)
        surface.blit(icon, (x, y))
    text(surface, fitted_name(item_id, room), x + 12, y, _dim(color) if dim else color)


class ItemsScreen(Page):
    """The Items screen. Zones: ``list`` (the hook on an item), ``header`` (on the category), ``member`` (on a
    member, with an item carried or not), ``choice`` (Use / Give beside them), ``bag`` (in their bag) and ``take``
    (Use / Take beside a bag item)."""

    full = True

    def __init__(self, menu, preview=False) -> None:
        super().__init__(menu, preview)
        from core.scenes.inventory_scene import InventoryScene

        self.inv = InventoryScene(self.gm)
        self.zone = "list"
        self.carry: str | None = None       # the item on the hook
        self.sel = min(menu.member, max(0, len(self.gm.party.members) - 1))     # the member the hook is on
        self.top = 0                        # the first member shown
        self.options: list[str] = []
        self.choice = 0
        self.bag_cursor = 0
        self.bag_top = 0
        self.take = 0
        self.take_options = ["Take"]
        self.last_hook: pygame.Rect | None = None
        self._fix()

    # -- state ----------------------------------------------------------------------------

    @property
    def members(self) -> list:
        return self.gm.party.members

    def _names(self) -> list[str]:
        """The categories with something in, but Battle Bags: a member's bag opens from the member."""
        from core.scenes.inventory_scene import BAGS

        return [name for name in self.inv.categories() if name != BAGS]

    def _fix(self) -> None:
        """Keep a category open while there is one, the cursor inside its list."""
        names = self._names()
        if not names:
            self.inv.category = None
            self.inv._item_cursor = 0
            return
        if self.inv.category not in names:
            self.inv.category = names[0]
            self.inv._item_cursor = 0
        self.inv._item_cursor = min(self.inv._item_cursor, max(0, len(self.inv._rows()) - 1))

    def _rows(self) -> list[tuple[str, int]]:
        return self.inv._rows() if self.inv.category else []

    @property
    def cursor(self) -> int:
        return self.inv._item_cursor

    def _first(self) -> int:
        """The first item row shown: the list scrolls to keep the cursor in sight."""
        return max(0, min(self.cursor - (ROWS - 1), max(0, len(self._rows()) - ROWS)))

    def _member(self):
        return self.members[self.sel] if self.members else None

    def _busy(self) -> bool:
        inv = self.inv
        return (not inv.text_box.is_done()) or inv._message is not None

    def blocking(self) -> bool:
        return self._busy()

    def update(self, dt: float) -> None:
        self.inv.update(dt)

    def _scroll_to(self, index: int) -> None:
        self.sel = index % max(1, len(self.members))
        if self.sel < self.top:
            self.top = self.sel
        elif self.sel >= self.top + SHOWN:
            self.top = self.sel - SHOWN + 1
        self.top = max(0, min(self.top, max(0, len(self.members) - SHOWN)))

    def _eligible(self, member) -> bool:
        """Whether the item carried can go to ``member`` at all: a lontar to one who can learn it, a revive to the fallen."""
        from core.scenes.inventory_scene import can_learn

        item = self.carry
        if item in ItemSettings.SHELLS:
            return can_learn(member, item, self.gm.party.flags)
        if battle_bag.is_gear(item):          # a weapon or a relic goes to a bag of someone who can use it
            return battle_bag.can_carry(member, item)
        if item in ItemSettings.REVIVES:
            return member.current_hp <= 0
        return True

    # -- input ----------------------------------------------------------------------------

    def handle(self, event) -> str | None:
        audio = self.gm.audio
        inv = self.inv
        if self._busy():
            inv.handle_event(event)           # a line to read: A or B closes it
            self._fix()
            return None
        if input_map.is_l1(event) or input_map.is_r1(event):
            # L and R flip the category from anywhere on the screen (Frankie, 11/21): while an item is hooked, the
            # hook is on the party, or a bag is open, the shared list changes behind it and nothing else does.
            self._flip(-1 if input_map.is_l1(event) else 1)
            return None
        zone = getattr(self, f"_zone_{self.zone}")
        return zone(event)

    def _flip(self, step: int) -> None:
        names = self._names()
        if names:
            inv = self.inv
            inv.category = names[(names.index(inv.category) + step) % len(names)] if inv.category in names else names[0]
            inv._item_cursor = 0
            if self.carry is not None:          # the pick is dropped with the category it came from
                self.carry, self.options = None, []
                inv._using = inv._held = None
                inv._giving = False
                if self.zone in ("member", "choice"):
                    self.zone = "list"
            self.gm.audio.play("menu_move")

    def _zone_list(self, event) -> str | None:
        audio, inv = self.gm.audio, self.inv
        rows = self._rows()
        if input_map.is_cancel(event):
            return "back"
        if input_map.is_up(event):
            if inv._item_cursor == 0:
                self.zone = "header"
            else:
                inv._item_cursor -= 1
            audio.play("menu_move")
        elif input_map.is_down(event):
            if rows and inv._item_cursor < len(rows) - 1:
                inv._item_cursor += 1
                audio.play("menu_move")
        elif input_map.is_left(event) and self.members:
            self.zone = "member"
            audio.play("menu_move")
        elif input_map.is_confirm(event) and rows:
            self._hook_item()
        return None

    def _zone_header(self, event) -> str | None:
        audio = self.gm.audio
        if input_map.is_cancel(event):
            return "back"
        if input_map.is_left(event):
            self._flip(-1)
        elif input_map.is_right(event):
            self._flip(1)
        elif input_map.is_down(event) and self._rows():
            self.zone = "list"
            audio.play("menu_move")
        return None

    def _hook_item(self) -> None:
        """A on an item: what can be used or given is hooked and swings over to the party; a bait, a garden seed or
        a lontar with no one to read it answers on the spot, as it always did (``InventoryScene``)."""
        from core.scenes.inventory_scene import _USABLE

        inv = self.inv
        inv.handle_event(_key_event(input_map.CONFIRM_KEYS))
        if inv._choice is not None:
            self.carry = inv._held
            self.options = (["Use"] if inv._held in _USABLE else []) + ["Give"]
            inv._choice = None
        elif inv._using is not None:
            self.carry, self.options = inv._using, []
            self._scroll_to(inv._member_cursor)       # the first who can learn it, for a lontar
            inv._using = None
        else:
            return
        self.zone = "member"

    def _zone_member(self, event) -> str | None:
        audio = self.gm.audio
        if input_map.is_cancel(event):
            self.carry = None
            self.zone = "list"
            audio.play("menu_move")
        elif input_map.is_up(event):
            self._scroll_to(self.sel - 1)
            audio.play("menu_move")
        elif input_map.is_down(event):
            self._scroll_to(self.sel + 1)
            audio.play("menu_move")
        elif input_map.is_right(event) and self.carry is None:
            self.zone = "list"
            audio.play("menu_move")
        elif input_map.is_confirm(event) and self._member() is not None:
            if self.carry is None:
                self.zone, self.bag_cursor, self.bag_top = "bag", 0, 0
                audio.play("menu_select")
            elif self.options:
                self.zone, self.choice = "choice", 0
                audio.play("menu_select")
            else:
                self._apply(giving=False)
        return None

    def _zone_choice(self, event) -> str | None:
        audio = self.gm.audio
        if input_map.is_cancel(event):
            self.zone = "member"
            audio.play("menu_move")
        elif input_map.is_up(event) or input_map.is_down(event):
            self.choice = (self.choice + (-1 if input_map.is_up(event) else 1)) % len(self.options)
            audio.play("menu_move")
        elif input_map.is_confirm(event):
            giving = self.options[self.choice] == "Give"
            self.zone = "member"
            self._apply(giving)
        return None

    def _apply(self, giving: bool) -> None:
        """The item carried goes to the member under the hook: used on them, or into their bag."""
        inv = self.inv
        inv._using, inv._giving, inv._member_cursor = self.carry, giving, self.sel
        inv.pick_member(self._member())
        self.carry = inv._using              # still in hand when more of it is left to give or use
        inv._using, inv._giving = None, False
        self._fix()
        if self.carry is not None and self.gm.party.inventory.get(self.carry, 0) <= 0:
            self.carry = None
        if self.carry is None:
            self.zone = "list"

    def _zone_bag(self, event) -> str | None:
        audio = self.gm.audio
        member = self._member()
        slots = battle_bag.size(member)
        if input_map.is_cancel(event):
            self.zone = "member"
            audio.play("menu_move")
        elif input_map.is_up(event) or input_map.is_down(event):
            self.bag_cursor = (self.bag_cursor + (-1 if input_map.is_up(event) else 1)) % slots
            if self.bag_cursor < self.bag_top:
                self.bag_top = self.bag_cursor
            elif self.bag_cursor >= self.bag_top + ROWS:
                self.bag_top = self.bag_cursor - ROWS + 1
            audio.play("menu_move")
        elif input_map.is_confirm(event):
            if self.bag_cursor < len(member.bag):
                from core.scenes.inventory_scene import _USABLE

                item = member.bag[self.bag_cursor]
                self.take_options = (["Use"] if item in _USABLE or item in ItemSettings.SEEDS else []) + ["Take"]
                self.zone, self.take = "take", 0
                audio.play("menu_select")
            else:
                audio.play("menu_move")
        return None

    def _zone_take(self, event) -> str | None:
        audio = self.gm.audio
        member = self._member()
        if input_map.is_cancel(event):
            self.zone = "bag"
            audio.play("menu_move")
        elif input_map.is_up(event) or input_map.is_down(event):
            self.take = (self.take + (-1 if input_map.is_up(event) else 1)) % len(self.take_options)
            audio.play("menu_move")
        elif input_map.is_confirm(event):
            if self.bag_cursor < len(member.bag):
                item = member.bag[self.bag_cursor]
                battle_bag.take_back(self.gm.party, member, item)       # back to the shared bag either way
                audio.play("menu_select")
                self._fix()
                if self.take_options[self.take] == "Use":
                    # Use: it is hooked again, carried to whoever it is for (the same as picking it from the list)
                    self.carry, self.options = item, []
                    self.zone = "member"
                    return None
            self.zone = "bag"
            self.bag_cursor = min(self.bag_cursor, battle_bag.size(member) - 1)
        return None

    # -- what the help says -----------------------------------------------------------------

    def _help_item(self) -> str | None:
        """The item the hook is on or carries, if any."""
        if self.carry is not None:
            return self.carry
        if self.zone in ("list", "choice"):
            rows = self._rows()
            return rows[self.cursor][0] if rows else None
        if self.zone in ("bag", "take"):
            member = self._member()
            return member.bag[self.bag_cursor] if member is not None and self.bag_cursor < len(member.bag) else None
        return None

    def help_lines(self) -> list[tuple[str, tuple]]:
        """The help along the bottom: the words, then in blue how long a food lasts at sea."""
        from core.scenes.inventory_scene import CATEGORIES, item_help

        inv = self.inv
        if inv._message is not None:
            return [(inv._message, WHITE)]
        item = self._help_item()
        if item is not None:
            lines = [(item_help(item), WHITE)]
            days = keeps(item)
            if days:
                lines.append((f"Lasts {days} days at sea", SEA))
            return lines
        if self.zone == "header" and inv.category:
            return [(CATEGORIES[inv.category], WHITE)]
        member = self._member()
        if self.zone == "member" and member is not None:
            return [("A opens this bag.", WHITE)]
        if self.zone in ("bag", "take"):
            return [("Nothing in this slot.", GRAY)]
        return []

    # -- drawing --------------------------------------------------------------------------

    def render(self, surface, lay, active) -> None:
        self._draw_party(surface)
        if self.zone in ("bag", "take"):
            self._draw_bag(surface)
        else:
            self._draw_list(surface)
        self._draw_help(surface)
        if self.zone == "choice":
            self._draw_choice(surface)
        elif self.zone == "take":
            self._draw_take(surface)
        self._draw_hook(surface)

    def _member_y(self, index: int) -> int:
        return M + (index - self.top) * (PH + G)

    def _draw_party(self, surface) -> None:
        lit = self.zone in ("member", "choice", "bag", "take")
        taking = self.carry is not None and self.zone in ("member", "choice")
        for index in range(self.top, min(len(self.members), self.top + SHOWN)):
            member = self.members[index]
            y = self._member_y(index)
            on = not lit or index == self.sel
            box(surface, PX, y, PW, PH, border=WHITE if on else GRAY)
            blit32(surface, member.id, PX + 2, y + 9)
            down = member.current_hp <= 0
            fit = not taking or self._eligible(member)
            color = (RED if down else WHITE) if on and fit else GRAY
            _, shown, top = stance_numbers(member)
            text(surface, short_name(member.id), TEXT_X, y + 8, color)
            text(surface, f"{shown}/{top}", TEXT_X, y + 20, color)
            if not (taking and index == self.sel):        # the carried item takes the bag line's place
                text(surface, f"Bag {len(member.bag)}/{battle_bag.size(member)}", TEXT_X, y + 32, GRAY)
        if self.top > 0:
            _arrow(surface, PX + PW - 14, M + 4, up=True)
        if len(self.members) > self.top + SHOWN:
            _arrow(surface, PX + PW - 14, M + 2 * (PH + G) + PH - 9)

    def _draw_list(self, surface) -> None:
        inv = self.inv
        category = inv.category
        names = self._names()
        box(surface, SIDE, M, LW, HEAD_H)
        if category:
            color = CATEGORY_COLORS.get(category, WHITE)
            name_x = SIDE + (LW - width(category)) // 2
            if len(names) > 1:
                # each arrow sits one letter (8px) clear of the name, so the longest still fits the window
                text(surface, "<", name_x - 16, M + 7, WHITE)
                text(surface, ">", name_x + width(category) + 8, M + 7, WHITE)
            text(surface, category, name_x, M + 7, color)
        else:
            text(surface, "Nothing", SIDE + (LW - width("Nothing")) // 2, M + 7, GRAY)
        box(surface, SIDE, LY, LW, LIST_BOTTOM - LY)
        rows = self._rows()
        first = self._first()
        color = CATEGORY_COLORS.get(category, WHITE)
        for i, (item_id, count) in enumerate(rows[first:first + ROWS]):
            y = LY + 8 + i * ROW
            index = first + i
            lifted = self.carry == item_id
            if lifted or (self.zone == "list" and index == self.cursor):
                _band(surface, SIDE + 6, y - 2, LW - 12)
            tag = f"x{count}" if count < 10 else str(count)       # 10 or more drops the x, so names get room
            # a name over ten letters, or one that would touch its count, takes its short form
            room = min(NAME_ROOM, SIDE + LW - 6 - width(tag) - 8 - (SIDE + 8 + 12))     # a letter's gap, so "Smoked Eel12" never joins
            item_row(surface, item_id, SIDE + 8, y, color if count > 0 else GRAY, dim=lifted, room=room)
            text(surface, tag, SIDE + LW - 6, y, WHITE if count > 0 else GRAY, right=True)
        if first > 0:
            _arrow(surface, SIDE + LW - 14, LY + 2, up=True)
        if len(rows) > first + ROWS:
            _arrow(surface, SIDE + LW - 14, LIST_BOTTOM - 8)

    def _draw_bag(self, surface) -> None:
        member = self._member()
        slots = battle_bag.size(member)
        shown = min(slots, ROWS)
        box(surface, SIDE, M, LW, 26 + shown * ROW)
        text(surface, "Bag", SIDE + 10, M + 8, WHITE)
        text(surface, f"{len(member.bag)}/{slots}", SIDE + LW - 10, M + 8, ITEMS_C, right=True)
        from core.scenes.field_menu_pages import CATEGORY_COLORS as colors, _category

        for i in range(shown):
            slot = self.bag_top + i
            y = M + 24 + i * ROW
            if slot < len(member.bag):
                item = member.bag[slot]
                if slot == self.bag_cursor:
                    _band(surface, SIDE + 6, y - 2, LW - 12)
                item_row(surface, item, SIDE + 12, y, colors.get(_category(item), WHITE))
            else:
                if slot == self.bag_cursor:
                    _band(surface, SIDE + 6, y - 2, LW - 12)
                text(surface, "-", SIDE + 24, y, GRAY)
        if self.bag_top > 0:
            _arrow(surface, SIDE + LW - 14, M + 20, up=True)
        if slots > self.bag_top + ROWS:
            _arrow(surface, SIDE + LW - 14, M + 24 + ROWS * ROW - 4)

    def _desc_rows(self) -> list[tuple[str, tuple]]:
        font = text_renderer.get_font(SIZE)
        rows: list[tuple[str, tuple]] = []
        for words, color in self.help_lines():
            for line in text_renderer.wrap(words, font, 256 - 2 * M - 20):
                rows.append((line, color))
        return rows

    def _draw_help(self, surface) -> None:
        y = 224 - M - DESC_H
        box(surface, M, y, 256 - 2 * M, DESC_H)
        rows, more = paged(self._desc_rows())
        top = rows_top(y, DESC_H, len(rows))
        for row, (line, color) in enumerate(rows):
            text(surface, line, M + 10, top + row * 12, color)
        if more:
            more_arrow(surface, 256 - M - 18, y + DESC_H - 10)

    def _draw_popup(self, surface, words: list[str], at: int, y: int, anchor_x: int) -> None:
        h = 8 + 16 * len(words)
        if y + h > 224 - M - DESC_H - 2:
            y = 224 - M - DESC_H - 2 - h
        box(surface, anchor_x, y, 72, h)
        for i, word in enumerate(words):
            text(surface, word, anchor_x + 14, y + 8 + i * 16, YELLOW if i == at else WHITE)

    def _draw_beside_member(self, surface, words: list[str], at: int) -> None:
        """A small window just under the member the hook is on, over the party and clear of the lists."""
        y = self._member_y(self.sel) + PH - 4
        if y + 8 + 16 * len(words) > 224 - M - DESC_H - 2:
            y = self._member_y(self.sel) - 8 - 16 * len(words) + 4
        self._draw_popup(surface, words, at, y, PX + 30)

    def _draw_choice(self, surface) -> None:
        self._draw_beside_member(surface, self.options, self.choice)

    def _draw_take(self, surface) -> None:
        self._draw_beside_member(surface, self.take_options, self.take)

    # -- the one hook -----------------------------------------------------------------------

    def hook_tip(self) -> tuple[int, int]:
        """Where the hook hangs: (the tip's x, the top of the row it is level with)."""
        if self.zone in ("member", "choice"):
            y = self._member_y(self.sel)
            return (PX + 32, y + 32 if self.carry is not None else y + 20)
        if self.zone in ("bag", "take"):
            return (SIDE + 18, M + 24 + (self.bag_cursor - self.bag_top) * ROW)
        if self.zone == "header":
            return (SIDE + 12, M + 7)
        return (SIDE + 16, LY + 8 + (self.cursor - self._first()) * ROW)

    def _draw_hook(self, surface) -> None:
        tip_x, row_y = self.hook_tip()
        rect = text_renderer.draw_pointer(surface, (tip_x, row_y + SIZE // 2), YELLOW, from_screen_top=True)
        self.last_hook = rect
        if self.carry is not None:
            # the item rides on the hook: icon, then name, in its category's color, without a box
            from core.scenes.field_menu_pages import _category

            room = PX + PW - 6 - (rect.right + 12)
            item_row(surface, self.carry, rect.right, rect.bottom - SIZE, CATEGORY_COLORS.get(_category(self.carry), WHITE),
                     room=max(8, min(room, NAME_ROOM)) if self.zone in ("member", "choice") else NAME_ROOM)

    def render_over(self, surface) -> None:
        if not self.inv.text_box.is_done():
            self.inv.text_box.render(surface)


def _arrow(surface: pygame.Surface, x: int, y: int, up: bool = False) -> None:
    """A small arrow where there is more: blinks as the lists' do."""
    if int(pygame.time.get_ticks() / 400) % 2 == 0:
        points = [(x, y + 5), (x + 8, y + 5), (x + 4, y)] if up else [(x, y), (x + 8, y), (x + 4, y + 5)]
        pygame.draw.polygon(surface, WHITE, points)


def _key_event(keys) -> pygame.event.Event:
    return pygame.event.Event(pygame.KEYDOWN, key=sorted(keys)[0], mod=0, unicode="")
