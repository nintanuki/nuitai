"""The sound test, from Options on the title (Frankie, 11/11, 11/19): like Capcom's on the Super Nintendo.

Two lists, Music and Sounds; left and right change the list, up and down scroll it, confirm plays the
one under the cursor, cancel leaves. A piece or sound shows only once it has played in the game
(``systems/heard.py``), so nothing is spoiled; the rest are ``???`` rows. Leaving brings back the title's music.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

import pygame

from core import save
from core.scene import Scene
from settings import AudioSettings, ColorSettings, FontSettings, UISettings
from systems import heard
from ui import input_map, text_renderer
from ui.window import draw_header
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager

_LIST_LEFT_X = 24  # Room for the pointer, as Config has it.
_ROW_HEIGHT = 16
_ROWS = 8
_HIDDEN = "???"
MUSIC, SOUNDS = range(2)
_TITLES = ("Music", "Sounds")
_HELP = "Confirm plays it."


class SoundTestScene(Scene):
    """Every piece of music and sound effect, played by confirm once heard."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        super().__init__(gm)
        self.page = MUSIC
        self._cursors = [0, 0]
        self._tops = [0, 0]
        # What the saves on hand have heard, read when the test opens.
        self._heard = save.heard_on_hand()

    # ------------------------------------------------------------------
    # THE LISTS
    # ------------------------------------------------------------------

    def keys(self, page: int | None = None) -> list[str]:
        """The keys on a list (the open one by default), in order."""
        return heard.songs() if (self.page if page is None else page) == MUSIC else heard.sounds()

    def known(self, key: str, page: int | None = None) -> bool:
        """Whether the player has heard it."""
        return key in self._heard["songs" if (self.page if page is None else page) == MUSIC else "sounds"]

    def label(self, row: int) -> str:
        """What a row shows: its number and name, or ``???`` until it is heard."""
        key = self.keys()[row]
        name = (heard.song_name(key) if self.page == MUSIC else heard.sound_name(key)) if self.known(key) else _HIDDEN
        return f"{row + 1:02d} {name}"

    @property
    def cursor(self) -> int:
        return self._cursors[self.page]

    # ------------------------------------------------------------------
    # ACTIONS
    # ------------------------------------------------------------------

    def play_current(self) -> bool:
        """Play the one under the cursor if heard; False for a ``???`` row."""
        key = self.keys()[self.cursor]
        if not self.known(key):
            return False
        if self.page == MUSIC:
            for files in AudioSettings.SCREEN_MUSIC.values():
                for file in files:
                    if heard.song_key(file) == key:
                        path = os.path.join(AudioSettings.MUSIC_DIR, AudioSettings.music_file(file))
                        self.gm.audio.play_music_track(path, loops=-1)
                        return True
            return False
        self.gm.audio.play(key)
        return True

    def _scroll(self, step: int) -> None:
        count = len(self.keys())
        at = (self.cursor + step) % count
        self._cursors[self.page] = at
        top = self._tops[self.page]
        if at < top:
            top = at
        elif at >= top + _ROWS:
            top = at - _ROWS + 1
        self._tops[self.page] = max(0, min(top, count - _ROWS))

    def on_exit(self) -> None:
        """Back to the title: its music again."""
        self.gm.audio.stop_music()
        self.gm.audio.play_screen("title")

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Scroll, change the list, play, or leave."""
        if input_map.is_cancel(event):
            self.gm.audio.play("menu_select")
            self.gm.scene_stack.pop()
        elif input_map.is_up(event) or input_map.is_down(event):
            self._scroll(-1 if input_map.is_up(event) else 1)
            self.gm.audio.play("menu_move")
        elif input_map.is_left(event) or input_map.is_right(event):
            self.page = 1 - self.page
            self.gm.audio.play("menu_move")
        elif input_map.is_confirm(event):
            self.play_current()

    def render(self, surface: pygame.Surface) -> None:
        """The header with the list's name, and eight rows."""
        render_scene_background(self, surface)
        count = len(self.keys())
        heard_count = sum(self.known(k) for k in self.keys())
        draw_header(surface, "Options", [_HELP, f"{_TITLES[self.page]}: {heard_count} of {count} heard"])
        size = FontSettings.SIZE_BODY
        top = self._tops[self.page]
        for i in range(top, min(top + _ROWS, count)):
            y = UISettings.HEADER_LIST_TOP + (i - top) * _ROW_HEIGHT
            color = ColorSettings.WHITE if self.known(self.keys()[i]) else ColorSettings.GRAY
            text_renderer.draw_text(surface, self.label(i), (_LIST_LEFT_X, y), color=color, size=size)
            if i == self.cursor:
                text_renderer.draw_pointer(surface, (_LIST_LEFT_X - 4, y + size // 2), ColorSettings.YELLOW)
        # Which list this is, and that there is another, at the bottom.
        tabs = "   ".join(f"[{t}]" if n == self.page else t for n, t in enumerate(_TITLES))
        text_renderer.draw_text(surface, tabs, (_LIST_LEFT_X, UISettings.HEADER_LIST_TOP + _ROWS * _ROW_HEIGHT + 4),
                                color=ColorSettings.YELLOW, size=size)
