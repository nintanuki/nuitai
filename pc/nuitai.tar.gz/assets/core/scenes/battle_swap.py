"""The in-fight element swap screen: Equip, then Element (Frankie, 11/12; built 11/13).

One screen with every open tier and everything slotted in either stance, then the bank, drawn as the field
menu's Element tab draws them (``field_menu_pages.slot_box``). The cursor moves over the slots; A picks one
element up, A again says where it goes: into an empty slot it just goes there, into a filled one the two
trade places (the one displaced goes to the mover's old slot, or to the bank when the mover came from it).
The bank is a tier with room for all. B before the second A puts the pick back; B with nothing picked leaves
without spending the turn. One change ends the turn: the scene sends it to ``Battle.submit_slot``.

This file holds the rules and the drawing; ``BattleScene`` owns the turn.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pygame

from core.scenes.field_menu_pages import GRID_COLUMNS, SLOT_ROW, SMALLEST, letters_that_fit, slot_box
from settings import BattleStageSettings, ColorSettings, LoadoutSettings
from ui import field_menu_kit as kit
from ui import input_map, text_renderer
from ui.element_tag import tag_elements
from ui.flex import flex_widths
from ui.grid_menu import short_move_name
from ui.window import draw_window

VISIBLE_ROWS = 3                  # what fits in the fight's bottom window above the help lines
_LEFT, _RIGHT = 30, 248           # the slots' span, an even margin each side as the field menu's
_TOP = 9                          # the first row's text line below the window's top edge
_HELP_Y = 58                      # the help lines below the window's top edge


@dataclass
class Row:
    """One row of the screen: a tier (``tier`` 1 to 7) or a row of the bank (``tier`` None)."""

    label: str
    tier: int | None
    cells: list[str | None]       # move ids; None is an empty slot


@dataclass
class Result:
    """What a press did: ``kind`` is "moved", "picked", "dropped", "left", "cant" or "none"."""

    kind: str
    loadout: dict[str, int] | None = None
    move: dict[str, Any] | None = None
    banked: bool = False


def rearrange(loadout: dict[str, int], held: str, held_row: int | None, row: int | None,
              target: str | None) -> dict[str, int] | None:
    """The loadout after putting ``held`` (from tier ``held_row``, None the bank) in tier ``row`` (None the bank),
    ``target`` the move in the slot aimed at, or None when nothing changes."""
    result = dict(loadout)
    if row is None:
        if held_row is None:
            return None            # bank to bank
        del result[held]
        return result
    if held_row == row:
        return None                # the same tier: a tier's slots are not ordered
    result[held] = row
    if target is not None:
        if held_row is None:
            del result[target]     # the bank takes the one displaced
        else:
            result[target] = held_row
    return result


class ElementSwap:
    """The screen's state: the rows, the cursor and the element picked up."""

    def __init__(self, known: list[dict[str, Any]], loadout: dict[str, int], slots: list[int],
                 member_elements: list[str] | tuple[str, ...], mana: int = 0,
                 start: str | None = None, forced: str | None = None) -> None:
        self.by_id = {m["id"]: m for m in known}
        self.loadout = dict(loadout)
        self.elements = tuple(member_elements)
        self.mana = mana
        self.forced = forced            # Hina's lesson: this one must be picked and slotted
        self.held: str | None = None
        self.rows: list[Row] = []
        for tier in range(1, LoadoutSettings.ROWS + 1):
            if slots[tier - 1] <= 0:
                continue
            here = [m["id"] for m in known if self.loadout.get(m["id"]) == tier][:slots[tier - 1]]
            self.rows.append(Row(str(tier), tier, here + [None] * (slots[tier - 1] - len(here))))
        bank = [m["id"] for m in known if m["id"] not in self.loadout]
        per = GRID_COLUMNS
        chunks = [bank[i:i + per] for i in range(0, len(bank), per)]
        if not chunks or len(chunks[-1]) >= per:
            chunks.append([])           # the bank always has room
        for index, chunk in enumerate(chunks):
            self.rows.append(Row("B" if index == 0 else "", None, chunk + [None] * (per - len(chunk))))
        self.row = 0
        self.col = 0
        if start is not None:
            self.go_to(start)
        elif self.rows[0].cells and self.rows[0].cells[0] is None:
            self.go_to(next((m for r in self.rows for m in r.cells if m is not None), None))

    # -- where things are ---------------------------------------------------------------------

    def find(self, move_id: str) -> tuple[int, int] | None:
        for r, row in enumerate(self.rows):
            if move_id in row.cells:
                return r, row.cells.index(move_id)
        return None

    def go_to(self, move_id: str | None) -> None:
        spot = self.find(move_id) if move_id else None
        if spot is not None:
            self.row, self.col = spot

    @property
    def under(self) -> str | None:
        """The move id in the slot the cursor is on, None for an empty one."""
        return self.rows[self.row].cells[self.col]

    def _tier_of(self, move_id: str) -> int | None:
        return self.loadout.get(move_id)

    def _locked(self, move_id: str | None) -> bool:
        """A character's own move stays where it is: the swap moves elements only."""
        return move_id is not None and bool(self.by_id[move_id].get("signature"))

    # -- the cursor -------------------------------------------------------------------------------

    def move(self, d_row: int, d_col: int) -> bool:
        """Step the cursor; True when it moved. Up and down keep the column as near as the row allows."""
        row = max(0, min(len(self.rows) - 1, self.row + d_row))
        col = max(0, min(len(self.rows[row].cells) - 1, self.col + d_col))
        moved = (row, col) != (self.row, self.col)
        self.row, self.col = row, col
        return moved

    def handle(self, event: pygame.event.Event) -> bool:
        """Move the cursor on a direction press; True when it moved. A and B are the scene's."""
        if input_map.is_up(event):
            return self.move(-1, 0)
        if input_map.is_down(event):
            return self.move(1, 0)
        if input_map.is_left(event):
            return self.move(0, -1)
        if input_map.is_right(event):
            return self.move(0, 1)
        return False

    # -- A and B ----------------------------------------------------------------------------------

    def confirm(self) -> Result:
        """A: pick the element under the cursor up, or put the picked one here."""
        here = self.under
        tier = self.rows[self.row].tier
        if self.held is None:
            if here is None or self._locked(here):
                return Result("cant")
            self.held = here
            return Result("picked", move=self.by_id[here])
        if here == self.held:
            self.held = None
            return Result("dropped")
        if self._locked(here):
            return Result("cant")
        held_row = self._tier_of(self.held)
        changed = rearrange(self.loadout, self.held, held_row, tier, here)
        if changed is None:
            return Result("cant")
        move = self.by_id[self.held]
        return Result("moved", loadout=changed, move=move, banked=tier is None)

    def cancel(self) -> Result:
        """B: put the pick back, or leave the screen."""
        if self.held is not None:
            self.held = None
            return Result("dropped")
        return Result("left")

    # -- what to say --------------------------------------------------------------------------------

    def help_lines(self) -> list[str]:
        """What A will do now, and what B will do."""
        here = self.under
        tier = self.rows[self.row].tier
        if self.held is None:
            if here is None:
                return ["Nothing here. Pick an element.", "B: back"]
            if self._locked(here):
                return [f"{short_move_name(self.by_id[here])} stays in its slot.", "B: back"]
            return [f"A: pick up {self.by_id[here]['name']}.", "B: back"]
        name = self.by_id[self.held]["name"]
        place = "the bank" if tier is None else f"tier {tier}"
        if here == self.held:
            return [f"A: put {name} back.", "B: put it back"]
        if self._locked(here):
            return [f"{short_move_name(self.by_id[here])} stays in its slot.", "B: put it back"]
        held_row = self._tier_of(self.held)
        if rearrange(self.loadout, self.held, held_row, tier, here) is None:
            return [f"{name} is there already." if held_row == tier else f"{name} is in the bank.",
                    "B: put it back"]
        if here is None:
            return [f"A: put {name} in {place}.", "B: put it back"]
        other = self.by_id[here]["name"]
        goes = "the bank" if held_row is None else f"tier {held_row}"
        return [f"A: put {name} in {place}.", f"{other} goes to {goes}."]

    # -- drawing -------------------------------------------------------------------------------------

    def _first_row(self) -> int:
        """The first row shown, scrolled just far enough to keep the cursor's row in view."""
        first = max(0, min(self.row - VISIBLE_ROWS + 1, len(self.rows) - VISIBLE_ROWS))
        return max(0, min(first, self.row))

    def _row_y(self, index: int, top: int) -> int:
        return top + _TOP + (index - self._first_row()) * SLOT_ROW

    def _widths(self, row: Row, on_row: bool) -> list[int]:
        total = _RIGHT - _LEFT
        count = len(row.cells)
        if on_row and self.under is not None:
            widths = [SLOT_ROW] * count
            widths[self.col] = total - SLOT_ROW * (count - 1)
            return widths
        return flex_widths(total, GRID_COLUMNS, None, 0, SMALLEST)

    def cell_rect(self, move_id: str, top: int) -> pygame.Rect | None:
        """Where a move's slot is drawn (the tutorial lights it), when its row is in view."""
        spot = self.find(move_id)
        if spot is None:
            return None
        r, c = spot
        widths = self._widths(self.rows[r], r == self.row)
        y = self._row_y(r, top)
        return pygame.Rect(_LEFT + sum(widths[:c]), y - (SLOT_ROW - 8) // 2, widths[c] + 1, SLOT_ROW + 1)

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the screen in ``window``: three rows of slots, then the help lines."""
        draw_window(surface, window)
        top = window.top
        first = self._first_row()
        for offset, row in enumerate(self.rows[first:first + VISIBLE_ROWS]):
            index = first + offset
            y = self._row_y(index, top)
            if row.tier is None:
                color = ColorSettings.GRAY
            else:
                color = BattleStageSettings.COLOR_MANA if self.mana >= row.tier else ColorSettings.GRAY
            if row.label:
                kit.text(surface, row.label, window.left + 14, y, color)
            on_row = index == self.row
            widths = self._widths(row, on_row)
            x = _LEFT
            for col, move_id in enumerate(row.cells[:GRID_COLUMNS]):
                move = self.by_id.get(move_id) if move_id else None
                expanded = on_row and col == self.col and move is not None
                label = ""
                if expanded:
                    full = move["name"]
                    label = full if kit.width(full) + 16 <= widths[col] else short_move_name(move)
                tint = tag_elements(move, self.elements) if move else None
                is_held = move_id is not None and move_id == self.held
                rect = slot_box(surface, x, y, widths[col], tint, label,
                                ColorSettings.YELLOW if is_held else ColorSettings.WHITE,
                                tag="" if expanded or not move else letters_that_fit(short_move_name(move), widths[col]))
                if is_held:
                    pygame.draw.rect(surface, ColorSettings.YELLOW, rect, 1)
                if on_row and col == self.col:
                    text_renderer.draw_pointer(surface, (rect.left + 2, rect.bottom - 5), ColorSettings.YELLOW)
                x += widths[col]
        if first > 0:
            kit.more_arrow(surface, window.left + 14, top + 3)
        if first + VISIBLE_ROWS < len(self.rows):
            kit.more_arrow(surface, window.left + 14, top + _TOP + VISIBLE_ROWS * SLOT_ROW - 2)
        for n, line in enumerate(self.help_lines()):
            kit.text(surface, line, window.left + 14, top + _HELP_Y + n * 10,
                     ColorSettings.YELLOW if self.held is not None and n == 0 else ColorSettings.WHITE)
