"""The overworld — sprite walks a tile grid, message box at the bottom.

The Layer-3 destination scene, kicked off early so it can advance in
parallel with the Layer-1 text demo / battle polish. Owns three
collaborators: a ``World`` (cell layout + active-cell pointer), an
``OverworldPlayer`` (logical position + sprite animation + held-input
polling), and a ``TextBox`` (the existing widget, reused unchanged for
the bottom message panel).

What is and is not here in Pass 1:

* **Walking, cell transitions, save/load round-trip** — yes.
* **System-menu push on Tab / START** — yes (re-uses ``MenuScene``).
* **The pond (D-525), a market stall (D-571) and its keeper (D-574)** — face them and confirm.
* **The town's buildings** stand over the tiles and block; walking up into
  a door goes inside. A nap in Kailo's bed heals the party, as the pond does,
  and moves the date on a day (Frankie, 10/25); neither wakes the knocked out
  (Frankie, 10/26).
* **The place pop-up** (Frankie, 10/25): walking from one place into another
  (``systems/places.py``) shows its name in a small box at the top for a
  moment; walking out of his house after a nap, the date under it.
* **People with lines** say them when talked to (Melia, the villagers).
  Two villagers spar in town; standing next to one, facing them, for 30
  seconds with nothing pressed makes Kailo stronger and faster, once.
* **Saving** is only at an Akua totem (Frankie, 10/26): the party prays,
  the fallen get back up, and the game asks to save; YES opens the three
  slots. The menu has no Save.
* **Monsters on the map** (D-576): touching one starts its fight; no
  random encounters.
* **The field tools on Y** (Frankie, 10/26 to 10/28): a tap uses the tool
  set, holding Y opens the tool wheel (``ui/tool_wheel.py``). The ko'i chops
  a tree in the woods: ten chops fell it for ten wood and leave a stump, five
  more clear the stump for five more; not a border tree holding the room's
  edge, nor any in town. Each chop is a swing he stands still through, and
  the tree shakes. Y on anything a tool cannot work plays the "can't" sound.
  Monsters keep coming while he chops.
* **The demo's story** (the demo line in ``game/answers.md``): a new game
  opens on the taro patch scene; the Great Boar beaten, it is night; at
  night Kailo gives Melia the tusk, and walking into the chief's room then,
  Hina asks if they are ready for the wake, which ends the demo on
  TO BE CONTINUED. The scenes play over the field (``core/story.py``), acted out by
  the walking sprites where the script has stage directions
  (``core/staging.py``), the speaker's face beside their words; a scene
  can fade the screen to black and back, and wait a moment.
* **NPCs, dialogue triggers, signs, warp tiles** — Pass 2.
* **Animated walk cycle, real sprite art** — Pass 2.

The cell area draws one 16 pixel picture per tile, chosen by the cell
char (``OverworldSettings.TILE_PICTURES``), from Mini World Sprites.
Without the pictures a flat colour per char stands in.

See [docs/design/overworld.md](../../docs/design/overworld.md) for the
full design rationale.
"""

from __future__ import annotations

import os
import random
import time
from typing import TYPE_CHECKING

import pygame

from core.stats import hp_keeping_share
from core import generated, lore
from core.scene import Scene
from core.overworld_cells import BUILDINGS, FIELD_MONSTERS, INSIDE_ROW, PEOPLE, room_offset, warps
from core.shared import by_id, short_name
from core.staging import Stage
from core.story import LOSE, StoryRunner, cast, party_flag
from core.world import World, _in_village
from systems import world_map
from systems import bounties, daytime, dig, drops, field_respawn, fishing, garden, hens, lontar_talk, meal_orders, places, records, sailing, seaweed, stew, swim, tools, trees
from systems.passives import join_line
from entities.field_monster import FieldMonster
from entities.overworld_player import OverworldPlayer
from entities.walker_art import walker_frames
from utils import sprite_files
from settings import (
    ClockSettings,
    AssetPaths,
    AudioSettings,
    BankSettings,
    BattleSettings,
    LanuSettings,
    SchoolSettings,
    BackgroundSettings,
    ColorSettings,
    CraftSettings,
    DigSettings,
    FieldMonsterSettings,
    FieldStrikeSettings,
    FishingSettings,
    FontSettings,
    GardenSettings,
    DropSettings,
    GridSettings,
    HenSettings,
    ItemSettings,
    KaigaraSettings,
    MapSettings,
    OrderSettings,
    OverworldPlayerSettings,
    OverworldSettings,
    PlaceSettings,
    SailingSettings,
    StewSettings,
    StorySettings,
    SwimSettings,
    ToolSettings,
    TownSettings,
    TutorialSettings,
    UISettings,
)
from ui import canopy, edges, fight_swirl, input_map, notices, outlines, pier, shadows, shore, text_renderer, walls
from ui.text_box import TextBox, draw_continue_marker
from ui.reel_meter import render_reel
from ui.tool_wheel import ToolWheel, render_corner
from ui.window import draw_window
from utils.backgrounds import render_scene_background

if TYPE_CHECKING:
    from main import GameManager


# Stand-in colour per cell char, used when the tile pictures are missing.
_TILE_COLORS: dict[str, tuple[int, int, int]] = {
    OverworldSettings.FLOOR_CHAR: ColorSettings.OVERWORLD_FLOOR,
    OverworldSettings.WALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.STUMP_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.CANOPY_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.WATER_CHAR: ColorSettings.OVERWORLD_WATER,
    OverworldSettings.SPRING_CHAR: ColorSettings.OVERWORLD_SPRING,
    OverworldSettings.FRESH_CHAR: ColorSettings.OVERWORLD_FRESH,
    OverworldSettings.SAND_CHAR: ColorSettings.OVERWORLD_SAND,
    OverworldSettings.PATH_CHAR: ColorSettings.OVERWORLD_SAND,
    OverworldSettings.STALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.MAT_CHAR: ColorSettings.OVERWORLD_SAND,
    OverworldSettings.INSIDE_WALL_CHAR: ColorSettings.OVERWORLD_WALL,
    OverworldSettings.VOID_CHAR: ColorSettings.BLACK,
    OverworldSettings.PIER_CHAR: ColorSettings.OVERWORLD_WALL,
    **{char: ColorSettings.OVERWORLD_SAND for char in OverworldSettings.STAIRS_CHARS},
}

# Tile pictures by cell char, loaded on first use. ``{}`` means the
# pictures were looked for and are missing.
_TILES: dict[str, list[pygame.Surface]] | None = None
_HOLE: pygame.Surface | bool | None = None
_PUNCH_SHEET: pygame.Surface | None = None   # Kailo's punch frames, loaded on first use
_CHOP_SHEET: pygame.Surface | None = None    # Kailo's chop frames (chop.png), loaded on first use


def _hole_picture() -> pygame.Surface | None:
    """The hole a dig leaves on sand, or None when its picture is missing."""
    global _HOLE
    if _HOLE is None:
        path = os.path.join(AssetPaths.TILES_DIR, DigSettings.HOLE_PICTURE)
        _HOLE = pygame.image.load(path).convert_alpha() if os.path.exists(path) else False
    return _HOLE or None


def _tiles() -> dict[str, list[pygame.Surface]]:
    """Return the choices of 16 pixel picture for each cell char."""
    global _TILES
    if _TILES is not None:
        return _TILES
    _TILES = {}
    size = GridSettings.TILE_SIZE
    sheets: dict[str, pygame.Surface] = {}
    for char, choices in OverworldSettings.TILE_PICTURES.items():
        pictures = []
        for name, index in choices:
            if name not in sheets:
                path = os.path.join(AssetPaths.TILES_DIR, name)
                if not os.path.exists(path):
                    _TILES = {}
                    return _TILES
                sheets[name] = pygame.image.load(path).convert_alpha()
            sheet = sheets[name]
            pictures.append(sheet.subsurface(pygame.Rect(
                (index * size) % sheet.get_width(),
                (index * size) // sheet.get_width() * size,
                size, size,
            )))
        if char in OverworldSettings.WATER_COLORS:
            # Fresh water and a spring are the sea's picture in their own color (Frankie, 11/16).
            pictures = []
            for _ in choices:
                flat = pygame.Surface((size, size), pygame.SRCALPHA)
                flat.fill(OverworldSettings.WATER_COLORS[char])
                pictures.append(flat)
        _TILES[char] = pictures
    return _TILES


# Each person's walk sheet by name, loaded on first use; None if missing.
_PEOPLE: dict[str, pygame.Surface | None] = {}


def _person_sheet(name: str, file: str = "{}-Walk.png") -> pygame.Surface | None:
    """Return the Ninja Adventure walk sheet ``<name>-Walk.png``, or another of
    theirs (``file``: the Kaigara Kame's sitting one), or None."""
    file = file.format(name)
    if file not in _PEOPLE:
        path = sprite_files.sheet_path(file[:-4])
        _PEOPLE[file] = pygame.image.load(path).convert_alpha() if os.path.exists(path) else None
    return _PEOPLE[file]


# Each building's picture by kind, loaded on first use; None if missing.
_BUILDINGS: dict[tuple[str, bool], pygame.Surface | None] = {}

# Which picture of the Meialana is drawn (Frankie, 11/26): "whole" with its faded stripes, "wrecked" from the pirates'
# night until it is mended, then "mended", its stripes painted fresh. The field sets it from the party's flags before
# it draws a room (``boat_state``).
_BOAT_STATE = {"meialana": "whole"}


def boat_state(flags: dict) -> str:
    """The Meialana's picture for these flags: whole, wrecked or mended (Frankie, 11/26)."""
    if flags.get(SailingSettings.READY_FLAG) or flags.get(StorySettings.BOAT_FIXED):
        return "mended"
    return "wrecked" if flags.get(StorySettings.AFTER_JUMP_FLAG) else "whole"


def _bob(kind: str) -> int:
    """How far down a picture bobbing on the water is drawn now: the whole Meialana rises and settles a pixel
    (Frankie, 11/26); wrecked, it lies still."""
    if kind not in OverworldSettings.BOB or _BOAT_STATE.get(kind) == "wrecked":
        return 0
    pixels, seconds = OverworldSettings.BOB[kind]
    return pixels if (pygame.time.get_ticks() // int(seconds * 1000)) % 2 else 0


def building_picture(kind: str, opened: bool = False) -> pygame.Surface | None:
    """Return the picture for a kind of building (``OverworldSettings.BUILDINGS``), or None.

    ``opened`` gives an opened chest's picture, ``OverworldSettings.CHEST_OPEN``.
    """
    state = _BOAT_STATE.get(kind, "whole")
    key = (kind, opened) if state == "whole" else (kind, state)
    if key not in _BUILDINGS:
        fruiting = kind.endswith("+fruit")           # a tree showing its fruit: ``<building key>+fruit``
        base = kind[:-len("+fruit")] if fruiting else kind
        name = OverworldSettings.BUILDINGS[base][0]
        if fruiting:
            name = OverworldSettings.TREE_FRUIT_FILES[OverworldSettings.TREE_BUILDINGS[base]]
        if opened:
            name = OverworldSettings.SHRUB_BARE if kind == "shrub" else OverworldSettings.CHEST_OPEN
        if state != "whole":
            name = OverworldSettings.BOAT_PICTURES[state]
        path = os.path.join(AssetPaths.BUILDINGS_DIR, name)
        _BUILDINGS[key] = pygame.image.load(path).convert_alpha() if os.path.exists(path) else None
    return _BUILDINGS[key]


_STUMPS: dict = {}


def _stump_picture(size: int) -> pygame.Surface:
    """One of the three stumps (thin, medium, wide) from the strip."""
    if not _STUMPS:
        sheet = pygame.image.load(os.path.join(AssetPaths.TILES_DIR, "trees", "stumps.png")).convert_alpha()
        for n in range(3):
            _STUMPS[n] = sheet.subsurface((n * 16, 0, 16, 16))
    return _STUMPS[size]


def chest_flag(cell_name: str, chest: dict) -> str:
    """The party flag that marks a chest as opened, kept in the save."""
    return f"chest:{cell_name}:{chest['col']}:{chest['row']}"


def chest_items(chest: dict, rng: random.Random | None = None) -> list[str]:
    """What a chest holds, picked now: its ``item``, its ``also`` list, then
    ``random`` from ``ItemSettings.CHEST_RANDOM``, once or as many times as
    ``picks`` (low, high) rolls. "pule" is ``ItemSettings.CHEST_PULE`` pule.

    A chest with a ``tier`` (Frankie, 11/15) holds what ``tier_picks`` rolls instead.
    """
    from settings import ItemSettings

    rng = rng or random
    if chest.get("tier"):
        return tier_picks(chest["tier"], rng)
    if not (chest.get("item") or chest.get("also") or chest.get("random")):
        # A chest painted with nothing set is never empty (Frankie, 11/16): random goodies, as a tier 2.
        return tier_picks(2, rng)
    items = ([chest["item"]] if chest.get("item") else []) + list(chest.get("also", []))
    if chest.get("random"):
        low, high = chest.get("picks", (1, 1))
        items += [rng.choice(ItemSettings.CHEST_RANDOM[chest["random"]]) for _ in range(rng.randint(low, high))]
    return items


def tier_picks(tier: int, rng: random.Random | None = None) -> list[str]:
    """What a chest of ``tier`` (1 to 5) holds (Frankie, 11/15; numbers Claude's, ``ItemSettings.CHEST_*``).

    The tier sets how many picks. Each pick is an element item of the shops', or an uncommon thing, by the
    tier's chances, and otherwise a common goodie drawn by the tier's weights ("pule" is a pick like another).
    """
    from settings import ItemSettings as S

    rng = rng or random
    items = []
    for _ in range(rng.randint(*S.CHEST_PICKS[tier])):
        roll = rng.random()
        if roll < S.CHEST_ELEMENT_CHANCE[tier]:
            items.append(rng.choice(S.CHEST_ELEMENTS))
        elif roll < S.CHEST_ELEMENT_CHANCE[tier] + S.CHEST_UNCOMMON_CHANCE[tier]:
            items.append(rng.choice(S.CHEST_UNCOMMON))
        else:
            names = list(S.CHEST_GOODIE_WEIGHTS)
            items.append(rng.choices(names, [S.CHEST_GOODIE_WEIGHTS[n][tier - 1] for n in names])[0])
    return items


def draw_tile(surface: pygame.Surface, grid, col: int, row: int, at: tuple[int, int],
              tiles: dict[str, list[pygame.Surface]], covered=()) -> None:
    """Draw one tile's picture at ``at``: water with its shore, an inside wall,
    the pier over the water, or the tile's own picture over what is under it.

    ``covered`` is every tile under a building: a wall tile there is only its floor, or the old palm picture
    would show through the see-through parts of the building's picture (around a roof's peak)."""
    char = grid[row][col]
    if char in shore.WATER:
        surface.blit(_pick(tiles.get(char, tiles[OverworldSettings.FLOOR_CHAR]), col, row), at)
        edges.draw_shallows(surface, grid, col, row, at)
        under_pier = pier.front(grid, col, row)
        if under_pier is not None:
            surface.blit(under_pier, at)
        return
    if char in walls.CHARS:
        surface.blit(walls.tile(grid, col, row), at)
        return
    if char == pier.CHAR:
        surface.blit(_pick(tiles[OverworldSettings.WATER_CHAR], col, row), at)
        edges.draw_shallows(surface, grid, col, row, at)
        surface.blit(pier.tile(grid, col, row), at)
        return
    under = OverworldSettings.TILE_UNDER.get(char)
    if under is not None:
        surface.blit(_pick(tiles[under], col, row), at)
        edges.draw_bank(surface, grid, col, row, at)
    if canopy.is_canopy(grid, col, row):
        # The wall round a room, and painted canopy, is a dark canopy, not palms, so every palm drawn can be chopped (Frankie, 11/13).
        picture = canopy.tile(grid, col, row)
        if picture is not None:
            surface.blit(picture, at)
            return
    if char == OverworldSettings.WALL_CHAR and (col, row) in covered:
        return  # the floor under it is already drawn
    surface.blit(_pick(tiles.get(char, tiles[OverworldSettings.FLOOR_CHAR]), col, row), at)
    if char == OverworldSettings.FLOOR_CHAR:
        edges.draw_bank(surface, grid, col, row, at)
    edges.draw(surface, grid, col, row, at)


def draw_sparkle(surface: pygame.Surface, col: int, row: int, at: tuple[int, int], ticks: int) -> None:
    """A healing spring's twinkle (Frankie, 11/12): a few single pixels that light and fade in turn, so it
    reads apart from plain water. Where they sit comes from the tile, so every spring twinkles its own way."""
    tile = GridSettings.TILE_SIZE
    for index in range(OverworldSettings.SPARKLE_COUNT):
        seed = (col * 73856093) ^ (row * 19349663) ^ (index * 83492791)
        phase = (ticks + (seed % 1000) * OverworldSettings.SPARKLE_MS // 1000) % OverworldSettings.SPARKLE_MS
        if phase >= OverworldSettings.SPARKLE_MS // 2:
            continue
        # The spot moves each time it lights, so it twinkles around rather than sitting still.
        round_ = (ticks + (seed % 1000) * OverworldSettings.SPARKLE_MS // 1000) // OverworldSettings.SPARKLE_MS
        spot = (seed >> 3) + round_ * 7919
        bright = phase < OverworldSettings.SPARKLE_MS // 4
        surface.set_at((at[0] + 1 + spot % (tile - 2), at[1] + 1 + (spot // 16) % (tile - 2)),
                       ColorSettings.SPARKLE_BRIGHT if bright else ColorSettings.SPARKLE_DIM)


def _overhang(kind: str, picture: pygame.Surface) -> int:
    """How far left of its tiles a picture wider than them starts, so it is centered on them:
    the totem is 20 pixels on a 16 pixel tile, and drawn from the tile's left it blocked Kailo
    off center (Frankie, 11/9)."""
    return (OverworldSettings.BUILDINGS[kind][1][0] * GridSettings.TILE_SIZE - picture.get_width()) // 2


def tree_kind(col: int, row: int, placed: dict | None = None, pool: tuple | None = None) -> str:
    """Which tree stands on the tree tile at ``(col, row)``, one of ``OverworldSettings.TREE_POOL`` (Frankie,
    11/24 night). A tree placed with a kind (``placed``, from the Workshop) is always that kind. A plain Tree is a
    random one from the pool, chosen per game: ``pool`` is ``(flags, room, seed)``, and it stays put and grows back
    as another (``systems/trees.py``). With no ``pool`` (the Workshop, which has no game) it is a pick by position.
    What it drops when chopped follows this."""
    if placed and (col, row) in placed:
        return placed[(col, row)]
    if pool is not None:
        flags, room, seed = pool
        return trees.pool_kind(flags, seed, room, col, row)
    return trees.pool_kind({}, 0, "", col, row)


def tree_tiles(grid, placed: dict | None = None, covered: set | None = None, pool: tuple | None = None) -> list:
    """Every tree on a room's tree tiles: (col, row, picture's kind) for each wall tile that is not the room's
    border (the border is canopy) and not under a building, which hides the tree there."""
    return [(col, row, OverworldSettings.TREE_PICTURES[tree_kind(col, row, placed, pool)]
             + ("+fruit" if pool is not None and trees.has_fruit(pool[2], pool[1], col, row, pool[0]) else ""))
            for row, cells in enumerate(grid) for col, char in enumerate(cells)
            if char == OverworldSettings.WALL_CHAR and not canopy.is_canopy(grid, col, row)
            and (col, row) not in (covered or ())]


def draw_tree(surface: pygame.Surface, col: int, row: int, kind: str = "breadfruit_tree", x0: int = 0, y0: int = 0,
              nudge: int = 0) -> None:
    """One big tree on a palm's tile, standing on its bottom edge. Every other tree stands a pixel off, so a row
    of them is not stamped."""
    picture = building_picture(kind)
    if picture is None:
        return
    tile = GridSettings.TILE_SIZE
    shift = ((col * 7 + row * 3) % 3) - 1
    surface.blit(picture, (x0 + col * tile + (tile - picture.get_width()) // 2 + shift + nudge,
                           y0 + (row + 1) * tile - picture.get_height() + (0 if (col + row) % 2 else 1)))


def draw_rising(surface: pygame.Surface, building: dict, x0: int = 0, y0: int = 0) -> None:
    """Draw again the part of a building's picture above its own tiles, over
    whoever stands behind it: the Meialana's sail, a totem's top (10/27), and a house's top row,
    walked behind (``BEHIND_ROWS``, 11/26)."""
    picture = building_picture(building["kind"])
    if picture is None:
        return
    tile_size = GridSettings.TILE_SIZE
    height = OverworldSettings.BUILDINGS[building["kind"]][1][1]
    sink = OverworldSettings.SINK.get(building["kind"], 0)
    rising = picture.get_height() - height * tile_size - sink
    rising += OverworldSettings.BEHIND_ROWS.get(building["kind"], 0) * tile_size
    if rising > 0:
        top = y0 + (building["row"] + height) * tile_size + sink - picture.get_height() + _bob(building["kind"])
        left = x0 + building["col"] * tile_size + _overhang(building["kind"], picture)
        surface.blit(picture, (left, top), pygame.Rect(0, 0, picture.get_width(), rising))


def draw_sunk(surface: pygame.Surface, grid, building: dict, x0: int = 0, y0: int = 0) -> None:
    """Draw again the pier's planks over the bottom of a building sunk below its tiles
    (``OverworldSettings.SINK``), so it is tucked behind them."""
    if not OverworldSettings.SINK.get(building["kind"]):
        return
    tile_size = GridSettings.TILE_SIZE
    width, height = OverworldSettings.BUILDINGS[building["kind"]][1]
    row = building["row"] + height
    if row >= len(grid):
        return
    for col in range(building["col"], building["col"] + width):
        if grid[row][col] == pier.CHAR:
            surface.blit(pier.tile(grid, col, row), (x0 + col * tile_size, y0 + row * tile_size))


def draw_building(surface: pygame.Surface, building: dict, x0: int = 0, y0: int = 0,
                  opened: bool = False) -> None:
    """Draw a building at its own size on its tiles, standing on their bottom edge.

    ``opened`` draws a chest open (Frankie, 10/25).
    """
    tile_size = GridSettings.TILE_SIZE
    width, height = OverworldSettings.BUILDINGS[building["kind"]][1]
    picture = building_picture(building["kind"], opened and building["kind"] in ("chest", "shrub"))
    left, bottom = x0 + building["col"] * tile_size, y0 + (building["row"] + height) * tile_size
    if picture is None:
        pygame.draw.rect(surface, ColorSettings.OVERWORLD_WALL,
                         (left, bottom - height * tile_size, width * tile_size, height * tile_size))
        return
    surface.blit(picture, (left + _overhang(building["kind"], picture),
                           bottom + OverworldSettings.SINK.get(building["kind"], 0) - picture.get_height()
                           + _bob(building["kind"])))


# Each plant's four garden pictures, loaded on first use; None if missing.
_PATCH_SHEETS: dict = {}


def _patch_sheet(plant: str) -> pygame.Surface | None:
    """Return a plant's strip of four pictures (GardenSettings.PICTURES), or None."""
    if plant not in _PATCH_SHEETS:
        path = os.path.join(AssetPaths.TILES_DIR, GardenSettings.PICTURES.get(plant, ""))
        sheet = pygame.image.load(path).convert_alpha() if os.path.isfile(path) else None
        if plant in GardenSettings.TARO_PLANTS:
            sheet = _tiny_farm_strip() or sheet
        _PATCH_SHEETS[plant] = sheet
    return _PATCH_SHEETS[plant]


def _tiny_farm_strip() -> pygame.Surface | None:
    """Tiny Farm's dirt row bare, then its purple turnip growing on the dirt: four pictures in a row, or None."""
    paths = [os.path.join(sprite_files.SPRITES_DIR, name) for name in (GardenSettings.SOIL, *GardenSettings.TARO_PARTS)]
    if not all(os.path.isfile(p) for p in paths):
        return None
    size = GridSettings.TILE_SIZE
    soil, *plants = (pygame.image.load(p).convert_alpha() for p in paths)
    strip = pygame.Surface((size * 4, size), pygame.SRCALPHA)
    strip.blit(soil, (0, 0))
    for i, plant in enumerate(plants, start=1):
        strip.blit(soil, (i * size, 0))
        strip.blit(plant, (i * size, 0))
    return strip


# The dirt's top edge (Frankie, 11/19: the mound has rounded corners). Rows above _DIRT_TOP are the soil
# picture's grass strip, drawn see-through so the room's own grass shows there (Frankie, 11/24).
_DIRT_TOP = 4
_ROUND = ((0, 0), (1, 0), (0, 1))   # the pixels knocked out at a corner, counted in from it
_PATCH_PICTURES: dict = {}


def _taro_patch_picture(stage: int, joined: tuple) -> pygame.Surface | None:
    """One taro patch tile as drawn: its soil with corners rounded where no other patch joins it.

    ``joined`` is (up, down, left, right), whether a patch sits on that side. A corner is rounded
    only when both sides that meet there are open, so a run of patches reads as one mound.
    Joined above or below, the soil's grass strip and shaded rim give way to plain dirt.
    Returns None when the Tiny Farm pictures are missing.
    """
    key = (stage, joined)
    if key not in _PATCH_PICTURES:
        paths = [os.path.join(sprite_files.SPRITES_DIR, name) for name in (GardenSettings.SOIL, *GardenSettings.TARO_PARTS)]
        if not all(os.path.isfile(p) for p in paths):
            _PATCH_PICTURES[key] = None
            return None
        size = GridSettings.TILE_SIZE
        soil, *plants = (pygame.image.load(p).convert_alpha() for p in paths)
        up, down, left, right = joined
        tile = soil.copy()
        if up:
            tile.blit(soil, (0, 0), (0, 6, size, 6))
        if down:
            tile.blit(soil, (0, size - 4), (0, 6, size, 4))
        top = 0 if up else _DIRT_TOP
        if not up:
            # The soil picture's own grass strip is see-through, so the room's grass shows above the mound
            # and always matches it (Frankie, 11/24: the drawn strip stopped matching the textured grass).
            tile.fill((0, 0, 0, 0), (0, 0, size, _DIRT_TOP))
        for corner_x, corner_y, open_x, open_y, fill in (
            (0, top, not left, not up, (0, 0, 0, 0)), (size - 1, top, not right, not up, (0, 0, 0, 0)),
            (0, size - 1, not left, not down, (0, 0, 0, 0)), (size - 1, size - 1, not right, not down, (0, 0, 0, 0)),
        ):
            if open_x and open_y:
                step_x, step_y = (1 if corner_x == 0 else -1), (1 if corner_y == top else -1)
                for dx, dy in _ROUND:
                    tile.set_at((corner_x + dx * step_x, corner_y + dy * step_y), fill)
        picture = pygame.Surface((size, size), pygame.SRCALPHA)
        picture.blit(tile, (0, 0))
        if stage > 0:
            picture.blit(plants[stage - 1], (0, 0))
        _PATCH_PICTURES[key] = picture
    return _PATCH_PICTURES[key]


def _boss_flag_for(cell_name: str, spot: dict) -> str:
    """The party flag that marks a boss on the map as beaten for good."""
    return f"field_boss:{cell_name}:{spot['kind']}"


def _boss_flag(monster: FieldMonster) -> str:
    """The flag for ``monster``, a boss, in the cell it stands in."""
    for cell_name, spots in FIELD_MONSTERS.items():
        if monster.spot in spots:
            return _boss_flag_for(cell_name, monster.spot)
    return f"field_boss::{monster.spot['kind']}"


def _pick(pictures: list[pygame.Surface], col: int, row: int) -> pygame.Surface:
    """Pick one of ``pictures`` by tile position, the same every time."""
    return pictures[(col * 7 + row * 13 + col * row) % len(pictures)]


def palm_has_coconuts(col: int, row: int) -> bool:
    """Whether the palm at ``(col, row)`` is drawn with coconuts (Frankie, 11/12): the same
    pick the picture is drawn by, so the tree that shows coconuts is the one that gives them."""
    choices = OverworldSettings.TILE_PICTURES[OverworldSettings.WALL_CHAR]
    return choices[(col * 7 + row * 13 + col * row) % len(choices)][1] in OverworldSettings.COCONUT_PALMS


def start_in_room(gm: "GameManager", name: str | None, col: int | None = None,
                  row: int | None = None, checkpoint: str | None = None) -> bool:
    """Skip the title: a fresh party standing in room ``name``, on ``(col, row)``.

    How the Workshop's Play button starts the game (``main.py --room``).
    With ``checkpoint``, the party and the story are that checkpoint's
    (core/save.py) instead of a fresh party's, and without ``name`` it
    starts where the checkpoint stood. Returns False, leaving the title
    up, when there is no such room or checkpoint.
    """
    # Local import: the title imports this module.
    from core import save
    from core.overworld_cells import WORLD_LAYOUT
    from core.scenes.save_slot_scene import resume
    from core.scenes.title_scene import build_default_party

    pos = next((pos for pos, who in WORLD_LAYOUT.items() if who == name), None)
    if name is not None and pos is None:
        return False
    if checkpoint is not None:
        try:
            data = save.load_checkpoint(checkpoint)
        except (OSError, ValueError):
            return False
        resume(gm, data)
        scene = gm.scene_stack.top
    else:
        gm.party = build_default_party()
        scene = OverworldScene(gm)
        gm.scene_stack.replace(scene)
    if pos is not None:
        scene.world.go_to(pos)
    if col is not None and row is not None:
        scene.player.from_dict({"col": int(col), "row": int(row)})
    return True


class OverworldScene(Scene):
    """The screen-locked, cell-based overworld."""

    OPAQUE = True

    def __init__(self, gm: "GameManager") -> None:
        """Construct the overworld with its world, player, and text box.

        Args:
            gm: The host game manager. Provides audio, save, and
                cross-scene navigation routing.
        """
        super().__init__(gm)
        self.world = World()
        self.world.party_source = lambda: self.gm.party
        self.player = OverworldPlayer(gm, self.world)
        # Cell area is narrower than the screen, so size the text box
        # to the full screen width but keep the existing 160-px height.
        self.text_box = TextBox(flippable=True)
        # The monsters in the cell (D-576), placed afresh on every entry.
        self.monsters: list[FieldMonster] = []
        self._monsters_cell: tuple[int, int] | None = None
        self._was_clock_night = self._clock_night()   # for ``_turn_of_day``
        self._monsters_by_night = False   # whether the monsters on the stage are the night ones
        # The monster whose fight is on, and how long until a monster
        # left standing by a fight can start another.
        self._fighting: tuple[FieldMonster, object] | None = None
        # The monsters that rushed in and joined that fight, and the catch under way (Frankie, 11/19):
        # while it lasts the party stands frozen and the monsters that see it rush in.
        self._joined: list[FieldMonster] = []
        self._rush: dict | None = None
        self._grace = 0.0
        self._grace_from = None
        # The demo is over: the words on the black screen, and the title on confirm.
        self._card: str | None = None
        # The Great Boar asks before his fight (Frankie, 10/23): the one asking,
        # whether he has asked since the party walked up, and the steps back
        # still to walk after "Go back".
        self._asking: FieldMonster | None = None
        # Whether Hina has asked about the wake since the party walked into the chief's room.
        self._wake_asked = False
        self._asked = False
        self._home_trip: str | None = None   # a way home (Frankie, 11/19): "out" fading to black, "in" fading back
        self._home_to: tuple | None = None
        # Where Kailo last bumped (room, tile, facing), so a dead end speaks once a walk-up.
        self._bumped_at: tuple | None = None
        self._walk_back: list[tuple[int, int]] = []
        # A shop pushed by a person who may join (Maika): who, and what the
        # bag held when it opened, so closing it can tell if anything was bought.
        self._joiner_shop: tuple[dict, dict] | None = None
        # What to open once the text box closes.
        self._after_text = None
        # How long B has been held over a dialogue box, and the time owed to the next box flown through.
        self._b_held = 0.0
        self._b_fly = 0.0
        self._b_last = time.monotonic()
        # When a press last closed a talk: the press right behind it opens nothing (Mark, 11/12).
        self._talk_closed = -1e9
        # The sparring villagers: how long nothing has been pressed.
        self._idle = 0.0
        # The story scene playing, the step it waits to show once the text
        # box closes, and the fight it started.
        self.story: StoryRunner | None = None
        self._story_next: dict | None = None
        self._story_fight = None
        # The scene acted out on the map, once its script names a Room.
        self.stage: Stage | None = None
        # The screen's darkness, 0 to 1, where a Fade is taking it, and a Wait's seconds left.
        self._dark = 0.0
        self._fade_to: float | None = None
        self._wait = 0.0
        # A new game opening: the field starts black and lights as the first line types.
        self._opening = False
        # The scene being skipped from the pause (skip_cutscene), None while none is.
        self.skipping: StoryRunner | None = None
        # Where the player stood last frame, to count the garden's steps.
        self._last_tile: tuple | None = None
        # What a room smaller than the screen is drawn on before it is moved to the middle.
        self._room_layer: pygame.Surface | None = None
        self._ground_layers: dict = {}   # finished tile grids, one per state (_render_cell)
        # The room this visit is in, so leaving it can send Melia home.
        self._visiting = self.world.current_cell_name
        # The room the place pop-up last looked at (None until the first frame,
        # which shows nothing), the place it was in, and the pop-up's lines and
        # seconds left.
        self._place_room: str | None = None
        self._place: str | None = None
        self.popup: list[str] | None = None
        self._popup_left = 0.0
        # Y: the tool wheel, the tree or stump being chopped (room, col, row)
        # and its chops so far, the seconds left of the swing Kailo is in, and
        # the tile shaking from the last chop with its seconds left.
        self.tool_wheel = ToolWheel()
        self._chop_at: tuple | None = None
        self._chops = 0
        self._swing = 0.0
        self._chop_total = 0.0   # the length of the chop swing under way, 0 for any other swing (the pose)
        # A field strike under way (Frankie, 11/14): see ``_field_strike``; None when idle.
        self._strike: dict | None = None
        self._strike_rest = 0.0
        self._shake: tuple | None = None
        self._drops: list = []   # what lies on the ground (``systems/drops``)
        self._shake_left = 0.0
        # Fishing (Frankie, 10/28; built small for the stew, 10/30): the line out, as
        # [where Kailo stands, seconds to the bite, seconds the bite lasts, baited], or None.
        self._line: list | None = None
        # A hooked fish being reeled in (Frankie, 11/2; ``fishing.Reel``), or None.
        self._reel: fishing.Reel | None = None
        # Digging (Frankie, 10/30): the tiles dug in this room, gone when he leaves it.
        self._dug: set = set()
        self._dug_room: str | None = None
        # Water drawn in a row, and the seconds since the last draw (Frankie, 10/28).
        self._draws = 0
        self._since_draw = 0.0
        self._rested_at: tuple | None = None  # where the party last drank at a healing spring (Frankie, 11/12)
        self._toll_stopped = False   # the toll Nuno has stopped Kailo in his lane (Frankie, 11/14)
        self._toll_battle: tuple | None = None  # the toll Nuno's fight, while it is on (Frankie, 11/12)
        self._sync_joined()

    def on_enter(self) -> None:
        """Play the room's sound, and settle the fight just over, if one was.

        The sound carries on if it is already playing (back from the
        menu). A monster beaten in its fight leaves the map, a boss for
        good, any other until ``RESPAWN_STEPS`` steps are walked or the
        party naps or drinks from a spring (Frankie, 10/28); one that was run from or lost to stays, and waits a moment
        before it can start another (D-576).
        """
        # Y let go on the screen just closed never reached here: the wheel starts shut.
        self.tool_wheel.cancel()
        # The fight settled first, so a won fight's Song is over before the room's song comes back.
        if self._story_fight is not None:
            battle, self._story_fight = self._story_fight, None
            won = battle.battle.outcome == "victory"
            if self.story.name == StorySettings.CLEARING_SCENE:
                # He was in the party for the Aghoy fight only; losing it is a plain game over (Frankie, 11/12).
                self.gm.party.remove(StorySettings.JOINER)
                if not won:
                    from core.scenes.game_over_scene import game_over  # local, as the battle does

                    self.story = None
                    game_over(self.gm)
                    return
            if self.story.name == "taro_patch" and not won:
                # Game over, since the win opens the second element slot (Frankie, 11/13; it went on before).
                from core.scenes.game_over_scene import game_over  # local, as the battle does

                self.story = None
                game_over(self.gm)
                return
            self.story.fought(won)
        if self._toll_battle is not None:
            # Beaten, the Nuno is gone for good; a loss is game over, which the fight itself starts.
            person, battle = self._toll_battle
            self._toll_battle = None
            if battle.battle.outcome == "victory":
                self.gm.party.flags[person["gone"]] = True
                self.world.go_to(self.world.current_pos)
        self._room_sound()
        self._sync_joined()
        if self._joiner_shop is not None:
            person, before = self._joiner_shop
            self._joiner_shop = None
            self._after_joiner_shop(person, before)
        if self._fighting is None:
            return
        monster, battle = self._fighting
        joined, self._joined = self._joined, []
        self._fighting = None
        if battle.battle.outcome == "victory":
            for beaten in [monster, *joined]:
                if beaten in self.monsters:
                    self.monsters.remove(beaten)
                if not beaten.spot.get("boss"):
                    # Back after RESPAWN_STEPS steps, or a nap or a spring (Frankie, 10/28).
                    spots = FIELD_MONSTERS.get(self.world.current_cell_name, [])
                    index = next((i for i, spot in enumerate(spots) if spot is beaten.spot), None)
                    if index is not None:
                        field_respawn.beat(self.gm.party, self.world.current_cell_name, index)
            if monster.spot.get("boss"):
                self.gm.party.flags[_boss_flag(monster)] = True
                # The Great Boar beaten, they talk, and it is night once the stew is made too
                # (the demo line, 10/23; the stew gates the night, Frankie, 10/30).
                self.gm.party.flags[StorySettings.BOAR_BEATEN_FLAG] = True
                # Every boar he called and the party beat is one fewer in his field from now on (Frankie, 11/12).
                self.gm.party.flags[StorySettings.BOAR_CALLS_FLAG] = battle.battle.boars_called
                gone = self._boars_called_gone(self.world.current_cell_name)
                self.monsters = [m for m in self.monsters
                                 if not any(m.spot is FIELD_MONSTERS[self.world.current_cell_name][i] for i in gone)]
                if stew.made(self.gm.party):
                    self.gm.party.flags[StorySettings.NIGHT_FLAG] = True
                self._sync_joined()
                self.begin_story(StorySettings.FALL_SCENE)
        # A breather after any fight, won too (Frankie, 10/27): the next monster
        # waits, and presses meant for the victory screen start nothing.
        self._grace = FieldMonsterSettings.GRACE_SECONDS
        # It counts down only once the party has walked off, so reading the victory screen and the
        # talk after a boss never uses it up (Mark, 11/12: a fight started the moment the screen closed).
        self._grace_from = (self.world.current_cell_name, self.player.col, self.player.row)

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        """Route one event.

        When the text box has content, confirm advances it and other
        keys fall through silently (so a held direction won't queue
        steps that fire the instant the player closes a dialogue).
        Otherwise, X (Tab) pushes the field menu; movement is
        polled inside ``player.update`` and does not go through this
        handler.

        Args:
            event: The pygame event to route.
        """
        if event.type in (pygame.KEYDOWN, pygame.JOYBUTTONDOWN, pygame.JOYHATMOTION):
            self._idle = 0.0
        if self._rush is not None:
            return   # caught: the party stands frozen, no menu and no field strike (Frankie, 11/19)
        # Holding B makes a slow line (Gajumaru's, Gen'emon's) type at the usual speed; B never fills it at once,
        # and the first time the party meets Gajumaru it does nothing to his speed (Frankie, 11/9).
        if input_map.is_cancel_up(event):
            self.text_box.hurry = False
        elif input_map.is_cancel(event):
            self.text_box.hurry = self.story is None or self.story.name != KaigaraSettings.MEET_SCENE
        # Reeling a fish in, the d-pad is the reel and nothing else answers.
        if self._reel is not None:
            self.tool_wheel.cancel()
            return
        # Mid-swing, Y does nothing: no mashing (Frankie, 10/28).
        if self._swing > 0 and (input_map.is_tool(event) or input_map.is_tool_up(event)):
            self.tool_wheel.cancel()
            return
        # Letting go of Y: a tap uses the set tool, a hold sets the one picked on the wheel.
        if input_map.is_tool_up(event):
            if self._card is not None or not self.text_box.is_done() or self.story is not None:
                self.tool_wheel.cancel()
            elif self.tool_wheel.release(self.gm.party) == "use":
                self._use_tool()
            return
        if self.tool_wheel.open:
            return
        if self._card is not None:
            if input_map.is_confirm(event):
                self.gm.return_to_title()
            return
        if not self.text_box.is_done():
            if input_map.is_textbox_flip(event):
                TextBox.flip()
            elif input_map.is_confirm(event) or input_map.is_cancel(event):
                # B reads a scene too: it fills the box, then goes on, as A does (Frankie, 11/9).
                self.text_box.advance()
                if self.text_box.is_done():
                    self._talk_closed = time.monotonic()
            return
        # The press that closed a talk counted once: one right behind it (a fast double tap) opens nothing.
        # The stamp is the computer's clock, which starts over when the computer does: a state saved
        # before a restart held a stamp in the future, and A did nothing for 18 minutes after it loaded
        # (Super Beard Bros. Episode 2, 11/15). A stamp from the future counts as long ago.
        since = time.monotonic() - self._talk_closed
        if input_map.is_confirm(event) and 0 <= since < OverworldSettings.TALK_DEAF_SECONDS:
            return
        # The story playing takes every key until its text box closes.
        if self.story is not None:
            return
        if input_map.is_l1(event) or input_map.is_r1(event):
            self._swap_walker(-1 if input_map.is_l1(event) else 1)
            return
        if input_map.is_tool(event):
            self.tool_wheel.press(self.gm.party)
            return
        # B facing water Kailo can swim jumps in (Frankie, 11/16); anywhere else it is the field strike.
        if input_map.is_strike(event) and self._can_dive():
            self._try_dive()
            return
        if input_map.is_strike(event):
            self._field_strike()
            return
        # With the line out, A does nothing: no nori picked off the sand mid-cast (Frankie, 11/4).
        if self._line is not None and input_map.is_confirm(event):
            return
        if input_map.is_confirm(event) and self._pick_up(self.player.col + self.player.facing[0],
                                                          self.player.row + self.player.facing[1]):
            return   # A facing a drop takes it, where the tile is too solid to walk onto
        if input_map.is_confirm(event) and self._faced_patch() is not None:
            self._tend(self._faced_patch())
            return
        if input_map.is_confirm(event) and self._faced_building() == "pot":
            self._open_pot()
            return
        if input_map.is_confirm(event) and self._faced_post() is not None:
            self._talk_to_post(self._faced_post())
            return
        if input_map.is_confirm(event) and self._faced_look():
            self._look(self._faced_look())
            self._banyan_told()
            # The log yard's Pōhaku does not wake on the first talk, only its lines, and Kailo can walk away;
            # touching it again (A on it) plays the lines and then wakes it (Frankie, 10/28). The warning is a
            # party flag, so it is in the save, and like a chest's flag it never resets.
            dx, dy = self.player.facing
            stone = self.world.building_at(self.player.col + dx, self.player.row + dy)
            if stone and stone.get("wakes"):
                warned = f"warned:{self.world.current_cell_name}:{stone['col']}:{stone['row']}"
                if self.gm.party.flags.get(warned):
                    self._after_text = lambda: self._wake_stone(stone)
                else:
                    self.gm.party.flags[warned] = True
            # The Meialana: after Kailo's line, cook or nap aboard (Frankie, 10/28).
            if stone and stone.get("galley"):
                self._after_text = self._boat_menu
            return
        if input_map.is_confirm(event) and self._faced_building() == KaigaraSettings.TABLE:
            self._talk_to_kame()
            return
        if input_map.is_confirm(event) and self._faced_building() in ("chest", "ground_taro"):
            self._open_chest()
            return
        if input_map.is_confirm(event) and self._faced_building() == "shrub":
            dx, dy = self.player.facing
            shrub = self.world.building_at(self.player.col + dx, self.player.row + dy)
            self.gm.audio.play("menu_select")
            self.text_box.push(garden.pick_shrub(self.gm.party, self.world.current_cell_name, shrub))
            return
        # An Akua totem: pray, the fallen get up, then save (Frankie, 10/26).
        if input_map.is_confirm(event) and self._faced_building() == "totem":
            self._pray()
            return
        if input_map.is_confirm(event) and self._facing_shut_door():
            self._say_shut_door()
            return
        # Kailo's bed in his house: a nap rests the party (Frankie, 10/23).
        # Anyone else's, Hina scolds (Frankie, 10/25).
        if input_map.is_confirm(event) and self._faced_building() == "bed":
            dx, dy = self.player.facing
            bed = self.world.building_at(self.player.col + dx, self.player.row + dy)
            if bed.get("inn"):
                self._ask_inn()
            elif bed.get("owner") == TownSettings.OWN_BED:
                self._ask_nap()
            else:
                self._not_your_bed(bed)
            return
        # Facing the pond, confirm rests there; facing a stall, it opens
        # the shop; on empty ground it does nothing (X opens the menu).
        if input_map.is_confirm(event) and self._facing(OverworldSettings.SPRING_CHAR):
            self._spring()
            return
        # Water (Frankie, 11/16): in it, A does nothing more. From the shore A scoops fresh water into the bag
        # (Frankie, 10/28) or looks for nori in the sea (10/29), and B jumps in.
        if input_map.is_confirm(event) and self.player.swimming:
            return
        if input_map.is_confirm(event) and self._facing(OverworldSettings.FRESH_CHAR):
            self._scoop_water()
            return
        if input_map.is_confirm(event) and self._facing(OverworldSettings.WATER_CHAR):
            notices.post_notice(seaweed.search(self.gm.party))
            return
        if input_map.is_confirm(event) and (self._facing(OverworldSettings.STALL_CHAR)
                                            or self._faced_building() in OverworldSettings.SHOP_BUILDINGS
                                            or self._faced_building() == "sign"):
            # A stall in the clearing is Maika's, digging: talking at it plays his scene (Frankie, 11/15).
            digger = next((p for p in self.world.people if p.get("scene")), None)
            if digger is not None:
                self.begin_story(digger["scene"])
                return
            # A stall is its keeper's: whoever in the room keeps a shop.
            keeper = next((p for p in self.world.people if p.get("shop")), None)
            away = next((p for p in PEOPLE.get(self.world.current_cell_name, [])
                         if p.get("shop") and not p.get("joins")), None)
            if keeper is not None:
                self._met(keeper)
            if keeper is None and away is not None and self.is_night():
                self._read_sign(away["shop"])
            elif keeper is None and away is not None and self._shop_shut(away["shop"]):
                pass   # the Grocer after dark: nobody behind it (Frankie, 11/20)
            elif keeper is not None and keeper.get("joins"):
                self._talk_to_joiner(keeper)
            elif keeper is not None:
                self._open_shop(keeper["shop"])
            else:
                self._joined_keeper_shop()
            return
        # The one left on the shore while Kailo swims: talking to them gathers the party (Frankie, 11/16).
        if input_map.is_confirm(event) and self._faced_person().get("party_rest"):
            self._gather_party(self._faced_person())
            return
        # A hen: her egg, if she has one (Frankie, 10/28).
        if input_map.is_confirm(event) and self._faced_person().get("hen"):
            notices.post_notice(hens.collect(self.gm.party, self._person_key(self._faced_person())))
            return
        # Whoever Kailo talks to turns to face him (Frankie, 10/23).
        was_facing = None
        if input_map.is_confirm(event) and self._faced_person():
            was_facing = self._turn_to_player(self._faced_person())
            self._met(self._faced_person())
        if input_map.is_confirm(event) and self._faced_person().get("night") and self.is_night():
            self._talk_at_night(self._faced_person())
            return
        # The toll Nuno on his bridge (Frankie, 11/12): pay, fight, or not now.
        if input_map.is_confirm(event) and self._faced_person().get("toll"):
            self._talk_toll(self._faced_person())
            return
        # An innkeeper: her line, then the night's price (Kupulau's inn, Frankie, 11/3).
        # One with a ``menu`` (the Crossroads Inn's) offers the night as a row of it instead.
        if input_map.is_confirm(event) and self._faced_person().get("inn") and not self._faced_person().get("menu"):
            person = self._faced_person()
            self._take_turn(person, "day", person["lines"])
            self._after_text = lambda: self._ask_inn(person)
            return
        # Ama and the Old Rod (Frankie, 11/17): the hint, the fishing lesson, then swimming.
        # Ama talks first, then shows his menu (Frankie, 11/20).
        if input_map.is_confirm(event) and self._faced_person().get("gift") and self._faced_person().get("menu")                 and self.gm.party:
            self._talk_ama(self._faced_person())
            return
        # A keeper who does more than sell (Frankie, 11/3): Ama in his Bait & Tackle, the
        # priest in Kulaiwi's temple. Their ``menu`` asks what Kailo wants, each row an action.
        if input_map.is_confirm(event) and self._faced_person().get("menu"):
            person = self._faced_person()
            # The first talk with Ama goes straight into his ramble, then his menu; the second plays the
            # rod (above); every talk after that opens his menu (Frankie, 11/12).
            first = person.get("gift", {}).get("when")
            if first and self.gm.party and not self.gm.party.flags.get(first) \
                    and not self.gm.party.flags.get(StorySettings.AFTER_JUMP_FLAG):
                self._say_lines(person)
                self._after_text = lambda: self._keeper_menu(person)
                return
            # A keeper who also asks for a dish (Nene, 11/15): with it in the bag the trade comes first.
            request = person.get("request")
            if request and self.gm.party and not self.gm.party.flags.get(request["flag"])                     and self.gm.party.inventory.get(request["wants"], 0) > 0:
                self._talk_requester(person, request)
                return
            self._keeper_menu(person)
            return
        # Ama and the boat, the morning after the jump (Frankie, 10/28 and 10/31).
        if (input_map.is_confirm(event) and self._faced_person().get("boat") and self.gm.party
                and self.gm.party.flags.get(StorySettings.AFTER_JUMP_FLAG)):
            self._talk_ama_boat(self._faced_person()["speaker"])
            return
        # Someone who asks for a dish and gives something for it (the widow, Frankie, 10/30).
        request = self._faced_person().get("request") if input_map.is_confirm(event) else None
        if request and self.gm.party:
            self._talk_requester(self._faced_person(), request)
            return
        # Noelani, while the stew is wanted: the quest (Frankie, 10/30).
        if input_map.is_confirm(event) and self._faced_person().get("stew") and self.gm.party                 and self.gm.party.flags.get(StewSettings.QUEST_FLAG) and not self.is_night() \
                and not self.gm.party.flags.get(StorySettings.AFTER_JUMP_FLAG):
            self._talk_noelani(self._faced_person())
            return
        # Melia takes the tusk by day too, the first talk with it in the bag (Frankie, 11/5).
        if input_map.is_confirm(event) and self._faced_person().get("tusk") and self.gm.party \
                and self._tusk_due(self._faced_person()):
            self.begin_story(StorySettings.TUSK_SCENE)
            return
        # After the jump she still holds Kailo's pule (Frankie, 11/5: she would not give it back):
        # her morning line, then leave or take some.
        if input_map.is_confirm(event) and self._faced_person().get("stew") and self.gm.party \
                and self.gm.party.flags.get(StorySettings.AFTER_JUMP_FLAG) and not self.is_night():
            self._say_lines(self._faced_person())
            if self._after_text is None:
                self._after_text = self._noelani_bank
            return
        # Hina at home: talking to her plays her scene, and she joins (Frankie, 10/23).
        if input_map.is_confirm(event) and self._faced_person().get("scene"):
            self.begin_story(self._faced_person()["scene"])
            return
        if input_map.is_confirm(event) and self._faced_person().get("joins"):
            self._talk_to_joiner(self._faced_person())
            return
        if input_map.is_confirm(event) and self._faced_person().get("sister"):
            self._talk_to_sister(self._faced_person())
            return
        # The Lanu sage: once all five posts are watered, Hina's Revive, unless the temple's
        # priest sold it first (Frankie, 11/3, changed 11/4). Short of five, he says how many are left.
        if input_map.is_confirm(event) and self._faced_person().get("blessing")                 and not self.gm.party.flags.get(LanuSettings.BLESSED_FLAG)                 and not self.gm.party.flags.get(LanuSettings.GONE_FLAG):
            person = self._faced_person()
            cups = self.gm.party.flags.get(LanuSettings.CUPS_FLAG, 0)
            if cups >= LanuSettings.CUPS:
                self.gm.party.flags[LanuSettings.BLESSED_FLAG] = True
                self.gm.party.flags[LanuSettings.GONE_FLAG] = True  # the temple stops selling it
                for line in LanuSettings.BLESSING:
                    self.text_box.push(line, speaker=person["speaker"])
                self.gm.party.inventory[LanuSettings.GIFT] = 1
                self.gm.audio.play("chest_open")
                self.text_box.push(OrderSettings.RECEIVED_LINE.format(item=ItemSettings.NAMES[LanuSettings.GIFT]))
                return
            left = LanuSettings.CUPS - cups
            self.text_box.push(LanuSettings.LEFT_ONE if left == 1 else LanuSettings.LEFT_MANY.format(left=left),
                               speaker=person["speaker"])
        # A loremaster, or the boy who explains the game: his questions after his first line,
        # the one that offers them (Frankie, 10/25); his other lines take turns with it.
        if input_map.is_confirm(event) and self._faced_person().get("ask"):
            person = self._faced_person()
            if not person.get("lines"):  # no opening line: the questions open straight away
                self._ask_menu(person)
                return
            # The menu follows the first line said (the intro before it, played once, counts as one).
            first = next((i for i, line in enumerate(person["lines"]) if not isinstance(line, dict)), 0)
            # The school's people (``menu_always``) offer their questions after every line (Frankie, 11/10).
            if self._take_turn(person, "day", person["lines"]) in (0, first) or person.get("menu_always"):
                self._after_text = lambda: self._ask_menu(person)
            return
        # Melia, hiding the first time: the three of them, then one line a talk (Frankie, 10/25).
        if input_map.is_confirm(event) and self._faced_person().get("talk") and not self._faced_person().get("talked"):
            person = self._faced_person()
            person["talked"] = True
            if person.get("first") and self.gm.party:
                self.gm.party.flags[person["first"]["flag"]] = True
            for speaker, line in person["talk"]:
                self.text_box.push(line, speaker=speaker)
            return
        # The Kame in the hunters' lodge: a game of Kaigara (Frankie, 10/26).
        if input_map.is_confirm(event) and self._faced_person().get("kaigara"):
            self._talk_to_kame()
            return
        if input_map.is_confirm(event) and self._faced_person().get("lines"):
            person = self._faced_person()
            self._say_lines(person)
            if person.get("spar"):
                # A sparring villager goes back to the fight once done talking.
                self._after_text = lambda: person.__setitem__("facing", was_facing)
            return
        # The hunters' lodge's keeper: the shop or the hunts; a finished hunt is paid only under Hunts (Frankie, 11/12).
        if input_map.is_confirm(event) and self._faced_person().get("bounties"):
            self._lodge_keeper(self._faced_person())
            return
        if input_map.is_confirm(event) and self._faced_person().get("shop"):
            self._open_shop(self._faced_person()["shop"])
            return
        if input_map.is_menu(event):
            self._open_menu()
        elif input_map.is_select(event):
            self._open_map()

    def _use_tool(self) -> None:
        """A tap of Y: the set tool works what Kailo faces, or the "can't" sound (Frankie, 10/26)."""
        if self.player.swimming:
            self.gm.audio.play("cant")
            return
        if tools.current(self.gm.party) == "chop" and self._sacred_tree() is not None:
            self._scold_chop(self._sacred_tree())
            return
        if tools.current(self.gm.party) == "chop" and self._faced_tree() is not None:
            self._chop(self._faced_tree())
            return
        if tools.current(self.gm.party) == "chop" and self._village_tree():
            # The village yells, as it does at digging (Frankie, 11/4, after Mark's Episode 1).
            self._chop_at, self._chops = None, 0
            self.text_box.push(ToolSettings.VILLAGE_CHOP_LINE)
            return
        if tools.current(self.gm.party) == "fish" and self._water_faced() is not None:
            if not self.gm.party.flags.get(SwimSettings.ROD_SHOWN_FLAG):
                # The rod dug up waits until Ama has seen it (Frankie, 11/17).
                self.text_box.push(SwimSettings.ROD_FIRST_LINE, speaker=StorySettings.PLAYER)
                return
            self._fish()
            return
        if tools.current(self.gm.party) == "dig":
            self._dig()
            return
        self._chop_at, self._chops = None, 0
        self.gm.audio.play("cant")

    def _dig(self) -> None:
        """A tap of Y with the 'O'o (Frankie, 10/27 and 10/30): dig the sand he faces; a spot
        gives 'awapuhi, anywhere else a random goodie; the village yells instead; never grass."""
        cell = self.world.current_cell_name
        dx, dy = self.player.facing
        col, row = self.player.col + dx, self.player.row + dy
        tile = self.world.tile_at(col, row)
        if tile not in (OverworldSettings.SAND_CHAR, OverworldSettings.PATH_CHAR, OverworldSettings.FLOOR_CHAR)                 or self.world.building_at(col, row) is not None or self.world.person_at(col, row):
            self.gm.audio.play("cant")
            return
        if _in_village(cell):
            self.text_box.push(DigSettings.VILLAGE_LINE)
            return
        if tile == OverworldSettings.FLOOR_CHAR:
            self.text_box.push(DigSettings.GRASS_LINE)
            return
        if cell != self._dug_room:
            self._dug, self._dug_room = set(), cell
        self._swing, self._chop_total = DigSettings.SWING_SECONDS, 0.0
        if (cell, col, row) == SwimSettings.ROD_SPOT and not self.gm.party.inventory.get(SwimSettings.ROD) \
                and (col, row) not in self._dug:
            # The Old Rod, buried on the hidden shore (Frankie, 11/17).
            self._dug.add((col, row))
            tools.take(self.gm.party, SwimSettings.ROD)
            self.gm.party.flags[SwimSettings.ROD_DUG_FLAG] = True
            self.gm.audio.play("dig")
            self.gm.audio.play(DigSettings.FOUND_SOUND)
            self.text_box.push(SwimSettings.ROD_FOUND_LINE)
            return
        if (col, row) in self._dug:
            notices.post_notice(DigSettings.AGAIN_LINE)
            return
        self._dug.add((col, row))
        had = self.gm.party.inventory.get(DigSettings.BURIED, 0)
        got = dig.find(self.gm.party, cell, col, row)
        self.gm.audio.play("dig")
        if dig.found_important(self.gm.party, had):
            self.gm.audio.play(DigSettings.FOUND_SOUND)
        # A notice, never a text box: Kailo keeps digging while it shows (Frankie, 11/12).
        if got is None:
            notices.post_notice(DigSettings.NOTHING_LINE)
        else:
            notices.post_found(got[0], got[1], always_count=got[2])

    def _fish(self) -> None:
        """A tap of Y with the rod, facing water (Frankie, 10/28): the first casts the line, baited
        only if bait was put on the rod from the bag (Frankie, 11/4); a tap while something is biting hooks
        it, and one before reels the line in, no fish. A hooked fish starts the reel."""
        if self._line is None:
            baited = fishing.has_bait(self.gm.party)
            wait = random.uniform(*(FishingSettings.BITE_WAIT if baited else FishingSettings.BITE_WAIT_NO_BAIT))
            water = self._water_faced()
            self._line = [(self.world.current_pos, self.player.col, self.player.row), wait, 0.0, baited,
                          fishing.roll(baited, water=water), water]  # What will bite is settled at the cast, so an empty one never shows the "!" (Frankie, 11/4).
            self.gm.audio.play("menu_select")
            return
        if self._line[2] > 0:
            kind = self._line[4]
            if kind != "nothing":
                fishing.spend_bait(self.gm.party)  # anything hooked eats the bait on the rod (Frankie, 11/4)
            if kind in ("fish", "rare"):
                self._reel = fishing.Reel(fishing.hook(kind, self.gm.party, water=self._line[5]))
                self.gm.audio.play("blip")
                return
            self._line = None
            line = fishing.land(self.gm.party, kind)
            self.gm.audio.play("cant" if line == FishingSettings.NIBBLE_LINE else "hit_sparkle_1")
            self._say_catch(line, kind)
            return
        self._line = None
        self.gm.audio.play("cant")

    def _say_catch(self, line: str, kind: str) -> None:
        """What the line landed: a rare item is still a text box (rare and meaningful); fish, nori,
        pule and nothing are notices that never stop play (Frankie, 11/12)."""
        if kind == "rare":
            self.text_box.push(line)
        else:
            notices.post_notice(line)

    def _tick_reel(self, dt: float) -> None:
        """Reeling (Frankie, 11/2): each quarter turn of the d-pad the same way fills the meter;
        full lands the catch; drained or out of time and it gets away. The bait went at the
        hook either way (Frankie, 11/4)."""
        held = input_map.read_held_direction(self.gm.connected_joysticks)
        if self._reel.press(held):
            self.gm.audio.play("menu_move")
        result = self._reel.tick(dt)
        if result is None:
            return
        item = self._reel.item
        self._reel, self._line = None, None
        self.gm.party.flags[FishingSettings.REEL_HINT_FLAG] = True
        if result == "caught":
            self.gm.audio.play("hit_sparkle_1")
            self._say_catch(fishing.catch(self.gm.party, item), "fish" if item in ItemSettings.FISH else "rare")
        else:
            self.gm.audio.play("cant")
            notices.post_notice(FishingSettings.ESCAPED_LINE)

    def _tick_fishing(self, dt: float) -> None:
        """The line out: the bite comes after its wait and lasts a moment, then the fish is gone.
        Kailo cannot walk with it out (Frankie, 11/4); leaving the spot any other way reels it in."""
        if self._reel is not None:
            self._tick_reel(dt)
            return
        if self._line is None:
            return
        here = (self.world.current_pos, self.player.col, self.player.row)
        if here != self._line[0]:
            self._line = None
        elif self._line[1] > 0:
            self._line[1] -= dt
            if self._line[1] <= 0 and self._line[4] == "nothing":
                self._line = None
                notices.post_notice(FishingSettings.NIBBLE_LINE)
            elif self._line[1] <= 0:
                self._line[2] = FishingSettings.BITE_WINDOW
                self.gm.audio.play("blip")
        elif self._line[2] > 0:
            self._line[2] -= dt
            if self._line[2] <= 0:
                self._line = None
                notices.post_notice(FishingSettings.MISS_LINE)

    def _faced_tree(self) -> tuple | None:
        """The tree or stump Kailo faces, as (room, col, row), if the ko'i can chop it, else None.

        Any tree in the woods (Frankie, 10/26): not one along the room's edge,
        which holds the map in, and none in town.
        """
        cell = self.world.current_cell_name
        dx, dy = self.player.facing
        col, row = self.player.col + dx, self.player.row + dy
        grid = self.world.current_grid
        if (self.world.tile_at(col, row) not in (OverworldSettings.WALL_CHAR, OverworldSettings.STUMP_CHAR)
                or self.world.building_at(col, row) is not None
                or _in_village(cell)
                or not (0 < row < len(grid) - 1 and 0 < col < len(grid[row]) - 1)):
            return None
        return (cell, col, row)

    def _village_tree(self) -> bool:
        """Whether Kailo faces a palm in town, which the ko'i may not chop."""
        dx, dy = self.player.facing
        col, row = self.player.col + dx, self.player.row + dy
        return (_in_village(self.world.current_cell_name)
                and self.world.tile_at(col, row) in (OverworldSettings.WALL_CHAR, OverworldSettings.STUMP_CHAR)
                and self.world.building_at(col, row) is None)

    def _sacred_tree(self) -> str | None:
        """What makes the tree Kailo faces off limits (Frankie, 11/3): "banyan" for a banyan
        anywhere, "grove" for any tree or stump in Lanu's grove, else None."""
        dx, dy = self.player.facing
        col, row = self.player.col + dx, self.player.row + dy
        building = self.world.building_at(col, row)
        if building is not None and building["kind"] in ("banyan", "great_banyan"):
            return "banyan"
        if self.world.current_cell_name == ToolSettings.GROVE and (
                (building is None
                 and self.world.tile_at(col, row) in (OverworldSettings.WALL_CHAR, OverworldSettings.STUMP_CHAR))
                or (building is not None and building["kind"] in OverworldSettings.TREE_BUILDINGS)):
            return "grove"
        return None

    def _scold_chop(self, why: str) -> None:
        """Hina scolds Kailo for raising the ko'i at a sacred tree; Maika with her away; alone,
        Kailo thinks better of it (Frankie, 11/3)."""
        party = self.gm.party
        speaker = next((name for name in ("Hina", "Maika") if party.find(name.lower()) is not None),
                       StorySettings.PLAYER)
        grove, banyan = ToolSettings.SACRED_SCOLD[speaker]
        if speaker == "Hina":
            self.gm.audio.play("scold_nag")  # Nagging Mumble goes with her scolding (Frankie, 11/11)
        self._chop_at, self._chops = None, 0
        self.text_box.push(grove if why == "grove" else banyan, speaker=speaker)

    def _fruiting(self, col: int, row: int) -> bool:
        """Whether the tree at ``(col, row)`` shows fruit it can drop (a coconut palm, breadfruit, kukui or banana)."""
        flags = self.gm.party.flags
        kind = self.world.tree_kind_at(col, row)
        if kind in ItemSettings.ALWAYS_FRUITING:
            return True
        return (kind in ItemSettings.TREE_FRUIT
                and trees.has_fruit(self.world.seed, self.world.current_cell_name, col, row, flags))

    def _drop(self, item: str, count: int, col: int, row: int) -> None:
        """Something falls from the crown of the tree at ``(col, row)`` and lands on its tile (``systems/drops``)."""
        self._drops.append(drops.Drop(self.world.current_cell_name, item, count, col, row))

    def _pick_up(self, col: int, row: int, force: bool = False) -> bool:
        """Take what lies on a tile (all of it, once it has landed): into the bag, a sound, and a line at the top."""
        room = self.world.current_cell_name
        got = [d for d in drops.at(self._drops, room, col, row) if d.landed or force]
        if not got:
            return False
        bag = self.gm.party.inventory
        for d in got:
            bag[d.item] = bag.get(d.item, 0) + d.count
            notices.post_found(ItemSettings.NAMES[d.item], d.count)
            self._drops.remove(d)
        self.gm.audio.play(DropSettings.PICKUP_SOUND)
        return True

    def take_all_drops(self) -> None:
        """Pick up every drop in the room at once, landed or not (for tests and tools)."""
        for col, row in {(d.col, d.row) for d in self._drops if d.room == self.world.current_cell_name}:
            self._pick_up(col, row, force=True)

    def _tick_drops(self, dt: float) -> None:
        """Let the falling drops fall; those of a room Kailo has left are gone."""
        room = self.world.current_cell_name
        self._drops[:] = [d for d in self._drops if d.room == room]
        for d in self._drops:
            d.age += dt

    def _give_fruit(self, col: int, row: int) -> None:
        """The fruit falls into the bag; the tree is plain until it grows back."""
        kind = self.world.tree_kind_at(col, row)
        fruit = ItemSettings.TREE_FRUIT[kind][0]
        self._drop(fruit, 1, col, row)
        if kind not in ItemSettings.ALWAYS_FRUITING:   # ti is never left plain
            trees.fruit_dropped(self.gm.party.flags, self.world.current_cell_name, col, row)

    def _knock_fruit(self, col: int, row: int) -> None:
        """One punch or chop on the tree at ``(col, row)``: a fruiting tree may drop its fruit, the chance rising with
        each blow in a row from where Kailo stands (Frankie, 11/24 night); another spot or tree starts it again."""
        key = (self.world.current_cell_name, col, row, self.player.col, self.player.row)
        if getattr(self, "_knock_key", None) != key:
            self._knock_key, self._knock_hits = key, 0
        self._knock_hits += 1
        if self._fruiting(col, row):
            chances = ItemSettings.FRUIT_KNOCK_CHANCES
            if random.random() < chances[min(self._knock_hits, len(chances)) - 1]:
                self._give_fruit(col, row)

    def _chop(self, tree: tuple) -> None:
        """One chop at ``tree`` (Frankie, 10/28): a swing Kailo is stuck in, and the tree shakes.

        The tenth in a row fells a tree to its stump, the fifth clears the
        stump to grass, each for its wood.
        """
        if tree != self._chop_at:
            self._chop_at, self._chops = tree, 0
        _, col, row = tree
        self._chops += 1
        self._swing = self._chop_total = ToolSettings.SWING_SECONDS[tools.best(self.gm.party, "chop")]
        self._shake, self._shake_left = (col, row), ToolSettings.SHAKE_SECONDS
        self.gm.audio.play("chop")
        stump = self.world.tile_at(col, row) == OverworldSettings.STUMP_CHAR
        if not stump:
            self._knock_fruit(col, row)
        if self._chops < (ToolSettings.STUMP_CHOPS if stump else ToolSettings.CHOPS):
            return
        # Felled: the tree is a stump, the stump grass, until 600 steps are walked (Frankie, 11/12).
        self._chops, self._shake = 0, None
        self.world.current_grid[row][col] = OverworldSettings.FLOOR_CHAR if stump else OverworldSettings.STUMP_CHAR
        trees.felled(self.gm.party.flags, self.world.current_cell_name, col, row, stump)
        wood = ToolSettings.WOOD_PER_STUMP if stump else ToolSettings.WOOD_PER_TREE
        # The tree's kind picks its wood (Frankie, 11/24): koa wood from a koa, plain wood from every other tree.
        kind = self.world.tree_kind_at(col, row)
        wood_item = ToolSettings.WOOD_ITEM.get(kind, ToolSettings.PLAIN_WOOD)
        self._drop(wood_item, wood, col, row)
        # Felling gives its materials too (Frankie, 11/25: punching gives food, felling gives materials).
        material = ItemSettings.TREE_MATERIALS.get(kind) if not stump else None
        if material:
            self._drop(material, 1, col, row)
        # Felling a fruiting tree always gives its fruit (Frankie, 11/24 night); a plain tree gives none.
        if not stump and self._fruiting(col, row):
            self._give_fruit(col, row)

    def _can_dive(self) -> bool:
        """Whether Kailo stands on the shore facing water he can swim, with nothing else going on."""
        dx, dy = self.player.facing
        player = self.player
        return (not player.swimming and not player._step_active and self._line is None and self.story is None
                and swim.can_swim(self.gm.party, player.shown)
                and self.world.is_swimmable(player.col + dx, player.row + dy))

    def _try_dive(self) -> None:
        """B at the water jumps in (Frankie, 11/16). The first time, the others say they cannot swim."""
        party = self.gm.party
        if not party.flags.get(SwimSettings.LEARNED_FLAG):
            # Not until Ama teaches him (Frankie, 11/17), so the bridge Nuno cannot be swum round.
            line = SwimSettings.AMA_FIRST_LINE if party.flags.get(SwimSettings.ROD_SHOWN_FLAG) else SwimSettings.NOT_YET_LINE
            self.text_box.push(line, speaker=StorySettings.PLAYER)
            return
        here = {m.id for m in party.members}
        voices = [who for who in SwimSettings.STAND_IN if who in here and who in SwimSettings.COMPLAINTS]
        if voices and not party.flags.get(SwimSettings.TOLD_FLAG):
            party.flags[SwimSettings.TOLD_FLAG] = True
            for member_id in voices:
                line = SwimSettings.COMPLAINTS[member_id]
                if member_id == "maika" and "hina" in voices:
                    line = SwimSettings.MAIKA_AFTER_HINA
                self.text_box.push(line, speaker=member_id.capitalize())
            # Then the waiting: Hina says it, annoyed, or Maika when she is not along (Frankie, 11/16).
            waiter = next((who for who in SwimSettings.WAIT_SPEAKERS if who in here), None)
            if waiter is not None:
                self.text_box.push(SwimSettings.WAIT_LINE, speaker=waiter.capitalize())
            self._after_text = self._dive
            return
        self._dive()

    def _dive(self) -> None:
        """Kailo hops in; the rest of the party stays where he stood (``systems/swim.py``)."""
        party, player = self.gm.party, self.player
        spot = (self.world.current_cell_name, player.col, player.row)
        if player.dive():
            swim.leave_party(party, *spot)
            self._line = None
            stand_in = swim.waiting_person(party, spot[0])
            if stand_in is not None:
                self.world.people.append(stand_in)   # one of them stays on the shore for the rest

    def _swim_step(self) -> None:
        """A new tile: the ones left ashore may give up and head home, quietly, and a Sirena may rise."""
        party, player = self.gm.party, self.player
        if swim.tick(party):
            self.world.people = [p for p in self.world.people if not p.get("party_rest")]
        if player._hop:
            return
        cell = self.world.current_cell_name
        if not player.swimming and swim.regroup_due(party, _in_village(cell)):
            swim.regroup(party)   # they went home to the village and are with him again, no word of it

    def _gather_party(self, person: dict) -> None:
        """Talking to the one left on the shore gathers the party again (Frankie, 11/16)."""
        # She turns to Kailo, says her line, and only then rejoins and leaves the shore (Frankie, 11/16).
        self._turn_to_player(person)
        line = SwimSettings.GATHER_LATE_LINE if swim.waited_long(self.gm.party) else SwimSettings.GATHER_LINE
        self.text_box.push(line, speaker=person["speaker"])

        def rejoin() -> None:
            swim.regroup(self.gm.party)
            self.world.people = [p for p in self.world.people if not p.get("party_rest")]
        self._after_text = rejoin

    def _on_stage_monsters(self) -> list:
        """The monsters in play: a Sirena drifts out of any scene on the stage (Frankie, 11/16), so a cutscene
        such as the wake's jump off the pier never has a monster in it."""
        if self.story is None and self.stage is None:
            return self.monsters
        return [m for m in self.monsters if not m.kind.get("water")]

    def _reachable(self, monster: FieldMonster) -> bool:
        """Whether ``monster`` can meet the party now: one that lives in the water (a Sirena) meets only a
        swimmer, never someone on the shore or the dock (Frankie, 11/16)."""
        return not monster.kind.get("water") or self.player.swimming

    def _water_faced(self) -> str | None:
        """"sea" or "fresh" for the water the player faces and may fish, or None: a spring gives no fish
        and nothing else is water (Frankie, 11/16)."""
        if self._facing(OverworldSettings.WATER_CHAR):
            return "sea"
        if self._facing(OverworldSettings.FRESH_CHAR):
            return "fresh"
        return None

    def _spring(self) -> None:
        """A on a healing spring rests the party (Frankie, 11/12); it gives no water (11/16)."""
        self._rest()

    def _scoop_water(self) -> None:
        """One water in the bag, free (Frankie, 10/28); after ten in a row the canteens
        are heavy and he rests a little before the next (Frankie, 10/28)."""
        bag = self.gm.party.inventory
        if self._since_draw >= CraftSettings.WATER_REST:
            self._draws = 0
        if bag.get(ItemSettings.WATER, 0) >= CraftSettings.WATER_MAX:
            self.text_box.push(CraftSettings.FULL_LINE)
            return
        if self._draws >= CraftSettings.WATER_STREAK:
            self.text_box.push(CraftSettings.REST_LINE, speaker=StorySettings.PLAYER)
            return
        self._draws += 1
        self._since_draw = 0.0
        bag[ItemSettings.WATER] = bag.get(ItemSettings.WATER, 0) + 1
        self.gm.audio.play("menu_select")
        self.text_box.push(CraftSettings.WATER_LINE)
        if self._draws == CraftSettings.WATER_STREAK:
            self.text_box.push(CraftSettings.HEAVY_LINE, speaker=StorySettings.PLAYER)

    def _person_key(self, person: dict) -> str:
        """A name for ``person`` that lasts across visits and saves: their room and place in its file."""
        cell = self.world.current_cell_name
        for index, original in enumerate(PEOPLE.get(cell, [])):
            if self.world.turns.get(id(original)) is person.get("turn"):
                return f"{cell}:{index}"
        return f"{cell}:{person.get('speaker')}"

    def _facing(self, char: str) -> bool:
        """Whether the tile the player faces is ``char``: the pond (D-525), a stall (D-571)."""
        dx, dy = self.player.facing
        return self.world.tile_at(self.player.col + dx, self.player.row + dy) == char

    def at_save_point(self) -> bool:
        """Whether the party stands on a tile next to an Akua totem (Frankie, 10/26)."""
        for dx, dy in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            building = self.world.building_at(self.player.col + dx, self.player.row + dy)
            if building and building["kind"] == "totem":
                return True
        return False

    def _faced_look(self) -> list:
        """The ``look`` lines of the building the player faces (a lore hint), or none."""
        dx, dy = self.player.facing
        col, row = self.player.col + dx, self.player.row + dy
        building = self.world.building_at(col, row)
        if building is not None and building["kind"] in OverworldSettings.BANYANS                 and not self.gm.party.flags.get(ToolSettings.BANYAN_FLAG):
            # The first banyan Kailo presses A on, anywhere, gets Hina's history (Frankie, 11/24), once per game.
            return list(ToolSettings.BANYAN_HISTORY)
        return building.get("look", []) if building else []

    def _banyan_told(self) -> None:
        """Mark Hina's banyan history as told once Kailo has pressed A on a banyan."""
        if self._faced_building() in OverworldSettings.BANYANS:
            self.gm.party.flags[ToolSettings.BANYAN_FLAG] = True

    def _look(self, lines: list) -> None:
        """Say a lore hint's lines (Frankie, 10/25): each ``[speaker, line]``, or with a third,
        ``with hina`` or ``without hina``, said only with that member along or away."""
        for speaker, line, *when in lines:
            if when:
                need, member = when[0].split()
                if (self.gm.party.find(member) is not None) != (need == "with"):
                    continue
            self.text_box.push(line, speaker=speaker)

    def _wake_stone(self, stone: dict) -> None:
        """A sleeping stone wakes and fights, alone (the log yard's Pōhaku, Frankie 10/28).

        It stays a stone on the map whatever comes of the fight, so Kailo
        can talk to it, and fight it, again.
        """
        kinds = self.gm.data.load("field_monsters")
        spot = {"col": stone["col"], "row": stone["row"], "kind": stone["wakes"], "still": True}
        self._start_fight(FieldMonster(spot, kinds[stone["wakes"]]))

    def _faced_building(self) -> str | None:
        """The kind of building on the tile the player faces, or None."""
        dx, dy = self.player.facing
        building = self.world.building_at(self.player.col + dx, self.player.row + dy)
        return building["kind"] if building else None

    def _facing_shut_door(self) -> bool:
        """Whether the player stands below a house's door, facing up, with no room behind it."""
        dx, dy = self.player.facing
        col, row = self.player.col + dx, self.player.row + dy
        building = self.world.building_at(col, row)
        door = OverworldSettings.DOORS.get(building["kind"]) if building else None
        return ((dx, dy) == (0, -1) and door is not None
                and (col - building["col"], row - building["row"]) == door
                and (self.world.current_cell_name, self.player.col, self.player.row, (0, -1)) not in warps())

    def _say_shut_door(self) -> None:
        """A house nobody can go into: Kailo says nobody is home (Frankie, 10/26)."""
        line = TownSettings.SHUT_DOOR_NIGHT if self.is_night() or self._clock_night() else TownSettings.SHUT_DOOR
        self.text_box.push(line, speaker=StorySettings.PLAYER)

    def _dead_end(self) -> bool:
        """Kailo walking into a shut door or off an edge with no room past it says
        one line, once each time he walks up to it (Frankie, 10/26). True if he spoke."""
        player = self.player
        if not player.bumped or player._step_active:
            self._bumped_at = None
            return False
        at = (self.world.current_cell_name, player.col, player.row, tuple(player.facing))
        if at == self._bumped_at:
            return False
        self._bumped_at = at
        if self._facing_shut_door():
            self._say_shut_door()
            return True
        dx, dy = player.facing
        edge = TownSettings.EDGE_LINES.get(self.world.current_cell_name)
        if edge and self.world.tile_at(player.col + dx, player.row + dy) is None:
            self.text_box.push(edge, speaker=StorySettings.PLAYER)
            return True
        return False

    def _turn_to_player(self, person: dict) -> list:
        """Turn ``person`` to face the player, who is facing them; return the way they faced."""
        was_facing = person["facing"]
        dx, dy = self.player.facing
        person["facing"] = [-dx, -dy]
        return was_facing

    def _met(self, person: dict) -> None:
        """Talking to a named person finds their People page, if they have one (Frankie, 11/12):
        the pages in ``game/shared/lore.md`` that unlock on ``talked <speaker>``."""
        if self.gm.party and person.get("speaker"):
            lore.unlock(self.gm.party, "talked " + person["speaker"])

    def _faced_person(self) -> dict:
        """The person on the tile the player faces, or an empty dict."""
        dx, dy = self.player.facing
        return self.world.person_at(self.player.col + dx, self.player.row + dy) or {}

    def _open_shop(self, shop_id: str) -> None:
        """Push a shop on top of this scene (D-571). No keeper talks up
        Counter any more (Frankie, 10/26)."""
        # Local import, as with the menu and the battle below.
        from core.scenes.shop_scene import ShopScene

        if self._shop_shut(shop_id):
            return
        self._push_shop(ShopScene(self.gm, shop_id))

    def _shop_shut(self, shop_id: str) -> bool:
        """A shop that closes at night, with the clock running and the hour past closing (Frankie, 11/20): its keeper
        says so and the shop does not open. True if it was shut."""
        party = self.gm.party
        if shop_id not in ClockSettings.SHOPS_THAT_CLOSE or not daytime.running(party) or daytime.shops_open(party):
            return False
        keeper = next((p for p in self.world.people if p.get("shop") == shop_id), None) or {}
        self.text_box.push(random.choice(ClockSettings.CLOSED_LINES), speaker=keeper.get("speaker"))
        return True

    def _push_shop(self, shop) -> None:
        self.gm.audio.play("menu_select")
        self.gm.scene_stack.push(shop)

    # ------------------------------------------------------------------
    # THE HUNTERS' LODGE: its bounties (Frankie, 10/26; systems/bounties.py)
    # ------------------------------------------------------------------

    def _lodge_keeper(self, keeper: dict) -> None:
        """Buy and sell, Hunts or Leave; a finished hunt is paid under Hunts (Frankie, 11/12)."""
        board = self.gm.data.load("bounties")[keeper["bounties"]]
        self._lodge_menu(keeper, board)

    def _lodge_menu(self, keeper: dict, board: dict) -> None:
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        lines = board["lines"]
        # The first visit to the keeper he mentions the kapa, once (Frankie, 11/10; it was never talked up, 10/26).
        if not self.gm.party.flags.get(StorySettings.KAPA_TOLD_FLAG):
            self.gm.party.flags[StorySettings.KAPA_TOLD_FLAG] = True
            for line in StorySettings.KAPA_TALK:
                self.text_box.push(line, speaker=keeper["speaker"])
            self._after_text = lambda: self._lodge_menu(keeper, board)
            return

        def pick(index: int) -> None:
            if index == 0:
                self._open_shop(keeper["shop"])
            elif index == 1:
                self._lodge_bounty(keeper, board)

        self.gm.scene_stack.push(ChoiceScene(self.gm, lines["ask"], lines["choices"], pick, cancel=len(lines["choices"]) - 1))

    def _lodge_bounty(self, keeper: dict, board: dict) -> None:
        """Hunts: a list of what is on offer, the Great Boar apart from the radiant one (Frankie, 11/12)."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        party, lines = self.gm.party, board["lines"]
        keys = bounties.hunts(party, board)
        names = [bounties.post_of(board, key)["name"] for key in keys]

        def pick(index: int) -> None:
            if index < len(keys):
                self._lodge_hunt(keeper, board, keys[index])

        self.gm.scene_stack.push(ChoiceScene(self.gm, lines["list"], names + [lines["back"]], pick, cancel=len(keys)))

    def _lodge_hunt(self, keeper: dict, board: dict, key: str) -> None:
        """One hunt's state: finished (collect it), in progress (the count), or offered (take it or not)."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        party, lines, speaker = self.gm.party, board["lines"], keeper["speaker"]
        post = bounties.post_of(board, key)
        if bounties.done(party, board, key):
            # Paid only when picked here, never on talking to him (Frankie, 11/12; it was paid on talking to him).
            # A wallet too full for the pay: he says so, pays nothing and keeps it until there is
            # room (Frankie, 11/12; it paid and lost the rest, 11/1).
            if party.pule + post["pule"] > party.pule_max:
                self.text_box.push(lines["wallet_full"], speaker=speaker)
                return
            paid = bounties.pay(party, board, key)
            prize = paid.get("prize")
            words = {"pule": paid["pule"], "prize": self._item_name(prize) if prize else ""}
            # A post may have its own words (Claude's drafts, 11/17); else the board's.
            self.text_box.push((paid.get("paid") or lines["paid" if prize else "paid_pule"]).format(**words), speaker=speaker)
            self.text_box.push(lines["got" if prize else "got_pule"].format(**words))
            self.gm.audio.play("hit_sparkle_1")
            return
        if bounties.taken(party, key):
            self.text_box.push(lines["progress"].format(what=post["what"][:1].upper() + post["what"][1:]), speaker=speaker)
            return
        prize = post.get("prize")
        self.text_box.push((post.get("offer") or lines["post" if prize else "post_pule"]).format(
            what=post["what"], pule=post["pule"], prize=self._item_name(prize) if prize else ""), speaker=speaker)

        def pick(index: int) -> None:
            if index == 0:
                bounties.take(party, key)
                self.text_box.push(lines["taken"], speaker=speaker)

        self._after_text = lambda: self.gm.scene_stack.push(
            ChoiceScene(self.gm, lines["take"], lines["take_choices"], pick,
                        cancel=len(lines["take_choices"]) - 1))

    @staticmethod
    def _item_name(item_id: str) -> str:
        from core.scenes.shop_scene import item_name  # local, as in _open_shop

        return item_name(item_id)

    # ------------------------------------------------------------------
    # MAIKA: a seller who joins (the demo plan, Frankie 10/22)
    # ------------------------------------------------------------------

    def _sync_joined(self) -> None:
        """Tell the world who is in the party and whether it is night, so whoever
        joined, or is at the wake, is gone from the map."""
        self.world.flags = self.gm.party.flags if self.gm.party else {}
        joined = {member.id for member in self.gm.party.members} if self.gm.party else set()
        night = bool(self.gm.party) and self.is_night()
        dark = daytime.dark(self.gm.party)
        if (joined, night, dark) != (self.world.joined, self.world.night, self.world.dark):
            self.world.joined, self.world.night, self.world.dark = joined, night, dark
            self.world.go_to(self.world.current_pos)

    def _talk_to_joiner(self, person: dict) -> None:
        """The first time, his scene and then his shop; after that, what his sister's errand left.

        Buying no longer makes him join (Frankie, 10/30). In order: once Kailo has
        agreed to find him for his sister, Maika asks Kailo not to tell her
        (the next talk, whether he was met before the sister or after); once
        Kailo has lied to her, he joins; once Kailo has told her the truth, he
        sulks, once, and stays; every other talk is his shop.
        """
        flags = self.gm.party.flags
        flag = f"met_{person['joins']}"
        if not flags.get(flag):
            flags[flag] = True
            self.begin_story(StorySettings.JOINER_MEETS)
        elif flags.get(StorySettings.SISTER_DEAL_FLAG) and not flags.get(StorySettings.JOINER_ASKED_FLAG):
            self.begin_story(StorySettings.JOINER_ASKS)
        elif flags.get(StorySettings.SISTER_LIED_FLAG):
            late = flags.get(StorySettings.BOAR_BEATEN_FLAG)
            if flags.get(StorySettings.JOINER_INVITED_FLAG):
                # Said no before: he asks the same question again (Frankie, 11/11).
                self.begin_story(StorySettings.JOINER_INVITES)
            else:
                self.begin_story(StorySettings.JOINER_JOINS_LATE if late else StorySettings.JOINER_JOINS)
        elif flags.get(StorySettings.SISTER_TOLD_FLAG) and not flags.get(StorySettings.JOINER_CROSS_FLAG):
            flags[StorySettings.JOINER_CROSS_FLAG] = True
            self.begin_story(StorySettings.JOINER_CROSS)
        else:
            self._open_joiner_shop(person)

    def _talk_to_sister(self, person: dict) -> None:
        """Maika's sister in the lodge (Frankie, 10/30): the deal, then once Maika has asked
        Kailo not to tell her, the report with its choice; either way, one line after."""
        flags = self.gm.party.flags
        if not flags.get(StorySettings.SISTER_DEAL_FLAG):
            self.begin_story(StorySettings.SISTER_ASKS)
        elif flags.get(StorySettings.SISTER_LIED_FLAG):
            self.text_box.push(StorySettings.SISTER_AFTER_LIE, speaker=person["speaker"])
        elif flags.get(StorySettings.SISTER_TOLD_FLAG):
            self.text_box.push(StorySettings.SISTER_AFTER_TRUTH, speaker=person["speaker"])
        elif flags.get(StorySettings.JOINER_ASKED_FLAG):
            # Maika found, in the Lost Woods, and he has asked Kailo not to tell her (Frankie, 11/12;
            # telling her right away after meeting him first, 11/1, is gone: he is missing from the deal on).
            self.begin_story(StorySettings.SISTER_REPORT)
        else:
            self.text_box.push(StorySettings.SISTER_WAITING, speaker=person["speaker"])

    def _ask_menu(self, person: dict, start: int = 0) -> None:
        """Someone's questions (``data/asks``), asked as often as the player likes; the last walks away.

        Each answer is said, unlocks its Lore page if it has one, and the
        questions come back (Frankie, 10/25).
        """
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        entry = self.gm.data.load("asks")[person["ask"]]
        questions = entry["questions"]
        along = self.gm.party is not None and self.gm.party.find(SchoolSettings.TEACHER) is not None
        # A school child speaks to Hina the first time they are asked with her along, and she
        # answers (Frankie, 11/10); then the questions.
        met = SchoolSettings.MET_FLAG.format(person["ask"])
        if along and entry.get("hina_meets") and not self.gm.party.flags.get(met):
            self.gm.party.flags[met] = True
            for speaker, line in entry["hina_meets"]:
                self.text_box.push(self._teacher_title(line), speaker=speaker)
            self._after_text = lambda: self._ask_menu(person, start)
            return

        def pick(index: int) -> None:
            question = questions[index]
            # With Hina along a question can have its own lines, with no talk of buttons.
            rows = question["with_hina"] if along and question.get("with_hina") else question["lines"]
            for speaker, line in rows:
                self.text_box.push(self._teacher_title(line), speaker=speaker)
            # One event, or a list when the answer names several pages (Frankie, 11/13).
            unlocks = question.get("unlock") or []
            for when in [unlocks] if isinstance(unlocks, str) else unlocks:
                lore.unlock(self.gm.party, when)
            if index < len(questions) - 1:
                # Back on the question just asked, never the top: confirm replayed the
                # first speech (Frankie, 11/3, Mark's playtest).
                self._after_text = lambda: self._ask_menu(person, index)

        menu = ChoiceScene(self.gm, person["speaker"], [q["ask"] for q in questions], pick,
                           cancel=len(questions) - 1)
        menu.cursor = start
        self.gm.scene_stack.push(menu)

    @staticmethod
    def _teacher_title(line: str) -> str:
        """What the school's children call Hina, in one place (``SchoolSettings.TEACHER_TITLE``)."""
        return line.replace(SchoolSettings.TEACHER_KEY, SchoolSettings.TEACHER_TITLE)

    def _say_lines(self, person: dict) -> None:
        """Someone's next line. Someone home at night says their ``night_lines`` (Kailo's
        cousins, 10/25); by day, the ``flag_lines`` of the first party flag set, if any (the
        chief with no stew, Frankie, 10/26). One of them a talk (Frankie, 10/26)."""
        flags = self.gm.party.flags if self.gm.party else {}
        which, lines = next(((flag, said) for flag, said in person.get("flag_lines", {}).items()
                             if flags.get(flag)), ("day", person["lines"]))
        if self.is_night() and person.get("night_lines"):
            which, lines = "night", person["night_lines"]
        self._take_turn(person, which, lines)
        if self.gm.party and not self.is_night() and self.gm.party.flags.get(StorySettings.AFTER_JUMP_FLAG):
            self._craving(person)

    def _talk_ama(self, person: dict) -> None:
        """Ama's greeting, then his menu (Frankie, 11/20). While the boat waits to be mended (after the jump,
        until ``BOAT_FIXED``) the greeting is the boat, at once; otherwise the next of the rod hint, the rod,
        the swimming lesson, his first ramble, the story of the rod, or his next line (once the boat is mended
        and nothing else is due, he says it is ready). The menu follows unless a line left a question open."""
        party, flags, speaker = self.gm.party, self.gm.party.flags, person["speaker"]
        after_jump = flags.get(StorySettings.AFTER_JUMP_FLAG)
        if person.get("boat") and after_jump and not flags.get(StorySettings.BOAT_FIXED):
            self._talk_ama_boat(speaker)
        elif self._talk_ama_rod(person, person["gift"]):
            pass
        elif not flags.get(person["gift"]["when"]) and not after_jump:
            self._say_lines(person)
        elif self._ama_story(person):
            pass
        elif person.get("boat") and after_jump:
            self._talk_ama_boat(speaker)
        else:
            self._say_lines(person)
        if self._after_text is None:
            self._after_text = lambda: self._keeper_menu(person)

    def _keeper_menu(self, person: dict) -> None:
        """A keeper's menu (Frankie, 11/3): ``menu`` holds the question and its rows, each
        [words, action]. "shop" opens their shop, "talk" says their next line (a requester's dish), "ask" opens their questions, "raise" gets the fallen up, "leave" closes."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        menu = person["menu"]
        choices = list(menu["choices"])
        flags = self.gm.party.flags if self.gm.party else {}
        # While Ama waits for his koa, he can be asked what it looks like (Frankie, 11/25).
        if person.get("boat") and flags.get(StorySettings.BOAT_ASKED) and not flags.get(StorySettings.BOAT_WOOD_FLAG):
            choices.insert(0, [StorySettings.BOAT_KOA_CHOICE, "koa"])

        def pick(index: int) -> None:
            action = choices[index][1]
            if action == "shop":
                self._open_shop(person["shop"])
            elif action == "sleep":
                self._ask_inn(person)
            elif action == "talk" and self.gm.party and self._ama_story(person):
                pass
            elif action == "talk" and person.get("boat") and self.gm.party \
                    and self.gm.party.flags.get(StorySettings.AFTER_JUMP_FLAG):
                self._talk_ama_boat(person["speaker"])
            elif action == "talk" and person.get("request") and self.gm.party:
                self._talk_requester(person, person["request"])
            elif action == "talk":
                self._say_lines(person)
            elif action == "ask":
                self._ask_menu(person)
            elif action == "raise":
                self._raise_fallen(person)
            elif action == "koa":
                self._show_koa(person["speaker"])
                self._after_text = lambda: self._keeper_menu(person)

        self.gm.scene_stack.push(ChoiceScene(self.gm, menu["ask"], [row[0] for row in choices], pick,
                                             cancel=[row[1] for row in choices].index("leave")))

    def _show_koa(self, speaker: str) -> None:
        """Ama's words on koa, the first with the tree itself, twice its size, in the box (Frankie, 11/25)."""
        path = os.path.join(AssetPaths.BUILDINGS_DIR, StorySettings.BOAT_KOA_PICTURE)
        picture = pygame.image.load(path).convert_alpha()
        first, *rest = StorySettings.BOAT_KOA_LINES
        self.text_box.push(first, speaker=speaker, picture=picture)
        for line in rest:
            self.text_box.push(line, speaker=speaker)

    def _faced_post(self) -> dict | None:
        """The one of Lanu's five posts the player faces (one that takes an offering), or None."""
        dx, dy = self.player.facing
        building = self.world.building_at(self.player.col + dx, self.player.row + dy)
        return building if building and building.get("offering") else None

    def _talk_to_post(self, post: dict) -> None:
        """Kailo at one of Lanu's posts: water in the bag, he offers it; once it is done, he says so;
        with none, he says what the post needs (Frankie, 11/4: it said "water would not hurt it" every time)."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menus nearby

        party = self.gm.party
        if party.flags.get(self._post_flag(post)):
            self.text_box.push(LanuSettings.DONE, speaker="Kailo")
        elif party.inventory.get(ItemSettings.WATER):
            self.text_box.push(LanuSettings.OFFER, speaker="Kailo")
            self._after_text = lambda: self.gm.scene_stack.push(
                ConfirmScene(self.gm, LanuSettings.ASK, on_yes=lambda: self._offer_water(post)))
        else:
            self.text_box.push(LanuSettings.DRY, speaker="Kailo")

    def _post_flag(self, post: dict) -> str:
        """The party flag that says ``post`` in this room was watered."""
        return LanuSettings.POST_FLAG.format(self.world.current_cell_name, post["col"], post["row"])

    def _offer_water(self, post: dict) -> None:
        """Leave Lanu a cup of water at ``post``: one water from the bag, the post counted (Frankie, 11/3)."""
        party = self.gm.party
        party.inventory[ItemSettings.WATER] -= 1
        if party.inventory[ItemSettings.WATER] <= 0:
            del party.inventory[ItemSettings.WATER]
        party.flags[self._post_flag(post)] = True
        cups = party.flags.get(LanuSettings.CUPS_FLAG, 0) + 1
        party.flags[LanuSettings.CUPS_FLAG] = cups
        lore.unlock(party, "event lanu_water")  # her page, with the first cup
        self.gm.audio.play("hit_sparkle_1")
        self.text_box.push(LanuSettings.POURED)
        if cups >= LanuSettings.CUPS:
            self.text_box.push(LanuSettings.ENOUGH)

    def _raise_fallen(self, person: dict) -> None:
        """The temple's priest raises every fallen member at full HP, free, as a totem does
        (Frankie, 11/3; free and full are Claude's calls). ``raise`` holds his two lines."""
        said = person["raise"]
        fallen = [m for m in self.gm.party.members if m.current_hp <= 0]
        if not fallen:
            self.text_box.push(said["none"], speaker=person["speaker"])
            return
        for member in fallen:
            member.current_hp = member.max_hp
        self.text_box.push(said["prays"], speaker=person["speaker"])
        self.gm.audio.play("hit_sparkle_1")
        for member in fallen:
            self.text_box.push(TownSettings.GOT_UP_LINE.format(name=short_name(member.id)))

    def _read_sign(self, shop_id: str) -> None:
        """The old man at the wake (Frankie, 10/25): Kailo stares at his sign, Hina reads it, and the shop opens."""
        for line in TownSettings.SIGN_STARE:
            self.text_box.push(line, speaker=StorySettings.PLAYER)
        hina = TownSettings.SCOLD_SPEAKER
        if self.gm.party.find(hina.lower()) is not None:
            for line in TownSettings.SIGN_READ:
                self.text_box.push(line, speaker=hina)
        # Straight to the shop.
        from core.scenes.shop_scene import ShopScene  # local, as in _open_shop

        self._after_text = lambda: self._push_shop(ShopScene(self.gm, shop_id))

    def _joined_keeper_shop(self) -> None:
        """A stall whose keeper has joined stays open (Frankie, 10/24): he asks, then his shop."""
        keeper = next((p for p in PEOPLE.get(self.world.current_cell_name, [])
                       if p.get("shop") and p.get("joins") and self.gm.party.find(p["joins"])), None)
        if keeper is None:
            return
        speaker = short_name(keeper["joins"])
        self.text_box.push(StorySettings.JOINED_SHOP_LINE, speaker=speaker)
        self._after_text = lambda: self._open_shop(keeper["shop"])

    def _joiner(self) -> dict | None:
        """The person in this room who may join (Maika), or None."""
        return next((p for p in self.world.people if p.get("joins")), None)

    def _open_joiner_shop(self, person: dict) -> None:
        self._joiner_shop = (person, dict(self.gm.party.inventory))
        self._open_shop(person["shop"])

    def _after_joiner_shop(self, person: dict, before: dict) -> None:
        """The shop closed, bought or not: he says to come back (buying no longer makes him join)."""
        self.begin_story(StorySettings.JOINER_LEAVES)

    def _joiner_joins(self) -> None:
        """His scene is over: he joins, with his pop-up, and is gone from the map."""
        from core.factories import party_member_from_data
        from core.shared import by_id

        self.gm.party.add(party_member_from_data(by_id("characters")[StorySettings.JOINER]))
        # He holds a doll from the start so he can Charm at once; his Ko'oko'o waits in the bag (Frankie, 11/1).
        bag = self.gm.party.inventory
        bag[StorySettings.JOINER_STAFF] = bag.get(StorySettings.JOINER_STAFF, 0) + 1
        self.text_box.push(join_line(StorySettings.JOINER))
        self.gm.audio.play("hit_sparkle_1")
        self._sync_joined()

    def _asker_in_reach(self) -> FieldMonster | None:
        """The Great Boar, if the party has walked up to him, facing him; he asks before he fights."""
        dx, dy = self.player.facing
        ahead = (self.player.col + dx, self.player.row + dy)
        return next((m for m in self.monsters if m.spot.get("kind") == StorySettings.ASK_KIND
                     and ahead in m.tiles()), None)

    def _slot_learned(self, member_id: str, move_id: str) -> None:
        """Put a move just learned in a scene into the member's lowest free slot, as a lontar does."""
        from core.factories import first_loadout
        from core.shared import by_id
        from systems.loadout import learn, open_slots
        member = self.gm.party.find(member_id)
        if member is not None:
            member.loadout = learn(member.loadout, by_id("moves")[move_id],
                                   first_loadout(member_id, self.gm.party.flags),
                                   open_slots(self.gm.party.flags))

    def _seed_lesson_due(self) -> bool:
        """Maika and Hina both along and Seed not taught yet: the first planting teaches it."""
        party = self.gm.party
        return (not party.flags.get(StorySettings.SEED_FLAG)
                and party.find(StorySettings.JOINER) is not None
                and party.find(StorySettings.HOME_MEMBER) is not None)

    # ------------------------------------------------------------------
    # THE STORY: the taro patch, night, Melia's tusk, Hina's question, the wake
    # ------------------------------------------------------------------

    def begin_story(self, name: str) -> None:
        """Play the scene ``name`` (``core/story.py``) over the field."""
        self.story = StoryRunner(name)
        # The Kaigara Kame's talk finds the Lore pages it names (Frankie, 10/27).
        lore.naming = name.startswith("kaigara_")
        self.story.choose(party_flag(self.gm.party))
        # "(if maika along)" plays whenever he is in the party (story-boar.md);
        # "(if maika)" only when he leads, Hina away.
        # A member knocked out in the fight just won says nothing in the scene that follows it (Mark, 11/12).
        self.story.flags.update(f"{member.id} along" for member in self.gm.party.members
                                if name != StorySettings.FALL_SCENE or member.current_hp > 0)
        # The first lontar talk plays in a scene that hands one over, if it has not yet (Frankie, 11/10).
        if lontar_talk.due(self.gm.party):
            self.story.choose("first lontar due")
        # Whether the gulls got the stew at the taro patch (Frankie, 10/26); a
        # save from before it, or a scene picked from the title, has it saved.
        lost = self.gm.party.flags.get(StorySettings.STEW_LOST_FLAG)
        self.story.choose(StorySettings.STEW_LOST if lost else StorySettings.STEW_SAVED)
        # Whether Kailo has cooked the new stew, Noelani helping, for the Great Boar's nightfall (Frankie, 10/30).
        if stew.made(self.gm.party):
            self.story.choose("stew made")
        # Whether Melia has the tusk, so the beach finds it (Frankie, 11/5).
        if self.gm.party.flags.get(StorySettings.TUSK_FLAG):
            self.story.choose("tusk given")
        # Whether Kailo talked to Maika at his stall before the deal (Frankie, 11/12): the clearing's opening differs.
        if name == StorySettings.CLEARING_SCENE:
            self.story.choose("met before" if self.gm.party.flags.get(f"met_{StorySettings.JOINER}") else "met not before")
        self._story_next = None
        self.stage = None

    def open_from_black(self) -> None:
        """Start the field black, the blurb's black, to fade in as the story's first line
        slowly types; lit just as it finishes (Frankie, 10/25)."""
        self._dark, self._opening = 1.0, True

    def _tick_opening(self) -> None:
        """Light the opening as far as its first line has typed; over once it has."""
        if not self._opening or self.text_box.is_done():
            return
        if self.text_box.has_own_speed() and self.text_box.typed() < 1:
            self._dark = 1.0 - self.text_box.typed()
        else:
            self._dark, self._opening = 0.0, False

    def is_night(self) -> bool:
        """Whether the Great Boar is beaten, so it is night, until the morning after the jump."""
        flags = self.gm.party.flags
        return bool(flags.get(StorySettings.NIGHT_FLAG)) and not flags.get(StorySettings.AFTER_JUMP_FLAG)

    def _tusk_due(self, person: dict) -> bool:
        """Melia by day with the tusk in the bag, not yet given, and found if she hid (Frankie, 11/5)."""
        party = self.gm.party
        first = person.get("first")
        return (not self.is_night() and bool(party.inventory.get(StorySettings.TUSK))
                and not party.flags.get(StorySettings.TUSK_FLAG)
                and not (first and not party.flags.get(first.get("flag"))))

    def _talk_at_night(self, person: dict) -> None:
        """Melia at night: with the Great Boar's tusk in the bag, Kailo gives it to her,
        once (10/25); otherwise her ``night_lines``."""
        party = self.gm.party
        if (person["night"] == StorySettings.TUSK_SCENE and party.inventory.get(StorySettings.TUSK)
                and not party.flags.get(StorySettings.TUSK_FLAG)):
            self.begin_story(StorySettings.TUSK_SCENE)
            return
        self._take_turn(person, "night", person.get("night_lines", []))

    def _wake_ask_due(self) -> bool:
        """At night, the party just in the chief's room: Hina asks, once a visit (Frankie, 10/25).
        The tusk no longer has to be given first (Frankie, 11/5)."""
        if self.world.current_cell_name != StorySettings.ASK_ROOM:
            self._wake_asked = False
            return False
        due = (not self._wake_asked and not self.player._step_active
               and self.is_night())
        if due:
            self._wake_asked = True
        return due

    def _ask_wake(self) -> None:
        """Hina: is the party ready for the wake? YES starts it; NO, nothing more this visit."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        self.text_box.push(StorySettings.ASK_LINE, speaker=StorySettings.ASK_SPEAKER)
        self._after_text = lambda: self.gm.scene_stack.push(ConfirmScene(
            self.gm, StorySettings.ASK_BOX, on_yes=lambda: self.begin_story(StorySettings.WAKE_SCENE),
        ))

    def _not_your_bed(self, bed: dict) -> None:
        """Someone else's bed: Hina scolds, flustered at her own; with her away, Kailo knows it is not his."""
        hina = TownSettings.SCOLD_SPEAKER
        if bed.get("owner") == hina.lower():
            self.text_box.push(TownSettings.HINA_BED, speaker=hina)
        elif self.gm.party.find(hina.lower()) is not None:
            self.text_box.push(TownSettings.NOT_YOUR_BED, speaker=hina)
        else:
            self.text_box.push(TownSettings.NOT_MY_BED, speaker=StorySettings.PLAYER)

    def _sleep_choices(self) -> list[tuple[str, float]]:
        """The bed's rows with the hours each passes (Frankie, 11/20): Nap, Until evening (left out once it is evening
        or night: the hour is past 6 PM or before 6 AM) and Until morning."""
        at = daytime.hour(self.gm.party)
        rows = [(ClockSettings.SLEEP_NAP, ClockSettings.NAP_HOURS)]
        if ClockSettings.WAKE_HOUR <= at < ClockSettings.EVENING_HOUR:
            rows.append((ClockSettings.SLEEP_EVENING, (ClockSettings.EVENING_HOUR - at) % 24.0))
        rows.append((ClockSettings.SLEEP_MORNING, (ClockSettings.WAKE_HOUR - at) % 24.0 or 24.0))
        return rows

    def _ask_sleep(self) -> None:
        """With the clock running a bed asks how long (Frankie, 11/20): Nap, Until evening or Until morning, B backs out.
        The party is rested, the time passes, and the date and time show in the notice window on waking."""
        from core.scenes.choice_scene import BACK, ChoiceScene  # local, as the menu below

        choices = self._sleep_choices()

        def pick(index: int) -> None:
            self._sleep(choices[index][1])

        self.gm.scene_stack.push(ChoiceScene(self.gm, ClockSettings.SLEEP_ASK, [row[0] for row in choices], pick,
                                             cancel=BACK))

    def _sleep(self, hours: float) -> None:
        """Sleep ``hours``: the time passes, the party rests (``_rest``), and the date and time show on waking."""
        daytime.advance(self.gm.party, hours)
        self._rest(None)
        self._show_wake()

    def _show_wake(self) -> None:
        """On waking, the date and the time in the notice window at the top (the room name's style), not a text box."""
        party = self.gm.party
        self._show_popup([records.date_text(party), daytime.clock_text(party)])

    def _ask_nap(self) -> None:
        """Kailo's bed: take a nap? YES rests the party; NO, nothing. With the clock running, how long to sleep."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        if daytime.running(self.gm.party):
            self._ask_sleep()
            return

        self.gm.scene_stack.push(ConfirmScene(
            self.gm, TownSettings.NAP_BOX, on_yes=self._nap,
        ))

    def _ask_inn(self, keeper: dict | None = None) -> None:
        """Kupulau's inn (Frankie, 11/3): pay the keeper's price in pule to sleep the night. A bed
        asks too, the price from the keeper in the room; short of pule, she says so."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        keeper = keeper or next((p for p in self.world.people if p.get("inn")), None)
        if keeper is None:
            return
        price = keeper["inn"]
        if self.gm.party.pule < price:
            self.text_box.push(TownSettings.INN_SHORT.format(price=price), speaker=keeper["speaker"])
            return
        self.gm.scene_stack.push(ConfirmScene(
            self.gm, TownSettings.INN_ASK.format(price=price), on_yes=lambda: self._sleep_at_inn(keeper),
        ))

    def _sleep_at_inn(self, keeper: dict) -> None:
        """The night at the inn: the price paid, the party rested and the next day (the nap's own rest)."""
        self.gm.party.pule -= keeper["inn"]
        self.text_box.push(TownSettings.INN_THANKS, speaker=keeper["speaker"])
        # Until the wake a bed is only a nap, never a night (Frankie, answers: the clock starts after the wake).
        woke = self.gm.party.flags.get(StorySettings.AFTER_JUMP_FLAG)
        if daytime.running(self.gm.party):
            # The inn's bed is the night, to morning (Claude's pick); the date and time show on waking.
            daytime.sleep_until(self.gm.party, ClockSettings.WAKE_HOUR)
            self._rest(TownSettings.INN_LINE)
            self._show_wake()
            return
        records.sleep(self.gm.party)
        self._rest(TownSettings.INN_LINE if woke else TownSettings.NAP_LINE)

    def _nap(self) -> None:
        """A nap in Kailo's bed: rested, and the next day (Frankie, 10/25)."""
        records.sleep(self.gm.party)
        self._rest(TownSettings.NAP_LINE)

    def _craving(self, person: dict) -> None:
        """At the end of a named villager's usual line (Frankie, 11/1): a hint that they are in the
        mood for a dish, or, with it in the bag, the ask; yes, and they give a random gift."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menus nearby

        party = self.gm.party
        said = meal_orders.talk(party, person)
        if said is None:
            return
        kind, meal = said
        words = meal_orders.name(meal)
        speaker = person["speaker"]
        if kind == "hint":
            self.text_box.push(random.choice(OrderSettings.HINT_LINES).format(meal=words), speaker=speaker)
            return
        self.text_box.push(OrderSettings.ASK_LINE.format(meal=words), speaker=speaker)

        def give() -> None:
            got = meal_orders.gift(party, meal)
            self.gm.audio.play("chest_open")
            self.text_box.push(OrderSettings.THANKS_LINE, speaker=speaker)
            self.text_box.push(OrderSettings.GAVE_LINE.format(meal=words))
            self.text_box.push(OrderSettings.RECEIVED_LINE.format(item=got))

        self._after_text = lambda: self.gm.scene_stack.push(
            ConfirmScene(self.gm, OrderSettings.ASK_BOX.format(meal=words), on_yes=give))

    def _check_orders(self) -> None:
        """The Meialana's orders (Frankie, 11/1): who ordered what, and Prices; picking one
        delivers it, if the dish is in the bag."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        party = self.gm.party
        found = meal_orders.orders(party)
        if not found:
            self.text_box.push(OrderSettings.NONE_LINE)
            return
        choices = [OrderSettings.ENTRY.format(who=who, meal=meal_orders.name(meal)) for who, meal in found]
        choices += [OrderSettings.PRICES_LABEL, OrderSettings.BACK_LABEL]

        def pick(index: int) -> None:
            if index < len(found):
                who, meal = found[index]
                price = meal_orders.deliver(party, index)
                if price is None:
                    self.text_box.push(OrderSettings.MISSING_LINE.format(meal=meal_orders.name(meal)))
                else:
                    self.gm.audio.play("chest_open")
                    self.text_box.push(OrderSettings.SOLD_LINE.format(
                        meal=meal_orders.name(meal), who=who, price=price))
                    self._after_text = self._check_orders if meal_orders.orders(party) else None
            elif choices[index] == OrderSettings.PRICES_LABEL:
                self._show_prices(self._check_orders)

        self.gm.scene_stack.push(ChoiceScene(self.gm, OrderSettings.ORDERS_ASK, choices, pick,
                                             cancel=len(choices) - 1))

    def _show_prices(self, back, page: int = 0) -> None:
        """What each dish pays, hardest first, PRICES_PAGE a page (the screen is 224 high); More
        turns the page, round and round, Back goes back."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu above

        ranked = sorted(meal_orders.meals(), key=lambda meal: (-meal_orders.pay(meal), meal_orders.name(meal)))
        size = OrderSettings.PRICES_PAGE
        pages = (len(ranked) + size - 1) // size
        rows = [OrderSettings.PRICE_ENTRY.format(meal=meal_orders.name(meal), price=meal_orders.pay(meal))
                for meal in ranked[page * size:(page + 1) * size]]
        extras = ([OrderSettings.MORE_LABEL] if pages > 1 else []) + [OrderSettings.BACK_LABEL]

        def pick(index: int) -> None:
            if index < len(rows) or extras[index - len(rows)] == OrderSettings.MORE_LABEL:
                self._show_prices(back, (page + 1) % pages if index >= len(rows) else page)
            else:
                back()

        self.gm.scene_stack.push(ChoiceScene(self.gm, OrderSettings.PRICES_ASK.format(page=page + 1, pages=pages),
                                             rows + extras, pick, cancel=len(rows + extras) - 1))

    def _boat_menu(self) -> None:
        """The Meialana, its cabin Kailo's kitchen and his bed (Frankie, 10/28): Cook opens
        the pot, Nap rests the party as his bed at home does, Leave does nothing."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

        choices = list(TownSettings.BOAT_CHOICES)
        party = self.gm.party
        if party.flags.get(StorySettings.AFTER_JUMP_FLAG):
            meal_orders.roll_orders(party)
            if meal_orders.orders(party):
                choices.insert(2, OrderSettings.CHECK_LABEL)
        # A save mended before the ready flag existed has only BOAT_FIXED.
        if party.flags.get(SailingSettings.READY_FLAG) or party.flags.get(StorySettings.BOAT_FIXED):
            choices.insert(choices.index("Leave"), "Sail")

        def pick(index: int) -> None:
            if index == 0:
                self._open_pot()
            elif index == 1:
                self._boat_nap()
            elif choices[index] == OrderSettings.CHECK_LABEL:
                self._check_orders()
            elif choices[index] == "Sail":
                self._ask_sail()

        self.gm.scene_stack.push(ChoiceScene(self.gm, TownSettings.BOAT_ASK, choices, pick,
                                             cancel=choices.index("Leave")))

    def _ask_sail(self) -> None:
        """Sail (Frankie, 10/31): the first time, one last "are you sure", Ama marks
        Lanuloa on the map and explains the food on the dock; then the open sea."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menu above

        party = self.gm.party
        if party.flags.get(SailingSettings.LEAVE_FLAG):
            self._set_sail()
            return

        short = sailing.first_voyage_short(party, "Kulāiwi")   # training wheels (Frankie, 11/20)
        if short:
            speaker, _, words = sailing.first_voyage_line(*short).partition(": ")
            self.text_box.push(words, speaker=speaker)
            return

        def pick(index: int) -> None:
            if index == 0:
                party.flags[SailingSettings.LEAVE_FLAG] = True
                if not party.flags.get(MapSettings.HAS_MAP_FLAG):   # given when the boat was mended (11/20); an older save gets it here
                    party.flags[MapSettings.HAS_MAP_FLAG] = True
                    party.inventory[MapSettings.ITEM] = 1   # a key item in the bag (Frankie, 11/17)
                    sailing.know(party, "Kupulau")   # Ama marks the first island
                self._set_sail(SailingSettings.AMA_LINES)

        self.gm.scene_stack.push(ChoiceScene(self.gm, SailingSettings.LEAVE_ASK, ["Yes", "No"], pick, cancel=1))

    def _set_sail(self, lines: tuple[str, ...] = ()) -> None:
        """Push the sea, leaving from the port the boat is moored at (Kulāiwi, or Kupulau,
        Frankie, 11/1); ashore at any port, Kailo is on its pier below the Meialana."""
        from core.scenes.sea_scene import SeaScene  # local: cycle

        def ashore(place: str) -> None:
            from core.overworld_cells import WORLD_LAYOUT  # local, as the rest of the field

            room, (col, row) = SailingSettings.LANDINGS[place]
            self.world.go_to(next(pos for pos, name in WORLD_LAYOUT.items() if name == room))
            self.player.from_dict({"col": col, "row": row, "facing": [0, -1]})
            self._room_sound()
            party = self.gm.party   # the browser demo ends at Kupulau, once a save (Frankie, 11/2)
            if (SailingSettings.BROWSER and place == SailingSettings.DEMO_END_PORT
                    and not party.flags.get(SailingSettings.DEMO_END_FLAG)):
                party.flags[SailingSettings.DEMO_END_FLAG] = True
                self.text_box.push(SailingSettings.DEMO_END_LINE)

        here = next((port for port, (room, _) in SailingSettings.LANDINGS.items()
                     if room == self.world.current_cell_name), "Kulāiwi")
        self.gm.scene_stack.push(SeaScene(self.gm, here, ashore, tuple(lines) + tuple(sailing.set_out_lines(self.gm.party, here))))

    def _boat_nap(self) -> None:
        """A nap aboard: as in the bed, and the date shown at once, since there is no door to walk out of."""
        if daytime.running(self.gm.party):
            self._ask_sleep()
            return
        self._nap()
        if self.gm.party.flags.pop(records.SLEPT_FLAG, False):
            self._show_popup([place for place in (self._place,) if place] + [records.date_text(self.gm.party)])

    def _watch_place(self, dt: float) -> None:
        """Name the place on walking into a new one, and the date on walking out of the
        house after a nap; count the pop-up down (Frankie, 10/25)."""
        self._popup_left = max(0.0, self._popup_left - dt)
        if self._popup_left <= 0:
            self.popup = None
        room = self.world.current_cell_name
        if room == self._place_room:
            return
        was, self._place_room = self._place_room, room
        place = places.name_of(room)
        flags = self.gm.party.flags if self.gm.party else {}
        if was is None or self.story is not None:
            pass
        elif was == places.HOME and flags.pop(records.SLEPT_FLAG, False) and place is not None:
            self._show_popup([place, records.date_text(self.gm.party)])
        elif place is not None and place != self._place:
            self._show_popup([place])
        if place is not None:
            self._place = place

    def _show_popup(self, lines: list[str]) -> None:
        self.popup = lines
        self._popup_left = PlaceSettings.SECONDS

    def _render_popup(self, surface: pygame.Surface) -> None:
        """The place, and the date in the speaker's yellow, in the notices' window at the top center."""
        if not self.popup:
            return
        top = PlaceSettings.TOP
        if TextBox.at_top and not self.text_box.is_done():
            # The dialogue box is up there; the pop-up waits under it.
            top += self.text_box.height
        notices.draw_box(surface, list(self.popup), top)

    def _play_story(self) -> None:
        """Called with the text box closed: show the lines up to the next choice, fight or stage direction, then it."""
        if (self.stage is not None and self.stage.busy()) or self._fade_to is not None or self._wait > 0:
            return
        if self._story_next is None:
            while True:
                step = self.story.next_step()
                if step is None:
                    self._story_next = {"over": True}
                    break
                if "say" in step or "text" in step:
                    slow = self._opening and self.text_box.is_done()
                    self.text_box.push(step["text"], speaker=step.get("say"), fast=step.get("fast", False),
                                       speed=UISettings.OPENING_CHARS_PER_SECOND if slow else step.get("speed"),
                                       hold=step.get("hold", False))
                    if step.get("say") == StorySettings.WAKE_GIFT_FROM and step.get("if") == StorySettings.STEW_SAVED:
                        self._wake_gift()
                    continue
                self._story_next = step
                break
            if "fight" in self._story_next and self.story.name == "wake":
                self._join_at_wake()
            elif "fight" in self._story_next and self.story.name == StorySettings.CLEARING_SCENE:
                self._join_at_clearing()
            if not self.text_box.is_done():
                return
        step, self._story_next = self._story_next, None
        if "room" in step:
            # The scene moves to a room: the stage starts empty there, but
            # for Kailo where he stands if he is in that room already.
            from core.overworld_cells import WORLD_LAYOUT  # local: as start_in_room

            here = self.world.current_cell_name == step["room"]
            self.world.go_to(next(pos for pos, name in WORLD_LAYOUT.items() if name == step["room"]))
            # The room's own monsters, not the last room's (none walk the rooms scenes play in today).
            self._place_monsters()
            kinds = self.gm.data.load("field_monsters")
            # A foe stands as its monster's kind on the map, or its sprite's (the wake's dwende).
            foes = {foe["name"]: kinds.get(foe["monster"]) or kinds[foe["sprite"]] for s in self.story.steps
                    for foe in s.get("fight", []) if foe["monster"] in kinds or foe["sprite"] in kinds}
            self.stage = Stage(cast(self.story.name), foes)
            self.stage.way_out = self._way_out
            self.stage.play = self.gm.audio.play
            self.stage.free = lambda col, row: not self.world.is_wall(col, row) and 0 <= col < OverworldSettings.COLS and 0 <= row < OverworldSettings.ROWS
            if here:
                self.stage.do({"stand": [{"who": StorySettings.PLAYER, "col": self.player.col,
                                          "row": self.player.row, "facing": tuple(self.player.facing)}]})
        elif any(key in step for key in ("stand", "move", "turn", "fall")):
            if self.stage is not None:
                self.stage.do(step)
        elif "fade" in step:
            self._fade_to = 1.0 if step["fade"] == "out" else 0.0
        elif "wait" in step:
            self._wait = step["wait"]
        elif "song" in step:
            self.story.song = step["song"]
        elif "choice" in step:
            from core.scenes.choice_scene import ChoiceScene  # local, as the menu below

            options = step["options"]
            self.gm.scene_stack.push(ChoiceScene(
                self.gm, step["choice"], [label for label, _ in options],
                lambda index: self.story.choose(options[index][1]),
            ))
        elif "fight" in step:
            from core.scenes.battle_scene import BattleScene  # local, as _start_fight

            # The taro patch's fight has Hina's tutorial (Frankie, 10/26).
            self._story_fight = BattleScene(self.gm, enemies=step["fight"], can_escape=False,
                                            in_town=self._in_town(), story=True,
                                            tutorial=self.story.name == TutorialSettings.SCENE,
                                            music=self.story.song or (StorySettings.CLEARING_MUSIC if self.story.name == StorySettings.CLEARING_SCENE else None), swap_lesson=self._swap_lesson(),
                                            opening=step.get("opening"),
                                            win_flag=StorySettings.CLEARING_WIN_FLAG if self.story.name == StorySettings.CLEARING_SCENE else None,
                                            cast_lesson=self.story.name == StorySettings.CLEARING_SCENE)
            fight_swirl.arm(self.gm, self._story_fight)
            self.gm.scene_stack.push(self._story_fight)
        else:
            self._story_over()

    def skip_cutscene(self) -> None:
        """Play the rest of the scene at once, behind black (Frankie, 10/28; ``core/skip_cutscene.py``).

        It runs through the game's own steps, a frame's worth of them at a
        time, so whatever the scene sets is set; it stops when the scene
        ends, or where a fight (or anything else) comes up on top.
        """
        self.skipping = self.story

    def _skip_ahead(self) -> None:
        """Up to ``StorySettings.SKIP_STEPS`` frames of the scene, text paged at once."""
        for _ in range(StorySettings.SKIP_STEPS):
            if self.story is not self.skipping or self.gm.scene_stack.top is not self or self._card is not None:
                self.skipping = None
                return
            self.text_box.update(10.0)
            self.text_box.advance()
            self._frame(1 / 60)

    def _swap_lesson(self) -> str | None:
        """At the wake, whoever came along and sits on the bench: Hina shows the player Swap."""
        if self.story.name != StorySettings.WAKE_SCENE:
            return None
        return StorySettings.WAKE_BENCH if self.gm.party.find(StorySettings.WAKE_BENCH) is not None else None

    def _wake_gift(self) -> None:
        """The stew saved, the chief thanks Kailo at the wake with a rare drop or relic (Frankie, 10/26)."""
        from settings import ItemSettings

        item = random.choice(ItemSettings.EQUIP_DROPS + StorySettings.WAKE_GIFT_EXTRA)
        inventory = self.gm.party.inventory
        inventory[item] = inventory.get(item, 0) + 1
        self.gm.audio.play("chest_open")
        self.text_box.push(StorySettings.WAKE_GIFT_LINE.format(item=ItemSettings.NAMES.get(item, item)))

    def _join_at_wake(self) -> None:
        """Before the fight Tawiri joins fourth, with her pop-up; whoever else came sits on the bench."""
        from core.factories import party_member_from_data
        from core.shared import by_id

        party = self.gm.party
        if party.find(StorySettings.WAKE_JOINS) is not None:
            return
        party.add(party_member_from_data(by_id("characters")[StorySettings.WAKE_JOINS]))
        lore.unlock(party, "event tawiri_joins")
        bench = party.find(StorySettings.WAKE_BENCH)
        if bench is not None:
            party.members.remove(bench)
            party.members.append(bench)
        self.gm.audio.play("hit_sparkle_1")
        self.text_box.push(StorySettings.WAKE_JOIN_LINE)

    def _join_at_clearing(self) -> None:
        """Before the Aghoy fight Maika joins, with his pop-up, for that fight only (Frankie, 11/12)."""
        from core.factories import party_member_from_data
        from core.shared import by_id

        party = self.gm.party
        if party.find(StorySettings.JOINER) is not None:
            return
        party.add(party_member_from_data(by_id("characters")[StorySettings.JOINER]))
        self.gm.audio.play("hit_sparkle_1")

    def _way_out(self, actor) -> list[tuple[int, int]]:
        """The stops that walk ``actor`` off the room by its open doorway nearest the village (Frankie, 11/15).

        Each open side is judged by the room past it: how far it is, on the world's grid, from the
        nearest village room. The way runs along the path to that doorway and one tile past the edge.
        """
        from core import generated
        from core.overworld_cells import WORLD_LAYOUT  # local: as the rest of the field

        grid, here = self.world.current_grid, self.world.current_pos
        homes = [pos for pos, name in WORLD_LAYOUT.items() if name in BackgroundSettings.TOWN_ROOMS] or [here]
        best = None
        for rank, side in enumerate(("south", "west", "east", "north")):
            spots = generated.open_spots(grid, side)
            if not spots:
                continue
            dx, dy = generated.SIDES[side]
            there = (here[0] + dx, here[1] + dy)
            key = (min(abs(there[0] - h[0]) + abs(there[1] - h[1]) for h in homes), rank)
            if best is None or key < best[0]:
                best = (key, side, spots)
        if best is None:
            return []
        _, side, spots = best
        tiles = [generated.edge_tiles(side)[i] for i in spots]
        col, row = min(tiles, key=lambda t: abs(t[0] - actor.col) + abs(t[1] - actor.row))
        if side in ("north", "south"):
            return [(col, -1 if side == "north" else OverworldSettings.ROWS)]
        return [(actor.col, row), (-1 if side == "west" else OverworldSettings.COLS, row)]

    def _clearing_over(self, flags: set) -> None:
        """He is found: the 'awa he gave, his asking not to tell, and his stall back (Frankie, 11/12)."""
        party = self.gm.party
        party.remove(StorySettings.JOINER)   # never left in the party, whatever the scene did
        bag = party.inventory
        bag[StorySettings.CLEARING_GIFT] = bag.get(StorySettings.CLEARING_GIFT, 0) + 1
        party.flags[StorySettings.FOUND_FLAG] = True
        party.flags[StorySettings.MISSING_FLAG] = False
        party.flags[f"met_{StorySettings.JOINER}"] = True
        party.flags[StorySettings.JOINER_ASKED_FLAG] = True   # the scene was his asking not to tell her
        lore.unlock(party, f"event met_{StorySettings.JOINER}")
        self.gm.audio.play("learned")
        self.world.go_to(self.world.current_pos)   # his stall is gone from the room with him

    def _story_over(self) -> None:
        """A scene's part is over: a lost story fight again; else on with the demo.

        Losing the taro patch never gets here: it is game over (Frankie, 11/13).
        """
        if self.story.part == LOSE and self.story.name != "taro_patch":
            self.story.retry()
            return
        part = self.story.part
        name, flags, ended, self.story = self.story.name, self.story.flags, self.story.ended, None
        lore.naming = False
        self._leave_stage()
        party = self.gm.party
        if name == "taro_patch":
            party.flags[StorySettings.TARO_FLAG] = True
            party.flags[StorySettings.STEW_LOST_FLAG] = part == LOSE
            # The boars knocked the pot over: the stew is a quest now (Frankie, 10/30).
            party.flags[StewSettings.QUEST_FLAG] = True
            # Hina goes home, out of the party until Kailo comes to her (Frankie, 10/23).
            party.leave(StorySettings.HOME_MEMBER)
            self._sync_joined()
        elif name in (StorySettings.HOME_SCENE, StorySettings.WOODS_SCENE):
            if party.rejoin(StorySettings.HOME_MEMBER) is None:
                from core.factories import party_member_from_data
                from core.shared import by_id

                party.add(party_member_from_data(by_id("characters")[StorySettings.HOME_MEMBER]))
            first = not party.flags.get(StorySettings.HOME_FLAG)
            party.flags[StorySettings.HOME_FLAG] = True
            self._sync_joined()
            if first:
                # Her pop-up, as Maika's (Frankie, 10/27).
                self.text_box.push(join_line(StorySettings.HOME_MEMBER))
                self.gm.audio.play("hit_sparkle_1")
            lore.unlock(party, "event hina_home")
        elif name == StorySettings.JOINER_MEETS:
            person = self._joiner()
            if person is not None:
                lore.unlock(party, f"event met_{person['joins']}")
                # Sent by his sister already: he asks first, then his shop opens.
                if party.flags.get(StorySettings.SISTER_DEAL_FLAG):
                    self.begin_story(StorySettings.JOINER_ASKS)
                else:
                    self._open_joiner_shop(person)
        elif name == StorySettings.JOINER_ASKS:
            party.flags[StorySettings.JOINER_ASKED_FLAG] = True
            person = self._joiner()
            if person is not None:
                self._open_joiner_shop(person)
        elif name == StorySettings.JOINER_CROSS:
            # He stays; his shop is as it was.
            pass
        elif name in (StorySettings.JOINER_JOINS, StorySettings.JOINER_JOINS_LATE):
            # The lie scene is over; he asks whether Kailo wants him along (Frankie, 11/11).
            party.flags[StorySettings.JOINER_INVITED_FLAG] = True
            self.begin_story(StorySettings.JOINER_INVITES)
        elif name == StorySettings.JOINER_INVITES:
            if StorySettings.JOINER_YES in flags:
                self._joiner_joins()
        elif name == BankSettings.CHARM_SCENE:
            # Maika charmed her (Frankie, 11/12): once, and then she makes her offer at his price.
            party.flags[BankSettings.CHARM_FLAG] = True
            self._noelani_wallet()
        elif name == StorySettings.SISTER_ASKS:
            party.flags[StorySettings.SISTER_DEAL_FLAG] = True
            # Maika is gone from his stall, digging in the Lost Woods, until Kailo finds him (Frankie, 11/12).
            party.flags[StorySettings.MISSING_FLAG] = True
        elif name == StorySettings.SISTER_REPORT:
            # The lie: Maika joins on his next talk, no soy sauce. The truth: the soy sauce now,
            # and Maika, his stall and Miki are gone from their rooms (Frankie, 11/1).
            party.flags[StorySettings.JOINER_ASKED_FLAG] = True  # no asking-not-to-tell scene after the telling
            if StorySettings.SISTER_TRUTH in flags:
                party.flags[StorySettings.SISTER_TOLD_FLAG] = True
                party.inventory[StorySettings.SOY_SAUCE] = (party.inventory.get(StorySettings.SOY_SAUCE, 0)
                                                           + StorySettings.SISTER_SOY_COUNT)
                self.text_box.push(StorySettings.SISTER_SOY_LINE)
                self.gm.audio.play("learned")
            else:
                party.flags[StorySettings.SISTER_LIED_FLAG] = True
        elif name == StorySettings.ASK_SCENE:
            # Fight now, or a few steps back the way they came, to heal and save first.
            if StorySettings.ASK_FIGHT in flags and self._asking in self.monsters:
                self._start_fight(self._asking)
            else:
                dx, dy = self.player.facing
                self._walk_back = [(-dx, -dy)] * StorySettings.BACK_STEPS
        elif name == StorySettings.EAST_SCENE:
            # Back out of the opening, west, the way in.
            self._walk_back = [(-1, 0)] * StorySettings.VILLAGE_BACK_STEPS
        elif name == StorySettings.CLEARING_SCENE:
            self._clearing_over(flags)
        elif name in (StorySettings.DEEP_HINA, StorySettings.DEEP_MAIKA, StorySettings.DEEP_HINA_MISSING):
            # Either names Lanu's beasts, which finds her page (Frankie, 10/25).
            party.flags[f"story_{name}"] = True
            if name == StorySettings.DEEP_HINA_MISSING:
                party.flags[f"story_{StorySettings.DEEP_HINA}"] = True   # it was her warning
            lore.unlock(party, "event deep_woods")
            # Kailo turns around and takes a few steps away from the entrance (Frankie, 11/12).
            dx, dy = getattr(self, "_deep_facing", (-1, 0))
            self._walk_back = [(-dx, -dy)] * StorySettings.DEEP_BACK_STEPS
        elif name == StorySettings.TUSK_SCENE:
            # The tusk is hers now; the wake waits in the chief's room.
            party.inventory.pop(StorySettings.TUSK, None)
            party.flags[StorySettings.TUSK_FLAG] = True
        elif name == StewSettings.SCENE:
            # The stew is a key item now (Frankie, 10/30); if the Great Boar is already
            # beaten, the night falls.
            party.inventory[StewSettings.KEY_ITEM] = 1
            if stew.night_falls(party):
                party.flags[StorySettings.NIGHT_FLAG] = True
                self.text_box.push(StewSettings.DUSK_LINE)
        elif name == StorySettings.SEED_SCENE:
            party.flags[StorySettings.SEED_FLAG] = True
            if "first lontar due" in flags and "kailo along" in flags:
                lontar_talk.take(party)  # the scene played it; mark it said
            self._slot_learned(StorySettings.HOME_MEMBER, "seed")
            self.gm.audio.play("learned")
            self._hina_says_wait()
        elif name.startswith("kaigara_"):
            self._kaigara_over(name, flags)
        elif name == "wake":
            # The wake ends the demo (Frankie, 10/23): it faded out on its last line, and
            # its End is on the black screen until confirm goes to the title. Hina named
            # Shaka there, and Maika, if he came, Lanu.
            lore.unlock(party, "event wake_shaka")
            if f"{StorySettings.WAKE_BENCH} along" in flags:
                lore.unlock(party, "event wake_lanu")
            if StorySettings.DEMO_ONLY:
                self._dark, self._card = 1.0, ended
            else:
                # The game goes on past the demo (Frankie, 10/31): Ama pulls Kailo out.
                self._dark = 1.0
                self.begin_story(StorySettings.AFTER_JUMP_SCENE)
        elif name == StorySettings.AFTER_JUMP_SCENE:
            self._next_morning(ended)

    def _swap_walker(self, step: int) -> None:
        """L and R: the next or last of the three who fight is the striker and walks the map
        (Frankie, 11/1; only the three who fight, 11/14). The sprite changes, with no words on screen
        (Frankie, 11/14); the people here still talk to Kailo."""
        ids = [member.id for member in self.gm.party.members][:BattleSettings.FIGHTERS]
        if len(ids) < 2 or self.player._step_active or self._strike is not None:
            return
        here = ids.index(self.player.walker) if self.player.walker in ids else 0
        # A knocked out member is passed over: they never walk (Frankie, 11/15).
        for hop in range(1, len(ids)):
            pick = ids[(here + step * hop) % len(ids)]
            if self.gm.party.find(pick).current_hp > 0:
                self.player.walker = pick
                return

    def _striker_weapon(self) -> dict:
        """The swing numbers for the weapon the striker holds (``FieldStrikeSettings.BY_TYPE``)."""
        member = self.gm.party.find(self.player.shown)
        held = by_id("weapons").get((member.weapon if member else None) or "")
        return FieldStrikeSettings.BY_TYPE.get(held["type"] if held else "", FieldStrikeSettings.DEFAULT)

    def _field_strike(self) -> None:
        """B on the map: the striker swings their weapon in front of them (Frankie, 11/14).

        Melee reaches ``reach`` tiles at the end of its windup; a bow's arrow flies. The first monster
        met starts a fight (``_land_strike``). Nothing happens mid-step, in a talk, with the line out or
        while another swing is on.
        """
        if (self._strike is not None or self._strike_rest > 0 or self._swing > 0 or self.player._step_active
                or self._line is not None or self.tool_wheel.open or self.stage is not None):
            return
        member = self.gm.party.find(self.player.shown)
        if member is None or member.current_hp <= 0:
            self.gm.audio.play("cant")
            return
        weapon = self._striker_weapon()
        self._strike = {"t": 0.0, "dir": self.player.facing, "who": member.id, **weapon}
        # Kailo punches (Frankie, 11/15): his own pose, and a sound only when the blow lands. The others
        # keep the line and the whoosh of a miss.
        self._strike["punch"] = member.id == FieldStrikeSettings.PUNCHER and not weapon["shot"]
        self._punches = getattr(self, "_punches", 0) + 1   # up and down: his two step frames, one arm each
        self._strike["arm"] = 1 if self._punches % 2 else 3
        if not self._strike["punch"]:
            self.gm.audio.play("hit_miss")

    def _strike_reach(self, strike: dict) -> float:
        """How many tiles in front the swing has reached: all at its windup's end, or the arrow's flight."""
        if strike["shot"]:
            return min(strike["reach"], strike["t"] * FieldStrikeSettings.SHOT_TILES_PER_SECOND)
        return strike["reach"] if strike["t"] >= strike["seconds"] * FieldStrikeSettings.WINDUP_SHARE else 0

    def _tick_strike(self, dt: float) -> None:
        """Advance the swing; the first monster in its path is struck, a wall stops it."""
        self._strike_rest = max(0.0, self._strike_rest - dt)
        strike = self._strike
        if strike is None:
            return
        strike["t"] += dt
        reach = self._strike_reach(strike)
        dx, dy = strike["dir"]
        for step in range(1, int(reach) + 1):
            tile = (self.player.col + dx * step, self.player.row + dy * step)
            if self.world.is_wall(*tile):
                # A fist or a blade against a tree shakes it as a chop does (Frankie, 11/24 night), once a swing.
                grid = self.world.current_grid
                if (not strike["shot"] and not strike.get("shook") and self.world.tile_at(*tile) == OverworldSettings.WALL_CHAR
                        and self.world.building_at(*tile) is None and not canopy.is_canopy(grid, *tile)):
                    strike["shook"] = True
                    self._shake, self._shake_left = tile, ToolSettings.SHAKE_SECONDS
                    self._knock_fruit(*tile)
                    self.gm.audio.play("chop")
                break
            hit = next((m for m in self.monsters if tile in m.tiles() and self._reachable(m)
                        and m.spot.get("kind") != StorySettings.ASK_KIND), None)
            if hit is not None and not getattr(self.gm, "no_fights", False):
                self._strike = None
                self._strike_rest = FieldStrikeSettings.COOLDOWN_SECONDS
                self._land_strike(hit, strike)
                return
        if strike["t"] >= strike["seconds"] + (strike["reach"] / FieldStrikeSettings.SHOT_TILES_PER_SECOND if strike["shot"] else 0):
            self._strike = None
            self._strike_rest = FieldStrikeSettings.COOLDOWN_SECONDS

    def _land_strike(self, monster: FieldMonster, strike: dict) -> None:
        """The swing hit: the fight opens with the striker's blow, and a preemptive strike when it came
        from behind a monster that had not noticed the party."""
        if strike.get("punch"):
            self.gm.audio.play("field_punch")
        facing = (-1, 0) if monster.facing_left else (1, 0)
        from_behind = tuple(strike["dir"]) == facing
        self._catch(monster, opening="preemptive" if from_behind and not monster.noticed else None,
                    blow=strike["who"])

    def _punch_pose(self) -> pygame.Surface | None:
        """The frame of Kailo's punch to draw in place of his walker, or None when he is not punching.

        The frames play across the swing's length, so the arm is out (frame 2) as the blow lands at
        ``WINDUP_SHARE``; a hit ends the swing, and the pose with it.
        """
        strike = self._strike
        if strike is None or not strike.get("punch") or strike["dir"][0] == 0:
            return None   # up and down use his walk's step frame (``_punch_frame``)
        global _PUNCH_SHEET
        if _PUNCH_SHEET is None:
            path = os.path.join(sprite_files.character_dir(FieldStrikeSettings.PUNCHER), "punch.png")
            _PUNCH_SHEET = pygame.image.load(path).convert_alpha()
        column = OverworldPlayerSettings.SHEET_COLUMNS.get(tuple(strike["dir"]), 0)
        frames = FieldStrikeSettings.PUNCH_FRAMES
        row = min(frames - 1, int(min(1.0, strike["t"] / strike["seconds"]) * frames))
        return _PUNCH_SHEET.subsurface((column * 32, row * 32, 32, 32))

    def _chop_pose(self) -> pygame.Surface | None:
        """The frame of Kailo's axe swing to draw in place of his walker, or None (Frankie, 11/15).

        ``chop.png`` has the punch's layout: a 32 by 32 cell per facing, ``CHOP_FRAMES`` frames down. The
        frames play across the chop's swing, so it lasts as long as before. North has no axe drawn, so
        facing up he stays his walker, as before. Only Kailo swings the ko'i like this.
        """
        if self._swing <= 0 or self._chop_total <= 0 or self.player.shown != FieldStrikeSettings.PUNCHER:
            return None
        global _CHOP_SHEET
        if _CHOP_SHEET is None:
            path = os.path.join(sprite_files.character_dir(FieldStrikeSettings.PUNCHER), "chop.png")
            _CHOP_SHEET = pygame.image.load(path).convert_alpha() if os.path.exists(path) else pygame.Surface((0, 0))
        column = OverworldPlayerSettings.SHEET_COLUMNS.get(tuple(self.player.facing), 0)
        if _CHOP_SHEET.get_width() < (column + 1) * 32:
            return None
        frames = FieldStrikeSettings.CHOP_FRAMES
        row = min(frames - 1, int((1.0 - self._swing / self._chop_total) * frames))
        cell = _CHOP_SHEET.subsurface((column * 32, row * 32, 32, 32))
        return cell if pygame.mask.from_surface(cell).count() else None   # an empty column (north): no pose

    def _punch_frame(self) -> int | None:
        """Facing up or down, the punch is Kailo's own step frame, held (Frankie, 11/15: the walk's
        step already looks like a punch, frames 1 and 3, one arm each, alternating). None when he is not punching that way."""
        strike = self._strike
        if strike is None or not strike.get("punch") or strike["dir"][0] != 0:
            return None
        return strike["arm"] if strike["t"] >= strike["seconds"] * 0.2 else None

    def _render_strike(self, surface: pygame.Surface, offset: tuple[int, int]) -> None:
        """The swing's slash, or the arrow in flight, and the striker's name just after L or R."""
        tile = GridSettings.TILE_SIZE
        px = OverworldSettings.X + offset[0] + self.player.col * tile
        py = OverworldSettings.Y + offset[1] + self.player.row * tile
        strike = self._strike
        if strike is not None and not strike.get("punch"):
            dx, dy = strike["dir"]
            cx, cy = px + tile // 2, py + tile // 2
            if strike["shot"]:
                far = self._strike_reach(strike)
                ax, ay = cx + dx * int((0.5 + far) * tile), cy + dy * int((0.5 + far) * tile)
                pygame.draw.line(surface, FieldStrikeSettings.ARROW_COLOR, (ax, ay), (ax - dx * 5, ay - dy * 5), 1)
                pygame.draw.rect(surface, FieldStrikeSettings.SLASH_COLOR, (ax - 1, ay - 1, 2, 2))
            else:
                share = min(1.0, strike["t"] / strike["seconds"])
                length = int(tile * (0.4 + strike["reach"] * 0.6))
                # A slash that sweeps across the front, a short bar turning about the striker.
                sweep = (share - 0.5) * 1.6
                ex = cx + int((dx * length) + (dy * sweep * length))
                ey = cy + int((dy * length) + (dx * sweep * length))
                pygame.draw.line(surface, FieldStrikeSettings.SLASH_COLOR, (cx + dx * 4, cy + dy * 4), (ex, ey), 2)

    def _next_morning(self, words: str) -> None:
        """After the meeting in the chief's hut: the night is over, Kailo wakes by his bed.

        The scene faded out on its last line; its End's words ("The next morning.")
        show on black, and the room fades in once they are read.
        """
        from core.overworld_cells import WORLD_LAYOUT  # local: as the stage's Room

        party = self.gm.party
        # The night flag stays, so whatever came after it stays; is_night() reads this one too.
        party.flags[StorySettings.AFTER_JUMP_FLAG] = True
        # Found on the beach, or never given: either way the tusk is Kailo's to carry (Frankie, 11/5).
        party.inventory[StorySettings.TUSK] = 1
        room, col, row, facing = StorySettings.AFTER_JUMP_WAKE
        self._sync_joined()
        self.world.go_to(next(pos for pos, name in WORLD_LAYOUT.items() if name == room))
        self.player.from_dict({"col": col, "row": row, "facing": list(facing)})
        self._dark = 1.0
        if words:
            self.text_box.push(words)
        self._after_text = lambda: setattr(self, "_fade_to", 0.0)

    def _talk_to_kame(self) -> None:
        """The Kame, or his table: meeting him the first time, which finds his Lore page; then his questions."""
        player = next((p for p in self.world.people if p.get("kaigara") and p.get("bets")), None)
        if player is not None:
            self._talk_to_bettor(player)
            return
        if self.gm.party.flags.get(KaigaraSettings.MET_FLAG):
            self.begin_story(KaigaraSettings.MENU_SCENE)
            return
        lore.unlock(self.gm.party, KaigaraSettings.MET_EVENT)
        self.begin_story(KaigaraSettings.MEET_SCENE)

    def _talk_to_bettor(self, person: dict) -> None:
        """Kupulau's Bandari (Frankie, 11/1): he plays Kaigara for kupang, up to ``bets``, and the
        player picks the stake; with no kupang he says so, and No leaves it."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menus above

        party, name = self.gm.party, person["speaker"]
        if party.kupang <= 0:
            self.text_box.push(KaigaraSettings.STAKE_NONE, speaker=name)
            return
        top = min(person["bets"], party.kupang)
        stakes = list(range(1, top + 1))

        def pick(index: int) -> None:
            if index >= len(stakes):
                self.text_box.push(KaigaraSettings.STAKE_NO_LINE, speaker=name)
                return
            self._play_for_kupang(person, stakes[index])

        def ask() -> None:
            self.gm.scene_stack.push(ChoiceScene(
                self.gm, KaigaraSettings.STAKE_ASK, [str(n) for n in stakes] + [KaigaraSettings.STAKE_NO], pick,
                cancel=len(stakes)))

        self.text_box.push(KaigaraSettings.STAKE_INTRO.format(max=person["bets"]), speaker=name)
        self._after_text = ask

    def _play_for_kupang(self, person: dict, stake: int) -> None:
        """One game against the Bandari for ``stake`` kupang: the winner has it, a draw pays nobody."""
        from core.scenes.kaigara_scene import KaigaraScene  # local, as the battle
        from systems import kaigara

        party, name = self.gm.party, person["speaker"]

        def done(winner: str | None) -> None:
            lore.unlock(party, kaigara.PLAYED_EVENT)
            if winner == kaigara.BLACK:
                party.kupang += stake
                self.gm.audio.play("hit_sparkle_1")
                line = KaigaraSettings.STAKE_WIN
            elif winner is None:
                line = KaigaraSettings.STAKE_DRAW
            else:
                party.kupang = max(0, party.kupang - stake)
                line = KaigaraSettings.STAKE_LOSE
            self.text_box.push(line.format(stake=stake), speaker=name)

        self.gm.scene_stack.push(KaigaraScene(self.gm, on_done=done, opponent=name, smart=True, stake=stake))

    def _kaigara_over(self, name: str, flags: set) -> None:
        """One of the Kame's scenes is over: on to his questions, a game, or an answer."""
        if name == KaigaraSettings.MEET_SCENE:
            self.gm.party.flags[KaigaraSettings.MET_FLAG] = True
            self.begin_story(KaigaraSettings.MENU_SCENE)
        elif name == KaigaraSettings.MENU_SCENE:
            asked = next((q for q in KaigaraSettings.QUESTIONS if q in flags), None)
            if KaigaraSettings.PLAY in flags:
                self._ask_kaigara_game()
            elif asked is not None:
                lore.unlock(self.gm.party, f"event kaigara_{asked}")
                self.begin_story(f"kaigara_{asked}")
        elif name == KaigaraSettings.STAKES_SCENE:
            if KaigaraSettings.FRIENDLY in flags:
                self._play_kaigara()
            elif KaigaraSettings.BET in flags:
                self.begin_story(KaigaraSettings.BET_ASK_SCENE)
            else:
                self.begin_story(KaigaraSettings.MENU_SCENE)
        elif name == KaigaraSettings.FRIENDLY_SCENE:
            self._play_kaigara()
        elif name == KaigaraSettings.BET_ASK_SCENE:
            self._pick_bet()
        elif name == KaigaraSettings.BET_NEVER_SCENE:
            self.begin_story(KaigaraSettings.MENU_SCENE)
        elif name in KaigaraSettings.BET_SCENES.values():
            # The pule changed hands when the game ended; say how much, once his words are said.
            note, self._kame_note = getattr(self, "_kame_note", ""), ""
            if note:
                self.text_box.push(note)
        elif name.removeprefix("kaigara_") in KaigaraSettings.QUESTIONS:
            self.begin_story(KaigaraSettings.MENU_SCENE)

    def _ask_kaigara_game(self) -> None:
        """Play was picked. Before the first win, the game as ever; after it (the kupang is won), a friendly
        game or a bet for pule (Frankie, 11/20), and with no pule to bet only the friendly game."""
        from systems import kaigara

        party = self.gm.party
        if not kaigara.bets_open(party):
            self._play_kaigara()
        elif kaigara.bet_cap(party) <= 0:
            self.begin_story(KaigaraSettings.FRIENDLY_SCENE)
        else:
            self.begin_story(KaigaraSettings.STAKES_SCENE)

    def _pick_bet(self) -> None:
        """How many pule: the count picker, 1 up to 100 and what the wallet carries; 0 or B is no bet."""
        from core.scenes.count_scene import CountScene
        from systems import kaigara

        def pick(amount: int | None) -> None:
            if not amount:
                self.begin_story(KaigaraSettings.BET_NEVER_SCENE)
                return
            self._play_kaigara_for_pule(min(amount, kaigara.bet_cap(self.gm.party)))

        self.gm.scene_stack.push(CountScene(self.gm, KaigaraSettings.BET_ASK, kaigara.bet_cap(self.gm.party), pick))

    def _play_kaigara_for_pule(self, bet: int) -> None:
        """A game against Gajumaru for ``bet`` pule: the winner has it, a draw gives it back, resigning loses."""
        from core.scenes.kaigara_scene import KaigaraScene  # local, as the battle
        from systems import kaigara

        party = self.gm.party

        def done(winner: str | None) -> None:
            moved = kaigara.settle_bet(party, winner, bet)
            kaigara.settle(party, winner)
            scene = KaigaraSettings.BET_SCENES["win" if winner == kaigara.BLACK
                                               else "draw" if winner is None else "lose"]
            if winner == kaigara.BLACK:
                self.gm.audio.play("hit_sparkle_1")
                note = KaigaraSettings.BET_WON.format(pule=moved)
                if moved < bet:
                    note += " " + KaigaraSettings.BET_FULL
            elif winner is None:
                note = ""
            else:
                note = KaigaraSettings.BET_PAID.format(pule=-moved)
            self._kame_note = note
            self.begin_story(scene)

        self.gm.scene_stack.push(KaigaraScene(self.gm, on_done=done, stake=bet))

    def _play_kaigara(self) -> None:
        """A game against the Kame; when it is over, the Lore pages, the prize and his line after."""
        from core.scenes.kaigara_scene import KaigaraScene  # local, as the battle
        from systems import kaigara

        def done(winner: str | None) -> None:
            first = kaigara.settle(self.gm.party, winner)
            if first:
                self.gm.audio.play("hit_sparkle_1")
            self.begin_story(KaigaraSettings.FIRST_WIN_SCENE if first
                             else KaigaraSettings.WIN_SCENE if winner == kaigara.BLACK
                             else KaigaraSettings.DRAW_SCENE if winner is None
                             else KaigaraSettings.LOSE_SCENE)

        self.gm.scene_stack.push(KaigaraScene(self.gm, on_done=done))

    def _leave_stage(self) -> None:
        """The scene is over: Kailo stays where the stage left him; everyone else is gone.

        Left on a doorway facing out, he goes through the door (Hina's scene).
        """
        if self.stage is None:
            return
        kailo = self.stage.actors.get(StorySettings.PLAYER)
        if kailo is not None and not kailo.off():
            self.player.from_dict({"col": kailo.col, "row": kailo.row, "facing": list(kailo.facing)})
            arrived = self.world.warp(kailo.col, kailo.row, kailo.facing)
            if arrived is not None:
                self.player.from_dict({"col": arrived[0], "row": arrived[1], "facing": list(kailo.facing)})
        self.stage = None

    def _hina_catches_up(self) -> bool:
        """Kailo in the room before the Great Boar's without having been to Hina's house: she runs after him."""
        party = self.gm.party
        return (self.world.current_cell_name == StorySettings.WOODS_ROOM and not self.player._step_active
                and party.flags.get(StorySettings.TARO_FLAG) and not party.flags.get(StorySettings.HOME_FLAG)
                and party.find(StorySettings.HOME_MEMBER) is None)

    def _deep_woods_warning(self) -> str | None:
        """At any way into the Lost Woods (``DEEP_ENTRANCES``), walking in: Maika's warning if he is along, else Hina's, each once (Frankie, 10/25)."""
        party = self.gm.party
        if self.player._step_active:
            return None
        here = (self.world.current_cell_name, self.player.col, self.player.row, tuple(self.player.facing))
        if not any(room == here[0] and col in (None, here[1]) and row in (None, here[2]) and facing == here[3]
                   for room, col, row, facing in StorySettings.DEEP_ENTRANCES):
            return None
        if here[0] == StorySettings.VILLAGE_ROOM and self._east_way_blocked():
            return None   # Maika's own warning plays there, before he goes missing
        if party.find(StorySettings.JOINER) is not None:
            scene = StorySettings.DEEP_MAIKA
        elif party.find(StorySettings.HOME_MEMBER) is not None:
            scene = StorySettings.DEEP_HINA
        else:
            return None
        if party.flags.get(f"story_{scene}") or (scene == StorySettings.DEEP_HINA
                                                   and party.flags.get(f"story_{StorySettings.DEEP_HINA_MISSING}")):
            return None
        if scene == StorySettings.DEEP_HINA and party.flags.get(StorySettings.MISSING_FLAG):
            scene = StorySettings.DEEP_HINA_MISSING   # "Maika might be, though" (Frankie, 11/12)
        if party.flags.get("beaten:Tandayag na Opon"):
            # The warning says the Great Boar is north; beaten, it only sends the lore page (Mark's Episodes 5 to 7, 11/8).
            party.flags[f"story_{scene}"] = True
            lore.unlock(party, "event deep_woods")
            return None
        self._deep_facing = here[3]   # he walks back out the way he came in
        return scene

    def _east_way_blocked(self) -> bool:
        """Maika is at his stall and has not gone missing yet: he warns off the way east from his room (Frankie, 11/12)."""
        flags = self.gm.party.flags
        return (not flags.get(StorySettings.MISSING_FLAG) and not flags.get(StorySettings.FOUND_FLAG)
                and not flags.get(StorySettings.SISTER_TOLD_FLAG) and self._joiner() is not None)

    def _east_way_turn(self) -> str | None:
        """In the opening east of Maika's room before he goes missing: his warning from the stall, every time."""
        if (self.world.current_cell_name != StorySettings.VILLAGE_ROOM or self.player._step_active
                or self._walk_back or self.player.col != StorySettings.VILLAGE_COL
                or tuple(self.player.facing) != (1, 0)):
            return None
        return StorySettings.EAST_SCENE if self._east_way_blocked() else None

    def _render_night(self, surface: pygame.Surface) -> None:
        """The hour's light outside: the Super Nintendo's color math over the room (``systems/daytime``)."""
        if self.world.current_pos[1] >= INSIDE_ROW:
            return
        daytime.apply(surface, pygame.Rect(OverworldSettings.X, OverworldSettings.Y,
                                           OverworldSettings.PIXEL_W, OverworldSettings.PIXEL_H),
                      daytime.hour(self.gm.party))

    # THE GARDEN AND THE POT: Hina plants, Maika grows, Kailo cooks
    # (Frankie, 10/22; systems/garden.py, core/scenes/craft_scene.py)
    # ------------------------------------------------------------------

    def _talk_requester(self, person: dict, request: dict) -> None:
        """Pono's widow (Frankie, 10/30): she hints at a dish; with it in the bag Kailo gives it,
        and she gives him the 'O'o, once."""
        party = self.gm.party
        speaker = person["speaker"]
        if tools.has_at_least(party, request["gives"]):
            # Already holding what he gives, from an older save (the axe was in Maika's chest before the
            # woodsman): he acts as if the trade was made (Frankie, 11/17).
            party.flags[request["flag"]] = True
        if party.flags.get(request["flag"]):
            if request.get("after_wake") and party.flags.get(StorySettings.AFTER_JUMP_FLAG):
                self._take_turn(person, "after_wake", request["after_wake"])  # the morning after the wake, one a talk
                return
            self.text_box.push(request["after"], speaker=speaker)
            return
        if party.inventory.get(request["wants"], 0) > 0:
            party.inventory[request["wants"]] -= 1
            if party.inventory[request["wants"]] <= 0:
                del party.inventory[request["wants"]]
            party.flags[request["flag"]] = True
            tools.take(party, request["gives"])
            for line in request["thanks"]:
                self.text_box.push(line, speaker=speaker)
            self.gm.audio.play("chest_open")
            self.text_box.push(OrderSettings.RECEIVED_LINE.format(item=ItemSettings.NAMES[request['gives']]))
            return
        for line in request["asks"]:
            self.text_box.push(line, speaker=speaker)

    def _talk_toll(self, person: dict) -> None:
        """The Nuno sa Tulay (Frankie, 11/12): his line and his price, then pay, refuse, or not now.

        Paying lets the party by for this visit only: he stands aside until they leave the room, and
        asks again the next time (Frankie, 11/12). Paid or not, he can be fought any time.
        """
        from core.scenes.choice_scene import ChoiceScene  # local, as the menus nearby
        from core.scenes.confirm_scene import ConfirmScene
        from settings import TollSettings

        speaker = person["speaker"]
        say = person["say"]
        if person.get("paid"):
            self.text_box.push(say["paid_up"][0], speaker=speaker)
            self._after_text = lambda: self.gm.scene_stack.push(
                ConfirmScene(self.gm, say["fight_ask"][0], on_yes=lambda: self._refuse_toll(person)))
            return
        self._take_turn(person, "day", person["lines"])
        self.text_box.push(say["demand"][0], speaker=speaker)

        def pick(index: int) -> None:
            party = self.gm.party
            if index == 0 and party.pule >= TollSettings.PRICE:
                party.pule -= TollSettings.PRICE
                person["paid"] = True   # for this visit: the room's people are made fresh on the way back
                self.gm.audio.play("chest_open")
                self.text_box.push(say["paid"][0])
                self.text_box.push(say["thanks"][0], speaker=speaker)
            elif index == 0:
                self.text_box.push(say["short"][0], speaker=speaker)
            elif index == 1:
                self._refuse_toll(person)
            else:
                self.text_box.push(say["not_now"][0], speaker=speaker)

        self._after_text = lambda: self.gm.scene_stack.push(
            ChoiceScene(self.gm, say["ask"][0], list(say["choices"]), pick, cancel=2))

    def _toll_stop(self) -> bool:
        """Kailo steps into the toll Nuno's lane and is stopped at once, as if he had walked up and
        talked (Frankie, 11/14). Not paid and not fought, he steps back the way he came (Claude's
        suggestion, 11/14), so he never stands past the Nuno.

        Returns:
            Whether the Nuno began talking this frame.
        """
        player = self.player
        person = self.world.lane_of(player.col, player.row)
        if person is None:
            self._toll_stopped = False
            return False
        if player._step_active or self._walk_back:
            return False
        back = (player._step_start[0] - player.col, player._step_start[1] - player.row)
        if self._toll_stopped:
            self._toll_stopped = False
            if abs(back[0]) + abs(back[1]) == 1:
                self._walk_back = [back]
            return False
        self._toll_stopped = True
        player.facing = (person["col"] - player.col, person["row"] - player.row)
        self._turn_to_player(person)
        self._met(person)
        self._talk_toll(person)
        return True

    def _refuse_toll(self, person: dict) -> None:
        """No toll from Kailo: the Nuno says so, then the fight."""
        self.text_box.push(person["say"]["refused"][0], speaker=person["speaker"])
        self._after_text = lambda: self._toll_fight(person)

    def _toll_fight(self, person: dict) -> None:
        """Refused, the Nuno fights as a boss: no running, his boss music (Frankie, 11/12)."""
        from core.scenes.battle_scene import BattleScene, compose_fight  # local, as _start_fight
        from settings import TollSettings

        kind = self.gm.data.load("field_monsters")[person["toll"]]
        battle = BattleScene(self.gm, enemies=compose_fight(kind), in_town=self._in_town(),
                             can_escape=False, music=TollSettings.MUSIC)
        self._toll_battle = (person, battle)
        fight_swirl.arm(self.gm, battle)
        self.gm.scene_stack.push(battle)

    def _talk_ama_rod(self, person: dict, gift: dict) -> bool:
        """Ama's part in the rod and in swimming (Frankie, 11/17); False when he has nothing to say for it.

        His second talk (``when``, once the stew is a quest, ``needs``; after the jump there is no first
        talk, so that counts) sends Kailo to dig the rod up on the hidden shore. Shown it, he teaches fishing
        and sends him for a first fish; shown that, he teaches swimming and Wave Fist.
        """
        party, speaker = self.gm.party, person["speaker"]
        flags = party.flags
        talked = flags.get(gift["when"]) or flags.get(StorySettings.AFTER_JUMP_FLAG)
        if not flags.get(gift["flag"]) and talked and party.inventory.get(gift["item"]):
            # Shown the rod, whenever it was dug up; found before he said where, he says so (Frankie, 11/17).
            flags[gift["flag"]] = True
            self._push_items(gift["found"] if flags.get(gift["hint_flag"]) else gift["early"], speaker)
            self._push_items(gift["lines"], speaker)
            return True
        if not flags.get(gift["flag"]):
            # The hint waits for his first talk and the stew quest (the opening is over).
            if talked and flags.get(gift.get("needs", gift["when"])) and not flags.get(gift["hint_flag"]):
                flags[gift["hint_flag"]] = True
                self._push_items(gift["hint"], speaker)
                return True
            return False
        if flags.get(SwimSettings.FIRST_FISH_FLAG) and not flags.get(SwimSettings.LEARNED_FLAG):
            flags[SwimSettings.LEARNED_FLAG] = True
            self._push_items(gift["swim"], speaker)
            self._teach_wave_fist()
            return True
        return False

    def _teach_wave_fist(self) -> None:
        """Ama teaches Kailo Wave Fist with swimming (Frankie, 11/17); a save that bought it already knows it."""
        from core.shared import by_id
        flag = f"kailo_learned_{SwimSettings.MOVE}"
        if self.gm.party.flags.get(flag):
            return
        self.gm.party.flags[flag] = True
        self._slot_learned("kailo", SwimSettings.MOVE)
        self.gm.audio.play("learned")
        self.text_box.push(SwimSettings.LEARNED_LINE.format(move=by_id("moves")[SwimSettings.MOVE]["name"]))

    def _ama_story(self, person: dict) -> bool:
        """Talk with Ama after the rod lesson is his ramble, once: the rod was Kailo's dad's (Frankie, 11/17).
        Only for a rod dug up; an older save's Ama said so when he handed it over."""
        gift, flags = person.get("gift"), self.gm.party.flags
        if not gift or not flags.get(gift["flag"]) or not flags.get(SwimSettings.ROD_DUG_FLAG) \
                or flags.get(gift["story_flag"]):
            return False
        flags[gift["story_flag"]] = True
        self._push_items(gift["story"], person["speaker"])
        return True

    def _push_items(self, items: list, speaker: str) -> None:
        """Lines as the room files hold them: a plain line is ``speaker``'s, an exchange names each speaker."""
        for item in items:
            if isinstance(item, dict):
                for row in item["talk"]:
                    self.text_box.push(row[1], speaker=row[0])
            else:
                self.text_box.push(item, speaker=speaker)

    def _talk_ama_boat(self, speaker: str) -> None:
        """Ama mends the Meialana: first the wood, which he takes, then the pule, which he gives back."""
        party, bag = self.gm.party, self.gm.party.inventory
        if party.flags.get(StorySettings.BOAT_FIXED):
            self.text_box.push(StorySettings.BOAT_DONE, speaker=speaker)
            return
        if not party.flags.get(StorySettings.BOAT_ASKED):
            party.flags[StorySettings.BOAT_ASKED] = True
            for line in StorySettings.BOAT_ASK_LINES:
                self.text_box.push(line, speaker=speaker)
            # Frankie, 11/20: one talk. With the wood in the bag he takes it right away; with none, the ask said all.
            if bag.get("wood", 0) < StorySettings.BOAT_WOOD:
                return
        if not party.flags.get(StorySettings.BOAT_WOOD_FLAG):
            have = bag.get("wood", 0)
            if have < StorySettings.BOAT_WOOD:
                self.text_box.push(StorySettings.BOAT_MORE_WOOD.format(have=have), speaker=speaker)
                return
            bag["wood"] = have - StorySettings.BOAT_WOOD
            if not bag["wood"]:
                del bag["wood"]
            party.flags[StorySettings.BOAT_WOOD_FLAG] = True
            self.gm.audio.play("chest_open")
            self.text_box.push(StorySettings.BOAT_GAVE_WOOD_LINE.format(count=StorySettings.BOAT_WOOD, item=ItemSettings.NAMES['wood']))
            self.text_box.push(StorySettings.BOAT_TAKES_WOOD, speaker=speaker)
        if party.pule < StorySettings.BOAT_PULE:
            self.text_box.push(StorySettings.BOAT_MORE_PULE, speaker=speaker)
            return
        party.flags[StorySettings.BOAT_FIXED] = True
        party.flags[SailingSettings.READY_FLAG] = True
        for who, line in StorySettings.BOAT_PULE_TALK:
            self.text_box.push(line, speaker=who)
        # Frankie, 11/20: Ama hands over the World Map as the boat is mended, in the same talk.
        for who, line in StorySettings.BOAT_MAP_TALK:
            self.text_box.push(line, speaker=who)
        self._give_world_map()

    def _give_world_map(self) -> None:
        """Ama gives Kailo the World Map and marks Kupulau on it (once; ``_ask_sail`` still gives it to an older save)."""
        from settings import OrderSettings
        party = self.gm.party
        if party.flags.get(MapSettings.HAS_MAP_FLAG):
            return
        party.flags[MapSettings.HAS_MAP_FLAG] = True
        party.inventory[MapSettings.ITEM] = 1   # a key item in the bag (Frankie, 11/17)
        sailing.know(party, "Kupulau")
        self.gm.audio.play("chest_open")
        self.text_box.push(OrderSettings.RECEIVED_LINE.format(item=ItemSettings.NAMES[MapSettings.ITEM]))

    def _talk_noelani(self, person: dict) -> None:
        """Noelani and the stew (Frankie, 10/30): the first talk she offers and lists what she
        needs. From the second on (Frankie's draft, 11/2) she says one of her own lines, and the
        first time offers to keep what Kailo does not need; then she asks what it is and he picks:
        what the stew still needs (or, with it all in the bag, they cook; with it made, the stew),
        the pule she holds for him, or never mind."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menus below
        from settings import BankSettings
        from systems import bank

        party = self.gm.party
        speaker = StewSettings.SPEAKER
        if not party.flags.get("stew_offered"):
            if stew.cook(party):
                self.gm.audio.play("hit_sparkle_1")
                self.begin_story(StewSettings.SCENE)
                return
            lacking = stew.missing(party)
            party.flags["stew_offered"] = True
            for line in StewSettings.OFFER_LINES:
                self.text_box.push(line, speaker=speaker)
            self.text_box.push(StewSettings.LIST_LINE.format(things=stew.things(lacking, numbers=True)),
                               speaker=StewSettings.LIST_SPEAKER)
            for line in StewSettings.SEND_LINES:
                self.text_box.push(line, speaker=speaker)
            self._after_text = self._noelani_take_stew
            return
        self._take_turn(person, "day", person["lines"])
        # She brings the jar up once Kailo carries at least BankSettings.LEAD_AT pule (Frankie, 11/12).
        if not party.flags.get(bank.OFFERED_FLAG) and party.pule >= BankSettings.LEAD_AT:
            party.flags[bank.OFFERED_FLAG] = True
            self.text_box.push(BankSettings.LEAD_LINE, speaker=speaker)
        self.text_box.push(BankSettings.WHAT_LINE, speaker=speaker)
        asked = bool(party.flags.get(bank.ASKED_FLAG))

        def say(line: str) -> None:
            self.text_box.push(line.format(held=bank.held(party)), speaker=speaker)

        def stew_pick() -> None:
            if stew.made(party):
                say(StewSettings.AFTER_LINE)
            elif stew.cook(party):
                self.gm.audio.play("hit_sparkle_1")
                self.begin_story(StewSettings.SCENE)
            else:
                # She says what is left, with numbers, and asks for what he carries so far (Frankie, 11/12;
                # Kailo no longer lists what he has first).
                say(StewSettings.MISSING_LINE.format(things=stew.things(stew.missing(party), numbers=True)))
                self._after_text = self._noelani_take_stew

        def pule_pick() -> None:
            party.flags[bank.ASKED_FLAG] = True
            say(BankSettings.ASK)
            self._after_text = self._noelani_bank

        def wallet_choice() -> list:
            """Her wallet, the next one up and only to BankSettings.WALLET_UP_TO (Frankie, 11/12)."""
            from core.scenes.shop_scene import next_wallet_row

            return [(BankSettings.WALLET_CHOICE, self._noelani_wallet)] \
                if next_wallet_row(party, BankSettings.WALLET_UP_TO) is not None else []

        def menu() -> None:
            if stew.made(party):
                stew_choice = BankSettings.STEW_CHOICE
            elif stew.missing(party):
                stew_choice = BankSettings.INGREDIENTS_CHOICE
            else:
                stew_choice = BankSettings.STEW_READY_CHOICE
            pule_choice = BankSettings.PULE_CHOICE if asked else BankSettings.PULE_FIRST_CHOICE
            options = [(stew_choice, stew_pick), (pule_choice, pule_pick), *wallet_choice(),
                       (BankSettings.NEVER_CHOICE, lambda: say(BankSettings.NEVER_LINE))]
            self.gm.scene_stack.push(ChoiceScene(
                self.gm, speaker, [label for label, _ in options], lambda index: options[index][1](),
                cancel=len(options) - 1))
        self._after_text = menu

    def _noelani_wallet(self) -> None:
        """Noelani sells the next wallet up (Frankie, 11/12): she names it and the price, and buying pays her
        from the wallet Kailo carries, upgrades it, and Kailo complains. With Maika along and standing, the
        first offer is the scene where he charms her (``story-noelani.md``), and her price is his discounted one."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menus nearby
        from core.scenes.shop_scene import next_wallet_row, shop_price
        from settings import BankSettings, WalletSettings
        from systems.passives import standing

        party, speaker = self.gm.party, StewSettings.SPEAKER
        row = next_wallet_row(party, BankSettings.WALLET_UP_TO)
        if row is None:
            return
        if standing(party, "maika") and not party.flags.get(BankSettings.CHARM_FLAG):
            self.begin_story(BankSettings.CHARM_SCENE)   # offers the wallet again when it ends
            return
        price = shop_price(party, row["price"])
        _item, name, holds, _cost = WalletSettings.TIERS[party.wallet_tier + 1]

        def yes() -> None:
            if party.pule < price:
                self.text_box.push(BankSettings.WALLET_SHORT.format(price=price), speaker=speaker)
                return
            party.pule -= price
            party.set_wallet(party.wallet_tier + 1)
            self.gm.audio.play("hit_sparkle_1")
            self.text_box.push(BankSettings.WALLET_SOLD, speaker=speaker)
            self.text_box.push(BankSettings.WALLET_COMPLAINT, speaker="Kailo")

        self.text_box.push(BankSettings.WALLET_OFFER.format(name=name, holds=f"{holds:,}", price=price), speaker=speaker)
        self._after_text = lambda: self.gm.scene_stack.push(
            ConfirmScene(self.gm, BankSettings.WALLET_BOX.format(name=name, price=price), on_yes=yes))

    def _noelani_take_stew(self) -> None:
        """With some of the stew's things in the bag, she asks for them (Frankie, 11/12); yes hands them over,
        and when that is all of it the two of them cook."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menus nearby

        party, speaker = self.gm.party, StewSettings.SPEAKER
        if stew.made(party) or not stew.carrying(party):
            return

        def yes() -> None:
            stew.give(party)
            self.gm.audio.play("hit_sparkle_1")
            if stew.cook(party):
                self.begin_story(StewSettings.SCENE)
            else:
                self.text_box.push(StewSettings.GAVE_LINE.format(
                    things=stew.things(stew.missing(party), numbers=True)), speaker=speaker)

        self.text_box.push(StewSettings.GIVE_ASK, speaker=speaker)
        self._after_text = lambda: self.gm.scene_stack.push(ConfirmScene(self.gm, StewSettings.GIVE_BOX, on_yes=yes))

    def _noelani_bank(self) -> None:
        """Noelani holds pule for Kailo (Frankie, 11/1; ``systems/bank.py``): leave some, take some back."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menus below
        from core.scenes.count_scene import CountScene
        from settings import BankSettings
        from systems import bank

        party, speaker = self.gm.party, StewSettings.SPEAKER

        def say(line: str) -> None:
            self.text_box.push(line.format(held=bank.held(party)), speaker=speaker)

        def amounts(ask: str, most: int, act, done: str, empty: str) -> None:
            """The shop's quantity picker, from 0 up to ``most`` (Frankie, 11/15); 0 or B leaves it be."""
            if most <= 0:
                say(empty)
                return

            def pick(amount: int | None) -> None:
                if not amount:
                    return
                if act(party, amount):
                    self.gm.audio.play("hit_sparkle_1")
                say(done)
            self.gm.scene_stack.push(CountScene(self.gm, ask, most, pick))

        def pick(index: int) -> None:
            if index == 0:
                amounts(BankSettings.LEAVE_ASK, party.pule, bank.leave, BankSettings.LEFT, BankSettings.NONE_LEFT)
            elif index == 1:
                if bank.held(party) and party.pule >= party.pule_max:
                    say(BankSettings.FULL)
                    return
                amounts(BankSettings.TAKE_ASK, min(bank.held(party), party.pule_max - party.pule), bank.take,
                        BankSettings.TOOK, BankSettings.NONE_HELD)

        self.gm.scene_stack.push(ChoiceScene(self.gm, speaker, BankSettings.CHOICES, pick,
                                                 cancel=len(BankSettings.CHOICES) - 1))

    def _hina_says_wait(self) -> None:
        """The first planting, Hina says they can go do something else while it grows (Frankie, 10/30)."""
        lesson = garden.wait_lesson(self.gm.party)
        if lesson is not None:
            speaker, line = lesson
            self.text_box.push(line, speaker=speaker)

    def _faced_patch(self) -> int | None:
        """The garden patch on the tile the player faces, by its index in the room, or None."""
        dx, dy = self.player.facing
        return self.world.patch_tiles.get((self.player.col + dx, self.player.row + dy))

    def _tend(self, index: int) -> None:
        """One press, one thing (Frankie, 10/23): pick the patch, or ask to replant it or grow it faster."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below

        pressed = garden.press(self.gm.party, self.world.current_cell_name, index)
        if pressed.line is not None:
            if pressed.line.startswith("Picked"):
                self.gm.audio.play("hit_sparkle_1")
            self.text_box.push(pressed.line)
        if pressed.offer is not None:
            speaker, line = pressed.offer
            self.text_box.push(line, speaker=speaker)
        if pressed.question is None:
            return

        def yes() -> None:
            self.gm.audio.play("hit_sparkle_1")
            for line in pressed.yes():
                self.text_box.push(line)
            replanted = pressed.question.startswith(GardenSettings.REPLANT_BOX.split("{")[0])
            # The first planting with Maika and Hina along, he teaches her Seed (Frankie, 10/24),
            # and only then does Hina say it takes a while.
            if replanted and self._seed_lesson_due():
                self.begin_story(StorySettings.SEED_SCENE)
            elif replanted:
                self._hina_says_wait()

        def choose(answer: int) -> None:
            """A farm patch's crop (Frankie, 10/29)."""
            planted = answer < len(pressed.choices) - 1
            for line in pressed.pick(answer):
                self.text_box.push(line)
            if planted:
                self.gm.audio.play("hit_sparkle_1")
                if self._seed_lesson_due():
                    self.begin_story(StorySettings.SEED_SCENE)
                else:
                    self._hina_says_wait()

        def ask() -> None:
            if pressed.choices is not None:
                from core.scenes.choice_scene import ChoiceScene
                self.gm.scene_stack.push(ChoiceScene(self.gm, pressed.question, pressed.choices, choose,
                                                     cancel=len(pressed.choices) - 1))
                return
            self.gm.scene_stack.push(ConfirmScene(self.gm, pressed.question, on_yes=yes))
        if self.text_box.is_done():
            ask()
        else:
            self._after_text = ask

    def _open_chest(self) -> None:
        """A chest (Frankie, 10/24): its item in the bag the first time, then it is empty.

        A chest with ``random`` instead holds one of ``ItemSettings.CHEST_RANDOM``,
        picked when it is opened (Frankie, 10/25): a weapon or relic, or a
        goodie, which may be pule. His dad's chest (Frankie, 10/26) holds
        several: its ``item``, the ``also`` list, and ``random`` picked a
        number of times in the ``picks`` range; Kailo says its ``before``
        line, then it opens.
        """
        dx, dy = self.player.facing
        chest = self.world.building_at(self.player.col + dx, self.player.row + dy)
        flag = chest_flag(self.world.current_cell_name, chest)
        items = chest_items(chest)
        if self.gm.party.flags.get(flag) or not items:
            self.text_box.push(StorySettings.CHEST_EMPTY)
            return
        self.gm.party.flags[flag] = True
        if chest.get("before"):
            self.text_box.push(chest["before"], speaker="Kailo")
            self._after_text = lambda: self._take_from_chest(chest, items)
        else:
            self._take_from_chest(chest, items)
        if chest["kind"] == "ground_taro":
            self.world.go_to(self.world.current_pos)  # the room again, the taro no longer on the ground

    def _take_from_chest(self, chest: dict, items: list[str]) -> None:
        """The chest opens: ``items`` go in the bag (pule in the wallet), each said, then its ``line``."""
        from settings import ItemSettings

        self.gm.audio.play("chest_open")
        for item in items:
            if item == "pule":
                pule = ItemSettings.CHEST_PULE_BY_TIER[chest["tier"]] if chest.get("tier") else ItemSettings.CHEST_PULE
                # A full wallet gets none, with no word; a nearly full one only what fits (Frankie, 11/1).
                pule = min(pule, max(0, self.gm.party.pule_max - self.gm.party.pule))
                if pule:
                    self.gm.party.pule += pule
                    self.text_box.push(StorySettings.CHEST_FOUND.format(item=f"{pule} pule"))
            elif tools.is_tool(item):
                # A tool is a key item; an upgrade replaces the one before it (Frankie, 10/28).
                tools.take(self.gm.party, item)
                self.text_box.push(StorySettings.CHEST_FOUND.format(item=ItemSettings.NAMES.get(item, item)))
            else:
                self.gm.party.inventory[item] = self.gm.party.inventory.get(item, 0) + 1
                self.text_box.push(StorySettings.CHEST_FOUND.format(item=ItemSettings.NAMES.get(item, item)))
                if item in ItemSettings.SHELLS and item not in ItemSettings.KAPAS:
                    for speaker, line in lontar_talk.take(self.gm.party):  # the first lontar talk (Frankie, 11/10)
                        self.text_box.push(line, speaker=speaker)
        if chest.get("line"):
            self.text_box.push(chest["line"], speaker="Kailo")

    def _open_pot(self) -> None:
        """The pot inside Kailo's house opens the crafting pot, the only place to craft (Frankie, 10/24)."""
        from core.scenes.craft_scene import CraftScene  # local: cycle.

        self.gm.audio.play("menu_select")
        self.gm.scene_stack.push(CraftScene(self.gm))

    def _count_steps(self) -> None:
        """Count a step for the garden each time the player stands on a new tile."""
        here = (self.world.current_pos, self.player.col, self.player.row)
        if self._last_tile is not None and here != self._last_tile:
            garden.walked(self.gm.party)
            self._swim_step()
        self._last_tile = here

    def _render_patches(self, surface: pygame.Surface) -> None:
        """Draw each patch in the room by how far it has grown."""
        tile_size = GridSettings.TILE_SIZE
        patches = garden.patches_in(self.world.current_cell_name)
        for index, patch in enumerate(patches):
            sheet = _patch_sheet(garden.plant_of(self.world.current_cell_name, index, self.gm.party))
            x = OverworldSettings.X + patch["col"] * tile_size
            y = OverworldSettings.Y + patch["row"] * tile_size
            stage = garden.stage(self.gm.party, self.world.current_cell_name, index)
            if sheet is None:
                pygame.draw.rect(surface, ColorSettings.OVERWORLD_SAND, (x, y, tile_size, tile_size))
                continue
            plant = garden.plant_of(self.world.current_cell_name, index, self.gm.party)
            picture = None
            if plant in GardenSettings.TARO_PLANTS:
                spots = {(other["col"], other["row"]) for i, other in enumerate(patches)
                         if garden.plant_of(self.world.current_cell_name, i, self.gm.party) in GardenSettings.TARO_PLANTS}
                col, row = patch["col"], patch["row"]
                picture = _taro_patch_picture(stage, tuple(
                    spot in spots for spot in ((col, row - 1), (col, row + 1), (col - 1, row), (col + 1, row))))
            look = garden.raided(self.gm.party, self.world.current_cell_name, index,
                                 self.story is not None and self.story.name == GardenSettings.RAIDED_SCENE)
            if look is not None and plant in GardenSettings.TARO_PLANTS:
                # The boars' work (Frankie, 11/19, "for now"): until the Great Boar is beaten.
                picture = _taro_patch_picture(0 if look == "hole" else 1, tuple(
                    spot in spots for spot in ((col, row - 1), (col, row + 1), (col - 1, row), (col + 1, row)))) or picture
                surface.blit(picture, (x, y))
                hole = _hole_picture()
                if look == "hole" and hole is not None:
                    surface.blit(hole, (x, y))
                continue
            if picture is not None:
                surface.blit(picture, (x, y))
            else:
                surface.blit(sheet, (x, y), (stage * tile_size, 0, tile_size, tile_size))

    def _rest(self, line: str | None = TownSettings.POND_LINE) -> None:
        """Drink from the pond, or nap in Kailo's bed: everyone standing back to full HP (D-525).

        The knocked out stay down, and neither saves (Frankie, 10/26): only a totem does both.
        Every beaten monster comes back (Frankie, 10/28).
        """
        field_respawn.bring_back_all(self.gm.party)
        for member in self.gm.party.members:
            if member.current_hp > 0:
                member.current_hp = member.max_hp
        self.gm.audio.play("hit_sparkle_1")
        if line is not None:
            self.text_box.push(line)

    def _pray(self) -> None:
        """Pray at an Akua totem (Frankie, 10/26): tell the Akua all that has happened,
        as Dragon Quest's confession, the fallen get back up at full HP, then save.

        The first time Hina explains, or Kailo with her away. No status outlasts a
        fight yet, so there is no zombie or curse here to lift.
        """
        flags = self.gm.party.flags
        if not flags.get(TownSettings.TOTEM_FLAG):
            flags[TownSettings.TOTEM_FLAG] = True
            speaker = "Hina" if self.gm.party.find("hina") is not None else StorySettings.PLAYER
            for line in TownSettings.TOTEM_FIRST[speaker]:
                self.text_box.push(line, speaker=speaker)
        self.text_box.push(TownSettings.PRAY_LINE)
        fallen = [m for m in self.gm.party.members if m.current_hp <= 0]
        for member in fallen:
            member.current_hp = member.max_hp
        self.gm.audio.play("hit_sparkle_1")
        if fallen:
            self.text_box.push(TownSettings.REVIVE_LINE)
        self._after_text = self._ask_save

    def _ask_save(self) -> None:
        """After praying at a totem, the save point: YES opens the three slots; NO, nothing."""
        from core.scenes.confirm_scene import ConfirmScene  # local, as the menu below
        from core.scenes.save_slot_scene import SaveSlotScene

        self.gm.scene_stack.push(ConfirmScene(
            self.gm, TownSettings.SAVE_BOX,
            on_yes=lambda: self.gm.scene_stack.push(SaveSlotScene(self.gm, loading=False)),
            yes_first=True,  # The save point starts on YES (Frankie, 11/4, after the Let's Play).
        ))

    def update(self, dt: float) -> None:
        """A frame of the field, or of a scene being skipped (``skip_cutscene``)."""
        if self.skipping is not None:
            self._skip_ahead()
            return
        self._turn_of_day()
        self._frame(dt)

    def _tick_clock(self, dt: float) -> None:
        """The day and night clock (Frankie, 11/20; ``systems/daytime``, ``ClockSettings``): started once the story has
        reached its start (the morning after Ama's rescue), and Ama says so, once; then the hour moves while
        Kailo is free on the field (this runs only then: no text, menu, shop, fight or scene)."""
        party = self.gm.party
        if party is None:
            return
        if not daytime.running(party) and daytime.due(party):
            daytime.start(party)
        if daytime.running(party) and not party.flags.get(daytime.TOLD_FLAG):
            party.flags[daytime.TOLD_FLAG] = True
            for line in ClockSettings.TELL_LINES:
                self.text_box.push(line, speaker=ClockSettings.TELL_SPEAKER)
            return
        daytime.tick(party, dt)

    def _frame(self, dt: float) -> None:
        """Tick the text box, then advance the player if no text is showing.

        After advancing the player, any newly-completed steps roll for
        a random encounter; on a hit a ``BattleScene`` is pushed on
        top of this scene. The overworld resumes automatically when
        the battle pops, since this scene was never destroyed.

        Args:
            dt: Frame time in seconds.
        """
        self._room_sound()
        self._end_visit()
        self._swing = max(0.0, self._swing - dt)
        self._tick_strike(dt)
        if self._dug and self.world.current_cell_name != self._dug_room:
            self._dug = set()  # the holes fill in when Kailo leaves the room
        self._shake_left = max(0.0, self._shake_left - dt)
        self._tick_drops(dt)
        if self._chop_at is not None and self._faced_tree() != self._chop_at:
            self._chop_at, self._chops = None, 0  # walked off mid-chop: the count starts over (Frankie, 10/29)
        self._since_draw += dt
        self._watch_place(dt)
        # A room is found once Kailo stands in it, not while a scene is acted out (the area map).
        if self.stage is None:
            self.world.seen.add(self.world.current_cell_name)
        self.text_box.update(dt)
        self._fly_through(dt)
        if not self.popup:
            # A room's name has the window; a notice waits until it is gone (Frankie, 11/12).
            notices.update(dt, self.gm.audio)
        ids = [member.id for member in self.gm.party.members]
        if ids and self.player.walker not in ids:
            self.player.walker = ids[0]   # whoever walked has left the party
        self._tick_opening()
        if self.stage is not None:
            self.stage.update(dt)
        self._tick_fade(dt)
        if self._home_trip is not None:
            self._home_step()
            return
        if self._card is not None or not self.text_box.is_done():
            return
        if self._after_text is not None:
            action, self._after_text = self._after_text, None
            action()
            return
        if self.story is not None:
            self._play_story()
            return
        self._watch_sparring(dt)
        if not self.text_box.is_done():
            return
        self._place_monsters()
        if self._rush is not None:
            self._tick_rush(dt)
            return
        self.tool_wheel.update(dt, input_map.read_held_direction(self.gm.connected_joysticks), self.gm.party)
        if self._toll_stop():
            return
        before = (self.world.current_pos, self.world.current_cell_name, self.player.col, self.player.row)
        if self._walk_back and not self.player._step_active:
            self.player._begin_step(*self._walk_back.pop())
        elif not self.tool_wheel.open and self._swing <= 0 and self._strike is None and self._line is None:
            # The d-pad picks on the open wheel, and mid-swing he is stuck in
            # the chop; either way Kailo stands still, the monsters do not. With
            # the line out he stands still too, so a d-pad ready for the reel
            # never walks him off (Frankie, 11/4); a tap of Y reels the line in.
            self.player.update(dt)
        if not self.player._step_active:
            self._pick_up(self.player.col, self.player.row)   # walking onto a drop takes it
        if self.world.current_pos != before[0]:
            self._crossed(before)
        self._tick_clock(dt)
        self._count_steps()
        self._tick_fishing(dt)
        lore.unlock_items(self.gm.party)
        self._wander_people(dt)
        if self._dead_end():
            return
        if self._hina_catches_up():
            self.begin_story(StorySettings.WOODS_SCENE)
            return
        if self._wake_ask_due():
            self._ask_wake()
            return
        warning = self._deep_woods_warning()
        if warning is not None:
            self.begin_story(warning)
            return
        turned = self._east_way_turn()
        if turned is not None:
            self.begin_story(turned)
            return
        # Walking into the Great Boar: are you ready? Once each time they walk up.
        boss = self._asker_in_reach()
        if boss is None:
            self._asked = False
        elif not self._asked and not self.player._step_active and not self._walk_back:
            self._asked = True
            self._asking = boss
            self.begin_story(StorySettings.ASK_SCENE)
            return
        self._place_monsters()
        if self._grace > 0 and (self.world.current_cell_name, self.player.col, self.player.row) != self._grace_from:
            self._grace = max(0.0, self._grace - dt)
        for monster in self._on_stage_monsters():
            taken = set().union(*(m.tiles() for m in self.monsters if m is not monster))
            if self._grace > 0:
                # The monster left standing waits for the party to walk off.
                taken.add((self.player.col, self.player.row))
            chase = None if self._grace > 0 or not self._reachable(monster) else (self.player.col, self.player.row)
            monster.update(dt, self.world, taken, chase)
            if monster.mark_sound:
                self.gm.audio.play(FieldMonsterSettings.MARK_SOUNDS[monster.mark_sound])
                monster.mark_sound = None
        # Started from the Workshop with fights off, the monsters walk
        # but never start one, so a room can be looked over in peace.
        if self._grace <= 0 and not getattr(self.gm, "no_fights", False):
            for monster in self._on_stage_monsters():
                if monster.spot.get("kind") == StorySettings.ASK_KIND or not self._reachable(monster):
                    continue
                if (self.player.col, self.player.row) in monster.tiles():
                    self._catch(monster)
                    return

    def _crossed(self, before: tuple) -> None:
        """The party walked into another room (Frankie, 11/19). Coming into the Lost Woods from outside keeps the way in; leaving
        the Great Boar's room once he is beaten, or the six-Aghoy room once Maika has talked about his sister, asks whether to
        go back or keep exploring."""
        from core.scenes.choice_scene import ChoiceScene  # local, as the menus nearby
        from core.overworld_cells import WORLD_LAYOUT  # local, as the rest of the field

        pos, name, col, row = before
        flags = self.gm.party.flags
        here = self.world.current_cell_name
        step = (self.world.current_pos[0] - pos[0], self.world.current_pos[1] - pos[1])
        if name in {entry[0] for entry in StorySettings.DEEP_ENTRANCES} and here in generated.INSTALLED:
            flags[StorySettings.HOME_ENTRY_FLAG] = f"{name}:{col}:{row}:{step[0]}:{step[1]}"
            return
        if name == StorySettings.SEED_ROOM and flags.get(StorySettings.BOAR_BEATEN_FLAG):
            room, col, row, facing = StorySettings.HOME_SQUARE
        elif name == StorySettings.CLEARING and flags.get(StorySettings.FOUND_FLAG):
            room, col, row, facing = self._woods_entry()
        else:
            return

        def pick(index: int) -> None:
            if index != 0:
                return
            self._home_to = (next(pos for pos, who in WORLD_LAYOUT.items() if who == room), col, row, facing)
            self._home_trip = "out"
            self._fade_to = 1.0

        self.gm.scene_stack.push(ChoiceScene(self.gm, StorySettings.HOME_ASK, list(StorySettings.HOME_CHOICES), pick,
                                             cancel=1))

    def _woods_entry(self) -> tuple[str, int, int, tuple[int, int]]:
        """Where the party came into the Lost Woods, standing there facing back out; without one kept (an old save), the
        log yard's west edge."""
        from core.overworld_cells import CELLS  # local, as the rest of the field

        kept = str(self.gm.party.flags.get(StorySettings.HOME_ENTRY_FLAG) or "").split(":")
        if len(kept) == 5:
            room, col, row, dx, dy = kept[0], int(kept[1]), int(kept[2]), int(kept[3]), int(kept[4])
            return room, col, row, (-dx, -dy)
        room, col, facing = StorySettings.HOME_ENTRY_FALLBACK
        grid = CELLS[room]
        row = next(r for r in range(OverworldSettings.ROWS) if grid[r][col] not in "#~")
        return room, col, row, facing

    def _home_step(self) -> None:
        """The way home's fade: to black, the party set down in the new room, and back in."""
        if self._fade_to is not None:
            return
        if self._home_trip == "out":
            pos, col, row, facing = self._home_to
            self.world.go_to(pos)
            self.player.from_dict({"col": col, "row": row, "facing": list(facing)})
            self._walk_back = []
            self._room_sound()
            self._home_trip = "in"
            self._fade_to = 0.0
        else:
            self._home_trip, self._home_to = None, None

    def _tick_fade(self, dt: float) -> None:
        """Take the screen's darkness toward where a Fade sends it, and count down a Wait."""
        self._wait = max(0.0, self._wait - dt)
        if self._fade_to is None:
            return
        step = dt / StorySettings.FADE_SECONDS
        if self._fade_to > self._dark:
            self._dark = min(self._fade_to, self._dark + step)
        else:
            self._dark = max(self._fade_to, self._dark - step)
        if self._dark == self._fade_to:
            self._fade_to = None

    def _render_dark(self, surface: pygame.Surface) -> None:
        """The fade, as the Super Nintendo's master brightness in its sixteen steps; and on
        black at the end, the demo's last words."""
        level = round(self._dark * StorySettings.FADE_STEPS) / StorySettings.FADE_STEPS
        if level > 0:
            veil = pygame.Surface(surface.get_size())
            veil.set_alpha(round(level * 255))
            surface.blit(veil, (0, 0))
        if self._card:
            from ui import text_renderer  # local: only the end needs it

            size = StorySettings.CARD_SIZE
            width = text_renderer.text_width(self._card, size)
            text_renderer.draw_text(surface, self._card, ((surface.get_width() - width) // 2,
                                    (surface.get_height() - text_renderer.line_height(size)) // 2), size=size)
            # The card waits for a press to go to the title: the marker says so.
            draw_continue_marker(surface, (surface.get_width() // 2, surface.get_height() - 12))

    def _take_turn(self, person: dict, which: str, lines: list) -> int | None:
        """The next of a person's ``lines``, one a talk, round and round, never all in a row
        (Frankie, 10/26). ``which`` names the set, by day, at night or a flag's, each with its
        own place in the round, so a new set starts at its first line. Returns the index said.

        A line can be a ``talk`` exchange, one thought over several boxes or a back-and-forth
        with Kailo, played whole as one turn. With ``once`` too, it plays the first time, and
        its flag drops it from the round for good (Melia asking about Kailo's dad, Frankie, 10/25).
        """
        flags = self.gm.party.flags if self.gm.party else {}
        turn = person.setdefault("turn", {}).get(which, 0)
        for step in range(len(lines)):
            index = (turn + step) % len(lines)
            line = lines[index]
            if not (isinstance(line, dict) and flags.get(line.get("once"))):
                break
        else:
            return None
        person["turn"][which] = index + 1
        if isinstance(line, dict) and line.get("once") and self.gm.party:
            self.gm.party.flags[line["once"]] = True
        self._say(person, line)
        return index

    def _say(self, person: dict, line) -> None:
        """One of a person's lines: a plain line under their ``speaker``, or a ``talk``
        exchange, a row with a third word only with that member along (Kailo
        answering Keo, Frankie, 10/26)."""
        if not isinstance(line, dict):
            self.text_box.push(line, speaker=person["speaker"])
            return
        for speaker, said, *along in line["talk"]:
            if not along or (self.gm.party and self.gm.party.find(along[0]) is not None):
                self.text_box.push(said, speaker=speaker)

    def _end_visit(self) -> None:
        """Leaving a room by one of a found person's ``leaves_by`` sides sends them home:
        Melia, found, goes back to the pots by Kailo's house once he walks off by any side,
        the harbor to the west included (Frankie, 10/25, 11/5). Going into a building has no
        side (an inside room has no map position), so it never sends anyone home."""
        here = self.world.current_cell_name
        if here == self._visiting:
            return
        rooms = {name: pos for pos, name in self.world.layout.items()}
        was, now = rooms.get(self._visiting), rooms.get(here)
        side = [now[0] - was[0], now[1] - was[1]] if was and now else None
        flags = self.gm.party.flags if self.gm.party else {}
        for person in PEOPLE.get(self._visiting, []):
            if side in person.get("leaves_by", []) and flags.get(person["first"]["flag"]):
                flags[person["until"]] = True
        self._visiting = here

    def _room_sound(self) -> None:
        """Each room's song, going on unbroken from room to room while it is the same
        (Frankie, 10/23; as the cartridge's room_sound): all through the town, its buildings
        too, and the harbor, Kulāiwi with the surf under it by day once the taro patch is over,
        else the surf alone (Frankie, 10/27); quiet everywhere else at night
        (the Great Boar beaten); by day The Big Bad in his room, The Forgotten Wilds in the
        generated deep forest (Frankie, 10/26) and the woods' song in the rest; Regrets all through Pono's wake, but for a scene's Song (Tawiri's theme), and
        nothing from its Song: none to its End's words (Frankie, 10/27)."""
        if self._card is not None:
            self.gm.audio.play_screen(AudioSettings.SILENT)
        elif self.story is not None and self.story.song:
            self.gm.audio.play_screen(self.story.song)
        else:
            self.gm.audio.play_screen(self._room_screen())

    def _clock_night(self) -> bool:
        """Whether it is night by the clock (``systems/daytime``): not the story's own night, which keeps the music it has."""
        return daytime.is_night(self.gm.party) and not daytime.story_night(self.gm.party)

    def _turn_of_day(self) -> None:
        """When the hour crosses into night or out of it (Frankie, 11/19): at nightfall the field music slows down and fades
        out, and a wolf howls; at daybreak a rooster crows and the music starts again. Night itself is silent
        (``_room_screen``); fights keep their own music."""
        night = self._clock_night()
        if night == self._was_clock_night:
            return
        self._was_clock_night = night
        self._sync_joined()   # the village goes indoors at nightfall and comes out at daybreak (``systems/schedules``)
        if self.story is not None or self._card is not None:
            return
        audio = self.gm.audio
        if night:
            audio.slow_fade()
            audio.play("wolf_howl", delay=1.5)
        else:
            audio.play("rooster_crow")
        self._room_sound()

    def _room_screen(self) -> str:
        """The room's song (``_room_sound``) with no Song over it."""
        name = self.world.current_cell_name
        within = lambda rooms: name in rooms or any(
            b.get("inside") == name for room in rooms for b in BUILDINGS.get(room, []))
        if self.story is not None and self.story.name == "wake":
            screen = "wake"
        elif self._clock_night():
            screen = "quiet"   # the clock's night is silent (Frankie, 11/19)
        elif name in AudioSettings.ROOM_SONGS and not self.is_night():
            # Frankie's own song for the grove and the temple (11/3).
            screen = AudioSettings.ROOM_SONGS[name]
        elif within(AudioSettings.BEACH_ROOMS + AudioSettings.HARBOR_ROOMS):
            taro = self.gm.party and self.gm.party.flags.get(StorySettings.TARO_FLAG)
            screen = "village" if taro and not self.is_night() else "beach"
        elif name in AudioSettings.LODGE_ROOMS and not self.is_night():
            # The hunters' lodge keeps the woods' song going (Frankie, 11/1), not the silence of a house.
            screen = "woods"
        elif self.world.current_pos[1] >= INSIDE_ROW or self.is_night():
            screen = "quiet"
        elif name == StorySettings.SEED_ROOM:
            screen = "great_boar"
        elif name in generated.INSTALLED:
            screen = "deep_woods"
        else:
            screen = "woods"
        return screen

    def _watch_sparring(self, dt: float) -> None:
        """The villagers' sparring, silent (Frankie, 10/23): 30 seconds watching, once, teaches Kailo.

        Watching is standing next to one of them, facing them, with nothing
        pressed; a step or a turn away starts the count again.
        """
        if not any(person.get("spar") for person in self.world.people):
            self._idle = 0.0
            return
        if self.player._step_active or not self._faced_person().get("spar"):
            self._idle = 0.0
            return
        self._idle += dt
        if self._idle < TownSettings.WATCH_SECONDS or self.gm.party.flags.get(TownSettings.WATCH_FLAG):
            return
        member = self.gm.party.find(TownSettings.WATCH_MEMBER)
        if member is None:
            return
        self.gm.party.flags[TownSettings.WATCH_FLAG] = True
        old_max = member.max_hp
        for stat, points in TownSettings.WATCH_GROWTH.items():
            member.growth[stat] = member.growth.get(stat, 0) + points
        member.refresh_stats()
        member.current_hp = hp_keeping_share(member.current_hp, old_max, member.max_hp)
        self.gm.audio.play("learned")
        for line in TownSettings.WATCH_LINES:
            self.text_box.push(line)

    def _place_monsters(self) -> None:
        """Put the cell's monsters out when the party arrives in a cell (D-576)."""
        night = self._monsters_night()
        if self._monsters_cell == self.world.current_pos and self._monsters_by_night == night:
            return
        self._monsters_cell = self.world.current_pos
        self._monsters_by_night = night
        self._grace = 0.0
        kinds = self.gm.data.load("field_monsters")
        cell_name = self.world.current_cell_name
        called = self._boars_called_gone(cell_name)
        self.monsters = [
            FieldMonster(spot, kinds[self._variant_of(self._kind_now(spot, kinds), kinds)])
            for index, spot in enumerate(FIELD_MONSTERS.get(cell_name, []))
            if not (spot.get("boss") and self.gm.party.flags.get(_boss_flag_for(cell_name, spot)))
            and index not in called
            and not field_respawn.is_gone(self.gm.party, cell_name, index)
            # A night monster walks only at night (the Sigbin, Frankie, 10/28).
            and (not spot.get("night") or daytime.is_night(self.gm.party))
        ]

    def _monsters_night(self) -> bool:
        """Whether the monsters here are the night ones: night by the hour (``systems/daytime``), on Kulāiwi's side of the map."""
        return daytime.is_night(self.gm.party) and world_map.area_of(self.world.current_cell_name) == MapSettings.WORLD_AREA

    def _kind_now(self, spot: dict, kinds: dict) -> str:
        """The kind a spot holds right now (Frankie, 11/19): by night a day kind with a ``night_kind`` is that one instead
        (the boar the Sigbin, the Nuno sa Punso the Mangkukulam, the Aghoy the Taong Tuod, the red mushroom the Wicked Dwende)."""
        kind = spot["kind"]
        return kinds[kind].get("night_kind", kind) if self._monsters_by_night else kind

    @staticmethod
    def _variant_of(kind: str, kinds: dict) -> str:
        """The kind a monster is this time: a kind with a ``variant`` (the Green Aghoy, Frankie, 11/22) is that other
        kind (the Blue Aghoy) with its ``chance``, rolled as the room is entered."""
        variant = kinds[kind].get("variant")
        return variant["kind"] if variant and random.random() < variant["chance"] else kind

    def _woods_night(self) -> bool:
        """Whether the party is in the Lost Woods at night, where the monsters are stronger still (Frankie, 11/19)."""
        return self._monsters_night() and self.world.current_cell_name in generated.INSTALLED

    def _boars_called_gone(self, cell_name: str) -> set[int]:
        """The spots of the boars the Great Boar's fight took from his field for good (Frankie, 11/12):
        one for each boar he called and the party beat, the first of the room's boars first."""
        count = int(self.gm.party.flags.get(StorySettings.BOAR_CALLS_FLAG) or 0)
        if cell_name != StorySettings.BOAR_FIELD_ROOM:
            return set()
        spots = [i for i, spot in enumerate(FIELD_MONSTERS.get(cell_name, []))
                 if spot["kind"] == StorySettings.BOAR_FIELD_KIND and not spot.get("boss")]
        # The Great Boar beaten, the boars still with him ran, so none are left in his clearing (Frankie, 11/16).
        if self.gm.party.flags.get(StorySettings.BOAR_BEATEN_FLAG):
            return set(spots)
        if count <= 0:
            return set()
        return set(spots[:count])

    def _in_town(self) -> bool:
        """Whether the party stands in one of the town's rooms, where a fight is on the beach."""
        return self.world.current_cell_name in BackgroundSettings.TOWN_ROOMS

    def _who_caught(self, monster: FieldMonster) -> str | None:
        """Who caught whom (Frankie, 10/27): walking into a monster's back or side is a
        preemptive strike, one stepping into Kailo's back an ambush, anything else a plain fight
        (ambushes from the side too came in nearly every forest fight of the 10/27 Let's Play,
        a chasing monster most often turning in at his side; Frankie, 10/27: back only).

        A monster faces only left or right, so above and below are its sides. Both
        stepping at once, or neither, is a plain fight.
        """
        kailo_stepped = self.player._step_active
        it_stepped = monster._progress < 1.0
        if kailo_stepped == it_stepped:
            return None
        if kailo_stepped:
            dx, dy = self.player.facing
            front = (-1, 0) if monster.facing_left else (1, 0)
            return None if (-dx, -dy) == front else "preemptive"
        mx, my = monster.col - monster._from[0], monster.row - monster._from[1]
        came_from = (-(mx > 0) + (mx < 0), -(my > 0) + (my < 0))
        behind = tuple(-d for d in self.player.facing)
        return "ambush" if came_from == behind else None

    def _can_rush(self, monster: FieldMonster, caught: FieldMonster) -> bool:
        """Whether ``monster`` joins the rush on the party ``caught`` has caught: one that sees the party
        right now, that could touch it at all, and that is not a boss or the Great Boar's asker."""
        return (monster is not caught and monster.kind.get("lead") is not None
                and monster.spot.get("kind") != StorySettings.ASK_KIND and self._reachable(monster)
                and not monster.still and monster.watches((self.player.col, self.player.row)))

    def _catch(self, monster: FieldMonster, opening: str | None = "", blow: str | None = None) -> None:
        """A monster has caught the party (Frankie, 11/19, as in Earthbound): the party freezes for about
        a second while every other monster that sees it rushes in, and whoever arrives joins the fight.
        Who caught whom is fixed now, from the first touch. With no one else watching, or against a
        boss, the fight starts at once."""
        if opening == "":
            opening = self._who_caught(monster)
        rushers = [] if monster.spot.get("boss") or "lead" not in monster.kind else \
            [m for m in self._on_stage_monsters() if self._can_rush(m, monster)]
        if not rushers:
            self._start_fight(monster, opening=opening, blow=blow)
            return
        self.tool_wheel.cancel()
        self._strike = None
        for rusher in rushers:
            rusher.start_rush((self.player.col, self.player.row))
        self._rush = {"caught": monster, "opening": opening, "blow": blow, "t": 0.0,
                      "rushers": rushers, "arrived": []}

    def _tick_rush(self, dt: float) -> None:
        """The second of the rush: the party stands frozen (a step under way finishes), the rushers run in
        and may overlap each other and the party, and when it is up the fight starts with those that arrived."""
        rush = self._rush
        rush["t"] += dt
        if self.player._step_active:
            self.player.update(dt)
        here = (self.player.col, self.player.row)
        for monster in self._on_stage_monsters():
            if monster is rush["caught"]:
                continue
            if monster in rush["rushers"]:
                monster.update(dt, self.world, set(), here)
            else:
                taken = set().union(*(m.tiles() for m in self.monsters if m is not monster))
                monster.update(dt, self.world, taken, here if self._reachable(monster) else None)
            if monster.mark_sound:
                self.gm.audio.play(FieldMonsterSettings.MARK_SOUNDS[monster.mark_sound])
                monster.mark_sound = None
            if monster in rush["rushers"] and monster not in rush["arrived"] and here in monster.tiles():
                rush["arrived"].append(monster)
        if rush["t"] < FieldMonsterSettings.RUSH_SECONDS:
            return
        self._rush = None
        for monster in rush["rushers"]:
            monster.rushing = False
        self._start_fight(rush["caught"], opening=rush["opening"], blow=rush["blow"], joined=rush["arrived"])

    def _start_fight(self, monster: FieldMonster, opening: str | None = "", blow: str | None = None,
                     at_sea: bool = False, joined: list[FieldMonster] | None = None) -> None:
        at_sea = at_sea or bool(monster.kind.get("water"))   # a fight in the water stands on the sea
        """Push the fight ``monster`` brings, and remember whose it is.

        ``opening`` is who caught whom (None: a plain fight; the default works it out from the steps taken);
        ``blow`` is the fighter whose field strike hit it and lands a Strong stroke first (Frankie, 11/14).
        ``joined`` is the monsters that rushed in and are in the fight with it, lettered in the order they
        came (Frankie, 11/19).
        """
        # Local import: ``BattleScene`` lives in a sibling scene file
        # and importing it at the top would risk a cycle the moment a
        # battle ever needs to read overworld state on the way out.
        from core.scenes.battle_scene import BattleScene, compose_group

        # No running from a boss (Frankie, 10/26; Mark ran from the Great Boar in Episode 5).
        crowd = [monster, *(joined or [])]
        enemies, used = compose_group([m.kind for m in crowd])
        if self._woods_night():
            for entry in enemies:
                entry["stat_mult"] = StorySettings.WOODS_NIGHT_MULT
        self._joined = [crowd[i] for i in used if crowd[i] is not monster]
        battle = BattleScene(self.gm, enemies=enemies, in_town=self._in_town(),
                             opening=self._who_caught(monster) if opening == "" else opening,
                             opening_blow=blow, at_sea=at_sea,
                             can_escape=not monster.spot.get("boss"), underwater=self.player.swimming)
        self._fighting = (monster, battle)
        fight_swirl.arm(self.gm, battle)
        self.gm.scene_stack.push(battle)

    def render(self, surface: pygame.Surface) -> None:
        """Paint background, cell tiles, player, and message box in that order.

        Args:
            surface: The screen surface to draw onto.
        """
        if self.skipping is not None:
            # A scene being skipped plays behind black.
            surface.fill(ColorSettings.BLACK)
            return
        render_scene_background(self, surface)
        offset = room_offset(self.world.current_grid)
        room = surface
        if offset != (0, 0):
            # A room smaller than the screen is drawn whole and then moved to the middle.
            if self._room_layer is None or self._room_layer.get_size() != surface.get_size():
                self._room_layer = pygame.Surface(surface.get_size())
            room = self._room_layer
        trees = tree_tiles(self.world.current_grid, self.world.tree_kinds, set(self.world.building_tiles),
                           (self.world.flags, self.world.current_cell_name, self.world.seed))
        self._render_cell(room, trees)
        self._render_patches(room)
        shadows.draw_still(room, self.world.current_grid, self.world.buildings)
        self._render_shadows(room)
        cell_name = self.world.current_cell_name
        _BOAT_STATE["meialana"] = boat_state(self.gm.party.flags)
        for building in self.world.buildings:
            opened = (building["kind"] == "chest"
                      and bool(self.gm.party.flags.get(chest_flag(cell_name, building)))) \
                or (building["kind"] == "shrub" and not garden.shrub_ripe(self.gm.party, cell_name, building))
            draw_building(room, building, OverworldSettings.X, OverworldSettings.Y, opened)
            draw_sunk(room, self.world.current_grid, building, OverworldSettings.X, OverworldSettings.Y)
        crowns = [] if self.stage is not None else [
            b for b in self.world.buildings if b["kind"] in OverworldSettings.SORTED_BUILDINGS]
        # While a scene is on the stage, Kailo is only where it puts him: in a
        # room he is not staged in (the wake's cutaway to Melia) he is not there.
        self.player.override = (self._punch_pose() or self._chop_pose()) if self.stage is None else None
        self.player.hold_frame = self._punch_frame() if self.stage is None else None

        def draw_player() -> None:
            if self.stage is not None:
                self.stage.render(room)
            elif self._line is None or not self.player.render_fishing(
                    room, self._reel.left if self._reel is not None else max(0.0, self._line[2])):
                self.player.render(room)

        if crowns or trees:
            self._render_sorted(room, crowns, draw_player, trees)
        else:
            self._render_people(room)
            for monster in self._on_stage_monsters():
                monster.render(room)
            draw_player()
        self._render_drops(room)
        self._render_strike(room, (0, 0))
        for building in self.world.buildings:
            if building not in crowns:
                draw_rising(room, building, OverworldSettings.X, OverworldSettings.Y)
        if room is not surface:
            surface.fill(walls.DARK)
            surface.blit(room, offset)
        self._render_night(surface)
        if self.stage is None and self.story is None and self._card is None and not self._opening:
            render_corner(surface, self.gm.party, self.tool_wheel)
            tile = GridSettings.TILE_SIZE
            middle = (OverworldSettings.X + self.player.col * tile + tile // 2 + offset[0],
                      OverworldSettings.Y + self.player.row * tile + tile // 2 + offset[1])
            self.tool_wheel.render(surface, middle, self.gm.party)
            if not self.popup:
                notices.render(surface)
        # The opening's words stay lit as the beach fades in under them, and words on a
        # black screen ("The next morning.") are read on it, not under it (Frankie, 11/1).
        lit = self._opening or self._dark >= 1.0
        if not lit:
            self.text_box.render(surface)
        self._render_popup(surface)
        if self._reel is not None:
            below = OverworldSettings.Y + self.player.row * GridSettings.TILE_SIZE + offset[1] > surface.get_height() // 2
            render_reel(surface, self._reel, not self.gm.party.flags.get(FishingSettings.REEL_HINT_FLAG), below)
        self._render_dark(surface)
        if lit:
            self.text_box.render(surface)

    # ------------------------------------------------------------------
    # INTERNAL HELPERS
    # ------------------------------------------------------------------

    def _fly_through(self, dt: float) -> None:
        """B held for ``UISettings.B_FLY_AFTER`` seconds flies through the rest of the talk, a box every
        ``B_FLY_EVERY`` seconds, until it ends (Frankie, 11/12). Tapping B still fills a box, then turns it.
        A held slow line (Gen'emon's, Gajumaru's) is never skimmed; ``hurry`` is off for his first meeting."""
        # A menu on top took the key's release, so a gap in frames means B is no longer known to be held.
        now = time.monotonic()
        gap, self._b_last = now - self._b_last, now
        if gap > 0.5:
            self.text_box.hurry = False
        if not self.text_box.hurry or self.text_box.is_done():
            self._b_held = 0.0
            return
        self._b_held += dt
        if self._b_held < UISettings.B_FLY_AFTER:
            return
        self._b_fly += dt
        while self._b_fly >= UISettings.B_FLY_EVERY and not self.text_box.is_done():
            self._b_fly -= UISettings.B_FLY_EVERY
            self.text_box.skim()

    def _render_cell(self, surface: pygame.Surface, trees: list = ()) -> None:
        """Draw the active cell's tile grid, one picture per tile.

        The ground only changes when the grid, the trees, the holes, or the tide's and the ripple's step
        change, so the finished grid is kept as one picture per such state and blitted whole (the browser
        build was slow drawing ~220 tiles with their shore edges every frame). A shaking tree falls back
        to drawing tile by tile; a spring's twinkle is drawn over the kept picture.

        Args:
            surface: The screen surface to draw onto.
        """
        tiles = _tiles()
        if not tiles or (self._shake_left > 0 and self._shake is not None):
            self._paint_cell(surface, trees, (OverworldSettings.X, OverworldSettings.Y))
            return
        grid = self.world.current_grid
        ticks = pygame.time.get_ticks()
        key = ("".join("".join(row) + "|" for row in grid), self.world.current_cell_name,
               frozenset((col, row) for col, row, _ in trees), frozenset(self.world.building_tiles),
               frozenset(self._dug) if self._dug_room == self.world.current_cell_name else frozenset(),
               int(ticks / 1000 / edges.TIDE_SECONDS) % len(edges.TIDE_STEPS), int(ticks / 1000 / edges.RIPPLE_SECONDS) % 4)
        layer = self._ground_layers.get(key)
        if layer is None:
            if len(self._ground_layers) >= 40:
                self._ground_layers.clear()
            size = (OverworldSettings.COLS * GridSettings.TILE_SIZE, OverworldSettings.ROWS * GridSettings.TILE_SIZE)
            layer = pygame.Surface(size, pygame.SRCALPHA)
            self._paint_cell(layer, trees, (0, 0), sparkle=False)
            self._ground_layers[key] = layer
        surface.blit(layer, (OverworldSettings.X, OverworldSettings.Y))
        tile_size = GridSettings.TILE_SIZE
        for row in range(OverworldSettings.ROWS):
            for col in range(OverworldSettings.COLS):
                if grid[row][col] == OverworldSettings.SPRING_CHAR:
                    draw_sparkle(surface, col, row, (OverworldSettings.X + col * tile_size,
                                                     OverworldSettings.Y + row * tile_size), ticks)

    def _paint_cell(self, surface: pygame.Surface, trees: list, origin: tuple[int, int], sparkle: bool = True) -> None:
        """Draw the tile grid onto ``surface`` with its top left at ``origin``, tile by tile; ``sparkle`` adds the springs' twinkle."""
        grid = self.world.current_grid
        tile_size = GridSettings.TILE_SIZE
        tiles = _tiles()
        tree_cells = {(col, row) for col, row, _ in trees}
        for row in range(OverworldSettings.ROWS):
            row_cells = grid[row]
            for col in range(OverworldSettings.COLS):
                char = row_cells[col]
                x = origin[0] + col * tile_size
                y = origin[1] + row * tile_size
                if not tiles:
                    color = _TILE_COLORS.get(char, ColorSettings.OVERWORLD_FLOOR)
                    pygame.draw.rect(surface, color, (x, y, tile_size, tile_size))
                    continue
                if (col, row) in tree_cells:
                    # A palm drawn as the big tree: the ground here, the tree itself comes in its place in the order.
                    surface.blit(_pick(tiles[OverworldSettings.FLOOR_CHAR], col, row), (x, y))
                    continue
                if char == OverworldSettings.STUMP_CHAR:
                    # The stump a tree leaves: its size follows the kind of tree it was.
                    surface.blit(_pick(tiles[OverworldSettings.FLOOR_CHAR], col, row), (x, y))
                    nudge = 0
                    if self._shake == (col, row) and self._shake_left > 0:
                        steps = ToolSettings.SHAKE_PIXELS
                        nudge = steps[min(len(steps) - 1, int((1 - self._shake_left / ToolSettings.SHAKE_SECONDS) * len(steps)))]
                    surface.blit(_stump_picture(OverworldSettings.TREE_STUMP_SIZES.get(self.world.tree_kind_at(col, row), 1)),
                                 (x + nudge, y))
                    continue
                if self._shake == (col, row) and self._shake_left > 0:
                    # The chopped tree shakes: its picture steps side to side over the grass.
                    steps = ToolSettings.SHAKE_PIXELS
                    done = 1 - self._shake_left / ToolSettings.SHAKE_SECONDS
                    nudge = steps[min(len(steps) - 1, int(done * len(steps)))]
                    surface.blit(_pick(tiles[OverworldSettings.FLOOR_CHAR], col, row), (x, y))
                    surface.blit(_pick(tiles[char], col, row), (x + nudge, y))
                    continue
                draw_tile(surface, grid, col, row, (x, y), tiles, self.world.building_tiles)
                if char == OverworldSettings.SPRING_CHAR and sparkle:
                    draw_sparkle(surface, col, row, (x, y), pygame.time.get_ticks())
                if (col, row) in self._dug and self._dug_room == self.world.current_cell_name:
                    hole = _hole_picture()
                    if hole is not None:
                        surface.blit(hole, (x, y))

    def _wander_people(self, dt: float) -> None:
        """Villagers with ``wander`` stroll a few tiles from their spot (Frankie, 10/26).

        Each rests a while, then tries one step in a random direction: never off
        the room, onto a wall, a building, someone else, the party or the tile
        Kailo faces, and never further from where the room file puts them than
        ``wander`` tiles. Beside Kailo they hold still, so he can talk to them
        (Frankie, 10/26); talking, they turn to him and nobody walks.
        """
        dx, dy = self.player.facing
        kailo = (self.player.col, self.player.row)
        faced = (kailo[0] + dx, kailo[1] + dy)
        for person in self.world.people:
            reach = person.get("wander")
            if not reach:
                continue
            person.setdefault("_home", (person["col"], person["row"]))
            if person.get("_t", 1.0) < 1.0:
                person["_t"] = min(1.0, person["_t"] + dt * 1000 / TownSettings.WANDER_STEP_MS)
                continue
            if abs(person["col"] - kailo[0]) + abs(person["row"] - kailo[1]) == 1:
                continue
            person["_wait"] = person.get("_wait", random.uniform(*TownSettings.WANDER_WAIT_RANGE)) - dt
            if person["_wait"] > 0:
                continue
            person["_wait"] = random.uniform(*TownSettings.WANDER_WAIT_RANGE)
            dc, dr = random.choice(((1, 0), (-1, 0), (0, 1), (0, -1)))
            col, row = person["col"] + dc, person["row"] + dr
            home = person["_home"]
            if (not (0 <= col < OverworldSettings.COLS and 0 <= row < OverworldSettings.ROWS)
                    or self.world.is_wall(col, row) or (col, row) in (kailo, faced)
                    or abs(col - home[0]) + abs(row - home[1]) > reach):
                continue
            person["_from"] = (person["col"], person["row"])
            person["col"], person["row"], person["facing"] = col, row, [dc, dr]
            person["_t"] = 0.0

    def _render_shadows(self, surface: pygame.Surface) -> None:
        """A soft shadow under everyone who moves: people, hens, monsters and Kailo (Frankie, 11/24)."""
        tile = GridSettings.TILE_SIZE
        for person in self.world.people:
            if self.stage is not None and self.stage.hides(person):
                continue
            t = person.get("_t", 1.0)
            from_col, from_row = person.get("_from", (person["col"], person["row"]))
            shadows.draw_under(surface,
                               OverworldSettings.X + (from_col + (person["col"] - from_col) * t) * tile + tile / 2,
                               OverworldSettings.Y + (from_row + (person["row"] - from_row) * t + 1) * tile)
        for monster in self._on_stage_monsters():
            t = monster._progress
            col = monster._from[0] + (monster.col - monster._from[0]) * t
            row = monster._from[1] + (monster.row - monster._from[1]) * t
            shadows.draw_under(surface, OverworldSettings.X + (col + monster.width / 2) * tile,
                               OverworldSettings.Y + (row + monster.height) * tile, monster.width * tile - 2)
        if self.stage is None:
            x, y = self.player.feet_pixel()
            shadows.draw_under(surface, x, y)

    def _render_drops(self, surface: pygame.Surface) -> None:
        """Draw what lies on the ground on the front layer, over the tree or stump it fell from: the top one on each tile."""
        tile = GridSettings.TILE_SIZE
        for d in drops.top_per_tile(self._drops, self.world.current_cell_name):
            surface.blit(drops.picture(d.item), drops.rect(d).topleft)

    def _render_sorted(self, surface: pygame.Surface, crowns: list, draw_player, trees: list = ()) -> None:
        """Draw walkers and tall pictures in the order of how low on the screen each one's base stands, so whoever
        stands lower is drawn on top (Frankie, 11/23, the Stardew Valley way; ``SORTED_BUILDINGS``).
        A tree's crown is drawn after everyone standing above its base and before everyone below it."""
        tile = GridSettings.TILE_SIZE
        items = []
        for person in self.world.people:
            t = person.get("_t", 1.0)
            _, from_row = person.get("_from", (person["col"], person["row"]))
            base = OverworldSettings.Y + (from_row + (person["row"] - from_row) * t + 1) * tile
            items.append((base, 0, lambda person=person: self._render_people(surface, [person])))
        # A walker a crown covers shows through it in an outline (Frankie, 11/24 night): Kailo white, a monster red
        # and only when Kailo has a clear line to it. Nothing is outlined while a scene is on the stage.
        outliner = outlines.Outliner(surface)
        kailo = (self.player.col, self.player.row)
        for monster in self._on_stage_monsters():
            t = monster._progress
            base = OverworldSettings.Y + (monster._from[1] + (monster.row - monster._from[1]) * t + monster.height) * tile
            seen = self.stage is None and outlines.monster_seen(self.world, kailo, monster)
            where = (OverworldSettings.X + round((monster._from[0] + (monster.col - monster._from[0]) * t) * tile),
                     OverworldSettings.Y + round((monster._from[1] + (monster.row - monster._from[1]) * t) * tile))
            items.append((base, 0, lambda monster=monster, seen=seen, where=where: outliner.draw_walker(
                lambda: monster.render(surface), where, ColorSettings.OUTLINE_MONSTER if seen else None)))
        feet_x, feet_y = self.player.feet_pixel()
        items.append((feet_y, 0, lambda: outliner.draw_walker(
            draw_player, (round(feet_x) - tile // 2, round(feet_y) - tile),
            ColorSettings.OUTLINE_KAILO if self.stage is None else None)))
        for tree in crowns:
            base = OverworldSettings.Y + (tree["row"] + OverworldSettings.BUILDINGS[tree["kind"]][1][1]) * tile
            items.append((base, 1, lambda tree=tree: draw_rising(surface, tree, OverworldSettings.X,
                                                                  OverworldSettings.Y)))
        for col, row, kind in trees:
            nudge = 0
            if self._shake == (col, row) and self._shake_left > 0:
                steps = ToolSettings.SHAKE_PIXELS
                nudge = steps[min(len(steps) - 1, int((1 - self._shake_left / ToolSettings.SHAKE_SECONDS) * len(steps)))]
            items.append((OverworldSettings.Y + (row + 1) * tile, 2 if kind == "great_banyan" else 1,
                          lambda col=col, row=row, kind=kind, nudge=nudge: draw_tree(
                              surface, col, row, kind, OverworldSettings.X, OverworldSettings.Y, nudge)))
        for _, _, draw in sorted(items, key=lambda item: item[:2]):
            draw()
        outliner.finish()

    def _render_people(self, surface: pygame.Surface, people: list | None = None) -> None:
        """Draw everyone in the cell: standing, or part way along a wandering step."""
        tile_size = GridSettings.TILE_SIZE
        column = OverworldPlayerSettings.SHEET_COLUMNS
        for person in (self.world.people if people is None else people):
            if self.stage is not None and self.stage.hides(person):
                continue
            if person.get("sits"):
                self._render_sitter(surface, person)
                continue
            if person.get("hen"):
                self._render_hen(surface, person)
                continue
            t = person.get("_t", 1.0)
            walker = walker_frames(person["sheet"])
            if walker:
                # Walker art (an NPC's walk/ frames, game/assets/sprites): stand, step, stand, step mirrored; the feet
                # alternate from tile to tile, as the player's do.
                frames = walker[column.get(tuple(person["facing"]), 0) % len(walker)]
                per_step = OverworldPlayerSettings.FRAMES_PER_STEP
                frame = ((person["col"] + person["row"]) % 2 * per_step + min(per_step - 1, int(t * per_step))
                         if t < 1.0 else 0)
                from_col, from_row = person.get("_from", (person["col"], person["row"]))
                surface.blit(frames[frame % len(frames)], (
                    OverworldSettings.X + round((from_col + (person["col"] - from_col) * t) * tile_size),
                    OverworldSettings.Y + round((from_row + (person["row"] - from_row) * t) * tile_size),
                ))
                continue
            sheet = _person_sheet(person["sheet"])
            if sheet is None:
                continue
            # The feet move while they step; standing is the first frame.
            step = int(t * OverworldPlayerSettings.WALK_FRAMES) if t < 1.0 else 0
            frame = sheet.subsurface(pygame.Rect(
                column.get(tuple(person["facing"]), 0) * tile_size,
                min(step, sheet.get_height() // tile_size - 1) * tile_size, tile_size, tile_size,
            ))
            from_col, from_row = person.get("_from", (person["col"], person["row"]))
            surface.blit(frame, (
                OverworldSettings.X + round((from_col + (person["col"] - from_col) * t) * tile_size),
                OverworldSettings.Y + round((from_row + (person["row"] - from_row) * t) * tile_size),
            ))

    @staticmethod
    def _render_hen(surface: pygame.Surface, person: dict) -> None:
        """A hen (Frankie, 10/28): her two frames by turns, flipped when she faces right."""
        sheet = _person_sheet(person["sheet"], HenSettings.SHEET)
        if sheet is None:
            return
        tile_size = GridSettings.TILE_SIZE
        frame = int(pygame.time.get_ticks() / 1000 / HenSettings.FRAME_SECONDS) % 2
        picture = sheet.subsurface(pygame.Rect(frame * tile_size, 0, tile_size, tile_size))
        if person["facing"][0] > 0:
            picture = pygame.transform.flip(picture, True, False)
        t = person.get("_t", 1.0)
        from_col, from_row = person.get("_from", (person["col"], person["row"]))
        surface.blit(picture, (
            OverworldSettings.X + round((from_col + (person["col"] - from_col) * t) * tile_size),
            OverworldSettings.Y + round((from_row + (person["row"] - from_row) * t) * tile_size),
        ))

    @staticmethod
    def _render_sitter(surface: pygame.Surface, person: dict) -> None:
        """Someone sitting, who never walks (the Kaigara Kame): their picture, now and then a blink."""
        sheet = _person_sheet(person["sheet"], KaigaraSettings.SIT_SHEET)
        if sheet is None:
            return
        tile_size = GridSettings.TILE_SIZE
        blink = pygame.time.get_ticks() / 1000 % KaigaraSettings.BLINK_EVERY < KaigaraSettings.BLINK_SECONDS
        frame = sheet.subsurface(pygame.Rect(tile_size if blink else 0, 0, tile_size, tile_size))
        surface.blit(frame, (OverworldSettings.X + person["col"] * tile_size,
                             OverworldSettings.Y + person["row"] * tile_size))

    def _open_menu(self) -> None:
        """Push the field menu on top of this scene: tabs across the top, the party on the left
        (Dragon Quest VIII's, Frankie 11/13; ``field_menu_scene.py``)."""
        # Local import: the menu's scenes live in sibling modules and importing them at top of file
        # would risk a cycle if the menu ever pushes overworld-aware actions later.
        from core.scenes.field_menu_scene import FieldMenuScene

        self.gm.scene_stack.push(FieldMenuScene(self.gm))

    def _open_map(self) -> None:
        """SELECT: the area map, of the rooms found, with Kailo where he stands (Frankie, 10/26)."""
        from core.scenes.map_scene import MapScene  # local: as the menu

        self.world.seen.add(self.world.current_cell_name)
        self.gm.scene_stack.push(MapScene(self.gm, self.world.seen, self.world.current_cell_name,
                                          self.player.col, self.player.row))

    # ------------------------------------------------------------------
    # PERSISTENCE
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Serialise the active cell pointer and the player's tile state."""
        base = super().to_dict()
        base["world"] = self.world.to_dict()
        base["player"] = self.player.to_dict()
        return base

    @classmethod
    def from_dict(cls, gm: "GameManager", data: dict) -> "OverworldScene":
        """Rebuild a scene from a previously-saved dict.

        Args:
            gm: The host game manager.
            data: The dict previously returned by ``to_dict``.

        Returns:
            A fully-restored ``OverworldScene``.
        """
        scene = cls(gm)
        if isinstance(data, dict):
            world_data = data.get("world")
            if isinstance(world_data, dict):
                scene.world.from_dict(world_data)
            player_data = data.get("player")
            if isinstance(player_data, dict):
                scene.player.from_dict(player_data)
            if getattr(scene.world, "moved_from_gone_room", False):
                scene._step_off_things()
        return scene

    def _step_off_things(self) -> None:
        """If the party stands on something (a save from a room since rearranged),
        move it to the nearest open tile."""
        start = (self.player.col, self.player.row)
        seen, queue = {start}, [start]
        while queue:
            col, row = queue.pop(0)
            inside = 0 <= col < OverworldSettings.COLS and 0 <= row < OverworldSettings.ROWS
            if inside and not self.world.is_wall(col, row):
                if (col, row) != start:
                    self.player.from_dict({"col": col, "row": row})
                return
            for dc, dr in ((0, 1), (0, -1), (1, 0), (-1, 0)):
                nxt = (col + dc, row + dr)
                if nxt not in seen and 0 <= nxt[0] < OverworldSettings.COLS and 0 <= nxt[1] < OverworldSettings.ROWS:
                    seen.add(nxt)
                    queue.append(nxt)
