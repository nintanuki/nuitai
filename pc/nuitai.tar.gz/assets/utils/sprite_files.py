"""Where every game sprite is: ``game/assets/sprites/``, shared by pygame and the cartridge (Frankie, 11/13).

Sorted by who is in the picture, under the character's real name::

    characters/heroes/<hero>/   walk.png (the Ninja-style sheet), walk/ (16 by 16 frames, Frankie's
                                Aseprite file beside them), battle/<animation>.png, portrait.png,
                                icon.png, battle-src/ (the PixelLab frames the strips are packed from)
    characters/npcs/<name>/     walk.png or sit.png, walk/ where a doll walker exists, portrait.png
    characters/unknown-portrait.png
    monsters/<name>/            battle.png, battle-idle.png, field.png (its map sheet)

The rooms and the field monsters still name a sheet by its old file stem (``"sheet": "LittleBoy"``
is Keo), because the cartridge's code is built on those ids. ``sheets.json`` turns an id into its
file, so this module is the only place that knows the folders. No pygame here: the cartridge's art
tools import it too. The browser build copies the tree into ``sprites/`` inside the game, which is
looked at first.
"""

from __future__ import annotations

import json
import os

_GAME_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPRITES_DIR = (os.path.join(_GAME_DIR, "sprites") if os.path.exists(os.path.join(_GAME_DIR, "sprites", "sheets.json"))
               else os.path.join(os.path.dirname(_GAME_DIR), "assets", "sprites"))
CHARACTERS_DIR = os.path.join(SPRITES_DIR, "characters")
MONSTERS_DIR = os.path.join(SPRITES_DIR, "monsters")
HEROES = ("kailo", "hina", "maika", "tawiri")
UNKNOWN_PORTRAIT = os.path.join(CHARACTERS_DIR, "unknown-portrait.png")

with open(os.path.join(SPRITES_DIR, "sheets.json"), encoding="utf-8") as _f:
    _TABLE = json.load(_f)
SHEETS: dict[str, str] = _TABLE["people"]
_MONSTER_FOLDER: dict[str, str] = _TABLE["monster_folders"]


def sheet_path(stem: str) -> str:
    """The file of a sheet named by its old stem (``"OldMan-Walk"``, ``"Hen"``, ``"Kame-Sit"``).

    An unknown stem gives a path that does not exist, so callers' ``os.path.exists`` checks
    fall back the way they did when the file was missing.
    """
    rel = SHEETS.get(stem)
    return os.path.join(SPRITES_DIR, rel) if rel else os.path.join(SPRITES_DIR, "none", f"{stem}.png")


def sheet_stems(suffix: str = "-Walk") -> list[str]:
    """Every sheet id with ``suffix`` on its stem, without it (``"OldMan"``), sorted."""
    return sorted(stem[:-len(suffix)] for stem in SHEETS if stem.endswith(suffix))


def walker_sheet(name: str) -> str | None:
    """A hero's or an NPC's walker sheet, ``walker.png``, or None when there is none.

    One sheet per character (Frankie, 11/13): a 16 by 16 column per facing, south, north, west, east,
    frames top down; west and east have two, their lower cells empty.

    ``name`` is a hero's id or an NPC's sheet id, either case (``"kailo"``, ``"OldMan"``).
    """
    key = name.lower()
    if key in HEROES:
        folder = os.path.join(CHARACTERS_DIR, "heroes", key)
    else:
        stem = next((s for s in SHEETS if s.lower() == f"{key}-walk"), None)
        if stem is None:
            return None
        folder = os.path.dirname(sheet_path(stem))
    path = os.path.join(folder, "walker.png")
    return path if os.path.isfile(path) else None


def character_dir(who: str) -> str:
    """A hero's or a named NPC's folder, by the id the portraits use (``"ulu"``, ``"keo"``)."""
    group = "heroes" if who in HEROES else "npcs"
    return os.path.join(CHARACTERS_DIR, group, who)


def portrait_path(who: str) -> str:
    """``who``'s portrait, which may not exist."""
    return os.path.join(character_dir(who), "portrait.png")


def icon_path(who: str) -> str:
    """A hero's small turn-order face, which may not exist."""
    return os.path.join(character_dir(who), "icon.png")


def battle_strip_path(name: str) -> str:
    """A hero's battle animation strip, ``"kailo_idle_stance1"`` -> ``heroes/kailo/battle/idle_stance1.png``."""
    who, _, animation = name.partition("_")
    return os.path.join(CHARACTERS_DIR, "heroes", who, "battle", f"{animation}.png")


def monster_dir(sprite: str) -> str:
    """A monster's folder by its battle picture id (``"wicked_witch"`` is the Mangkukulam)."""
    return os.path.join(MONSTERS_DIR, _MONSTER_FOLDER.get(sprite, sprite))


def monster_picture(sprite: str) -> str:
    """A monster's still battle picture, which may not exist."""
    return os.path.join(monster_dir(sprite), "battle.png")


def monster_idle(sprite: str) -> str:
    """A monster's idle battle strip, which may not exist."""
    return os.path.join(monster_dir(sprite), "battle-idle.png")


def monster_sprites() -> list[str]:
    """Every battle picture id there is a file for, sorted."""
    back = {folder: sprite for sprite, folder in _MONSTER_FOLDER.items()}
    return sorted(back.get(d, d) for d in os.listdir(MONSTERS_DIR)
                  if os.path.exists(os.path.join(MONSTERS_DIR, d, "battle.png")))
