# The palm-frond canopy

`palm-fronds.png`: the wall round every room (the ring of `#` tiles at its edge), in place of border palms
(Frankie, 11/13: players took the unchoppable border palms for palms they could chop).

Made by PixelLab (Frankie's account, 11/13): `create_topdown_tileset`, pro mode, 16 by 16, high top-down,
flat transition, grass as the lower terrain and dense dark tropical canopy of coconut palm fronds as the
upper, palette Mini World's three grass greens plus jungle greens. 64 by 64: sixteen Wang tiles, one for
each way a tile's four corners can be canopy or grass. The tileset id is c7826022-842d-4c0d-84de-f636bb05e28f (the palm fronds sample, b).

How the game composes it (`ui/canopy.py`, drawn through `draw_tile` so the game, the Workshop and the
cartridge's art step all match, the same as the mid3 preview in `art/previews/canopy-border/`):

1. A wall tile on the room's edge takes the sheet tile for its four corners. A corner counts as canopy only
   if every wall tile round it is a border wall (off the screen counts as wall), so every end of the wall, at
   an exit, a river or a corner, is a rounded end from the sheet.
2. The tile slides 4 pixels toward the room, so the leafy edge ends at the tile's inner edge. The strip that
   opens on the wall side is filled from the sheet's solid all-canopy tile (the one with all four corners
   canopy), never by repeating rows.
3. The grass the sheet drew under the edge (only grass joined to a grass corner) is cut out, so the room's
   own grass shows.

Nothing else changed: the tiles are still `#`, so walls, exits and chopping are as before.
