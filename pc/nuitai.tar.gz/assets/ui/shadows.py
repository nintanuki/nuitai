"""Soft shadows on the field (Frankie, 11/24, the "soft" one of three test styles; the Polish plan's second fix).

A small see-through oval under every palm, building, person, hen, monster and Kailo, so they look planted on
the ground instead of floating. The oval darkens the ground a step toward a cool blue, straight under the thing.

Palms and buildings never move, so their shadows are worked out once per room and only darken grass and sand,
never a trunk or a wall. People, hens, monsters and Kailo move, so theirs are drawn each frame, under their feet.
The numbers are ``ShadowSettings``.
"""
from __future__ import annotations

import os
import sys
from array import array

import pygame

from core.overworld_cells import building_size
from settings import GridSettings, OverworldSettings, ShadowSettings
from ui import canopy

_GROUND: set | None = None
_STILL: dict = {}      # the room's key -> its baked palm and building shadows
_OVALS: dict = {}      # (width, height) -> one oval, already see-through


def _ground() -> set:
    """Every grass and sand color in the ground tiles: the only colors a still shadow darkens."""
    global _GROUND
    if _GROUND is None:
        _GROUND = set()
        tiles = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "graphics", "tiles")
        for name in ShadowSettings.GROUND_TILES:
            path = os.path.join(tiles, name)
            if not os.path.exists(path):
                continue
            picture = pygame.image.load(path)
            # Every pixel's four bytes as one number, so a set finds the picture's colors at C speed
            # (looking at each pixel in Python took seconds in the browser, at the first room).
            for packed in set(array("I", pygame.image.tobytes(picture, "RGBA"))):
                r, g, b, a = (packed & 255, packed >> 8 & 255, packed >> 16 & 255, packed >> 24 & 255) \
                    if sys.byteorder == "little" else (packed >> 24 & 255, packed >> 16 & 255, packed >> 8 & 255, packed & 255)
                if a and r + g + b > ShadowSettings.DARKEST_GROUND:
                    _GROUND.add((r, g, b))
    return _GROUND


def _oval(width: int, height: int) -> pygame.Surface:
    key = (width, height)
    if key not in _OVALS:
        oval = pygame.Surface(key, pygame.SRCALPHA)
        pygame.draw.ellipse(oval, ShadowSettings.COLOR + (ShadowSettings.ALPHA,), oval.get_rect())
        _OVALS[key] = oval
    return _OVALS[key]


def _still_spots(grid, buildings, big_trees: bool = True) -> list:
    """(centre x, bottom y, width, height) under every palm and building, in room pixels."""
    tile = GridSettings.TILE_SIZE
    spots = []
    for row, cells in enumerate(grid):
        for col, char in enumerate(cells):
            if char == OverworldSettings.WALL_CHAR and not canopy.is_canopy(grid, col, row):
                spots.append((col * tile + tile // 2, (row + 1) * tile - 1)
                             + (ShadowSettings.TREE if big_trees else ShadowSettings.PALM))
    for building in buildings:
        width, height = building_size(building)
        if building["kind"] in OverworldSettings.SORTED_BUILDINGS:
            spots.append((building["col"] * tile + tile // 2, (building["row"] + height) * tile + 1)
                         + ShadowSettings.BANYAN)
            continue
        size = ShadowSettings.BUILDING if width > 1 else ShadowSettings.SMALL_BUILDING
        spots.append((building["col"] * tile + width * tile // 2, (building["row"] + height) * tile + 1,
                      width * tile + size[0], size[1]))
    return spots


def draw_still(surface: pygame.Surface, grid, buildings, big_trees: bool = True) -> None:
    """The palms' and buildings' shadows, over the room's tiles just drawn and under everything else."""
    key = (tuple("".join(cells) for cells in grid),
           tuple((b["kind"], b["col"], b["row"], bool(b.get("sideways"))) for b in buildings), big_trees)
    layer = _STILL.get(key)
    if layer is None:
        if len(_STILL) > ShadowSettings.ROOMS_KEPT:
            _STILL.clear()
        layer = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        ground = _ground()
        shade = ShadowSettings.COLOR + (ShadowSettings.ALPHA,)
        bounds = surface.get_rect()
        for centre, bottom, width, height in _still_spots(grid, buildings, big_trees):
            rect = pygame.Rect(0, 0, width, height)
            rect.midbottom = (OverworldSettings.X + centre, OverworldSettings.Y + bottom)
            oval = _oval(width, height)
            for x in range(width):
                for y in range(height):
                    spot = (rect.x + x, rect.y + y)
                    if (oval.get_at((x, y)).a and bounds.collidepoint(spot)
                            and tuple(surface.get_at(spot)[:3]) in ground):
                        layer.set_at(spot, shade)
        _STILL[key] = layer
    surface.blit(layer, (0, 0))


def draw_under(surface: pygame.Surface, x: float, bottom: float, width: int | None = None) -> None:
    """A moving thing's shadow: centred on ``x``, its bottom at ``bottom`` (screen pixels, the thing's feet)."""
    width = width or ShadowSettings.WALKER[0]
    height = ShadowSettings.WALKER[1]
    oval = _oval(width, height)
    surface.blit(oval, (round(x - width / 2), round(bottom + ShadowSettings.BELOW_FEET - height)))
