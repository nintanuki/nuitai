"""The charge-up over a fighter who is about to use an element (Frankie, 11/17, after Super Mario RPG).

The aura is the game's own element icon (the hibiscus, flame, wave, skull, spiral and sun beside each
name on the party HUD), the detailed 18 by 18 art of the party Status screen, its frame and ground dropped, scaled up three times with no smoothing to 48, painted one flat color of
the element's own (``ColorSettings.ELEMENT_COLORS``) with its dark details kept a shade darker, and
drawn semi-transparent OVER the fighter, centered on them. It never changes shape: it fades in, holds
with a pulse of brightness and a few sparkles, flashes, fades out, and then the element happens.
"""

from __future__ import annotations

import math
import os
from functools import lru_cache

import pygame

from settings import AssetPaths, BattleStageSettings as Stage, ColorSettings


def _ground(art: pygame.Surface) -> set[tuple[int, int]]:
    """The black ground round the picture: black pixels joined to its edge (a skull's eyes are not)."""
    w, h = art.get_size()
    def black(x: int, y: int) -> bool:
        r, g, b, a = art.get_at((x, y))
        return a == 0 or (r, g, b) == (0, 0, 0)
    todo = [(x, y) for x in range(w) for y in (0, h - 1)] + [(x, y) for y in range(h) for x in (0, w - 1)]
    seen: set[tuple[int, int]] = set()
    while todo:
        x, y = todo.pop()
        if (x, y) in seen or not (0 <= x < w and 0 <= y < h) or not black(x, y):
            continue
        seen.add((x, y))
        todo += [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]
    return seen


@lru_cache(maxsize=None)
def _icon(element: str) -> pygame.Surface:
    """The element's detailed icon (the party Status screen's, 18 by 18 with a one pixel frame), without its
    frame and ground, painted in four tones of the element's color by how bright each pixel was, then scaled
    up three times with no smoothing to 48 by 48, with no edge."""
    full = pygame.image.load(os.path.join(AssetPaths.ICONS_DIR, f"{element}.png")).convert_alpha()
    art = full.subsurface(pygame.Rect(1, 1, full.get_width() - 2, full.get_height() - 2)).copy()
    color = Stage.CHARGE_COLORS.get(element) or ColorSettings.ELEMENT_COLORS[element]
    tones = (tuple(c // 3 for c in color), tuple(round(c * 0.65) for c in color), color,
             tuple(min(255, c + 45) for c in color))
    ground = _ground(art)
    flat = pygame.Surface(art.get_size(), pygame.SRCALPHA)
    for y in range(art.get_height()):
        for x in range(art.get_width()):
            if (x, y) in ground:
                continue
            r, g, b, a = art.get_at((x, y))
            bright = (0.3 * r + 0.59 * g + 0.11 * b) / 255
            flat.set_at((x, y), (*tones[0 if bright < 0.25 else 1 if bright < 0.5 else 2 if bright < 0.8 else 3], 255))
    scale = Stage.CHARGE_SIZE // art.get_width()
    big = pygame.transform.scale(flat, (flat.get_width() * scale, flat.get_height() * scale))   # nearest
    return big


def _alpha_and_glow(age: float) -> tuple[float, float]:
    """(opacity 0 to 1, whiteness 0 to 1) at ``age`` seconds: fade in, hold and pulse, flash, fade out."""
    end = Stage.CHARGE_SECONDS_SHOWN
    fade_in, flash_at, flash_len, fade_out = (
        Stage.CHARGE_FADE_IN_SECONDS, Stage.CHARGE_FLASH_AT, Stage.CHARGE_FLASH_SECONDS, Stage.CHARGE_FADE_OUT_SECONDS)
    if age < fade_in:
        return age / fade_in, 0.0
    if age < flash_at:
        return 1.0, 0.10 * (0.5 + 0.5 * math.sin((age - fade_in) * math.tau * Stage.CHARGE_PULSE_HZ))
    if age < flash_at + flash_len:
        return 1.0, 0.9
    return max(0.0, (end - age) / max(1e-6, fade_out)), 0.3


def render_charge(surface: pygame.Surface, element: str, center: tuple[int, int], age: float) -> None:
    """Draw the aura over a fighter, ``age`` seconds into its charge."""
    if element not in Stage.CHARGE_ELEMENTS or age >= Stage.CHARGE_SECONDS_SHOWN:
        return
    opacity, glow = _alpha_and_glow(age)
    if opacity <= 0:
        return
    picture = _icon(element).copy()
    if glow > 0:
        picture.fill((round(255 * glow),) * 3 + (0,), special_flags=pygame.BLEND_RGB_ADD)
    picture.set_alpha(round(Stage.CHARGE_ALPHA * opacity))
    rect = picture.get_rect(center=center)
    surface.blit(picture, rect)
    # A few sparkles twinkling round it while it holds.
    if Stage.CHARGE_FADE_IN_SECONDS <= age < Stage.CHARGE_FLASH_AT + Stage.CHARGE_FLASH_SECONDS:
        for n in range(Stage.CHARGE_SPARKLES):
            seed = n * 2.399963   # the golden angle, so they spread evenly
            if int(age * 14 + n * 3) % 4 == 0:
                continue          # off for a beat: twinkling
            radius = rect.width * (0.42 + 0.1 * ((n * 7) % 3) / 2)
            x = center[0] + round(math.cos(seed) * radius)
            y = center[1] + round(math.sin(seed) * radius)
            pygame.draw.rect(surface, (255, 255, 255), (x - 1, y, 3, 1))
            pygame.draw.rect(surface, (255, 255, 255), (x, y - 1, 1, 3))
