"""Translate battle events into text-box narration.

The battle simulation emits typed events (see ``core/events.py``); the
view subscribes to them and pushes phrased lines into a ``TextBox``.
This is the seam that lets the same battle logic drive a text-only
presentation now and sprites and animation later.

One event becomes at most one line, so the scene can show each line
while the matching change (an HP number dropping) appears on screen.
Phrasing is intentionally barebones; a writing pass comes later.
"""

from __future__ import annotations

from core.events import (
    AbilityUsedEvent,
    AttackEvent,
    BattleEndedEvent,
    ChainEndedEvent,
    CleansedEvent,
    CureFailedEvent,
    ComboUsedEvent,
    CombatantDefeatedEvent,
    DamageEvent,
    DefendEvent,
    DodgeEvent,
    EscapeEvent,
    GuardInterceptEvent,
    GuardRaisedEvent,
    HealEvent,
    MissEvent,
    NoteEvent,
    NoniUsedEvent,
    RevivedEvent,
    StanceEvent,
    StatGrowthEvent,
    StatusAppliedEvent,
    StatusResistedEvent,
    SwapEvent,
    TurnSkippedEvent,
    WardBlockedEvent,
    SlotEvent,
    WeaponEvent,
)
from core.stats import STAT_NAMES
from settings import ColorSettings
from ui.notice_bar import NoticeBar
from ui.text_box import TextBox


# What a combatant is told when a status takes hold.
_STATUS_GAINED: dict[str, str] = {
    "blind": "{name} is blinded.",
    "sleep": "{name} falls asleep.",
    "poison": "{name} is poisoned.",
    "ward": "A ward of light settles on {name}, against the next shadow hit.",
    "haste": "{name} speeds up.",
    "safeguard": "A safeguard settles on {name}.",
    "regen": "{name}'s wounds begin to close.",
    "protect": "{name} hardens against blows.",
    "shell": "{name} hardens against magic.",
    "possess": "One of the dead possesses {name}.",
    "turned": "The dead spirit in {name} turns it on its own side!",
    # The kits (10/21), in the browser's words.
    "burn": "{name} catches fire.",
    "weak": "{name} is weakened.",
    "mbreak": "{name}'s mind cracks.",
    "calm": "{name} is stilled.",
    "mleech": "Maika latches onto {name}'s mana.",
    "seed": "A seed is planted in {name}.",
    "sprout": "A seed is planted on {name}.",
    "bloom": "A flower opens on {name}.",
    "perennial": "{name} will rise again if they fall.",
    "haunt": "A spirit follows {name}.",
    "doom": "{name} is doomed.",
    "sap": "{name}'s mana starts to drain.",
    "up_magic": "{name}'s Magic goes up.",
    "up_hp": "{name}'s Max HP goes up.",
    # Scold's reactions (10/21), in the browser's words.
    "sulk": "{name} starts sulking.",
    "up_strength": "{name}'s Strength goes up.",
    "up_vitality": "{name}'s Vitality goes up.",
    "dn_magic": "{name}'s Magic goes down.",
    "dn_strength": "{name}'s Strength goes down.",
    "dn_evasion": "{name}'s Evasion goes down.",
    "dn_accuracy": "{name}'s Accuracy goes down.",
    "dn_vitality": "{name}'s Vitality goes down.",
    "dn_spirit": "{name}'s Spirit goes down.",
    # Charm's (Frankie, 10/25).
    "charmed": "{name} is charmed and fights for the party.",
}

# What is said when a status ends, where "shakes off" would not fit.
_STATUS_LOST: dict[str, str] = {
    "possess": "The spirit leaves {name}.",
    "charmed": "{name} snaps out of the charm.",
    "burn": "{name}'s burn cools.",
    "sleep": "{name} wakes up.",
    "poison": "The poison leaves {name}.",
    "spirit_knocked": "The blow knocks the spirit out of {name}.",
    "up_magic": "{name}'s Magic goes back down.",
    "up_hp": "{name}'s Max HP goes back down.",
    "up_strength": "{name}'s Strength goes back down.",
    "up_vitality": "{name}'s Vitality goes back down.",
    "dn_magic": "{name}'s Magic comes back.",
    "dn_strength": "{name}'s Strength comes back.",
    "dn_evasion": "{name}'s Evasion comes back.",
    "dn_accuracy": "{name}'s Accuracy comes back.",
    "dn_vitality": "{name}'s Vitality comes back.",
    "dn_spirit": "{name}'s Spirit comes back.",
}

_GUARD_RAISED: dict[str, str] = {
    "sentinel": "{name} stands guard over the party.",
    "counter": "{name} stands guard, ready to kick back.",
    "cooker": "{name} puts the lid on.",
    "bell": "{name} bangs the pan. Dinner!",
    "oil": "{name} heats the oil.",
    "steam": "{name} starts to steam.",
    "boil": "{name} puts the lid on the whole kitchen.",
    "cast_iron": "{name} sets like cast iron.",
    "oven_mitt": "{name} pulls on the oven mitt.",
}

# Damage a NoteEvent already tells about: no second line for the number.
_TOLD: tuple[str, ...] = ("burn", "haunt", "seed", "mana_burn", "steam", "toll", "doom")

_OUTCOMES: dict[str, str] = {
    "victory": "Victory.",
    "defeat": "The party has fallen.",
    "flee": "Escaped.",
}


class BattleView:
    """Push narration lines for battle events into a text box."""

    def __init__(self, text_box: TextBox, notices: NoticeBar | None = None) -> None:
        """Bind the view to the text box it narrates into, and the bar for growth lines."""
        self.text_box = text_box
        self.notices = notices

    def consume(self, event: object) -> None:
        """Phrase one battle event into the text box.

        Events with nothing worth saying (a turn starting) push no
        line; unknown events are ignored so the simulation can grow
        new ones without breaking this view.
        """
        if isinstance(event, StatGrowthEvent):
            # Said as it happens (D-498), the stat's name in its colour
            # (D-503 to D-505, D-509).
            # It shows in the bar along the top, so the fight does not
            # stop for it (D-526), shortened to fit the bar's 28 letters.
            name = STAT_NAMES[event.stat]
            (self.notices or self.text_box).push(
                f"{event.member_name}'s {name} up!" if self.notices
                else f"{event.member_name}'s {name} went up!",
                keywords={name: ColorSettings.STAT_TEXT_STYLES.get(event.stat, {})},
            )
            return
        line = self._line_for(event)
        if line:
            self.text_box.push(line)

    def _line_for(self, event: object) -> str | None:
        """Return the narration line for ``event``, or None."""
        if isinstance(event, NoteEvent):
            return event.text
        if isinstance(event, AttackEvent):
            if event.move_name:
                return (
                    f"{event.attacker_name} uses {event.move_name} "
                    f"on {event.target_name}."
                )
            return f"{event.attacker_name} attacks {event.target_name}."
        if isinstance(event, DamageEvent):
            return self._damage_line(event)
        if isinstance(event, DodgeEvent):
            # A stroke's dodge shows as a floating word, not a line.
            if event.stroke:
                return None
            return f"{event.target_name} dodges."
        if isinstance(event, ChainEndedEvent):
            if event.fell:
                return None
            if event.total <= 0:
                if event.target_name:
                    return f"{event.target_name} dodges {event.attacker_name}."
                return f"{event.attacker_name} misses."
            if event.target_name:
                return (
                    f"{event.attacker_name} hits {event.target_name} "
                    f"for {event.total}."
                )
            return f"{event.attacker_name} deals {event.total} in all."
        if isinstance(event, MissEvent):
            return f"{event.attacker_name} is blind and misses."
        if isinstance(event, GuardRaisedEvent):
            template = _GUARD_RAISED.get(event.guard, "{name} stands guard.")
            return template.format(name=event.combatant_name)
        if isinstance(event, GuardInterceptEvent):
            return f"{event.guard_name} steps in front of {event.target_name}."
        if isinstance(event, WardBlockedEvent) and event.status:
            return f"Safeguard stops the {event.status} on {event.target_name}."
        if isinstance(event, WardBlockedEvent) and event.share < 1:
            return f"Shaka's Light softens the shadow on {event.target_name}."
        if isinstance(event, WardBlockedEvent):
            return f"Shaka's Light blocks the shadow on {event.target_name}."
        if isinstance(event, StatusAppliedEvent):
            template = _STATUS_GAINED.get(event.status)
            if template and event.applied:
                return template.format(name=event.target_name)
            if not event.applied and event.status in _STATUS_LOST:
                return _STATUS_LOST[event.status].format(name=event.target_name)
            verb = "is afflicted by" if event.applied else "shakes off"
            return f"{event.target_name} {verb} {event.status}."
        if isinstance(event, StatusResistedEvent):
            if event.status == "charmed":
                return f"{event.target_name} is not charmed."
            if event.immune:
                return f"{event.target_name} is immune to {event.status}."
            return f"{event.status.capitalize()} does not take hold on {event.target_name}."
        if isinstance(event, CleansedEvent):
            return f"{event.target_name} is cleansed."
        if isinstance(event, CureFailedEvent):
            return f"The cure failed on {event.target_name}."
        if isinstance(event, TurnSkippedEvent):
            return f"{event.combatant_name} is asleep and loses the turn."
        if isinstance(event, StanceEvent):
            # A monster's stance has no name. Its switch is always said, by the new
            # element, scanned or not (Frankie, 10/28; it was only "changes stance", D-595;
            # "shifts to", Frankie, 11/4).
            if not event.stance_name:
                return f"{event.combatant_name} shifts to {event.element.label.lower()} stance."
            return f"{event.combatant_name} shifts into {event.stance_name}."
        if isinstance(event, DefendEvent):
            return f"{event.combatant_name} braces for the blow."
        if isinstance(event, AbilityUsedEvent):
            if event.target_name:
                return (
                    f"{event.user_name} uses {event.ability_name} "
                    f"on {event.target_name}!"
                )
            return f"{event.user_name} uses {event.ability_name}!"
        if isinstance(event, ComboUsedEvent):
            return f"{event.user_name} and {event.partner_name}: {event.combo_name}!"
        if isinstance(event, SwapEvent):
            return f"{event.in_name} steps in for {event.out_name}."
        if isinstance(event, WeaponEvent):
            return f"{event.combatant_name} takes up the {event.weapon_name}."
        if isinstance(event, SlotEvent):
            return f"{event.combatant_name} {'banks' if event.banked else 'slots'} {event.move_name}."
        if isinstance(event, EscapeEvent):
            if event.escaped:
                return f"{event.combatant_name} gets away!"
            return f"{event.combatant_name} can't get away!"
        if isinstance(event, HealEvent):
            if event.amount <= 0:
                return None  # a heal that restores nothing says nothing (Frankie, 11/5)
            return f"{event.target_name} recovers {event.amount} HP."
        if isinstance(event, NoniUsedEvent):
            # Self-use vs giving the Noni to another character.
            if event.thrown:
                return f"{event.user_name} throws the Noni at {event.target_name}."
            if event.user_id == event.target_id:
                return f"{event.user_name} uses the Noni."
            return f"{event.user_name} gives {event.target_name} the Noni."
        if isinstance(event, CombatantDefeatedEvent):
            if event.fled:
                return f"{event.combatant_name} leaves the fight."
            return f"{event.combatant_name} falls."
        if isinstance(event, RevivedEvent):
            return f"{event.target_name} gets back up with {event.hp} HP."
        if isinstance(event, BattleEndedEvent):
            return _OUTCOMES.get(event.outcome, event.outcome)
        return None

    def _damage_line(self, event: DamageEvent) -> str | None:
        """Phrase a damage event, with why the number is what it is."""
        if event.cause == "poison":
            return f"{event.target_name} takes {event.amount} from poison."
        if event.cause == "nightmare":
            # Tawiri's Moepapa (Frankie, 10/31).
            return f"{event.target_name} takes {event.amount} from a nightmare."
        if event.cause == "counter":
            # On the block meter the kick back is told by its number, in step with the bars (Frankie, 11/2).
            if event.stroke:
                return None
            return f"{event.target_name} is kicked back for {event.amount}."
        if event.cause == "cooker":
            return f"{event.attacker_name} lets it all out on {event.target_name} for {event.amount}."
        if event.cause in _TOLD:
            return None
        if event.cause == "spell" and event.stroke:
            # Wili's casts come rapidfire, told by the floating numbers (Frankie, 11/1).
            return None
        if event.cause == "stroke":
            # Strokes are told by the floating numbers, the sounds and
            # the bars; a monster's chain gets one line at the end
            # (Frankie, 10/17).
            return None
        line = f"{event.target_name} takes {event.amount} damage."
        # A guarded hit lands at the guard's rate, which says nothing
        # about weakness, so it gets its own tag.
        if event.guarded:
            line += " Guarded."
        elif event.multiplier > 1.0:
            line += " Weak!"
        elif event.multiplier < 1.0:
            line += " Resisted."
        if event.woke:
            line += " It wakes up."
        return line
