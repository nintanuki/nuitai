"""Bordered JRPG-style dialogue box.

The text box hugs the bottom of its host surface, draws a bordered
panel, and reveals queued lines with a typewriter effect. Callers
``push`` lines (optionally with a speaker tag); pressing confirm
fast-forwards to the end of the current page or advances to the next
page. A line longer than the panel is split into pages of as many rows
as fit; a small triangle in the corner says there is more. A line can
carry the speaker's face: drawn at the left of the panel, as Final
Fantasy VI does, with the name and the words beside it. A fast line
types out at ``UISettings.FAST_TEXT_TIMES`` the speed, and one that ends
on a dash, cut off, goes on to the next line by itself once typed, turning
its own pages if it has more than one; a line can
also be given its own speed (the new game's first, typed slowly as the beach
fades in), and held, so confirm cannot hurry it (the Kame, Frankie 10/26). Config's message speed (``systems/config.py``) scales the usual
speed and a fast line's, but never a line's own speed that is not fast. When the
queue empties, ``is_done`` returns True and the host scene can pop the
box.

The text box does not own any input mapping itself — the host scene
calls ``advance()`` when its confirm button is pressed.
"""

from __future__ import annotations

from collections import deque
from typing import Any, Callable, Optional

import pygame

from settings import ColorSettings, FontSettings, ScreenSettings, UISettings
from systems import config
from ui import text_renderer
from ui.window import draw_window
from utils.graphics import speaker_face


def draw_continue_marker(surface: pygame.Surface, tip: tuple[int, int]) -> None:
    """The small blinking triangle that says the game waits for a press, its point at ``tip``."""
    if (pygame.time.get_ticks() // UISettings.CONTINUE_BLINK_MS) % 2:
        return
    tip_x, tip_y = tip
    pygame.draw.polygon(surface, ColorSettings.WHITE,
                        [(tip_x, tip_y), (tip_x - 4, tip_y - 4), (tip_x + 4, tip_y - 4)])


class TextBox:
    """A bordered dialogue panel with paginated typewriter text."""

    # Whether the field's dialogue boxes sit at the top of the screen (Frankie, 10/25: X moves
    # the box out of the way). One flag for the whole play session, shared by the text box and
    # the yes/no box.
    at_top = False
    # Called with each line as it starts to show, so the Words pages unlock once a word is
    # heard (Frankie, 10/26). The game sets it; None in a box with no game behind it.
    on_line: Optional[Callable[[str], None]] = None

    @classmethod
    def flip(cls) -> None:
        """Move the field's dialogue boxes to the top, or back to the bottom."""
        cls.at_top = not cls.at_top

    @classmethod
    def top_for(cls, host_h: int, height: int) -> int:
        """The y of a field dialogue box ``height`` tall on a screen ``host_h`` tall."""
        return 0 if cls.at_top else host_h - height

    def __init__(
        self,
        width: int = ScreenSettings.WIDTH,
        height: int = UISettings.TEXT_BOX_HEIGHT,
        x: int = 0,
        flippable: bool = False,
        highlight_names: bool = True,
    ) -> None:
        """Construct a text box for the bottom of the screen.

        Args:
            width: Panel width in pixels (defaults to the full screen width).
            height: Panel height in pixels.
            x: The panel's left edge. The battle narrates in the left
                part of its window, so its box starts at 0 and is as
                wide as the command panel.
            flippable: The field's box, which X can move to the top.
            highlight_names: Names in the lines are drawn in the People color (dialogue); off for fights.
        """
        self.flippable = flippable
        self.highlight_names = highlight_names
        self.x = x
        self.width = width
        self._base_height = height
        self._queue: deque[tuple[Optional[str], str, dict[str, dict[str, Any]], Optional[pygame.Surface], bool,
                                 Optional[float], bool]] = deque()

        # The line being shown, wrapped and cut into pages of rows.
        self._current_speaker: Optional[str] = None
        # The speaker's 48 by 48 face beside the words, or None.
        self._portrait: Optional[pygame.Surface] = None
        # Key words in the line and their look, as ``draw_text`` keywords
        # (color, glow); the rest is white (Frankie, 10/18: key words
        # colour-coded in dialogue).
        self._keywords: dict[str, dict[str, Any]] = {}
        # The line types out fast (a story line marked ``(fast)``).
        self._fast = False
        # The line's own letters a second, or None for the usual speed.
        self._speed: Optional[float] = None
        # Confirm cannot hurry the line: it types out at its own speed first.
        self._hold = False
        # B is held (Frankie, 11/9): a held line, which B cannot fill at once, types at the usual speed meanwhile.
        # The host sets it; the first meeting with Gajumaru never does.
        self.hurry = False
        # Seconds a typed page of a cut-off line has been shown.
        self._read_for = 0.0
        self._pages: list[list[str]] = []
        self._page: int = 0
        self._chars_revealed: float = 0.0
        self._total_chars: int = 0

    # ------------------------------------------------------------------
    # GEOMETRY
    # ------------------------------------------------------------------

    @property
    def height(self) -> int:
        """The panel's height: as given, taller only when a speaker's name has to sit above a portrait."""
        if self._current_speaker and self._portrait is not None:
            name = text_renderer.line_height(FontSettings.SIZE_BODY)
            frame = UISettings.PORTRAIT_SIZE + 2 * UISettings.TEXT_BOX_BORDER_THICKNESS
            return max(self._base_height, 2 * UISettings.TEXT_BOX_PADDING + name + frame)
        return self._base_height

    @property
    def rows_per_page(self) -> int:
        """Rows of words a page holds; the speaker's name takes a menu row above them."""
        room = self._base_height - 2 * UISettings.TEXT_BOX_PADDING
        if self._current_speaker:
            room -= text_renderer.line_height(FontSettings.SIZE_BODY)
        return max(1, room // text_renderer.line_height(FontSettings.SIZE_DIALOGUE))

    # ------------------------------------------------------------------
    # QUEUE
    # ------------------------------------------------------------------

    def push(
        self,
        text: str,
        speaker: Optional[str] = None,
        keywords: Optional[dict[str, dict[str, Any]]] = None,
        portrait: Optional[pygame.Surface] = None,
        fast: bool = False,
        speed: Optional[float] = None,
        hold: bool = False,
    ) -> None:
        """Append a line to the queue.

        Args:
            text: The line to display. Wrapping happens lazily when the
                line becomes the current one.
            speaker: Optional speaker label rendered above the line.
            keywords: Words to colour, each with its look as ``draw_text``
                keywords (``color``, ``glow``...), e.g. ``{"Strength":
                ColorSettings.STAT_TEXT_STYLES["strength"]}``. The rest
                of the line is white.
            portrait: The speaker's face, drawn left of the name and the
                words (the story's lines, Frankie 10/23). Left out, it is
                looked up from the speaker (Frankie, 10/25: a character with
                a portrait always shows it); a speaker with none shows none.
            fast: Type it out fast; ending on a dash, it is cut off by
                the next line (Frankie, 10/23: Hina's rant at the wake).
            speed: Letters a second for this line, in place of the usual;
                with ``fast`` (a quick line) Config's message speed scales
                it, without (the opening's slow line) it is kept as it is.
            hold: Confirm does nothing until each page has typed out (the
                Kame's slow lines, Frankie 10/26).
        """
        if portrait is None:
            portrait = speaker_face(speaker)
        self._queue.append((speaker, text, {text_renderer.cased(w, FontSettings.SIZE_DIALOGUE): s for w, s in (keywords or {}).items()}, portrait, fast, speed, hold))
        if not self._pages:
            self._pull_next()

    def clear(self) -> None:
        """Drop any queued and currently-displayed text."""
        self._queue.clear()
        self._pages = []
        self._page = 0
        self._current_speaker = None
        self._portrait = None
        self._keywords = {}
        self._speed = None
        self._hold = False
        self._chars_revealed = 0.0
        self._total_chars = 0

    def is_done(self) -> bool:
        """Return True when nothing is queued and nothing is displayed."""
        return not self._pages and not self._queue

    def is_page_complete(self) -> bool:
        """Return True if the current page has fully revealed its text."""
        return self._chars_revealed >= self._total_chars

    def typed(self) -> float:
        """How much of the current page has typed out, 0 to 1 (1 with nothing showing)."""
        return min(1.0, self._chars_revealed / self._total_chars) if self._total_chars else 1.0

    def has_own_speed(self) -> bool:
        """Return True while the line showing types at a speed of its own."""
        return bool(self._pages) and self._speed is not None

    def has_more(self) -> bool:
        """Return True when another page or line follows the current page."""
        return self._page + 1 < len(self._pages) or bool(self._queue)

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------

    def advance(self) -> None:
        """Advance presentation: fast-forward, next page, or next line."""
        if not self._pages:
            return
        if not self.is_page_complete():
            if not self._hold:
                self._chars_revealed = self._total_chars
            return
        if self._page + 1 < len(self._pages):
            self._page += 1
            self._start_page()
            return
        self._pull_next()

    def skim(self) -> None:
        """Fill the page and turn it, in one go: B held for a second flies through the lines this way
        (Frankie, 11/12, Ocarina of Time style). A held line (the Kame's slow talk) is never skimmed."""
        if not self._pages or self._hold:
            return
        self._chars_revealed = float(self._total_chars)
        self.advance()

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        """Advance the typewriter reveal by ``dt`` seconds.

        Args:
            dt: Frame time in seconds.
        """
        if not self._pages:
            return
        if self._chars_revealed < self._total_chars:
            if self._hold and self.hurry:
                times = config.current.text_times()
                speed = None if times is None else times * UISettings.TYPEWRITER_CHARS_PER_SECOND
            elif self._speed is not None and not self._fast:
                speed = self._speed
            else:
                times = config.current.text_times(own=self._fast)
                speed = None if times is None else times * (
                    self._speed or UISettings.TYPEWRITER_CHARS_PER_SECOND * (UISettings.FAST_TEXT_TIMES if self._fast else 1))
            self._chars_revealed += self._total_chars if speed is None else speed * dt
            if self._chars_revealed > self._total_chars:
                self._chars_revealed = float(self._total_chars)
        elif self._fast and self._queue and self._pages[-1][-1].rstrip().endswith(UISettings.CUT_OFF):
            # Cut off: the next line comes up by itself, and a page before
            # the last turns by itself once there has been time to read it.
            if self._page + 1 == len(self._pages):
                self._pull_next()
            else:
                self._read_for += dt
                if self._read_for >= UISettings.CUT_OFF_PAGE_SECONDS:
                    self.advance()

    def render(self, surface: pygame.Surface) -> None:
        """Draw the panel and the currently-revealed text onto ``surface``."""
        if not self._pages:
            return

        host_h = surface.get_height()
        top = TextBox.top_for(host_h, self.height) if self.flippable else host_h - self.height
        rect = pygame.Rect(self.x, top, self.width, self.height)
        draw_window(surface, rect, see_through=True)

        pad = UISettings.TEXT_BOX_PADDING
        x = rect.left + pad
        y = rect.top + pad
        name_x = rect.left + pad
        name_h = text_renderer.line_height(FontSettings.SIZE_BODY) if self._current_speaker else 0
        if self._portrait is not None:
            # The speaker's name above the face, the face in the room left under it, the words beside it.
            # Framed in the box's own border, just outside the face (Frankie, 11/1).
            size = UISettings.PORTRAIT_SIZE
            room = rect.height - 2 * pad - name_h
            face = pygame.Rect(x, rect.top + pad + name_h + (room - size) // 2, size, size)
            surface.blit(self._portrait, face.topleft)
            edge = max(1, UISettings.TEXT_BOX_BORDER_THICKNESS - 1)  # a pixel thinner than the box's own border
            draw_window(surface, face.inflate(2 * edge, 2 * edge), fill=None, radius=edge)
            x += size + UISettings.PORTRAIT_GAP
        line_height = text_renderer.line_height(FontSettings.SIZE_DIALOGUE)

        if self._current_speaker:
            if self._portrait is not None:
                # Centered over the portrait's frame.
                name_x = face.centerx - text_renderer.text_width(self._current_speaker, FontSettings.SIZE_DIALOGUE) // 2
            # The speaker's name as written, white, in the dialogue's own font (Frankie, 11/25).
            text_renderer.draw_text(
                surface, self._current_speaker, (name_x, y),
                color=ColorSettings.WHITE, size=FontSettings.SIZE_DIALOGUE,
            )
            y += name_h

        # Reveal characters across the page's rows in order.
        revealed = int(self._chars_revealed)
        consumed = 0
        for line in self._pages[self._page]:
            if revealed <= consumed:
                break
            self._draw_row(surface, line, max(0, revealed - consumed), (x, y))
            y += line_height
            consumed += len(line)

        # The corner triangle, blinking, whenever the box waits for a press (Frankie, 11/1):
        # more to read after this page, or the last page, which a press closes.
        if self.is_page_complete() and not self._advances_itself():
            draw_continue_marker(surface, (rect.right - pad, rect.bottom - pad // 2))

    def _advances_itself(self) -> bool:
        """Whether this page turns by itself (a cut-off line), so no press is waited for."""
        return bool(self._fast and self._queue and self._pages[-1][-1].rstrip().endswith(UISettings.CUT_OFF))

    # ------------------------------------------------------------------
    # INTERNALS
    # ------------------------------------------------------------------

    def _pull_next(self) -> None:
        """Take the next queued line, wrap it for the panel, cut it into pages."""
        if not self._queue:
            self.clear()
            return
        speaker, text, self._keywords, self._portrait, self._fast, self._speed, self._hold = self._queue.popleft()
        if TextBox.on_line is not None:
            TextBox.on_line(text)
        body_font = text_renderer.get_font(FontSettings.SIZE_DIALOGUE)
        max_width = self.width - 2 * UISettings.TEXT_BOX_PADDING
        if self._portrait is not None:
            max_width -= UISettings.PORTRAIT_SIZE + UISettings.PORTRAIT_GAP
        wrapped = text_renderer.wrap(text, body_font, max_width)
        self._current_speaker = speaker
        rows = self.rows_per_page
        self._pages = [wrapped[i:i + rows] for i in range(0, len(wrapped), rows)] or [[""]]
        if rows >= 2 and len(self._pages) > 1 and len(self._pages[-1]) == 1 and " " not in self._pages[-1][0].strip():
            # A single word never gets a page to itself ("mud.", "waste."): the row before it comes along.
            self._pages[-1].insert(0, self._pages[-2].pop())
        self._page = 0
        self._start_page()

    def _start_page(self) -> None:
        """Begin revealing the current page from its first letter."""
        self._chars_revealed = 0.0
        self._total_chars = sum(len(line) for line in self._pages[self._page])
        self._read_for = 0.0

    def _draw_row(
        self, surface: pygame.Surface, line: str, shown: int, at: tuple[int, int]
    ) -> None:
        """Draw the first ``shown`` letters of ``line``, its key words in their colours."""
        spans: list[tuple[int, int, dict[str, Any]]] = []
        for word, style in self._keywords.items():
            start = line.find(word)
            while start != -1:
                spans.append((start, start + len(word), style))
                start = line.find(word, start + len(word))
        if self.highlight_names:
            # A name in a dialogue line stands out (Frankie, 11/25), unless a key word already colors it.
            taken = [(b, e) for b, e, _ in spans]
            spans += [(m.start(), m.end(), {"color": ColorSettings.CATEGORY_COLORS["People"]})
                      for m in text_renderer.name_spans().finditer(line)
                      if not any(m.start() < e and b < m.end() for b, e in taken)]
        spans.sort(key=lambda span: span[0])
        # Cut the row into plain and key-word pieces, in order.
        pieces: list[tuple[int, int, dict[str, Any]]] = []
        pos = 0
        for start, end, style in spans:
            if start < pos:
                continue
            pieces += [(pos, start, {}), (start, end, style)]
            pos = end
        pieces.append((pos, len(line), {}))
        x, y = at
        for start, end, look in pieces:
            piece = line[start:min(end, shown)]
            if not piece:
                continue
            text_renderer.draw_text(
                surface, piece, (x, y),
                **{"color": ColorSettings.WHITE, **look}, size=FontSettings.SIZE_DIALOGUE,
            )
            x += text_renderer.text_width(piece, FontSettings.SIZE_DIALOGUE)
