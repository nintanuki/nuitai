"""The window frames, made with PixelLab (Frankie, 11/26).

A menu the cursor moves through takes the ocean frame. Whatever pops up to tell
the player something (dialogue, messages, notices) takes the thin bamboo one,
with a flower cluster in its top-right and bottom-left corners. The pictures are
in ``assets/ui/frames/`` (cut by ``art/ui/frames/make_game_frames.py``).

A frame fits any size without resizing a pixel: each corner is the picture's own
corner, and a longer side repeats the middle of that side. The inside is never
cut from the pictures that way, so it has no seams: ``water_colors`` reads the
ocean's deep blue to near black once and shades any height smoothly with it, in
Config's window color. The ocean frame's lines, the bamboo and the flowers keep
their own colors.
"""

from __future__ import annotations

from pathlib import Path

import pygame

from settings import ColorSettings
from systems import config

_DIR = Path(__file__).resolve().parents[1] / "assets" / "ui" / "frames"
# How deep each frame's edge goes, in pixels.
OCEAN_EDGE = 3  # dark line, white, gray
BAMBOO_EDGE = 5
FLOWER_HANG = 6  # how far a cluster hangs past a small notice's corner
# The rows of the ocean picture's inside that hold its shading, clear of the lines shaded along its edges.
_SHADE_ROWS = (6, 106)

_pictures: dict[str, pygame.Surface] = {}
_drawn: dict[tuple, tuple[pygame.Surface, pygame.Surface]] = {}
_ocean_stops: list[tuple[float, tuple[int, int, int]]] = []


def _picture(name: str) -> pygame.Surface:
    if name not in _pictures:
        _pictures[name] = pygame.image.load(str(_DIR / f"{name}.png"))
    return _pictures[name]


def _spans(source: int, length: int) -> list[tuple[int, int, int]]:
    """(from, to, run) pieces that make ``length`` pixels of a ``source``-pixel side: both ends, the middle repeated."""
    if length <= source:
        first = (length + 1) // 2
        return [(0, 0, first), (source - (length - first), first, length - first)]
    half = source // 2
    # What is repeated is the stretch in the middle, clear of the corners.
    run = source // 2
    start = (source - run) // 2
    spans = [(0, 0, half)]
    at, left = half, length - source
    while left > 0:
        step = min(run, left)
        spans.append((start, at, step))
        at, left = at + step, left - step
    spans.append((half, at, source - half))
    return spans


def _fitted(name: str, size: tuple[int, int]) -> pygame.Surface:
    """The frame picture at ``size``."""
    art = _picture(name)
    out = pygame.Surface(size, pygame.SRCALPHA)
    for from_y, to_y, high in _spans(art.get_height(), size[1]):
        for from_x, to_x, wide in _spans(art.get_width(), size[0]):
            # Onto clear pixels, so this adds them exactly as they are.
            out.blit(art, (to_x, to_y), (from_x, from_y, wide, high), special_flags=pygame.BLEND_RGBA_ADD)
    return out


def _inside(shape: pygame.Surface, depth: int) -> pygame.Mask:
    """The pixels of ``shape`` more than ``depth`` pixels in from its outline."""
    mask = pygame.mask.from_surface(shape, 127)
    width, height = shape.get_size()
    for _ in range(depth):
        less = mask.copy()
        for step in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            moved = pygame.Mask((width, height))
            moved.draw(mask, step)
            less = less.overlap_mask(moved, (0, 0))
        mask = less
    return mask


def _stops() -> list[tuple[float, tuple[int, int, int]]]:
    """PixelLab's ocean, top to bottom, as (share of the height, color): the middle of each of its bands."""
    if not _ocean_stops:
        art = _picture("ocean")
        first, last = _SHADE_ROWS
        rows = [tuple(art.get_at((art.get_width() // 2, y)))[:3] for y in range(first, last + 1)]
        start = 0
        for y in range(1, len(rows) + 1):
            if y == len(rows) or rows[y] != rows[start]:
                _ocean_stops.append(((start + y - 1) / 2 / (len(rows) - 1), rows[start]))
                start = y
        # The first and last bands reach the very top and bottom.
        _ocean_stops.insert(0, (0.0, rows[0]))
        _ocean_stops.append((1.0, rows[-1]))
    return _ocean_stops


def water_colors(height: int) -> list[tuple[int, int, int]]:
    """One color a row for a window ``height`` tall: deep blue to near black, in Config's window color.

    With the default color these are PixelLab's own. Moving a slider adds the change to them, less
    toward the dark bottom, so any color shades down the same way.
    """
    stops = _stops()
    change = [config.to_8bit(now) - config.to_8bit(was)
              for now, was in zip(config.current.window, config.WINDOW_DEFAULT)]
    brightest = sum(stops[0][1])
    colors, index = [], 0
    for y in range(height):
        share = y / max(1, height - 1)
        while index < len(stops) - 2 and share > stops[index + 1][0]:
            index += 1
        (at, above), (to, below) = stops[index], stops[index + 1]
        part = min(1.0, max(0.0, (share - at) / (to - at))) if to > at else 0.0
        blue = [a + (b - a) * part for a, b in zip(above, below)]
        depth = sum(blue) / brightest
        colors.append(tuple(min(255, max(0, round(c + d * depth))) for c, d in zip(blue, change)))
    return colors


def _bamboo_inside(art: pygame.Surface) -> pygame.Mask:
    """What the bamboo leaves open: the middle, and the water PixelLab painted beside and between the stalks."""
    width, height = art.get_size()
    inside = pygame.mask.Mask((width, height))
    for x in range(width):
        for y in range(height):
            red, _, blue, _ = art.get_at((x, y))
            middle = BAMBOO_EDGE <= x < width - BAMBOO_EDGE and BAMBOO_EDGE <= y < height - BAMBOO_EDGE
            if middle or blue > red + 20:
                inside.set_at((x, y))
    return inside


def _recolor(ring: pygame.Surface, color: tuple[int, int, int]) -> None:
    """Turn the ocean frame's white and gray into ``color`` (a lit or unlit box keeps its meaning)."""
    for x in range(ring.get_width()):
        for y in range(ring.get_height()):
            red, green, blue, alpha = ring.get_at((x, y))
            light = (red + green + blue) / 3
            if alpha and light > 100:
                share = min(1.0, light / 230)
                ring.set_at((x, y), (*(round(c * share) for c in color[:3]), alpha))


def window(water: pygame.Surface, style: str, border: tuple[int, int, int] = ColorSettings.WHITE) -> pygame.Surface:
    """A whole window the size of ``water``: the frame, with ``water`` showing inside it.

    Args:
        water: The inside's colors and opacity over the whole box, square-cornered.
        style: "ocean" or "bamboo".
        border: Ocean frame only: a color other than white tints the frame with it.
    """
    size = water.get_size()
    key = (size, style, tuple(border[:3]))
    if key not in _drawn:
        art = _fitted(style, size)
        if style == "bamboo":
            inside = _bamboo_inside(art)
            shape = pygame.mask.Mask(size, fill=True)
        else:
            inside = _inside(art, OCEAN_EDGE)
            shape = pygame.mask.from_surface(art, 127)
        shape.erase(inside, (0, 0))
        ring = shape.to_surface(setsurface=art, unsetcolor=(0, 0, 0, 0))
        if key[2] != tuple(ColorSettings.WHITE[:3]):
            _recolor(ring, key[2])
        # Where the water shows, white on clear, to cut it to the frame's shape.
        _drawn[key] = ring, inside.to_surface(setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0))
    ring, cut = _drawn[key]
    out = water.copy()
    out.blit(cut, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    out.blit(ring, (0, 0))
    return out


def draw_flowers(surface: pygame.Surface, rect: pygame.Rect, corners: tuple[str, ...] = ("top", "bottom")) -> None:
    """Clusters tucked into the box's corners: "top" its top-right, "bottom" mirrored in its bottom-left."""
    cluster = _picture("flowers")
    if "top" in corners:
        surface.blit(cluster, cluster.get_rect(topright=rect.topright))
    if "bottom" in corners:
        surface.blit(pygame.transform.flip(cluster, True, False), cluster.get_rect(bottomleft=rect.bottomleft))


def notice_flowers(
    surface: pygame.Surface, rect: pygame.Rect, words: pygame.Rect, corners: tuple[str, ...] = ("top", "bottom"),
) -> None:
    """The clusters on a small notice, at their own size, hung over its corners and clear of ``words``.

    Args:
        surface: Where to draw.
        rect: The notice's outer edge.
        words: The box its letters fill.
        corners: "top" for the top-right cluster, "bottom" for the bottom-left one.
    """
    cluster = _picture("flowers")
    screen = surface.get_rect()
    if "top" in corners:
        spot = cluster.get_rect(left=max(rect.right - cluster.get_width() + FLOWER_HANG, words.right + 1),
                                top=max(screen.top, rect.top - FLOWER_HANG))
        if spot.right > screen.right:  # a notice the screen's width: up over the words instead of past the edge
            spot.right, spot.bottom = screen.right, words.top - 1
        surface.blit(cluster, spot)
    if "bottom" in corners:
        spot = cluster.get_rect(right=min(rect.left + cluster.get_width() - FLOWER_HANG, words.left - 1),
                                bottom=rect.bottom + FLOWER_HANG)
        if spot.left < screen.left:
            spot.left, spot.top = screen.left, words.bottom + 1
        surface.blit(pygame.transform.flip(cluster, True, False), spot)


def flower_size() -> tuple[int, int]:
    """The flower cluster's width and height."""
    return _picture("flowers").get_size()


# The smallest side the ocean frame's round corners fit; a smaller box keeps a plain line.
SMALLEST = 20
