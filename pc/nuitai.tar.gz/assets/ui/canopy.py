"""The palm-frond canopy that walls in a room (Frankie, 11/13).

The ring of '#' tiles round the edge of a room used to be drawn as palms, which players took for
palms they could chop. They are now a dark wall of fronds, so every palm the player sees can be chopped.
Collision, exits and chopping are untouched: the tiles are still '#', only the picture changed. The game,
the Workshop and ``tools/snes_check.py`` all draw through ``draw_tile``, which asks here.

The art is PixelLab's (``tiles/canopy/palm-fronds.png``, 64 by 64, sixteen 16 pixel tiles, one for each
way four corners can be wall or room). A wall tile takes the one for its four corners (so every end of the
wall, at an exit, a river or a corner, is a rounded one from the sheet). Each is slid 4 pixels toward the
room so the leafy edge ends at the tile's inner edge, and the strip that opens on the wall side is filled
from the sheet's solid canopy tile. The grass the sheet drew under the edge is cut out, so the room's own
grass shows. ``tiles/canopy/README.md`` has the story.
"""

from __future__ import annotations

import os

import pygame

from settings import AssetPaths, GridSettings, OverworldSettings

PUSH = 4  # pixels the edge slides toward the room
SHEET_FILE = os.path.join("canopy", "palm-fronds.png")
# The sheet's grass, in Mini World's greens (the palette PixelLab was given); only grass joined to a
# grass corner is cut out, so grass-coloured gaps inside the canopy stay solid.
GRASS = {(0xB1, 0xD3, 0x54), (0xC3, 0xD6, 0x57), (0xCB, 0xE3, 0x6F)}

# Where each tile sits in the sheet (column, row), by which of its corners (NW, NE, SW, SE) are canopy.
POSITIONS: dict[tuple[bool, bool, bool, bool], tuple[int, int]] = {
    (True, True, False, True): (0, 0), (True, False, True, False): (1, 0),
    (False, True, False, False): (2, 0), (True, True, False, False): (3, 0),
    (False, True, True, False): (0, 1), (True, False, False, False): (1, 1),
    (False, False, False, False): (2, 1), (False, False, False, True): (3, 1),
    (True, False, True, True): (0, 2), (False, False, True, True): (1, 2),
    (False, False, True, False): (2, 2), (False, True, False, True): (3, 2),
    (True, True, True, True): (0, 3), (True, True, True, False): (1, 3),
    (True, False, False, True): (2, 3), (False, True, True, True): (3, 3),
}

_SHEET: pygame.Surface | None | bool = None
_MADE: dict[tuple, pygame.Surface] = {}


def _sheet() -> pygame.Surface | None:
    """The canopy sheet, loaded once, or None when it is missing (the palms are drawn then)."""
    global _SHEET
    if _SHEET is None:
        path = os.path.join(AssetPaths.TILES_DIR, SHEET_FILE)
        _SHEET = False
        if os.path.exists(path):
            _SHEET = pygame.image.load(path)
            if pygame.display.get_surface() is not None:  # tools/snes_check.py draws with no window open
                _SHEET = _SHEET.convert_alpha()
    return _SHEET or None


def is_border(grid, col: int, row: int) -> bool:
    """Whether the wall tile at (col, row) is on the room's edge, where the canopy stands."""
    return (grid[row][col] == OverworldSettings.WALL_CHAR
            and (col in (0, len(grid[row]) - 1) or row in (0, len(grid) - 1)))


def is_canopy(grid, col: int, row: int) -> bool:
    """Whether (col, row) is canopy: the wall on the room's edge, or a tile painted with the canopy brush."""
    return grid[row][col] == OverworldSettings.CANOPY_CHAR or is_border(grid, col, row)


def _raw(key) -> pygame.Surface:
    size = GridSettings.TILE_SIZE
    col, row = POSITIONS[key]
    return _sheet().subsurface(pygame.Rect(col * size, row * size, size, size)).copy()


def _cut_grass(tile: pygame.Surface, key) -> pygame.Surface:
    """``tile`` with the grass joined to a grass corner made see-through."""
    size = GridSettings.TILE_SIZE
    out = tile.copy()
    corners = {(0, 0): key[0], (size - 1, 0): key[1], (0, size - 1): key[2], (size - 1, size - 1): key[3]}
    seen, stack = set(), [at for at, canopy in corners.items() if not canopy]
    while stack:
        x, y = stack.pop()
        if (x, y) in seen or not (0 <= x < size and 0 <= y < size) or tuple(out.get_at((x, y)))[:3] not in GRASS:
            continue
        seen.add((x, y))
        stack += [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]
    for at in seen:
        out.set_at(at, (0, 0, 0, 0))
    return out


def _make(key, dx: int, dy: int) -> pygame.Surface:
    """The finished tile for ``key`` on a wall whose room lies toward (dx, dy): slid, with its open strip filled."""
    size = GridSettings.TILE_SIZE
    tile, solid = _cut_grass(_raw(key), key), _raw((True, True, True, True))
    out = pygame.Surface((size, size), pygame.SRCALPHA)
    for y in range(size):
        for x in range(size):
            opened = (dx > 0 and x < PUSH) or (dx < 0 and x >= size - PUSH) \
                or (dy > 0 and y < PUSH) or (dy < 0 and y >= size - PUSH)
            if opened and tile.get_at((x, y))[3]:
                out.set_at((x, y), solid.get_at((x, y)))
    for y in range(size):
        for x in range(size):
            ox, oy = x - dx * PUSH, y - dy * PUSH
            if 0 <= ox < size and 0 <= oy < size and tile.get_at((ox, oy))[3]:
                out.set_at((x, y), tile.get_at((ox, oy)))
    return out


def tile(grid, col: int, row: int) -> pygame.Surface | None:
    """The canopy picture for the canopy tile at (col, row), or None if the sheet is missing."""
    if _sheet() is None:
        return None
    last_c, last_r = len(grid[0]) - 1, len(grid) - 1

    def wall(c: int, r: int) -> bool:
        # Off the screen counts as canopy, so it runs on to the edge of the picture.
        return not (0 <= c <= last_c and 0 <= r <= last_r) or is_canopy(grid, c, r)

    def corner(i: int, j: int) -> bool:
        return all(wall(i + dc, j + dr) for dc, dr in ((-1, -1), (0, -1), (-1, 0), (0, 0)))

    key = (corner(col, row), corner(col + 1, row), corner(col, row + 1), corner(col + 1, row + 1))
    # Which way the room lies. On the room's edge that is by the edge, not by the corners: a wall's end tile
    # (at an exit or the river) must not be pushed along the wall, or its rounded end gets clipped flat.
    if is_border(grid, col, row):
        dx = 1 if col == 0 else -1 if col == last_c else 0
        dy = 1 if row == 0 else -1 if row == last_r else 0
    else:
        up, down, left, right = wall(col, row - 1), wall(col, row + 1), wall(col - 1, row), wall(col + 1, row)
        dy = 1 if up and not down else -1 if down and not up else 0
        dx = 1 if left and not right else -1 if right and not left else 0
        if up and down and left and right:  # inside the canopy; a missing diagonal is a corner of the room
            gaps = [(ox, oy) for ox, oy in ((-1, -1), (1, -1), (-1, 1), (1, 1)) if not wall(col + ox, row + oy)]
            if len(gaps) == 1:
                dx, dy = gaps[0]
    if not any(key):
        # A painted tile with no 2 by 2 of canopy round any of its corners (a lone tile, a one tile line)
        # has no edge piece to take, so it is drawn as the sheet's solid tile, square, and still blocks.
        key, dx, dy = (True, True, True, True), 0, 0
    made = (key, dx, dy)
    if made not in _MADE:
        _MADE[made] = _make(key, dx, dy)
    return _MADE[made]
