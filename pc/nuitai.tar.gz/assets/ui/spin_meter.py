"""Wili on screen: spin the d-pad round while the time runs out (Frankie, 11/1).

In the window the commands were in, as Paddle's meter is (``ui/paddle_meter.py``):
a Super Nintendo d-pad whose arm lights where the last press was, a ring of
arrows going round it to say which way, "Spin!" beside it, the mana the casts
will leave the caster with (red once it is below zero), and under them a bar
that drains in WILI_SECONDS. The casts are not shown as they are counted; when
the bar is empty the battle casts them all, rapidfire (``Battle.submit_wili``).

A turn is counted from the directions pressed: eight places round the pad (the
four arrows and the corners between them, which a pad's hat or stick gives),
and a run of steps the same way round adds up to eight for one turn. Going the
other way, or jumping across the pad, starts the run over.
"""

from __future__ import annotations

import math

import pygame

from settings import BattleSettings, BattleStageSettings, BlockSettings, FontSettings
from ui import text_renderer
from ui.block_meter import draw_frame, draw_shaded

_PLACES = 8               # The places round the pad: N, NE, E, SE, S, SW, W, NW.
_PAD_ARM = 7              # The d-pad's arm length, in pixels.
_BAR_WIDTH = 96
_BAR_HEIGHT = BlockSettings.HEIGHT
_RING = 17                # The arrows' ring radius.
_PAD = (70, 70, 80)
_PAD_BODY = (96, 98, 112)
_PAD_LIGHT = (150, 154, 172)
_PAD_SHADE = (52, 54, 66)
_PAD_ARROW = (200, 204, 216)
_PAD_EDGE = (20, 20, 28)
_PAD_LIT = (255, 222, 40)
_ARROW = (255, 222, 40)
_ARROW_EDGE = (40, 24, 0)
_LETTER = (255, 255, 255)
_STICK = 0.5              # How far the stick goes before it counts as a direction.
# The hat's (x, y) to a place; y is up.
_HAT = {(0, 1): 0, (1, 1): 1, (1, 0): 2, (1, -1): 3, (0, -1): 4, (-1, -1): 5, (-1, 0): 6, (-1, 1): 7}


class SpinMeter:
    """The clock and the turns counted, for one Wili."""

    def __init__(self, mana: int = 0, ease: float = 1.0) -> None:
        """Start the clock for a Wili; ``mana`` is what the caster has now, ``ease`` from the stats lengthens the time."""
        self.mana = mana
        self.seconds = BattleSettings.WILI_SECONDS * ease
        self.left = float(self.seconds)
        self.rotations = 0
        self._place: int | None = None   # Where the pad was last pressed.
        self._run = 0                    # Steps round the same way so far, signed.
        self._age = 0.0
        self._lit = 0.0                  # Time left showing the last press.
        self._axes = [0.0, 0.0]

    @property
    def done(self) -> bool:
        """True once the time is up."""
        return self.left <= 0

    @property
    def mana_after(self) -> int:
        """What the caster would have if the time ran out now."""
        from systems.battle import Battle
        return self.mana - Battle.wili_debt(self.rotations)

    def press(self, place: int) -> bool:
        """Count the pad pressed at ``place`` (0 up, clockwise by eighths); True when it was a step round."""
        if self.done:
            return False
        last, self._place = self._place, place
        if last is None or place == last:
            return False
        self._lit = 0.12
        step = (place - last) % _PLACES
        if step in (1, 2):
            move = step
        elif step in (_PLACES - 1, _PLACES - 2):
            move = step - _PLACES
        else:
            self._run = 0  # Across the pad: the run starts over.
            return False
        if self._run and (move > 0) != (self._run > 0):
            self._run = 0
        self._run += move
        self._stepped(move)
        if abs(self._run) >= _PLACES:
            self._run -= _PLACES if self._run > 0 else -_PLACES
            if self.rotations < BattleSettings.WILI_MOST:
                self.rotations += 1
        return True

    def _stepped(self, move: int) -> None:
        """A step round the pad was counted, ``move`` eighths (signed); for Cook's stir (``ui/stir_meter.py``)."""

    def handle(self, event: pygame.event.Event) -> bool:
        """Take a pad, stick or arrow-key event; True when it was one of those (and a step round if it counted)."""
        from ui import input_map
        place = None
        if event.type == pygame.KEYDOWN:
            if input_map.is_up(event):
                place = 0
            elif input_map.is_right(event):
                place = 2
            elif input_map.is_down(event):
                place = 4
            elif input_map.is_left(event):
                place = 6
        elif event.type == pygame.JOYHATMOTION:
            place = _HAT.get(tuple(event.value))
        elif event.type == pygame.JOYAXISMOTION and event.axis in (0, 1):
            self._axes[event.axis] = event.value
            x, y = self._axes
            if math.hypot(x, y) >= _STICK:
                place = round(math.degrees(math.atan2(x, -y)) / 45) % _PLACES
        if place is None:
            return False
        self.press(place)
        return True

    def update(self, dt: float) -> None:
        """Run the clock down by ``dt`` seconds."""
        self.left = max(0.0, self.left - dt)
        self._age += dt
        self._lit = max(0.0, self._lit - dt)

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the pad with its ring on the left, "Spin!" and the mana to its right, the bar along the bottom."""
        center = (window.left + 34, window.top + 38)
        self.render_pad(surface, center)
        size = FontSettings.SIZE_BODY
        middle = (center[0] + _RING + window.right) // 2
        text = "Spin!"
        text_renderer.draw_text(surface, text, (middle - text_renderer.text_width(text, size) // 2, window.top + 28),
                                color=_LETTER, size=size)
        after = self.mana_after
        text = f"Mana {after}"
        color = BattleStageSettings.COLOR_DEBT if after < 0 else BattleStageSettings.COLOR_MANA
        text_renderer.draw_text(surface, text, (middle - text_renderer.text_width(text, size) // 2, window.top + 42),
                                color=color, size=size)
        self.render_bar(surface, pygame.Rect(window.left, window.bottom - 22, window.width, 12))

    def render_pad(self, surface: pygame.Surface, center: tuple[int, int]) -> None:
        """Draw the d-pad at ``center`` with a ring of arrows going round it."""
        draw_pad(surface, center, self._place if self._lit > 0 else None, self._age)

    def render_bar(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the time left as a draining bar centered in ``window``, in the block meter's frame."""
        frame = pygame.Rect(0, 0, _BAR_WIDTH + 4, _BAR_HEIGHT + 4)
        frame.center = window.center
        well = draw_frame(surface, frame)
        draw_shaded(surface, well, well.left, round(_BAR_WIDTH * self.left / self.seconds))


PAD_REACH = _RING + 4  # how far the arrows reach from the pad's center


def draw_pad(surface: pygame.Surface, center: tuple[int, int], lit: int | None, age: float) -> None:
    """A d-pad at ``center``, the arm at place ``lit`` (0 up, 2 right, 4 down, 6 left) in yellow,
    with four arrowheads chasing round it clockwise, ``age`` seconds along. Wili's and the reel's."""
    cx, cy = center
    arm = _PAD_ARM + 3     # the cross reaches 10 pixels from the middle, each arm 7 wide
    bars = (pygame.Rect(cx - arm, cy - 3, 2 * arm + 1, 7), pygame.Rect(cx - 3, cy - arm, 7, 2 * arm + 1))
    # Pixel art: a dark outline, a lit top and left edge, a shaded bottom and right, a body between.
    for bar in bars:
        pygame.draw.rect(surface, _PAD_EDGE, bar.inflate(2, 2))
    for bar in bars:
        pygame.draw.rect(surface, _PAD_BODY, bar)
    for bar in bars:
        pygame.draw.line(surface, _PAD_LIGHT, bar.topleft, (bar.right - 1, bar.top))
        pygame.draw.line(surface, _PAD_LIGHT, bar.topleft, (bar.left, bar.bottom - 1))
    for bar in bars:
        pygame.draw.line(surface, _PAD_SHADE, (bar.left, bar.bottom - 1), (bar.right - 1, bar.bottom - 1))
        pygame.draw.line(surface, _PAD_SHADE, (bar.right - 1, bar.top), (bar.right - 1, bar.bottom - 1))
    # The middle: a round dimple where the thumb rests, drawn over the seams of the two bars.
    pygame.draw.rect(surface, _PAD_BODY, pygame.Rect(cx - 2, cy - 2, 5, 5))
    pygame.draw.rect(surface, _PAD_SHADE, pygame.Rect(cx - 1, cy - 1, 3, 3))
    surface.set_at((cx - 1, cy - 1), _PAD_EDGE)
    # An arrow on each arm, three rows of pixels pointing out. The lit arm turns yellow with a dark arrow.
    def pixel(dx: int, dy: int, out: int, across: int, color: tuple) -> None:
        surface.set_at((cx + dx * out - dy * across, cy + dy * out + dx * across), color)

    for dx, dy, place in ((0, -1, 0), (1, 0, 2), (0, 1, 4), (-1, 0, 6)):
        on = lit == place
        if on:
            for out in range(4, arm + 1):
                for across in range(-2, 3):
                    pixel(dx, dy, out, across, _PAD_LIT)
        for row, width in enumerate((1, 3, 5)):           # row 0 is the tip
            for across in range(-(width // 2), width // 2 + 1):
                pixel(dx, dy, 9 - row, across, _ARROW_EDGE if on else _PAD_ARROW)
    # Four arrowheads chasing round, clockwise.
    for i in range(4):
        angle = age * 4.5 + i * math.pi / 2
        x, y = cx + _RING * math.sin(angle), cy - _RING * math.cos(angle)
        tip = (x + 4 * math.cos(angle), y + 4 * math.sin(angle))
        back = ((x - 3 * math.cos(angle)) - 3 * math.sin(angle), (y - 3 * math.sin(angle)) + 3 * math.cos(angle))
        back2 = ((x - 3 * math.cos(angle)) + 3 * math.sin(angle), (y - 3 * math.sin(angle)) - 3 * math.cos(angle))
        pygame.draw.polygon(surface, _ARROW, [tip, back, back2])
        pygame.draw.polygon(surface, _ARROW_EDGE, [tip, back, back2], 1)
