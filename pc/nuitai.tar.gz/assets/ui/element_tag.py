"""A move's element tag: 7 by 7, cut on the diagonal (Frankie, 10/23).

It sits in the one-letter gap before a move's name on the ELEMENT grid,
like the browser game's move buttons and Chrono Cross's element slots,
with a pixel of space between it and the word. A dual move's tag is its
two colors meeting on the diagonal, the first element top left, with no
line between them; a single move's is its color top left and gray bottom
right. The cartridge cuts the same tags from ``tag_pixels``
(snes/tools/make_art.py).
"""

from __future__ import annotations

from typing import Any, Iterable

import pygame

from settings import ColorSettings

SIZE = 7      # The tag; it sits in an 8 by 8 square, the last column and row clear.
CELL = 8

# Each pixel's part: "a" the first element, "b" the second (or gray), "" clear.
# The diagonal itself goes with the first.
_PARTS: tuple[tuple[str, ...], ...] = tuple(
    tuple("" if x >= SIZE or y >= SIZE else "a" if x + y < SIZE else "b" for x in range(CELL))
    for y in range(CELL)
)


def tag_pixels() -> tuple[tuple[str, ...], ...]:
    """The 8 by 8 square's parts, row by row."""
    return _PARTS


def tag_elements(move: dict[str, Any], member_elements: Iterable[str]) -> tuple[str, str | None]:
    """The tag's two elements, as the browser picks a move button's: ``elements`` if the
    move names them, else a special uses both of the member's, its own first; else its
    one element and None (gray)."""
    named = move.get("elements")
    if not named and move.get("tier") == "special":
        mine = list(member_elements)
        named = [move["element"]] + [e for e in mine if e != move["element"]] if move["element"] in mine else mine
    named = list(dict.fromkeys(named or [move["element"]]))
    return named[0], (named[1] if len(named) > 1 else None)


def tag_color(element: str | None) -> tuple[int, int, int]:
    """An element's color on a tag; gray for none."""
    return ColorSettings.GRAY if element is None else ColorSettings.TAG_COLORS[element]


_CACHE: dict[tuple, pygame.Surface] = {}


def tag_surface(first: str, second: str | None) -> pygame.Surface:
    """The tag for ``first`` and ``second`` (None for a single move), in its 8 by 8 square."""
    key = (first, second)
    if key not in _CACHE:
        colors = {"a": tag_color(first), "b": tag_color(second)}
        surface = pygame.Surface((CELL, CELL), pygame.SRCALPHA)
        for y, row in enumerate(_PARTS):
            for x, part in enumerate(row):
                if part:
                    surface.set_at((x, y), colors[part])
        _CACHE[key] = surface
    return _CACHE[key]


_NAME_CACHE: dict[tuple, pygame.Surface] = {}
_NAME_MARGIN = 3      # room round the letters for the halo


def element_name_surface(text: str, first: str, second: str, size: int) -> pygame.Surface:
    """A two-element move's name, smoothly blended left to right from ``first``'s color to ``second``'s
    (Frankie, 11/13), each drawn in its own element style so the outline stays as it is.

    Cached; the SNES will do its own stepped version later (``game/answers.md``).
    """
    key = (text, first, second, size)
    if key not in _NAME_CACHE:
        from ui import text_renderer  # local: text_renderer is heavier than this module's callers need

        styles = ColorSettings.ELEMENT_TEXT_STYLES
        width = text_renderer.text_width(text, size) + 2 * _NAME_MARGIN
        height = size + 2 * _NAME_MARGIN + 2
        layers = []
        for element in (first, second):
            layer = pygame.Surface((width, height), pygame.SRCALPHA)
            text_renderer.draw_text(layer, text, (_NAME_MARGIN, _NAME_MARGIN), size=size,
                                    **styles.get(element, {}))
            layers.append(layer)
        mask = pygame.Surface((width, height), pygame.SRCALPHA)
        for column in range(width):
            mask.fill((255, 255, 255, int(255 * column / max(1, width - 1))), (column, 0, 1, height))
        layers[1].blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        layers[0].blit(layers[1], (0, 0))
        _NAME_CACHE[key] = layers[0]
    return _NAME_CACHE[key]


def draw_element_name(surface: pygame.Surface, text: str, position: tuple[int, int],
                      elements: tuple[str, str | None], size: int) -> None:
    """Draw a move's name in its element's style; a two-element move's as a gradient, first to second."""
    from ui import text_renderer

    first, second = elements
    if second is None or second == first:
        text_renderer.draw_text(surface, text, position, size=size, **ColorSettings.ELEMENT_TEXT_STYLES.get(first, {}))
        return
    surface.blit(element_name_surface(text, first, second, size),
                 (position[0] - _NAME_MARGIN, position[1] - _NAME_MARGIN))
