"""The cloth hung in an island hale's doorway (Frankie, 11/26).

A room's doorway is the gap in its bottom wall (``core.overworld_cells.door_gap``). The cloth there hangs closed
until someone stands in the gap or on the tile before it, then it is drawn tied back (that it waits for someone is
Claude's reading). It is drawn on the floor of the gap, under whoever walks there. The pictures are two tiles,
closed then open (``tools/make_hale_interior.py``).
"""
from __future__ import annotations

import os

import pygame

from settings import AssetPaths, GridSettings, InteriorSettings, OverworldSettings

_SHEETS: dict = {}


def gap(grid) -> int | None:
    """The column of the doorway in an inside room's bottom wall, or None (outside, or no door)."""
    bottom = grid[-1]
    if OverworldSettings.INSIDE_WALL_CHAR not in bottom:
        return None
    return next((c for c, ch in enumerate(bottom) if ch in OverworldSettings.WALKABLE_CHARS), None)


def draw(surface: pygame.Surface, grid, room: str, standing, x0: int = 0, y0: int = 0) -> None:
    """Draw ``room``'s doorway cloth, open if any of ``standing`` (tiles) is at the door."""
    col = gap(grid)
    if col is None:
        return
    row = len(grid) - 1
    dye = InteriorSettings.CURTAINS.get(room, InteriorSettings.CURTAIN)
    if dye not in _SHEETS:
        _SHEETS[dye] = pygame.image.load(os.path.join(AssetPaths.TILES_DIR, "interior", f"curtain_{dye}.png"))
    size = GridSettings.TILE_SIZE
    open_ = any(tile in standing for tile in ((col, row), (col, row - 1)))
    surface.blit(_SHEETS[dye], (x0 + col * size, y0 + row * size), pygame.Rect(size * open_, 0, size, size))
