"""A one pixel outline on whoever walks behind a tree crown (Frankie, 11/24 night).

Kailo gets a white outline (the palette's foam) on the part of him a crown covers, so he is never lost behind a tree;
a monster gets a soft red one, but only when Kailo could really see it (a wall, a tree trunk or a corner between
them hides it, crown or not). Full strength, every frame, so it follows the walk.

How it works, and why it needs no knowledge of the walkers' pictures: the scene draws walkers and crowns in one
sorted pass. For each walker that is to be outlined, ``Outliner.draw_walker`` copies a patch of the screen, lets the
walker draw, and the pixels that changed are its silhouette (whatever pose it is in: a step, a punch, a swim). A copy
taken right after is the picture with nothing in front of it yet. After the pass, any pixel of that patch that is not
the same any more was covered by something drawn later. The outline is the ring of pixels touching the silhouette,
drawn only where that ring was covered. Each walker is two small copies and a few mask operations on a patch the size
of the sprite, so nothing needs caching per frame image.
"""
import pygame


MARGIN = (24, 40, 24, 16)   # left, above, right, below a walker's tiles: room for a 32 pixel pose, a hop and a tall hat


def clear_sight(blocks, eye: tuple[int, int], target: tuple[int, int], ignore: frozenset = frozenset()) -> bool:
    """Whether the straight line of tiles from ``eye`` to ``target`` has nothing in it that ``blocks(col, row)``.

    The two end tiles do not count, nor do ``ignore``d ones (the rest of a big monster's own tiles). The same
    walk a monster does to see Kailo (``FieldMonster._clear_line``), from his side."""
    steps = max(abs(target[0] - eye[0]), abs(target[1] - eye[1]))
    between = {(round(eye[0] + (target[0] - eye[0]) * i / steps), round(eye[1] + (target[1] - eye[1]) * i / steps))
               for i in range(1, steps)}
    return not any(blocks(*tile) for tile in between - ignore)


def monster_seen(world, kailo: tuple[int, int], monster) -> bool:
    """Whether Kailo, on ``kailo``, has a clear line to ``monster`` (its nearest tile if it is big)."""
    tiles = frozenset(monster.tiles())
    near = min(tiles, key=lambda t: abs(t[0] - kailo[0]) + abs(t[1] - kailo[1]))
    return clear_sight(world.blocks_sight, kailo, near, tiles)


def _changed(before: pygame.Surface, after: pygame.Surface) -> pygame.Mask:
    """The pixels that are not the same in the two pictures."""
    same = pygame.mask.from_threshold(after, (0, 0, 0), (1, 1, 1, 255), othersurface=before)
    same.invert()
    return same


def ring_of(body: pygame.Mask) -> pygame.Mask:
    """The pixels touching ``body`` on a side, and not in it: the one pixel outline."""
    ring = pygame.Mask(body.get_size())
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        ring.draw(body, (dx, dy))
    ring.erase(body, (0, 0))
    return ring


class Outliner:
    """Collects the walkers drawn in one pass and, at the end, draws the outline of each covered part."""

    def __init__(self, surface: pygame.Surface) -> None:
        self.surface = surface
        self._walkers: list[tuple[pygame.Rect, pygame.Mask, pygame.Surface, tuple[int, int, int]]] = []

    def draw_walker(self, draw, tile: tuple[int, int], color: tuple[int, int, int] | None,
                    size: tuple[int, int] = (16, 16)) -> None:
        """Run ``draw`` (a walker's own drawing), and if ``color`` is set, remember its silhouette to outline.

        ``tile`` is where its tiles are, in screen pixels (the top left), ``size`` how big they are, to pick the patch to watch."""
        if color is None:
            draw()
            return
        left, above, right, below = MARGIN
        patch = pygame.Rect(tile[0] - left, tile[1] - above, size[0] + left + right,
                            size[1] + above + below).clip(self.surface.get_rect())
        if patch.w <= 0 or patch.h <= 0:
            draw()
            return
        before = self.surface.subsurface(patch).copy()
        draw()
        after = self.surface.subsurface(patch).copy()
        self._walkers.append((patch, _changed(before, after), after, color))

    def finish(self) -> None:
        """Draw the outlines: on each walker, the ring pixels that something drawn later now covers, minus the
        pixels of any walker drawn later still (who stands in front, and keeps their own picture)."""
        for index, (patch, body, after, color) in enumerate(self._walkers):
            if not body.count():
                continue
            covered = _changed(after, self.surface.subsurface(patch))
            hidden = ring_of(body).overlap_mask(covered, (0, 0))
            for other_patch, other_body, _, _ in self._walkers[index + 1:]:
                hidden.erase(other_body, (other_patch.x - patch.x, other_patch.y - patch.y))
            if hidden.count():
                self.surface.blit(hidden.to_surface(setcolor=color + (255,), unsetcolor=(0, 0, 0, 0)), patch.topleft)
        self._walkers.clear()
