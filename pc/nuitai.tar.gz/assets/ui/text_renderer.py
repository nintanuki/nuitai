"""Centralised text rendering.

One place in the codebase loads fonts, wraps text, and puts names in
capitals. Text is mixed case, and in menus a name (a character's, or
anyone who speaks in the game's words) is drawn in capitals, as Final
Fantasy VI did (Frankie, 10/27): gameplay code writes "Kailo", the menu
shows KAILO. In dialogue and story text names stay as written, "Kailo",
since capitals there read as shouting (Frankie, 10/27): text drawn in the
dialogue font, and anything drawn with ``spoken=True`` (a speaker's name
over a text box, Kaigara's lines). Dialogue is drawn at ``FontSettings.SIZE_DIALOGUE``, which is its
own font, proportional, on rows ``DIALOGUE_LINE_HEIGHT`` apart, with
``DIALOGUE_LETTER_GAP`` pixels after every letter, as the Super Nintendo's
variable-width fonts built a gap into each letter, so no two letters touch.

Text is placed by the top of its capital letters, not by the font's
own box: Pixeled carries blank space above its letters, and on a 256 by
224 screen that space would throw every layout off. ``draw_text`` takes
that space off, so a position is where the letters start, and rows are
``FontSettings.LINE_HEIGHT`` apart.

The cache keys on (font path, point size) so callers can ask for the
same logical font-size repeatedly without paying the load cost.
"""

from __future__ import annotations

import contextlib
import functools
import glob
import json
import math
import os
import re
import time
import unicodedata
from typing import Callable

import pygame

from settings import ColorSettings, FontSettings, UISettings


_FONT_CACHE: dict[tuple[str, int], pygame.font.Font] = {}
_DIALOGUE_FONT: dict[tuple[str, int], pygame.font.Font] = {}
_INK_TOP_CACHE: dict[int, int] = {}


def get_font(size: int = FontSettings.SIZE_BODY) -> pygame.font.Font:
    """Return a cached pygame font at ``size`` points.

    Args:
        size: Point size; should come from ``FontSettings.SIZE_*``.
            ``SIZE_DIALOGUE`` is the dialogue font at its own size.

    Returns:
        The cached ``pygame.font.Font`` for that size.
    """
    if size == FontSettings.SIZE_DIALOGUE:
        # Its own copy, even when it is the menu's font file: the dialogue font is told apart by
        # which object it is (``_spaced``), and dialogue is never mixed or cased.
        key = (FontSettings.DIALOGUE_FONT, FontSettings.DIALOGUE_POINTS)
        cached = _DIALOGUE_FONT.get(key)
        if cached is None:
            cached = _DIALOGUE_FONT[key] = pygame.font.Font(*key)
        return cached
    font = _load(FontSettings.FONT, FontSettings.FONT_POINTS * size // FontSettings.SIZE_BODY)
    _MENU_SIZE[id(font)] = size
    return font


def _load(path: str, points: int) -> pygame.font.Font:
    """The font file at ``points``, loaded once."""
    cached = _FONT_CACHE.get((path, points))
    if cached is None:
        cached = _FONT_CACHE[(path, points)] = pygame.font.Font(path, points)
        _KEY_OF[id(cached)] = (path, points)
    return cached


_KEY_OF: dict[int, tuple[str, int]] = {}


# Menu text mixes three fonts, picked word by word (Frankie, 11/23): the main font for most
# words, the old Press Start 2P for words in capitals (names, GROCER, HP) and the time, and a
# number font for plain numbers (money, HP, prices). ``classic=True`` (or ``with old_font()``) draws a whole text in the old
# font: the title's options and monster names. Every old-font letter is as wide as before and
# the others are narrower, so no line can grow longer than it was.
_MENU_SIZE: dict[int, int] = {}
_CLASSIC = False
_NUMBER = re.compile(r"[0-9][0-9/,.%+\-]*")


@contextlib.contextmanager
def old_font():
    """Inside this, menu text is drawn and measured in the old font only."""
    global _CLASSIC
    before, _CLASSIC = _CLASSIC, True
    try:
        yield
    finally:
        _CLASSIC = before


def _takes_classic(draw: Callable) -> Callable:
    """Give ``draw`` a ``classic`` keyword: True draws the whole text in the old font."""
    @functools.wraps(draw)
    def wrapped(*args, classic: bool = False, **kwargs):
        if not classic:
            return draw(*args, **kwargs)
        with old_font():
            return draw(*args, **kwargs)
    return wrapped


def _face(font: pygame.font.Font, word: str) -> pygame.font.Font:
    """The font one word of menu text is drawn in; ``font`` is the main menu font."""
    size = _MENU_SIZE.get(id(font))
    if size is None:
        return font
    letters = [c for c in word if c.isalpha()]
    # In capitals (a lone capital too: Pua'a Hihiu A), or a clock ("7:00", or "--:--" before the clock runs).
    if (_CLASSIC or (letters and all(c.isupper() for c in letters))
            or (":" in word and all(c.isdigit() or c in ":-" for c in word))):
        return _load(FontSettings.CAPS_FONT, size)
    if _NUMBER.fullmatch(word):
        return _load(FontSettings.NUMBER_FONT, FontSettings.NUMBER_POINTS * size // FontSettings.SIZE_BODY)
    return font


@functools.cache
def _caps(path: str, points: int) -> tuple[int, int]:
    """Where a capital H starts in this font's box, and how tall it is."""
    rect = _load(path, points).render("H", False, ColorSettings.WHITE).get_bounding_rect()
    return rect.top, rect.height


def _menu_box(size: int) -> tuple[int, int]:
    """The menu line's capital box: its top in the line's surface, and its height.

    The height is the old font's capitals (7 pixels at size 8), so every line stays where it was
    on screen; each font's capitals are centered on that box, a taller one reaching a pixel above
    and below (Frankie, 11/23: text and icons line up as before). The top leaves room for that.
    """
    return 2 * size // FontSettings.SIZE_BODY, 7 * size // FontSettings.SIZE_BODY


@functools.cache
def _monster_pattern() -> re.Pattern[str]:
    """Every monster's name, whole, drawn in the old font wherever it shows (Frankie, 11/23)."""
    from core.shared import by_id
    names = {m["name"] for m in by_id("monsters").values() if m.get("name")}
    return re.compile(r"(?<!\w)(" + "|".join(re.escape(n) for n in sorted(names, key=len, reverse=True)) + r")(?!\w)")


def _pieces(font: pygame.font.Font, text: str) -> list[tuple[pygame.font.Font, str]]:
    """``text`` cut into words and spaces, each with the font it is drawn in; spaces in the main font.

    A monster's name stays one piece, in the old font.
    """
    old = _load(FontSettings.CAPS_FONT, _MENU_SIZE[id(font)])
    if _CLASSIC or text.strip() in FontSettings.OLD_FONT_WORDS:
        return [(old, text)]
    # A sentence is all in the main font, names and numbers too (Frankie, 11/23).
    if len(text.split()) >= 4 or re.search(r"[.!?](\s|$)", text):
        return [(font, text)]
    out = []
    for i, part in enumerate(_monster_pattern().split(text)):
        if i % 2:
            out.append((old, part))
            continue
        # A word's last stop or comma is cut off it and drawn in the main font: "HP." keeps
        # HP in the old font, but the old font's full-width stop would leave a gap.
        out.extend((font if piece.isspace() or not piece.strip(".,;!?") else _face(font, piece), piece)
                   for piece in re.split(r"( +|[.,;!?]+(?= |$))", part) if piece)
    return out


def _spaced(font: pygame.font.Font) -> bool:
    """Whether ``font`` is the dialogue font, drawn with a gap after every letter."""
    return font is _DIALOGUE_FONT.get((FontSettings.DIALOGUE_FONT, FontSettings.DIALOGUE_POINTS))


# Letters a font lacks are built from ones it has (Frankie, 10/27: Galmuri has no
# macrons, neither font the ʻokina): the ʻokina drawn as an opening quote, an
# accented letter as its plain letter with each mark laid over it, the mark
# taken from the font's own spacing accent ("ā" is "a" under "¯").
_STAND_INS = {"ʻ": ("‘", "'")}
_MARKS = {"̄": "¯", "́": "´", "̀": "`", "̂": "^",
          "̃": "~", "̈": "¨", "̛": "'"}
_HORN = "̛"        # Vietnamese ư, ơ: a hook at the letter's top right, not above it.
_HAS_CACHE: dict[tuple[int, str], bool] = {}


def has_glyph(font: pygame.font.Font, letter: str) -> bool:
    """Whether ``font`` draws ``letter`` itself, rather than its box for a missing letter."""
    key = (id(font), letter)
    cached = _HAS_CACHE.get(key)
    if cached is None:
        def look(text: str) -> tuple:
            drawn = font.render(text, False, ColorSettings.WHITE)
            surf = pygame.Surface(drawn.get_size(), pygame.SRCALPHA)
            surf.blit(drawn, (0, 0))
            return surf.get_size(), pygame.image.tobytes(surf, "RGBA")
        cached = letter.isspace() or look(letter) != look("\U0010fffd")
        _HAS_CACHE[key] = cached
    return cached


def _built(font: pygame.font.Font, letter: str) -> tuple[str, list[str]] | None:
    """How a letter the font lacks is built: the letter it has, and the spacing marks over it.

    None if it cannot be built, so the font's missing box shows.
    """
    for stand_in in _STAND_INS.get(letter, ()):
        if has_glyph(font, stand_in):
            return stand_in, []
    parts = unicodedata.normalize("NFD", letter)
    # The longest start the font has whole: ố is ô under an acute.
    for cut in range(len(parts) - 1, 0, -1):
        base = unicodedata.normalize("NFC", parts[:cut])
        if len(base) == 1 and has_glyph(font, base):
            marks = [_MARKS.get(mark) for mark in parts[cut:]]
            if all(mark is not None and has_glyph(font, mark) for mark in marks):
                return base, [mark if mark != "'" or part != _HORN else _HORN
                              for mark, part in zip(marks, parts[cut:])]
            return None
    return None


def drawable(font: pygame.font.Font, letter: str) -> bool:
    """Whether ``letter`` draws in ``font``, itself or built from letters it has."""
    return letter == THIN_SPACE or has_glyph(font, letter) or _built(font, letter) is not None


THIN_SPACE = "\u2009"   # A gap narrower than a letter, FontSettings.THIN_SPACE pixels (Frankie, 11/18).


def _letter(font: pygame.font.Font, letter: str, color: tuple[int, int, int]) -> pygame.Surface:
    """One letter as drawn: the font's own, or built over its plain letter (``_built``)."""
    if letter == THIN_SPACE:
        return pygame.Surface((FontSettings.THIN_SPACE, font.get_height()), pygame.SRCALPHA)
    built = None if has_glyph(font, letter) else _built(font, letter)
    if built is None:
        return font.render(letter, False, color)
    base, marks = built
    plain = font.render(base, False, color)
    ink = plain.get_bounding_rect()
    # Where each mark goes, before the letter's surface is made wide enough for them.
    placed = []
    above = base != unicodedata.normalize("NFD", base)[0]   # ô already carries a mark
    for mark in marks:
        shape = font.render("'" if mark == _HORN else mark, False, color)
        area = shape.get_bounding_rect()
        cut = 0
        if mark == _HORN:
            # Up and right off the letter's top right.
            x, y = ink.right - 1, max(0, ink.top - area.height + 1)
        elif above:
            # A second mark goes beside the first, as Vietnamese sets the acute of ố.
            x, y = ink.right, ink.top
        else:
            # A pixel above the letter, or as high as the row allows: in Galmuri, whose
            # capitals reach its top, Ā's bar takes the place of the A's top rows.
            x, y = ink.centerx - area.width // 2, max(0, ink.top - 1 - area.height)
            cut = max(0, y + area.height + 1 - ink.top)
        placed.append((shape, area, x, y, cut))
        ink = ink.union(pygame.Rect(x, y, area.width, area.height))
        above = True
    width = max([plain.get_width()] + [x + area.width + 1 for _, area, x, _, _ in placed])
    surf = pygame.Surface((width, plain.get_height()), pygame.SRCALPHA)
    surf.blit(plain, (0, 0))
    top = plain.get_bounding_rect().top
    for shape, area, x, y, cut in placed:
        if cut:
            pygame.draw.rect(surf, (0, 0, 0, 0), (x, top, area.width, cut))
        surf.blit(shape, (x, y), area)
    return surf


# A name in a sentence, and a word with a Lore page of its own, stand out (Frankie, 11/24): drawn in
# ``ColorSettings.NAME_COLOR`` (or smeared one pixel wider, when ``FontSettings.NAME_STYLE`` is "bold";
# Galmuri9 has no bold of its own). ``mark`` wraps each such word in these two zero-width stand-ins.
# The open mark says the kind of word: chr(0xE000 + n), n the place of its Lore category in
# ``ColorSettings.CATEGORY_COLORS`` (People first; names in sentences are People).
OPEN, CLOSE = chr(0xE000), chr(0xE010)
_OPEN_MARK = re.compile("[-]")


def unmarked(text: str) -> str:
    """``text`` without the highlight marks."""
    return _OPEN_MARK.sub("", text).replace(CLOSE, "")


def _kind_color(kind: int) -> tuple[int, int, int]:
    """The highlight color of word kind ``kind``."""
    return tuple(ColorSettings.CATEGORY_COLORS.values())[kind]


def _split_marks(text: str) -> tuple[str, list[int | None]]:
    """``text`` without its marks, and for each of its letters whether it was marked."""
    plain, mask, hot = [], [], None
    for letter in text:
        if 0xE000 <= ord(letter) < 0xE010:
            hot = ord(letter) - 0xE000
        elif letter == CLOSE:
            hot = None
        else:
            plain.append(letter)
            mask.append(hot)
    return "".join(plain), mask


def _runs(font: pygame.font.Font, text: str) -> list[tuple[pygame.font.Font, str, int | None]]:
    """Menu ``text`` as (font, words, marked) runs: ``_pieces`` of its plain letters, cut again at each mark."""
    plain, mask = _split_marks(text)
    runs, at = [], 0
    for face, piece in _pieces(font, plain):
        start = 0
        for i in range(1, len(piece) + 1):
            if i == len(piece) or mask[at + i] != mask[at + start]:
                runs.append((face, piece[start:i], mask[at + start]))
                start = i
        at += len(piece)
    return runs


def _bold() -> bool:
    return FontSettings.NAME_STYLE == "bold"


def _measure(font: pygame.font.Font, text: str) -> int:
    """The drawn width of ``text`` in ``font``, the dialogue font's letter gaps counted."""
    if id(font) in _MENU_SIZE:
        if not _OPEN_MARK.search(text):
            return sum(_measure_one(face, piece) for face, piece in _pieces(font, text))
        return sum(_measure_one(face, piece) + (1 if hot is not None and _bold() else 0) for face, piece, hot in _runs(font, text))
    return _measure_one(font, text)


def _measure_one(font: pygame.font.Font, text: str) -> int:
    """The drawn width of ``text`` in this one font."""
    if not _spaced(font) and all(has_glyph(font, letter) for letter in text):
        return font.size(text)[0]
    gap = FontSettings.DIALOGUE_LETTER_GAP if _spaced(font) else 0
    return sum(_letter(font, letter, ColorSettings.WHITE).get_width() + gap for letter in text)


def _render(font: pygame.font.Font, text: str, color: tuple[int, int, int]) -> pygame.Surface:
    """Render ``text`` in ``font``; menu text word by word in its fonts, each centered on one line."""
    if id(font) not in _MENU_SIZE:
        return _render_one(font, text, color)
    top, tall = _menu_box(_MENU_SIZE[id(font)])
    pieces = []
    for face, piece, hot in _runs(font, text):
        face_top, face_tall = _caps(*_KEY_OF[id(face)])
        y = top + (tall - face_tall) // 2 - face_top
        if hot is not None and _bold():
            shape = _render_one(face, piece, _kind_color(hot))
            wide = pygame.Surface((shape.get_width() + 1, shape.get_height()), pygame.SRCALPHA)
            wide.blit(shape, (0, 0))
            wide.blit(shape, (1, 0))
            pieces.append((wide, y))
        else:
            pieces.append((_render_one(face, piece, color if hot is None else _kind_color(hot)), y))
    height = max(shape.get_height() + y for shape, y in pieces) if pieces else font.get_height()
    surf = pygame.Surface((max(1, sum(shape.get_width() for shape, _ in pieces)), max(1, height)), pygame.SRCALPHA)
    x = 0
    for shape, y in pieces:
        surf.blit(shape, (x, y))
        x += shape.get_width()
    return surf


def _render_one(font: pygame.font.Font, text: str, color: tuple[int, int, int]) -> pygame.Surface:
    """Render ``text`` in this one font; the dialogue font one letter at a time, a gap after each.

    A letter the font lacks is built (``_letter``), so its line is drawn letter by letter too.
    """
    if not _spaced(font) and all(has_glyph(font, letter) for letter in text):
        return font.render(text, False, color)
    gap = FontSettings.DIALOGUE_LETTER_GAP if _spaced(font) else 0
    surf = pygame.Surface((max(1, _measure_one(font, text)), font.get_height()), pygame.SRCALPHA)
    x = 0
    for letter in text:
        shape = _letter(font, letter, color)
        surf.blit(shape, (x, 0))
        x += shape.get_width() + gap
    return surf


def ink_top(size: int = FontSettings.SIZE_BODY) -> int:
    """Return the blank rows above the capital letters at ``size``.

    Subtract it from a blit position to put the top of the letters
    where the position says.
    """
    cached = _INK_TOP_CACHE.get(size)
    if cached is None and size != FontSettings.SIZE_DIALOGUE:
        cached = _INK_TOP_CACHE[size] = _menu_box(size)[0]
    if cached is None:
        cached = (
            get_font(size).render("H", False, ColorSettings.WHITE)
            .get_bounding_rect().top
        )
        _INK_TOP_CACHE[size] = cached
    return cached


def line_height(size: int = FontSettings.SIZE_BODY) -> int:
    """Return the row pitch for text at ``size``: one text row, or two for a heading."""
    if size == FontSettings.SIZE_DIALOGUE:
        return FontSettings.DIALOGUE_LINE_HEIGHT
    rows = max(1, round(size / FontSettings.SIZE_BODY))
    return FontSettings.LINE_HEIGHT * rows


@functools.cache
def _names_pattern() -> re.Pattern[str]:
    """The names drawn in capitals, as one whole-word pattern.

    Every character's short name, and every speaker in the rooms and the
    story scripts but those in ``FontSettings.NOT_NAMES`` (Villager...).
    """
    from core.shared import by_id, short_name
    from core import story

    names = {short_name(member_id) for member_id in by_id("characters")}

    def walk(node) -> None:
        if isinstance(node, dict):
            for key, value in node.items():
                if key == "speaker" and isinstance(value, str):
                    names.add(value)
                elif key == "talk" and isinstance(value, list):
                    names.update(pair[0] for pair in value if isinstance(pair, list) and len(pair) == 2)
                walk(value)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    game_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for path in glob.glob(os.path.join(game_dir, "data", "cells", "*.json")):
        with open(path, encoding="utf-8") as f:
            walk(json.load(f))
    for scene in [*story.SCRIPTS, *story.PYGAME_SCRIPTS]:
        names.update(step["say"] for step in story.load(scene) if "say" in step)
    names = {name for name in names if isinstance(name, str) and name.isalpha()}
    names -= set(FontSettings.NOT_NAMES)
    # Not before an 'okina and a letter: Pua is a person, Pua'a Hihiu is a boar.
    return re.compile(r"\b(" + "|".join(sorted(names, key=len, reverse=True)) + r")\b(?!'[a-rt-zA-Z])")


def _sentence(text: str) -> bool:
    """Whether menu text is a sentence, or a phrase with a possessive ("Miki's brother"): names in it
    are said as written and stand out, instead of being a label's name in capitals (Frankie, 11/24)."""
    plain = unmarked(text)
    return len(plain.split()) >= 4 or re.search(r"[.!?](\s|$)", plain) is not None or "'s" in plain


@functools.cache
def name_spans() -> re.Pattern[str]:
    """A name in a sentence, an 's after it included."""
    return re.compile(_names_pattern().pattern + r"(?:'s)?(?!\w)")


def mark(text: str, keywords: re.Pattern[str] | None = None, kinds: dict[str, int] | None = None) -> str:
    """``text`` with every name in it (a person), and every match of ``keywords``, wrapped in marks.

    ``kinds`` gives each keyword's kind, by its lowercase name without an 's; a keyword it lacks is a
    person's. Where two matches overlap, the longer one wins.
    """
    plain = unmarked(text)
    found = [(m.start(), m.end(), 0) for m in name_spans().finditer(plain)]
    if keywords is not None:
        for m in keywords.finditer(plain):
            word = m[0].lower().removesuffix("'s")
            found.append((m.start(), m.end(), (kinds or {}).get(word, 0)))
    spans: list[tuple[int, int, int]] = []
    for b, e, kind in sorted(found, key=lambda f: (f[0] - f[1], f[0])):
        if not any(b < se and sb < e for sb, se, _ in spans):
            spans.append((b, e, kind))
    if not spans:
        return plain
    out, at = [], 0
    for b, e, kind in sorted(spans):
        out.append(plain[at:b])
        out.append(re.sub(r"[^ ]+", lambda m: chr(0xE000 + kind) + m[0] + CLOSE, plain[b:e]))
        at = e
    out.append(plain[at:])
    return "".join(out)


def cased(text: str, size: int = FontSettings.SIZE_BODY, spoken: bool = False) -> str:
    """Return ``text`` as drawn: a name alone in capitals; in a sentence as written and marked to stand out.

    Dialogue (the dialogue font, or ``spoken``) keeps its names as written; the text box
    marks them itself.
    """
    if spoken or size == FontSettings.SIZE_DIALOGUE:
        return text
    if _OPEN_MARK.search(text):
        return text
    if _sentence(text):
        return mark(text)
    return _names_pattern().sub(lambda match: match[0].upper(), text)


@_takes_classic
def text_width(text: str, size: int = FontSettings.SIZE_BODY, spoken: bool = False) -> int:
    """Return the drawn width of ``text`` at ``size``, cased as ``cased`` draws it."""
    return _measure(get_font(size), cased(text, size, spoken))


def wrap(text: str, font: pygame.font.Font, max_width: int, spoken: bool = False) -> list[str]:
    """Greedy word-wrap ``text`` so each line fits within ``max_width`` pixels.

    Args:
        text: The text to wrap. May contain ``\n`` for hard breaks.
        font: The font to measure with.
        max_width: The maximum allowed pixel width per line.
        spoken: Dialogue drawn in a menu font: names stay as written.

    Returns:
        A list of lines.
    """
    out: list[str] = []
    for paragraph in (text if spoken or _spaced(font) else cased(text)).split("\n"):
        if not paragraph:
            out.append("")
            continue
        words = paragraph.split(" ")
        current = ""
        for word in words:
            candidate = word if not current else f"{current} {word}"
            # Menu text is measured with its names in capitals even when it is kept as written:
            # a caller may wrap it as written and draw it cased, and a name in capitals is wider
            # in the old font, so measuring the wider way never lets a line run out of its window.
            measured = cased(candidate) if id(font) in _MENU_SIZE else candidate
            if _measure(font, measured) <= max_width:
                current = candidate
            else:
                if current:
                    out.append(current)
                current = word
        if current:
            out.append(current)
    return out


def _render_glow(
    text: str,
    font: pygame.font.Font,
    fill: tuple[int, int, int],
    glow: tuple[int, int, int],
    radius: int,
    alpha: int,
) -> tuple[pygame.Surface, int]:
    """Render ``text`` in ``fill`` with a soft ``glow`` halo behind it.

    The halo is drawn by blitting the glow-colored text at every offset
    inside a filled circle of ``radius`` pixels with a single per-blit
    ``alpha`` so the offsets accumulate into a soft cloud rather than a
    hard edge. Returned alongside the surface is the pad amount, which
    callers use to offset the blit so the glyph's natural baseline still
    lands at the requested ``position`` (glow bleeds *outward* from the
    text and shouldn't shift layout).
    """
    body = _render(font, text, fill)
    halo = _render(font, text, glow)
    halo.set_alpha(alpha)
    w, h = body.get_size()
    pad = radius + 1
    surf = pygame.Surface((w + 2 * pad, h + 2 * pad), pygame.SRCALPHA)
    r_sq = radius * radius
    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            if dx == 0 and dy == 0:
                continue
            # Drop the box corners so the halo reads round, not square.
            if dx * dx + dy * dy > r_sq:
                continue
            surf.blit(halo, (dx + pad, dy + pad))
    surf.blit(body, (pad, pad))
    return surf, pad


@_takes_classic
def render_line(
    text: str,
    color: tuple[int, int, int] = ColorSettings.WHITE,
    size: int = FontSettings.SIZE_BODY,
    glow: tuple[int, int, int] | None = None,
    glow_radius: int = 1,
    glow_alpha: int = 110,
    spoken: bool = False,
) -> pygame.Surface:
    """Render one line of text to a fresh surface, its names in capitals.

    The surface is the font's own box, blank space above the letters
    included; blit it ``ink_top(size)`` higher than where the letters
    should start.

    Args:
        text: The text to render.
        color: The text color (the sharp body of the glyph).
        size: Point size; should come from ``FontSettings.SIZE_*``.
        glow: Optional halo color. When set, the returned surface is
            ``2 * (glow_radius + 1)`` pixels wider and taller than the
            raw glyph box; callers blitting it should account for the
            pad (or use ``draw_text`` which handles the offset itself).
        glow_radius: Pixel radius of the halo.
        glow_alpha: Per-blit alpha of the halo passes. Lower values
            make the halo softer.
        spoken: Dialogue drawn in a menu font: names stay as written.

    Returns:
        A new surface containing the rendered glyphs.
    """
    font = get_font(size)
    text = cased(text, size, spoken)
    if glow is None:
        return _render(font, text, color)
    surf, _pad = _render_glow(
        text, font, color, glow, glow_radius, glow_alpha,
    )
    return surf


@_takes_classic
def draw_text(
    surface: pygame.Surface,
    text: str,
    position: tuple[int, int],
    color: tuple[int, int, int] = ColorSettings.WHITE,
    size: int = FontSettings.SIZE_BODY,
    max_width: int | None = None,
    line_spacing: int = 0,
    glow: tuple[int, int, int] | None = None,
    glow_radius: int = 1,
    glow_alpha: int = 110,
    spoken: bool = False,
) -> int:
    """Draw ``text`` onto ``surface``, wrapping if ``max_width`` is given.

    Args:
        surface: The surface to draw onto.
        text: The text to render.
        position: Top-left in pixels of the first line's capital
            letters. The glow halo, if any, bleeds outside this box
            symmetrically and does not shift the letters.
        color: Text color (sharp body).
        size: Point size.
        max_width: If set, word-wrap to this many pixels per line.
        line_spacing: Extra pixels between rows, on top of ``line_height``.
        glow: Optional halo color. Used by shadow-element labels so the
            lore-black body remains readable against the black command
            panel and any other dark background.
        glow_radius: Pixel radius of the halo.
        glow_alpha: Per-blit alpha of the halo passes.
        spoken: Dialogue drawn in a menu font, such as a speaker's name
            over a text box: names stay as written (Frankie, 10/27).

    Returns:
        The total height in pixels that was drawn (so callers can stack
        further content below it). Halo bleed is NOT counted toward this
        height -- vertical layout treats glow as a free overhang.
    """
    font = get_font(size)
    text = cased(text, size, spoken)
    lines = wrap(text, font, max_width, spoken=True) if max_width is not None else text.split("\n")
    x, y = position
    y -= ink_top(size)
    pitch = line_height(size) + line_spacing
    drawn = 0
    for line in lines:
        if glow is None:
            rendered = _render(font, line, color)
            surface.blit(rendered, (x, y + drawn))
        else:
            rendered, pad = _render_glow(
                line, font, color, glow, glow_radius, glow_alpha,
            )
            # Offset by -pad so the glyph body lines up with where the
            # plain-text render would have placed it.
            surface.blit(rendered, (x - pad, y + drawn - pad))
        drawn += pitch
    return drawn


@_takes_classic
def draw_text_at(surface: pygame.Surface, words: str, x: int, y: int,
                 color: tuple[int, int, int] = ColorSettings.WHITE, right: bool = False,
                 size: int = FontSettings.SIZE_BODY) -> None:
    """Words at ``x``, or ending at ``x`` when ``right``."""
    if right:
        x -= text_width(words, size)
    draw_text(surface, words, (x, y), color=color, size=size)


def pointer_color() -> tuple[int, int, int]:
    """Return the target arrow's colour this frame: bright and dim yellow in turn, never off.

    Menu cursors stay solid yellow; only the arrow over a fighter pulses (Frankie, 10/26).
    """
    lit = int(time.monotonic() * UISettings.MENU_CURSOR_BLINK_HZ * 2) % 2 == 0
    return ColorSettings.YELLOW if lit else UISettings.MENU_CURSOR_DIM


# The menu cursor: a white bone fishhook with its cord wrap, after the carved
# pendants, hung on a line from the top of its window as if fishing for the
# option (Frankie, 11/2; it was a yellow triangle). "#" bone, "s" its shade,
# "c" and "d" the cord; a dark outline is drawn round it.
_HOOK = (
    ".##.........",
    "cccd........",
    "cdcc........",
    "ccdc........",
    ".###........",
    ".###.....#..",
    ".###....##..",
    ".###...###..",
    ".###....##..",
    ".###....##..",
    ".####..###..",
    "..########..",
    "..s######s..",
    "....ssss....",
)
_HOOK_COLORS = {"#": (244, 236, 214), "s": (200, 184, 150), "c": (196, 152, 92), "d": (132, 96, 56)}
_HOOK_INK = (20, 16, 28)
_HOOK_LINE = (224, 216, 196)
_HOOK_CORD_X = 3      # The line ties on here, from the sprite's left edge.
_HOOK_GAP = 4         # The hook's right edge sits this far right of the old tip.
_hooks: dict[tuple[int, int, int], pygame.Surface] = {}
# The windows drawn this frame, so the cursor's line knows where to stop.
_windows: list[tuple[int, pygame.Rect]] = []
# The same windows in their root surface's own coordinates, for over_window: a box drawn on a
# subsurface (the battle's talk box) still sits over a window drawn on the whole screen.
_stack: list[tuple[int, pygame.Rect]] = []


# The hook moves: it reels up and down to a new row, its line's top slides
# along the window and the hook swings after it, and it bobs while it waits
# (Frankie, 11/2). One hook per window, remembered from frame to frame.
ANIMATE = True        # tools/screens.py turns it off, for still pictures.
_frame = 0
_swings: dict[tuple, list[float]] = {}   # key -> [hook x, hook y, x speed, line x, frame, time]


def new_frame() -> None:
    """Forget last frame's windows (core/scene.py calls this before drawing)."""
    global _frame
    _windows.clear()
    _stack.clear()
    _frame += 1


def note_window(surface: pygame.Surface, rect: pygame.Rect) -> None:
    """Remember a window just drawn (ui/window.py calls this)."""
    _windows.append((id(surface), pygame.Rect(rect)))
    del _windows[:-64]
    root, absolute = _root(surface, rect)
    _stack.append((id(root), absolute))
    del _stack[:-64]


def _root(surface: pygame.Surface, rect: pygame.Rect) -> tuple[pygame.Surface, pygame.Rect]:
    """Return the surface ``surface`` is cut from, and ``rect`` in that surface's coordinates."""
    absolute = pygame.Rect(rect)
    while surface.get_parent() is not None:
        absolute.move_ip(surface.get_offset())
        surface = surface.get_parent()
    return surface, absolute


def over_window(surface: pygame.Surface, rect: pygame.Rect) -> bool:
    """True if ``rect`` overlaps a window already drawn this frame on ``surface`` (Frankie, 11/19).

    A window drawn over another window is solid, so the two windows' words never show through
    each other; ui/window.py asks this before it fills a see-through window.
    """
    root, absolute = _root(surface, rect)
    return any(owner == id(root) and absolute.colliderect(other) for owner, other in _stack)


def _window_top(surface: pygame.Surface, point: tuple[int, int]) -> int | None:
    """Return where the line above ``point`` meets a window edge, if it is in a window.

    The nearest edge above it: the top of a window holding it, or the
    bottom of one sitting over it (a header drawn on a full-screen window).
    """
    window = _window_of(surface, point)
    if window is None:
        return None
    x, y = point
    thick = UISettings.TEXT_BOX_BORDER_THICKNESS
    mine = [rect for owner, rect in _windows if owner == id(surface)]
    edges = [rect.top + thick for rect in mine if rect.collidepoint(point)]
    edges += [rect.bottom for rect in mine if rect.left <= x < rect.right and rect.bottom <= y]
    return max(edges)


def _window_of(surface: pygame.Surface, point: tuple[int, int]) -> pygame.Rect | None:
    """Return the smallest window drawn this frame on ``surface`` holding ``point``."""
    holding = [rect for owner, rect in _windows if owner == id(surface) and rect.collidepoint(point)]
    return min(holding, key=lambda rect: rect.width * rect.height, default=None)


def _swing(key: tuple, x: int, y: int) -> tuple[int, int, int]:
    """Move the hook toward ``(x, y)``; return where the hook and its line's top are now."""
    now = time.monotonic()
    state = _swings.get(key)
    if not ANIMATE or state is None or state[4] < _frame - 1:
        # Just appeared: no sliding in from wherever it was last.
        state = [float(x), float(y), 0.0, float(x), _frame, now]
        _swings[key] = state
        return x, y, x
    dt = min(now - state[5], 0.05)
    hook_x, hook_y, speed, line_x = state[0], state[1], state[2], state[3]
    hook_y += (y - hook_y) * min(1.0, dt * UISettings.HOOK_REEL_SPEED)
    line_x += (x - line_x) * min(1.0, dt * UISettings.HOOK_SLIDE_SPEED)
    # A spring pulls the hook under its line, a little loose, so it swings past and settles.
    speed += ((line_x - hook_x) * UISettings.HOOK_SPRING - speed * UISettings.HOOK_DAMPING) * dt
    hook_x += speed * dt
    if abs(hook_y - y) < 0.3:
        hook_y = float(y)
    _swings[key] = [hook_x, hook_y, speed, line_x, _frame, now]
    bob = round(math.sin(now * math.tau * UISettings.HOOK_BOB_HZ)) if hook_y == y else 0
    return round(hook_x), round(hook_y) + bob, round(line_x)


def _tint(color: tuple[int, int, int], share: float) -> tuple[int, int, int]:
    return tuple(round(c * share) for c in color)


def _hook(color: tuple[int, int, int]) -> pygame.Surface:
    """Return the fishhook: bone for the live yellow, else greyed or dimmed toward ``color``."""
    key = tuple(color)
    if key not in _hooks:
        live = key == tuple(ColorSettings.YELLOW)
        on = {(x, y): c for y, row in enumerate(_HOOK) for x, c in enumerate(row) if c != "."}
        sprite = pygame.Surface((len(_HOOK[0]) + 2, len(_HOOK) + 2), pygame.SRCALPHA)
        for x, y in on:
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    if (x + dx, y + dy) not in on:
                        sprite.set_at((x + dx + 1, y + dy + 1), _HOOK_INK)
        for (x, y), c in on.items():
            if live:
                shade = _HOOK_COLORS[c]
            else:
                shade = _tint(key, {"#": 1.0, "s": 0.8, "c": 0.7, "d": 0.5}[c])
            sprite.set_at((x + 1, y + 1), shade)
        _hooks[key] = sprite
    return _hooks[key]


def _draw_line(surface: pygame.Surface, color: tuple[int, int, int], a: tuple[int, int], b: tuple[int, int]) -> None:
    """Draw the hook's line, one pixel wide and see-through so what is behind it shows (Frankie, 11/19)."""
    left, top = min(a[0], b[0]), min(a[1], b[1])
    width, height = abs(a[0] - b[0]) + 1, abs(a[1] - b[1]) + 1
    layer = pygame.Surface((width, height), pygame.SRCALPHA)
    pygame.draw.line(layer, (*color[:3], UISettings.HOOK_LINE_ALPHA), (a[0] - left, a[1] - top), (b[0] - left, b[1] - top))
    surface.blit(layer, (left, top))


def draw_arrow(
    surface: pygame.Surface,
    tip: tuple[int, int],
    color: tuple[int, int, int] = ColorSettings.YELLOW,
    size: int = 4,
) -> None:
    """Draw the yellow triangle pointing right, its tip at ``tip``: the title's cursor.

    The title keeps the arrow the menus had before the fishhook (Frankie, 11/2).
    """
    x, y = tip
    pygame.draw.polygon(
        surface, color, [(x, y), (x - size, y - size), (x - size, y + size)]
    )


def draw_pointer(
    surface: pygame.Surface,
    tip: tuple[int, int],
    color: tuple[int, int, int] = ColorSettings.YELLOW,
    size: int = 4,
    hang_from: Callable[[int], int] | None = None,
    from_screen_top: bool = False,
) -> pygame.Rect:
    """Draw the menu cursor, the fishhook on its line, for the row whose middle is ``tip``'s.

    ``tip`` is where the old triangle's point went, just left of the
    words. The hook's bottom sits on the words' baseline and its cord
    rises above them; the line runs up to the top of the window it is
    in, if any. ``size`` is left from the triangle and not used.

    There is one live hook (Frankie, 11/2): it floats from where it was
    last drawn to here, across windows and from one screen to the next,
    so opening a page carries the hook down to its list and backing out
    carries it up again.

    ``from_screen_top`` hangs the line from the top of the screen, over whatever windows lie between, instead
    of from the top of the window the hook is in: the Items screen's one free hook (Frankie, 11/21). Returns the
    hook's rect as drawn, where it is now, so something can ride on it.
    """
    sprite = _hook(color)
    rect = sprite.get_rect(right=tip[0] + _HOOK_GAP, bottom=tip[1] + FontSettings.SIZE_BODY // 2)
    window = _window_of(surface, tip)
    key = (id(surface), tuple(window) if window is not None else tuple(color))
    if tuple(color) == tuple(ColorSettings.YELLOW):
        live = ("live", id(surface))
        if live not in _swings or _swings[live][4] != _frame:
            key = live
    settled = rect.topleft
    rect.left, rect.top, line_x = _swing(key, rect.left, rect.top)
    # On its way, the line hangs from the window the hook is passing through.
    flying = abs(rect.left - settled[0]) > 1 or abs(rect.top - settled[1]) > 1
    if from_screen_top:
        top = 0
    else:
        top = _window_top(surface, (line_x + _HOOK_CORD_X, rect.centery) if flying else tip)
    if top is not None and top < rect.top:
        line = _HOOK_LINE if tuple(color) == tuple(ColorSettings.YELLOW) else _tint(color, 0.9)
        _draw_line(surface, line, (line_x + _HOOK_CORD_X, top), (rect.left + _HOOK_CORD_X, rect.top + 1))
    if hang_from is not None:
        # On the field (Frankie, 11/19): a thin line straight down to the hook's eye, from the top of the
        # screen or the bottom of the name box over it; ``hang_from(x)`` gives the y it starts at.
        x = rect.left + _HOOK_CORD_X
        _draw_line(surface, _HOOK_LINE, (x, hang_from(x)), (x, rect.top + 1))
    surface.blit(sprite, rect)
    return rect
