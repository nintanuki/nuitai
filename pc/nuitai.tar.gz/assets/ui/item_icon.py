"""An item's icon: one per kind of item, Final Fantasy VI's (Frankie, 10/24).

Each is 7 by 7 in an 8 by 8 letter space, the last column and row clear,
and sits in the letter space right before the item's name, as a move's
ELEMENT tag does (ui/element_tag.py). The pixels and three shades of each
kind are in ``game/shared/item-icons.json``, drawn once and kept as drawn.
A lontar shows its move's own ELEMENT tag; a weapon its type's icon. An
item with no kind yet has no icon (``item_kind`` says None). Key items
show the key and materials the log (Frankie, 10/28). An item drawn on its
own, by its id, shows that instead of its kind's: the noni, the 'awa, the
field tools (Frankie, 10/28). The cartridge cuts the
same icons (snes/tools/make_art.py).
"""

from __future__ import annotations

import json
import unicodedata
import os
from typing import Any

import pygame

from core.shared import SHARED, SHARED_DIR, by_id
from settings import ColorSettings, ItemSettings
from ui.element_tag import CELL, tag_elements, tag_surface

with open(os.path.join(SHARED_DIR, "item-icons.json"), encoding="utf-8") as _f:
    ICONS: dict[str, Any] = json.load(_f)

# The plant medicine (Frankie, 10/24): what heals or cures and was never cooked.
MEDICINE: tuple = ("noni", "awa", "kukui", "olena")
# A cooked dish that goes back in the pot is an ingredient, not food (ramen, Frankie 11/2).
FOOD: tuple = tuple(d for d in (*(dish["id"] for dish in SHARED["cooking"]["dishes"]), *ItemSettings.SALT_DISHES,
                                *ItemSettings.POT_DISHES, *ItemSettings.CURE_DISHES) if d not in ItemSettings.INGREDIENTS)
SPECIAL: tuple = ("seer_shell", "life_totem", "smoke_bomb")  # the totem is spiritual, not medicine (Frankie, 11/2)


def weapon_kind(weapon_type: str) -> str:
    """A weapon type's icon in the json, by the type's plural name: "Bo Staffs" is bo_staffs."""
    return by_id("weapon_types")[weapon_type]["name"].lower().replace(" ", "_")


def relic_kind(relic: dict[str, Any]) -> str:
    """A relic's icon in the json, by its type: "Kūpe'e" is relic_kupee."""
    plain = unicodedata.normalize("NFD", relic["type"]).encode("ascii", "ignore").decode()
    return "relic_" + "".join(ch for ch in plain.lower() if ch.isalpha())


def item_kind(item_id: str) -> str | None:
    """Which icon ``item_id`` shows: a kind in the json, "element" for a lontar, or None."""
    if item_id in ItemSettings.SHELLS:
        return "element"
    if item_id in ItemSettings.INGREDIENTS or item_id == ItemSettings.WATER:
        return "ingredient"
    if item_id in FOOD:
        return "food"
    if item_id in MEDICINE:
        return "medicine"
    if item_id in ItemSettings.SEEDS or item_id in ItemSettings.CROP_SEEDS:
        return "seed"
    if item_id in SPECIAL or item_id == "battle_bag":   # the shop row for a bigger battle bag (Frankie, 11/12)
        return "special"
    if item_id in ItemSettings.MATERIALS:
        return "material"
    if item_id in ItemSettings.KEY_ITEMS:
        return "key"
    weapon = by_id("weapons").get(item_id)
    if weapon:
        return weapon_kind(weapon["type"])
    relic = by_id("relics").get(item_id)
    return relic_kind(relic) if relic else None


def _hex(color: str) -> tuple[int, int, int]:
    return tuple(int(color[i:i + 2], 16) for i in (1, 3, 5))


_CACHE: dict[str, pygame.Surface] = {}


def element_shades(element: str) -> list[tuple[int, int, int]]:
    """An element's dark, middle and light shade, from its color in the game."""
    mid = ColorSettings.ELEMENT_COLORS[element]
    return [tuple(c // 2 for c in mid), mid, tuple((c + 255) // 2 for c in mid)]


def kind_surface(kind: str, element: str | None = None) -> pygame.Surface:
    """The icon of one kind in the json, in its 8 by 8 square, in its element's
    colors when ``element`` is given (an elemental item, Frankie 10/24)."""
    key = f"{kind}/{element}"
    if key not in _CACHE:
        icon = ICONS["icons"][kind]
        shades = element_shades(element) if element else [_hex(c) for c in ICONS["palettes"][icon["palette"]]]
        surface = pygame.Surface((CELL, CELL), pygame.SRCALPHA)
        for y, row in enumerate(icon["pixels"]):
            for x, pixel in enumerate(row):
                if pixel != ".":
                    surface.set_at((x, y), shades[int(pixel) - 1])
        _CACHE[key] = surface
    return _CACHE[key]


def item_icon(item_id: str) -> pygame.Surface | None:
    """The icon before ``item_id``'s name, or None for an item with no kind yet."""
    kind = item_kind(item_id)
    if kind is None:
        return None
    if kind == "element":
        member_id, move_id = ItemSettings.SHELLS[item_id]
        elements = by_id("characters")[member_id]["elements"]
        return tag_surface(*tag_elements(by_id("moves")[move_id], elements))
    if item_id in ICONS["icons"]:
        return kind_surface(item_id)
    relic = by_id("relics").get(item_id)
    return kind_surface(kind, relic["element"] if relic else None)


def weapon_icon(weapon: dict[str, Any]) -> pygame.Surface:
    """The icon before a weapon's name: its type's."""
    return kind_surface(weapon_kind(weapon["type"]))


SEASON_SIZE = 9
_SEASON_CACHE: dict[int, pygame.Surface] = {}


def season_icon(index: int) -> pygame.Surface:
    """The icon beside the date, for season ``index`` (0 Mohala to 3 Ho'oilo): 9 by 9, made as the others are
    from ``seasons`` in the json (Frankie, 11/13)."""
    if index not in _SEASON_CACHE:
        icon = ICONS["seasons"][index]
        shades = [_hex(c) for c in icon["palette"]]
        surface = pygame.Surface((SEASON_SIZE, SEASON_SIZE), pygame.SRCALPHA)
        for y, row in enumerate(icon["pixels"]):
            for x, pixel in enumerate(row):
                if pixel != ".":
                    surface.set_at((x, y), shades[int(pixel) - 1])
        _SEASON_CACHE[index] = surface
    return _SEASON_CACHE[index]
