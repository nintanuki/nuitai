"""One slot of the small slot grid: the wordless bar the Status page and a bestiary page both draw.

A bar 10 by 5 pixels with a pale border: gray when open, one element's color when a move sits in
it, or two halves for a move of two elements (Frankie, 11/1; 11/15 for the bestiary).
"""

from __future__ import annotations

import pygame

CELL_W, CELL_H = 10, 5
PITCH_X, PITCH_Y = 12, 7
OPEN_COLOR = (120, 124, 132)
BORDER_COLOR = (200, 208, 230)


def draw_cell(surface: pygame.Surface, pos: tuple[int, int],
              colors: tuple[tuple[int, int, int], ...] = ()) -> None:
    """Draw one bar at ``pos``: open with no ``colors``, whole in one, split in two."""
    x, y = pos
    if not colors:
        pygame.draw.rect(surface, OPEN_COLOR, (x, y, CELL_W, CELL_H))
    elif len(colors) == 1:
        pygame.draw.rect(surface, colors[0], (x, y, CELL_W, CELL_H))
    else:
        half = CELL_W // 2
        pygame.draw.rect(surface, colors[0], (x, y, half, CELL_H))
        pygame.draw.rect(surface, colors[1], (x + half, y, half, CELL_H))
    pygame.draw.rect(surface, BORDER_COLOR, (x, y, CELL_W, CELL_H), 1)
