"""Field notices: short lines that never stop play, shown in the same window at the top
center as a new room's name (Frankie, 11/12: the first try, lines stacked in the top left
corner, did not fit the game).

"Found 2 Taro" and "Nothing but dirt." go here instead of the text box
(Frankie, 11/12): the player keeps walking and digging while they show.
Post with ``post_notice(text)``; ``post_found(name, count)`` posts a find and adds to
the one still showing for the same thing ("Found 2 Taro", then "Found 3 Taro").
One line is up at a time; the rest wait their turn. Each stays ``SECONDS``, as long
as a room's name. They take no input and no scene owns them:
the field calls ``update(dt)`` and ``render(surface)`` each frame.

SNES limits: 8x8 letters, 32 to a line, so a line is cut to ``MAX_CHARS``.
The state is module level so any code (the Lore page notice too) can post
without a handle. Separate from ``ui/notice_bar.py``, the battle's one line bar.
"""

from __future__ import annotations

from collections import deque

import pygame

from settings import ColorSettings, FontSettings, PlaceSettings, UISettings
from ui import text_renderer
from ui.window import draw_window

MAX_CHARS = 32
MAX_SHOWN = 1
SECONDS = 2.0


class _Notice:
    def __init__(self, text: str, key: str | None, count: int, sound: str | None = None) -> None:
        self.text = text
        self.key = key
        self.count = count
        self.left = SECONDS
        self.sound = sound


_showing: list[_Notice] = []
_waiting: deque[_Notice] = deque()


def clear() -> None:
    """Drop every notice (a new game or a test)."""
    _showing.clear()
    _waiting.clear()


def active() -> list[str]:
    """The lines showing now, oldest first (for tests)."""
    return [n.text for n in _showing]


def pending() -> list[str]:
    """The lines waiting for room, oldest first (for tests)."""
    return [n.text for n in _waiting]


def post_notice(text: str, sound: str | None = None) -> None:
    """Post a line; it shows at once if there is room, else waits its turn. The same line
    already up just stays longer, so five empty digs do not stack five "Nothing but dirt."."""
    text = text[:MAX_CHARS]
    for notice in (*_showing, *_waiting):
        if notice.key is None and notice.text == text:
            notice.left = max(notice.left, SECONDS)
            return
    _add(_Notice(text, None, 0, sound))


def found_text(name: str, count: int = 1, always_count: bool = False) -> str:
    """"Found Taro", or "Found 2 Taro" (always with a count when ``always_count``, as pule)."""
    return f"Found {count} {name}" if count != 1 or always_count else f"Found {name}"


def post_found(name: str, count: int = 1, always_count: bool = False) -> None:
    """Post a find. A notice for the same thing still up or waiting just counts higher."""
    key = "found:" + name
    for notice in (*_showing, *_waiting):
        if notice.key == key:
            notice.count += count
            notice.text = found_text(name, notice.count, always_count)[:MAX_CHARS]
            notice.left = max(notice.left, SECONDS)
            return
    _add(_Notice(found_text(name, count, always_count)[:MAX_CHARS], key, count))


def _add(notice: _Notice) -> None:
    if len(_showing) < MAX_SHOWN:
        _showing.append(notice)
    else:
        _waiting.append(notice)


def update(dt: float, audio=None) -> None:
    """Count the showing line down, drop it when spent, bring on the next (playing its sound)."""
    for notice in _showing:
        notice.left -= dt
    _showing[:] = [n for n in _showing if n.left > 0]
    while _waiting and len(_showing) < MAX_SHOWN:
        _showing.append(_waiting.popleft())
    for notice in _showing:
        if notice.sound and audio is not None:
            audio.play(notice.sound)
        notice.sound = None


def draw_box(surface: pygame.Surface, lines: list[str], top: int = PlaceSettings.TOP) -> None:
    """The small window at the top center that a new room's name and every notice use: white
    text, a second line (the date) in yellow, as thin as the letters allow (Frankie, 11/12)."""
    size = FontSettings.SIZE_BODY
    pad = UISettings.TEXT_BOX_PADDING
    row = text_renderer.line_height(size)
    width = -(-(max(text_renderer.text_width(line, size) for line in lines) + 2 * pad) // 8) * 8
    height = (len(lines) - 1) * row + size + 2 * pad  # the letters are size pixels tall
    rect = pygame.Rect((surface.get_width() - width) // 16 * 8, top, width, height)
    draw_window(surface, rect)
    for index, line in enumerate(lines):
        x = rect.left + (rect.width - text_renderer.text_width(line, size)) // 2
        text_renderer.draw_text(surface, line, (x, rect.top + pad + index * row), size=size,
                                color=ColorSettings.YELLOW if index else ColorSettings.WHITE)


def render(surface: pygame.Surface) -> None:
    """Draw the notice showing now in the room name's window; the rest wait their turn."""
    if _showing:
        draw_box(surface, [text_renderer.cased(_showing[0].text, FontSettings.SIZE_BODY)])
