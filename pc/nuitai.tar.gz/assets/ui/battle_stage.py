"""The battle stage: the fighters you can see, and how they move.

The battle rules (``systems/battle.py``) decide what happens and say so
as events. This module is one of the things that listens. It draws each
monster as a picture on a battlefield, lists the party in the HUD's
right panel, and turns events into motion:

* someone acts            -> they lunge forward (a party row hops)
* someone takes damage    -> they shake and flash, and a number floats up
* someone is healed       -> a green number floats up
* a monster is defeated   -> it fades out
* HP changes              -> the bar slides to its new length

All of the motion is done by moving one still picture a little each
frame (a "tween"). No animation frames are needed, so any still image
dropped into ``assets/graphics/monsters/`` works at once.

Monsters are drawn alone, facing the player, in the style of Dragon
Quest. The party is a list of names, bars and HP in the window below,
in the style of Final Fantasy (D-445); there are no portraits in a
fight. Nothing here stops party sprites being added later: they would
be one more kind of actor that reacts to the same events.

The stage owns no rules and changes nothing in the battle. Deleting it
would leave a fight that still plays out correctly in text.
"""

from __future__ import annotations

import math
import os
import random
from dataclasses import dataclass, field
from typing import Any

import pygame

from core.events import (
    AbilityUsedEvent,
    AttackEvent,
    ComboUsedEvent,
    CombatantDefeatedEvent,
    DamageEvent,
    DefendEvent,
    DodgeEvent,
    GuardRaisedEvent,
    HealEvent,
    ManaEvent,
    MissEvent,
    NoniUsedEvent,
    RevivedEvent,
    StanceEvent,
    StatusAppliedEvent,
    StrokeEvent,
    SwapEvent,
    WardBlockedEvent,
)
from core.data_loader import DataLoader
from core.elements import Element
from core.shared import by_id, short_name
from entities.field_monster import _frames
from settings import (
    AssetPaths,
    BattleSettings,
    BattleStageSettings as Stage,
    ColorSettings,
    FontSettings,
    ScreenSettings,
    UISettings,
)
from systems import config
from systems.battle import Combatant
from ui import text_renderer
from utils.graphics import (
    load_monster_sprite, load_party_sheet, load_turn_face,
)

# Short labels for the status line under a monster's name.
_GUARD_LABELS: dict[str, str] = {
    "sentinel": "Guard", "counter": "Counter", "cooker": "Cooker",
    "bell": "Bell", "oil": "Hot Oil", "steam": "Steam", "boil": "Boil Over",
    "cast_iron": "Cast Iron", "oven_mitt": "Oven Mitt",
}

# The short tags for the kits' statuses (10/21); any other status shows by its id.
_STATUS_LABELS: dict[str, str] = {
    "burn": "Burn", "weak": "Weak", "mbreak": "Mind Break", "calm": "Still",
    "mleech": "Leeched", "seed": "Seeded", "sprout": "Seed", "bloom": "Bloom",
    "perennial": "Green Dream", "haunt": "Haunted", "grip": "Gripped", "sap": "Sap",
    "doom": "Doom", "up_magic": "Magic Up", "up_hp": "HP Up",
    "sulk": "Sulking", "up_strength": "Str Up", "up_vitality": "Vit Up",
    "dn_magic": "Magic Down", "dn_strength": "Str Down", "dn_evasion": "Eva Down",
    "dn_accuracy": "Acc Down", "dn_vitality": "Vit Down", "dn_spirit": "Spr Down",
    "charmed": "Charmed", "nightmare": "Nightmare", "poison": "Poison", "sleep": "Sleep", "blind": "Blind",
    "slow": "Slow", "possess": "Possessed",
}


_SMALL_ICONS: dict[tuple[str, int], pygame.Surface | None] = {}


def _small_element_icon(element_id: str, size: int) -> pygame.Surface | None:
    """Return the hand-made ``size`` square element icon, or None without one.

    The icon is icons/<element>_<size>.png, drawn at that size (10/19); a
    bigger icon is never shrunk to stand in for it (D-577).
    """
    key = (element_id, size)
    if key not in _SMALL_ICONS:
        drawn = os.path.join(AssetPaths.ICONS_DIR, f"{element_id}_{size}.png")
        _SMALL_ICONS[key] = (
            pygame.image.load(drawn).convert_alpha() if os.path.exists(drawn) else None
        )
    return _SMALL_ICONS[key]


_MAP_KINDS: dict[str, dict] | None = None


def _map_kinds() -> dict[str, dict]:
    """Each monster kind in the shared file to the map monster that brings it, its
    ``lead`` (or its boss fight's), so its turn picture is that map sprite (Frankie, 11/2)."""
    global _MAP_KINDS
    if _MAP_KINDS is None:
        templates = {e["id"]: e for f in by_id("encounters").values() for e in f["enemies"]}
        _MAP_KINDS = {}
        for kind in DataLoader().load("field_monsters").values():
            if "encounter" in kind:
                leads = by_id("encounters")[kind["encounter"]]["enemies"]
            else:
                leads = [templates[kind["lead"]]]
            for lead in leads:
                _MAP_KINDS.setdefault(lead["monster"], kind)
    return _MAP_KINDS


def _map_turn_icon(kind: dict, size: int) -> pygame.Surface | None:
    """A map monster's first frame as a ``size`` square turn picture, or None without one.

    Its visible pixels are centered both ways; one too big to fit is shrunk
    by a whole number, as the map editor's icons are.
    """
    frames = _frames(kind)
    if not frames:
        return None
    seen = frames[0].subsurface(frames[0].get_bounding_rect())
    factor = max(1, -(-seen.get_width() // size), -(-seen.get_height() // size))
    seen = pygame.transform.scale(seen, (seen.get_width() // factor, seen.get_height() // factor))
    icon = pygame.Surface((size, size), pygame.SRCALPHA)
    icon.blit(seen, ((size - seen.get_width()) // 2, (size - seen.get_height()) // 2))
    return icon


def _in_sprite_colors(icon: pygame.Surface, sprite: pygame.Surface | None) -> pygame.Surface:
    """``icon`` with each seen pixel painted the nearest colour of the battle ``sprite``.

    The cartridge draws a map monster's turn picture in its battle picture's
    palette, so the boar's is brown as its battle sprite; pygame matches it
    (Frankie, 11/10). Without a battle sprite the icon is kept as it is.
    """
    if sprite is None:
        return icon
    colors = sorted({
        tuple(sprite.get_at((x, y)))[:3]
        for y in range(sprite.get_height()) for x in range(sprite.get_width())
        if sprite.get_at((x, y)).a > 127
    })
    if not colors:
        return icon
    out = pygame.Surface(icon.get_size(), pygame.SRCALPHA)
    for y in range(icon.get_height()):
        for x in range(icon.get_width()):
            p = icon.get_at((x, y))
            if p.a > 127:
                out.set_at((x, y), min(colors, key=lambda c: math.dist(c, (p.r, p.g, p.b))) + (255,))
    return out


def element_icon(element_id: str) -> pygame.Surface | None:
    """The 8 by 8 element icon before a party member's name, for other screens (the Equip screen's)."""
    return _small_element_icon(element_id, Stage.PARTY_ICON_SIZE)


def status_labels(combatant: Combatant) -> list[str]:
    """Return short labels for everything currently on ``combatant``."""
    if not combatant.alive:
        return []
    labels: list[str] = []
    if combatant.guard is not None:
        labels.append(_GUARD_LABELS.get(combatant.guard, "Guard"))
    if combatant.defending:
        labels.append("Defend")
    if combatant.ward:
        labels.append("Ward")
    if combatant.haste > 0:
        labels.append("Haste")
    if combatant.safe:
        labels.append("Safeguard")
    if combatant.regen > 0:
        labels.append(f"Regen {combatant.regen}")
    for status, value in combatant.statuses.items():
        if status == "deep":
            continue  # Moepapa's sleep shows as sleep.
        label = _STATUS_LABELS.get(status, status)
        labels.append(f"{label} {value}" if status == "doom" else label)
    if combatant.spirit:
        labels.append(f"Spirit {combatant.spirit['left']}")
    return labels


@dataclass
class _Floater:
    """A number or word drifting up from a fighter."""

    text: str
    color: tuple[int, int, int]
    x: float
    y: float
    age: float = 0.0
    # How far it rises over its life.
    rise: float = Stage.FLOAT_RISE_PIXELS
    # A knocked-out number flies instead of rising: its speed, in pixels a second.
    vx: float | None = None
    vy: float = 0.0
    # A single big hit's number hops once in place, then sits still (Frankie, 11/1).
    bounce: bool = False


@dataclass
class _Actor:
    """The on-screen state of one fighter. Times count down to zero."""

    combatant: Combatant
    # Where the fighter stands: bottom-centre for a monster, the start
    # of the row for a party member.
    home: tuple[int, int]
    sprite: pygame.Surface | None = None
    flash_sprite: pygame.Surface | None = None
    # The picture washed in each element's color, made once, for a stance switch.
    stance_sprites: dict = field(default_factory=dict)
    shake: float = 0.0
    flash: float = 0.0
    lunge: float = 0.0
    # Seconds into a party member's attack animation, or None while they idle.
    swing: float | None = None
    # Seconds since a monster was defeated, or None while it stands.
    fallen_for: float | None = None
    # HP as the bar shows it, sliding toward the real figure.
    bar_hp: float = 0.0
    # Mana as the pips show it, set by each ManaEvent as it is played.
    mana: int = 0
    bob_phase: float = 0.0
    floaters: list[_Floater] = field(default_factory=list)
    # Which way the last knocked-out number flew, so the next goes the other way.
    splash_side: int = 1
    # The effect of a stance switch playing over a monster, or None.
    burst: _Burst | None = None
    # The splashes of attacks that have just landed on a monster, oldest first.
    hits: list[_Hit] = field(default_factory=list)


@dataclass
class _Burst:
    """A monster's stance switch, shown as a short burst of its new element (Frankie, 10/28)."""

    element: str
    age: float = 0.0
    seed: int = 0
    # Only a stance switch pulses the monster in the element's color; a job done to it does not.
    pulse: bool = True


@dataclass
class _Hit:
    """An attack landing on a monster, shown as a splash flung out of its middle (Frankie, 11/4)."""

    element: str  # An element id, or "plain" for a swing with none.
    age: float = 0.0
    seed: int = 0
    # A two-element move splashes both: every other particle is the second element's (Claude's call, 11/4).
    also: str | None = None


def render_hit_splash(surface: pygame.Surface, center: tuple[int, int], hit: _Hit) -> None:
    """Draw ``hit`` flung outward from ``center``, in square screen pixels.

    Every element starts with the same short white flash at the point of impact, then
    moves its own way: streaks of flame for fire, tumbling leaves for nature, thrown
    droplets and a ring for water, rays and a starburst for light, growing smoke puffs
    for shadow, sparks on a spiral and a ring for spirit. A plain swing is white
    streaks. Colors are ``Stage.STANCE_FX_COLORS``; near the end every other particle
    drops out, a dither, instead of fading.
    """
    cx, cy = center
    t = min(1.0, hit.age / Stage.HIT_FX_SECONDS)
    rng = random.Random(hit.seed)

    def dot(x: float, y: float, color: tuple[int, int, int], size: int = 1) -> None:
        surface.fill(color, (int(x), int(y), size, size))

    def line(x0: float, y0: float, x1: float, y1: float, color: tuple[int, int, int]) -> None:
        steps = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
        for k in range(steps):
            f = k / max(1, steps - 1)
            dot(x0 + (x1 - x0) * f, y0 + (y1 - y0) * f, color)

    if t < Stage.HIT_FX_FLASH_SHARE:
        reach = 2 + int(t / Stage.HIT_FX_FLASH_SHARE * 4)
        for degrees in range(0, 360, 45):
            angle = math.radians(degrees)
            line(cx, cy, cx + math.cos(angle) * reach, cy + math.sin(angle) * reach, (255, 255, 255))
    for i in range(Stage.HIT_FX_PARTICLES):
        angle = rng.random() * math.tau
        speed = 0.6 + rng.random() * 0.6
        dist = (1 - (1 - t) ** 2) * Stage.HIT_FX_REACH * speed  # Fast out, slowing down.
        x, y = cx + math.cos(angle) * dist, cy + math.sin(angle) * dist
        if t > 0.7 and i % 2:
            continue
        element = hit.also if hit.also and i % 4 >= 2 else hit.element  # Pairs, so the dither keeps both.
        dark, mid, bright = Stage.HIT_FX_PLAIN_COLORS if element == "plain" else Stage.STANCE_FX_COLORS[element]
        if element in ("afi", "plain"):
            # Streaks with a tail that shortens, an ember at the tip.
            tail = max(2, 12 * (1 - t))
            line(x - math.cos(angle) * tail, y - math.sin(angle) * tail, x, y, dark)
            line(x - math.cos(angle) * tail / 2, y - math.sin(angle) * tail / 2, x, y, mid)
            dot(x, y, bright)
        elif element == "lau":
            flip = int(t * 12 + i) % 2
            dot(x, y + flip, dark)
            dot(x + 1, y, mid)
            dot(x + 1, y + 1, mid)
            dot(x + 2, y + 1 - flip, dark)
        elif element == "wai":
            y += t * t * 20  # Thrown out, then falling.
            dot(x, y, mid, 2)
            dot(x, y, bright)
        elif element == "la":
            if i % 2 == 0:
                inner = dist * 0.3
                line(cx + math.cos(angle) * inner, cy + math.sin(angle) * inner, x, y, mid)
            dot(x, y, bright)
            if i % 4 == 0:
                for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    dot(x + dx, y + dy, bright)
        elif element == "ata":
            size = 2 + int(t * 3)
            dot(x - size // 2, y - size // 2, dark, size)
            if i % 3 == 0:
                dot(x, y, bright)
        else:  # mana: sparks riding outward on a spiral
            spun = angle + t * 3
            x, y = cx + math.cos(spun) * dist, cy + math.sin(spun) * dist
            dot(x, y, mid, 2)
            dot(x, y, bright)
    for element in (hit.element, hit.also):
        if element in ("wai", "mana"):
            # A ring spreading out, squashed to read as lying on the ground.
            radius = t * Stage.HIT_FX_RING_REACH
            dark, mid, _ = Stage.STANCE_FX_COLORS[element]
            color = mid if t < 0.6 else dark
            for degrees in range(0, 360, 6 if element == "wai" else 10):
                angle = math.radians(degrees)
                dot(cx + math.cos(angle) * radius, cy + math.sin(angle) * radius * 0.5, color)


def render_stance_burst(surface: pygame.Surface, box: pygame.Rect, burst: _Burst) -> None:
    """Draw ``burst`` over a monster whose picture fills ``box``, in square screen pixels.

    Each element has its own motion: leaves drift down for nature, flames
    lick up for fire, black smoke billows for shadow, droplets splash for
    water, sparkles twinkle for light, wisps spiral up for spirit. Every
    particle is a few solid pixels in the element's three colors
    (``Stage.STANCE_FX_COLORS``); near the end every other one drops out,
    a dither, instead of fading, as the hardware would.
    """
    dark, mid, bright = Stage.STANCE_FX_COLORS[burst.element]
    t = burst.age / Stage.STANCE_FX_SECONDS
    rng = random.Random(burst.seed)
    w, h = max(8, box.width), max(8, box.height)

    def dot(x: float, y: float, color: tuple[int, int, int], size: int = 1) -> None:
        surface.fill(color, (int(x), int(y), size, size))

    for i in range(Stage.STANCE_FX_PARTICLES):
        u, v, p = rng.random(), rng.random(), rng.random()
        start = p * 0.35
        if t < start:
            continue
        life = (t - start) / (1 - start)
        if life > 0.75 and i % 2:
            continue
        if burst.element == "lau":
            x = box.left + u * w + math.sin(life * 7 + p * 6) * 4
            y = box.top - 4 + life * h * (0.5 + 0.5 * v)
            flip = int(life * 8 + i) % 2
            dot(x, y + flip, dark)
            dot(x + 1, y, mid)
            dot(x + 1, y + 1, mid)
            dot(x + 2, y + 1 - flip, dark)
            if i % 3 == 0:
                dot(x + 1, y, bright)
        elif burst.element == "afi":
            x = box.left + u * w + math.sin(life * 25 + p * 9)
            y = box.bottom - v * h * 0.4 - life * h * 0.7
            # A tongue of flame, 2 wide, shrinking as it rises: red under, orange, a yellow tip.
            tall = 5 if life < 0.4 else 3 if life < 0.75 else 2
            surface.fill(dark, (int(x), int(y) + tall - 2, 2, 2))
            surface.fill(mid, (int(x), int(y) + 1, 2, max(0, tall - 3)))
            dot(x + (i % 2), y, bright)
        elif burst.element == "ata":
            x = box.centerx + (u - 0.5) * w * (0.8 + 0.5 * life)
            y = box.bottom - v * h * 0.6 - life * 14
            r = 1 + int(life * 3)
            pygame.draw.circle(surface, mid, (int(x), int(y)), r + 1)
            pygame.draw.circle(surface, dark, (int(x), int(y)), r)
            if i % 4 == 0:
                dot(x - r, y - r, bright)
        elif burst.element == "wai":
            x = box.centerx + (u - 0.5) * w * 1.3 * life
            y = box.top + h * 0.35 - (10 + v * 20) * life + 50 * life * life
            dot(x, y, bright)
            surface.fill(mid, (int(x) - 1, int(y) + 1, 3, 2))
            surface.fill(dark, (int(x), int(y) + 3, 2, 1))
        elif burst.element == "la":
            if not 0 <= t - p * 0.6 <= 0.4:
                continue
            glow = 1 - abs((t - p * 0.6) / 0.2 - 1)
            x, y = box.left + u * w, box.top + v * h
            dot(x, y, bright)
            for arm in range(1, 1 + round(glow * 2)):
                color = mid if arm == 1 else dark
                for dx, dy in ((arm, 0), (-arm, 0), (0, arm), (0, -arm)):
                    dot(x + dx, y + dy, color)
        else:  # mana
            angle = p * math.tau + life * math.tau * 1.5
            radius = w * 0.55 * (1 - 0.4 * life)
            x = box.centerx + math.cos(angle) * radius
            y = box.bottom - life * h * 1.1 + math.sin(angle) * 3
            trail = angle - 0.35
            dot(box.centerx + math.cos(trail) * radius, y + 2, dark)
            dot(x, y, mid, 2)
            dot(x, y, bright)


# Status icons over a monster (Frankie, 11/4): '#' is a solid pixel. To give another status an
# icon, add its pattern and a drawer here, and a row in ``_STATUS_ICONS``.
_HEART = [".##.##.", "#######", "#######", ".#####.", "..###..", "...#..."]
_SKULL = [
    "..###..", ".#####.", ".#.#.#.", ".#####.", "..#.#..",
    "#.....#", ".#...#.", "..#.#..", ".#...#.", "#.....#",
]
_SHADES = ["#######", "###.###", ".#...#."]
_Z = ["####", "..#.", ".#..", "####"]
_FLAME = ["...#...", "..##...", "..###.#", ".######", "#######", "#######", ".#####."]


def _stamp(
    surface: pygame.Surface, pattern: list[str], x: int, y: int,
    color: tuple[int, int, int], outline: tuple[int, int, int] = Stage.ICON_OUTLINE,
) -> None:
    """Draw ``pattern`` with its top left at ``(x, y)``, one pixel each, edged in ``outline``."""
    for row, cells in enumerate(pattern):
        for col, cell in enumerate(cells):
            if cell == "#":
                for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    surface.fill(outline, (x + col + dx, y + row + dy, 1, 1))
    for row, cells in enumerate(pattern):
        for col, cell in enumerate(cells):
            if cell == "#":
                surface.fill(color, (x + col, y + row, 1, 1))


def _icon_charmed(surface: pygame.Surface, x: int, y: int, clock: float) -> None:
    """A heart that hops once a beat."""
    beat = 1 if (clock * Stage.ICON_HEART_BEATS) % 1 < 0.2 else 0
    _stamp(surface, _HEART, x, y - beat, Stage.ICON_HEART_COLOR)


def _icon_sleep(surface: pygame.Surface, x: int, y: int, clock: float) -> None:
    """Three Zs climbing, each a step behind the last."""
    for k in range(3):
        phase = (clock * Stage.ICON_Z_SPEED + k / 3) % 1
        _stamp(surface, _Z, x + k * Stage.ICON_Z_STEP, y + 6 - int(phase * Stage.ICON_Z_RISE), Stage.ICON_Z_COLOR)


def _icon_poison(surface: pygame.Surface, x: int, y: int, clock: float) -> None:
    """A skull and crossbones."""
    _stamp(surface, _SKULL, x, y - 2, Stage.ICON_SKULL_COLOR)


def _icon_blind(surface: pygame.Surface, x: int, y: int, clock: float) -> None:
    """A pair of sunglasses."""
    _stamp(surface, _SHADES, x, y + 2, Stage.ICON_SHADES_COLOR, Stage.ICON_SHADES_OUTLINE)


def _icon_burn(surface: pygame.Surface, x: int, y: int, clock: float) -> None:
    """A flame that flickers, its core a yellower red."""
    lean = 1 if (clock * Stage.ICON_FLAME_FLICKER) % 1 < 0.5 else 0
    _stamp(surface, _FLAME, x + lean, y - 3, Stage.ICON_FLAME_COLOR)
    _stamp(surface, ["...", ".#.", "###"], x + 2 + lean, y + 1, Stage.ICON_FLAME_CORE, Stage.ICON_FLAME_COLOR)


# Status -> (width in pixels, drawer). The row shows them in this order.
_STATUS_ICONS = {
    "charmed": (7, _icon_charmed),
    "sleep": (14, _icon_sleep),
    "poison": (7, _icon_poison),
    "blind": (7, _icon_blind),
    "burn": (8, _icon_burn),
}


class BattleStage:
    """Draws both sides of a fight and animates them from battle events."""

    def __init__(
        self,
        party: list[Combatant],
        enemies: list[Combatant],
        sprite_ids: dict[str, str | None],
        floating: set[str] = frozenset(),
        bench: list[Combatant] | None = None,
    ) -> None:
        """Place every fighter.

        Args:
            party: The party's combatants, in menu order.
            enemies: The monsters, left to right.
            sprite_ids: Monster combatant id -> picture name in
                ``assets/graphics/monsters/`` (without ".png"), or None
                for a monster with no picture, which gets a plain box.
            floating: Monster ids that bob in the air, ghosts and flyers
                (``floats`` in the shared file). The rest stand still.
            bench: Party members who can be swapped in. Each gets a row
                the moment they take someone's place.
        """
        self._floating = set(floating)
        self._sprite_ids = dict(sprite_ids)
        # Monsters already called to a side when the fight opens (the Great Boar's boar) are not in
        # the encounter's list, so their picture comes from themselves (Frankie, 11/1: a grey square).
        for c in enemies:
            self._sprite_ids.setdefault(c.id, getattr(c, "picture", None))
        # The stroke being swung, so a Paddle hit knows to splash (Frankie, 11/1).
        self._stroke: str | None = None
        # Combatant id -> its small turn-order picture.
        self._turn_icons: dict[str, pygame.Surface] = {}
        self._clock = 0.0
        # Counts the hits landed, so each splash scatters differently.
        self._hit_count = 0
        # The elements the move being played lists, if it lists two.
        self._move_elements: list[str] = []
        self._actors: dict[str, _Actor] = {}
        self._party = party
        self._bench = bench if bench is not None else []
        self._enemies = enemies
        for c in enemies:
            self._add_enemy(c)
        self._place_enemies()
        for index, c in enumerate(list(party) + list(bench or [])):
            self._actors[c.id] = _Actor(
                combatant=c,
                home=(
                    Stage.PARTY_ROW_X,
                    Stage.PARTY_ROW_TOP_Y + index * Stage.PARTY_ROW_PITCH,
                ),
                bar_hp=float(c.hp),
                mana=c.mana,
            )

    def _add_enemy(self, c: Combatant) -> None:
        """Give monster ``c`` its picture and a place in the line, set by ``_place_enemies``."""
        actor = _Actor(
            combatant=c,
            home=(0, Stage.MONSTER_SPOTS[0][1]),
            bar_hp=float(c.hp),
            mana=c.mana,
            bob_phase=len([a for a in self._actors.values() if not a.combatant.is_party]) * Stage.BOB_PHASE_STEP,
        )
        loaded = load_monster_sprite(self._sprite_ids.get(c.id))
        if loaded is not None:
            actor.sprite, actor.flash_sprite = loaded
        self._actors[c.id] = actor

    def _place_enemies(self) -> None:
        """Stand the monsters on the field's spots as the fight opens or when one joins.

        The spots are Frankie's (11/11): two staggered rows, set on the layout
        board. A monster's picture is centered where a boar's is on its spot,
        then pulled in if it would run onto the turn bar, the screen's edge or
        the HUD. One already faded away gives up its place.
        """
        shown = [
            self._actors[c.id] for c in self._enemies
            if c.id in self._actors and not (
                self._actors[c.id].fallen_for is not None
                and self._actors[c.id].fallen_for >= Stage.FADE_SECONDS)
        ]
        if not shown:
            return
        boar = load_monster_sprite(Stage.MONSTER_SPOT_SPRITE)
        boar_half = boar[0].get_height() // 2 if boar is not None else 0
        spots = Stage.MONSTER_SPOTS
        fill = Stage.MONSTER_FILL.get(len(shown)) or tuple(range(len(spots)))
        for n, actor in enumerate(shown):
            lap, slot = divmod(n, len(fill))
            spot_x, spot_y = spots[fill[slot]]
            spot_x += lap * Stage.MONSTER_EXTRA_SHIFT
            image = actor.sprite
            height = image.get_height() if image is not None else Stage.PLACEHOLDER_SIZE
            feet = round(spot_y - boar_half + height / 2)
            actor.home = (spot_x, feet)
            actor.home = self._kept_on_field(actor)

    def _kept_on_field(self, actor: _Actor) -> tuple[int, int]:
        """Return ``actor.home`` moved just far enough that its picture stays clear of the turn bar, the screen's edge and the HUD."""
        cx, ground = actor.home
        box = self._visible_box(actor)
        bar = self.turn_bar_rect(8)
        left_limit = bar.right if bar is not None else Stage.FIELD_LEFT
        dx = max(0, left_limit - box.left) - max(0, box.right - ScreenSettings.WIDTH)
        dy = -max(0, ground - Stage.FIELD_BOTTOM)
        return (cx + dx, ground + dy)

    def join(self, monster: Combatant) -> None:
        """A monster called into the fight (the Great Boar's Squeal, Frankie 10/28) takes its place in the line."""
        if monster.id in self._actors:
            return
        self._sprite_ids[monster.id] = monster.picture
        self._add_enemy(monster)
        self._place_enemies()

    def _rows(self) -> list[Combatant]:
        """The party's rows on screen: the party in order, then Tawiri's spirit while its fading is still shown.

        The battle drops a spirit from its party the moment it falls or runs out, well before the
        screen has told it (Frankie, 11/1: it vanished from the window before it faded away), so
        the row stays until the stage is told it has left.
        """
        rows = [c for c in self._party if c.id in self._actors]
        # Not the bench: a member waiting there has no row until a swap puts them in someone's place.
        rows += [a.combatant for a in self._actors.values()
                 if a.combatant.is_party and a.combatant not in self._party and a.combatant not in self._bench]
        return rows

    def summon(self, spirit: Combatant | None, spirit_id: str) -> None:
        """Tawiri's spirit takes a fourth row, the four moved up to fit, or leaves it (Frankie, 10/25)."""
        if spirit is None:
            self._actors.pop(spirit_id, None)
            shift = 0
        else:
            self._actors[spirit.id] = _Actor(
                combatant=spirit, home=(Stage.PARTY_ROW_X, 0), bar_hp=float(spirit.hp), mana=spirit.mana)
            shift = Stage.PARTY_ROW_PITCH // 2
        rows = self._rows()
        for index, c in enumerate(rows):
            actor = self._actors[c.id]
            actor.home = (actor.home[0], Stage.PARTY_ROW_TOP_Y - shift + index * Stage.PARTY_ROW_PITCH)

    # ------------------------------------------------------------------
    # EVENTS IN
    # ------------------------------------------------------------------

    def consume(self, event: Any) -> None:
        """Start whatever motion ``event`` calls for."""
        if isinstance(event, (AttackEvent, StrokeEvent)):
            self._lunge(event.attacker_id)
            swinger = self._actors.get(event.attacker_id)
            if swinger is not None and swinger.combatant.is_party:
                swinger.swing = 0.0
            self._stroke = event.stroke if isinstance(event, StrokeEvent) else None
        elif isinstance(event, ManaEvent):
            actor = self._actors.get(event.combatant_id)
            if actor is not None:
                actor.mana = event.total
        elif isinstance(event, DodgeEvent):
            actor = self._actors.get(event.target_id)
            if actor is not None:
                self._float(actor, "Dodge", ColorSettings.GRAY)
        elif isinstance(event, (AbilityUsedEvent, NoniUsedEvent)):
            self._lunge(event.user_id)
            # A move that lists two elements splashes in both (Frankie, 11/4).
            move = by_id("moves").get(getattr(event, "ability_id", None)) or {}
            self._move_elements = list(move.get("elements") or ())
        elif isinstance(event, ComboUsedEvent):
            self._lunge(event.user_id)
            self._lunge(event.partner_id)
        elif isinstance(event, SwapEvent):
            # The one coming in takes the row of the one stepping back.
            leaving = self._actors[event.out_id]
            coming = self._actors[event.in_id]
            coming.home, leaving.home = leaving.home, coming.home
            coming.lunge = Stage.LUNGE_SECONDS
        elif isinstance(event, DamageEvent):
            if event.cause == "counter" and event.attacker_id:
                self._lunge(event.attacker_id)
            actor = self._actors.get(event.target_id)
            if actor is None:
                return
            if event.timed == "perfect":
                # A perfect parry: nothing lands and nothing rises over their name; "Parried!" rises
                # above the meter's bar instead (Frankie, 11/10).
                actor.floaters.clear()
                return
            actor.shake = Stage.SHAKE_SECONDS
            actor.flash = Stage.FLASH_SECONDS
            if not actor.combatant.is_party and event.cause in Stage.HIT_FX_CAUSES and event.element:
                # A splash flung out of the monster, for an elemental hit only; a plain swing just
                # flashes and shakes (Frankie, 11/4).
                self._hit_count += 1
                element = event.element.value if event.element else "plain"
                other = [e for e in self._move_elements if e != element]
                also = other[0] if element in self._move_elements and other else None
                actor.hits.append(_Hit(element, seed=self._hit_count, also=also))
            if actor.combatant.is_party:
                color = Stage.COLOR_PARTY_DAMAGE
            elif event.guarded or event.multiplier == 1.0:
                color = ColorSettings.WHITE
            elif event.multiplier > 1.0:
                color = ColorSettings.YELLOW
            else:
                color = ColorSettings.GRAY
            stroke, self._stroke = self._stroke, None
            if actor.combatant.is_party:
                self._float(actor, str(event.amount), color)
                # A parry that was not perfect shows no word at all, only less damage (Frankie, 11/10).
            elif stroke == "Paddle" and event.cause == "stroke":
                self._splash(actor, str(event.amount), color)
            elif stroke in Stage.BOUNCE_STROKES:
                # One big hit: the number hops once where it lands (Frankie, 11/1).
                x, y = self._float_origin(actor)
                actor.floaters.append(_Floater(str(event.amount), color, x, y, bounce=True))
            else:
                self._float(actor, str(event.amount), color)
        elif isinstance(event, HealEvent):
            actor = self._actors.get(event.target_id)
            if actor is not None and event.amount > 0:  # a heal of nothing shows nothing (Frankie, 11/5)
                self._float(actor, f"+{event.amount}", Stage.COLOR_HEAL)
                self._job(actor, "lau")
        elif isinstance(event, RevivedEvent):
            actor = self._actors.get(event.target_id)
            if actor is not None:
                actor.fallen_for = None
                self._float(actor, f"+{event.hp}", Stage.COLOR_HEAL)
        elif isinstance(event, MissEvent):
            actor = self._actors.get(event.target_id)
            if actor is not None:
                self._float(actor, "Miss", ColorSettings.GRAY)
        elif isinstance(event, WardBlockedEvent) and event.share >= 1:
            actor = self._actors.get(event.target_id)
            if actor is not None:
                self._float(actor, "Block", Stage.COLOR_STATUS)
        elif isinstance(event, StatusAppliedEvent):
            actor = self._actors.get(event.target_id)
            if actor is not None and event.applied:
                self._float(actor, _STATUS_LABELS.get(event.status, event.status), Stage.COLOR_STATUS)
                self._job(actor, self._status_element(event.status))
        elif isinstance(event, (DefendEvent, GuardRaisedEvent)):
            self._job(self._actors.get(event.combatant_id), "wai")  # Water's job is the body taking the hit.
        elif isinstance(event, CombatantDefeatedEvent):
            actor = self._actors.get(event.combatant_id)
            if actor is not None and not actor.combatant.is_party:
                actor.fallen_for = 0.0
        elif isinstance(event, StanceEvent):
            # A monster's switch is always shown, scanned or not (Frankie, 10/28).
            actor = self._actors.get(event.combatant_id)
            if actor is not None and not actor.combatant.is_party:
                actor.burst = _Burst(event.element.value, seed=sum(map(ord, actor.combatant.id)))

    def _job(self, actor: _Actor | None, element: str | None) -> None:
        """Play ``element``'s burst over a monster it is doing its job to, without the pulse (Frankie, 11/4).

        A burst already playing is left to finish, so a stance switch is never cut short.
        """
        if element is None or actor is None or actor.combatant.is_party or actor.burst is not None:
            return
        actor.burst = _Burst(element, seed=sum(map(ord, actor.combatant.id)), pulse=False)

    @staticmethod
    def _status_element(status: str) -> str | None:
        """Return the element whose job gaining ``status`` is, or None for one no element owns."""
        for prefix, element in Stage.JOB_FX_PREFIXES.items():
            if status.startswith(prefix):
                return element
        return Stage.JOB_FX_STATUSES.get(status)

    def _lunge(self, combatant_id: str) -> None:
        """Send a fighter forward and back."""
        actor = self._actors.get(combatant_id)
        if actor is not None:
            actor.lunge = Stage.LUNGE_SECONDS

    def _float(
        self, actor: _Actor, text: str, color: tuple[int, int, int]
    ) -> None:
        """Start a number or word rising from ``actor``.

        A second floater started while the first is still low is nudged
        upward so the two do not print on top of each other. A party
        member's row has no room above it, the next row up is someone
        else's, so there the new one takes the old one's place (the 10/26
        Let's Play read Hina's second number as a hit on Kailo).
        """
        if actor.combatant.is_party:
            actor.floaters.clear()
        x, y = self._float_origin(actor)
        y -= Stage.FLOAT_STACK_STEP * sum(
            1 for f in actor.floaters if f.age < Stage.FLOAT_STACK_WINDOW
        )
        rise = Stage.FLOAT_PARTY_RISE_PIXELS if actor.combatant.is_party else Stage.FLOAT_RISE_PIXELS
        actor.floaters.append(_Floater(text, color, x, y, rise=rise))

    def _splash(self, actor: _Actor, text: str, color: tuple[int, int, int]) -> None:
        """Knock a Paddle hit's number out of a monster (Frankie, 11/1): off to one side, then down.

        Each flies to the other side from the last, at a random angle and speed,
        so a run of rapid hits sprays apart instead of stacking.
        """
        actor.splash_side = -actor.splash_side
        angle = math.radians(random.uniform(Stage.SPLASH_ANGLE_MIN, Stage.SPLASH_ANGLE_MAX))
        speed = random.uniform(Stage.SPLASH_SPEED_MIN, Stage.SPLASH_SPEED_MAX)
        x, y = self._float_origin(actor)
        actor.floaters.append(_Floater(text, color, x, y,
                                       vx=actor.splash_side * speed * math.sin(angle),
                                       vy=-speed * math.cos(angle)))

    def _float_origin(self, actor: _Actor) -> tuple[float, float]:
        """Return where a floater over ``actor`` starts.

        A party member's pops up from the middle of their HP bar, which drains
        under it anyway, so the name and the HP figure stay readable (Frankie,
        10/25: it covered the name), and rises only a little, staying on its
        own row (``Stage.FLOAT_PARTY_RISE_PIXELS``).
        """
        if actor.combatant.is_party:
            return (
                actor.home[0] + Stage.PARTY_BAR_DX + Stage.BAR_WIDTH / 2,
                actor.home[1] - Stage.FLOAT_PARTY_RISE_START,
            )
        height = (
            actor.sprite.get_height()
            if actor.sprite is not None
            else Stage.PLACEHOLDER_SIZE
        )
        return (actor.home[0], actor.home[1] - height * Stage.FLOAT_SPRITE_HEIGHT)

    # ------------------------------------------------------------------
    # TIME
    # ------------------------------------------------------------------

    def update(self, dt: float, shown_hp: dict[str, int]) -> None:
        """Advance every motion by ``dt`` seconds.

        Args:
            dt: Seconds since the last frame.
            shown_hp: The HP the scene is currently narrating for each
                combatant id. Bars slide toward these.
        """
        self._clock += dt
        for combatant_id, actor in self._actors.items():
            actor.shake = max(0.0, actor.shake - dt)
            actor.flash = max(0.0, actor.flash - dt)
            actor.lunge = max(0.0, actor.lunge - dt)
            if actor.swing is not None:
                actor.swing += dt
                sheet = load_party_sheet(Stage.PARTY_ATTACK_SHEETS.get(combatant_id, ""))
                if sheet is None or actor.swing >= len(sheet[0]) * Stage.ATTACK_FRAME_SECONDS:
                    actor.swing = None
            if actor.fallen_for is not None:
                actor.fallen_for += dt
            # Extra HP past full (Kailo's meal, 10/25) counts up past max too.
            target = float(max(0, shown_hp[combatant_id]))
            step = actor.combatant.max_hp * Stage.BAR_SPEED * dt
            if actor.bar_hp < target:
                actor.bar_hp = min(target, actor.bar_hp + step)
            else:
                actor.bar_hp = max(target, actor.bar_hp - step)
            for floater in actor.floaters:
                floater.age += dt
            actor.floaters = [
                f for f in actor.floaters if f.age < Stage.FLOAT_SECONDS
            ]
            if actor.burst is not None:
                actor.burst.age += dt
                if actor.burst.age >= Stage.STANCE_FX_SECONDS:
                    actor.burst = None
            for hit in actor.hits:
                hit.age += dt
            actor.hits = [h for h in actor.hits if h.age < Stage.HIT_FX_SECONDS]

    # ------------------------------------------------------------------
    # DRAWING
    # ------------------------------------------------------------------

    def render_enemies(
        self,
        surface: pygame.Surface,
        shown_hp: dict[str, int],
        active_id: str | None,
        target: Combatant | None,
    ) -> None:
        """Draw the monsters: pictures only, a name while aimed at (D-458).

        Args:
            surface: Where to draw.
            shown_hp: HP per combatant id as currently narrated.
            active_id: Whose turn it is, drawn in yellow.
            target: The fighter the player is aiming at, if any.
        """
        # One called in this turn has no place until its arrival is shown (join).
        # Back row first, so a front monster covers the one behind it.
        for c in sorted((c for c in self._enemies if c.id in self._actors),
                        key=lambda c: self._actors[c.id].home[1]):
            self._render_enemy(
                surface, self._actors[c.id], shown_hp[c.id], active_id,
                c is target,
            )
        # What a Seer's Shell read (Frankie, 10/28), after the pictures so
        # none covers it. A reading that would run into the one before it
        # drops a row.
        last_right, last_row = -1, 1
        for c in (c for c in self._enemies if c.id in self._actors):
            actor = self._actors[c.id]
            if not c.seen or actor.fallen_for is not None:
                continue
            row = 1 - last_row if self._reading_left(actor, shown_hp[c.id]) <= last_right else 0
            last_right = self._render_reading(surface, actor, shown_hp[c.id], row)
            last_row = row

    def render_party(
        self,
        surface: pygame.Surface,
        shown_hp: dict[str, int],
        active_id: str | None,
        target: Combatant | None,
        picking: bool = False,
    ) -> None:
        """Draw the party's rows in the HUD. The scene draws the window first.

        While ``picking`` an ally, the rows are a list: the element icons
        give way to a solid menu cursor on the one aimed at, like the field
        menu's Items (the 10/26 Let's Play never saw the small pulsing arrow).
        """
        for c in self._rows():
            self._render_party_row(
                surface, self._actors[c.id], shown_hp[c.id], active_id,
                c is target, picking,
            )

    def render_party_sprites(self, surface: pygame.Surface, shown_hp: dict[str, int]) -> None:
        """Draw the party on the right of the field, turned toward the monsters (Frankie, 11/11).

        Each stands in a loose stagger, breathing in an idle loop, and plays their weapon's swing
        when they attack, then goes back to idling. A member with no sheet is simply not drawn.
        A fallen one is shown faded.
        """
        for index, c in enumerate(self._rows()):
            if index >= len(Stage.PARTY_SPRITE_FEET) or c.id not in self._actors:
                continue
            actor = self._actors[c.id]
            idle = load_party_sheet(f"{c.id}_idle")
            if idle is None:
                continue
            frames, whites = idle
            anchor = frames[0].get_bounding_rect().bottom or frames[0].get_height()
            hp = shown_hp.get(c.id, c.hp)
            attack = None
            if actor.swing is not None and hp > 0:
                attack = load_party_sheet(Stage.PARTY_ATTACK_SHEETS.get(c.id, ""))
            if attack is not None:
                frames, whites = attack
                n = min(len(frames) - 1, int(actor.swing / Stage.ATTACK_FRAME_SECONDS))
            else:
                n = int((self._clock + index * 0.11) / Stage.IDLE_FRAME_SECONDS) % len(frames)
            image = whites[n] if self._flashing(actor) else frames[n]
            fx, fy = Stage.PARTY_SPRITE_FEET[index]
            shadow = pygame.Surface((26, Stage.SHADOW_HEIGHT), pygame.SRCALPHA)
            pygame.draw.ellipse(shadow, (0, 0, 0, Stage.SHADOW_ALPHA), shadow.get_rect())
            surface.blit(shadow, (fx - 13, fy - Stage.SHADOW_HEIGHT // 2))
            if hp <= 0:
                image = image.copy()
                image.set_alpha(Stage.DOWN_ALPHA)
            x = fx - image.get_width() // 2 + self._shake_offset(actor)
            y = fy - anchor + Stage.FEET_SINK
            surface.blit(image, (x, y))

    def render_turn_order(
        self, surface: pygame.Surface, order: list[Combatant]
    ) -> None:
        """Draw the turn order as one bordered bar of small pictures (D-453).

        ``order`` starts with the one acting now, who gets the yellow
        arrow. Each entry has a stripe on its left, blue for the party
        and red for monsters. As many as fit above the bottom window.
        """
        size = Stage.TURN_ICON_SIZE
        stripe = Stage.TURN_STRIPE
        pitch = size + 1
        frame = self.turn_bar_rect(len(order))
        if frame is None:
            return
        count = (frame.height - 1) // pitch
        pygame.draw.rect(surface, config.window_colors()[1], frame.inflate(-2, -2))
        x = frame.left + 1
        for index, c in enumerate(order[:count]):
            y = frame.top + 1 + index * pitch
            pygame.draw.rect(
                surface,
                Stage.COLOR_TURN_PARTY if c.is_party else Stage.COLOR_TURN_FOE,
                pygame.Rect(x, y, stripe, size),
            )
            surface.blit(self._turn_icon(c), (x + stripe + 1, y))
            if index:
                pygame.draw.line(
                    surface, ColorSettings.GRAY,
                    (x, y - 1), (frame.right - 2, y - 1),
                )
        # The border leaves out its four corner pixels (D-457).
        l, t, r, b = frame.left, frame.top, frame.right - 1, frame.bottom - 1
        for start, end in (((l + 1, t), (r - 1, t)), ((l + 1, b), (r - 1, b)),
                           ((l, t + 1), (l, b - 1)), ((r, t + 1), (r, b - 1))):
            pygame.draw.line(surface, ColorSettings.WHITE, start, end)
        # The arrow points left at the one acting, over their picture's right side.
        tip_x = frame.right - Stage.TURN_ARROW - 3
        tip_y = frame.top + 1 + size // 2
        arrow = [
            (tip_x, tip_y),
            (tip_x + Stage.TURN_ARROW + 1, tip_y - Stage.TURN_ARROW - 1),
            (tip_x + Stage.TURN_ARROW + 1, tip_y + Stage.TURN_ARROW + 1),
        ]
        pygame.draw.polygon(surface, ColorSettings.BLACK, arrow)
        pygame.draw.polygon(surface, ColorSettings.YELLOW, [
            (tip_x + 1, tip_y),
            (tip_x + Stage.TURN_ARROW + 1, tip_y - Stage.TURN_ARROW + 1),
            (tip_x + Stage.TURN_ARROW + 1, tip_y + Stage.TURN_ARROW - 1),
        ])

    def render_turn_target(
        self, surface: pygame.Surface, order: list[Combatant], target: Combatant
    ) -> None:
        """Point the target arrow at ``target``'s pictures in the turn order bar.

        Drawn just right of the bar, pointing left, beside every turn the
        monster has in view, so two look-alikes can be told apart (10/28).
        """
        frame = self.turn_bar_rect(len(order))
        if frame is None:
            return
        pitch = Stage.TURN_ICON_SIZE + 1
        count = (frame.height - 1) // pitch
        s = Stage.CURSOR_SIZE
        x = frame.right + Stage.CURSOR_GAP
        for index, c in enumerate(order[:count]):
            if c is not target:
                continue
            y = frame.top + 1 + index * pitch + Stage.TURN_ICON_SIZE // 2
            points = [(x, y), (x + s, y - s), (x + s, y + s)]
            pygame.draw.polygon(surface, text_renderer.pointer_color(), points)
            pygame.draw.polygon(surface, ColorSettings.BLACK, points, 1)

    def _turn_icon(self, c: Combatant) -> pygame.Surface:
        """Return ``c``'s turn-order picture: a hand-drawn 16 by 16 face, a map sprite, or a marker.

        The marker stands in until a face is drawn: the element icon on a
        dark tile edged in the element's colour, a monster's one element
        or a party member's first. Nothing is shrunk to fit (D-577, D-585).
        """
        cached = self._turn_icons.get(c.id)
        if cached is not None:
            return cached
        size = Stage.TURN_ICON_SIZE
        if c.is_party:
            face = load_turn_face(c.id)
        elif c.kind in _map_kinds():
            face = _map_turn_icon(_map_kinds()[c.kind], size)
            if face is not None:
                loaded = load_monster_sprite(self._sprite_ids.get(c.id))
                face = _in_sprite_colors(face, loaded[0] if loaded else None)
        else:
            # Frankie's angry face, the marker of every monster with no map sprite (10/19).
            path = os.path.join(AssetPaths.ICONS_DIR, "monster_turn.png")
            face = pygame.image.load(path).convert_alpha() if os.path.exists(path) else None
        if face is not None and face.get_size() == (size, size):
            self._turn_icons[c.id] = face
            return face
        element = c.elements[0].value if c.elements else ""
        color = ColorSettings.ELEMENT_COLORS.get(element, Stage.COLOR_TURN_FOE)
        icon = pygame.Surface((size, size), pygame.SRCALPHA)
        pygame.draw.rect(icon, Stage.COLOR_TURN_MARKER, icon.get_rect(), border_radius=3)
        pygame.draw.rect(icon, color, icon.get_rect(), width=1, border_radius=3)
        mark = _small_element_icon(element, 8)
        if mark is not None:
            icon.blit(mark, ((size - 8) // 2, (size - 8) // 2))
        self._turn_icons[c.id] = icon
        return icon

    def numbers_up(self) -> bool:
        """Return True while a number or word still floats over any fighter."""
        return any(actor.floaters for actor in self._actors.values())

    def render_floaters(self, surface: pygame.Surface) -> None:
        """Draw the rising numbers and words, over everything else."""
        for actor in self._actors.values():
            for floater in actor.floaters:
                self._render_floater(surface, floater)

    def _text(
        self,
        surface: pygame.Surface,
        text: str,
        pos: tuple[int, int],
        color: tuple[int, int, int],
        size: int,
    ) -> None:
        """Draw text so the top of its letters sits at ``pos``."""
        text_renderer.draw_text(surface, text, pos, color=color, size=size)

    def _text_width(self, text: str, size: int) -> int:
        """Return the drawn width of ``text`` at ``size``."""
        return text_renderer.text_width(text, size)

    def _name_color(
        self, combatant: Combatant, hp: int, active_id: str | None
    ) -> tuple[int, int, int]:
        """Gray when down, yellow on their turn, white otherwise."""
        if hp <= 0:
            return ColorSettings.GRAY
        if combatant.id == active_id:
            return ColorSettings.YELLOW
        return ColorSettings.WHITE

    def _shake_offset(self, actor: _Actor) -> int:
        """Return the sideways jolt for a fighter who was just hit."""
        if actor.shake <= 0:
            return 0
        fade = actor.shake / Stage.SHAKE_SECONDS
        return round(
            math.sin(actor.shake * Stage.SHAKE_SPEED) * Stage.SHAKE_PIXELS * fade
        )

    def _lunge_amount(self, actor: _Actor) -> float:
        """Return 0..1..0 over the course of a lunge."""
        if actor.lunge <= 0:
            return 0.0
        return math.sin(math.pi * (1 - actor.lunge / Stage.LUNGE_SECONDS))

    def _flashing(self, actor: _Actor) -> bool:
        """Return True on the lit frames of a hit fighter's flash."""
        return (
            actor.flash > 0
            and int(actor.flash * Stage.FLASH_BLINK_HZ * 2) % 2 == 0
        )

    def _render_bar(
        self,
        surface: pygame.Surface,
        pos: tuple[int, int],
        actor: _Actor,
    ) -> None:
        """Draw an HP bar. It turns red when HP is low."""
        x, y = pos
        frame = pygame.Rect(x, y, Stage.BAR_WIDTH, Stage.BAR_HEIGHT)
        pygame.draw.rect(surface, Stage.COLOR_BAR_BACK, frame)
        # Extra HP past full (Kailo's meal) fills the bar, no further.
        share = min(1.0, actor.bar_hp / max(1, actor.combatant.max_hp))
        if share > 0:
            color = (
                Stage.COLOR_BAR_LOW
                if share < Stage.BAR_LOW_SHARE
                else Stage.COLOR_BAR
            )
            inner = frame.inflate(-2, -2)
            inner.width = max(1, round(inner.width * share))
            pygame.draw.rect(surface, color, inner)
        pygame.draw.rect(surface, ColorSettings.WHITE, frame, 1)

    @staticmethod
    def render_pip_row(
        surface: pygame.Surface,
        pos: tuple[int, int],
        lit: int,
        color: tuple[int, int, int],
        count: int = BattleSettings.MANA_CAP,
    ) -> None:
        """Draw ``count`` small pips from ``pos``, the first ``lit`` in ``color``.

        Mana in debt (``lit`` below zero, after Wili, Frankie 11/1) lights that many in the warning color.
        """
        x, y = pos
        if lit < 0:
            lit, color = -lit, Stage.COLOR_DEBT
        for index in range(count):
            pygame.draw.rect(
                surface,
                color if index < lit else Stage.COLOR_PIP_OFF,
                (x + index * (Stage.PIP_WIDTH + Stage.PIP_GAP), y,
                 Stage.PIP_WIDTH, Stage.PIP_HEIGHT),
            )

    def _render_pips(
        self, surface: pygame.Surface, pos: tuple[int, int], mana: int
    ) -> None:
        """Draw a fighter's mana: seven pips, one lit per point."""
        self.render_pip_row(surface, pos, mana, Stage.COLOR_MANA)

    def _render_cursor(
        self, surface: pygame.Surface, tip: tuple[int, int], down: bool
    ) -> None:
        """Draw the target arrow with its point at ``tip``, pulsing bright and dim."""
        x, y = tip
        s = Stage.CURSOR_SIZE
        points = (
            [(x, y), (x - s, y - s), (x + s, y - s)]
            if down
            else [(x, y), (x - s, y - s), (x - s, y + s)]
        )
        pygame.draw.polygon(surface, text_renderer.pointer_color(), points)
        pygame.draw.polygon(surface, ColorSettings.BLACK, points, 1)

    def _render_enemy(
        self,
        surface: pygame.Surface,
        actor: _Actor,
        hp: int,
        active_id: str | None,
        targeted: bool,
    ) -> None:
        """Draw one monster."""
        cx, ground = actor.home
        gone = (
            actor.fallen_for is not None
            and actor.fallen_for >= Stage.FADE_SECONDS
        )
        height = (
            actor.sprite.get_height()
            if actor.sprite is not None
            else Stage.PLACEHOLDER_SIZE
        )
        if not gone:
            self._render_enemy_body(surface, actor)
        if targeted:
            self._render_cursor(
                surface, (cx, ground - height - Stage.CURSOR_GAP), down=True
            )

        # A monster is only its picture (D-458): no name (the window shows it
        # while it is aimed at) and no status words. A few statuses show as
        # small icons floating over it (Frankie, 11/4).
        if not gone and actor.fallen_for is None:
            box = self._visible_box(actor)
            if actor.burst is not None:
                render_stance_burst(surface, box, actor.burst)
            for hit in actor.hits:
                render_hit_splash(surface, box.center, hit)
            self._render_status_icons(surface, actor, box)

    def _render_enemy_body(
        self, surface: pygame.Surface, actor: _Actor
    ) -> None:
        """Draw a monster's shadow and picture, with any motion applied."""
        cx, ground = actor.home
        if actor.sprite is None:
            size = Stage.PLACEHOLDER_SIZE
            image = pygame.Surface((size, size), pygame.SRCALPHA)
            image.fill(Stage.COLOR_PLACEHOLDER)
            pygame.draw.rect(image, ColorSettings.WHITE, image.get_rect(), 1)
            flash_image = image
        else:
            image, flash_image = actor.sprite, actor.flash_sprite
        width, height = image.get_size()

        alpha = 255
        sink = 0
        if actor.fallen_for is not None:
            done = min(1.0, actor.fallen_for / Stage.FADE_SECONDS)
            alpha = round(255 * (1 - done))
            sink = round(Stage.FADE_SINK_PIXELS * done)

        # Shadow first, so the monster stands on something.
        shadow_w = max(8, round(width * Stage.SHADOW_WIDTH_SHARE))
        shadow = pygame.Surface((shadow_w, Stage.SHADOW_HEIGHT), pygame.SRCALPHA)
        pygame.draw.ellipse(
            shadow,
            (0, 0, 0, round(Stage.SHADOW_ALPHA * alpha / 255)),
            shadow.get_rect(),
        )
        surface.blit(
            shadow, (cx - shadow_w // 2, ground - Stage.SHADOW_HEIGHT // 2)
        )

        standing = actor.fallen_for is None and actor.combatant.id in self._floating
        bob = (
            round(
                math.sin(self._clock * Stage.BOB_SPEED + actor.bob_phase)
                * Stage.BOB_PIXELS
            )
            if standing
            else 0
        )
        x = cx - width // 2 + self._shake_offset(actor)
        # Stand on the feet, not on the picture's edge: the empty rows under
        # a monster (seven under the boar) made it float (Frankie, 10/18).
        feet = image.get_bounding_rect().bottom or height
        y = (
            ground - feet + Stage.FEET_SINK + bob + sink
            + round(self._lunge_amount(actor) * Stage.LUNGE_PIXELS)
        )
        picture = (
            flash_image if self._flashing(actor) and flash_image is not None
            else image
        )
        if picture is not flash_image and actor.burst is not None and actor.burst.pulse and self._stance_lit(actor):
            picture = self._stance_tinted(actor, image, actor.burst.element)
        if alpha < 255:
            picture = picture.copy()
            picture.set_alpha(alpha)
        surface.blit(picture, (x, y))

    def _stance_lit(self, actor: _Actor) -> bool:
        """Return True on the lit beats of a stance switch's pulse (Frankie, 11/4)."""
        return int(actor.burst.age * Stage.STANCE_GLOW_HZ * 2) % 2 == 0

    def _stance_tinted(self, actor: _Actor, image: pygame.Surface, element: str) -> pygame.Surface:
        """Return ``image`` washed in ``element``'s color, made once per monster and element."""
        tinted = actor.stance_sprites.get(element)
        if tinted is None:
            color = ColorSettings.ELEMENT_COLORS[element]  # Fire red, nature green, as everywhere.
            tinted = image.copy()
            # Toward the element's color, then lifted, so it reads on any picture.
            tinted.fill(color, special_flags=pygame.BLEND_RGB_MULT)
            tinted.fill(tuple(c * 3 // 5 for c in color), special_flags=pygame.BLEND_RGB_ADD)
            actor.stance_sprites[element] = tinted
        return tinted

    def enemy_center(self, combatant_id: str) -> tuple[int, int] | None:
        """Return the middle of a monster's drawn picture, for Banish's circles (Frankie, 10/31)."""
        actor = self._actors.get(combatant_id)
        if actor is None or actor.combatant.is_party:
            return None
        return self._visible_box(actor).center

    def _visible_box(self, actor: _Actor) -> pygame.Rect:
        """Return the monster's drawn picture, empty edges cut, on the screen."""
        cx, ground = actor.home
        image = actor.sprite
        if image is None:
            size = Stage.PLACEHOLDER_SIZE
            return pygame.Rect(cx - size // 2, ground - size, size, size)
        box = image.get_bounding_rect()
        feet = box.bottom or image.get_height()
        left = cx - image.get_width() // 2
        top = ground - feet + Stage.FEET_SINK
        return box.move(left, top)

    def _render_status_icons(self, surface: pygame.Surface, actor: _Actor, box: pygame.Rect) -> None:
        """Draw a bobbing row of icons over a monster, one for each status it has that has one."""
        shown = [_STATUS_ICONS[name] for name in _STATUS_ICONS if name in actor.combatant.statuses]
        if not shown:
            return
        total = sum(width for width, _ in shown) + Stage.ICON_GAP * (len(shown) - 1)
        x = box.centerx - total // 2
        y = box.top - Stage.ICON_ROW_GAP + int(math.sin(self._clock * Stage.ICON_BOB_SPEED) * Stage.ICON_BOB_PIXELS)
        for width, draw in shown:
            draw(surface, x, y, self._clock)
            x += width + Stage.ICON_GAP

    def _reading(self, actor: _Actor, hp: int) -> tuple[list[Element], Element | None, str, int]:
        """A Seer's Shell reading's element icons, the one boxed as its stance, HP figure and drawn width.

        A two-stance monster shows both its elements, the stance it is in
        boxed in yellow, as the party's are (Frankie, 11/4, after Mark's
        Episode 3); any other shows its own, none boxed.
        """
        c = actor.combatant
        if len(c.pools) > 1:
            elements = list(dict.fromkeys(element for element, _ in c.pools))
            stance = c.pools[c.pool][0]
        else:
            elements, stance = list(dict.fromkeys(c.elements)), None
        figure = f"{max(0, min(hp, c.max_hp))}/{c.max_hp}"
        width = len(elements) * self._reading_pitch(stance) + (2 if stance is not None else 0) \
            + self._text_width(figure, FontSettings.SIZE_SMALL)
        return elements, stance, figure, width

    @staticmethod
    def _reading_pitch(stance: Element | None) -> int:
        """One reading icon to the next: wider with a stance box, so the boxes do not touch."""
        return Stage.PARTY_ICON_PITCH if stance is not None else Stage.READING_ICON_PITCH

    def _reading_left(self, actor: _Actor, hp: int) -> int:
        """Where a monster's reading starts, centred under it."""
        return actor.home[0] - self._reading(actor, hp)[3] // 2

    def _render_reading(self, surface: pygame.Surface, actor: _Actor, hp: int, row: int = 0) -> int:
        """Draw what a Seer's Shell read, under the monster's feet (Frankie, 10/28).

        Its element icons, then its HP as narrated, so the figure drops as
        the hits are told, and under the HP its mana as the party's is
        shown, seven pips (Frankie, 10/28). The icons are read from its
        elements each frame, so a monster that changes stance shows its new
        one. Returns the reading's right edge.
        """
        elements, stance, figure, width = self._reading(actor, hp)
        x = actor.home[0] - width // 2
        y = actor.home[1] + Stage.READING_DY + row * Stage.READING_ROW_PITCH
        size = Stage.PARTY_ICON_SIZE
        for element in elements:
            icon = _small_element_icon(element.value, size)
            if icon is not None:
                surface.blit(icon, (x + (1 if stance is not None else 0), y))
            if element is stance:
                pygame.draw.rect(surface, ColorSettings.YELLOW, pygame.Rect(x, y - 1, size + 2, size + 2), 1)
            x += self._reading_pitch(stance)
        if stance is not None:
            x += 2  # A gap, so the box does not touch the HP figure.
        text_renderer.draw_text(
            surface, figure, (x, y), color=ColorSettings.WHITE, size=FontSettings.SIZE_SMALL,
            glow=Stage.COLOR_READING_EDGE, glow_radius=1, glow_alpha=255,
        )
        # A dark edge round the pips, as the figure has, so they read on grass.
        pips_y = y + Stage.READING_PIPS_DY
        pips_w = BattleSettings.MANA_CAP * (Stage.PIP_WIDTH + Stage.PIP_GAP) - Stage.PIP_GAP
        pygame.draw.rect(surface, Stage.COLOR_READING_EDGE, (x - 1, pips_y - 1, pips_w + 2, Stage.PIP_HEIGHT + 2))
        self._render_pips(surface, (x, pips_y), actor.mana)
        return actor.home[0] - width // 2 + width

    @staticmethod
    def turn_bar_rect(entries: int) -> pygame.Rect | None:
        """Return the turn order bar's frame for ``entries`` pictures, as many as fit, or None."""
        pitch = Stage.TURN_ICON_SIZE + 1
        bottom = ScreenSettings.HEIGHT - UISettings.TEXT_BOX_HEIGHT - 2
        count = min(entries, (bottom - Stage.TURN_BAR_Y - 2) // pitch)
        if count <= 0:
            return None
        return pygame.Rect(
            Stage.TURN_BAR_X, Stage.TURN_BAR_Y,
            Stage.TURN_STRIPE + Stage.TURN_ICON_SIZE + 3, count * pitch + 1,
        )

    def party_row_rect(self, member_id: str) -> pygame.Rect | None:
        """Return a member's row in the HUD, icons to HP figure, mana pips included; None if not shown."""
        actor = self._actors.get(member_id)
        if actor is None:
            return None
        x, y = actor.home
        return pygame.Rect(x - 2, y - 3, ScreenSettings.WIDTH - x - 2, Stage.PARTY_ROW_PITCH)

    def stance_icons_rect(self, member_id: str) -> pygame.Rect | None:
        """Return the area of a member's element icons, the stance's boxed in yellow; None if not shown."""
        actor = self._actors.get(member_id)
        if actor is None:
            return None
        x, y = actor.home
        return pygame.Rect(x - 2, y - 3, Stage.PARTY_ICON_PITCH + Stage.PARTY_ICON_SIZE + 4,
                           Stage.PARTY_ICON_SIZE + 6)

    def _render_party_row(
        self,
        surface: pygame.Surface,
        actor: _Actor,
        hp: int,
        active_id: str | None,
        targeted: bool,
        picking: bool = False,
    ) -> None:
        """Draw one party member's row: first name, HP bar, HP.

        The name is yellow on their turn, red while they are being hit,
        the status colour while something is on them, gray when down.
        """
        c = actor.combatant
        hp = max(0, min(hp, c.max_hp))
        x = actor.home[0] + self._shake_offset(actor)
        y = actor.home[1] - round(
            self._lunge_amount(actor) * Stage.PARTY_HOP_PIXELS
        )
        if hp > 0 and self._flashing(actor):
            color = Stage.COLOR_HURT_NAME
        elif hp > 0 and c.id != active_id and status_labels(c):
            color = Stage.COLOR_STATUS
        else:
            color = self._name_color(c, hp, active_id)
        if picking:
            if targeted:
                text_renderer.draw_pointer(
                    surface,
                    (x + Stage.PARTY_NAME_DX - Stage.PICK_CURSOR_GAP, y + FontSettings.LETTER_WIDTH // 2),
                    ColorSettings.YELLOW,
                )
        else:
            self._render_party_icons(surface, c, x, y)
        # Tawiri's spirit goes by its own name.
        name = (c.name if c.summon_turns else short_name(c.id))[:Stage.PARTY_NAME_CHARS]
        # A letter with a blank column on its left (the T) is pulled back so every name starts in one column.
        bearing = text_renderer.render_line(name, color, FontSettings.SIZE_BODY).get_bounding_rect().left
        self._text(surface, name, (x + Stage.PARTY_NAME_DX - bearing, y), color, FontSettings.SIZE_BODY)
        # The bar is centred on the row's letters.
        bar_y = y + (FontSettings.LETTER_WIDTH - Stage.BAR_HEIGHT) // 2
        self._render_bar(surface, (x + Stage.PARTY_BAR_DX, bar_y), actor)
        if hp > 0:
            self._render_pips(
                surface, (x + Stage.PARTY_BAR_DX, y + Stage.PARTY_PIPS_DY), actor.mana
            )
        self._text(
            surface, str(round(actor.bar_hp)), (x + Stage.PARTY_FIGURES_DX, y),
            # Gray when down, yellow while a meal's extra HP holds it past full.
            ColorSettings.GRAY if hp <= 0 else ColorSettings.YELLOW if actor.bar_hp > c.max_hp else ColorSettings.WHITE,
            FontSettings.SIZE_SMALL,
        )

    def _render_party_icons(
        self, surface: pygame.Surface, c: Combatant, x: int, y: int
    ) -> None:
        """Draw a member's two element icons, the stance's boxed in yellow (D-453)."""
        size = Stage.PARTY_ICON_SIZE
        for index, element in enumerate(c.elements):
            icon = _small_element_icon(element.value, size)
            left = x + index * Stage.PARTY_ICON_PITCH
            if icon is not None:
                surface.blit(icon, (left + 1, y))
            if element is c.stance_element:
                pygame.draw.rect(
                    surface, ColorSettings.YELLOW,
                    pygame.Rect(left, y - 1, size + 2, size + 2), 1,
                )

    def _render_floater(
        self, surface: pygame.Surface, floater: _Floater
    ) -> None:
        """Draw one rising number with a dark edge so it reads anywhere."""
        progress = floater.age / Stage.FLOAT_SECONDS
        # Ease out: quick at first, slowing as it rises.
        rise = floater.rise * (1 - (1 - progress) ** 2)
        drift = 0.0
        if floater.vx is not None:
            # A knocked-out number: thrown, then falling.
            t = floater.age
            drift = floater.vx * t
            rise = -(floater.vy * t + Stage.SPLASH_GRAVITY * t * t / 2)
        elif floater.bounce:
            # One hop up and back down, then still until it fades.
            hop = min(1.0, floater.age / Stage.BOUNCE_SECONDS)
            rise = Stage.BOUNCE_PIXELS * 4 * hop * (1 - hop)
        body = text_renderer.render_line(
            floater.text, floater.color, FontSettings.SIZE_BODY
        )
        edge = text_renderer.render_line(
            floater.text, ColorSettings.BLACK, FontSettings.SIZE_BODY
        )
        fade_from = 1 - Stage.FLOAT_FADE_SHARE
        alpha = (
            255 if progress < fade_from
            else round(255 * (1 - (progress - fade_from) / Stage.FLOAT_FADE_SHARE))
        )
        x = round(floater.x + drift - body.get_width() / 2)
        y = round(floater.y - rise) - text_renderer.ink_top(FontSettings.SIZE_BODY)
        edge.set_alpha(alpha)
        body.set_alpha(alpha)
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            surface.blit(edge, (x + dx, y + dy))
        surface.blit(body, (x, y))
