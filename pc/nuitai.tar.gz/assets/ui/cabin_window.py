"""What is seen through the order window in the Meialana's cabin (Frankie, 11/26): a sea and sky with drifting
clouds and moving water, not two flat blues.

The pictures are PixelLab's (``tools/make_cabin.py``). On the Super Nintendo this is a second background layer
behind the wall's hole: the sea's rows each scroll at their own speed (a per-line scroll), the sky stands
still, and the clouds slide along it. Everything moves by whole pixels.
"""

from __future__ import annotations

import os

import pygame

from settings import AssetPaths, CabinSettings

_PICTURES: dict = {}


def _picture(name: str) -> pygame.Surface:
    if name not in _PICTURES:
        _PICTURES[name] = pygame.image.load(os.path.join(AssetPaths.BUILDINGS_DIR, name + ".png"))
    return _PICTURES[name]


def rect(x: int, y: int) -> pygame.Rect:
    """The window's opening, with the cabin picture's top left at ``(x, y)``."""
    return pygame.Rect(CabinSettings.WINDOW).move(x, y)


def draw(surface: pygame.Surface, x: int, y: int, ticks: int) -> None:
    """Draw the view into the window of the cabin picture whose top left is ``(x, y)``, ``ticks``
    milliseconds into the game."""
    opening = rect(x, y)
    sea = _picture("cabin_sea")
    seconds = ticks / 1000
    before = surface.get_clip()
    surface.set_clip(opening.clip(before))
    for row in range(opening.height):
        speed = 0.0
        if row >= CabinSettings.HORIZON:
            # Nearer water passes quicker, and each row at its own pace, so it ripples instead of sliding as one.
            speed = CabinSettings.SEA_SPEEDS[(row - CabinSettings.HORIZON) % len(CabinSettings.SEA_SPEEDS)]
        shift = int(seconds * speed) % sea.get_width()
        for left in (opening.x - shift, opening.x - shift + sea.get_width()):
            surface.blit(sea, (left, opening.y + row), pygame.Rect(0, row, sea.get_width(), 1))
    for name, start, top, speed in CabinSettings.CLOUDS:
        cloud = _picture(name)
        # Off the right edge, a cloud comes back on at the left.
        span = opening.width + cloud.get_width()
        left = (start + int(seconds * speed)) % span - cloud.get_width()
        surface.blit(cloud, (opening.x + left, opening.y + top))
    surface.set_clip(before)
