"""Soft edges: a sand tile pushes ragged grass in and wears a wet lip where the sea touches it.

The tile pack has flat squares, so a beach used to be a staircase. Here a
sand tile looks at its eight neighbors and draws, over the sand, the tile
numbered by which of them are grass and which are water, from the
sheets ``tools/make_edges.py`` draws in ``tiles/edges/``. No room file
names an edge. The game and the Workshop both draw through here.

    Ponds and rivers (Frankie, 10/30) work the same way with
``tools/make_fresh_edges.py``'s sheets: a grass tile gets water pushed into
it with a ragged rim, a wet lip and pale shallows, and a water tile gets
a few shallows pixels along the grass. Only grass makes them: where water
meets sand the sea's tide above is the only edge, so nothing doubles.
"""

from __future__ import annotations

import os
import sys
from array import array

import pygame

from settings import AssetPaths, GridSettings, OverworldSettings
from ui.shore import NEIGHBORS, WATER

GRASS = (OverworldSettings.FLOOR_CHAR, OverworldSettings.WALL_CHAR, OverworldSettings.STUMP_CHAR)
SAND = OverworldSettings.SAND_CHAR
PATH = OverworldSettings.PATH_CHAR

TIDE_SECONDS = 1.1                 # one step of the tide; a whole cycle is about six and a half seconds
TIDE_STEPS = (0, 1, 2, 3, 2, 1)    # which sea sheet, in turn: in, in, in, out, out, out
SEA_SHEETS = tuple(f"sea_onto_sand_{n}.png" for n in range(4))

RIPPLE_SECONDS = 0.9               # one step of a pond's ripple, a gentle swap of four sheets
FRESH_LAND = (OverworldSettings.FLOOR_CHAR,) + tuple(
    char for char, under in OverworldSettings.TILE_UNDER.items() if under == OverworldSettings.FLOOR_CHAR)

_SHEETS: dict[str, pygame.Surface] = {}
_PICTURES: dict[tuple[str, int, str], pygame.Surface | None] = {}


def _mask(grid, col: int, row: int, chars: tuple[str, ...]) -> int:
    """Which of the eight neighbors are one of ``chars``, one bit each."""
    mask = 0
    for bit, (dx, dy) in enumerate(NEIGHBORS):
        c, r = col + dx, row + dy
        if 0 <= r < len(grid) and 0 <= c < len(grid[r]) and grid[r][c] in chars:
            mask |= 1 << bit
    return mask


# The sheets are drawn in one blue-green: its rim, middle and pale shallows, and the sea-onto-sand tide's two darks.
_SHEET_COLORS = {"rim": (64, 168, 168), "mid": (112, 208, 200), "pale": (152, 216, 200),
                 "dark": (24, 88, 104), "tide": (40, 128, 136)}


def _tones(char: str) -> dict[tuple[int, int, int], tuple[int, int, int]]:
    """The sheets' blue-greens mapped to ``char``'s own water: every water's bank and shallows wear its own
    tones, a spring's and a pond's fresh and the sea's salt (Frankie, 11/16)."""
    base = OverworldSettings.WATER_COLORS[char]

    def toward(color, k):
        return tuple(int(c + (255 - c) * k) if k > 0 else int(c * (1 + k)) for c in color)

    return {_SHEET_COLORS["rim"]: base, _SHEET_COLORS["mid"]: toward(base, 0.35),
            _SHEET_COLORS["pale"]: toward(base, 0.55), _SHEET_COLORS["dark"]: toward(base, -0.45),
            _SHEET_COLORS["tide"]: toward(base, -0.2)}


def _picture(sheet: str, mask: int, water: str = OverworldSettings.WATER_CHAR) -> pygame.Surface | None:
    key = (sheet, mask, water)
    if key not in _PICTURES:
        if sheet not in _SHEETS:
            path = os.path.join(AssetPaths.TILES_DIR, "edges", sheet)
            _SHEETS[sheet] = pygame.image.load(path)
        size = GridSettings.TILE_SIZE
        picture = pygame.Surface((size, size), pygame.SRCALPHA)
        picture.blit(_SHEETS[sheet], (0, 0), pygame.Rect((mask % 16) * size, (mask // 16) * size, size, size))
        if sys.byteorder == "little":
            # The same recolor, a whole picture at once (a pixel at a time in Python hitched the browser
            # every time a new shore shape came on screen): each pixel is one number, red lowest, alpha top.
            swap = {old[0] | old[1] << 8 | old[2] << 16: new[0] | new[1] << 8 | new[2] << 16
                    for old, new in _tones(water).items()}
            pixels = array("I", pygame.image.tobytes(picture, "RGBA"))
            pixels = array("I", [(v & 0xFF000000) | swap[v & 0xFFFFFF] if v >> 24 and v & 0xFFFFFF in swap else v
                                 for v in pixels])
            picture = pygame.image.frombytes(pixels.tobytes(), (size, size), "RGBA")
        else:
            for old, new in _tones(water).items():
                for x in range(size):
                    for y in range(size):
                        if tuple(picture.get_at((x, y)))[:3] == old and picture.get_at((x, y))[3]:
                            picture.set_at((x, y), (*new, picture.get_at((x, y))[3]))
        _PICTURES[key] = picture
    return _PICTURES[key]


def draw(surface: pygame.Surface, grid, col: int, row: int, at: tuple[int, int]) -> None:
    """Draw the edges over a sand tile already drawn at ``at``."""
    if grid[row][col] not in (SAND, PATH):
        return
    grass = _mask(grid, col, row, GRASS)
    if grass:
        surface.blit(_picture("grass_into_path.png" if grid[row][col] == PATH else "grass_into_sand.png", grass), at)
    # Each kind of water is drawn from its own neighbors in its own tones, so a tile between a pond and the sea
    # never gives one the other's (Frankie, 11/16). Only salt water's edge moves like a tide.
    for char, near in _KINDS:
        sea = _mask(grid, col, row, near)
        if sea:
            step = int(pygame.time.get_ticks() / 1000 / TIDE_SECONDS) % len(TIDE_STEPS) if char in SALT else 0
            surface.blit(_picture(SEA_SHEETS[TIDE_STEPS[step]], sea, char), at)


SALT = (OverworldSettings.WATER_CHAR,)
FRESH = (OverworldSettings.FRESH_CHAR, OverworldSettings.SPRING_CHAR)
_KINDS = ((OverworldSettings.WATER_CHAR, SALT), (OverworldSettings.FRESH_CHAR, FRESH))   # tones, the tiles that count


def _ripple(moving: bool = True) -> int:
    """Which of the four ripple sheets: cycling for salt water, always the first for fresh and spring (11/16)."""
    return int(pygame.time.get_ticks() / 1000 / RIPPLE_SECONDS) % 4 if moving else 0


def draw_bank(surface: pygame.Surface, grid, col: int, row: int, at: tuple[int, int]) -> None:
    """Draw the water's edge over a grass tile already drawn at ``at``."""
    if grid[row][col] not in FRESH_LAND:
        return
    rim = "ab"[(col * 5 + row * 3) % 2]
    for char, near in _KINDS:
        water = _mask(grid, col, row, near)
        if water:
            sheet = f"water_into_grass_{rim}{_ripple(char in SALT)}.png"
            surface.blit(_picture(sheet, water, char), at)


def draw_shallows(surface: pygame.Surface, grid, col: int, row: int, at: tuple[int, int]) -> None:
    """Draw pale shallows over a water tile already drawn at ``at``, along its grass."""
    grass = _mask(grid, col, row, FRESH_LAND)
    if grass:
        surface.blit(_picture(f"shallows_{_ripple(grid[row][col] in SALT)}.png", grass,
                                OverworldSettings.WATER_CHAR if grid[row][col] in SALT else OverworldSettings.FRESH_CHAR), at)
