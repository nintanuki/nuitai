"""Draw the parry meter across the whole bottom area (Frankie, 10/30; three lanes 11/19).

A black well in the meter's two ring border with cut corners and a shaded yellow zone near its left
end, in three lanes, Y on top, X in the middle, A at the bottom, divided by thin lines. Each stroke is
its button, as large as the stroke box's, sliding left along its lane. The meter takes the command and
party windows together, in one rounded window. A perfect press floats "Parried!" up from the meter (Frankie, 11/10).
"""

from __future__ import annotations

import pygame

from settings import BlockSettings, ColorSettings, FontSettings
from systems.timed_block import BlockMeter
from ui import text_renderer

_BORDER = 2  # Frame thickness: an outer and an inner ring.
_WELL = (6, 6, 10)
_SHINE = (36, 36, 48)
_RING_OUTER = (120, 128, 150)
_RING_INNER = (232, 236, 244)
_BEVEL = (168, 176, 196)
# The zone, one color per row from top to bottom, with a pale left edge and a dark right edge.
_ZONE_ROWS = ((255, 244, 150), (255, 226, 80), (255, 206, 40), (250, 190, 24), (240, 170, 16),
              (226, 150, 12), (210, 132, 8), (190, 112, 6), (170, 96, 4), (150, 80, 4))
_ZONE_EDGE_LEFT = (255, 250, 200)
_ZONE_EDGE_RIGHT = (150, 90, 4)


_DIVIDER = (58, 64, 84)   # Between the well's black and the frame's grey ring.
_KIND_BUTTON = {"light": "Y", "medium": "X", "strong": "A"}


def draw_button(surface: pygame.Surface, button: str, x: int, y: int) -> None:
    """Draw a face button exactly as the stroke box does (radius 7, a rim row beneath), centered on ``x``."""
    from ui.dance_meter import _FACES
    r = BlockSettings.BUTTON_RADIUS
    size = FontSettings.SIZE_BODY
    rim, face = _FACES[button]
    pygame.draw.circle(surface, rim, (x, y + 1), r + 1)
    pygame.draw.circle(surface, face, (x, y), r)
    width = text_renderer.text_width(button, size)
    nudge = -1 if button == "Y" else 0   # Y sits a pixel left in its button, as in the stroke box.
    text_renderer.draw_text(surface, button, (x - width // 2 + 1 + nudge, y - 3), (255, 255, 255), size=size)


def draw_frame(surface: pygame.Surface, frame: pygame.Rect) -> pygame.Rect:
    """Draw the empty meter in ``frame`` and return its well; Paddle's time bar uses it too.

    A black well with a shine along its top, two rings with their corner pixels
    cut, and a lighter bevel under the well.
    """
    well = frame.inflate(-2 * _BORDER, -2 * _BORDER)
    pygame.draw.rect(surface, _WELL, well)
    pygame.draw.line(surface, _SHINE, well.topleft, (well.right - 1, well.top))
    for inset, color in ((0, _RING_OUTER), (1, _RING_INNER)):
        ring = frame.inflate(-2 * inset, -2 * inset)
        l, t, r, b = ring.left, ring.top, ring.right - 1, ring.bottom - 1
        for start, end in (((l + 1, t), (r - 1, t)), ((l + 1, b), (r - 1, b)),
                           ((l, t + 1), (l, b - 1)), ((r, t + 1), (r, b - 1))):
            pygame.draw.line(surface, color, start, end)
    pygame.draw.line(surface, _BEVEL, (well.left, well.bottom), (well.right - 1, well.bottom))
    return well


def draw_shaded(surface: pygame.Surface, well: pygame.Rect, left: int, width: int) -> None:
    """Fill ``width`` columns of ``well`` from ``left`` in the zone's shaded yellow, edges and all."""
    if width <= 0:
        return
    for row in range(well.height):
        color = _ZONE_ROWS[row * len(_ZONE_ROWS) // well.height]
        pygame.draw.line(surface, color, (left, well.top + row), (left + width - 1, well.top + row))
    pygame.draw.line(surface, _ZONE_EDGE_LEFT, (left, well.top), (left, well.bottom - 1))
    if width > 1:
        pygame.draw.line(surface, _ZONE_EDGE_RIGHT, (left + width - 1, well.top), (left + width - 1, well.bottom - 1))


class BlockMeterView:
    """The meter, its "Parried!" pop-ups, and where they are drawn."""

    def __init__(self, meter: BlockMeter) -> None:
        """Wrap the ``meter`` whose bars are drawn."""
        self.meter = meter
        self._pops: list[float] = []  # Ages of the "Parried!"s rising.

    def parried(self) -> None:
        """Start a "Parried!" rising from the meter."""
        self._pops.append(0.0)

    def update(self, dt: float) -> None:
        """Age the pop-ups, dropping the ones that are done."""
        self._pops = [age + dt for age in self._pops if age + dt < BlockSettings.POP_SECONDS]

    def render(self, surface: pygame.Surface, window: pygame.Rect) -> None:
        """Draw the meter centered in ``window``, the whole bottom area, its window already drawn."""
        length = BlockSettings.LENGTH
        height = BlockSettings.meter_height()
        frame = pygame.Rect(0, 0, length + 2 * _BORDER, height + 2 * _BORDER)
        frame.center = window.center
        well = draw_frame(surface, frame)
        # The well's shine line would read as a stray line above the top lane.
        pygame.draw.line(surface, _WELL, well.topleft, (well.right - 1, well.top))
        meter = self.meter
        draw_shaded(surface, well, well.left + meter.zone_left, meter.zone)
        lane = BlockSettings.lane_height()
        for i in (1, 2):
            y = well.top + i * lane + (i - 1)
            pygame.draw.line(surface, _DIVIDER, (well.left, y), (well.right - 1, y))
        old_clip = surface.get_clip()
        surface.set_clip(well)
        for red in meter.bars:
            # A caught stroke is gone; one pressed too early keeps sliding until it lands.
            if red.result in ("catch", "perfect"):
                continue
            # The button's rows run from y - r (face top) to y + r + 2 (rim bottom): centered in its lane
            # with the same air above and below in every lane.
            top = well.top + BlockSettings.LANES.index(red.kind) * (lane + 1) + BlockSettings.LANE_PAD
            draw_button(surface, _KIND_BUTTON[red.kind], well.left + round(red.x), top + BlockSettings.BUTTON_RADIUS)
        surface.set_clip(old_clip)
        bar = frame
        for age in self._pops:
            progress = age / BlockSettings.POP_SECONDS
            text = "Parried!"
            width = text_renderer.text_width(text, FontSettings.SIZE_BODY)
            x = bar.centerx - width // 2
            top = bar.top - 14 - round(BlockSettings.POP_RISE * progress)
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                text_renderer.draw_text(
                    surface, text, (x + dx, top + dy), color=ColorSettings.BLACK, size=FontSettings.SIZE_BODY)
            text_renderer.draw_text(
                surface, text, (x, top), color=ColorSettings.WHITE, size=FontSettings.SIZE_BODY)
