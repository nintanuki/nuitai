"""The swirl into a fight (Frankie, 11/9; ``FightSwirlSettings`` turns it off).

It is the opening's spiral (``ui/title_painter.py``), in two halves.

Closing: over a picture of the map taken as the fight begins. The map fades to the
title's ocean blue, the spiral grows and turns, then everything goes dark.

Opening: the fight is drawn under black, and the spiral, spun back, cuts its arms
out of the black; the arms widen until the fight is whole.

``BattleScene`` plays it over its first moments, with its song already on (``arm``).
"""

from __future__ import annotations

import pygame

from settings import FightSwirlSettings as S
from settings import ScreenSettings
from ui import title_dawn as dawn
from ui import title_painter

_MIDDLE = (ScreenSettings.WIDTH // 2, ScreenSettings.HEIGHT // 2)


class FightSwirl:
    """The swirl over ``backdrop`` (the map as it stood)."""

    def __init__(self, backdrop: pygame.Surface) -> None:
        self.backdrop = backdrop
        self.time = 0.0
        self._spiral = title_painter.load_spiral()
        self._blue = pygame.Surface(backdrop.get_size())
        self._blue.fill(dawn.to_rgb(dawn.OCEAN_BLUE))

    @property
    def opening(self) -> bool:
        """True once the map is gone and the fight is coming through."""
        return self.time >= S.CLOSE_TIME

    @property
    def done(self) -> bool:
        return self.time >= S.CLOSE_TIME + S.OPEN_TIME

    def update(self, dt: float) -> None:
        self.time += dt

    def render_close(self, surface: pygame.Surface, t: float | None = None) -> None:
        """The map going to blue under the growing spiral, then dark; ``t`` 0 to 1 of the closing."""
        if t is None:
            t = min(1.0, self.time / S.CLOSE_TIME)
        surface.blit(self.backdrop, (0, 0))
        blue = min(1.0, t / S.BLUE_BY)
        if blue > 0:
            self._blue.set_alpha(round(255 * blue))
            surface.blit(self._blue, (0, 0))
        # The spiral grows, eased out as the title's does, and turns faster as it goes.
        grow = 1 - (1 - t) ** 2
        scale = S.START_SCALE + (S.END_SCALE - S.START_SCALE) * grow
        gray = round(31 * min(1.0, t / 0.35))
        title_painter.add_spiral(surface, self._spiral, S.SPIN * t * t, scale, gray, _MIDDLE)
        if t > S.DARK_FROM:
            dark = pygame.Surface(surface.get_size())
            dark.set_alpha(round(255 * (t - S.DARK_FROM) / (1 - S.DARK_FROM)))
            surface.blit(dark, (0, 0))

    def open_mask(self, t: float) -> pygame.Surface:
        """White where the fight shows, black where it is hidden; ``t`` 0 to 1 of the opening."""
        grow = t * (2 - t)
        scale = S.END_SCALE - (S.END_SCALE - S.OPEN_SCALE) * grow
        angle = -S.SPIN * (1 - t) ** 2 * S.OPEN_SPIN
        size = max(1, round(dawn.SPIRAL_SIZE * scale))
        arms = pygame.transform.rotate(pygame.transform.scale(self._spiral, (size, size)), -angle)
        mask = pygame.Surface(surface_size())
        mask.blit(arms, arms.get_rect(center=_MIDDLE))
        # The arms widen: blurred, then cut low and made solid white (the blur's faint edge counts).
        radius = round(1 + S.OPEN_WIDEN * t * t)
        for _ in range(2):
            mask = pygame.transform.box_blur(mask, max(1, radius // 2))
        for _ in range(4):
            mask.blit(mask, (0, 0), special_flags=pygame.BLEND_ADD)
        return mask

    def cover(self, surface: pygame.Surface, t: float | None = None) -> None:
        """Black over the fight already drawn on ``surface``, except through the arms; ``t`` 0 to 1 of the opening."""
        if t is None:
            t = min(1.0, (self.time - S.CLOSE_TIME) / S.OPEN_TIME)
        if t >= 1.0:
            return
        surface.blit(self.open_mask(t), (0, 0), special_flags=pygame.BLEND_MULT)


def surface_size() -> tuple[int, int]:
    return ScreenSettings.RESOLUTION


def arm(gm, battle) -> None:
    """Give ``battle`` the swirl over the screen as it is now, if it is on.

    Call this just before pushing the battle; the fight's own song starts
    on the push, so it plays under the swirl.
    """
    if not S.ENABLED:
        return
    picture = pygame.Surface(ScreenSettings.RESOLUTION)
    gm.scene_stack.render_all(picture)
    battle.swirl = FightSwirl(picture)
