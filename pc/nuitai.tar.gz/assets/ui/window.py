"""A window: a filled box in a frame (D-457).

Every window in the game is drawn here, so changing the look is one place.
A menu the cursor moves through takes the ocean frame; whatever pops up to tell
the player something the thin bamboo one (Frankie, 11/26; ``ui/frames.py``). The inside is deep ocean rather than
black (D-451), the way Final Fantasy VI fills its windows with blue,
tinted by Config's window color (``systems/config.py``). Outlines, flat boxes
(``fill`` None or a color) and boxes too small for the frame are a plain line
with rounded corners.
"""

from __future__ import annotations

import pygame

from settings import ColorSettings, FontSettings, UISettings
from systems import config
from ui import frames, text_renderer

# Gradient fills already drawn, keyed by size, radius and colours.
_FILLS: dict[tuple, pygame.Surface] = {}


def _gradient_fill(size: tuple[int, int], radius: int, alpha: int = 255) -> pygame.Surface:
    """Return a ``size`` box of ocean shading in Config's window color, corners cut round, ``alpha`` solid."""
    key = (size, radius, config.current.window, alpha)
    cached = _FILLS.get(key)
    if cached is not None:
        return cached
    width = size[0]
    fill = pygame.Surface(size, pygame.SRCALPHA)
    for y, color in enumerate(frames.water_colors(size[1])):
        pygame.draw.line(fill, color, (0, y), (width - 1, y))
    mask = pygame.Surface(size, pygame.SRCALPHA)
    pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=radius)
    fill.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    if alpha < 255:
        fill.fill((255, 255, 255, alpha), special_flags=pygame.BLEND_RGBA_MULT)
    _FILLS[key] = fill
    return fill


def draw_window(
    surface: pygame.Surface,
    rect: pygame.Rect,
    border: tuple[int, int, int] = ColorSettings.WHITE,
    fill: tuple[int, int, int] | None | str = "ocean",
    thickness: int = UISettings.TEXT_BOX_BORDER_THICKNESS,
    radius: int = UISettings.WINDOW_CORNER_RADIUS,
    see_through: bool = True,
    style: str = "ocean",
) -> None:
    """Draw a window over ``rect``: the framed ocean inside, or a fill and a plain border.

    Args:
        surface: Where to draw.
        rect: The window's outer edge.
        border: The border's colour; on an ocean window, one other than white tints the frame.
        fill: "ocean" for a framed window in Config's window color, a colour for a flat fill,
            or None to leave it see-through.
        thickness: A plain border's width in pixels (not used by a framed window).
        radius: How round a plain box's corners are, in pixels.
        see_through: True (the default) for the fill to take Config's Window opacity (Frankie, 11/19):
            over a scene the scene shows through, and a full-screen menu's windows sit on plain
            black. False for a solid fill; a window drawn over another window this frame is always solid. The border and the text are always solid; a flat
            colour fill is left as given.
        style: The frame of an "ocean" window: "ocean", or "bamboo" for what pops up to tell something.
    """
    # A window drawn over another window is solid, whatever the caller asked (Frankie, 11/19).
    if see_through and text_renderer.over_window(surface, rect):
        see_through = False
    alpha = config.window_alpha() if see_through else 255
    if fill == "ocean" and min(rect.size) >= frames.SMALLEST:
        water = _gradient_fill(rect.size, 0, alpha)
        surface.blit(frames.window(water, style, border), rect.topleft)
    else:
        if fill == "ocean":
            # Too small for the frame's corners (the tool wheel's boxes): a plain line.
            surface.blit(_gradient_fill(rect.size, radius, alpha), rect.topleft)
        elif fill is not None:
            pygame.draw.rect(surface, fill, rect, border_radius=radius)
        pygame.draw.rect(surface, border, rect, thickness, border_radius=radius)
    text_renderer.note_window(surface, rect)


def draw_popup(surface: pygame.Surface, rect: pygame.Rect, words: pygame.Rect, see_through: bool = True) -> None:
    """Draw a window that pops up to tell the player something: bamboo and flowers (Frankie, 11/26).

    A menu the cursor moves through takes ``draw_window``'s ocean frame instead.

    Args:
        surface: Where to draw.
        rect: The window's outer edge.
        words: The box what is written in it fills; the flowers keep off it.
        see_through: As for ``draw_window``.
    """
    draw_window(surface, rect, see_through=see_through, style="bamboo")
    frames.notice_flowers(surface, rect, words)


def draw_header(
    surface: pygame.Surface,
    label: str,
    help_lines: list[str] | tuple[str, ...] = (),
    corner: str | None = None,
    help_color: tuple[int, int, int] = ColorSettings.WHITE,
) -> None:
    """Draw a menu screen's whole window and Final Fantasy VI's top (Frankie, 10/23).

    The screen is one window; over its top left, a small box with
    ``label``, and under that the help window with up to two
    ``help_lines`` about what the cursor is on. ``corner``, the member
    the screen is about, sits at the top right. The list goes from
    ``UISettings.HEADER_LIST_TOP`` down.
    """

    size = FontSettings.SIZE_BODY
    draw_window(surface, surface.get_rect())
    label_rect = pygame.Rect(UISettings.HEADER_LABEL_RECT)
    help_rect = pygame.Rect(UISettings.HEADER_HELP_RECT)
    draw_window(surface, label_rect)
    draw_window(surface, help_rect)
    x = UISettings.HEADER_TEXT_X
    text_renderer.draw_text(surface, label, (x, label_rect.top + 8), color=ColorSettings.WHITE, size=size)
    if corner:
        text_renderer.draw_text(surface, corner, (label_rect.right + x, label_rect.top + 8),
                                color=ColorSettings.WHITE, size=size)
    for index, line in enumerate(help_lines[:2]):
        text_renderer.draw_text(surface, line, (x, help_rect.top + 8 + index * 16), color=help_color, size=size)


def help_wrap(text: str, width: int | None = None) -> list[str]:
    """``text`` wrapped to the help window's width (or ``width`` pixels), two lines at most.

    Longer text keeps as many whole sentences from the start as fit.
    """
    width = width or UISettings.HEADER_HELP_RECT[2] - 2 * UISettings.HEADER_TEXT_X
    font = text_renderer.get_font(FontSettings.SIZE_BODY)
    # A sentence ends at "!" or "?" too: Ama's "Fresh bait! The fish don't know..." was cut mid-sentence (11/8).
    sentences = text.replace(". ", ".\n").replace("! ", "!\n").replace("? ", "?\n").split("\n")
    while len(sentences) > 1 and len(text_renderer.wrap(" ".join(sentences), font, width)) > 2:
        sentences.pop()
    return text_renderer.wrap(" ".join(sentences), font, width)[:2]
