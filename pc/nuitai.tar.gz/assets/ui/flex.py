"""Flex-grow for one row of boxes (the field menu's Element grid, Frankie 11/13).

Every row is the same full width. With nothing hovered its slots share the width equally; with a slot
hovered it takes the width of its full entry and the others share what is left, never below ``smallest``.
"""

from __future__ import annotations


def flex_widths(total: int, count: int, hovered: int | None, natural: int, smallest: int) -> list[int]:
    """The widths of ``count`` boxes sharing ``total`` pixels, the one at ``hovered`` wanting ``natural``.

    The widths always add up to ``total``, so every row ends in the same place.
    """
    if count <= 0:
        return []
    if count == 1:
        return [total]
    if hovered is None or not 0 <= hovered < count:
        base = total // count
        return [base] * (count - 1) + [total - base * (count - 1)]
    others = count - 1
    rest = max(smallest * others, total - natural)
    rest = min(rest, total - smallest)            # never leave the hovered one under the smallest size
    share = rest // others
    widths = [share] * count
    widths[hovered] = total - share * others
    return widths
