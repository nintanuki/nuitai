"""Drawing the field menu's frame: the tabs, the party column, the bottom window, and small helpers.

The pages (``core/scenes/field_menu_pages.py``) draw the right side; this draws what is the same on every
tab. Everything is on the 256 by 224 screen and the 8 pixel font, the preview's measures
(``docs/design/party_menu_preview_ingame.py``).
"""

from __future__ import annotations

import os

import pygame

from core.factories import stance_numbers
from core.shared import by_id, short_name
from settings import ColorSettings, FontSettings, UISettings
from ui import text_renderer
from ui.window import draw_window
from utils import sprite_files
from utils.graphics import load_element_icon, load_party_sheet

SIZE = FontSettings.SIZE_BODY
WHITE, GRAY, CYAN, YELLOW = ColorSettings.WHITE, ColorSettings.GRAY, ColorSettings.LABEL_CYAN, ColorSettings.YELLOW
RED = ColorSettings.RED

# One color per tab (the mockup's), on its border and its word.
TAB_COLORS = {
    "Items": (240, 168, 48), "Element": (230, 90, 110), "Equip": (159, 196, 232), "Status": (92, 196, 106),
    "Party": (180, 139, 232), "Info": (60, 200, 200), "Config": (160, 164, 173),
}
ITEMS_C = TAB_COLORS["Items"]
ROW_H = 53                      # a fighter's row in the column
TOP = 30                        # under the tabs
BOTTOM = 190                    # the bottom window starts here
TAB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "ui", "tabs")

# ---- small drawing helpers ------------------------------------------------------------------


def text(surface: pygame.Surface, words: str, x: int, y: int, color=WHITE, right: bool = False) -> None:
    """Words with the top of their capitals at ``y``; ``right`` ends them at ``x``."""
    text_renderer.draw_text_at(surface, words, x, y, color, right, SIZE)


def width(words: str) -> int:
    return text_renderer.text_width(words, SIZE)


def hook(surface: pygame.Surface, tip_x: int, y: int) -> None:
    """The one hook, for a row of text whose letters start at ``y``; the words start 6 pixels right of ``tip_x``.

    Wherever it hangs beside text, its fishing line runs down the middle between the window's left border and the
    start of that text (Frankie, 11/13), so the line is seen and not lost along the border; the hook may cover a
    little of what is beside it.
    """
    point = (tip_x + 6, y + SIZE // 2)
    window = text_renderer._window_of(surface, point)
    if window is not None:
        cord = (window.left + point[0]) // 2
        tip_x = cord + 7        # the line ties on 3 pixels in from the sprite's left, the sprite 14 wide, its right at tip + 4
    text_renderer.draw_pointer(surface, (tip_x, y + SIZE // 2), YELLOW)


def box(surface: pygame.Surface, x: int, y: int, w: int, h: int, border=WHITE) -> None:
    draw_window(surface, pygame.Rect(x, y, w, h), border=border)


def more_arrow(surface: pygame.Surface, x: int, y: int) -> None:
    """The arrow at a list's bottom edge: there is more below."""
    if int(pygame.time.get_ticks() / 400) % 2 == 0:
        pygame.draw.polygon(surface, WHITE, [(x, y), (x + 8, y), (x + 4, y + 5)])


def dashed(surface: pygame.Surface, rect: pygame.Rect, color=WHITE) -> None:
    for x in range(rect.left, rect.right, 4):
        for y in (rect.top, rect.bottom - 1):
            surface.set_at((x, y), color)
    for y in range(rect.top, rect.bottom, 4):
        for x in (rect.left, rect.right - 1):
            surface.set_at((x, y), color)


# ---- the tabs -------------------------------------------------------------------------------

_TAB_IMAGES: dict[str, pygame.Surface] = {}


def tab_image(name: str, lit: bool) -> pygame.Surface:
    """The tab's 16 by 16 icon from ``assets/ui/tabs/<tab>.png``; an unlit tab's is the same at half brightness."""
    if name not in _TAB_IMAGES:
        path = os.path.join(TAB_DIR, f"{name.lower()}.png")
        if os.path.exists(path):
            _TAB_IMAGES[name] = pygame.image.load(path).convert_alpha()
        else:
            _TAB_IMAGES[name] = pygame.Surface((16, 16), pygame.SRCALPHA)
    image = _TAB_IMAGES[name]
    if lit:
        return image
    dim = image.copy()
    dim.fill((128, 128, 128, 255), special_flags=pygame.BLEND_RGBA_MULT)
    return dim


def draw_tabs(surface: pygame.Surface, active: str, lit: bool = False) -> None:
    """Seven tabs across the top: the open one shows its word beside its icon, the rest are narrow. The open
    tab's border is its own color (which tab is open); while the hook is on the tabs it hangs at the open
    tab's left, the one mark of where you are."""
    from core.scenes.field_menu_scene import TABS

    gap = 2
    on_w = 14 + 16 + 6 + width(active) + 8      # room at its left for the hook
    off_w = (256 - 2 * gap - on_w - gap * (len(TABS) - 1)) // (len(TABS) - 1)
    x = gap
    for name in TABS:
        on = name == active
        w = on_w if on else off_w
        rect = pygame.Rect(x, 2 if on else 5, w, 24 if on else 20)
        color = TAB_COLORS[name]
        draw_window(surface, rect, border=color if on else GRAY)
        if on:
            surface.blit(tab_image(name, True), (rect.left + 18, rect.centery - 8))
            text(surface, name, rect.left + 38, rect.centery - 4, color)
            if lit:
                hook(surface, rect.left + 8, rect.centery - 4)
        else:
            surface.blit(tab_image(name, False), (rect.centerx - 8, rect.centery - 8))
        x += w + gap


# ---- the party column -----------------------------------------------------------------------

_SPRITES: dict[str, pygame.Surface | None] = {}


def member_sprite(member_id: str) -> pygame.Surface | None:
    """The member's battle idle pose cropped to its pixels, or None when the game has none."""
    if member_id not in _SPRITES:
        sheet = load_party_sheet(f"{member_id}_idle")
        if sheet:
            frame = sheet[0][0]
            rect = frame.get_bounding_rect()
            _SPRITES[member_id] = frame.subsurface(rect).copy()
        else:
            _SPRITES[member_id] = None
    return _SPRITES[member_id]


class Layout:
    """The measures that follow from the widest sprite: the column, then the right side beside it."""

    def __init__(self, gm) -> None:
        widest = max((member_sprite(m.id).get_width() for m in gm.party.members[:3] if member_sprite(m.id)),
                     default=24)
        self.sprite_x = 4
        self.text_x = self.sprite_x + widest + 6
        self.col_w = self.text_x + 56 + 4        # room for "130/130"
        self.rx = self.col_w
        self.lx = self.rx + 14                   # words on the right start here; the hook sits left of them
        self.right = 250
        self.rw = 256 - self.rx


def row_y(index: int) -> int:
    return TOP + index * ROW_H


def draw_column(surface: pygame.Surface, lay: Layout, fighters: list, lit: int, hook_row: int | None = None,
                held: int | None = None) -> None:
    """A window per fighter: sprite, name, HP now over max, the two elements with the starting stance boxed,
    KO in red when down. The lit one has a white border; ``held`` is the one picked to swap, in yellow."""
    size = UISettings.ELEMENT_ICON_SIZE
    room = lay.col_w - lay.text_x - 4
    for index, member in enumerate(fighters):
        y = row_y(index)
        box(surface, 0, y, lay.col_w, ROW_H + 1, border=YELLOW if held == index else WHITE if index == lit else GRAY)
        sprite = member_sprite(member.id)
        if sprite is not None:
            surface.blit(sprite, (lay.sprite_x, y + (ROW_H - sprite.get_height()) // 2))
        else:
            pygame.draw.rect(surface, WHITE, (lay.sprite_x, y + 8, 16, 16), 1)
        down = member.current_hp <= 0
        text(surface, short_name(member.id), lay.text_x, y + 7, RED if down else WHITE)
        if down:
            text(surface, "KO", lay.col_w - 8, y + 7, RED, right=True)
        _, shown, top = stance_numbers(member)
        text(surface, f"{shown}/{top}", lay.text_x, y + 19)
        stances = by_id("characters").get(member.id, {}).get("stances", [])
        start = stances[member.stance]["element"] if stances and 0 <= member.stance < len(stances) else None
        for slot, element in enumerate(member.elements):
            icon = load_element_icon(element)
            ix = lay.text_x + 2 + slot * (size + 6)
            if icon is not None:
                surface.blit(icon, (ix, y + 31))
            if element == start:
                pygame.draw.rect(surface, YELLOW, (ix - 2, y + 29, size + 4, size + 4), 2, border_radius=2)
    if hook_row is not None and 0 <= hook_row < len(fighters):
        hook(surface, lay.text_x - 6, row_y(hook_row) + 12)


# ---- the bottom window ----------------------------------------------------------------------

def draw_bottom(surface: pygame.Surface, party, content, active: bool = True) -> None:
    """The full width window along the bottom. ``content`` is ("help", lines, color), ("money",) or
    ("bar", words, hook_index): what the hook is on, else the money."""
    box(surface, 0, BOTTOM, 256, 224 - BOTTOM)
    kind = content[0]
    if kind == "help":
        lines = content[1]
        color = content[2] if len(content) > 2 else WHITE
        for i, line in enumerate(lines[:2]):
            text(surface, line, 12, BOTTOM + 8 + i * 12, color)
    elif kind == "bar":
        words, at = content[1], content[2]
        for i, (word, x) in enumerate(zip(words, (28, 100, 186))):
            text(surface, word, x, BOTTOM + 13)
            if i == at and active:
                hook(surface, x - 6, BOTTOM + 13)
    elif kind == "status":
        _status_footer(surface, content[1], content[2])
    else:
        for name, x, number in (("kupang", 44, party.kupang), ("pule", 148, party.pule)):
            icon = load_element_icon(name)
            if icon is not None:
                surface.blit(icon, (x, BOTTOM + 9))
            text(surface, f"{number}", x + 22, BOTTOM + 13)


def _status_footer(surface: pygame.Surface, member, stat_row: int) -> None:
    """Status's bottom window: the Skill of the weapon type in hand, then the EXP to the next point of the stat
    under the hook, the Morrowind bar (``party_scene``)."""
    from core.scenes.party_scene import _STAT_ROWS, exp_points
    from core.shared import skill_for
    from systems import mastery
    from systems.battle import _GROWTH

    held = mastery.type_held(member.id, member.weapon)
    skill = skill_for(member.id, held) if held else None
    text(surface, "Skill", 12, BOTTOM + 8, GRAY)
    text(surface, skill["name"] if skill else "None", 60, BOTTOM + 8, WHITE if skill and not skill.get("off") else GRAY)
    key, label = _STAT_ROWS[stat_row]
    text(surface, "EXP to next", 140, BOTTOM + 8, GRAY)
    text_renderer.draw_text(surface, label, (12, BOTTOM + 20), size=SIZE, **ColorSettings.STAT_EDGE_STYLES[key])
    frame = pygame.Rect(120, BOTTOM + 18, 96, 12)
    full = int(_GROWTH["meter"])
    points = min(int(exp_points(member, key)), full)
    pygame.draw.rect(surface, (0, 0, 0), frame)
    inner = frame.inflate(-2, -2)
    inner.width = round(inner.width * points / full)
    if inner.width:
        pygame.draw.rect(surface, (150, 36, 24), inner)
    pygame.draw.rect(surface, (200, 164, 106), frame, 1)
    label_text = f"{points}/{full}"
    text(surface, label_text, frame.centerx - width(label_text) // 2, frame.top + 2, (240, 226, 192))
