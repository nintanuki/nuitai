"""The title's dawn on a quiet beach, as numbers both games read (Frankie, 10/24).

The sequence, frame by frame at 60 a second: on a flat ocean blue screen a
solid white spiral grows from the middle while slowly turning; it fades out
in 16 brightness steps while the dawn fades in, the sky line by line from
deep indigo to peach at the horizon, the sun a half disc on the horizon
where the spiral was, the sea below. The sea then comes alive (its waves
moving in bands, faster nearer the bottom, and the sun's reflection
wavering line by line) while faint specks of light drift up off the water.
Then the NUITAI logo rises from behind the horizon and settles near the
top, each of its lines sliding a pixel sideways as a wave rolls down it, as
if seen through water; last, NEW GAME and CONTINUE fade in over the sea.

Everything here is worked out the way the Super Nintendo does it, so the
cartridge (``game/snes/tools/make_title.py``) bakes its tables from these
same functions: colors are the console's 5 bit ones, the sky and sea are
one color a line (the backdrop, rewritten every line by HDMA), the spiral
is a Mode 7 picture turned and scaled each frame and added to what is
behind it (color math), the waves are a layer scrolled band by band, the
reflection is a window a line wide added in a warm color, the logo a layer
whose lines are scrolled a pixel apiece. The pictures are in
``assets/graphics/title/``, drawn by ``tools/draw_title_art.py``.
"""

from __future__ import annotations

import math

# ----------------------------------------------------------------------
# THE PICTURE
# ----------------------------------------------------------------------

WIDTH, HEIGHT = 256, 224
# The horizon's line: the sky above it, the sea from it down. The spiral
# turns about the middle of the screen, and the sun sits on this line there.
HORIZON = 112
CENTER_X = 128

# The flat blue the spiral grows on.
OCEAN_BLUE = (4, 12, 20)

# The dawn sky, line by line: (line, color) stops, straight between them.
SKY_STOPS = (
    (0, (4, 3, 12)),       # deep indigo
    (36, (8, 5, 16)),
    (70, (17, 8, 17)),     # violet into rose
    (94, (26, 13, 15)),
    (111, (31, 22, 16)),   # peach at the horizon
)
# The sea under it: the sky's light on the water at the horizon, darker
# toward the shore at the bottom.
SEA_STOPS = (
    (112, (16, 13, 18)),
    (120, (9, 10, 18)),
    (160, (4, 8, 16)),
    (223, (1, 4, 10)),
)

# The sun, a half disc sitting on the horizon, its radius in pixels.
SUN_RADIUS = 20
# The sun's three rings, the middle out.
SUN_COLORS = ((31, 30, 22), (31, 26, 15), (31, 20, 11))

# The sun's reflection, added to the sea inside its window (color math).
GLOW = (20, 13, 4)


def _lerp_stops(stops, line: int) -> tuple[int, int, int]:
    for (y0, c0), (y1, c1) in zip(stops, stops[1:]):
        if y0 <= line <= y1:
            t = (line - y0) / (y1 - y0)
            return tuple(round(a + (b - a) * t) for a, b in zip(c0, c1))
    return stops[-1][1] if line > stops[-1][0] else stops[0][1]


def dawn_color(line: int) -> tuple[int, int, int]:
    """The finished dawn's color on screen line ``line``, 5 bits a channel."""
    if line < HORIZON:
        return _lerp_stops(SKY_STOPS, line)
    return _lerp_stops(SEA_STOPS, line)


def mix(c0, c1, step: int, steps: int = 16) -> tuple[int, int, int]:
    """``step`` of ``steps`` of the way from color c0 to c1, rounded."""
    return tuple(round(a + (b - a) * step / steps) for a, b in zip(c0, c1))


def backdrop(line: int, step: int) -> tuple[int, int, int]:
    """Line ``line``'s backdrop ``step`` of 16 steps into the dawn's fade in."""
    return mix(OCEAN_BLUE, dawn_color(line), step)


def to_rgb(c) -> tuple[int, int, int]:
    """A 5 bit color as pygame's 8 bits, as an emulator shows it."""
    return tuple((v << 3) | (v >> 2) for v in c)


# ----------------------------------------------------------------------
# THE TIMELINE, in frames
# ----------------------------------------------------------------------

STEP_FRAMES = 6                      # one of the fade's 16 steps
GROW_FRAMES = 150                    # the spiral grows on the blue
FADE_START = GROW_FRAMES
FADE_FRAMES = 16 * STEP_FRAMES       # spiral out, dawn in
SEA_START = FADE_START + FADE_FRAMES
SEA_STEP_FRAMES = 3
SEA_FRAMES = 16 * SEA_STEP_FRAMES    # waves and reflection come up
SPECKS_START = FADE_START + 8 * STEP_FRAMES
LOGO_START = SEA_START + SEA_FRAMES
LOGO_FRAMES = 128                    # rising from the horizon
MENU_START = LOGO_START + LOGO_FRAMES
MENU_STEP_FRAMES = 3
MENU_FRAMES = 16 * MENU_STEP_FRAMES  # NEW GAME and CONTINUE fade in
DONE = MENU_START + MENU_FRAMES      # from here on it only moves


def fade_step(frame: int) -> int:
    """How many of the dawn's 16 steps are in, 0 to 16."""
    if frame < FADE_START:
        return 0
    return min(16, (frame - FADE_START) // STEP_FRAMES + 1)


def sea_step(frame: int) -> int:
    """How many of the sea's 16 steps are in (waves, reflection), 0 to 16."""
    if frame < SEA_START:
        return 0
    return min(16, (frame - SEA_START) // SEA_STEP_FRAMES + 1)


def menu_step(frame: int) -> int:
    """How many of the menu's 16 steps are in, 0 to 16."""
    if frame < MENU_START:
        return 0
    return min(16, (frame - MENU_START) // MENU_STEP_FRAMES + 1)


# ----------------------------------------------------------------------
# THE SPIRAL
# ----------------------------------------------------------------------

SPIRAL_SIZE = 192          # the picture, square, its middle the spiral's
SPIRAL_TURNS = 2.5
SPIRAL_REACH = 86          # the outer end's distance from the middle
SPIRAL_SPIN = 0.5          # degrees a frame, the slow turn


def spiral_pose(frame: int) -> tuple[float, float]:
    """The spiral's turn in degrees and its size (1 the picture's own).

    It grows from nothing to its own size over the grow, easing out, and
    keeps turning while it fades.
    """
    t = min(frame, GROW_FRAMES) / GROW_FRAMES
    scale = max(0.02, 1 - (1 - t) ** 2)
    return frame * SPIRAL_SPIN, scale


def spiral_gray(frame: int) -> int:
    """The spiral's brightness, 31 white to 0 gone: 16 steps out as the dawn comes in."""
    return round(31 * (16 - fade_step(frame)) / 16)


def spiral_matrix(frame: int) -> tuple[int, int, int, int]:
    """The Mode 7 matrix A, B, C, D (8.8 fixed point) for the spiral's pose:
    screen to picture, turning by the angle and shrinking by the size."""
    angle, scale = spiral_pose(frame)
    r = math.radians(angle)
    inv = 1 / scale
    a = round(256 * inv * math.cos(r))
    b = round(256 * inv * math.sin(r))
    return a, b, -b, a


# ----------------------------------------------------------------------
# THE SEA
# ----------------------------------------------------------------------

# The wave bands: (first line, lines, speed in 1/256 pixels a frame). Each
# band slides left; nearer the bottom they are taller and faster, so the
# water seems to come toward the beach.
WAVE_BANDS = (
    (112, 4, 24),
    (116, 5, 36),
    (121, 6, 52),
    (127, 7, 70),
    (134, 8, 92),
    (142, 9, 118),
    (151, 10, 148),
    (161, 11, 182),
    (172, 12, 222),
    (184, 13, 268),
    (197, 13, 320),
    (210, 14, 380),
)

# Wave colors, three a band group (shadow, body, crest): near the horizon
# the crests catch the dawn, further down they are the sea's own blues.
WAVE_PALETTES = (
    ((11, 9, 16), (19, 14, 19), (29, 21, 20)),
    ((5, 7, 15), (10, 13, 21), (18, 21, 26)),
    ((2, 4, 11), (6, 11, 19), (13, 18, 25)),
)
# Where each palette starts, in lines below the horizon: whole tile rows, as
# a tile has one palette on the console.
WAVE_PALETTE_FROM = (0, 24, 64)


def wave_palette_for_line(line: int) -> int:
    """The wave palette screen line ``line`` of the sea uses."""
    below = line - HORIZON
    return sum(1 for start in WAVE_PALETTE_FROM[1:] if below >= start)


def wave_color(palette: int, index: int, step: int) -> tuple[int, int, int]:
    """Wave color ``index`` (1 to 3) of a palette, ``step`` of 16 into the sea's fade in,
    from the water behind it."""
    behind = dawn_color(HORIZON + WAVE_PALETTE_FROM[palette] + 4)
    return mix(behind, WAVE_PALETTES[palette][index - 1], step)


REFLECTION_FRAMES = 16       # the reflection's shapes, one every few frames
REFLECTION_FRAME_TIME = 4


def reflection(shape: int) -> list[tuple[int, int] | None]:
    """The sun's reflection on each sea line in shape ``shape`` (0 to 15):
    the first and last pixel lit, or None for a line left dark.

    Under the sun a column narrows toward the shore; each line's middle
    wavers a few pixels and its width breathes, and here and there a line
    is dark, so the light breaks into streaks that roll down.
    """
    t = shape * 2 * math.pi / REFLECTION_FRAMES
    lines: list[tuple[int, int] | None] = []
    for line in range(HORIZON, HEIGHT):
        d = line - HORIZON
        streak = math.sin(d * 0.9 - t * 2) + 0.6 * math.sin(d * 0.37 + t)
        if d > 3 and streak < -0.9:
            lines.append(None)
            continue
        half = (SUN_RADIUS + 2 - d * 0.11) * (0.65 + 0.2 * streak)
        middle = CENTER_X + round(2.5 * math.sin(d * 0.55 + t * 3))
        half = max(1, round(half))
        lines.append((middle - half, middle + half - 1))
    return lines


def reflection_shape(frame: int) -> int:
    return (frame // REFLECTION_FRAME_TIME) % REFLECTION_FRAMES


# ----------------------------------------------------------------------
# THE SPECKS OF LIGHT
# ----------------------------------------------------------------------

SPECKS = 8                 # at most this many at once
SPECK_EVERY = 12           # frames between two
SPECK_LIFE = 96            # frames each lives, rising a quarter pixel a frame
# Their look by age: 2 dim, 1 brighter, 0 brightest, and back.
SPECK_LOOKS = ((12, 2), (24, 1), (72, 0), (84, 1), (96, 2))
SPECK_COLORS = ((28, 27, 20), (13, 14, 17))      # light, halo
# A small sway sideways, by age.
SPECK_SWAY = (0, 0, 1, 1, 1, 1, 0, 0, 0, 0, -1, -1, -1, -1, 0, 0)


def speck_look(age: int) -> int:
    return next(look for until, look in SPECK_LOOKS if age < until)


class Specks:
    """The specks, as the cartridge moves them: the same 16 bit random
    numbers, so both games put each speck in the same place."""

    def __init__(self) -> None:
        self.seed = 7
        self.count = 0
        self.x = [0] * SPECKS
        self.y4 = [0] * SPECKS      # in quarter pixels
        self.age = [SPECK_LIFE] * SPECKS

    def _random(self) -> int:
        self.seed = (self.seed * 25173 + 13849) & 0xFFFF
        return self.seed >> 8

    def tick(self, frame: int) -> None:
        """One frame, ``frame`` frames into the title."""
        for k in range(SPECKS):
            if self.age[k] < SPECK_LIFE:
                self.age[k] += 1
                self.y4[k] -= 1
        if frame >= SPECKS_START and (frame - SPECKS_START) % SPECK_EVERY == 0:
            k = self.count % SPECKS
            self.count += 1
            self.x[k] = 16 + self._random() % 224
            self.y4[k] = (136 + self._random() % 72) * 4
            self.age[k] = 0

    def shown(self):
        """(x, y, look) of each speck alive, its middle pixel at x, y."""
        for k in range(SPECKS):
            if self.age[k] < SPECK_LIFE:
                sway = SPECK_SWAY[(self.age[k] >> 2) & 15]
                yield self.x[k] + sway, self.y4[k] >> 2, speck_look(self.age[k])


# ----------------------------------------------------------------------
# THE ISLAND, THE BOAT AND THE GULLS (Frankie, 10/24: quiet details)
# ----------------------------------------------------------------------

# A small island with a lone palm on the horizon, off to the left so the
# sun and its reflection keep the middle: a 32 by 32 picture, its bottom on
# the line above the horizon. It comes in with the dawn, as the sun does.
ISLAND_LEFT = 36
ISLAND_COLORS = ((9, 6, 15), (15, 9, 17), (29, 18, 14))   # shadow, body, the sun's rim


def island_color(index: int, step: int) -> tuple[int, int, int]:
    """Island color ``index`` (1 to 3), ``step`` of 16 into the dawn's fade in."""
    return mix(OCEAN_BLUE, ISLAND_COLORS[index - 1], step)


# Now and then a small boat drifts right to left with the current, riding
# the third wave band at its speed (a pixel every 5 frames against the
# band's 52/256), bobbing a pixel.
BOAT_START = MENU_START + 60
BOAT_CYCLE = 2400          # frames from one boat to the next
BOAT_STEP = 5              # frames a pixel
BOAT_TOP = 114             # its 16 by 16 box; the hull's bottom is on line 128
BOAT_BOB = (0, 0, 0, 1, 1, 1, 0, 0)
# The boat's and gulls' colors: hull, sail, sail's shade, gull, gull's light.
BOAT_COLORS = ((6, 5, 12), (27, 21, 18), (17, 12, 17), (8, 5, 14), (14, 9, 17))


def boat_place(frame: int) -> tuple[int, int] | None:
    """Where the boat's box is in ``frame``, or None while there is no boat."""
    if frame < BOAT_START:
        return None
    t = (frame - BOAT_START) % BOAT_CYCLE
    x = WIDTH - t // BOAT_STEP
    if x <= -16:
        return None
    return x, BOAT_TOP + BOAT_BOB[(frame >> 3) & 7]


# A few gulls cross the sky left to right under the logo, flapping a while
# and gliding a while.
GULL_START = LOGO_START + 40
GULL_CYCLE = 1800
GULL_STEP = 2              # frames a pixel
GULLS = ((0, 80, 0), (-14, 74, 17), (-27, 86, 33))    # x behind the first, line, phase
GULL_FLAP = (0, 1, 2, 1)   # wings up, level, down, level


def gulls(frame: int) -> list[tuple[int, int, int]]:
    """(x, y, look) of each gull on screen in ``frame``, its 8 by 8 box's corner."""
    if frame < GULL_START:
        return []
    t = (frame - GULL_START) % GULL_CYCLE
    out = []
    for dx, y, phase in GULLS:
        x = t // GULL_STEP - 8 + dx
        if -8 < x < WIDTH:
            c = (t + phase) & 63
            look = GULL_FLAP[(c >> 2) & 3] if c < 32 else 1
            out.append((x, y + SPECK_SWAY[((t >> 3) + phase) & 15], look))
    return out


# ----------------------------------------------------------------------
# THE LOGO
# ----------------------------------------------------------------------

LOGO_TOP = 28              # where its top settles
WOBBLE_PHASES = 16
WOBBLE_FRAME_TIME = 3
WOBBLE_LENGTH = 14         # lines from one wave to the next


def logo_top(frame: int, height: int) -> int:
    """The logo's top line: hidden under the horizon until it rises, easing to a stop."""
    if frame < LOGO_START:
        return HORIZON
    t = min(1.0, (frame - LOGO_START) / LOGO_FRAMES)
    return round(HORIZON - (HORIZON - LOGO_TOP) * (1 - (1 - t) ** 3))


def wobble(line: int, phase: int) -> int:
    """How far screen line ``line`` of the logo slides, -1, 0 or 1, in phase ``phase``:
    the wave rolls down as the phase goes on."""
    s = math.sin(2 * math.pi * (line / WOBBLE_LENGTH - phase / WOBBLE_PHASES))
    return 1 if s > 0.6 else -1 if s < -0.6 else 0


def wobble_phase(frame: int) -> int:
    return (frame // WOBBLE_FRAME_TIME) % WOBBLE_PHASES


# ----------------------------------------------------------------------
# THE MENU
# ----------------------------------------------------------------------

MENU_X = 96                # the letters' left, the cursor 8 pixels before
MENU_Y = 152               # the first row's top
MENU_ROW = 16
