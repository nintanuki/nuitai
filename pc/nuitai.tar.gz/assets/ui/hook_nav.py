"""Where the hook goes when a direction is pressed between two parts of a screen (Frankie, 11/13).

The hook moves by where things are on screen: a direction goes to the nearest thing that way from where the
hook is now, preferring what is level with it (overlaps on the other axis). Right from Kailo goes to
whatever is beside Kailo, not to something at the bottom right. Within a list, up and down still step through
the rows; this picks between lists, windows and the party column.

``targets`` are ``(key, (x, y))`` where ``(x, y)`` is where the hook would hang.
"""

from __future__ import annotations

from typing import Hashable, Iterable

# How much a pixel off the line of travel costs against a pixel along it: a target level with the hook beats
# a nearer one far off to the side.
OFF_AXIS = 3


def nearest(origin: tuple[int, int], direction: str, targets: Iterable[tuple[Hashable, tuple[int, int]]]):
    """The key of the nearest target in ``direction`` ("left", "right", "up" or "down") from ``origin``, or None
    when nothing lies that way."""
    ox, oy = origin
    best, best_cost = None, None
    for key, (x, y) in targets:
        if direction == "right":
            along, across = x - ox, abs(y - oy)
        elif direction == "left":
            along, across = ox - x, abs(y - oy)
        elif direction == "down":
            along, across = y - oy, abs(x - ox)
        else:
            along, across = oy - y, abs(x - ox)
        if along <= 0:
            continue
        cost = along + OFF_AXIS * across
        if best_cost is None or cost < best_cost:
            best, best_cost = key, cost
    return best
