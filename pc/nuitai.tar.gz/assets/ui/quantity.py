"""The quantity picker's one rule, shared by the shop and Noelani's pule menu (Frankie, 11/12).

Up and Down count one, Right adds ten and Left takes ten off (Frankie, 11/19; it was the other way
round), stopping at the least and the most; A confirms and B cancels, which each scene handles itself.
"""

from __future__ import annotations

import pygame

from ui import input_map

TEN = 10


def stepped(event: pygame.event.Event, count: int, least: int, most: int) -> int:
    """``count`` after ``event``: Up and Down move one, Right adds ten, Left takes ten off, kept in ``least..most``.

    Up and Down that would pass an end do nothing, as in the shop; Left and Right stop at the end.
    Returns ``count`` unchanged for any other event.
    """
    if input_map.is_up(event) or input_map.is_down(event):
        moved = count + (1 if input_map.is_up(event) else -1)
        return moved if least <= moved <= most else count
    if input_map.is_left(event) or input_map.is_right(event):
        moved = count + (TEN if input_map.is_right(event) else -TEN)
        return max(least, min(most, moved))
    return count
