"""Monsters seen on the map, in place of random encounters (D-576).

A field monster stands on the grid like the player and, unless it is
told to stand still, wanders one tile at a time in a random direction
every second or so, sliding across the tile as the player does. One that
sees the player close by chases instead, a step at a time and quicker;
a boss never does (Frankie, 10/21). When it
and the player meet, the overworld starts its fight.

What each kind looks like and which fight it starts is in
``data/field_monsters/<kind>.json``:

* ``sheet``: the picture's id in ``sprite_files.SHEETS`` (its map sheet), a row of frames
  facing right (Ninja Adventure's animals), flipped to face left; or
  ``picture``, a monster's battle picture in ``AssetPaths.MONSTERS_DIR``,
  one frame, also facing right; or ``prop``, a picture in
  ``AssetPaths.BUILDINGS_DIR`` (the Pōhaku stands as the log yard's stone).
* ``wake_tiles``: for a sleeper, the Pōhaku (Frankie, 10/28): it stands
  still until the player comes this close, then chases, never wanders;
  ``chase_wait`` and ``step_ms`` slow its steps (the defaults are
  ``FieldMonsterSettings``').
* ``frame_width``: how wide one frame of a ``sheet`` is.
* ``tiles``: tiles across and down that it covers, ``[1, 1]`` unless
  given. Every picture is drawn at its own size, one picture pixel to
  one screen pixel, never enlarged (D-577).
* ``encounter``: a fixed fight from the shared battle file, for a boss;
  or ``lead`` (the monster that is in the fight when it catches the party), for an ordinary one.
  Company comes only from the other monsters on the map that see the party and rush in
  (Frankie, 11/19); see ``compose_group``.
"""

from __future__ import annotations

import os
import random
from typing import TYPE_CHECKING

import pygame

from settings import AssetPaths, FieldMonsterSettings, GridSettings, OverworldSettings
from utils import graphics, sprite_files

if TYPE_CHECKING:
    from core.world import World


# Each kind's frames by id, loaded on first use.
_FRAMES: dict[str, list[pygame.Surface]] = {}


def _frames(kind: dict) -> list[pygame.Surface]:
    """Return ``kind``'s frames facing right, at their own size; empty if missing."""
    if kind["id"] not in _FRAMES:
        frames: list[pygame.Surface] = []
        if "prop" in kind:
            path = os.path.join(AssetPaths.BUILDINGS_DIR, f"{kind['prop']}.png")
            if os.path.exists(path):
                frames.append(pygame.image.load(path).convert_alpha())
        elif "field" in kind:
            # A sheet of ``frame_width`` frames in the monster's own folder (the Sirena's, Frankie, 11/16).
            path = os.path.join(sprite_files.monster_dir(kind["field"]), "field.png")
            if os.path.exists(path):
                sheet = graphics.recolored(kind["field"], pygame.image.load(path).convert_alpha())
                width = kind["frame_width"]
                for index in range(sheet.get_width() // width):
                    frames.append(sheet.subsurface(pygame.Rect(index * width, 0, width, sheet.get_height())))
        elif "picture" in kind:
            path = sprite_files.monster_picture(kind['picture'])
            if os.path.exists(path):
                frames.append(pygame.image.load(path).convert_alpha())
        else:
            path = sprite_files.sheet_path(kind['sheet'])
            if os.path.exists(path):
                sheet = pygame.image.load(path).convert_alpha()
                width = kind["frame_width"]
                for index in range(sheet.get_width() // width):
                    frames.append(sheet.subsurface(
                        pygame.Rect(index * width, 0, width, sheet.get_height())
                    ))
        _FRAMES[kind["id"]] = frames
    return _FRAMES[kind["id"]]


# The spotted and lost icons, loaded on first use.
_MARKS: dict[str, pygame.Surface | None] = {}


def _mark_icon(name: str) -> pygame.Surface | None:
    """The ``spotted`` or ``lost`` icon (Frankie's drawings, 11/14); None if the picture is missing."""
    if name not in _MARKS:
        path = os.path.join(AssetPaths.ICONS_DIR, f"notice_{name}.png")
        _MARKS[name] = pygame.image.load(path).convert_alpha() if os.path.exists(path) else None
    return _MARKS[name]


class FieldMonster:
    """One monster standing or wandering on the map."""

    def __init__(self, spot: dict, kind: dict) -> None:
        """Place a monster.

        Args:
            spot: Where it starts, from ``FIELD_MONSTERS`` in
                ``core/overworld_cells.py``: ``col``, ``row``, ``kind``,
                ``still`` for one that never moves, ``leash`` for how many
                tiles from its start it may wander (or chase), and
                ``faces_left`` to set which way it looks, and ``pack`` for that many
                more slots in its fight (Kupulau's monsters, Frankie 11/1: bigger
                groups of their own kind, each slot filled nine times in ten).
            kind: Its ``data/field_monsters`` entry.
        """
        self.spot = spot
        if spot.get("pack") and kind.get("companions"):
            kind = {**kind, "extra_slots": kind.get("extra_slots", 0) + spot["pack"],
                    "join_chance": max(kind.get("join_chance", 0.0), 0.9)}
        self.kind = kind
        self.col: int = spot["col"]
        self.row: int = spot["row"]
        self.width, self.height = kind.get("tiles", (1, 1))
        self.still: bool = bool(spot.get("still"))
        self.leash: int | None = spot.get("leash")
        self.facing_left = spot.get("faces_left", random.random() < 0.5)
        self._wait = random.uniform(*FieldMonsterSettings.WAIT_RANGE)
        self._from: tuple[int, int] = (self.col, self.row)
        self._progress = 1.0
        # A sleeper (a ``wake_tiles`` kind, the Pōhaku) stands still until woken.
        self.awake = "wake_tiles" not in kind
        # Whether it has noticed the party (Frankie, 11/14): it does so only with the party close and in
        # front of it, and keeps chasing, turned or not and however far, until the party hides from it.
        self.noticed = False
        # The icon over its head (Frankie, 11/14): "spotted" as it notices the party, "lost" as the
        # party gets out of range; ``mark_sound`` is the same word until the room has played its sound.
        self.mark: str | None = None
        self.mark_sound: str | None = None
        self._mark_age = 0.0
        self._hidden = 0.0   # seconds the party it is chasing has been out of its sight
        # Rushing the party that a monster has caught (Frankie, 11/19): faster, no stopping to look.
        self.rushing = False
        self._world: "World | None" = None   # the room, once it has updated in one: what blocks its sight

    def tiles(self) -> set[tuple[int, int]]:
        """Every tile the monster covers."""
        return {
            (self.col + dx, self.row + dy)
            for dx in range(self.width) for dy in range(self.height)
        }

    def update(self, dt: float, world: "World", taken: set[tuple[int, int]],
               player: tuple[int, int] | None = None) -> None:
        """Finish the slide under way, or wait and then try a step.

        Args:
            dt: Frame time in seconds.
            world: Asked whether a tile is a wall.
            taken: Tiles the other monsters cover; a monster never steps
                onto another. The player's tile is not in it: stepping
                onto the player is how a monster starts its fight.
            player: Where the player stands, for the chase; None when
                the monster should not chase (just after a fight).
        """
        self._world = world
        self._mark_age += dt
        self._hidden += dt   # set back to zero in ``_notice`` while it can see the party
        if self._mark_age >= FieldMonsterSettings.MARK_SECONDS:
            self.mark = None
        if not self.rushing:
            self._notice(player)
        speed = FieldMonsterSettings.RUSH_SPEED if self.rushing else 1.0
        if self._progress < 1.0:
            step_ms = self.kind.get("step_ms", FieldMonsterSettings.STEP_MS) / speed
            self._progress = min(1.0, self._progress + dt * 1000 / step_ms)
            return
        if self.still:
            return
        if not self.awake:
            # It wakes only when the party comes within wake_tiles (the Pōhaku, Frankie 10/28).
            if player is None or self._distance(player) > self.kind["wake_tiles"]:
                return
            self.awake = True
            self._wait = self.kind.get("chase_wait", FieldMonsterSettings.CHASE_WAIT)
            return
        self._wait -= dt
        if self._wait > 0:
            return
        steps = self._chase_steps(player)
        if steps:
            self._wait = self.kind.get("chase_wait", FieldMonsterSettings.CHASE_WAIT) / speed
        elif self.rushing:
            return   # on the party: it stays there (no wandering off while the rest arrive)
        elif "wake_tiles" in self.kind:
            # Awake, a stone does not wander: it waits for the party to come back.
            self._wait = self.kind.get("chase_wait", FieldMonsterSettings.CHASE_WAIT)
            return
        else:
            self._wait = random.uniform(*FieldMonsterSettings.WAIT_RANGE)
            steps = [random.choice(((1, 0), (-1, 0), (0, 1), (0, -1)))]
        for dx, dy in steps:
            if self._try_step(dx, dy, world, taken):
                return

    def _chase_steps(self, player: tuple[int, int] | None) -> list[tuple[int, int]]:
        """The steps toward the player, the longer way first; none if far, or a boss."""
        if not self.rushing:
            self._notice(player)
        if not (self.noticed or self.rushing):
            return []
        # Distance to the nearest of its tiles, so a big monster chases from its edge.
        near = min(self.tiles(), key=lambda t: abs(t[0] - player[0]) + abs(t[1] - player[1]))
        dx, dy = player[0] - near[0], player[1] - near[1]
        across = [((dx > 0) - (dx < 0), 0)] if dx else []
        down = [(0, (dy > 0) - (dy < 0))] if dy else []
        return across + down if abs(dx) >= abs(dy) else down + across

    def watches(self, player: tuple[int, int]) -> bool:
        """Whether it can see the party right now (Frankie, 11/19): one that has noticed it still does while
        nothing blocks the line, however far; one that has not, only in front of it and within chasing
        range. A boss and a sleeper still asleep never do."""
        if self.spot.get("boss") or not self.awake:
            return False
        if self.noticed:
            if "wake_tiles" in self.kind:
                return self._distance(player) <= FieldMonsterSettings.CHASE_TILES
            return self._clear_line(player)
        return self._distance(player) <= FieldMonsterSettings.CHASE_TILES and self.sees(player)

    def start_rush(self, player: tuple[int, int]) -> None:
        """Rush the party: it has been seen, so it stops its wait and the spotted icon pops over it."""
        if not self.noticed:
            self.noticed = True
            self._show("spotted")
        self._hidden = 0.0
        self.rushing = True
        self._wait = 0.0

    def _notice(self, player: tuple[int, int] | None) -> None:
        """Notice the party when it is close and in front; lose it once it is out of range."""
        if player is None or self.spot.get("boss"):
            self.noticed = False   # a fight just ended, or a boss: no icon
        elif self.noticed:
            # It chases for as long as it can see the party, however far (Frankie, 11/14). A stone
            # has no eyes, so it gives up by distance, as it wakes.
            if "wake_tiles" in self.kind:
                hidden = self._distance(player) > FieldMonsterSettings.CHASE_TILES
                self._hidden = FieldMonsterSettings.LOSE_SECONDS if hidden else 0.0
            elif self._clear_line(player):
                self._hidden = 0.0
            if self._hidden >= FieldMonsterSettings.LOSE_SECONDS:
                self.noticed = False
                self._show("lost")
        elif (self._distance(player) <= FieldMonsterSettings.CHASE_TILES and self.awake
              and (self.sees(player) or "wake_tiles" in self.kind)):  # a woken stone needs no eyes
            self.noticed = True
            self._hidden = 0.0
            self._show("spotted")

    def _show(self, mark: str) -> None:
        """Pop ``mark`` over its head, for the room to play its sound."""
        self.mark = self.mark_sound = mark
        self._mark_age = 0.0

    def sees(self, player: tuple[int, int]) -> bool:
        """Whether ``player`` stands in front of the monster, the half it faces plus a little, with
        no tree, wall or building on the straight line between them (Frankie, 11/14).

        A map monster faces only left or right, so behind is the other side; nothing is drawn.
        """
        near = min(self.tiles(), key=lambda t: abs(t[0] - player[0]) + abs(t[1] - player[1]))
        ahead = (player[0] - near[0]) * (-1 if self.facing_left else 1)
        if ahead < -FieldMonsterSettings.NOTICE_BEHIND_TILES:
            return False
        return self._clear_line(player)

    def _clear_line(self, player: tuple[int, int]) -> bool:
        """Whether no tree, wall or building stands on the straight line from it to ``player``."""
        if self._world is None:
            return True
        near = min(self.tiles(), key=lambda t: abs(t[0] - player[0]) + abs(t[1] - player[1]))
        # Walk the straight line from it to the player, tile by tile, and stop at anything tall.
        steps = max(abs(player[0] - near[0]), abs(player[1] - near[1]))
        between = {(round(near[0] + (player[0] - near[0]) * i / steps),
                    round(near[1] + (player[1] - near[1]) * i / steps)) for i in range(1, steps)}
        return not any(self._world.blocks_sight(*tile) for tile in between - self.tiles())

    def _distance(self, player: tuple[int, int]) -> int:
        """Tiles across plus down from the player to the nearest tile it covers."""
        return min(abs(c - player[0]) + abs(r - player[1]) for c, r in self.tiles())

    def _try_step(self, dx: int, dy: int, world: "World", taken: set[tuple[int, int]]) -> bool:
        """Start a slide one tile that way, if every tile it would cover is free."""
        moved = {(c + dx, r + dy) for c, r in self.tiles()}
        for c, r in moved:
            inside = 0 <= c < OverworldSettings.COLS and 0 <= r < OverworldSettings.ROWS
            if not inside or (c, r) in taken:
                return False
            if self.kind.get("water"):
                # A swimmer moves only on its own water, nothing standing in it: the Sirena on salt, the Syokoy on
                # fresh (Frankie, 11/16 and 11/19).
                own = OverworldSettings.FRESH_CHAR if self.kind["water"] == "fresh" else OverworldSettings.WATER_CHAR
                if world.tile_at(c, r) != own or (c, r) in world.building_tiles \
                        or world.person_at(c, r):
                    return False
            elif world.is_wall(c, r):
                return False
        if self.leash is not None:
            home = (self.spot["col"], self.spot["row"])
            if abs(self.col + dx - home[0]) + abs(self.row + dy - home[1]) > self.leash:
                return False
        if dx:
            self.facing_left = dx < 0
        self._from = (self.col, self.row)
        self.col, self.row = self.col + dx, self.row + dy
        self._progress = 0.0
        return True

    def render(self, surface: pygame.Surface) -> None:
        """Draw the monster on its tiles, part way along a slide; a coloured square without art."""
        tile = GridSettings.TILE_SIZE
        t = self._progress
        x = OverworldSettings.X + round((self._from[0] + (self.col - self._from[0]) * t) * tile)
        y = OverworldSettings.Y + round((self._from[1] + (self.row - self._from[1]) * t) * tile)
        frames = _frames(self.kind)
        if not frames:
            pygame.draw.rect(
                surface, FieldMonsterSettings.COLOR, (x, y, tile * self.width, tile * self.height)
            )
            return
        # The feet move while it slides; standing, it holds the first frame.
        frame = frames[int(t * len(frames)) % len(frames) if t < 1.0 else 0]
        if self.facing_left:
            frame = pygame.transform.flip(frame, True, False)
        # Centred across its tiles, its bottom on their bottom.
        left = x + (tile * self.width - frame.get_width()) // 2
        top = y + tile * self.height - frame.get_height()
        surface.blit(frame, (left, top))
        icon = _mark_icon(self.mark) if self.mark else None
        if icon is not None:
            # Over its head, popping up from the head in the first moment.
            rise = min(1.0, self._mark_age / FieldMonsterSettings.MARK_POP_SECONDS)
            surface.blit(icon, (x + (tile * self.width - icon.get_width()) // 2,
                                top - round(icon.get_height() * rise)))
