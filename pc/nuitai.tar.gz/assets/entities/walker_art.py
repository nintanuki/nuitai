"""The 16 by 16 walker frames of the four heroes and of the NPCs, read straight from art/sprites/walkers.

Frankie edits ``<hero>/walk/*.png`` (NPCs: ``npcs/<name>/walk/*.png``) in Aseprite and
``export_aseprite.py`` rewrites them, so the game reads that folder and an edit shows up with no
copy step. An NPC is named by its Ninja sheet, lowercased (``OldMan`` is ``npcs/oldman``). Per facing: south and north
have four frames, west and east two (the stand frame first). The columns come out in the order of
``OverworldPlayerSettings.SHEET_COLUMNS`` (south, north, west, east), so callers index them the
way they did the Ninja sheets. A name with no walker art returns ``[]`` and the caller falls
back to its old sheet.
"""

from __future__ import annotations

import os

import pygame

HEROES = ("kailo", "hina", "maika", "tawiri")
WALKERS_DIR = os.path.abspath(os.path.join(
    os.path.dirname(__file__), '..', '..', '..', 'art', 'sprites', 'walkers'))
FACINGS = ("south", "north", "west", "east")

_CACHE: dict[str, list[list[pygame.Surface]]] = {}


def _walk_dir(key: str) -> str | None:
    """The folder of ``key``'s walk frames, or None when there is none."""
    path = os.path.join(WALKERS_DIR, key if key in HEROES else os.path.join('npcs', key), 'walk')
    return path if os.path.isdir(path) else None


def walker_frames(name: str) -> list[list[pygame.Surface]]:
    """``[facing column][frame]`` for a hero or an NPC, or ``[]`` when ``name`` has no walker art."""
    key = name.lower()
    if key not in _CACHE and _walk_dir(key) is None:
        return []
    if key not in _CACHE:
        columns: list[list[pygame.Surface]] = []
        for facing in FACINGS:
            frames = []
            index = 0
            while True:
                path = os.path.join(_walk_dir(key), f"{facing}-{index}.png")
                if not os.path.exists(path):
                    break
                image = pygame.image.load(path)
                if pygame.display.get_surface() is not None:
                    image = image.convert_alpha()
                frames.append(image)
                index += 1
            columns.append(frames)
        _CACHE[key] = columns if all(columns) else []
    return _CACHE[key]
