"""The 16 by 16 walker frames of the four heroes and of the NPCs, from game/assets/sprites.

Each character has one sheet, ``walker.png`` (Frankie, 11/13), beside the ``.aseprite`` Frankie edits;
``art/sprites/walkers/export_aseprite.py`` (or ``export-sprites.bat``) rewrites it, so an edit shows up
with no copy step. An NPC is asked for by its sheet id (``OldMan`` is Ama's folder,
``utils/sprite_files.py``). The sheet has a 16 by 16 column per facing, south, north, west, east, the
frames top down: south and north four, west and east two (the stand frame first), an empty cell ending a
column. The columns come out in the order of ``OverworldPlayerSettings.SHEET_COLUMNS``, so callers index
them the way they did the Ninja sheets. A name with no walker art returns ``[]`` and the caller falls
back to its old sheet.
"""

from __future__ import annotations

import pygame

from utils import sprite_files

HEROES = sprite_files.HEROES
FACINGS = ("south", "north", "west", "east")

_CACHE: dict[str, list[list[pygame.Surface]]] = {}


FRAME = 16


def walker_frames(name: str) -> list[list[pygame.Surface]]:
    """``[facing column][frame]`` for a hero or an NPC, or ``[]`` when ``name`` has no walker art."""
    key = name.lower()
    if key not in _CACHE:
        path = sprite_files.walker_sheet(key)
        if path is None:
            return []
        sheet = pygame.image.load(path)
        if pygame.display.get_surface() is not None:
            sheet = sheet.convert_alpha()
        columns: list[list[pygame.Surface]] = []
        for column in range(len(FACINGS)):
            frames = []
            for row in range(sheet.get_height() // FRAME):
                cell = sheet.subsurface((column * FRAME, row * FRAME, FRAME, FRAME))
                if cell.get_bounding_rect().width == 0:
                    break   # an empty cell ends the column
                frames.append(cell.copy())
            columns.append(frames)
        _CACHE[key] = columns if all(columns) else []
    return _CACHE[key]
