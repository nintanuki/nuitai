"""Overworld player — grid-stepped, pixel-interpolated.

Logical position is ``(col, row)`` in cell-local tile coordinates.
The sprite's pixel position is interpolated each frame between the
previous tile and the destination tile over
``OverworldPlayerSettings.STEP_DURATION_MS``, so movement feels smooth
even though the underlying rules are tile-based.

This class is intentionally JRPG-traditional:

* Four-directional only; diagonals are never returned from the input
  layer for movement (the polled reader keeps the dominant axis when
  the player holds two directions at once).
* Held-input is read polled inside ``update`` rather than event-driven.
  Pygame's ``KEYDOWN`` repeat would have to be reconfigured per-scene
  to feel right, and that bleeds global state into the text box and
  menus. Polling stays local.
* Facing direction is the most recent attempted step (a wall bump
  still turns the sprite to face the wall).

The sprite is one tile, 16 by 16, Pokemon style (D-573). Its frames come
from the sheet at ``AssetPaths.PLAYER_SHEET``, a Ninja Adventure walk
sheet: one column per facing, four walk frames down each, the first
also the standing frame. Without the sheet a flat colored square stands
in, so the scaffolding can be verified without art.
"""

from __future__ import annotations

import math
import os
import random
from typing import TYPE_CHECKING

import pygame

from core.world import World
from utils import sprite_files
from settings import (
    AssetPaths,
    FishingSettings,
    GridSettings,
    OverworldPlayerSettings,
    OverworldSettings,
    SwimSettings,
)
from entities.walker_art import walker_frames
from ui import input_map

if TYPE_CHECKING:
    from main import GameManager


# The sheet cut into frames, ``[facing column][frame]``, loaded on first use.
# ``[]`` means the sheet was looked for and is missing.
_FRAMES: dict[str, list[list[pygame.Surface]]] = {}

# Who walks the map when L or R has not picked another (Frankie, 11/1).
LEAD = "kailo"


def _frames(walker: str = LEAD) -> list[list[pygame.Surface]]:
    """Return ``walker``'s frames by facing, or an empty list when there is no sheet.

    The four heroes walk on Frankie's walker frames (``entities/walker_art.py``); anyone
    else falls back to the Ninja Adventure sheet (``<Name>-Walk.png``), laid out the same.
    """
    if walker in _FRAMES:
        return _FRAMES[walker]
    frames_out = _FRAMES[walker] = walker_frames(walker)
    if frames_out:
        return frames_out
    path = AssetPaths.PLAYER_SHEET if walker == LEAD else sprite_files.sheet_path(f"{walker.capitalize()}-Walk")
    if not os.path.exists(path):
        return frames_out
    sheet = pygame.image.load(path)
    if pygame.display.get_surface() is not None:
        sheet = sheet.convert_alpha()
    width = OverworldPlayerSettings.FRAME_WIDTH
    height = OverworldPlayerSettings.FRAME_HEIGHT
    frames = min(OverworldPlayerSettings.WALK_FRAMES, sheet.get_height() // height)
    for column in range(sheet.get_width() // width):
        frames_out.append([
            sheet.subsurface(pygame.Rect(column * width, frame * height, width, height))
            for frame in range(frames)
        ])
    return frames_out


_FISH: list[pygame.Surface] | None = None
_BUBBLE: pygame.Surface | None = None


def _fishing_art() -> tuple[list[pygame.Surface], pygame.Surface | None]:
    """The fishing poses by facing, and the bite bubble; ``([], None)`` without the art."""
    global _FISH, _BUBBLE
    if _FISH is None:
        _FISH = []
        if os.path.exists(AssetPaths.FISH_SHEET) and os.path.exists(AssetPaths.FISH_BUBBLE):
            def load(path: str) -> pygame.Surface:
                image = pygame.image.load(path)
                return image.convert_alpha() if pygame.display.get_surface() is not None else image
            sheet, _BUBBLE = load(AssetPaths.FISH_SHEET), load(AssetPaths.FISH_BUBBLE)
            size = sheet.get_height()
            _FISH = [sheet.subsurface(pygame.Rect(i * size, 0, size, size))
                     for i in range(sheet.get_width() // size)]
    return _FISH, _BUBBLE


from entities.swim_fx import ripple_color as _ripple_color, swim_frames  # noqa: E402,F401


class OverworldPlayer:
    """Grid-stepped overworld leader with pixel-interpolation animation."""

    def __init__(self, gm: "GameManager", world: World) -> None:
        """Spawn the player at the configured starting tile.

        Args:
            gm: Active game manager. Used to reach the cached joystick
                list for polled direction reads.
            world: Active world model. Queried for wall collision and
                cell-edge transitions.
        """
        self.gm = gm
        self.world = world
        # Logical position in cell-local tile coordinates.
        self.col: int = OverworldPlayerSettings.SPAWN_COL
        self.row: int = OverworldPlayerSettings.SPAWN_ROW
        # Facing direction as a (dx, dy) cardinal unit vector. Default
        # south so the placeholder sprite has a stable facing on spawn.
        self.facing: tuple[int, int] = (0, 1)
        # Animation state. ``_step_progress`` walks 0.0 -> 1.0 over one
        # step duration; while ``_step_active`` is True the renderer
        # interpolates between ``_step_start`` and ``_step_target``.
        self._step_active: bool = False
        self._step_start: tuple[int, int] = (self.col, self.row)
        self._step_target: tuple[int, int] = (self.col, self.row)
        self._step_progress: float = 0.0
        # Completed steps, so the feet alternate from step to step.
        self.step_count: int = 0
        # Whether the last step tried was a bump, so the scene can say
        # something at a dead end (Frankie, 10/26).
        self.bumped: bool = False
        # Whose sprite walks (L and R pick, Frankie 11/1); looks only, NPCs still talk to Kailo.
        self.walker: str = LEAD
        self.override: pygame.Surface | None = None   # a pose drawn in place of the walker (the punch)
        self.hold_frame: int | None = None   # a walk frame held while standing (up and down punches)
        # Swimming (Frankie, 11/16): in the water he shows from the eyes up; a hop carries him in or out over one tile.
        self.swimming: bool = False
        self._hop: bool = False            # the step under way is a hop in or out
        self._splashes: list[dict] = []    # droplets in the air, each with its own start time
        self.splash_sound: str | None = SwimSettings.SPLASH_SOUND   # a hook: the sound to play on a splash (none yet)

    @property
    def shown(self) -> str:
        """Who is on the map: ``walker``, unless they are knocked out, then the next member
        standing in party order (Frankie, 11/15: a KO'd member never walks). ``walker`` is
        left alone, so the first one walks again the moment they are on their feet."""
        party = getattr(self.gm, "party", None)
        members = party.members if party is not None else []
        mine = next((m for m in members if m.id == self.walker), None)
        if mine is None or mine.current_hp > 0:
            return self.walker
        for member in members:
            if member.current_hp > 0:
                return member.id
        return self.walker  # everyone is down: the game is over, nobody to swap in

    # ------------------------------------------------------------------
    # POSITION HELPERS
    # ------------------------------------------------------------------

    def _logical_pixel(self, col: int, row: int) -> tuple[int, int]:
        """Return the screen-space top-left for a tile in the active cell.

        Args:
            col: Cell-local column index.
            row: Cell-local row index.

        Returns:
            The ``(x, y)`` screen-space pixel coordinate of the tile's
            top-left corner.
        """
        x = OverworldSettings.X + col * GridSettings.TILE_SIZE
        y = OverworldSettings.Y + row * GridSettings.TILE_SIZE
        return x, y

    def _snap_to_logical(self) -> None:
        """Force any in-flight animation to drop to the logical tile.

        Called after a cell transition or a save-load restore — the
        sprite snaps to the new logical position rather than animating
        across a discontinuity.
        """
        self._step_active = False
        self._step_start = (self.col, self.row)
        self._step_target = (self.col, self.row)
        self._step_progress = 0.0

    # ------------------------------------------------------------------
    # STEP CONTROL
    # ------------------------------------------------------------------

    def _begin_step(self, dx: int, dy: int) -> None:
        """Validate and start a step in a cardinal direction.

        Args:
            dx: ``-1`` west, ``+1`` east, ``0`` no horizontal step.
            dy: ``-1`` north, ``+1`` south, ``0`` no vertical step.
        """
        if dx == 0 and dy == 0:
            return
        # Always face the direction the player tried to move, even if
        # the step fails. That is how DQ-style "bumping" feels right.
        self.facing = (dx, dy)
        self.bumped = False
        target_col = self.col + dx
        target_row = self.row + dy

        # Through a door, into a house or back out (Frankie, 10/22).
        arrived = self.world.warp(self.col, self.row, (dx, dy))
        if arrived is not None:
            self.col, self.row = arrived
            self._snap_to_logical()
            return

        # Onto stairs that lead somewhere: up or down at once (Frankie, 11/10).
        arrived = self.world.climb(target_col, target_row)
        if arrived is not None:
            self.col, self.row = arrived
            self._snap_to_logical()
            return

        # Cell-edge crossing: ask the world to swap cells. The matching
        # entry tile in the new cell becomes the player's new logical
        # position; the sprite snaps to it rather than animating across
        # the seam.
        out_of_x = not (0 <= target_col < OverworldSettings.COLS)
        out_of_y = not (0 <= target_row < OverworldSettings.ROWS)
        if out_of_x or out_of_y:
            dx_cells = 1 if target_col >= OverworldSettings.COLS else (
                -1 if target_col < 0 else 0
            )
            dy_cells = 1 if target_row >= OverworldSettings.ROWS else (
                -1 if target_row < 0 else 0
            )
            if self.world.step_to_neighbor(dx_cells, dy_cells):
                self.col = target_col % OverworldSettings.COLS
                self.row = target_row % OverworldSettings.ROWS
                if self.swimming and not self.world.is_swimmable(self.col, self.row):
                    # The water ends at the room's edge: on an open far shore he comes out, else he turns back.
                    if self.world.is_wall(self.col, self.row):
                        self.world.step_to_neighbor(-dx_cells, -dy_cells)
                        self.col = (self.col - dx) % OverworldSettings.COLS
                        self.row = (self.row - dy) % OverworldSettings.ROWS
                        self.bumped = True
                    else:
                        self.swimming = False
                self._snap_to_logical()
            else:
                # On failure: bump (no animation, just the face-turn above).
                self.bumped = True
            return

        # Stopped in a toll keeper's lane, the only way out is back the way he came (Frankie, 11/14).
        if self.world.lane_of(self.col, self.row) and (target_col, target_row) != self._step_start:
            self.bumped = True
            return

        # A hen in the way steps aside (Frankie, 11/5), so she cannot box him in.
        self.world.nudge_hen(target_col, target_row, dx, dy, (self.col, self.row))

        # A swimmer goes through water, and climbs out onto any open shore: a hop (Frankie, 11/16).
        if self.swimming:
            if self.world.is_swimmable(target_col, target_row):
                self._go(target_col, target_row, hop=False)
            elif (self.world.is_wall(target_col, target_row) or self.world.building_at(target_col, target_row)
                  or self.world.person_at(target_col, target_row)):
                self.bumped = True
            else:
                self._burst(self.col, self.row)
                self._go(target_col, target_row, hop=True)
                self.swimming = False
            return

        # In-cell wall check.
        # A toll keeper's lane is the one wall Kailo can step into: he is stopped there (Frankie, 11/14).
        if self.world.is_wall(target_col, target_row) and not self.world.lane_of(target_col, target_row):
            self.bumped = True
            return

        self._go(target_col, target_row, hop=False)

    def _go(self, col: int, row: int, hop: bool) -> None:
        """Begin the animation of a step to ``(col, row)``; a hop is the one in or out of the water."""
        self._hop = hop
        self._step_active = True
        self._step_start = (self.col, self.row)
        self._step_target = (col, row)
        self._step_progress = 0.0
        self.col = col
        self.row = row

    def dive(self) -> bool:
        """Hop from the shore into the water he faces; False when it cannot be swum."""
        dx, dy = self.facing
        col, row = self.col + dx, self.row + dy
        if self._step_active or not self.world.is_swimmable(col, row):
            return False
        self.swimming = True
        self._go(col, row, hop=True)
        return True

    def _burst(self, col: int, row: int) -> None:
        """A few droplets fly up from the water at ``(col, row)``, a step lighter than it, and fall back."""
        char = self.world.tile_at(col, row)
        if char not in OverworldSettings.WATER_COLORS:
            char = self.world.tile_at(self.col, self.row)
        x, y = self._logical_pixel(col, row)
        now = pygame.time.get_ticks()
        for _ in range(SwimSettings.SPLASH_COUNT):
            angle = math.radians(random.uniform(*SwimSettings.SPLASH_ANGLE)) * random.choice((-1, 1))
            speed = random.uniform(*SwimSettings.SPLASH_SPEED)
            self._splashes.append({"t0": now, "x": x + 8, "y": y + 10, "vx": math.sin(angle) * speed,
                                   "vy": math.cos(angle) * speed, "color": _ripple_color(char)})
        if self.splash_sound:
            self.gm.audio.play(self.splash_sound)

    def _read_polled_direction(self) -> tuple[int, int]:
        """Read the currently-held cardinal direction, normalised to one axis.

        When the player holds two perpendicular directions, the
        existing facing axis wins — that makes corner-turning feel
        responsive instead of locking the sprite into a diagonal.

        Returns:
            A cardinal ``(dx, dy)`` with at most one component non-zero.
        """
        dx, dy = input_map.read_held_direction(self.gm.connected_joysticks)
        if dx == 0 and dy == 0:
            return 0, 0
        if dx != 0 and dy != 0:
            # Keep the axis already being walked; if neither, prefer
            # horizontal (matches most JRPG conventions).
            if self.facing[1] != 0 and self.facing[0] == 0:
                return 0, dy
            return dx, 0
        return dx, dy

    # ------------------------------------------------------------------
    # FRAME
    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        """Advance the step animation and, at idle, start the next step.

        Args:
            dt: Frame time in seconds. Pulled straight from
                ``clock.tick(FPS) / 1000.0`` upstream.
        """
        if self._step_active:
            step_seconds = SwimSettings.HOP_SECONDS if self._hop else OverworldPlayerSettings.STEP_DURATION_MS / 1000.0
            self._step_progress += dt / step_seconds
            if self._step_progress >= 1.0:
                self._step_active = False
                self._step_progress = 0.0
                self.step_count += 1
                if self._hop and self.swimming:
                    self._burst(self.col, self.row)   # he lands in the water
                elif self.swimming and self.step_count % 2 == 0:
                    self.gm.audio.play(SwimSettings.STROKE_SOUND)
                self._hop = False
            return
        dx, dy = self._read_polled_direction()
        if dx == 0 and dy == 0:
            return
        self._begin_step(dx, dy)

    def render(self, surface: pygame.Surface) -> None:
        """Draw the sprite at the current (interpolated) position, on its tile.

        Args:
            surface: The screen surface to draw onto.
        """
        if self._step_active:
            start_x, start_y = self._logical_pixel(*self._step_start)
            end_x, end_y = self._logical_pixel(*self._step_target)
            t = max(0.0, min(1.0, self._step_progress))
            x = int(start_x + (end_x - start_x) * t)
            y = int(start_y + (end_y - start_y) * t)
        else:
            x, y = self._logical_pixel(self.col, self.row)
        if self.override is not None:
            surface.blit(self.override, (x - 8, y - 8))   # a 32 by 32 pose centred on the tile
            return
        self._render_splashes(surface)
        hop = 0
        if self._hop and self._step_active:
            t = max(0.0, min(1.0, self._step_progress))
            hop = round(SwimSettings.HOP_PIXELS * 4 * t * (1 - t))
        if self.swimming and not self._hop:
            char = self.world.tile_at(*(self._step_target if self._step_active else (self.col, self.row)))
            swim = swim_frames(char)
            if swim:
                column = OverworldPlayerSettings.SHEET_COLUMNS.get(self.facing, 0)
                pose = swim[(column * 2 + pygame.time.get_ticks() // SwimSettings.FRAME_MS % 2) % len(swim)]
                surface.blit(pose, (x - 8, y - 8))
                return
        y -= hop
        frames = _frames(self.shown) or _frames(LEAD)
        if not frames:
            rect = pygame.Rect(
                x, y, OverworldPlayerSettings.WIDTH, OverworldPlayerSettings.HEIGHT
            )
            pygame.draw.rect(surface, OverworldPlayerSettings.COLOR, rect)
            return
        column = frames[OverworldPlayerSettings.SHEET_COLUMNS.get(self.facing, 0) % len(frames)]
        if self._step_active:
            # Each tile crossed shows half the walk cycle; alternate
            # halves so the feet keep alternating from step to step.
            per_step = OverworldPlayerSettings.FRAMES_PER_STEP
            half = (self.step_count % 2) * per_step
            frame = half + min(per_step - 1, int(self._step_progress * per_step))
        else:
            frame = self.hold_frame or 0
        surface.blit(column[frame % len(column)], (x, y))

    def _render_splashes(self, surface: pygame.Surface) -> None:
        """The droplets in the air: each flies up and out and falls, gone after ``SPLASH_SECONDS``."""
        now = pygame.time.get_ticks()
        alive = []
        for drop in self._splashes:
            t = (now - drop["t0"]) / 1000.0
            if t >= SwimSettings.SPLASH_SECONDS:
                continue
            alive.append(drop)
            x = drop["x"] + drop["vx"] * t
            y = drop["y"] - (drop["vy"] * t - SwimSettings.SPLASH_GRAVITY * t * t / 2)
            surface.fill(drop["color"], (int(x), int(y), 1, 1))
        self._splashes = alive

    def render_fishing(self, surface: pygame.Surface, bite_left: float = 0.0) -> bool:
        """Draw Kailo holding the rod out over the water (Frankie, 10/30).

        With a fish biting (``bite_left`` seconds of the bite left) he jerks side to side and
        the ! bubble stands over his head. Returns False, drawing nothing, when there is no
        art, so the caller draws him walking.
        """
        poses, bubble = _fishing_art()
        if not poses or self._step_active or self.shown != LEAD:  # the rod pose is Kailo's own
            return False
        x, y = self._logical_pixel(self.col, self.row)
        pose = poses[OverworldPlayerSettings.SHEET_COLUMNS.get(self.facing, 0) % len(poses)]
        inset = (pose.get_width() - OverworldPlayerSettings.WIDTH) // 2
        shake = 0
        if bite_left > 0:
            jerk = int(bite_left / FishingSettings.SHAKE_SECONDS) % 2
            shake = FishingSettings.SHAKE_PIXELS * (1 if jerk else -1)
        surface.blit(pose, (x - inset + shake, y - inset))
        if bite_left > 0 and bubble is not None:
            surface.blit(bubble, (x + (OverworldPlayerSettings.WIDTH - bubble.get_width()) // 2,
                                  y - bubble.get_height() - FishingSettings.BUBBLE_GAP))
        return True

    # ------------------------------------------------------------------
    # PERSISTENCE
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Serialise logical position and facing to a JSON-safe dict."""
        return {
            "col": self.col,
            "row": self.row,
            "facing": list(self.facing),
            "walker": self.walker,
            "swimming": self.swimming,
        }

    def from_dict(self, data: dict) -> None:
        """Restore logical position and facing from a saved dict.

        Args:
            data: The dict previously returned by ``to_dict``. Missing
                or malformed fields are ignored, leaving the current
                value in place.
        """
        if isinstance(data.get("walker"), str):
            self.walker = data["walker"]
        self.swimming = bool(data.get("swimming", False))
        col = data.get("col")
        row = data.get("row")
        if isinstance(col, int):
            self.col = col
        if isinstance(row, int):
            self.row = row
        facing = data.get("facing")
        if isinstance(facing, list) and len(facing) == 2:
            try:
                self.facing = (int(facing[0]), int(facing[1]))
            except (TypeError, ValueError):
                pass
        self._snap_to_logical()
