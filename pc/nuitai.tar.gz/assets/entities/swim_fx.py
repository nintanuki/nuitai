"""What a swimmer looks like, shared by the map's player and the stage's actors (Frankie, 11/16).

The swim frames are PixelLab's (``kailo/swim.png``), their ripples recolored a step lighter than the water, and
a splash is a few droplets in that color flying up and falling.
"""

from __future__ import annotations

import math
import os
import random

import pygame

from settings import OverworldSettings, SwimSettings

_SWIM: dict[str, list[pygame.Surface]] = {}


def ripple_color(char: str) -> tuple[int, int, int]:
    """A step lighter than the water ``char`` (the ripples and the droplets, Frankie, 11/16)."""
    base = OverworldSettings.WATER_COLORS.get(char, OverworldSettings.WATER_COLORS[OverworldSettings.WATER_CHAR])
    k = SwimSettings.RIPPLE_LIGHTER
    return tuple(int(c + (255 - c) * k) for c in base)


def swim_frames(char: str) -> list[pygame.Surface]:
    """Kailo's swim frames for the water ``char`` (eight: south, north, west, east, two each), the ripples recolored
    a step lighter than that water (Frankie, 11/16); ``[]`` without the sheet or a display."""
    if char in _SWIM:
        return _SWIM[char]
    frames: list[pygame.Surface] = []
    if os.path.exists(SwimSettings.SHEET) and pygame.display.get_surface() is not None:
        sheet = pygame.image.load(SwimSettings.SHEET).convert_alpha()
        light = ripple_color(char)
        key, tol = SwimSettings.RIPPLE_KEY, SwimSettings.RIPPLE_TOLERANCE
        size = SwimSettings.FRAME
        for i in range(sheet.get_width() // size):
            frame = sheet.subsurface(pygame.Rect(i * size, 0, size, size)).copy()
            for y in range(size):
                for x in range(size):
                    r, g, b, a = frame.get_at((x, y))
                    if a and math.dist((r, g, b), key) <= tol:
                        frame.set_at((x, y), (*light, a))
            frames.append(frame)
    _SWIM[char] = frames
    return frames


def burst(x: int, y: int, char: str) -> list[dict]:
    """The droplets of a splash at pixel ``(x, y)`` (the middle of a tile), in the color of water ``char``."""
    now = pygame.time.get_ticks()
    out = []
    for _ in range(SwimSettings.SPLASH_COUNT):
        angle = math.radians(random.uniform(*SwimSettings.SPLASH_ANGLE)) * random.choice((-1, 1))
        speed = random.uniform(*SwimSettings.SPLASH_SPEED)
        out.append({"t0": now, "x": x, "y": y, "vx": math.sin(angle) * speed, "vy": math.cos(angle) * speed,
                    "color": ripple_color(char)})
    return out


def draw_drops(surface: pygame.Surface, drops: list[dict]) -> list[dict]:
    """Draw the droplets in the air and return the ones still falling."""
    now = pygame.time.get_ticks()
    alive = []
    for drop in drops:
        t = (now - drop["t0"]) / 1000.0
        if t >= SwimSettings.SPLASH_SECONDS:
            continue
        alive.append(drop)
        x = drop["x"] + drop["vx"] * t
        y = drop["y"] - (drop["vy"] * t - SwimSettings.SPLASH_GRAVITY * t * t / 2)
        surface.fill(drop["color"], (int(x), int(y), 1, 1))
    return alive
