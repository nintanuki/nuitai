import os
import sys

from core.shared import SHARED, SHARED_DIR
from core.field_lines import FieldLines
from utils import sprite_files

# Battle numbers shared with the browser game. See ``core/shared.py``.
_RULES = SHARED["rules"]
_STATS = SHARED["stats"]
# The lines said on the field are in game/shared/story-field.md, to edit with the
# story scenes (Frankie, 10/31); each name below that reads _FIELD gets its words there.
_FIELD = FieldLines()


class ColorSettings:
    """Class to hold all the color settings for the game."""
    BLACK = (0, 0, 0)
    NERO = (30, 30, 30)
    GRAY = (120, 120, 120)
    DARK_GRAY = (60, 60, 60)
    WHITE = (255, 255, 255)
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    BLUE = (0, 0, 255)
    YELLOW = (255, 220, 0)
    # The MUTE mark in the top right corner while the sound is off (M key).
    MUTE_MARK = (60, 230, 90)
    # Enemy names in the battle turn-order strip, so the two sides can
    # be told apart at a glance without reading.
    FOE_NAME = (240, 170, 150)

    BG_COLOR = NERO
    OVERLAY_BACKGROUND = BLACK
    # The Equip screen, Final Fantasy VI's (Frankie, 10/24): cyan slot and
    # stat names, a stat that would rise in yellow, one that would drop in
    # red, and the green arrows beside the element icons.
    LABEL_CYAN = (110, 220, 230)
    STAT_DROP = (255, 90, 90)
    ELEMENT_ARROW = (60, 230, 90)

    # Overworld tile placeholder colors. Replaced by tile sprite blits
    # in Pass 2 once we have real art chosen for Nuitai's island
    # setting. Until then these are how the cell area visually
    # distinguishes one terrain type from another.
    OVERWORLD_FLOOR = (110, 160, 90)    # grass green; walkable
    OVERWORLD_WALL = (90, 70, 60)       # rocky brown; impassable
    OVERWORLD_WATER = (60, 130, 180)    # ocean blue; impassable
    SPARKLE_BRIGHT = (235, 252, 255)    # a healing spring twinkle (Frankie, 11/12)
    SPARKLE_DIM = (150, 210, 235)
    OVERWORLD_SAND = (220, 200, 140)    # sandy beige; walkable

    # Per-element accent colors. Used by menus / UI labels to flag the
    # affinity of an ability or item at a glance. Tuned for readability
    # on the black command-panel background -- fire and water are *lighter*
    # than the pure RED/BLUE constants above. Shadow's entry is the lore
    # color (black); rendering it readably is the job of
    # ``ELEMENT_TEXT_STYLES`` below, which pairs the black body with a
    # white halo so the glyph survives any backdrop.
    # D-366, set B: fire red, plant green, water turquoise, light gold,
    # shadow purple, spirit blue, each lightened enough to read on black
    # (10/18: Tawiri's black shadow moves were hard to see).
    ELEMENT_COLORS: dict = {
        "afi":  (240, 110, 95),   # red
        "wai":  (60, 200, 220),   # turquoise
        "lau":  (140, 205, 90),   # green
        "mana": (160, 190, 255),  # blue, light enough to read on the blue windows (10/18)
        "la":   (242, 194, 48),   # gold
        "ata":  (190, 120, 230),  # purple
    }

    # Per-element TEXT style. Anywhere the UI renders an element name
    # (element-pair lines on combatant cards, ability-row labels in the
    # battle command menu) reads its render kwargs from here and splats
    # them into ``text_renderer.draw_text``.
    #
    # SHIPPED RECIPE: every element gets the same white halo at radius
    # 3, alpha 90 -- the same recipe shadow originally needed so its lore-
    # black body would survive a dark background. Applying it to all
    # six keeps the screen visually balanced; without the halo the
    # other five read flat next to a halo'd shadow. Shadow's body stays
    # black; everyone else keeps their accent fill.
    #
    # Alternatives we considered (preserved as runnable recipes in
    # ``visual_test_text.py``):
    #   universal soft white: glow=WHITE,  r=2, a=70  (toned down)
    #   self-color soft:      glow=fill,   r=2, a=60  (own-color bloom)
    #   self-color parity:    glow=fill,   r=3, a=90  (own-color at shadow intensity)
    #   brighter self-color:  glow=lighter, r=2, a=80 ("flame edge" -- per-element lighter halo)
    # Re-run ``python visual_test_text.py`` to compare again.
    _TEXT_HALO_WHITE = {
        "glow": (255, 255, 255),
        "glow_radius": 1,
        "glow_alpha": 90,
    }
    # The white halo every element word had before 10/22, kept for the stats' words.
    _HALO_STYLES: dict = {
        "afi":  {"color": ELEMENT_COLORS["afi"],  **_TEXT_HALO_WHITE},
        "wai":  {"color": ELEMENT_COLORS["wai"],  **_TEXT_HALO_WHITE},
        "lau":  {"color": ELEMENT_COLORS["lau"],  **_TEXT_HALO_WHITE},
        "mana": {"color": ELEMENT_COLORS["mana"], **_TEXT_HALO_WHITE},
        "la":   {"color": ELEMENT_COLORS["la"],   **_TEXT_HALO_WHITE},
        "ata":  {"color": ELEMENT_COLORS["ata"],  **_TEXT_HALO_WHITE},
    }
    # Element words (moves, stances) have a thick black edge, every element
    # alike, because it reads best on the blue windows; shadow's words are
    # white and spirit's purple, since purple shadow and blue spirit were hard
    # to read (Frankie, 10/22). The cartridge draws the same edge on its
    # third background layer (game/snes/src/edge.h).
    _TEXT_EDGE_BLACK = {
        "glow": (0, 0, 0),
        "glow_radius": 2,
        "glow_alpha": 255,
    }
    # A move's element tag on the ELEMENT grid (ui/element_tag.py, Frankie
    # 10/23): each element's color as its words show it, but Shadow black,
    # which reads on the ocean blue. A dual move's two colors meet with no
    # line between them (Frankie tried white and black and liked neither).
    TAG_COLORS: dict = {
        "afi": ELEMENT_COLORS["afi"], "wai": ELEMENT_COLORS["wai"], "lau": ELEMENT_COLORS["lau"],
        "mana": ELEMENT_COLORS["ata"], "la": ELEMENT_COLORS["la"], "ata": (0, 0, 0),
    }

    ELEMENT_TEXT_STYLES: dict = {
        "afi":  {"color": ELEMENT_COLORS["afi"],  **_TEXT_EDGE_BLACK},
        "wai":  {"color": ELEMENT_COLORS["wai"],  **_TEXT_EDGE_BLACK},
        "lau":  {"color": ELEMENT_COLORS["lau"],  **_TEXT_EDGE_BLACK},
        "mana": {"color": ELEMENT_COLORS["ata"],  **_TEXT_EDGE_BLACK},
        "la":   {"color": ELEMENT_COLORS["la"],   **_TEXT_EDGE_BLACK},
        "ata":  {"color": (255, 255, 255),        **_TEXT_EDGE_BLACK},
    }

    # The stats' colours (D-503 to D-505), by stat key: their elements', with
    # Agility orange and Willpower pink, for the "strength went up!" lines and
    # dialogue.
    STAT_TEXT_STYLES: dict = {
        "hp": _HALO_STYLES["lau"],
        "strength": _HALO_STYLES["afi"],
        "magic": _HALO_STYLES["mana"],
        "vitality": _HALO_STYLES["wai"],
        "spirit": {"color": (245, 130, 190), **_TEXT_HALO_WHITE},
        "speed": {"color": (255, 160, 70), **_TEXT_HALO_WHITE},
        "accuracy": _HALO_STYLES["la"],
        "evasion": _HALO_STYLES["ata"],
    }
    # The status screen's stat names: each in its color with the stances'
    # thick black edge, so blue Intelligence and purple Luck read on the
    # blue window (Frankie, 10/27).
    STAT_EDGE_STYLES: dict = {
        "hp": {"color": ELEMENT_COLORS["lau"], **_TEXT_EDGE_BLACK},
        "strength": {"color": ELEMENT_COLORS["afi"], **_TEXT_EDGE_BLACK},
        "magic": {"color": ELEMENT_COLORS["mana"], **_TEXT_EDGE_BLACK},
        "vitality": {"color": ELEMENT_COLORS["wai"], **_TEXT_EDGE_BLACK},
        "spirit": {"color": (245, 130, 190), **_TEXT_EDGE_BLACK},
        "speed": {"color": (255, 160, 70), **_TEXT_EDGE_BLACK},
        "accuracy": {"color": ELEMENT_COLORS["la"], **_TEXT_EDGE_BLACK},
        "evasion": {"color": ELEMENT_COLORS["ata"], **_TEXT_EDGE_BLACK},
    }


class BackgroundSettings:
    """Named scene-background templates and per-scene assignments."""

    SOLID = "solid"
    GRADIENT = "gradient"
    IMAGE = "image"
    # Battle backgrounds: Pixel-boy's battlebacks, CC0 (assets/graphics/backgrounds/battle/README.md).
    BATTLE_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'backgrounds', 'battle'
    )

    TEMPLATES: dict = {
        "ocean": (GRADIENT, (60, 180, 210), (10, 30, 70)),
        "midnight": (GRADIENT, (20, 20, 60), (0, 0, 0)),
        "dusk": (GRADIENT, (120, 60, 100), (20, 10, 40)),
        "ember": (GRADIENT, (200, 80, 30), (60, 10, 10)),
        "nero": (SOLID, (30, 30, 30)),
        # Behind a fight: dusk sky down into dark ground.
        "battlefield": (GRADIENT, (36, 58, 78), (16, 30, 26)),
        # Behind a fight in town: the tropical beach (Frankie, 10/18); anywhere
        # else, the jungle (Frankie, 10/23).
        "beach": (IMAGE, os.path.join(BATTLE_DIR, "3.png")),
        "jungle": (IMAGE, os.path.join(BATTLE_DIR, "6.png")),
        # The same two at night (Frankie, 11/1: Pono's Corpse is fought at night, not on a sunny beach).
        "beach_night": (IMAGE, os.path.join(BATTLE_DIR, "3-night.png")),
        "jungle_night": (IMAGE, os.path.join(BATTLE_DIR, "6-night.png")),
        # Behind a fight at sea (Frankie, 11/1): CraftPix's open ocean.
        "sea": (IMAGE, os.path.join(BATTLE_DIR, "ocean.png")),
        "black": (SOLID, (0, 0, 0)),
        # Behind the Kaigara board (its mockup, 10/27).
        "kaigara": (SOLID, (11, 19, 36)),
    }

    # The town's rooms, where a fight stands on the beach.
    TOWN_ROOMS: tuple = ("beach_west", "beach_east", "pono_yard", "harbor", "harbor_beach", "harbor_clearing",
                         "kupulau_harbor", "kupulau_farm", "kupulau_square")

    SCENE_BACKGROUNDS: dict = {
        "TitleScene": "ocean",
        "BattleScene": "beach",
        "MenuScene": "nero",
        "OverworldScene": "nero",
        "KaigaraScene": "kaigara",
    }

    DEFAULT_TEMPLATE: str = "nero"


class ScreenSettings:
    """The screen is a Super Nintendo screen (D-158): 256 by 224 pixels.

    Every scene draws onto a surface this size. ``main.py`` then enlarges
    it by a whole number, the scale, to fill the window, so one game
    pixel is the same square of screen pixels in the window, which takes
    the largest whole number that fits the desktop. Fullscreen shows the
    4:3 TV shape as big as the screen allows, sharp bilinear (viewport.py).
    Every position in this file is on the 256 by 224 screen.
    """

    # True when running in a browser, built by pygbag (tools/web_build.py).
    # The page scales the canvas itself, so the game draws at WEB_SCALE.
    WEB = sys.platform == "emscripten"
    WEB_SCALE = 3
    WIDTH = 256
    HEIGHT = 224
    RESOLUTION = (WIDTH, HEIGHT)
    FPS = 60
    # Room the window leaves for the title bar and the taskbar when it
    # picks its scale, in desktop pixels.
    WINDOW_MARGIN_W = 64
    WINDOW_MARGIN_H = 120
    CRT_ALPHA_RANGE = (75, 90)
    WINDOW_TITLE = "Nuitai RPG"
    TITLE_SCREEN_HEADING = "Nuitai"


class InputSettings:
    """Controller button and axis mappings used by gameplay and menus."""

    # The face buttons by position, named as on a Super Nintendo pad whatever
    # the pad prints (Frankie, 10/24). The numbers are SDL's, which are by
    # position too: 0 south, 1 east, 2 west, 3 north. So on an Xbox or
    # Logitech pad, A here is the button printed B.
    JOY_BUTTON_B = 0  # south
    JOY_BUTTON_A = 1  # east
    JOY_BUTTON_Y = 2  # west
    JOY_BUTTON_X = 3  # north
    JOY_BUTTON_L1 = 4
    JOY_BUTTON_R1 = 5
    JOY_BUTTON_BACK = 6
    JOY_BUTTON_START = 7
    # Held together: a soft reset to the title, every build (Frankie, 10/23).
    JOY_BUTTON_RESET_COMBO = (7, 6, 4, 5)

    JOY_AXIS_LEFT_X = 0
    JOY_AXIS_LEFT_Y = 1
    JOY_AXIS_L2 = 4
    JOY_AXIS_R2 = 5
    JOY_TRIGGER_THRESHOLD = 0.5


class FontSettings:
    """The one font, and the pixel grid its text sits on.

    Press Start 2P draws every letter in an 8 by 8 cell at size 8, one
    font pixel per screen pixel, so 8 is the size of all text, 16 the
    heading size and 24 the title's; any other size blurs the pixels.
    Thirty-two letters fit across the screen (D-445). Text sits on rows
    ``LINE_HEIGHT`` apart, two 8 pixel cells, as the Super Nintendo
    games spaced their lines; a heading takes two rows.
    ``ui/text_renderer`` places text by the top of its capital letters,
    so a position here is where the letters start.

    Text is mixed case (Frankie, 10/27): menus on the fixed 8 by 8 grid,
    as Chrono Trigger's menus, since on the Super Nintendo each letter is
    one tile; names in capitals, as Final Fantasy VI. Dialogue is in
    Galmuri11 Bold, a proportional font with taller letters and 2 pixel
    strokes, about 11 pixel capitals on 16 pixel rows, as Final Fantasy VI's
    dialogue, with a pixel more between every two letters; bold reads
    clearest from far away (Frankie, 10/27). Galmuri11 is crisp only at
    size 12, its own pixel grid.
    """

    FONT = os.path.join(
        os.path.dirname(__file__), 'assets', 'font', 'PressStart2P-Regular.ttf'
    )
    DIALOGUE_FONT = os.path.join(
        os.path.dirname(__file__), 'assets', 'font', 'Galmuri11-Bold.ttf'
    )

    SIZE_SMALL = 8
    SIZE_BODY = 8
    SIZE_HEADING = 16
    SIZE_TITLE_SCREEN_HEADING = 24
    # Dialogue is asked for by this name in place of a size; it is drawn at
    # DIALOGUE_POINTS, with DIALOGUE_LETTER_GAP pixels after every letter.
    SIZE_DIALOGUE = "dialogue"
    DIALOGUE_POINTS = 12
    DIALOGUE_LETTER_GAP = 1
    LINE_HEIGHT = 16
    DIALOGUE_LINE_HEIGHT = 16
    # Every letter is this wide, so a line holds its width // 8 letters.
    LETTER_WIDTH = 8
    # Speakers in the game's words who are not names, so stay mixed case;
    # every other speaker and every character's name is drawn in capitals.
    NOT_NAMES = (
        "Narrator", "Villager", "Hunter", "Elder", "Boy",
        "Child", "Keeper", "Trapper", "Loremaster", "Pirate", "PirateTwo", "Widow",
    )


class AudioSettings:
    """Global audio toggles, mixer-level defaults, and the sound/music registry."""

    MUTE = False
    MUTE_MUSIC = False
    MUSIC_VOLUME = 1.0
    SFX_VOLUME = 1.0

    SOUND_EFFECTS: dict = {
        "menu_move": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_move2.ogg'
        ),
        "menu_select": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_select3.ogg'
        ),
        # A chest opening: Leohpaz's Minifantasy Dungeon SFX (Frankie, 10/24).
        "chest_open": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_chest_open.ogg'
        ),
        # One stat point ticking up on the victory screen (tools/make_blip.py).
        "blip": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_blip.ogg'
        ),
        # The ko'i biting a tree, and Y on what no tool can work (tools/make_tool_sounds.py).
        "chop": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_chop.ogg'
        ),
        "cant": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_cant.ogg'
        ),
        # Hina's Scold babble: Nagging Mumble, every time (tools/make_scold_voices.py; Frankie, 11/11).
        "scold_nag": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_scold_nag.ogg'
        ),
        # A good, not perfect, timed block: a short clank (tools/make_clank_sound.py).
        "clank": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_clank.ogg'
        ),
        # A perfect timed block (tools/make_block_sound.py).
        "perfect": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_perfect.ogg'
        ),
        # A shovel biting the ground: Leohpaz's Minifantasy Dungeon SFX, by way of
        # Dungeon Digger (Frankie, 10/30).
        "dig": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_dig.ogg'
        ),
        # 'Awapuhi dug up: a short "you found something important" (tools/make_found_sound.py).
        "found": os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_found.ogg'
        ),
        # Attack sounds (D-151), synthesized for the Super Nintendo's sound memory
        # (tools/make_attack_sounds.py): the six elements, and three ways a blow lands.
        **{
            f"elem_{_e}": os.path.join(
                os.path.dirname(__file__), 'assets', 'audio', 'sound', f'sfx_elem_{_e}.ogg'
            )
            for _e in ("afi", "lau", "wai", "la", "ata", "mana")
        },
        **{
            f"hit_{_k}": os.path.join(
                os.path.dirname(__file__), 'assets', 'audio', 'sound', f'sfx_hit_{_k}.ogg'
            )
            for _k in ("blade", "blunt", "thrown")
        },
        # Only sounds a Super Nintendo could hold (Frankie, 10/23): a jingle,
        # such as the lontar's, comes back as music made from MIDI.
    }

    # How a blow lands (D-151), shared with the browser battle: one take
    # of each, the browser's three being too much for the Super Nintendo's
    # sound memory (Frankie, 10/23). "hit_punch" for a physical blow,
    # "hit_magic" for a spell, "hit_sparkle" for healing, "hit_miss"
    # for a dodge or a miss.
    # Every plain physical attack draws from one shared pool, whatever the weapon (Frankie,
    # 11/11: Hina's wand zapped); magic-sounding hits are kept for spells. One is picked at
    # random per blow. The synthesized kinds (tools/make_attack_sounds.py) have no numbered takes.
    PHYSICAL_HIT_POOL: tuple = ("hit_blade", "hit_blunt", "hit_thrown", "hit_punch")
    HIT_KINDS_ONE_TAKE: tuple = ("hit_blade", "hit_blunt", "hit_thrown")
    ELEMENT_SOUND_DELAY = 0.1   # Seconds after the blow's own sound that its element follows.
    HIT_SOUNDS: tuple = ("hit_punch", "hit_magic", "hit_sparkle", "hit_miss")
    HIT_TAKES = 1
    for _kind in HIT_SOUNDS:
        for _take in range(1, HIT_TAKES + 1):
            SOUND_EFFECTS[f"{_kind}_{_take}"] = os.path.join(
                SHARED_DIR, 'sounds',
                # The browser build carries them as OGG (tools/web_build.py).
                f'{_kind}_{_take}.ogg' if sys.platform == "emscripten" else f'{_kind}_{_take}.mp3'
            )
    del _kind, _take

    SFX_FILE_VOLUMES: dict = {
        os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_move2.ogg'
        ): 0.2,
        os.path.join(
            os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_select3.ogg'
        ): 0.2,
    }

    MUSIC_TRACKS: list = []

    # Songs by screen. Only music made from MIDI, which a Super Nintendo
    # can hold (Frankie, 10/23): Frankie's own pieces as tracker modules in
    # game/shared/music/snes/, the same files the cartridge plays
    # (tools/music/midi_to_it.py). The title plays his Main Theme; the
    # town and the harbor, their buildings too, his Kulāiwi with the surf under it by day from
    # the end of the taro patch, else the surf alone (Frankie, 10/27); at
    # night every room past the town is quiet; by day Potions, Poisons and Forest Mushrooms in the woods; The Forgotten
    # Wilds in the generated deep forest, so it sounds like a different place (Frankie, 10/26); The Big Bad in the
    # Great Boar's room while he is there; Spiny Shell in every fight, except the Great Boar's, which
    # has Frankie's Boss Battle 1 (11/11);
    # Regrets at Pono's wake (Frankie, 10/23); Cloud Racer when a fight is won (Frankie, 10/26).
    # A scene's Song (story.md) is a screen of its file's name: Voices of the Past, Tawiri's
    # theme, from her walking in at the wake through its fight (Frankie, 10/26).
    # SCREEN_MUSIC is which songs each screen picks from, SONG_LOOPS each
    # song's loop start and length in seconds; a song without loops repeats
    # whole. A screen with no songs is quiet.
    MUSIC_DIR = os.path.join(SHARED_DIR, 'music')
    SCREEN_MUSIC: dict = {"title": [os.path.join('snes', 'main-theme.it')],
                          "beach": [os.path.join('snes', 'waves.it')],
                          "village": [os.path.join('snes', 'kulaiwi.it')],
                          "woods": [os.path.join('snes', 'potions-poisons-and-forest-mushrooms.it')],
                          "great_boar": [os.path.join('snes', 'the-big-bad.it')],
                          "deep_woods": [os.path.join('snes', 'the-forgotten-wilds.it')],
                          "wake": [os.path.join('snes', 'regrets.it')],
                          "battle": [os.path.join('snes', 'spiny-shell.it')],
                          "boss": [os.path.join('snes', 'spiny-shell.it')],
                          "great_boar_fight": [os.path.join('snes', 'boss-battle-1.it')],
                          "victory": [os.path.join('snes', 'cloud-racer.it')],
                          "voices-of-the-past": [os.path.join('snes', 'voices-of-the-past.it')],
                          "black-flags": [os.path.join('snes', 'black-flags.it')]}
    # Frankie's own songs for two rooms by day (11/3): Sapphire Rain Drops in Lanu's grove,
    # Red Sands in the temple of Haka. Room name to its screen, a key of SCREEN_MUSIC.
    ROOM_SONGS: dict = {"key_room": "sapphire-rain-drops", "kulaiwi_temple": "red-sands", "kulaiwi_school": "red-sands"}
    SCREEN_MUSIC.update({"sapphire-rain-drops": [os.path.join('snes', 'sapphire-rain-drops.it')],
                         "red-sands": [os.path.join('snes', 'red-sands.it')]})
    # The town's rooms: they and the buildings in them play "village" by day once the taro
    # patch is over, else "beach", and the harbor's the same; at night everything else is quiet; by day the
    # Great Boar's room plays "great_boar", the generated deep forest "deep_woods", the rest "woods".
    LODGE_ROOMS: tuple = ("hunters_lodge", "kupulau_lodge")  # inside, but the woods' song plays
    # The temple's clearing is the village too (Frankie, 11/12: it said Kulāiwi Forest and played the woods' song).
    BEACH_ROOMS: tuple = ("beach_west", "beach_east", "pono_yard", "pono_farm", "harbor_beach", "harbor_clearing")
    HARBOR_ROOMS: tuple = ("harbor", "kupulau_harbor", "kupulau_farm", "kupulau_square")
    SONG_LOOPS: dict = {}
    # Screens whose song plays once, then silence until the screen changes (Frankie, 10/26).
    PLAY_ONCE: tuple = ("victory",)
    # A screen with no songs: a scene's "Song: none" stops the music, as the wake does from the
    # pirates to its End's words (Frankie, 10/27).
    SILENT = "none"

    @staticmethod
    def music_file(name: str) -> str:
        """A song's file name: the browser build carries them as OGG (tools/web_build.py)."""
        return os.path.splitext(name)[0] + '.ogg' if sys.platform == "emscripten" else name

    MUSIC_FILE_VOLUMES: dict = {}


class AssetPaths:
    """Class to hold all the file paths for assets."""
    # The title's dawn: the logo, the spiral, the sun, the specks, the waves (tools/draw_title_art.py).
    TITLE_DIR = os.path.join(os.path.dirname(__file__), 'assets', 'graphics', 'title')
    TV = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'effects', 'tv.png'
    )
    MENU_MOVE_SOUND = os.path.join(
        os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_move2.ogg'
    )
    MENU_SELECT_SOUND = os.path.join(
        os.path.dirname(__file__), 'assets', 'audio', 'sound', 'sfx_menu_select3.ogg'
    )
    # Every game sprite is in game/assets/sprites/, by who is in the picture (Frankie, 11/13);
    # utils/sprite_files.py knows the folders. A portrait is ``characters/<heroes|npcs>/<id>/portrait.png``;
    # ``unknown-portrait.png`` is the placeholder for a member with none drawn yet.
    SPRITES_DIR = sprite_files.SPRITES_DIR
    # A speaker whose face file goes by another name: a title in the label, or
    # one who borrows someone's face (none since Gajumaru got his own, 10/28).
    BORROWED_PORTRAITS: dict = {"chief ulu": "ulu"}
    UNKNOWN_PORTRAIT = sprite_files.UNKNOWN_PORTRAIT
    # Per-element 16x16 affinity icons (e.g. a flame for ``afi``, a wave
    # for ``wai``) used by the roster element lines on the party screen
    # and in battle. Files are named ``<element_id>.png`` -- if a file
    # for a given element does not exist, the renderer falls back to the
    # element word so partial coverage is fine while art lands.
    ICONS_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'icons'
    )
    # Monster battle pictures, one still image each, ``monsters/<name>/battle.png``
    # (sprite_files.monster_picture). An enemy in the shared battle file names its
    # picture with ``"sprite"``. A monster with no file gets a plain
    # box, so a missing picture never stops a fight.
    MONSTERS_DIR = sprite_files.MONSTERS_DIR
    # The party's battle sprites, one strip per animation, ``heroes/<who>/battle/<animation>.png``,
    # asked for as ``<who>_<animation>`` (kailo_idle, kailo_pan_attack, ...). Square
    # frames side by side; a new strip dropped in under the same name replaces
    # the old one (Frankie, 11/11). Made by tools/make_battle_party_sheets.py.
    # Map tiles: Mini World Sprites by Merchant Shade, CC0, unedited, in
    # miniworld/; the insides' walls and mats from Ninja Adventure, CC0, in
    # interior/.
    TILES_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'tiles'
    )
    # The walking sprite sheet, a Ninja Adventure walk sheet: one column
    # per facing (down, up, left, right), four 16 by 16 frames down each
    # (D-573).
    PLAYER_SHEET = sprite_files.sheet_path('Kailo-Walk')
    # Kailo fishing (Frankie, 10/30; tools/make_fishing_sprites.py): four 32 by 32 poses,
    # down, up, left, right, his 16 by 16 body at (8, 8) in each, and the ! bubble over him.
    FISH_SHEET = os.path.join(sprite_files.character_dir('kailo'), 'fish.png')
    FISH_BUBBLE = os.path.join(sprite_files.character_dir('kailo'), 'fish-bubble.png')
    # The people standing on the map are Ninja Adventure walk sheets laid out like
    # ``PLAYER_SHEET``; a room names one by its old stem (``"sheet": "OldMan"``) and
    # ``sprite_files.sheet_path("OldMan-Walk")`` finds it (Ama's folder).
    # The town's buildings and dressing (``OverworldSettings.BUILDINGS``),
    # cut from Ninja Adventure's TilesetHouse.png (CC0).
    BUILDINGS_DIR = os.path.join(
        os.path.dirname(__file__), 'assets', 'graphics', 'buildings'
    )


class BattleStageSettings:
    """Where fighters stand in a battle and how they move.

    Positions are in screen pixels on the 256 by 224 screen. Times are
    in seconds. See ``ui/battle_stage.py``. From the top: the turn strip
    and the help line (two rows), the monsters standing on ``MONSTER_SPOTS``
    with their statuses under each, then the 80 pixel HUD, whose right
    panel lists the party.
    """

    # --- Monsters ---------------------------------------------------
    # Every monster picture is drawn at its own size (D-577).
    # The box drawn for a monster that has no picture.
    PLACEHOLDER_SIZE = 32
    COLOR_PLACEHOLDER = (70, 70, 80, 255)
    SHADOW_WIDTH_SHARE = 0.8   # Of the picture's width.
    SHADOW_HEIGHT = 6
    SHADOW_ALPHA = 90
    # How far a monster's feet sink below the ground line, into its shadow.
    FEET_SINK = 1
    # Where monsters stand (Frankie, 11/11, set on the layout board): up to four spots in two
    # staggered rows, each a boar's feet point. Another monster is centered where a boar's
    # center sits on its spot (the boar's feet point minus half the boar sprite's height),
    # not placed by its feet. Which spots a pack takes, by how many there are, balances
    # the field: one stands back right, two take the back row, three add a front-left one.
    # The party stands on the left now, so these are the 11/11 spots mirrored (Frankie, 11/12): one
    # stands back left of the middle, two take the back row, three add a front-right one.
    MONSTER_SPOTS = ((111, 135), (131, 100), (161, 135), (181, 100))
    # A swarm of one kind (the aghoy, five or six at once, Frankie, 11/12) is spaced evenly in two staggered rows
    # instead, by how many there are: a first guess, clear of the party and the turn bar, to be moved on the layout page.
    SWARM_SPOTS = {
        5: ((121, 100), (161, 100), (201, 100), (141, 135), (181, 135)),
        6: ((121, 100), (161, 100), (201, 100), (101, 135), (141, 135), (181, 135)),
    }
    # Spots 1 to 4 run closest to the party first, and a fight of n monsters takes spots 1 to n (Frankie, 11/12, set
    # on the layout page's picker), so a smaller fight fills the ones nearest the party.
    # A fight with a layout of its own (the picker's changes): the monsters' picture names joined with "+" in fight
    # order, to one spot each, in the same order, each a boar's feet point.
    FIGHT_SPOTS = {
        "wicked_witch+wicked_witch+wicked_witch": ((111, 135), (135, 100), (176, 135)),
        "kapre": ((140, 95),),
        # The Great Boar stands in the back row, hiding behind the boars he calls (Frankie, 11/12): spot 2 is his
        # from the start, so he never moves, and the boars take the front spots 1 and 3, a third
        # one spot 4, beside him at the back.
        "tandayag_na_opon": ((131, 100),),
        "tandayag_na_opon+boar": ((131, 100), (111, 135)),
        "tandayag_na_opon+boar+boar": ((131, 100), (111, 135), (161, 135)),
        "tandayag_na_opon+boar+boar+boar": ((131, 100), (111, 135), (161, 135), (181, 100)),
    }
    MONSTER_SPOT_SPRITE = "boar"
    # A monster past the fourth reuses the spots, this many pixels further left each lap, toward the party.
    MONSTER_EXTRA_SHIFT = 12
    # No picture may reach the turn bar's left edge, the screen's left edge, or the HUD.
    FIELD_BOTTOM = 143
    BACKDROP_DY = -28          # The fight's backdrop slides up this far (Frankie, 11/11).
    # The Seer's Shell's reading (Frankie, 10/28): once a monster is looked
    # at, its element icons, HP and mana stay under its feet for the rest of
    # the fight, as Scan's do in Final Fantasy. Ground line to the row's top.
    READING_DY = 8
    READING_ICON_PITCH = 9     # One element icon to the next, then the HP.
    READING_PIPS_DY = 10       # Row top to the mana pips, under the HP; one pixel of air between, as the party's (Frankie, 11/12).
    READING_ROW_PITCH = 14     # A reading that would touch its neighbour's drops this far.
    READING_SLIDE = 14         # A reading slides at most this far sideways before it drops a row.
    READING_GAP = 3            # Pixels of air kept between two neighbouring readings (Frankie, 11/12).
    COLOR_READING_EDGE = (12, 12, 20)

    # --- Party sprites (Frankie, 11/11) --------------------------------
    # The party stands on the left of the field, turned toward the monsters
    # on the right, in a diagonal down to the left: each one's feet centre (x, y) (Frankie, 11/12;
    # it was the mirror of this, on the right).
    PARTY_SPRITE_FEET = ((66, 100), (41, 115), (16, 130))
    # An idle plays at one of three speeds, seconds a frame, set by the stance's element (Frankie, 11/13,
    # "for now", the seconds set on the slider preview).
    IDLE_SPEED_SECONDS = {"slow": 0.40, "medium": 0.20, "fast": 0.10}
    IDLE_SPEED_BY_ELEMENT = {
        "lau": "slow", "afi": "fast", "wai": "medium",
        "ata": "slow", "mana": "fast", "la": "medium",
    }
    IDLE_FRAME_SECONDS = IDLE_SPEED_SECONDS["medium"]  # Anyone with no stance element.

    MONSTER_IDLE_SPEED = "medium"   # Every monster's idle loop (Frankie, 11/13).

    @classmethod
    def idle_pace_named(cls, speed: str) -> float:
        """Seconds a frame for ``speed``: slow, medium or fast."""
        return cls.IDLE_SPEED_SECONDS.get(speed, cls.IDLE_FRAME_SECONDS)

    @classmethod
    def idle_pace(cls, element: object) -> float:
        """Seconds a frame for an idle in a stance of ``element`` (an Element, its id, or None)."""
        key = getattr(element, "value", element)
        speed = cls.IDLE_SPEED_BY_ELEMENT.get(key)
        return cls.IDLE_SPEED_SECONDS[speed] if speed else cls.IDLE_FRAME_SECONDS
    # Seconds into the loop each member starts, so no two are in step.
    IDLE_OFFSET = {"kailo": 0.0, "hina": 0.17, "maika": 0.41, "tawiri": 0.08}
    ATTACK_FRAME_SECONDS = 0.07    # A swing frame, played once.
    RUN_FRAME_SECONDS = 0.07       # A running-away frame, looping.
    RUN_SPEED = 140                # Pixels a second someone who got away runs off to the left.
    DOWN_ALPHA = 110               # A fallen member's picture, when there is no KO pose.
    # A fallen member lies in their KO pose (``<id>_ko``) under a red KO (Frankie, 11/12).
    COLOR_KO = (232, 48, 48)
    KO_LABEL_GAP = 2               # Pixels between the top of the pose and the label.
    # The party's weapon animations: combatant id -> sheet name for its attack.
    PARTY_ATTACK_SHEETS = {
        "kailo": "kailo_pan_attack",
        "hina": "hina_gohei_attack",
        "maika": "maika_hulakii_attack",
        "tawiri": "tawiri_hulakii_attack",
    }

    # --- Party rows -------------------------------------------------
    # The party is listed in the HUD's right panel, Final Fantasy style:
    # one row each, the first name, the HP bar and the HP, 16 pixels
    # apart. A name with a status on it turns ``COLOR_STATUS``.
    PARTY_ROW_X = 131          # The element icons start here, past the divider, in the window on the right.
    # The two element icons before each name, shrunk to 8 by 8, the
    # stance's boxed in yellow (D-453).
    PARTY_ICON_SIZE = 8
    PARTY_ICON_PITCH = 10      # One icon's box to the next.
    PERFECT_NAME_DX = 20       # A perfect block's DODGE is centered on the name: from the name's start to its middle (Claude's pick, 10/30).
    PERFECT_NAME_DY = -7
    PARTY_NAME_DX = 22         # Row start to the name, past the icons.
    PARTY_ROW_TOP_Y = 163      # Centres the three rows in the HUD (Frankie, 10/18).
    PARTY_ROW_PITCH = 16
    PARTY_NAME_CHARS = 6       # A longer first name is cut.
    PARTY_BAR_DX = 68          # Row start to the HP figure and mana pips (the figure is 56 wide at most, to the screen edge).

    # --- Turn order ---------------------------------------------------
    # One bordered bar down the right edge of the field (D-453; it was the left until 11/12, with
    # the party on the left now), Final Fantasy X style: a small picture per turn, the one acting
    # on top with a yellow arrow over it, a stripe on each entry's inner (left) edge, blue for the
    # party and red for monsters. The monsters stand to its left.
    TURN_ICON_SIZE = 16
    TURN_STRIPE = 3            # The side's colour, left of each picture (the bar's inner edge).
    TURN_BAR_X = 231           # 256 less the bar's 22 and three pixels from the edge (Frankie, 11/12: it looked flush).
    TURN_BAR_Y = 3
    TURN_ARROW = 4             # The arrow's half height.
    FIELD_RIGHT = 232          # The field's right edge, before the bar.
    COLOR_TURN_PARTY = (80, 130, 230)
    COLOR_TURN_FOE = (210, 80, 70)
    COLOR_TURN_MARKER = (24, 28, 44)   # Behind a monster's turn-order marker.
    PARTY_HOP_PIXELS = 2       # A row hops this far up when its member acts.
    COLOR_HURT_NAME = (255, 90, 80)    # The name while its member is hit.

    # --- Mana --------------------------------------------------------
    # Seven pips under each HP bar, lit for each point of mana
    # (D-213 to D-220), in spirit's blue (D-366).
    PIP_WIDTH = 2
    PIP_HEIGHT = 2
    PIP_GAP = 1
    PARTY_PIPS_DY = 10         # Row top to the pips, under the HP figure; one pixel of air between (Frankie, 11/12).
    COLOR_MANA = (80, 150, 255)
    COLOR_DEBT = (255, 70, 60)  # Mana below zero, after Wili (Frankie, 11/1).
    COLOR_PIP_OFF = (45, 45, 60)
    # The stroke points left this turn, in the command panel's top right.
    COLOR_POINTS = (255, 130, 130)

    # --- HP bars ----------------------------------------------------
    BAR_WIDTH = 24
    BAR_HEIGHT = 4
    BAR_TEXT_GAP = 4
    BAR_LOW_SHARE = 0.35       # Below this the hurt pose shows and the party's HP figure turns yellow.
    ROLL_MIN_RATE = 60         # HP figures count at least this many HP a second (one per tick).
    ROLL_CATCH_UP = 0.12       # Seconds a gap takes to close at its own pace: a big gap rolls faster.
    COLOR_BAR = (90, 210, 120)
    COLOR_BAR_LOW = (230, 70, 60)
    COLOR_BAR_BACK = (20, 20, 20)

    # --- Motion -----------------------------------------------------
    SHAKE_SECONDS = 0.35
    SHAKE_PIXELS = 3
    SHAKE_SPEED = 55.0         # How fast the jolt swings side to side.
    FLASH_SECONDS = 0.24
    FLASH_BLINK_HZ = 12.0
    LUNGE_SECONDS = 0.28
    LUNGE_PIXELS = 8           # A monster steps this far toward you.
    FADE_SECONDS = 0.6         # A defeated monster takes this long to go.
    FADE_SINK_PIXELS = 4
    BOB_PIXELS = 1             # Idle sway, so nothing stands dead still.
    BOB_SPEED = 2.6
    BOB_PHASE_STEP = 1.7       # Keeps neighbours from swaying in step.

    # --- A monster's stance switch (Frankie, 10/28) -------------------
    # Always shown, scanned or not: a short burst over the monster in the
    # new element's colors, square screen pixels, no smoothing. Leaves for
    # nature, flames for fire, black smoke for shadow; Claude's picks for
    # the rest: droplets for water, sparkles for light, blue wisps for spirit.
    # Made bigger after Mark's Episode 5, where the switches went unseen (Frankie, 11/4): longer,
    # twice the particles, and the monster itself pulses in the new element's color.
    STANCE_FX_SECONDS = 1.6
    STANCE_FX_PARTICLES = 32
    STANCE_GLOW_HZ = 4.0       # How fast the monster pulses in its new color (Claude's number).
    # Each element's colors, darkest first: the body, the light edge, the brightest.
    STANCE_FX_COLORS: dict = {
        "lau":  ((60, 130, 40), (123, 192, 67), (190, 235, 120)),    # leaves
        "afi":  ((200, 50, 30), (240, 130, 40), (255, 220, 90)),     # flames
        "ata":  ((22, 16, 30), (60, 34, 80), (142, 68, 173)),        # black smoke, purple edge
        "wai":  ((11, 122, 144), (31, 175, 199), (210, 250, 255)),   # droplets
        "la":   ((200, 150, 0), (242, 194, 48), (255, 255, 220)),    # sparkles
        "mana": ((36, 72, 176), (61, 107, 224), (180, 205, 255)),    # wisps
    }

    # --- A hit's splash (Frankie, 11/4; previews in art/) -------------
    # An attack that lands on a monster flings particles outward from the middle of its
    # picture in the hit's element colors, so a hit never reads as a stance switch. A short
    # white flash at the point of impact first. Solid pixels, no smoothing, every other
    # particle dropping out near the end instead of fading. All Claude's numbers, to tune.
    HIT_FX_SECONDS = 0.6
    HIT_FX_PARTICLES = 26
    HIT_FX_FLASH_SHARE = 0.12  # The flash lasts this share of the splash.
    HIT_FX_REACH = 34          # How far a particle flies, in pixels, at the most.
    HIT_FX_RING_REACH = 30     # Water's and spirit's ring grows to this.
    # A plain Attack has no element and no splash now (Frankie, 11/4); the colors stay for the site.
    HIT_FX_PLAIN_COLORS = ((150, 150, 165), (225, 225, 235), (255, 255, 255))
    # Damage that is a hit landing. A poison or burn tick, a seed or a doom is not.
    HIT_FX_CAUSES = ("hit", "stroke", "counter", "spell", "steam", "mana_burn", "cooker")

    # --- An element's job done to a monster (Frankie, 11/4) -----------
    # The stance burst plays over a monster whenever its element's job happens to it, without
    # the color pulse: nature when it is healed or regens, light when it is hasted or buffed,
    # water when it guards, shadow when it is cursed. A status gained -> the element that did it.
    JOB_FX_STATUSES: dict = {
        "regen": "lau", "sprout": "lau", "bloom": "lau", "perennial": "lau",
        "haste": "la", "protect": "la", "ward": "la", "safeguard": "la",
        "weak": "ata", "mbreak": "ata", "calm": "ata", "haunt": "ata",
    }
    JOB_FX_PREFIXES: dict = {"up_": "la", "dn_": "ata"}  # Stat boosts are light, drops are shadow.

    # --- Status icons floating over a monster (Frankie, 11/4) ---------
    # Small pixel pictures in a bobbing row above the monster, instead of a tint or things
    # worn on the picture. Each is drawn in code from a pattern (ui/battle_stage.py), with a
    # one pixel outline so it reads on any background. Claude's numbers, to tune.
    ICON_BOB_PIXELS = 1.5      # The row rises and falls this far...
    ICON_BOB_SPEED = 4.0       # ...this fast, in radians a second.
    ICON_ROW_GAP = 14          # The row's top sits this far above the picture.
    ICON_GAP = 3               # Blank pixels between icons.
    ICON_OUTLINE = (0, 0, 0)
    ICON_HEART_COLOR = (235, 40, 60)
    ICON_HEART_BEATS = 3       # Beats a second; the heart hops on the first fifth of each.
    ICON_SKULL_COLOR = (240, 240, 240)
    ICON_SHADES_COLOR = (20, 20, 20)
    ICON_SHADES_OUTLINE = (255, 255, 255)  # Black glasses need a light edge.
    ICON_FLAME_COLOR = (235, 90, 20)    # Burn: an orange flame with a yellow core (Claude, 11/4).
    ICON_FLAME_CORE = (255, 220, 60)
    ICON_FLAME_FLICKER = 4.0   # Flickers a second.
    ICON_Z_COLOR = (255, 255, 255)
    ICON_Z_SPEED = 0.8         # Cycles a second for the climbing Zs.
    ICON_Z_RISE = 12           # How far each Z climbs, in pixels.
    ICON_Z_STEP = 5            # How far apart the three Zs stand.

    # --- Floating numbers -------------------------------------------
    FLOAT_SECONDS = 1.0
    FLOAT_RISE_PIXELS = 16
    FLOAT_FADE_SHARE = 0.3     # The last part of its life spent fading.
    FLOAT_SPRITE_HEIGHT = 0.95 # Starts this far up a monster picture.
    FLOAT_PARTY_RISE_START = 2
    # A party member's number rises only this much, so it stays on its own
    # row of the fight box, over the HP bar (Claude's call, 10/25).
    FLOAT_PARTY_RISE_PIXELS = 4
    FLOAT_STACK_STEP = 8       # A second number starts this much higher.
    FLOAT_STACK_WINDOW = 0.5
    # A Paddle hit knocks its number out of a monster like a droplet (Frankie, 11/1; only Paddle): it jumps off
    # at a random angle from straight up, each one to the other side from the last, arcs
    # down and fades. Claude's numbers, to tune.
    SPLASH_ANGLE_MIN = 20      # Degrees off straight up, at the least...
    SPLASH_ANGLE_MAX = 55      # ...and at the most.
    SPLASH_SPEED_MIN = 30.0    # Pixels a second it leaves at.
    SPLASH_SPEED_MAX = 45.0
    SPLASH_GRAVITY = 110.0     # Pixels a second, a second, pulling it down.
    # A single big hit's number (Frankie, 11/1: "like Vault") appears, hops once and sits
    # still until it fades, no rising. Vault and Banish are Claude's picks; the numbers are Claude's, to tune.
    BOUNCE_STROKES = ("Vault", "Banish")
    BOUNCE_PIXELS = 6          # How high the one hop goes.
    BOUNCE_SECONDS = 0.3       # How long the hop takes.
    COLOR_PARTY_DAMAGE = (255, 120, 110)
    COLOR_HEAL = (120, 230, 140)
    COLOR_STATUS = (200, 150, 245)
    # Shadow's own color is black, which vanishes on a dark field.
    COLOR_ATA_WORD = (190, 190, 200)

    # --- Target arrow -----------------------------------------------
    CURSOR_SIZE = 4
    CURSOR_GAP = 2
    PICK_CURSOR_GAP = 4        # Cursor tip to an ally's name while picking one.


class BestiarySettings:
    """Layout of the bestiary, one creature per page, in screen pixels.

    The name and the page count on the top row, the picture under them,
    a row of facts, then a block of text rows (the description, where
    it is found, its moves) that scrolls when it is longer than the
    block. Left and right turn the page; up and down scroll.
    """

    NAME_POS = (8, 8)
    COUNT_RIGHT_X = 248        # The "3/8" ends here.
    PICTURE_CENTER_X = 128
    PICTURE_GROUND_Y = 100     # The picture's feet.
    FACTS_Y = 112              # On the 8 pixel text grid, as the cartridge's is (10/22).
    FACT_GAP = 8               # Between one fact and the next on the row.
    PANEL_X = 8
    PANEL_WIDTH = 240          # 30 letters.
    TEXT_TOP_Y = 128
    TEXT_ROWS = 5              # Rows of the scrolling block.
    SCROLL_MARK_X = 248        # The flashing arrows saying there is more (ui/scroll_mark.py).
    COLOR_BODY_TEXT = (215, 215, 215)
    COLOR_BEAST = (200, 170, 120)
    COLOR_ATA_WORD = (190, 190, 200)


class SaveSettings:
    """Save-system tunables."""

    SAVES_DIR = os.path.join(os.path.dirname(__file__), 'saves')
    # Saves kept for testing, checked in: see core/save.py (Frankie, 10/25).
    CHECKPOINTS_DIR = os.path.join(os.path.dirname(__file__), 'checkpoints')
    MAX_SAVE_SLOTS = 3
    AUTOSAVE_SLOT_ID = 0


class StatSettings:
    """How elements turn into stats. See ``core/stats.py``.

    The values come from the shared battle file, so they are the same
    in the browser game. Every number is a placeholder; the shape
    (elements decide stats) is the ruling.
    """

    BASE_POINTS = _STATS["base"]                # Every stat starts here.
    ELEMENT_MULTIPLIER = _STATS["element_multiplier"]  # Each element, on its two job stats.
    STANCE_MULTIPLIER = _STATS["stance_multiplier"]    # The stance in play, on its element's two.
    HP_PER_POINT = _STATS["hp_per_point"]       # Max HP is the HP score x this.


class LoadoutSettings:
    """Ability slots (D-318 to D-320): three per mana row, seven rows.

    The numbers are the shared file's ``rules.slots``.
    """

    # Hina explains the rows the first time Element is opened with her along, once ever
    # (Frankie, 11/3, after Mark never found the rows; the lines are Claude's drafts, 11/4).
    LESSON_FLAG = "hina_taught_rows"
    LESSON_TEACHER = "hina"
    LESSON: tuple = tuple((s.lower(), l) for s, l in _FIELD.pairs('Hina teaches the rows', "LESSON_LINES"))

    # Counter lands in the bank at the Great Boar (Frankie, 11/11): Hina shows how to slot an element in a
    # fight, once ever, and the game makes the player slot it. Claude's drafts, for Frankie to approve.
    SLOT_LESSON_FLAG = "hina_taught_slotting"
    # The in-fight element swap is Equip's second choice, after Weapon (Frankie, 11/11); its name here.
    SLOT_COMMAND = "Element"
    # General and reusable (the first and third lines approved, the second is Frankie's, 11/11).
    SLOT_LESSON: tuple = tuple((s.lower(), l) for s, l in _FIELD.pairs('Hina teaches the rows', "SLOT_LESSON_LINES"))
    # Without her lesson (she is not along, or the player said they know how to fight), the game says just this.
    SLOT_PROMPT = _FIELD.one('Hina teaches the rows', "SLOT_PROMPT")

    PER_ROW = _RULES["slots"]["per_tier"]
    ROWS = _RULES["slots"]["tiers"]
    TURNS_PER_ROW = _RULES["slots"]["turns_per_tier"]
    GIFT_PER_ROW = _RULES["slots"]["gift_per_tier"]
    SHELL_PER_ROW = _RULES["slots"]["shell_per_tier"]
    GUARD_PER_ROW = _RULES["slots"]["guard_per_tier"]
    # Shaka's Light (Frankie, 10/28): the share of the next shadow hit it cuts, and how much more a row.
    WARD_SHARE = _RULES["slots"]["ward_share"]
    WARD_PER_ROW = _RULES["slots"]["ward_per_tier"]
    # Slots unlock over time (Frankie, 11/1): START_OPEN is how many slots are open in each
    # row at the start (row to count), and each of UNLOCK_BOSSES, when any of its flags is set,
    # opens one more slot in its row, as (flags, row).
    START_OPEN = {int(row): count for row, count in _RULES["slots"]["start_open"].items()}
    UNLOCK_BOSSES = tuple((tuple(boss["flags"]), boss["opens"]) for boss in _RULES["slots"]["unlock_bosses"])
    OPENED = "Element slot unlocked"   # Frankie, 11/1; the grid shows which (core/scenes/slot_scene.py)


class BlockSettings:
    """The timed block meter against a monster's plain strokes (Frankie, 10/30).

    Every number here is Claude's pick, 10/30, for Frankie to tune. Lengths
    are pixels of the 256x224 screen, speeds pixels a second, and the meter
    is drawn in the left window, where the commands go.
    """

    # Off in headless runs (tests, autoplay, the checkpoint maker): the
    # strokes land as they always did, unblocked.
    ENABLED = os.environ.get("SDL_VIDEODRIVER") != "dummy"

    # The well's length and height, and where the zone starts from its left end. The mock-up
    # (Frankie, 10/30) has a 146 long well, but the left window is 128 wide, so the well
    # is 118 (a 122 frame, as before) and the zone, gap and speeds are the first look's.
    LENGTH = 118
    HEIGHT = 10
    ZONE_LEFT = 8
    # The yellow zone grows with the defender's Perception: this wide at 0
    # points, a pixel more per point, never under the least or over the most.
    ZONE_BASE = 12
    ZONE_PER_PERCEPTION = 1.0
    ZONE_LEAST = 14
    ZONE_MOST = 42
    # The red arrows' speed grows with the monster's Agility.
    SPEED_BASE = 35
    SPEED_PER_AGILITY = 3.5
    SPEED_LEAST = 35
    SPEED_MOST = 138
    # An arrow's width by the stroke's weight, always odd so it has a middle column:
    # light small, strong big (a row of height per two pixels of width, less the tip).
    BAR_WIDTH = {"light": 5, "medium": 7, "strong": 9}
    # How far apart the arrows start, beyond the right end, one per stroke.
    BAR_GAP = 32
    # An arrow whose middle column is this close to the zone's middle is a perfect catch.
    # It grows with the defender's Luck (Frankie, 11/1): a pixel at 0 Luck, one more
    # per PERFECT_PER_LUCK points, never over the most. Claude's numbers, to tune:
    # 10 Luck, where everyone starts, keeps the old 2.
    PERFECT_PIXELS = 2
    PERFECT_BASE = 1
    PERFECT_PER_LUCK = 8
    PERFECT_MOST = 6
    # A press in the yellow that is not the perfect one is "Parried!" and takes off a share of the
    # stroke's damage that grows the nearer the press is to the sweet spot (Frankie, 11/10): the
    # least at the zone's far edge, the most just off the perfect, on top of Defend's. A perfect
    # takes it all. Claude's numbers, to tune: the middle is the old flat half.
    CATCH_REDUCTION_LEAST = 0.2
    CATCH_REDUCTION_MOST = 0.8
    PARRY_STREAK = 3  # Perfect parries in a row within one attack that earn a Strong counterattack (Frankie, 11/10).

    @classmethod
    def catch_multiplier(cls, grade: float | None) -> float:
        """What is left of a stroke after a parry that was not perfect; ``grade`` 0 (the edge) to 1 (next to the sweet spot)."""
        grade = 0.5 if grade is None else max(0.0, min(1.0, grade))
        return 1.0 - (cls.CATCH_REDUCTION_LEAST + (cls.CATCH_REDUCTION_MOST - cls.CATCH_REDUCTION_LEAST) * grade)

    # Seconds the meter stays after the last bar, and the "Parried!" word's rise.
    LINGER_SECONDS = 0.4
    POP_SECONDS = 0.7
    POP_RISE = 12

    @classmethod
    def zone_width(cls, perception: int) -> int:
        """The yellow zone's width for a defender's Perception."""
        return int(max(cls.ZONE_LEAST, min(cls.ZONE_MOST, cls.ZONE_BASE + cls.ZONE_PER_PERCEPTION * perception)))

    @classmethod
    def perfect_reach(cls, luck: int) -> int:
        """How close to centered a perfect catch must be, for a defender's Luck."""
        return int(max(cls.PERFECT_BASE, min(cls.PERFECT_MOST, cls.PERFECT_BASE + luck // cls.PERFECT_PER_LUCK)))

    @classmethod
    def bar_speed(cls, agility: int) -> float:
        """The red bars' speed for a monster's Agility."""
        return max(cls.SPEED_LEAST, min(cls.SPEED_MOST, cls.SPEED_BASE + cls.SPEED_PER_AGILITY * agility))


class MinigameSettings:
    """The Skills' timed minigames (Frankie, 11/1): every Skill has one, and the stats set how hard.

    The character's stat against the monster's same stat makes the game
    easier or harder (Frankie, 11/1): ``ease`` is 1 when they are even,
    more when the character is stronger, less when the monster is. Which
    stat: physical Skills Strength, mental ones Willpower, magical ones
    Intelligence, Cook Perception (Claude's suggestion, Frankie's yes, 11/1).
    How well the game is played decides whether the Skill works; there is
    no chance roll on top (Frankie, 11/1). This game's numbers alone, all
    Claude's drafts, to tune after playing.
    """

    # Scold and Charm take hold when at least this share of their game was got right,
    # with no roll on top (Frankie, 11/3: stats over dice; Claude's number, to tune).
    HOLD_SHARE = 0.5
    # Ease: the stat share (mine over mine and theirs) moves it this far from 1 either way.
    EASE_SPREAD = 0.8
    EASE_LEAST = 0.6
    EASE_MOST = 1.4
    # The stat each Skill's game is set by (points keys: strength, spirit is Willpower,
    # magic is Intelligence, accuracy is Perception).
    STAT = {
        "paddle": "strength", "pound": "strength", "vault": "strength",
        "scold": "spirit", "charm": "spirit",
        "wili": "magic", "call_the_dead": "magic", "moepapa": "magic", "banish": "magic", "dance": "magic",
        "cook": "accuracy",
    }

    # Kailo's Cook: stir the pot steadily, not fast (Frankie, 11/1). The steadiness is how
    # even the time between steps round the pad is; a spread of STIR_SPREAD (times the
    # ease) or more is no good at all. Fewer than STIR_TURNS turns counts for less.
    STIR_SECONDS = 3.0
    # Pōhuehue's second half (Frankie, 11/3): the fire partner spins the vine round the d-pad for
    # VINE_SECONDS, VINE_FULL_TURNS turns making it as long as it gets, and A cracks it; a crack with
    # the pad last pressed at the top (up or a corner beside it) hooks the enemy. How hard it hits:
    # (VINE_DANCE_FLOOR up to 1 by the dance) times (VINE_SPIN_FLOOR up to 1 by the turns) times
    # VINE_TOP at the top, else 1. Claude's first guesses, to tune after playing: the best is 1.5
    # times the old fixed blow, a fair try about 1.1, a crack off the top about 0.75.
    # Tinju Surya (Frankie, 11/3): the light partner's seals, Charm's Simon game, then the fire
    # partner's punch, Moepapa's one tap on a shrinking circle. The hit: (SUN_SEAL_FLOOR up to 1 by
    # the rounds of seals got, out of SIMON_ROUNDS) times (SUN_PUNCH_FLOOR plus how small the circle
    # was, so up to 1.5; a miss is the floor alone). The same range as Pōhuehue: a quarter to 1.5.
    SUN_SEAL_FLOOR = 0.5
    SUN_PUNCH_FLOOR = 0.5
    VINE_SECONDS = 3.0
    VINE_FULL_TURNS = 5
    VINE_DANCE_FLOOR = 0.5
    VINE_SPIN_FLOOR = 0.5
    VINE_TOP = 1.5
    STIR_SPREAD = 0.6
    STIR_TURNS = 1.5
    # How much of the dish a stir of 0 still gives (1 is the dish at its best).
    STIR_LEAST = 0.4
    # Cook in battle lists the meals made at the pot outside a fight, and one feeds the whole party,
    # served at the start of his next turn (Frankie, 11/4). Its healing grows with tool level: the
    # bag's amount at level 1, COOK_TOP_SHARE times it at COOK_TOP_LEVEL, evenly between. The
    # milestones (Frankie, 11/4): from COOK_SWAP_LEVEL a missing ingredient can be swapped for another
    # of its kind, and a vegetable for a meat or a fish; from COOK_KEEP_LEVEL the ingredients are needed
    # but not used up; from COOK_FREE_LEVEL none are needed.
    COOK_TOP_SHARE = 2.0
    COOK_TOP_LEVEL = 10
    COOK_SWAP_LEVEL = 4
    COOK_KEEP_LEVEL = 7
    COOK_FREE_LEVEL = 10
    # What the Mastery page lists Cook learning by tool level (Claude's words, 11/4).
    COOK_MILESTONES: tuple = ((4, "Swap Ingredients"), (7, "Keep Ingredients"), (10, "No Ingredients"))

    # Hina's Scold: mash A (Frankie, 11/1); this many presses at even ease for the full sulk.
    SCOLD_SECONDS = 3.0
    SCOLD_PRESSES = 14
    SCOLD_PRESSES_LEAST = 8
    SCOLD_PRESSES_MOST = 20

    # Maika's Charm: Simon on A, B, X and Y (Frankie, 11/1). Fast, against a timer. A button
    # lights this long (times the ease), with this gap after it; this many rounds for
    # the full charm.
    SIMON_SECONDS = 9.0
    SIMON_LIT = 0.32
    SIMON_GAP = 0.1
    SIMON_GAP_LEAST = 0.18    # Never less dark between two lights, so a repeat shows (Frankie, 11/1).
    SIMON_READY = 1.0         # The wait after picking Charm before the first light (Frankie, 11/1).
    SIMON_BONUS = 1.0         # Seconds a round got right adds to the clock, up to the full time (Frankie, 11/1).
    SIMON_ROUNDS = 4
    SIMON_MOST = 8

    # Maika's Vault: Banish's circles, one try (Frankie, 11/1). Time to jump, and how long
    # the inner circle takes to shrink away (times the ease).
    VAULT_SECONDS = 3.0
    VAULT_DRAW_SECONDS = 1.0

    # Tawiri's Call: alternate A and B, A B A B, keeping her own rhythm (Frankie, 11/1). Nothing on
    # screen keeps the beat for her: the tighter her own rhythm, the stronger the spirit. The time,
    # how uneven the gaps between presses may be before it counts for nothing (times the ease),
    # how many presses for a full rhythm, and how strong the spirit is at a rhythm of 0.
    CALL_SECONDS = 4.0
    CALL_SPREAD = 0.5
    CALL_PRESSES = 10
    CALL_LEAST = 0.5

    # Escape (Frankie, 11/4): Tawiri's Call on L and R. Alternate the shoulders in a rhythm of your
    # own; the steadier it is, the better the chance of getting away (BattleSettings.ESCAPE_LIMITS,
    # the worst rhythm to the best), and then the chance is rolled. The runner's Speed against the
    # fastest foe's is the ease on ESCAPE_SPREAD, as Intelligence is for the Call. The same shoulder
    # twice is a missed beat. The time, how uneven the gaps may be (times the ease) and how many
    # presses for a full rhythm: Claude's numbers, to tune after playing.
    ESCAPE_SECONDS = 3.0
    ESCAPE_SPREAD = 0.5
    ESCAPE_PRESSES = 8

    # Hina's Dance: a rhythm game on four rows, like Dance Dance Revolution (Frankie, 11/1). The
    # beat, the beats before the first note, how far off a press may be and still count, and how
    # close is perfect (both times the ease). Each move's steps: (beat, button), the button one
    # of the eight; its row is set by the button (ui/dance_meter.py). Claude's patterns, the
    # later moves longer and with half beats.
    DANCE_BEAT = 0.4
    DANCE_LEAD_IN = 3
    DANCE_WINDOW = 0.16
    DANCE_PERFECT = 0.05
    DANCE_STEPS = {
        # Pōhuehue's first half: the nature partner dances the vine up (Frankie, 11/3; Claude's pattern).
        "pohuehue": [(0, "UP"), (1, "X"), (2, "UP"), (3, "X"), (4, "A")],
        # Spring Rain's first half: the nature partner calls the rain down (Frankie, 11/4; Claude's pattern).
        "spring_rain": [(0, "DOWN"), (1, "Y"), (2, "DOWN"), (3, "Y"), (4, "A")],
        "sway": [(0, "RIGHT"), (1, "LEFT"), (2, "RIGHT"), (3, "LEFT"), (4, "A")],
        "breeze": [(0, "UP"), (1, "X"), (2, "RIGHT"), (3, "A"), (4, "DOWN"), (5, "B"), (6, "LEFT"), (7, "Y")],
        "twirl": [(0, "RIGHT"), (1, "DOWN"), (2, "LEFT"), (3, "UP"), (4, "A"), (4.5, "B"), (5, "X"),
                  (5.5, "Y"), (6, "RIGHT"), (7, "LEFT"), (8, "A")],
        "kagura": [(0, "DOWN"), (1, "UP"), (2, "DOWN"), (3, "UP"), (4, "X"), (4.5, "Y"), (5, "A"),
                   (5.5, "B"), (6, "RIGHT"), (6.5, "LEFT"), (7, "UP"), (7.5, "DOWN"), (8, "X"),
                   (8.5, "A"), (9, "Y"), (10, "B")],
    }

    # Tawiri's Moepapa: tap A once as the circle shrinks, the smaller the better, one shot
    # (Frankie, 11/1). A short wait, then the circle shrinks away in this long (times the ease).
    MOEPAPA_READY = 0.5
    MOEPAPA_SHRINK = 0.7
    MOEPAPA_TURNS = 3
    # The nightmare at its best, a share of the sleeper's max HP each turn asleep.
    MOEPAPA_NIGHTMARE = 0.1

    @classmethod
    def ease(cls, mine: float, theirs: float) -> float:
        """How easy a Skill's game is: 1 at even stats, more when ``mine`` is higher, less when lower."""
        share = mine / max(1.0, mine + theirs)
        return max(cls.EASE_LEAST, min(cls.EASE_MOST, 1.0 + cls.EASE_SPREAD * (share - 0.5) * 2))


class BattleSettings:
    """Gameplay tunables for battles.

    Everything read from ``_RULES`` comes from the shared battle file
    and so is the same number in the browser game; change it there.
    The plain literals below are this game's alone.

    Waits are in turn-counter units: after acting, a combatant's
    counter goes up by the wait, and the lowest counter acts next.
    """

    # This game only: the browser test fills its own pockets. Noni, the
    # island's plant medicine, heals in the Potion's place (Frankie, 10/23).
    STARTING_NONI = 5
    # A new game (Frankie, 11/4, after Mark's Episode 1 found Cook empty): Kailo already
    # knows Poi, so Cook lists it from the first fight, and the bag holds what one takes.
    STARTING_MEALS: tuple = ("poi",)
    STARTING_BAG: dict = {"taro": 1, "water": 1}
    NONI_HEAL_AMOUNT = 30  # Frankie, 10/23 (was 35)
    # 'Awa heals more than Noni, as much as the browser's old Hi-Potion
    # (Claude's number, 10/23).
    AWA_HEAL_AMOUNT = 80
    # What a beaten monster drops (D-524), placeholders: pule by its
    # max HP, and the chance it leaves the item it carries (a boss
    # always does).
    DROP_PULE_PER_HP = 0.5
    DROP_ITEM_CHANCE = 0.3

    # The plain Attack, and Kailo's counter kick.
    ATTACK_POWER = _RULES["attack_power"]
    # Damage rolls within +/- this fraction.
    DAMAGE_JITTER = _RULES["damage_jitter"]

    # Physical damage taken while defending.
    DEFEND_MULTIPLIER = _RULES["defend_multiplier"]
    # Physical damage a guard takes for an ally, then the extra factor
    # when the guarded hit is fire, and when it is nature.
    GUARD_MULTIPLIER = _RULES["guard_multiplier"]
    GUARD_AFI_MULTIPLIER = _RULES["guard_afi_multiplier"]
    GUARD_LAU_MULTIPLIER = _RULES["guard_lau_multiplier"]

    STATUS_HIT_CHANCE = _RULES["status_hit_chance"]    # A status takes hold.
    BLIND_MISS_CHANCE = _RULES["blind_miss_chance"]    # A blind physical hit misses.
    SLEEP_TURNS = _RULES["sleep_turns"]                # Turns a sleeper loses.
    POISON_RATE = _RULES["poison_rate"]                # Share of max HP per turn.
    REGEN_TURNS = _RULES["regen_turns"]                # Turns Regen heals for.
    RAIN_TURNS = 3                # Spring Rain falls this many of each one's turns, fire halved (Frankie, 11/4).
    REGEN_RATE = _RULES["regen_rate"]                  # Share of max HP a Regen turn heals.
    POSSESS_TURNS = _RULES["possess_turns"]            # Turns Possess lasts (D-547).
    POSSESS_CHANCE = _RULES["possess_chance"]          # Chance a possessed monster turns on its side.
    SULK_TURNS = _RULES["sulk_turns"]                  # Turns a sulk lasts (Frankie, 10/25).
    # Tawiri's Call (Frankie, 10/25): the spirit's turns, and its share of her max HP and points.
    CALL_TURNS = _RULES["call_turns"]
    CALL_HP = _RULES["call_hp"]
    CALL_STATS = _RULES["call_stats"]
    # Kailo's Cook (Frankie, 10/25): the meal's share of max HP (and the most extra HP
    # past full), what the cure takes away, the dishes' names.
    COOK_HEAL = _RULES["cook_heal"]
    # Kailo's Paddle, his oar Skill (Frankie, 10/31): mash A this long, at most this many hits.
    PADDLE_SECONDS = _RULES["paddle_seconds"]
    PADDLE_MOST = _RULES["paddle_most"]
    # Hina's Banish, her bow Skill (Frankie, 10/31): the time to shoot, how long the inner
    # circle takes to shrink away, the arrow at its best in light strokes, and on the undead.
    BANISH_SECONDS = _RULES["banish_seconds"]
    BANISH_DRAW_SECONDS = _RULES["banish_draw_seconds"]
    BANISH_POWER = _RULES["banish_power"]
    BANISH_UNDEAD = _RULES["banish_undead"]
    # Kailo's Pound, his handwraps Skill (Frankie, 10/31): the time to press a move's
    # buttons, and the moves in the order he learns them.
    POUND_SECONDS = _RULES["pound_seconds"]
    POUND_MOVES = _RULES["pound_moves"]
    # Hina's Dance, her fan Skill (Frankie, 10/31): Pound's twin for healing, in the same time.
    DANCE_MOVES = _RULES["dance_moves"]
    # A slippery enemy gives Paddle and Pound less time (Frankie, 11/1, in place of the dodge
    # roll): each point of its Luck over 10 takes this share off the clock, never below the
    # least. Claude's numbers, to tune: 10 Luck changes nothing, 13 Luck is 6% less.
    SKILL_LUCK_SHAVE = 0.02
    SKILL_LUCK_LEAST = 0.5

    @classmethod
    def skill_seconds(cls, base: float, luck: int) -> float:
        """Paddle's or Pound's time against an enemy with ``luck`` (Frankie, 11/1)."""
        over = max(0, luck - 10)
        return base * max(cls.SKILL_LUCK_LEAST, 1 - cls.SKILL_LUCK_SHAVE * over)
    # Maika's Vault, his spear Skill (Frankie, 11/1): the landing, in full Attacks.
    VAULT_POWER = _RULES["vault_power"]
    # The most a Skill costs, for a perfect game (Frankie, 11/1 late): the bank first, then mana debt.
    SKILL_MANA_MOST = _RULES["skill_mana_most"]
    PADDLE_POWER = _RULES["paddle_power"]  # Each Paddle hit, times a light stroke (Frankie, 11/1 late).
    WILI_POWER = _RULES["wili_power"]      # Each Wili cast (Frankie, 11/1 late; it was Spin's 5).
    # Maika's and Tawiri's Wili, their staff Skill (Frankie, 11/1): spin the d-pad this long, at
    # most this many casts, the mana debt reaching this far below zero.
    WILI_SECONDS = _RULES["wili_seconds"]
    WILI_MOST = _RULES["wili_most"]
    WILI_DEBT_MOST = _RULES["wili_debt_most"]
    COOK_CURES = tuple(_RULES["cook_cures"])
    COOK_DISHES = _RULES["cook_dishes"]
    COOK_LEARN = _RULES["cook_learn"]  # The tool level each dish is learned at (Frankie, 10/31).
    # What each dish takes from the bag, spent when he starts (Frankie, 10/31; the recipes are Claude's draft).
    COOK_RECIPES = _RULES["cook_recipes"]
    CHARM_TURNS = _RULES["charm_turns"]                # Turns Maika's Charm lasts (Frankie, 10/25).
    # How likely Scold and Charm take hold by Willpower, at least and at most (Frankie, 10/25).
    WILL_LEAST = _RULES["will_least"]
    WILL_MOST = _RULES["will_most"]
    BUFF_TURNS = _RULES["buff_turns"]                  # Turns a monster's Protect or Shell lasts.
    PROTECT_MULTIPLIER = _RULES["protect_multiplier"]  # Physical damage taken under Protect.
    SHELL_MULTIPLIER = _RULES["shell_multiplier"]      # Magic damage taken under Shell.
    FOE_STANCE_CHANCE = _RULES["foe_stance_chance"]    # A two-stance monster with no reasons switches (D-596).

    # Mana (D-213 to D-220) and fatigue (D-328, D-329), as the browser
    # battle plays them: every number is in the shared file's
    # ``rules.warmup``. Mana is a meter of up to 7. An Attack is a chain
    # of strokes on one enemy, up to 7 points a turn; a stroke that
    # lands builds its points in mana. A technique costs its ``warmup``
    # in mana. The wait after a turn is what the turn built: each
    # stroke its points, a Skill 7, anything else 1, Defend included.
    _WARM = _RULES["warmup"]
    MANA_CAP = _WARM["cap"]
    MANA_START = _WARM["start"]
    DEFEND_MANA = _WARM["defend"]          # Mana Defend builds.
    STANCE_MANA = _WARM["form"]            # Mana a stance switch builds (D-285).
    ITEM_MANA = 1                          # Mana using an item builds, as Defend does (D-676, Frankie, 10/18); pygame only so far.
    TECH_MANA = _WARM["tech"]              # Mana a Skill builds (Frankie, 10/24).
    FIGHTERS = 3                           # The rest of the party waits on the bench (D-196).
    FOES = 3                               # The most monsters on the field at once, the cartridge's.
    # Monsters too big for company of their own kind: never more than one in a fight (Frankie, 11/12).
    ONE_PER_FIGHT = ("kapre",)
    # A fight of mixed monsters never has more than this many; only a fight of one kind (aghoy) goes past it (Frankie, 11/12).
    MIXED_MAX = 4
    COMBO_MANA = _WARM["combo"]            # Mana a Team Up takes from each partner.
    # What Select says of a battle menu option, held over it (Frankie, 11/1; the words are Claude's drafts).
    HELP = {
        "Attack": "Strike one enemy. Chain light, medium and strong strokes, up to 7 points a turn.",
        # The cost too (Frankie, 11/4, after Mark's Episode 1 found Scold's only by its red bar).
        "Skill": "A little game: play it well and it works better, and costs more. 1 to 7 mana, even below zero.",
        "Element": "Use an element move. It costs mana and hits harder than a stroke. Switch stance here too.",
        "Item": "Use something from the bag on a friend: a Noni, food, a cure or a revive.",
        "Equip": "Change your weapon or move one element. Either ends your turn and builds 1 mana.",
        "Equip Weapon": "Take a spare weapon from the bag. This ends your turn.",
        "Equip Element": "Move one element: bank to a tier, tier to tier, or tier to bank. This ends your turn.",
        "Escape": "Try to run from the fight.",
        "Defend": "Brace yourself. Half damage from hits until your turn, and builds 1 mana.",
        "Team Up": "Two friends strike together. It takes all 7 mana from both, tires both, and the partner must have the very next turn.",
        "Swap": "Trade places with a friend on the bench.",
        "No Skill": "No Skill with this weapon in hand. Switch weapons to get one.",
    }
    TEAM_UP_SIGN = "Team Up >"             # The old sign, kept for the 11/4 previews; page arrows replaced it (Frankie, 11/4).
    WEAPON_MANA = 1                        # Mana changing weapons builds (D-455).
    # Slotting an element in a fight (Frankie, 11/11) ends the turn and builds the same mana as Weapon.
    SLOT_MANA = WEAPON_MANA
    # Escape (D-455): this chance, moved by the runner's Speed against the
    # fastest monster's, kept between the two limits. Claude's numbers.
    ESCAPE_CHANCE = 0.5
    ESCAPE_PER_SPEED = 0.05
    ESCAPE_LIMITS = (0.1, 0.9)
    DODGE_MANA = _WARM["dodge_gain"]       # Mana for dodging or blocking a blow.
    STROKE_POINTS = _WARM["strokes"]["points"]
    STROKE_STEADY = _WARM["strokes"]["steady"]   # Each stroke landed adds this to the next one's chance.
    STROKES: dict = {
        "light": _WARM["strokes"]["light"],
        "medium": _WARM["strokes"]["medium"],
        "strong": _WARM["strokes"]["strong"],
    }
    AUTO_STROKES: tuple = tuple(_WARM["strokes"]["auto"])  # A monster's chain.
    STROKE_POWER = _WARM["attack_power"]   # Times a stroke's own power.
    STROKE_WAIT = _WARM["wait"]["attack"]  # Fatigue per stroke point.
    # Said along the top as a fight opens with one side caught from behind or the side (Frankie, 10/27).
    OPENING_WORDS = {"preemptive": "Preemptive strike!", "ambush": "Ambush!"}
    FATIGUE_OTHER = _WARM["fatigue"]["other"]
    FATIGUE_TECH = _WARM["fatigue"]["tech"]  # A Skill's wait, a full Attack's (Frankie, 10/24).
    FATIGUE_COMBO = _WARM["fatigue"]["combo"]  # A Team Up's wait, for both partners (Frankie, 11/2).
    FATIGUE_DEFEND = _WARM["fatigue"]["defend"]
    FATIGUE_LEAST = _WARM["fatigue"]["least"]
    FATIGUE_DEFEND_LEAST = _WARM["fatigue"]["defend_least"]
    # Accuracy and Evasion: 1% a point over the base of 10. Vitality
    # blocks a blow for half damage.
    PER_ACCURACY = _WARM["accuracy"]["per_accuracy"]
    EVADE_BASE = _WARM["evade"]["base"]
    PER_EVASION = _WARM["evade"]["per_evasion"]
    # The turn-order preview's guess at everyone else's next wait.
    PREVIEW_WAIT = 3


    TURN_ORDER_LENGTH = 7         # Upcoming turns shown after the current one.
    WHY_SECONDS = 1.2             # A greyed row's reason stays up this long (Claude's number, 11/4).
    # Seconds a finished line of battle narration stays up before the
    # scene advances it on its own. Confirm still advances at once.
    NARRATION_HOLD_SECONDS = 0.9
    # Seconds the fight's first commands wait before they take a press.
    FIRST_COMMANDS_SETTLE = 0.4
    # Seconds between one stroke and the next as they play out. Strokes
    # have no line of their own, so this is their rhythm.
    STROKE_BEAT_SECONDS = 0.3
    # The pause between Paddle's hits, rapidfire (Frankie, 10/31; a little longer, 10/31).
    PADDLE_BEAT_SECONDS = 0.12
    WILI_BEAT_SECONDS = 0.24   # Half Paddle's speed (Frankie, 11/1).
    # Seconds between the hit (or dodge) on a guard and its kick back,
    # so the counter reads as an answer (Frankie, 10/28).
    COUNTER_BEAT_SECONDS = 0.45
    # Each Counter kick back is this share of a Flame Kick at Counter's row, so a
    # three-stroke attack answered adds up to about one Flame Kick (Frankie, 11/2;
    # the third is Claude's number, to tune).
    COUNTER_KICK_SHARE = 1 / 3


class UISettings:
    """Tunables for in-game UI presentation, on the 256 by 224 screen."""

    # The bar along the top for "went up!" lines (D-526): seconds each
    # line stays, and where it draws, right of the turn order.
    NOTICE_SECONDS = 2.5
    # B held this long over a dialogue box flies through the rest of the talk, a box every B_FLY_EVERY seconds (Frankie, 11/12).
    B_FLY_AFTER = 1.0
    B_FLY_EVERY = 0.08
    NOTICE_RECT = (28, 4, 224, 20)

    # The message window and the battle HUD: the bottom 80 pixels, five
    # map tiles tall. Eight pixels of padding leaves four rows of text.
    TEXT_BOX_HEIGHT = 80
    TEXT_BOX_PADDING = 8
    TEXT_BOX_BORDER_THICKNESS = 2
    # Every window's corners are rounded this many pixels (D-457).
    WINDOW_CORNER_RADIUS = 4
    # A window's inside shades from the first colour at the top to the
    # second at the bottom: deep ocean, not black (D-451). Claude's pick.
    WINDOW_TOP = (28, 74, 120)
    WINDOW_BOTTOM = (8, 26, 58)
    # The top of a screen the field menu opens, Final Fantasy VI's (Frankie,
    # 10/23): a small box with the screen's name, a help line under it for
    # what the cursor is on (two rows of text), and the list from
    # HEADER_LIST_TOP down. Every edge and word on the 8 pixel grid, so the
    # cartridge draws them in the same places.
    HEADER_LABEL_RECT = (0, 0, 88, 24)
    HEADER_HELP_RECT = (0, 24, 256, 40)
    HEADER_TEXT_X = 16
    HEADER_LIST_TOP = 72

    # Portraits are pixel faces in a ``PORTRAIT_SIZE`` frame, three tiles
    # square (D-449), on the party screen. A smaller face sits centred
    # in the frame, unscaled, until it is redrawn; a bigger one is cut
    # to the frame's middle. Nothing is ever resized. ``PORTRAIT_GAP``
    # is the space between the frame's right edge and the text beside
    # it. Text is placed by the top of its letters, so the frame and the
    # name share a top edge with no nudge.
    PORTRAIT_SIZE = 48
    PORTRAIT_GAP = 8
    PORTRAIT_Y_OFFSET = 0
    # The element line sits one text row under the name.
    ROSTER_ELEMENT_LINE_Y_OFFSET = 16

    # The element icons are 18 pixels square on disk, two more than a
    # tile; they are drawn as they are, never resized. Beside an 8 pixel
    # word an icon is centred on the word, which puts its top
    # ``ELEMENT_ICON_Y_OFFSET`` above the word's top.
    ELEMENT_ICON_SIZE = 18
    ELEMENT_ICON_GAP = 2
    ELEMENT_ICON_WORD_GAP = 4
    ELEMENT_ICON_Y_OFFSET = -5
    ELEMENT_ICON_INLINE_Y_OFFSET = -5

    # The battle HUD splits here: commands, or the narration, on the left; the party's names, bars and HP on
    # the right, the way Final Fantasy lays out its window. The 11/12 flip turned only the fighters and the turn
    # bar, not the window (Frankie, 11/12), so the window is as it was. A submenu (abilities, items) takes the
    # whole width while it is open, as its magic list does.
    COMMAND_PANEL_WIDTH = 128
    COMMAND_PANEL_X = 0        # The commands' panel starts here, on the left; the party's panel is from COMMAND_PANEL_WIDTH on.

    # Rows of the battle menus sit one text row apart.
    COMMAND_MENU_ROW_HEIGHT = 16
    # The stroke points left, a standing bar at the command panel's right edge.
    POINTS_BAR_WIDTH = 4
    STROKE_MENU_NUDGE = 2      # The stroke rows slide left so the hit chances clear the bar (Claude, 11/4).
    POINTS_BAR_GAP = 1
    POINTS_BAR_SPENT = (60, 60, 60)
    ABILITY_MENU_ROW_HEIGHT = 16
    # The Ability menu is a grid (D-450): the mana row's number, then
    # three names of at most 7 letters, so a space always comes before the
    # next move's element tag (Frankie, 10/23), Final Fantasy's spell menu.
    ABILITY_NAME_CHARS = 7
    ABILITY_LABEL_WIDTH = 16   # The row's number to its first name.
    ABILITY_COL_WIDTH = 72     # One name to the next: the tag, 7 letters, a space.
    SLOT_BOX_COLOR = (150, 110, 20)    # An element slot's border: dark gold (Frankie, 11/1).
    SLOT_CURSOR_COLOR = ColorSettings.YELLOW  # The cursor's box: the menus' bright yellow, two pixels, well apart from the dark gold lines (Frankie, 11/1).
    # A filled slot shows the window, with its elements as right triangles cut on the diagonal in the
    # corners: the first top-left, the second bottom-right (the dark-screen element colors on
    # game/answers.md, Frankie 11/1).
    SLOT_FILL_COLORS = {"afi": (0xE0, 0x4A, 0x3A), "wai": (0x1F, 0xAF, 0xC7), "lau": (0x7B, 0xC0, 0x43),
                        "la": (0xF2, 0xC2, 0x30), "ata": (0x8E, 0x44, 0xAD), "mana": (0x3D, 0x6B, 0xE0)}
    # Over the window, each filled slot has a faint wash of its elements, first into second, left to right,
    # so the name sits on something and the corners still stand out (Frankie, 11/1).
    SLOT_WASH_ALPHA = 70               # About 27% of 255.
    SLOT_EMPTY_FILL = (0, 0, 0)        # An open slot with nothing in it: black (Frankie, 11/1).
    SLOT_TAG_WIDTH = 8                # An element tag's width (ui/element_tag.py).
    SLOT_BOX_PAD = 3                  # From a slot's border to its tag.
    # Short names for every move whose name is longer than 7 letters
    # (Frankie, 10/23: Flame Kick is FlmKick, Wave Guard WaveGrd; the rest
    # Claude's, rename freely). Anything not here is cut to 7.
    MOVE_SHORT_NAMES: dict = {
        "Absolution": "Absolve", "Act of Mauga": "ActMaug", "Anglerfish": "Angler",
        "Annotate": "Annote", "Antidote": "Antidot", "Antidote Mist": "AntiMst",
        "Antivenom": "Antivnm", "Backstab": "Bkstab", "Bad Dancing": "BadDanc",
        "Bark Tea": "BarkTea", "Battle Meditation": "Meditat", "Belly Flop": "BlyFlop",
        "Bilge Water": "Bilge", "Bitter Medicine": "BitrMed", "Bitter Smoke": "BitrSmk",
        "Black Spot": "BlkSpot", "Bleed and Gather": "BleedGa", "Blessed Edge": "BlsEdge",
        "Blessing": "Blessng", "Blind Faith": "BlndFth", "Blood Trail": "BldTrl",
        "Boil Over": "BoilOvr", "Boomerang": "Boomrng", "Borrowed Life": "BrwLife",
        "Borrowed Notes": "BrwNote", "Bottle It": "Bottle", "Bright Seal": "BrtSeal",
        "Brilliance": "Brillnc", "Bush Tucker": "BshTuck", "Cartwheel": "Cartwhl",
        "Cast Iron": "CastIrn", "Catalyst": "Catalst", "Cauterize": "Cautrze",
        "Clear Head": "ClrHead", "Coin Toss": "CoinTos",
        "Cross Reference": "CrossRf", "Cure All": "CureAll", "Cure Blind": "CureBld",
        "Cure Poison": "CurePsn", "Cure Sleep": "CureSlp", "Damnation": "Damnatn",
        "Davy Jones": "DavyJns", "Dawn Seal": "DawnSl", "Death Knell": "DthKnel",
        "Death Mark": "DthMark", "Dim Seal": "DimSeal", "Dinner Bell": "DinBell",
        "Dirty Strike": "DrtyStk", "Dirty Trick": "DrtyTrk", "Discipline": "Discipl",
        "Dissertation": "Thesis", "Doldrums": "Doldrum", "Dragon's Breath": "DragBrt",
        "Drill Sergeant": "DrillSg", "Dust Devil": "DstDevl", "Eruption": "Erupt",
        "Evil Eye": "EvilEye", "Eye Drops": "EyeDrop", "Eye of Shaka": "EyeShak",
        "Fan the Flames": "FanFlam", "Feedback": "Feedbck", "Field Dress": "FldDres",
        "Field Dressing": "Dressng", "Field Notes": "FldNote", "Fire Arrow": "FirArrw",
        "Fire Blast": "FirBlst", "Fire Breath": "FirBrth", "Fire Guard": "FirGrd",
        "Fire Knife": "FirKnif", "Fire Rain": "FirRain", "Fire Sentinel": "FirSent",
        "Fire Spring": "FirSprg", "Fire Wheel": "FirWhel", "Fire Whirl": "FirWhrl",
        "Firebomb": "Firebmb", "Firestorm": "Firstrm", "Flame Kick": "FlmKick",
        "Flame Slash": "FlmSlsh", "Focus Beam": "FocBeam", "Follow Me": "FollwMe",
        "Forced March": "FrcMrch", "Glass Sea": "GlasSea", "Golden Hour": "GoldHr",
        "Golden Sun": "GoldSun", "Grand Spiral": "GrSpirl", "Grave Grip": "GrvGrip", "Green Dream": "GrDream",
        "Haste and Slow": "HstSlow", "Heavy Limbs": "HvyLimb", "Heavy Weather": "HvyWthr",
        "Hex Bolt": "HexBolt", "Hex Doll": "HexDoll", "Hide in Shell": "HideShl",
        "Holy War": "HolyWar", "Hurricane Dance": "Hurrcan", "Ice Bath": "IceBath",
        "Inoculate": "Inocult", "Jolly Roger": "JlyRogr", "Judgment": "Judgmnt",
        "Kill Order": "KillOrd", "Kill or Cure": "KillCur", "Lanu's Bounty": "Bounty",
        "Last Stand": "LstStnd", "Lava Burst": "LavBrst", "Leech Seed": "LeechSd",
        "Leviathan": "Leviath", "Lomilomi": "Lomilom", "Long Draught": "LngDrgt",
        "Maelstrom": "Maelstr", "Magnum Opus": "MagOpus", "Mana Leech": "MnLeech",
        "Margin Note": "MrgNote", "Martyr Guard": "MrtyGrd", "Mending Hula": "MndHula",
        "Mental Break": "MindBrk", "Message in a Bottle": "Message", "Mirror Pool": "MirPool",
        "Mirror Sin": "MirSin", "Morning Prayer": "MrnPryr", "Nature Blast": "NatBlst",
        "Nightfall": "Nightfl", "Numbing Agent": "Numbing", "Open Flame": "OpnFlam",
        "Open Wound": "OpnWond", "Oven Mitt": "OvnMitt", "Overdose": "Overdos",
        "Pan Flip": "PanFlip", "Patience": "Patienc", "Peer Review": "PeerRev",
        "Perennial": "Perenl", "Petal Rain": "PetRain", "Pistol Shot": "Pistol",
        "Poison Dart": "PsnDart", "Poultice": "Poultic", "Purgative": "Purgatv",
        "Purification": "Purify", "Purifying Guard": "PureGrd", "Quick Draw": "QckDraw",
        "Radiant Edge": "RadEdge", "Radiant Seal": "RadSeal", "Reckless": "Reckles",
        "Regen and Poison": "RgnPsn", "Revelation": "Reveal", "Ricochet": "Ricoch",
        "Rough Seas": "RghSeas", "Safeguard": "Safegrd", "Sake Gourd": "SakeGrd",
        "Sanctuary": "Sanctum", "Sand in the Eyes": "SandEye", "Scapegoat": "Scapegt",
        "Sea Shanty": "Shanty", "Second Look": "2ndLook", "Second Opinion": "2ndOpin",
        "Set the Bone": "SetBone", "Shadow Blast": "ShdBlst", "Shadow Step": "ShdStep",
        "Shadow Strike": "ShdStrk", "Shaka's Light": "ShakaLt", "Shared Cup": "ShrdCup",
        "Sharkskin": "Shrkskn", "Siva Afi": "SivaAfi", "Sleep Dart": "SlpDart",
        "Sleeping Draught": "SlpDrgt", "Smelling Salts": "Salts", "Smite the Heretic": "Smite",
        "Smoke Bomb": "SmkBomb", "Smoke Out": "SmokOut", "Smoke Ring": "SmkRing",
        "Smoke and Flame": "SmkFlam", "Solar Seal": "SolSeal", "Somersault": "Somrslt",
        "Spirit Blast": "SprBlst", "Spirit Kick": "SprKick", "Spirit Storm": "SprStrm",
        "Spring Guard": "SprgGrd", "Squall Wall": "SqlWall", "Starfall": "Starfal",
        "Status Guard": "StatGrd", "Steam Vent": "StmVent", "Still Water": "StlWatr",
        "Stillness": "Stilnes", "Stir Fry": "StirFry", "Stone Skin": "StnSkin",
        "Storm Call": "StrmCal", "Storm Mirror": "StrmMir", "Study Group": "StudyGp",
        "Sun Blast": "SunBlst", "Sun Salute": "SunSalt", "Sun Slash": "SunSlsh",
        "Thank the Animal": "Thanks", "Thorn Arrow": "ThrnArw", "Thorn Kick": "ThrnKck",
        "Thousand Cuts": "1000Cut", "Thunderhead": "Thundhd", "Tidal Wave": "TdlWave",
        "Tide Guard": "TideGrd", "Tide Veil": "TideVl", "Tide of Life": "TidLife",
        "Tiga Nasib": "TigaNsb", "Tornado Kick": "Tornado", "Toxic Cloud": "ToxCld",
        "Triple Trouble": "Triple", "Turtle Stance": "Turtle", "Twist the Knife": "Twist",
        "Undercurrent": "Undercr", "Undertow": "Undrtow", "Use Every Part": "UseAll",
        "Veiled Seal": "VeilSl", "Venus Flytrap": "Flytrap", "Vigor Seal": "VigSeal",
        "Voice of Mauga": "VoiceMg", "Wasting Curse": "Wasting", "Waterspout": "Wtrspt",
        "Wave Fist": "WavFist", "Wave Guard": "WaveGrd", "Weak Spot": "WeakSpt", "Well Done": "WellDon",
        "Wellspring": "Wellspr", "Whirlwind Kick": "Whrlwnd", "Wild Card": "WildCrd",
        "Wrath of Mauga": "WrathMg",
    }

    # The battle turn-order strip across the top of the battle screen,
    # and the help line under it (the highlighted action's wait and
    # numbers) while a command is being chosen.
    TURN_STRIP_X = 8
    TURN_STRIP_Y = 4
    TURN_STRIP_GAP = 8    # Pixels between one name and the next.

    TYPEWRITER_CHARS_PER_SECOND = 60
    # A story line marked (fast) types this many times quicker; one that ends
    # on a dash is cut off, the next line on at once (Frankie, 10/23).
    FAST_TEXT_TIMES = 3
    # A line marked (quick) types this many times quicker, between the usual
    # and fast, and is cut off on a dash the same way (Frankie, 10/25: fast
    # was too fast for Hina's line at the wake).
    QUICK_TEXT_TIMES = 2
    CUT_OFF = ("—", "-")
    # A cut-off line too long for one box turns its own pages, this many
    # seconds after each is typed, so it needs no button at all (10/26).
    CUT_OFF_PAGE_SECONDS = 0.8
    # The continue marker blinks: this many milliseconds lit, then this many dark (Frankie, 11/1).
    CONTINUE_BLINK_MS = 450
    # A new game's first line types this slowly, letters a second, as the beach
    # fades in from the words' black; lit when it is typed (Frankie, 10/25).
    OPENING_CHARS_PER_SECOND = 25

    MENU_CURSOR_BLINK_HZ = 2.0
    # Menu cursors are solid; the target arrow in a fight pulses between yellow
    # and this dim yellow, never off (Frankie, 10/26).
    MENU_CURSOR_DIM = (128, 110, 0)
    # A list with more past its edge flashes a white arrow there (ui/scroll_mark.py).
    SCROLL_MARK_BLINK_HZ = 2.0
    SCROLL_MARK_ROW_MIDDLE = 4
    # The stance switch's sign turns this many quarter turns a second while
    # the cursor is on its row, and the window over its name flashes the
    # other stance this many times a second (Frankie, 10/26; Claude's numbers).
    SWITCH_SPIN_HZ = 6.0
    SWITCH_FLASH_HZ = 3.0  # From the top of a row's letters to the arrow's middle.
    # Added to a text row to give the pitch of a menu's rows: 0 is one
    # row (16 pixels) per item.
    MENU_ITEM_SPACING = 0
    TITLE_SCREEN_MENU_ITEM_SPACING = 0
    # The cursor's tip sits this far left of a menu row's text.
    MENU_LABEL_OFFSET = 6
    # The fishhook cursor is wider than the old arrow; menus by a window's
    # left edge move their words this much more to the right (Frankie, 11/2).
    MENU_HOOK_ROOM = 8
    # Beside the Team Up list, each partner's mana as a row of pips, one a mana
    # point, lit up to what they have (Frankie's drawing, 11/4; Claude's sizes).
    TEAM_UP_PIP_SIZE = (5, 4)
    TEAM_UP_PIP_GAP = 1
    TEAM_UP_PIP_EMPTY = (40, 55, 90)
    # How the hook moves (Frankie, 11/2; Claude's numbers): how fast it reels to
    # a new row and its line slides to a new column (shares a second), how
    # tight and how damped the spring that swings it under its line, and how
    # often it bobs a pixel while it waits.
    HOOK_REEL_SPEED = 16.0
    HOOK_SLIDE_SPEED = 18.0
    HOOK_SPRING = 260.0
    HOOK_DAMPING = 9.0
    HOOK_BOB_HZ = 0.6

    TITLE_SCREEN_HEADING_X = 56
    TITLE_SCREEN_HEADING_Y = 56
    TITLE_SCREEN_MENU_X = 96
    # NEW GAME and CONTINUE over the sea, under the sun's reflection (ui/title_dawn.py).
    TITLE_SCREEN_MENU_TOP_Y = 152


class FightSwirlSettings:
    """The swirl into a fight from the map (Frankie, 11/9: approved, then changed to close and open).

    It closes: the opening's spiral (``ui/title_dawn.py``) grows over the map, which
    fades to the title's ocean blue, then everything goes dark. It opens: the same spiral
    spins back, the screen black except its arms, and the fight shows through the arms as they
    widen. Set ``ENABLED`` False and fights start as before. The cartridge reads these numbers
    too (``game/snes/tools/make_title.py``).
    """

    ENABLED = True
    CLOSE_TIME = 0.85          # Seconds, map to black (the fight's song starts under it).
    OPEN_TIME = 0.80           # Seconds, black to the whole fight.
    SPIN = 600.0               # Degrees the spiral turns while it closes.
    START_SCALE = 0.05         # The spiral's size at the start (1 is the picture's own).
    END_SCALE = 3.4            # And when closed: big enough to fill the screen.
    OPEN_SCALE = 1.6           # Its size when the fight is whole again.
    OPEN_SPIN = 0.6            # How much of the closing's turn it spins back through.
    OPEN_WIDEN = 70            # Pixels the arms have widened by when the fight is whole.
    BLUE_BY = 0.45             # Fraction of the closing by which the map has faded to blue.
    DARK_FROM = 0.78           # Fraction of the closing at which it all goes dark.
    DURATION = CLOSE_TIME + OPEN_TIME


class ConfirmSettings:
    """The NO / YES box (``core/scenes/confirm_scene.py``).

    Follows Dungeon Digger's dialog: NO first, cancel means NO. There is
    no quit box: the game cannot be quit from inside (Frankie, 10/23).
    """

    NO_INDEX = 0                # NO sits on the left and starts selected.
    YES_INDEX = 1
    LABEL_NO = "No"
    LABEL_YES = "Yes"

    BOX_WIDTH = 160             # Pixels; the warning wraps inside it.
    PADDING = 8                 # Pixels inside the border, top and bottom.
    BORDER_THICKNESS = 2        # Matches the text box border.
    OPTION_GAP = 48             # Pixels between the centres of NO and YES.
    DIM_ALPHA = 160             # Out of 255; dims the scene underneath.
    COLOR_WARNING = (255, 120, 110)   # The "what is lost" line.


class GameOverSettings:
    """The GAME OVER screen after a lost fight (``core/scenes/game_over_scene.py``).

    Final Fantasy VI's (Frankie, 10/24): a dark screen, the words, a short
    pause, then any button goes to the title. No music for now.
    """

    TEXT = "Game Over"
    HOLD_SECONDS = 2.0          # The pause before a button is listened to.


class GridSettings:
    """Tile dimensions for the overworld grid."""

    TILE_SIZE = 16  # Pixels per overworld tile (D-444).


class OverworldSettings:
    """Cell-area layout for the overworld scene.

    One cell is a fixed grid of tiles that fills the whole screen, 16
    across and 14 down (D-444). Crossing the edge swaps to the matching
    neighbor cell in ``WORLD_LAYOUT`` and snaps the sprite to its entry
    tile. Screen-locked -- no scrolling camera at this layer. The
    message window draws over the bottom four rows when it has text.
    """

    # A press this soon after one that closed a talk opens nothing (Mark, 11/12: the last press counted twice).
    TALK_DEAF_SECONDS = 0.2
    COLS = 16  # Tiles wide per cell.
    ROWS = 14  # Tiles tall per cell.
    PIXEL_W = COLS * GridSettings.TILE_SIZE   # 256 px.
    PIXEL_H = ROWS * GridSettings.TILE_SIZE   # 224 px.
    X = 0
    Y = 0

    # Wall character recognised by World.is_wall. Walls block the
    # player's step; the cell renderer draws them as coconut palms.
    WALL_CHAR = "#"
    WATER_CHAR = "~"  # Impassable.
    # A rest stop (D-525): a pond that looks like water and blocks like
    # it; facing it and pressing confirm heals and revives the party.
    SPRING_CHAR = "o"
    # A healing spring twinkles (Frankie, 11/12): this many single pixels, each lit for half of every period.
    SPARKLE_COUNT = 3
    SPARKLE_MS = 1400
    SAND_CHAR = "_"   # Walkable; paths and beaches.
    # A market stall: blocks, and facing it and pressing confirm opens
    # the shop (D-571).
    STALL_CHAR = "m"
    FLOOR_CHAR = "."  # Walkable default, grass.
    # Inside a house (Frankie, 10/22): woven mats to walk on, the wooden
    # wall around the room (ui/walls.py picks each tile's piece), and the
    # black outside it. Both of the last two block.
    MAT_CHAR = "f"
    INSIDE_WALL_CHAR = "w"
    VOID_CHAR = "v"
    # The harbor's pier (Frankie, 10/27): wooden planks over the water,
    # walked on like sand; ui/pier.py picks each tile's piece.
    PIER_CHAR = "="
    # A felled tree's stump (Frankie, 10/28): blocks like the tree. Only the
    # ko'i makes one, for the visit; no room file holds it.
    STUMP_CHAR = "t"
    # Canopy (Frankie, 11/13): a solid wall of palm fronds painted in the Workshop. It blocks like a border
    # wall and is drawn by ui/canopy.py, which picks each tile's piece from its neighbors. The wall round
    # a room's edge ('#' there) is drawn the same way.
    CANOPY_CHAR = "k"
    # Stairs (Frankie, 11/5), painted like any tile and walked on like sand; they lead
    # nowhere yet. Mini World's Ground/Cliff.png steps: stone for outside (grass shows
    # round them), wood for inside (mats show round them); "front" is the steps seen
    # from the front, "side" the steps seen climbing left or right.
    STONE_STAIRS_CHAR = "a"
    STONE_STAIRS_SIDE_CHAR = "b"
    WOOD_STAIRS_CHAR = "c"
    WOOD_STAIRS_SIDE_CHAR = "d"
    STAIRS_CHARS: tuple = (STONE_STAIRS_CHAR, STONE_STAIRS_SIDE_CHAR, WOOD_STAIRS_CHAR, WOOD_STAIRS_SIDE_CHAR)
    # What can be walked on.
    WALKABLE_CHARS: tuple = (FLOOR_CHAR, SAND_CHAR, MAT_CHAR, PIER_CHAR) + STAIRS_CHARS

    # The picture for each cell character: a list of choices, each a
    # (file, tile index) pair in ``AssetPaths.TILES_DIR``, counting 16
    # pixel tiles left to right: Mini World Sprites (CC0) outside, Ninja
    # Adventure's mats inside. The inside wall's picture is only the
    # Workshop's brush; the room draws each wall tile with ui/walls.py.
    # A tile with several choices picks one by its position, so the
    # same map always looks the same. A wall is a palm drawn over grass.
    TILE_PICTURES: dict = {
        FLOOR_CHAR: [("miniworld/Ground/Grass.png", 1)] * 6
        + [("miniworld/Ground/TexturedGrass.png", 1), ("miniworld/Ground/TexturedGrass.png", 2)],
        SAND_CHAR: [("miniworld/Ground/Grass.png", 3)],
        WATER_CHAR: [("miniworld/Ground/Shore.png", 4)],
        SPRING_CHAR: [("miniworld/Ground/Shore.png", 4)],
        WALL_CHAR: [("miniworld/Nature/CoconutTrees.png", n) for n in (2, 3, 4, 5)],
        # The palms' own sheet has the stump, so felling one is a tile swap.
        STUMP_CHAR: [("miniworld/Nature/CoconutTrees.png", 0)],
        # The solid piece of the canopy sheet; ui/canopy.py draws the real tile (edges, corners, ends).
        CANOPY_CHAR: [("canopy/palm-fronds.png", 12)],
        STALL_CHAR: [("miniworld/Buildings/Wood/Market.png", 4)],
        MAT_CHAR: [("interior/floor.png", n) for n in range(4)],
        INSIDE_WALL_CHAR: [("interior/walls.png", 3)],
        VOID_CHAR: [("interior/walls.png", 6)],
        # The middle piece of tools/make_pier.py's planks; only the Workshop's brush.
        PIER_CHAR: [("pier.png", 4)],
        # tools/make_stairs.py (Frankie, 11/10): Mini World's own steps (Cliff.png 40, 33, 61, 54) were
        # pale on pale ground, so these are dark and outlined: stone front and side, wood front and side.
        STONE_STAIRS_CHAR: [("stairs.png", 0)],
        STONE_STAIRS_SIDE_CHAR: [("stairs.png", 1)],
        WOOD_STAIRS_CHAR: [("stairs.png", 2)],
        WOOD_STAIRS_SIDE_CHAR: [("stairs.png", 3)],
    }
    # Of the four palm pictures, these sheet tiles are drawn with coconuts, and only a palm drawn
    # so gives a coconut when chopped (Frankie, 11/12); the other two are bare.
    COCONUT_PALMS: tuple = (3, 5)
    # What is drawn under a character whose picture has see-through parts.
    TILE_UNDER: dict = {
        WALL_CHAR: FLOOR_CHAR, STUMP_CHAR: FLOOR_CHAR, STALL_CHAR: SAND_CHAR, CANOPY_CHAR: FLOOR_CHAR,
        STONE_STAIRS_CHAR: FLOOR_CHAR, STONE_STAIRS_SIDE_CHAR: FLOOR_CHAR,
        WOOD_STAIRS_CHAR: MAT_CHAR, WOOD_STAIRS_SIDE_CHAR: MAT_CHAR,
    }

    # An opened chest's picture in ``AssetPaths.BUILDINGS_DIR``: the closed one
    # with its lid up and the inside empty, drawn by ``tools/make_chest_open.py``
    # since the sheet has no open chest (Frankie, 10/25).
    CHEST_OPEN = "chest_open.png"

    # A building stands on the room's tiles, drawn at its own size (D-577)
    # with its top left corner on its tile, and blocks every tile it
    # covers. Each kind: its picture in ``AssetPaths.BUILDINGS_DIR`` and
    # the tiles it covers, across and down. A picture a few pixels taller
    # than its tiles (the pot) stands on their bottom edge. From Ninja
    # Adventure's TilesetHouse.png: the hale is the thatched house's roof
    # over its door, one story; the tall hale, the chief's house, is the
    # same house whole, two stories; the stall is the awning over three bottles of medicine.
    BUILDINGS: dict = {
        "hale": ("hale.png", (4, 5)),
        "tall_hale": ("tall_hale.png", (4, 7)),
        # The pack's dark log house, a hale's size. Not used for now: Frankie
        # (10/26) saw a hut under construction, kept for somewhere else.
        "lodge": ("lodge.png", (4, 5)),
        "stall": ("stall.png", (3, 2)),
        "baskets": ("baskets.png", (3, 1)),
        "crates": ("crates.png", (2, 2)),
        "pot": ("pot.png", (1, 1)),
        # A chest (Frankie, 10/24): Mini World Sprites' Miscellaneous/Chests.png,
        # the wooden one. Its ``item`` goes in the bag the first time, with its
        # ``line`` if it has one; after that it is empty, and drawn open with
        # ``CHEST_OPEN`` (Frankie, 10/25).
        "chest": ("chest.png", (1, 1)),
        # A wooden sign, Mini World Sprites' Miscellaneous/Signs.png (the second),
        # standing at the old man's stall at night (Frankie, 10/25).
        "sign": ("sign.png", (1, 1)),
        # The lore hints on the map (Frankie, 10/25), drawn from Mini World Sprites'
        # Trees.png and Rocks.png: the Maki Sages' spiral cut into a tree, a Pohaku
        # asleep with two faint eyes, Lanu's carved post with a cup of water, a banyan.
        # Each has its ``look`` lines, said when faced.
        "spiral_tree": ("spiral_tree.png", (1, 1)),
        "pohaku": ("pohaku.png", (1, 1)),
        "lanu_post": ("lanu_post.png", (1, 1)),
        "banyan": ("banyan.png", (1, 1)),
        # A lump of dark lava rock, two shapes (Frankie, 10/29): blocks a beach corner
        # where a palm would clash with the sand and water edge (tools/make_lava_rock.py).
        "lava_rock": ("lava_rock.png", (1, 1)),
        "lava_rock2": ("lava_rock2.png", (1, 1)),
        # An Akua totem, the save point (Frankie, 10/26): a placeholder carved
        # post drawn by ``tools/make_totem.py``, taller than its tile as the pot is.
        "totem": ("totem.png", (1, 1)),
        # The insides' furniture, from Ninja Adventure's bed and camp
        # tilesets: sleeping mats, a bed, a fire pit, a stool, a stump
        # table, a clay jar, a barrel, a rug.
        "mat": ("mat.png", (1, 2)),
        "bed": ("bed.png", (1, 2)),
        "firepit": ("firepit.png", (2, 2)),
        "stool": ("stool.png", (1, 1)),
        "table": ("table.png", (2, 2)),
        "jar": ("jar.png", (1, 1)),
        "barrel": ("barrel.png", (2, 2)),
        "rug": ("rug.png", (2, 2)),
        # The temple of Haka's shrine (Frankie, 11/3; tools/make_shrine.py): the sun altar with
        # Haka's sword in sand, candles, incense, a floor cushion to kneel on, a hanging scroll.
        "sun_altar": ("sun_altar.png", (2, 2)),
        "candles": ("candles.png", (1, 1)),
        "incense": ("incense.png", (1, 1)),
        "cushion": ("cushion.png", (1, 1)),
        "scroll": ("scroll.png", (1, 2)),
        "runner": ("runner.png", (2, 1)),
        # The Kaigara Kame's low table with the board on it (tools/make_kame.py, 10/27).
        "board_table": ("board_table.png", (1, 1)),
        # Kailo's boat, the Meialana (Frankie, 10/27): art/meialana-short.png,
        # seen from the window side, padded to whole tiles. Its hull covers
        # two rows of water; the cabin and the sail rise far over the tiles
        # behind it, drawn over whoever stands there, as every picture
        # taller than its tiles is.
        "meialana": ("meialana.png", (7, 2)),
        # A wild pineapple shrub (Frankie, 11/12; tools/make_shrub.py): pressing on it picks a pineapple,
        # and it is drawn picked clean (``SHRUB_BARE``) until it bears again.
        "shrub": ("shrub.png", (1, 1)),
    }
    SHRUB_BARE = "shrub_bare.png"
    # Facing one of these and pressing confirm opens its keeper's shop, as
    # a market stall tile does.
    SHOP_BUILDINGS: tuple = ("stall",)
    # Buildings walked over, not around.
    FLAT_BUILDINGS: tuple = ("rug", "cushion", "runner")
    # Pixels a building's picture is drawn below its tiles, its bottom tucked
    # behind the pier in front: the Meialana's hull against the pier's north
    # edge, not floating above it (Frankie, 10/27).
    SINK: dict = {"meialana": 6}
    # The door of a building that can be walked into (Frankie, 10/22): the
    # tile of its picture the door is on, across and down from its top
    # left. A building's ``inside`` names the room behind the door. Walking
    # up into the door goes in, onto the gap in the bottom of that room's
    # wall; walking down out of the gap comes back out below the door.
    DOORS: dict = {"hale": (1, 4), "tall_hale": (1, 6), "lodge": (1, 4)}


class ToolSettings:
    """Kailo's field tools on Y and the tool wheel (Frankie, 10/26 to 10/28; systems/tools.py)."""

    # Each job's tools, first to last upgrade; an upgrade replaces the one
    # before it (Frankie, 10/28). The Old Rod is Ama's gift at the harbor
    # (Frankie, 10/28; the scene and fishing itself not built yet); Pono's
    # 'O'o (the digging stick, Pono's) is in its line.
    LINES: dict = {"chop": ("koi",), "fish": ("old_rod",), "dig": ("oo",)}
    # No chopping in Lanu's grove, and never a banyan anywhere (Frankie, 11/3): Hina scolds,
    # or Maika with her away, or Kailo thinks better of it alone. Speaker to (grove, banyan)
    # lines; the words are Claude's placeholders.
    GROVE = "key_room"
    SACRED_SCOLD: dict = _FIELD.keyed_many('The grove scolds', "SACRED_SCOLD_ALL")
    # The wheel's slots, up first then clockwise, and the job in each. Four
    # now, the d-pad's four ways; eight later, the diagonals too.
    WHEEL_SLOTS = 4
    WHEEL: tuple = ("chop", "fish", "dig")
    # How long Y is held before the wheel opens; let go sooner, it is a tap
    # that uses the set tool (Claude's number, 10/28).
    WHEEL_HOLD_SECONDS = 0.25
    # Pixels from the screen's top right to the set tool's icon.
    CORNER_MARGIN = 8
    # The icon shows only this long after the wheel sets a tool, then goes
    # (Frankie, 10/28; the seconds are Claude's).
    CORNER_SECONDS = 1.5
    # Chopping (Frankie, 10/28): ten chops fell a tree for ten wood and leave
    # its stump; five more clear the stump for five more wood, and the ground
    # it stood on can be walked. No mashing: each chop is a swing Kailo is
    # stuck in, standing still while the monsters keep coming. A better ko'i
    # swings quicker, the chops stay the same (Claude's call, 10/28). The
    # trees stand again after REGROW_STEPS steps walked (Frankie, 11/12; it was on leaving the room).
    CHOPS = 10
    # A felled tree stands again after this many steps walked, as crops grow, never on leaving the room
    # (Frankie, 11/12; systems/trees.py).
    REGROW_STEPS = 600
    STUMP_CHOPS = 5
    WOOD_PER_TREE = 10
    WOOD_PER_STUMP = 5
    # Seconds each chop holds Kailo, by ko'i (Claude's number, 10/28).
    SWING_SECONDS: dict = {"koi": 0.6}
    # A chopped tree or stump shakes this many pixels side to side, one step
    # a frame of the pattern, over these seconds.
    SHAKE_PIXELS: tuple = (1, -1, 1, -1, 0)
    SHAKE_SECONDS = 0.25
    WOOD_LINE = _FIELD.one("Chopping and picking", "WOOD_LINE")
    FRUIT_LINE = _FIELD.one("Chopping and picking", "FRUIT_LINE")
    ROOT_LINE = _FIELD.one("Chopping and picking", "ROOT_LINE")
    # A tree in town: the village yells, as it does at digging (Frankie, 11/4, after Mark's Episode 1).
    VILLAGE_CHOP_LINE = _FIELD.one("Chopping and picking", "VILLAGE_CHOP_LINE")


class WalletSettings:
    """The wallet: how many pule the party can hold, and the tiers it is bought in (Frankie, 11/12).

    A wallet is a key item in the bag, one at a time: buying the next replaces the last. The
    cap on pule is what the owned wallet holds. A save without a wallet starts at tier 0.
    Sizes and prices are Claude's numbers with Frankie's yes (11/12); the names are Frankie's
    (11/12). Who sells tiers 2 to 6 is open, so no shop does yet.
    """

    # (item id, name, holds, cost to buy). Tier 0 is the one the party starts with.
    TIERS: tuple = (
        ("wallet_0", "Leaf Pouch", 1000, 0),
        ("wallet_1", "Lauhala Bag", 5000, 800),
        ("wallet_2", "Kapa Pouch", 10000, 4000),
        ("wallet_3", "Shark Pouch", 50000, 8000),
        ("wallet_4", "Honu Box", 100000, 40000),
        ("wallet_5", "Pearl Box", 500000, 80000),
        ("wallet_6", "Chief's Box", 999999, 400000),
    )
    ITEMS: tuple = tuple(t[0] for t in TIERS)
    NAMES: dict = {t[0]: t[1] for t in TIERS}
    # One line each, saying how much it holds (Claude's wording, 11/12).
    HELP: dict = {t[0]: f"Holds {t[2]:,} pule." for t in TIERS}


class BattleBagSettings:
    """The battle bag each fighter carries, and the sizes it is bought in (Frankie, 11/12, after Dragon Quest).

    A bag holds one item per slot, only things used up in battle. Every member starts with the Grass Sash;
    the next size up is bought for one member at a time, as wallets are. The sizes and names are
    Frankie's (11/12). The prices are Claude's placeholders (11/12); who sells the bags is open, so no
    shop does yet.
    """

    # (name, slots, cost to buy). Tier 0 is the one everyone starts with.
    TIERS: tuple = (
        ("Grass Sash", 4, 0),
        ("Coir Belt", 8, 300),       # price: Claude's placeholder
        ("Kapa Satchel", 12, 1500),  # price: Claude's placeholder
        ("Net Bag", 16, 6000),       # price: Claude's placeholder
        ("Voyager Bag", 20, 20000),  # price: Claude's placeholder
    )
    # The starting fill (Claude's choice, 11/12): Noni to this many slots under the bag's size, so a
    # Life Totem fits, then one Life Totem each while there are any, then Noni into what is left.
    START_ROOM_FOR_TOTEM = 1


class ItemSettings:
    """What the items in the bag are called, and the lontar."""

    # The name an item shows in the bag and the shops; an item not here
    # shows its id.
    NAMES: dict = {
        "counter_shell": "Counter",  # a lontar shows the move's name (Frankie, 10/23)
        "drain_shell": "Drain",
        "blanch_shell": "Wave Fist",  # Kailo's, sold in the hunters' lodge (Frankie, 11/7); the id keeps the old name Blanch, since saves store it (11/10)
        "nature_blast_shell": "Nature Blast",  # Maika's, the same (Frankie, 11/7)
        "flambe_shell": "Flambé",  # Kailo's, sold in the hunters' lodge (Frankie, 11/10; the price is Claude's)
        "osmose_shell": "Osmose",
        "shakas_light_shell": "Shaka's Light",  # sold in Kulaiwi's temple, for the light characters who join later (Frankie, 11/10)  # Maika's, the same (Frankie, 11/10)
        "revive_shell": "Revive",  # Hina's, the Lanu sage's gift for a cup of water (Frankie, 11/3)
        "haste_shell": "Haste",  # Hina's, sold in Kulaiwi's temple (Frankie, 11/3)
        "cure_shell": "Cure",  # Hina's, in the crossroads chest (Frankie, 11/4)
        "seer_shell": "Seer's Shell",
        "smoke_bomb": "Smoke Bomb",  # Frankie's idea, 11/12: who sells it and for how much is open
        "seed_hp": "Seed of Vitality", "seed_strength": "Seed of Strength",
        "seed_magic": "Seed of Intelligence", "seed_vitality": "Seed of Endurance",
        "seed_spirit": "Seed of Willpower", "seed_speed": "Seed of Agility",
        "seed_accuracy": "Seed of Perception", "seed_evasion": "Seed of Luck",
        "wheat": "Wheat", "noodles": "Noodles", "broth": "Broth", "saimin": "Saimin",
        "taro": "Taro", "poi": "Poi", "water": "Water", "egg": "Egg", "seaweed": "Nori",
        "taro_seed": "Taro Seed", "wheat_seed": "Wheat Seed",
        # The stew's ingredients (Frankie, 10/30): fish, soy sauce and the two seed-only crops.
        "fish": "Fish",  # the kind, as the stew and the Cook name it; no item is plain Fish (Frankie, 11/2)
        # Every fish is a kind of fish (Frankie, 11/2; the kinds are Claude's picks): eel is the rare catch.
        "mackerel": "Mackerel", "snapper": "Snapper", "mullet": "Mullet", "mahimahi": "Mahi-mahi",
        "tuna": "Tuna", "eel": "Eel",
        # Cooked by itself, or by kind of ingredient (Frankie, 11/2; the names are Claude's).
        "grilled_eel": "Grilled Eel", "smoked_eel": "Smoked Eel", "poke": "Poke",
        "baked_taro": "Baked Taro", "baked_uala": "Baked 'Uala", "roast_breadfruit": "Roast Breadfruit",
        "roast_coconut": "Roast Coconut", "grilled_pineapple": "Grilled Pineapple", "baked_noni": "Baked Noni",
        "toasted_nori": "Toasted Nori", "boiled_egg": "Boiled Egg", "grilled_akai_lau": "Grilled Onion",
        "toasted_wheat": "Toasted Wheat", "baked_pia": "Baked Pia",
        "meat_stew": "Meat Stew", "fish_stew": "Fish Stew", "mixed_vegetables": "Mixed Veggies",
        "fruit_bowl": "Fruit Bowl", "vegetable_soup": "Veggie Soup",
        "dubious": "???",  # a mix that makes nothing; whoever eats it gets sick (Frankie, 11/2; the name may change)
        "awapuhi": "'Awapuhi", "oo": "'O'o", "uala": "'Uala", "akai_lau": "Akai Lau",
        "uala_seed": "'Uala Seed", "akai_lau_seed": "Akai Seed",  # short to fit the NO / YES box (Claude's name, 10/30)
        "breadfruit": "Breadfruit", "niu": "Coconut", "pineapple": "Pineapple",  # niu was Niu (Frankie, 11/2)
        "salt": "Salt", "pork": "Pork", "soy_sauce": "Māla Shoyu",  # a key item (Frankie, 11/1); plain "shoyu" is the future ingredient
        "cooked_pork": "Roast Pork",  # it was Cooked Pork (Frankie, 11/2)
        "cooked_fish": "Grilled Fish", "inamona": "'Inamona", "kukui_nut": "Kukui Nut", "fried_egg": "Fried Egg",
        "boar_tusk": "Boar Tusk",
        **WalletSettings.NAMES,  # the wallets, key items (Frankie, 11/12)
        "battle_bag": "Bag Upgrade",  # the shop row for the next size up; the member is picked after (Frankie, 11/12)
        "kohuapua": "Kohuapua",  # the stew for Pono's wake (Frankie, 10/30)
        "koi": "Ko'i",  # the stone adze in his dad's chest (Frankie, 10/26)
        "bait": "Bait",  # the angler's, for fishing (Frankie, 11/2)
        "old_rod": "Old Rod",  # Ama's gift, the first fishing rod (Frankie, 10/28)
        "wood": "Koa Wood",  # the first material, koa (Claude's pick of the wood, 10/26)
        # The raw plants are ingredients and the bought medicines carry a second word, so
        # the bag never shows two things called Noni or 'Awa (Claude's names, 10/29).
        "noni_fruit": "Noni", "awa_root": "'Awa Root",
        "ramen": "Ramen", "noni_juice": "Noni Juice", "awa_drink": "'Awa", "ulu_poi": "'Ulu Poi",
        "kulolo": "Kulolo", "laulau": "Laulau",
        "puaa_anana": "Pua'a Ananá",
        "chow_fun": "Chow Fun",  # pork and noodles (Frankie, 11/4)
        "haupia": "Haupia", "pia": "Pia",  # coconut and pia make haupia (Frankie, 10/29; in the game 11/2)
        "coconut_water": "Coconut Water",  # niu and water (Claude's pick, Frankie's yes, 11/4); Cook's fatigue dish (Frankie, 10/29)
        "ginger_tea": "Ginger Tea",  # 'awapuhi and water (Frankie, 11/2), the same tea as Kailo's Cook  # pork and pineapple, a Lanuloa dish (Frankie, 11/2: ananá in the name; the rest is Claude's)
        "noni": "Noni Pulu", "awa": "'Awa Tonic", "life_totem": "Life Totem", "kukui": "Kukui", "ti_leaf": "Ti Leaf", "olena": "'Ōlena",
        # Weapons and relics in the bag go by their own names (Frankie, 10/24).
        **{entry["id"]: entry["name"] for entry in SHARED["weapons"] + SHARED["relics"]},
    }
    # What heals from the bag, in a fight or out, and by how much: the
    # plant medicine, Noni and 'Awa, and the dishes in the shared file's
    # ``cooking`` (food more than medicine, Noni then poi then saimin, Frankie 10/28; cooked fresh in a fight by Kailo's Cook,
    # each heals half again as much).
    # Every food ingredient can be eaten as it is, for a little HP, and is
    # worth more cooked (Frankie, 10/23).
    INGREDIENT_HEAL = 5
    INGREDIENTS: tuple = ("wheat", "taro", "noodles", "broth", "egg", "seaweed",
                          "breadfruit", "niu", "pineapple", "salt", "pork", "kukui_nut",
                          "noni_fruit", "awa_root", "awapuhi", "uala", "akai_lau", "pia",
                          "mackerel", "snapper", "mullet", "mahimahi", "tuna", "eel",
                          # Ti leaf (it was a medicine) and ramen (it was a meal) are ingredients
                          # so laulau and saimin still cook in a pot that takes only ingredients
                          # (Frankie, 11/2). Ti leaf still cures and heals nothing; ramen heals its own.
                          "ti_leaf", "ramen",
                          # Roast pork goes back in the pot too, for chow fun, so what a burning boar
                          # drops is not wasted (Claude's pick, 11/4). It still heals its own 50.
                          "cooked_pork")
    # Food (Frankie, 10/29): a chopped tree now and then drops breadfruit, a
    # coconut or a pineapple (pineapple will come from bushes later). Eaten
    # from the bag they heal FRUIT_HEAL, more than a plain ingredient and less
    # than Noni (Claude's call, 10/29; Noni heals 30).
    FRUITS: tuple = ("breadfruit", "niu", "pineapple")
    FRUIT_HEAL = 10
    # The kukui nut (Frankie, 10/29) is an ingredient apart from Kukui, the oil
    # that cures a burn; a chopped tree drops it as it drops a fruit (Claude's
    # call). It is not food, so it heals as a plain ingredient does.
    # Noni and 'awa root (Frankie, 10/29: ingredients; the poultice and the tonic stay
    # the bought medicines) drop from chopped trees too, for now (Claude's call, 10/29).
    PLANT_DROPS: tuple = ("noni_fruit", "awa_root")
    # Niu comes only from chopping trees (Frankie, 10/30) and the stew needs it, so it
    # has a chance of its own on every felled trunk, apart from the random pick of the
    # rest (Claude's number, 10/30: it would be one tree in fifty otherwise).
    NIU = "niu"
    # Only a palm drawn with coconuts can give one (Frankie, 11/12), about half the palms, so the
    # chance on those is doubled to keep the same coconuts overall (Claude's number, 11/12).
    NIU_DROP_CHANCE = 0.5
    # Pineapple grows on shrubs and in the garden, never on trees (Frankie, 11/12).
    TREE_DROPS: tuple = ("breadfruit", "kukui_nut", *PLANT_DROPS)
    # One chopped tree in TREE_DROP_CHANCE gives one fruit or kukui nut when it falls (the
    # trunk, not the stump), picked at random (Claude's number, 10/29).
    TREE_DROP_CHANCE = 0.15
    # Salt (Frankie, 10/29): the old man's stall sells it. Not food, so it heals nothing.
    SALT = "salt"
    # The dishes the pot makes with salt (Frankie, 10/28 and 10/29), the meat
    # cooked, the candlenut roasted, the egg fried. Cooked food heals more than
    # medicine (Claude's numbers, 10/29: under poi's 40 except the pork).
    # Cooked fish is salt and fish (Frankie, 11/2); its 45, under the pork, is Claude's.
    SALT_DISHES: dict = {"cooked_pork": 50, "cooked_fish": 45, "inamona": 35, "fried_egg": 35}
    # Dishes the pot makes without salt (Frankie, 10/29; the numbers are Claude's).
    # Ramen sits between poi (40) and saimin (55), and saimin stays the best. Noni
    # juice is cooked food, so over the Noni Pulu's 30. The 'awa drink gives only
    # HP, as the tonic does (mana comes only from moving).
    # Ramen and fish cake will also make saimin once fish cake is in the game.
    POT_DISHES: dict = {"ramen": 48, "noni_juice": 35, "awa_drink": 42, "ulu_poi": 42, "kulolo": 46, "laulau": 52, "puaa_anana": 50, "chow_fun": 52, "haupia": 44,
                       # Claude's numbers, 11/2: a food cooked by itself a little over raw, the stews like the meals.
                       "grilled_eel": 50, "smoked_eel": 60, "poke": 50,
                       "baked_taro": 12, "baked_uala": 12, "roast_breadfruit": 15, "roast_coconut": 15,
                       "grilled_pineapple": 15, "baked_noni": 12, "toasted_nori": 10, "boiled_egg": 12,
                       "grilled_akai_lau": 10, "toasted_wheat": 10, "baked_pia": 12,
                       "meat_stew": 50, "fish_stew": 48, "mixed_vegetables": 25, "fruit_bowl": 25, "vegetable_soup": 30,
                       "dubious": 0}
    # Seaweed (Frankie, 10/29): broth is seaweed and water. Found on the beach
    # (``systems/seaweed.py``); never sold by a shop.
    SEAWEED = "seaweed"
    # Water (Frankie, 10/28): poi is taro and water, and water is free from
    # the river or a pond (Claude's suggestion, taken). An ingredient that
    # is not food, so it heals nothing, and free, so no shop pays for it.
    WATER = "water"
    # Eggs (Frankie, 10/28): from the village hens (``systems/hens.py``) and
    # the Papanok, an ingredient for noodles.
    EGG = "egg"
    # What the stall buys besides the ingredients (Frankie, 10/28): fish. None
    # in the demo yet; fishing comes with its minigame.
    # Every fish is a kind (Frankie, 11/2; it was one plain fish): the stall buys them all.
    FISH: tuple = ("mackerel", "snapper", "mullet", "mahimahi", "tuna", "eel")
    # The kinds of ingredient the pot mixes by (Frankie, 11/2, as in Breath of the Wild;
    # ``systems/cooking.py``); the sorting is Claude's. Salt seasons and goes with anything.
    FOOD_GROUPS: dict = {
        "meat": ("pork",),
        "fish": FISH,
        "vegetable": ("taro", "uala", "akai_lau", "breadfruit", "seaweed", "pia"),
        "fruit": ("pineapple", "noni_fruit", "niu"),
        "water": ("water",),
    }
    SEASONINGS: tuple = ("salt",)
    DUBIOUS = "dubious"
    # Raw food (Frankie, 11/2): raw pork makes whoever eats it sick, but for Gen'emon, who can
    # eat raw meat, and Ren, a shark, who can eat anything; raw fish too, but for the Nuitagata (Leilagi among them, culturally), Gen'emon
    # and Ren, who is a shark. Sick is poison in a fight; out of one it takes SICK_SHARE of
    # their max HP at once (Claude's number), never the last one.
    RAW_MEAT_EATERS: tuple = ("genemon", "ren")
    RAW_FISH_EATERS: tuple = ("kailo", "hina", "tawiri", "maika", "paku", "olola", "leilagi", "genemon", "ren")
    SICK_SHARE = 0.1
    # A dish eaten raw counts as its raw food: poke is raw fish.
    RAW_DISHES: dict = {"poke": "fish"}
    # Monster loot, what the lodge buys besides gear (Frankie, 10/28): the
    # parts monsters drop, like the Nuno's toenail. None in the demo yet; a
    # key item (the Great Boar's tusk) is not loot and never sells.
    LOOT: tuple = ()
    # Materials (Frankie, 10/26), for repairing and making things, later
    # smithing too: wood, chopped from the trees in the woods with the ko'i.
    # They go in the bag the crafts draw on.
    MATERIALS: tuple = ("wood", "bait")
    # Who will not eat what goes by faith or people (Frankie, 11/2; ``systems/diet.py``):
    # Māla is strictly vegetarian, eggs fine; gajas, as Tahji the Luminary is, cannot eat
    # meat or fish; the Golden Sun refuses only pork; Wai'Ki eats no meat but fish. Everyone else eats anything, and
    # anything made with a refused food is refused too. A villager goes by the name shown.
    FAITH_REFUSES: dict = {"mala": ("meat", "fish"), "gaja": ("meat", "fish"), "golden_sun": ("pork",), "waiki": ("meat",)}
    FAITHS: dict = {"hina": "mala", "luminary": "gaja", "genemon": "waiki", "jago": "golden_sun", "agent": "golden_sun"}
    # What each raw food is, for those rules: pork is a meat, fish is fish. A new meat
    # (chicken) is ("meat",): the Golden Sun eats it, Māla and Wai'Ki do not.
    FOOD_KINDS: dict = {"pork": ("pork", "meat"), "fish": ("fish",), **{f: ("fish",) for f in FISH}}
    DIET_BY_NAME: dict = {"Gen'emon": "genemon"}
    # What each says when handed one: Hina indignant (Frankie, 11/2, his words); Gen'emon's
    # is Claude's draft in his slow way. The rest say "No, thank you." until they have one.
    REFUSE_LINES: dict = {
        "hina": "I don't eat anything with a face!",
        "genemon": "No... pork... for me... thank you...",
    }
    # Sarjana is a Polished Mirror Shakan, loose on the pork rule (Frankie, 11/2): handed pork he
    # eats it and says he shouldn't, unless Hina or Damar is in the fight with him to scold him
    # (only in fights; from the bag out of one he just eats it), and then he puts it down and nothing is spent; the Agent says nothing
    # (Frankie, 11/2). The first of them in party order speaks. The lines are Claude's drafts.
    PORK_GUILT: dict = {
        "who": "sarjana",
        "line": "I really shouldn't... Don't tell anyone in Kota Emas.",
        "scolds": {
            "hina": "Sarjana! You know better than that.",
            "jago": "Pork. And you call yourself a Shakan.",
        },
        "backs_down": "All right, all right. I wasn't that hungry.",
    }
    # Key items (Frankie, 10/28): the field tools (``ToolSettings.LINES``) and
    # what the story asks for, such as the Great Boar's tusk. Never sold.
    KEY_ITEMS: tuple = ("koi", "old_rod", "oo", "boar_tusk", "kohuapua", "soy_sauce", *WalletSettings.ITEMS)
    HEALS: dict = {
        "noni": BattleSettings.NONI_HEAL_AMOUNT,
        "awa": BattleSettings.AWA_HEAL_AMOUNT,
        **{dish["id"]: dish["heals"]
           for dish in SHARED["cooking"]["dishes"]},
        **dict.fromkeys(tuple(i for i in INGREDIENTS if i not in ("salt", "ti_leaf")), INGREDIENT_HEAL),
        **dict.fromkeys(FRUITS, FRUIT_HEAL),
        **SALT_DISHES,
        **POT_DISHES,
    }
    # The plant medicine that cures (Frankie, 10/23): used in a fight on an
    # ally, it takes away these ailments. Ailments last only the fight, so
    # out of one these only show their help line.
    # An item that raises the fallen, a spiritual one, not medicine (Frankie, 10/30; the
    # Life Totem since 11/1, it was the Ola Tonic Maika sold; its half of max HP is Claude's
    # draft): item id to the share of max HP the fallen ally gets up with, the same half as
    # the Revive move. Monsters drop it, chests hold it, and Kulaiwi's temple sells it, dear
    # (Frankie, 11/3; until then it was never sold).
    REVIVES: dict = {"life_totem": next(m for m in SHARED["moves"] if m["id"] == "revive")["revive_share"]}
    CURES: dict = {
        "kukui": ("burn",),
        "ti_leaf": ("sleep", "possess"),
        "olena": ("poison",),
        # From the pot, the same as the Cook's Ginger Tea in a fight (Frankie, 11/2).
        "ginger_tea": tuple(BattleSettings.COOK_CURES),
        # 'Fatigue' is not an ailment: it takes the fatigue away, so their turn comes next (Frankie, 11/4).
        "coconut_water": ("fatigue",),
    }
    # Dishes that cure rather than heal: food all the same.
    CURE_DISHES: tuple = ("ginger_tea", "coconut_water")
    # A lontar, an ELEMENT (Frankie, 10/22; a lontar since 10/24): used
    # from Items, Hina reads it, the member learns the move (the party flag
    # ``<member>_learned_<move>``) and it is gone. Item id to (member, move
    # id in battle.json). The ids still say shell, so older saves keep it.
    # Maika's Drain is sold beside Counter, not known from the start
    # (Frankie, 10/26).
    # Hina's Haste is sold in Kulaiwi's temple, dear (Frankie, 11/3: one more light element for
    # her; Haste and its price are Claude's picks). She reads it to herself.
    # The Counter lontar is no longer sold (Frankie, 11/10: Kailo learns it at the Great Boar);
    # it stays here so a save that holds one still reads it.
    SHELLS: dict = {"counter_shell": ("kailo", "counter_guard"), "drain_shell": ("maika", "drain"),
                    "haste_shell": ("hina", "haste"), "revive_shell": ("hina", "revive"),
                    "cure_shell": ("hina", "cure_status"),
                    "blanch_shell": ("kailo", "tide_kick"), "nature_blast_shell": ("maika", "nature_blast"),
                    "flambe_shell": ("kailo", "flambe"), "osmose_shell": ("maika", "osmose"),
                    "shakas_light_shell": ("hina", "shakas_light")}  # the last two: the lodge, 11/7; Hina's Cure, the crossroads chest (Frankie, 11/4)
    # Everything the hunters' lodge sells is a kapa, and so are Cure and Revive (pure nature moves are never
    # lontars, Frankie, 11/10). The demo's lontars are only Haste, Shaka's Light and Green Dream.
    # A kapa is painted bark cloth with the move drawn step by
    # step: no reader needed, the one it is for learns it alone, and it does not start the first
    # lontar talk (Frankie, 11/10). The rest of SHELLS are lontars: Hina reads them.
    KAPAS: frozenset = frozenset({"drain_shell", "blanch_shell", "nature_blast_shell", "flambe_shell", "osmose_shell",
                                          "cure_shell", "revive_shell"})
    # What is said the first time Kailo learns from a lontar, speaker id
    # and line (Frankie's words, 10/24): he cannot read, so Hina reads it.
    # Once only, and only his (Frankie, 10/26); READ_FLAG marks it said.
    READ_TALK: tuple = (
        ("kailo", "...that's right, I can't read"),
        ("hina", "Here, give it to me, I'll read it for you."),
    )
    # The first time the party gets or reads any lontar, with Kailo and Hina along (Frankie, 11/10;
    # systems/lontar_talk.py). It never names the move. Speaker, line.
    FIRST_FLAG = "first_lontar_talk"
    FIRST_TALK: tuple = (
        ("Kailo", "There's your squiggly marks again."),
        ("Hina", "They're not squiggles, Kailo. It's writing. The Bandari write everything down."),
        ("Hina", "This is a lontar. They dry a palm leaf, scratch the letters in with a knife, and rub soot in so they show."),
        ("Kailo", "So it's a leaf that knows a move."),
        ("Hina", "A leaf that remembers one. Someone wrote down how it's done."),
        ("Kailo", "Do they write recipes?"),
        ("Hina", "...Yes, Kailo. They write recipes."),
    )
    # With Hina away, nobody can read a lontar: Kailo says so and keeps it
    # for later (Frankie, 10/31). Speaker id and line.
    NO_LEARNER = "Nobody can learn this yet."
    NO_READER: tuple = ("kailo", "I'll need Hina to read this.")
    READER = "hina"
    READ_TALK_MEMBER = "kailo"
    READ_FLAG = "hina_read_to_kailo"
    # The seeds (Frankie, 10/22): one per stat, named plainly, used from
    # Items on a member, it raises that stat by SEED_POINTS, as a rise from
    # use in a fight does (Claude's number). Item id to stat key.
    # The crop seeds (Frankie, 10/29): the old man sells them, and Hina's
    # replanting uses the matching one. Not stat seeds, so not in SEEDS.
    CROP_SEEDS: tuple = ("taro_seed", "wheat_seed", "uala_seed", "akai_lau_seed")
    # A crop seed used from the bag: where it goes instead (Frankie, 11/5, Mark's Episode 5: A did nothing).
    PLANT_WHERE_LINE = "Plant it in a bare patch."
    SEEDS: dict = {
        "seed_hp": "hp", "seed_strength": "strength", "seed_magic": "magic",
        "seed_vitality": "vitality", "seed_spirit": "spirit", "seed_speed": "speed",
        "seed_accuracy": "accuracy", "seed_evasion": "evasion",
    }
    SEED_POINTS = 1
    # The Items screen's help line for what is not a heal, a lontar or a
    # seed (those say what they do from the numbers), and the words after
    # a heal's number. Claude's words, 10/23; what it does comes first, since a
    # narrow help line (the shop's) keeps only the first sentences (10/24).
    HELP: dict = {
        # Frankie, 11/6: a description puts its effect first and never repeats the item's name; a heal's
        # "Recovers # HP." is made from its number (core/scenes/inventory_scene.py), so what is here is
        # only a short rule that goes with it. Every line fits the shop's box whole (tests/test_item_help.py).
        # A description only describes the item and never names a character, a key item's included (Frankie, 11/13).
        "seer_shell": "Scans one enemy in a fight.",
        "smoke_bomb": "The whole party flees a fight at once.",
        "taro_seed": "Plant in soil.",
        "wheat_seed": "Plant in soil.",
        "uala_seed": "Plant in soil.",
        "akai_lau_seed": "Plant in soil.",
        "dubious": "",
        "awapuhi": "",
        "oo": "Dig soft ground with Y.",
        "water": "Fresh water from the river.",
        "salt": "Cooks meat, eggs and nuts.",
        "soy_sauce": "The stew needs it.",
        "pork": "Raw, it makes you sick.",  # Mark's Episode 5
        "ginger_tea": "Wakes the sleeping in a fight.",
        "coconut_water": "Takes an ally's fatigue.",
        "life_totem": "",
        "kukui": "Cures a burn in a fight.",
        "ti_leaf": "Cures sleep and confusion.",
        "olena": "Cures poison in a fight.",
        "boar_tusk": "Curved and sharp, from a wild boar.",
        **WalletSettings.HELP,  # how much each wallet holds (Frankie, 11/12)
        "battle_bag": "The next size up, for one member.",  # Claude's words, 11/12
        "kohuapua": "Pork and eggs in coconut.",  # Claude's words, 11/13
        "koi": "For chopping wood.",
        "old_rod": "Set it to Y to fish.",
        "bait": "Draws more fish on the rod.",  # Claude's words, 11/4
        "wood": "For repairing and making things.",
    }
    # What each item with a name that is not English is, in English, said first on every
    # help line so the word always shows (Frankie, 10/30; the help window holds two lines
    # and drops whole sentences from the end). Claude's glosses; kept short.
    ENGLISH: dict = {
        "uala": "Sweet potato", "uala_seed": "Sweet potato seed", "baked_uala": "Sweet potato",
        "poke": "Raw fish salad", "mahimahi": "Dolphinfish", "baked_noni": "Indian mulberry", "baked_pia": "Arrowroot",
        "akai_lau": "Green onion", "akai_lau_seed": "Green onion seed", "awapuhi": "Wild ginger",
        "poi": "Taro paste", "ulu_poi": "Breadfruit paste", "laulau": "Pork in ti leaf", "puaa_anana": "Pineapple pork", "chow_fun": "Fried noodles","haupia": "Coconut pudding", "pia": "Arrowroot",
        "kulolo": "Taro pudding", "inamona": "Candlenut relish", "saimin": "Noodle soup",
        "awa_root": "Kava root", "awa_drink": "Kava drink", "awa": "Kava tonic",
        "noni_fruit": "Indian mulberry", "noni": "Noni poultice", "kukui_nut": "Candlenut",
        "kukui": "Candlenut oil", "olena": "Turmeric",
        "oo": "Digging stick", "soy_sauce": "Soy sauce", "koi": "Stone adze", "kohuapua": "Egg braise",
        "ili": "Woven fan", "pedang": "Straight sword", "mandau": "Dayak sword",
        "kampilan": "Long war sword", "tokotoko": "Staff", "kookoo": "Staff",
        "gohei": "Wand", "golden_gohei": "Golden wand", "sarashi": "Cloth wraps",
        "siapo_wraps": "Bark wraps", "kapa_wraps": "Bark wraps",
        "faavao_bow": "Hunting bow", "karambit": "Claw knife", "eku": "Oar",
        "hamaya": "Bow", "kagura_fan": "Fan", "hula_kii": "Hula puppet",
        "ihe": "Spear", "honu_putong": "Headcloth", "telang": "Butterfly pea",
        "tuhua_hei": "Amulet", "anana_bracer": "Bracer",
        "anana_sash": "Sash", "anana_lei": "Garland",
    }
    # The Seer's Shell (Frankie, 10/22): used in a fight on an enemy, it
    # reads it as Sarjana's Scan does, and is used up.
    SEER_SHELL = "seer_shell"
    # The Smoke Bomb (Frankie, 11/12): the whole party gets away at once, with no rhythm and no
    # roll; only where Escape is allowed (no bosses, no story fights). Sold in the hunters' lodge
    # (the price is Claude's), dropped and found in chests as often as a Seer's Shell.
    SMOKE_BOMB = "smoke_bomb"
    # Drops besides a monster's own item (Frankie, 10/22; the numbers are
    # Claude's first guess). Each beaten monster: one time in
    # EVERYDAY_CHANCE an everyday item, picked by weight; one time in
    # SEED_CHANCE a seed, its favorite (if it has one) half the time,
    # any seed the rest.
    EVERYDAY_CHANCE = 0.2
    EVERYDAY: dict = {"noni": 3, "seer_shell": 1, "smoke_bomb": 1}  # the bomb as often as a shell (Frankie, 11/12)
    # The Life Totem (Frankie, 11/1), which raises the fallen, sold only in the temple (11/3): one time in
    # TOTEM_CHANCE a beaten monster leaves one, a boss one time in TOTEM_BOSS_CHANCE
    # (Claude's numbers, 11/1: about one in a dozen fights, so a long stretch of woods
    # leaves one or two). Two chests hold one besides (``data/cells``).
    TOTEM_CHANCE = 0.04
    TOTEM_BOSS_CHANCE = 0.25
    SEED_CHANCE = 0.04
    SEED_FAVORITE_SHARE = 0.5
    # The demo's dropped equipment (Frankie, 10/24): rarer than items or
    # ingredients. One time in EQUIP_CHANCE a beaten monster leaves one of
    # these, any of them alike (Claude's number, 10/24).
    EQUIP_CHANCE = 0.03
    # Taro and wheat drop too (Frankie, 10/24), so selling or eating them
    # never leaves the garden with nothing to replant: one time in
    # 1 / INGREDIENT_CHANCE, either alike (Claude's number).
    INGREDIENT_CHANCE = 0.1
    INGREDIENT_DROPS: tuple = ("taro", "wheat")
    EQUIP_DROPS: tuple = ("kapa_wraps", "hamaya", "kagura_fan", "hula_kii", "tokotoko", "pearl_anklet")
    # What a chest with ``random`` holds, one picked alike when it is opened
    # (Frankie, 10/25): ``equip`` a weapon or relic monsters drop, ``goodie``
    # a medicine Maika sells, a Seer's Shell or CHEST_PULE pule ("pule";
    # Claude's number).
    CHEST_PULE = 30
    CHEST_RANDOM: dict = {
        "equip": EQUIP_DROPS,
        "goodie": ("noni", "kukui", "ti_leaf", "olena", "awa", "seer_shell", "smoke_bomb", "pule"),
    }
    # Which seed a kind of monster (the shared file's ``monsters``) drops
    # more often.
    # A key item a monster always leaves (Claude's call, 10/25): the Great
    # Boar's tusk, for Melia (game/shared/story-tusk.md). Never sold.
    KEY_DROPS: dict = {"great_boar": "boar_tusk"}
    # An ingredient a kind of monster leaves now and then (Frankie, 10/28):
    # the Papanok, a bird, an egg, one time in MONSTER_DROP_CHANCE (Claude's
    # number). Eggs come from the village's chickens too.
    MONSTER_DROPS: dict = {"papanok": "egg", "boar": "pork", "great_boar": "pork"}
    MONSTER_DROP_CHANCE = 0.5
    ROASTED: dict = {"pork": "cooked_pork"}  # What a drop becomes when its monster fell burning (Frankie, 11/4).
    # Boars drop pork less often than the Papanok drops an egg (Frankie, 10/29: now and
    # then; the chance is Claude's number). A kind not here uses MONSTER_DROP_CHANCE.
    MONSTER_DROP_CHANCES: dict = {"boar": 0.3, "great_boar": 0.3}
    SEED_FAVORITES: dict = {
        "boar": "seed_strength", "great_boar": "seed_hp", "mage": "seed_magic",
        "nuno": "seed_vitality", "shade": "seed_speed", "rot": "seed_hp", "dwende": "seed_hp",
        "lich": "seed_spirit", "aghoy": "seed_magic", "papanok": "seed_speed",
        "taong_tuod": "seed_vitality", "wicked_witch": "seed_magic", "kapre": "seed_strength",
        "pohaku": "seed_spirit",
    }


class ShopSettings:
    """Prices in the shops (D-571)."""

    BOUGHT_SECONDS = 1.5  # How long "Bought 2 Taro." stays in the top window (Claude's number, 11/4).

    # While Maika is in the party, every price is this share lower, rounded,
    # never under 1 pule: his party passive, he charms the sellers (Frankie,
    # 10/22). The share is Claude's first guess.
    CHARM_DISCOUNT = 0.2
    # What the wallet holds is the owned wallet's size (WalletSettings, Party.pule_max; Frankie, 11/12).
    # Soy sauce at the grocer (Frankie, 10/30): the row's ``price`` in the shop
    # file is 6,000, more than even the first bought wallet holds (Frankie, 11/12), so without the member the row
    # names (``talks_down``, Maika) it can never be bought; Kailo says so the
    # first time he lands on it (SOY_HINT). With Maika along the two haggle
    # once (SOY_HAGGLE) and it costs the row's ``talked_price``, 500, which his
    # shop discount does not touch. The flags remember each talk.
    SOY_HINT_FLAG = "soy_hint"
    SOY_HAGGLE_FLAG = "soy_haggled"
    # Claude's drafts, 10/30 (docs/demo-script.md): (speaker, line).
    SOY_HINT = tuple(("Kailo", line) for line in _FIELD.many("The shops", "SOY_HINT_LINES"))
    SOY_HAGGLE = _FIELD.pairs('Haggling for soy', "SOY_HAGGLE_LINES")
    # The most of one thing bought in one go (Claude's number, 10/28).
    MOST_AT_ONCE = 99
    # Selling (Frankie, 10/24): anything the demo gives again, never the starting
    # gear, a chest's item or a one-off (``once`` in a shop); and each shop buys
    # only its own kind, its ``buys``, no shop a meal (Frankie, 10/28).
    # A shop's item sells for this share of its price, rounded down (Claude's
    # number); what no shop sells has its price here (Claude's numbers).
    SELL_SHARE = 0.5
    # The seller's line over the Buy and the Sell list, as Final Fantasy VI's
    # "Help yourself!" (Claude's drafts, 10/24, in docs/demo-script.md).
    BUY_LINE = _FIELD.one("The shops", "BUY_LINE")
    SELL_LINE = _FIELD.one("The shops", "SELL_LINE")
    SELL_PRICES: dict = {
        **{seed: 25 for seed in ItemSettings.SEEDS},
        **{item: 20 for item in ItemSettings.EQUIP_DROPS},
        "egg": 2,  # No shop sells eggs; as cheap as half a taro (Claude's number).
        # The stall sells the crops again, as the grocer (Frankie, 10/29, later the
        # same day; taro and wheat 4, so half is 2); broth and seaweed keep the
        # price it paid before.
        "taro": 2, "wheat": 2, "broth": 2, "seaweed": 2,
        "breadfruit": 3, "niu": 3, "pineapple": 3, "fish": 4, "awapuhi": 3, "uala": 2, "akai_lau": 2, "pork": 4, "salt": 1, "kukui_nut": 3,  # Claude's numbers, 10/29.
        "noni_fruit": 3, "awa_root": 3,
    }


class TownSettings:
    """The two villagers sparring in town (the demo plan, Frankie 10/22), and Kailo's bed."""
    # Villagers with ``wander`` in their room file stroll that many tiles from
    # their spot (Frankie, 10/26): a step this slow, then a rest picked at random.
    WANDER_STEP_MS = 400
    WANDER_WAIT_RANGE = (1.5, 4.0)


    # Standing next to one, facing them, this long with nothing pressed
    # teaches Kailo, once (Frankie, 10/23).
    WATCH_SECONDS = 30
    WATCH_MEMBER = "kailo"
    WATCH_GROWTH = {"strength": 2, "speed": 2}
    WATCH_FLAG = "watched_lelua"
    WATCH_LINES = _FIELD.many("The village", "WATCH_LINES")
    # Facing Kailo's bed and confirming asks this, NO / YES; YES rests the
    # party (Frankie's words, 10/23; there is no inn).
    NAP_BOX = _FIELD.one('Beds, signs, the inn and the totem', "NAP_BOX")
    # Kupulau's inn (Frankie, 11/3: you pay to sleep the night; the price, the words and the three
    # beds are Claude's placeholders): an innkeeper's ``inn`` is the price in pule, and so are the
    # inn's beds. Sleeping is a nap's rest and the next day (``records.sleep``), for money.
    INN_ASK = _FIELD.one('Beds, signs, the inn and the totem', "INN_ASK")
    INN_SHORT = _FIELD.one('Beds, signs, the inn and the totem', "INN_SHORT")
    INN_THANKS = _FIELD.one('Beds, signs, the inn and the totem', "INN_THANKS")
    INN_LINE = _FIELD.one('Beds, signs, the inn and the totem', "INN_LINE")
    NAP_LINE = _FIELD.one("The village", "NAP_LINE")
    # Facing the Meialana, after Kailo's line: cook in its cabin, nap on
    # his cot, or leave (Frankie, 10/28; the words are Claude's). The nap
    # is the bed's: HP back, never mana, which comes only from moving.
    BOAT_ASK = _FIELD.one('Beds, signs, the inn and the totem', "BOAT_ASK")
    BOAT_CHOICES = ("Cook", "Nap", "Leave")
    POND_LINE = _FIELD.one("The village", "POND_LINE")
    # The Akua totem, the only save point (Frankie, 10/26): the party prays,
    # telling the Akua all that has happened, the fallen get back up, and
    # then YES opens the three slots. The first time, Hina explains, or
    # Kailo with her away (Claude's drafts, in docs/demo-script.md).
    TOTEM_FLAG = "prayed_at_totem"
    TOTEM_FIRST = {k: list(ls) for k, ls in _FIELD.keyed_many('Beds, signs, the inn and the totem', "TOTEM_FIRST_ALL").items()}
    PRAY_LINE = _FIELD.one("The village", "PRAY_LINE")
    REVIVE_LINE = _FIELD.one("The village", "REVIVE_LINE")
    SAVE_BOX = _FIELD.one('Beds, signs, the inn and the totem', "SAVE_BOX")
    # Only Kailo's own bed naps (Frankie, 10/25). At anyone else's
    # Hina scolds, flustered at her own; with her away, Kailo says it is
    # not his (Claude's drafts, in docs/demo-script.md).
    OWN_BED = "kailo"
    SCOLD_SPEAKER = "Hina"
    NOT_YOUR_BED = _FIELD.one('Beds, signs, the inn and the totem', "NOT_YOUR_BED")
    HINA_BED = _FIELD.one('Beds, signs, the inn and the totem', "HINA_BED")
    NOT_MY_BED = _FIELD.one('Beds, signs, the inn and the totem', "NOT_MY_BED")
    # The old man's stall at night (Frankie, 10/25): a sign stands in his place,
    # Kailo cannot read it, Hina reads it, and his shop is open as by day.
    SIGN_STARE = ["...", "......", "........."]
    SIGN_READ = list(_FIELD.many('Beds, signs, the inn and the totem', "SIGN_READ_LINES"))
    # Dead ends say something (Frankie, 10/26): walking up into a house's door
    # with no inside, or pressing confirm on it, and walking off a room's edge
    # where no room is, Kailo says one line, once each time he walks up
    # (Claude's drafts, in docs/demo-script.md).
    SHUT_DOOR = _FIELD.one('Beds, signs, the inn and the totem', "SHUT_DOOR")
    GOT_UP_LINE = _FIELD.one("Beds, signs, the inn and the totem", "GOT_UP_LINE")
    SHUT_DOOR_NIGHT = _FIELD.one('Beds, signs, the inn and the totem', "SHUT_DOOR_NIGHT")
    # harbor: the west end of the town, past the harbor (Frankie, 10/27; until then the beach's).
    EDGE_LINES: dict = _FIELD.keyed("The village", "EDGE_LINES")


class HenSettings:
    """The village hens (Frankie, 10/28; ``systems/hens.py``): Ninja Adventure's
    brown chicken, two frames facing left, three of them by Kailo's house.
    How long a hen takes to lay again and the lines are Claude's."""

    SHEET = "Hen.png"
    FRAME_SECONDS = 0.5
    LAY_STEPS = 100
    EGG_LINE = _FIELD.one("The hens", "EGG_LINE")
    NO_EGG_LINE = _FIELD.one("The hens", "NO_EGG_LINE")


class FishingSettings:
    """Fishing with the rod set to Y (Frankie, 10/28; built small for the stew quest, 10/30).
    Facing water, a tap of Y casts; after a wait something bites, and a tap of Y while it
    does hooks it. A fish must then be reeled in by rolling the d-pad (Frankie, 11/2).
    With the line out Kailo cannot walk and A does nothing (Frankie, 11/4); a tap of Y
    before the bite reels it in. The seconds and the lines are Claude's."""

    # Bait (Frankie, 11/2): the angler sells it. Kailo puts one on the rod from the bag
    # (Frankie, 11/4) and it stays on until something is hooked, anything at all, even
    # seaweed; an empty cast keeps it. Bait doubles the fish chance, out of "nothing",
    # and halves the wait; it never changes which fish (Frankie's numbers, 11/2).
    BAIT = "bait"
    BAITED_FLAG = "rod_baited"  # a party flag: the rod has bait on it
    BAIT_ON_LINE = _FIELD.one('Baiting the rod', "BAIT_ON_LINE")  # Claude's words, 11/4
    BAIT_ALREADY_LINE = _FIELD.one('Baiting the rod', "BAIT_ALREADY_LINE")
    BAIT_NO_ROD_LINE = _FIELD.one('Baiting the rod', "BAIT_NO_ROD_LINE")
    BITE_WAIT = (2.5, 5.0)  # seconds from the cast to the bite with bait, picked at random
    BITE_WAIT_NO_BAIT = (5.0, 10.0)  # and without
    BITE_WINDOW = 1.0  # seconds the bite lasts
    # Shown, not told (Frankie, 10/30): Kailo is drawn with the rod out while the line is
    # in the water, and a bite is a ! bubble over his head and a shake, not a line of text.
    SHAKE_PIXELS = 1  # how far he jerks left and right on a bite
    SHAKE_SECONDS = 0.06  # how long each jerk lasts
    BUBBLE_GAP = 1  # pixels between the bubble's tail and the top of his head
    CAUGHT_LINE = _FIELD.one("Fishing", "CAUGHT_LINE")
    MISS_LINE = _FIELD.one("Fishing", "MISS_LINE")  # the bite passed with no tap
    # A tap in time that hooks "nothing" (Frankie, 11/4: "It got away" read as a missed tap).
    NIBBLE_LINE = _FIELD.one("Fishing", "NIBBLE_LINE")
    NORI_LINE = _FIELD.one("Fishing", "NORI_LINE")
    PULE_LINE = _FIELD.one("Fishing", "PULE_LINE")
    # What a bite brings up, in percent (Frankie, 11/2): "nothing" is a bite that gets
    # away, "rare" an item from RARE_ODDS.
    ODDS_NO_BAIT = (("fish", 10), ("nori", 10), ("pule", 5), ("rare", 1), ("nothing", 74))
    ODDS = (("fish", 20), ("nori", 10), ("pule", 5), ("rare", 1), ("nothing", 64))  # with bait
    # Which fish a "fish" is (Frankie, 11/2: every fish is a kind, eel a rare catch; the
    # kinds and weights are Claude's).
    FISH_ODDS = (("mackerel", 20), ("snapper", 18), ("mullet", 12), ("mahimahi", 6), ("tuna", 3), ("eel", 1))
    # Each rod catches only its own fish, by FISH_ODDS's weights (Frankie, 11/2: the Old Rod
    # only mackerel and snapper). A better rod goes after it here; the best one carried is used.
    RODS: dict = {"old_rod": ("mackerel", "snapper")}
    # A rare catch (Frankie, 11/2: something already in the game; the pool and weights are
    # Claude's, for Frankie to approve): a Seer's Shell, the Pearl Anklet, or one of the two oars.
    RARE_ODDS = (("seer_shell", 6), ("pearl_anklet", 2), ("eku", 1), ("hoe", 1))
    RARE_LINE = _FIELD.one("Fishing", "RARE_LINE")
    PULE_RANGE = (3, 12)
    # Reeling (Frankie, 11/2): a hooked fish fills a meter as Kailo rolls the d-pad
    # round (up, right, down, left, either way); every quarter turn the same way adds a
    # quarter of REEL_PER_TURN. It drains all the while; full lands the fish, empty or
    # out of time loses it. Nori, pule and nothing need no reeling. The numbers are Claude's.
    REEL_START = 0.3  # how full the meter starts
    REEL_PER_TURN = 0.2  # one full turn of the d-pad
    REEL_DRAIN = 0.15  # lost each second
    REEL_SECONDS = 8.0  # the most a fish can be fought
    REEL_HINT_FLAG = "reel_hint_seen"  # the hint shows on the first fish only
    REEL_HINT = _FIELD.one("Fishing", "REEL_HINT")
    ESCAPED_LINE = _FIELD.one("Fishing", "ESCAPED_LINE")


class DigSettings:
    """Digging with Pono's 'O'o on Y (Frankie, 10/30; ``systems/dig.py``). The seconds
    and the lines are Claude's."""

    BURIED = "awapuhi"
    SWING_SECONDS = 0.5
    # The hole a dig leaves on the sand, in ``AssetPaths.TILES_DIR`` (tools/make_dug_hole.py).
    # It fills back in when Kailo leaves the room, as a felled tree stands again.
    HOLE_PICTURE = "dug_sand.png"
    FOUND_LINE = _FIELD.one("Digging", "FOUND_LINE")
    # A dig that is not a spot (Frankie, 10/30): nothing, an item or pule, by these chances
    # (Claude's numbers: 25 / 10 / 65 as he said; they add to 1).
    NOTHING_CHANCE = 0.25
    ITEM_CHANCE = 0.10
    PULE_CHANCE = 0.65
    # An item is one thing from the monster drop pool, with each kind's weight as a monster's
    # chance for it (``ItemSettings``), and 'awapuhi added at this weight (Claude's pick: as
    # likely as a taro or a wheat, about one item in eight).
    BURIED_WEIGHT = 0.05
    # The pule is small mostly and big rarely (Claude's curve): 1 plus an exponential with
    # this mean, cut at the most.
    PULE_MEAN = 5.0
    PULE_MAX = 30
    # Finding 'awapuhi plays this the first time; after that only when the stew still needs it
    # and the bag had none (Frankie, 10/30).
    FOUND_SOUND = "found"
    FOUND_FLAG = "awapuhi_found"
    NOTHING_LINE = _FIELD.one("Digging", "NOTHING_LINE")
    AGAIN_LINE = _FIELD.one("Digging", "AGAIN_LINE")
    VILLAGE_LINE = _FIELD.one("Digging", "VILLAGE_LINE")
    GRASS_LINE = _FIELD.one("Digging", "GRASS_LINE")


class BankSettings:
    """Noelani holds pule for Kailo (Frankie, 11/1; ``systems/bank.py``). From her second talk on, after
    one of her own lines, a menu opens with the pule in it. The lines are in ``story-field.md``, Claude's
    drafts; the game has no number picker yet, so she offers set amounts, in the order of the labels."""

    _S = "Noelani and the pule"
    LEAD_LINE = _FIELD.one(_S, "BANK_LEAD_LINE")
    # The lead line waits until Kailo carries this much (Frankie, 11/12; it came on her second talk).
    LEAD_AT = 500
    WHAT_LINE = _FIELD.one(_S, "BANK_WHAT_LINE")
    INGREDIENTS_CHOICE = _FIELD.one(_S, "INGREDIENTS_CHOICE")
    STEW_READY_CHOICE = _FIELD.one(_S, "STEW_READY_CHOICE")
    STEW_CHOICE = _FIELD.one(_S, "STEW_CHOICE")
    PULE_FIRST_CHOICE = _FIELD.one(_S, "PULE_FIRST_CHOICE")
    PULE_CHOICE = _FIELD.one(_S, "PULE_CHOICE")
    NEVER_CHOICE = _FIELD.one(_S, "NEVER_CHOICE")
    NEVER_LINE = _FIELD.one(_S, "NEVER_LINE")
    ASK = _FIELD.one(_S, "BANK_ASK")
    CHOICES = list(_FIELD.many(_S, "BANK_CHOICES_LINES"))
    LANDFALL_LINE = _FIELD.one("Setting sail", "LANDFALL_LINE")
    LEAVE_ASK = _FIELD.one(_S, "LEAVE_ASK")
    LEAVE_CHOICES = list(zip(_FIELD.many(_S, "LEAVE_CHOICES_LINES"), (10, 100, None, 0)))
    TAKE_ASK = _FIELD.one(_S, "TAKE_ASK")
    TAKE_CHOICES = list(zip(_FIELD.many(_S, "TAKE_CHOICES_LINES"), (10, 100, None, 0)))
    LEFT = _FIELD.one(_S, "LEFT")
    TOOK = _FIELD.one(_S, "TOOK")
    NONE_LEFT = _FIELD.one(_S, "NONE_LEFT")
    NONE_HELD = _FIELD.one(_S, "NONE_HELD")
    FULL = _FIELD.one(_S, "FULL")
    # Noelani sells the wallet, not the Trapper (Frankie, 11/12): the next one up from the one owned,
    # on this island only the first (the Lauhala Bag). She names it and the price; it comes out of
    # the wallet Kailo carries, and he complains. All Claude's drafts, for Frankie to rewrite.
    WALLET_UP_TO = 1
    WALLET_CHOICE = _FIELD.one(_S, "WALLET_CHOICE")
    WALLET_OFFER = _FIELD.one(_S, "WALLET_OFFER")
    WALLET_BOX = _FIELD.one(_S, "WALLET_BOX")
    WALLET_SHORT = _FIELD.one(_S, "WALLET_SHORT")
    WALLET_SOLD = _FIELD.one(_S, "WALLET_SOLD")
    WALLET_COMPLAINT = _FIELD.one(_S, "WALLET_COMPLAINT")
    # Maika's discount works on her too (Frankie, 11/12): the first time the wallet is offered with
    # him in the party and standing, ``story-noelani.md`` plays, once (this flag), and her price is
    # the discounted one from then on (``shop_price``).
    CHARM_SCENE = "noelani_charmed"
    CHARM_FLAG = "noelani_charmed"


class StewSettings:
    """The stew quest (Frankie, 10/26, reshaped 10/30; ``systems/stew.py``): after the
    opening fight the boars knock the stew pot over, and Kailo cooks a new one,
    with Noelani helping, once the player brings her what it needs. The party flags: ``stew_quest`` once
    the opening is over, ``stew_made`` once she has the ingredients. The counts are
    Claude's pick (10/30) by how hard and slow each is to get (Frankie, 10/30):
    fewer of the hard ones. The hints are where each one comes from, and the lines are Claude's drafts."""

    QUEST_FLAG = "stew_quest"
    MADE_FLAG = "stew_made"
    # Easy and quick: fish (cast again and again), egg (hens, Papanok). Niu is a quarter
    # of the trees felled. Pork is a boar fight at 30%. 'Uala and akai lau are a seed, a
    # patch and a long wait, and a patch gives two. 'Awapuhi has three spots in the whole
    # game and soy sauce is a quest, so one each.
    NEEDS: dict = {"fish": 4, "egg": 3, "niu": 3, "pork": 2, "uala": 2, "akai_lau": 2, "awapuhi": 1, "soy_sauce": 1}
    HINTS: dict = _FIELD.keyed("Noelani and the stew", "HINTS")  # Maika's quest owns the soy sauce (Frankie, 10/30)
    SPEAKER = "Noelani"
    # The first talk (Frankie, 10/30): she heard and will help, asks what goes in, Kailo
    # says the list, and she sends him off. She names only what and how many, never where
    # from. All Claude's drafts (10/30), in Noelani's bossy cousin voice and Kailo's terse one.
    OFFER_LINES: tuple = _FIELD.many("Noelani and the stew", "OFFER_LINES")
    # She says what is needed herself, and Kailo no longer lists what he has (Frankie, 11/12).
    LIST_SPEAKER = "Noelani"
    LIST_LINE = _FIELD.one("Noelani and the stew", "LIST_LINE")
    SEND_LINES: tuple = _FIELD.many("Noelani and the stew", "SEND_LINES")
    # Asked what is still needed she says what is missing, with the numbers, and asks for what he carries so
    # far (Frankie, 11/12; it was Kailo listing what he had first, 11/5). Claude's drafts.
    GIVE_ASK = _FIELD.one("Noelani and the stew", "GIVE_ASK")
    GIVE_BOX = _FIELD.one("Noelani and the stew", "GIVE_BOX")
    GAVE_LINE = _FIELD.one("Noelani and the stew", "GAVE_LINE")
    MISSING_LINE = _FIELD.one("Noelani and the stew", "MISSING_LINE")
    # Everything in the bag: the two of them cook (``story-stew.md``) and Kailo is given
    # the stew as a key item.
    SCENE = "stew_cooks"
    KEY_ITEM = "kohuapua"
    AFTER_LINE = _FIELD.one("Noelani and the stew", "AFTER_LINE")
    # Beating the Great Boar before the stew is made leaves it day; the stew made after
    # that brings the night.
    DUSK_LINE = _FIELD.one("Noelani and the stew", "DUSK_LINE")


class SeaweedSettings:
    """Seaweed on the beach (Frankie, 10/29; ``systems/seaweed.py``). The numbers
    and lines are Claude's. Fishing also gives it by chance (``systems/fishing.py``)."""

    CHANCE = 0.5
    WAIT_STEPS = 100
    COUNT = 1
    FOUND_LINE = _FIELD.one("Nori", "FOUND_LINE")
    NOTHING_LINE = _FIELD.one("Nori", "NOTHING_LINE")


class GardenSettings:
    """How Hina's garden patches look (``systems/garden.py``)."""

    # Each plant's four 16 pixel pictures in a row: bare soil, growing,
    # more grown, ripe. Wheat is Mini World Sprites' wheat field. Taro
    # (Frankie, 10/23) is Mini World's bare soil with Ninja Adventure's
    # plants on it, from TilesetNature.png: the small round plant at x 96,
    # y 160, the leafy one at x 0, y 160, and the big dark leaf at x 64,
    # y 176.
    PICTURES: dict = {
        "wheat": "miniworld/Nature/Wheatfield.png",
        "taro": "garden/Taro.png",
        # 'Uala is a placeholder (Claude's, 10/30). Akai lau is green onion (Frankie, 10/30); its
        # four pictures are drawn by Claude.
        "uala": "garden/Taro.png",
        "akai_lau": "garden/GreenOnion.png",
        # Pineapple (Frankie, 11/12) borrows taro's four pictures until it has its own.
        "pineapple": "garden/Taro.png",
    }
    # A wild pineapple shrub (Frankie, 11/12: pineapples grow wild on shrubs, never on trees):
    # pressing on a ripe one picks SHRUB_PICKED of them, and it bears again after SHRUB_STEPS steps
    # walked (the garden's count). The numbers are Claude's picks.
    SHRUB_PICKED = 1
    SHRUB_STEPS = 600
    SHRUB_FRUIT = "pineapple"
    SHRUB_PICK_LINE = _FIELD.one('The garden prompts', "SHRUB_PICK_LINE")
    SHRUB_BARE_LINE = _FIELD.one('The garden prompts', "SHRUB_BARE_LINE")
    # The lines pressing on a patch says (Frankie, 10/23: one press, one
    # thing). Maika's ability is the Maki Hula (Frankie, 10/23).
    REPLANT_BOX = _FIELD.one('The garden prompts', "REPLANT_BOX")  # the seed's or the crop's name; short to fit the NO / YES box (Frankie, 10/29)
    ABILITY_BOX = _FIELD.one('The garden prompts', "ABILITY_BOX")
    ABILITY_DONE_LINE = _FIELD.one("The garden", "ABILITY_DONE_LINE")
    GROWING_LINE = _FIELD.one("The garden", "GROWING_LINE")
    NEEDS_HINA_LINE = _FIELD.one("The garden", "NEEDS_HINA_LINE")
    # Replanting uses the matching seed (Frankie, 10/29; the old man sells
    # them); with none in the bag (Claude's words, {item} is its name):
    NO_SEED_LINE = _FIELD.one("The garden", "NO_SEED_LINE")
    ABILITY_LINE = _FIELD.one("The garden", "ABILITY_LINE")
    # A farm patch takes any crop (Frankie, 10/29); Claude's words.
    PLANT_BOX = _FIELD.one('The garden prompts', "PLANT_BOX")
    PLANT_CHOICE = "{item}"
    LEAVE_CHOICE = _FIELD.one('The garden prompts', "LEAVE_CHOICE")
    NO_FARM_SEED_LINE = _FIELD.one("The garden", "NO_FARM_SEED_LINE")
    # The first time each ability can be used, its owner offers it before
    # the question, once a game (Frankie, 10/23). Claude's drafts, in their
    # voices, for Frankie to rewrite.
    # The first time anything is planted, Hina says they need not stand and wait
    # (Frankie, 10/30); Claude's words, in her voice.
    WAIT_LINE = _FIELD.one("The garden", "WAIT_LINE")
    HINA_OFFER_LINE = _FIELD.one("The garden", "HINA_OFFER_LINE")
    MAIKA_OFFER_LINE = _FIELD.one("The garden", "MAIKA_OFFER_LINE")


class CraftSettings:
    """What the pot says (``core/scenes/craft_scene.py``). Crafting is by
    experiment first, then a list, as in Skyrim (Frankie, 10/28). The
    wording is Claude's but for the two lines of FIND_LINES, from Frankie's
    preview (``outbox/crafting-menu-preview.png``); {item} is an
    ingredient's name and {crafter} the one whose craft it is."""

    # Only Kailo's cooking is designed, so the screen is Cook (the preview).
    TITLE = "Cook"
    CRAFTER = "kailo"  # only his cooking is built; every dish is his
    INGREDIENTS_ROW = "Ingredients"
    FIND_LINES: tuple = _FIELD.many("Cooking and crafting", "FIND_LINES")  # the cartridge's two-thing pot
    FIND_THREE_LINES: tuple = _FIELD.many("Cooking and crafting", "FIND_THREE_LINES")  # pygame's, up to three (11/2)
    WITH_LINE = _FIELD.one("Cooking and crafting", "WITH_LINE")
    # Up to three go in (Frankie, 11/2): the Cook row on top cooks what is picked.
    COOK_ROW = _FIELD.one("Cooking and crafting", "COOK_ROW")
    ADD_LINE = _FIELD.one("Cooking and crafting", "ADD_LINE")
    SICK_LINE = _FIELD.one('Cooking', "SICK_LINE")  # Claude's words (11/2)
    PUT_BACK_LINE = _FIELD.one("Cooking and crafting", "PUT_BACK_LINE")
    MADE_LINE = _FIELD.one("Cooking and crafting", "MADE_LINE")
    NEW_RECIPE_LINE = _FIELD.one("Cooking and crafting", "NEW_RECIPE_LINE")
    # A mix that makes nothing makes ??? (Frankie, 11/2; they were used up and lost, 10/28).
    NO_MIX_LINES: tuple = _FIELD.many("Cooking and crafting", "NO_MIX_LINES")  # the cartridge's, both lost
    DUBIOUS_LINES: tuple = _FIELD.many("Cooking and crafting", "DUBIOUS_LINES")  # pygame's, ??? made
    # Only the cartridge's old pot says this (snes/tools/make_art.py): in pygame two of
    # the same never go in (Frankie, 10/28).
    ONLY_ONE_LINE = _FIELD.one("Cooking and crafting", "ONLY_ONE_LINE")
    AWAY_LINE = _FIELD.one("Cooking and crafting", "AWAY_LINE")
    EMPTY_LINE = _FIELD.one("Cooking and crafting", "EMPTY_LINE")
    # The cartridge's old pot still says these (snes/tools/make_art.py) until it
    # catches up; nothing in pygame does.
    PICK_LINE = _FIELD.one("Cooking and crafting", "PICK_LINE")
    NO_MIX_LINE = _FIELD.one("Cooking and crafting", "NO_MIX_LINE")
    # Water is free from the river or a pond (Frankie, 10/28; Claude's
    # suggestion, taken): facing fresh water and pressing confirm gives one.
    # The sea is salt: the shore's rooms give none. A healing pond (the
    # spring tile) rests the party instead, one press, one thing.
    WATER_LINE = _FIELD.one("Cooking and crafting", "WATER_LINE")
    # No spamming it (Frankie, 10/28): after WATER_STREAK (five, Frankie 10/29) draws in a row Kailo
    # says the canteens are getting heavy, and draws none until WATER_REST
    # seconds have gone by with no draw (Claude's number). He still carries
    # up to WATER_MAX. The lines are Claude's drafts.
    WATER_STREAK = 5
    WATER_REST = 10.0
    WATER_MAX = 255
    HEAVY_LINE = _FIELD.one("Cooking and crafting", "HEAVY_LINE")
    REST_LINE = _FIELD.one("Cooking and crafting", "REST_LINE")
    FULL_LINE = _FIELD.one("Cooking and crafting", "FULL_LINE")
    SALT_ROOMS: tuple = ("beach_west", "beach_east", "pono_yard", "pono_farm", "harbor", "harbor_beach", "kupulau_harbor", "docks", "island_hut")


class OrderSettings:
    """Kailo gets paid to cook (Frankie, 10/28 and 11/1; ``systems/meal_orders.py``):
    named villagers crave a dish, and the Meialana takes their orders. Which
    villagers, how often, the effort picks and the pay are Claude's first
    guess; the lines are Claude's drafts, in ``game/shared/story-field.md``.
    {meal} is the dish's name, {price} its pule, {who} the villager."""

    # Only people with a name crave or order (Frankie, 11/1: "villager" can't order
    # food); the unnamed ones join when they are named. Ama is only a customer at the
    # boat, since he always talks boat after the jump.
    NAMED: tuple = ("Chief Ulu", "Noelani", "Ama", "Melia", "Keo")
    # Who is out of reach once a story flag is set (Frankie, 11/2): Melia, taken by the pirates
    # at the wake, gone from the map with the same flag. Nothing in the story brings her back yet.
    GONE_AFTER: dict = {"Melia": "story_after_jump"}  # StorySettings.AFTER_JUMP_FLAG
    # Family never pays for Kailo's cooking (Frankie, 11/2): they place no boat orders and a
    # craving never gives them pule to hand over, only the tier's gift.
    FAMILY: tuple = ("Melia", "Noelani", "Keo")
    # People of Kupulau, who order once the town is on Kailo's map.
    KUPULAU_NAMED: tuple = ("Chief Kekoa", "Gen'emon")
    # One talk in this many, with no craving open, a named villager has one.
    CHANCE = 1 / 3
    # How hard a dish is to make (Frankie, 11/1: rewards and pay go by it). Effort
    # counts like the garden's steps: the crops are the garden's own (taro 1200,
    # wheat 900, 'uala 750, akai lau 600, Claude's picks, 10/30); the rest are Claude's
    # picks in the same measure, by how long each takes to get; each pot step adds POT_STEP.
    EFFORT: dict = {
        "water": 0, "salt": 100, "egg": 200, "seaweed": 150, "pork": 600, "taro": 1200,
        "wheat": 900, "uala": 750, "akai_lau": 600, "noni_fruit": 400, "awa_root": 400,
        "breadfruit": 400, "niu": 500, "kukui_nut": 400, "ti_leaf": 300, "pineapple": 400, "pia": 300,
        "mackerel": 400, "snapper": 400, "mullet": 400, "mahimahi": 600, "tuna": 900, "eel": 1000,
    }
    POT_STEP = 150
    # Pay is effort over PAY_PER, rounded to the nearest PAY_ROUND, never under PAY_ROUND.
    PAY_PER = 90
    PAY_ROUND = 5
    # A dish's tier: 1 under the first number, 2 under the second, else 3.
    TIERS: tuple = (900, 1500)
    # A craving's gift: with chance PULE_CHANCE the dish's pay in pule, else one thing
    # from its tier's pool (a seed comes as two).
    PULE_CHANCE = 0.5
    GIFTS: dict = {
        1: ("noni", "ti_leaf", "kukui", "olena"),
        2: ("awa", "uala_seed", "akai_lau_seed", "noni"),
        3: ("ola", "seer_shell", "uala_seed", "akai_lau_seed"),
    }
    SEED_COUNT = 2
    # The Meialana takes orders: at most MAX_ORDERS open, and a new one may come each
    # ORDER_STEPS steps walked, one time in ORDER_CHANCE.
    MAX_ORDERS = 3
    ORDER_STEPS = 150
    ORDER_CHANCE = 0.75
    CHECK_LABEL = "Check orders"
    PRICES_LABEL = "Prices"
    BACK_LABEL = "Back"
    MORE_LABEL = "More"
    PRICES_PAGE = 4
    ORDERS_ASK = _FIELD.one("Meal orders", "ORDERS_ASK")
    PRICES_ASK = _FIELD.one("Meal orders", "PRICES_ASK")
    ENTRY = "{who}: {meal}"
    PRICE_ENTRY = "{meal} {price}"
    HINT_LINES = _FIELD.many("Meal orders", "HINT_LINES")
    ASK_LINE = _FIELD.one("Meal orders", "ASK_LINE")
    ASK_BOX = _FIELD.one('Meal order prompts', "ASK_BOX")
    THANKS_LINE = _FIELD.one("Meal orders", "THANKS_LINE")
    GAVE_LINE = _FIELD.one("Meal orders", "GAVE_LINE")
    RECEIVED_LINE = _FIELD.one('Meal order prompts', "RECEIVED_LINE")
    NONE_LINE = _FIELD.one("Meal orders", "NONE_LINE")
    MISSING_LINE = _FIELD.one("Meal orders", "MISSING_LINE")
    SOLD_LINE = _FIELD.one("Meal orders", "SOLD_LINE")


class RecordSettings:
    """The date and Data's records (Frankie, 10/23 and 10/25; ``systems/records.py``)."""

    # Four seasons of 30 days, by their Nuitai names (lore/law/calendar.md):
    # spring, summer, autumn, winter. The game starts on the last day of
    # summer and for now stays there: a nap is not a night's sleep, and the
    # wake is tonight (Frankie, 10/26). The calendar comes back later, for
    # sailing or a full night's sleep: DAYS_PASS turns it on.
    SEASONS = ("Mohala", "Kau", "Hauhake", "Ho'oilo")
    SEASON_DAYS = 30
    START_DAY = 60  # Counted from Mohala 1 as day 1: the 30th of Kau.
    DAYS_PASS = False


class PlaceSettings:
    """The place pop-up at the top of the field (Frankie, 10/25; ``systems/places.py``).

    Walking from one place into another shows its name in a small box at
    the top center, never over Kailo, for a moment; walking out of his
    house after a nap in his bed shows the date under it too.
    """

    VILLAGE = "Kulāiwi Village"
    FOREST = "Kulāiwi Forest"
    # Kupulau, the town on the first Lanuloa island (Frankie, 11/1): its rooms are listed
    # in ``systems/places.py``.
    KUPULAU = "Kupulau"
    KUPULAU_FOREST = "Kupulau Forest"
    # The named rooms (Frankie, 11/1): walking into a house shows its own name, and walking
    # out shows the place again. Names are Claude's drafts except where Frankie said them
    # (Kailo's house, Hina's house, the chief's hut, the hunters' lodge).
    ROOMS: dict = {
        "kailo_house": "Kailo's House", "hina_house": "Hina's House", "chief_house": "The Chief's Hut", "chief_house_upstairs": "The Chief's Loft",
        "hunters_lodge": "Hunters' Lodge", "ama_house": "Ama's Bait & Tackle", "kulaiwi_temple": "Temple of Haka",
        "kulaiwi_school": "Temple School", "key_room": "Lanu's Grove",
        "kupulau_chief_house": "The Chief's Hut", "kupulau_lodge": "Hunters' Lodge",
        "kupulau_fishing_shop": "Fishing Shop", "kupulau_inn": "The Inn",
        "kupulau_house_mele": "The Net Mender's House", "kupulau_house_nalu": "The Fisher's House",
        "kupulau_house_empty": "A House",
    }
    SECONDS = 2.0
    TOP = 8
    # The opening's second card, after the blurb: the place and the day.
    OPENING_CARD = "Kulāiwi Village\nThe last day of Summer"


class MapSettings:
    """The maps on SELECT (Frankie, 10/26 and 10/28; ``systems/area_map.py``, ``core/scenes/map_scene.py``).

    SELECT on the field opens the area map: every outside room Kailo has
    walked into, two pixels per tile (``TILE_PIXELS``), in its tile's
    color, the rooms not yet found left dark, seen through a fixed view
    (``VIEW_W`` by ``VIEW_H``) the d-pad pans. SELECT again goes to the world
    map once Kailo has the map Ama gives him (``HAS_MAP_FLAG``, set after the
    demo, so never yet), otherwise it closes; B closes it too.
    """

    # One tile to this many pixels across and down: two (Frankie, 10/28; it was one, which left the
    # box mostly empty). Even Kulaiwi is taller than the screen at two, so the map is seen through a
    # view under the title and the d-pad pans it, and an area can be any size (Frankie, 10/28).
    TILE_PIXELS = 2
    # The view: 28 by 21 of the cartridge's 8 pixel tiles, as big as fits with the frame and title.
    # An area narrower or shorter than it is centered that way and does not pan.
    VIEW_W = 224
    VIEW_H = 168
    # Holding the d-pad glides the map this many pixels a second, a tile a frame; it stops at the edges.
    PAN_SPEED = 120
    # The party flag set once Ama gives Kailo the map, before he leaves Kulāiwi (after the demo).
    HAS_MAP_FLAG = "has_world_map"
    # One color per kind of tile, kept in sync with ``OverworldSettings.*_CHAR``.
    TILE_COLORS: dict = {
        ".": (104, 168, 72),    # grass
        "#": (32, 96, 48),      # palms, dark green
        "~": (48, 104, 200),    # sea
        "o": (120, 208, 232),   # the healing pond, pale blue
        "_": (224, 200, 128),   # sand
        "=": (160, 112, 64),    # the pier, planks
        "m": (200, 72, 56),     # a market stall
        "f": (200, 168, 112),   # mats inside
        "w": (120, 80, 48),     # an inside wall
        "a": (168, 176, 152),   # stone stairs
        "b": (168, 176, 152),
        "c": (216, 184, 104),   # wood stairs
        "d": (216, 184, 104),
    }
    # A house, a stall or the boat standing on the tiles, over whatever is under it.
    BUILDING_COLOR = (184, 64, 48)
    BUILDING_KINDS: tuple = ("hale", "tall_hale", "lodge", "stall", "meialana")
    # Kailo's dot on both maps, in both games: yellow, no edge, blinking slowly, on this many
    # seconds and off as many (Frankie, 10/28; yellow so it stands out from the red roofs).
    DOT_COLOR = (248, 224, 32)
    BLINK_SECONDS = 0.8
    # The world map (``systems/world_map.py``): the area Kailo is in, the whole demo, and each
    # area's spot on the picture, by its name in ``data/world_map.json`` (tools/mapgen/worldpic.py).
    # In Māla Iki the dot is on Kulāiwi, the small island beside the big one where the story starts.
    WORLD_AREA = "Māla Iki"
    LANULOA_AREA = "Lanuloa"   # Kupulau's rooms; no spot on the picture yet, so no dot there
    WORLD_SPOTS: dict = {"Māla Iki": "Kulāiwi"}
    # The window's space around the map, and below the title.
    PADDING = 8
    TITLE_GAP = 4


class PassiveSettings:
    """The party passives (Frankie, 10/21 and 10/22; ``systems/passives.py``).

    A passive is on while its member is in the party, bench included. It
    is said once, in one sentence, when the member joins, and nowhere else.
    """

    # The one sentence said when each one joins. Kailo starts in the party,
    # so his is never said; Hina's is said when she joins at her house or in
    # the woods (Frankie, 10/27).
    JOIN_LINES: dict = _FIELD.keyed("Joining the party", "JOIN_LINES")
    # Tawiri's: every point toward a stat's next rise counts this many
    # times (Frankie, 10/27).
    TAWIRI_GROWTH = 1.5
    # The first time Hina's or Kailo's works, its member says this; every
    # time after, the victory screen narrates it (Frankie, 10/26). Hina's
    # line is a draft (docs/demo-script.md).
    FIRST_LINES: dict = _FIELD.keyed("Joining the party", "FIRST_LINES")
    NARRATED: dict = {
        "hina": "Hina helps the fallen up.",
        "kailo": "Kailo feeds everyone.",
    }


class MasterySettings:
    """Weapon mastery (Frankie, 10/30; ``systems/mastery.py``). Every number is Claude's draft.

    Each character has a level in each of their three weapon types, kept in
    the save as total EXP per type. A stroke that lands with a weapon of that
    type earns EXP by its points, more for a heavier stroke; empty hands count
    as handwraps. Modest on purpose, so it never swamps the strokes.
    """

    MAX_LEVEL = 10
    # EXP a landed stroke earns, by stroke: its points (light 1, medium 2, strong 3).
    EXP_PER_STROKE: dict = {"light": 1, "medium": 2, "strong": 3}
    # EXP from level L to L + 1 is this times L: 120, 240, ... 1080; 5400 in all (eight times the first 15, 11/2, Frankie).
    EXP_STEP = 120
    # Each level above the first adds this to a stroke's chance to land and to its damage.
    HIT_PER_LEVEL = 0.01
    DAMAGE_PER_LEVEL = 0.02


class RainSettings:
    """Spring Rain's rain over the fight (Frankie, 11/4; ``ui/rain.py``). Claude's numbers."""

    DROPS = 64                       # Streaks on screen at once.
    LENGTH = 7                       # Pixels long.
    SLANT = 0.25                     # Pixels left per pixel down.
    SPEED = 220                      # Pixels a second.
    COLOR = (205, 225, 255, 190)     # Pale blue, a little see-through.


class LightWaveSettings:
    """Light Wave's light over the fight (Frankie, 11/4; ``ui/rain.py``). Claude's numbers."""

    SPECKS = 56                      # Gold specks on screen at once.
    SPEED = 40                       # Pixels a second they rise.
    COLOR = (255, 240, 150, 255)     # Light's gold.


class VictorySettings:
    """The victory screen's pace (Frankie, 10/26; ``core/scenes/victory_scene.py``). Claude's numbers."""

    # A steady beat, one thing per beat, never two at once (Frankie, 10/26).
    BEAT_SECONDS = 0.45     # One stat point, one item, or the rest between them.
    UNFOLD_SECONDS = 0.2    # How long an item takes to open, at the start of its beat.
    COUNT_SECONDS = 0.07    # One number of money, or of HP coming back, like a slot machine.
    COUNT_CAP_SECONDS = 2.0  # A count longer than this steps by more than one, to fit.
    HOLD_SECONDS = 0.6      # In the fight, after its last line, before the screen opens.
    DEAF_SECONDS = 0.4      # A held over from the fight is ignored this long, or till let go.


class FieldMonsterSettings:
    """Pacing for the monsters seen on the map (D-576)."""

    STEP_MS = 250                     # How long one tile's slide takes.
    WAIT_RANGE = (0.6, 1.6)           # Seconds standing between steps, picked at random.
    # A wandering monster this many tiles from the player (across plus
    # down) chases instead, a step every CHASE_WAIT seconds; a boss never
    # does (Frankie, 10/21).
    CHASE_TILES = 4
    CHASE_WAIT = 0.15
    COLOR = (150, 60, 50)             # Stand-in square when the picture is missing.
    # After any fight, won too (Frankie, 10/27), no monster can start
    # another for this long, so the party can walk off.
    GRACE_SECONDS = 2.0
    # A beaten monster comes back once the party has walked this many steps
    # since; a nap or a spring brings them all back (Frankie, 10/28).
    RESPAWN_STEPS = 200

class OverworldPlayerSettings:
    """Tunable values for the overworld player sprite.

    A walking character is one tile, 16 by 16, Pokemon style (D-573).
    The sheet named in ``AssetPaths.PLAYER_SHEET`` is a Ninja Adventure
    walk sheet: one column per facing, four walk frames down each.
    """

    STEP_DURATION_MS = 150            # Walk animation duration per tile.
    COLOR = ColorSettings.YELLOW      # Stand-in fill when the sheet is missing.
    WIDTH = GridSettings.TILE_SIZE
    HEIGHT = GridSettings.TILE_SIZE
    # Column of the sheet for each facing, as (dx, dy).
    SHEET_COLUMNS: dict = {(0, 1): 0, (0, -1): 1, (-1, 0): 2, (1, 0): 3}
    FRAME_WIDTH = 16
    FRAME_HEIGHT = 16
    WALK_FRAMES = 4                   # Frame 0 is also the standing frame.
    FRAMES_PER_STEP = 2               # Shown while crossing one tile.
    SPAWN_COL = OverworldSettings.COLS // 2  # Center column on first spawn.
    SPAWN_ROW = OverworldSettings.ROWS // 2  # Center row on first spawn.


class StorySettings:
    """The demo's story around its two scenes (the demo line in game/answers.md, 10/22)."""

    # A scene acted out on the map (core/staging.py, Frankie 10/23): the
    # player is this one of its cast. People in a scene walk a tile in
    # WALK_STEP_MS, the pace Hina and Melia leave west at after the first
    # fight; a run, only for an emergency or a rush, takes RUN_STEP_MS,
    # between that and the old 75 (Frankie, 10/26).
    PLAYER = "Kailo"
    WALK_STEP_MS = 150
    RUN_STEP_MS = 110
    # Tawiri walks a little slower on the field; she walks with a cane (Frankie, 11/1). A step
    # of hers takes this long whatever the scene asks (Claude's number, 40 ms over a walk).
    CANE_WALKERS: dict = {"Tawiri": 190}
    # A foe on the stage facing down roots in the mud, a frame this long each.
    ROOT_SECONDS = 0.35

    # Party flags, so a save keeps the story's place: the taro patch is
    # over, and the Great Boar is beaten, so it is night.
    TARO_FLAG = "story_taro_patch"
    # Losing the taro patch fight goes on with the game (Frankie, 10/26):
    # the save keeps whether it was lost, so the gulls got the stew. The
    # wake's lines read it as "stew saved" or "stew lost"; the chief's
    # ``flag_lines`` in his house, as this flag.
    STEW_LOST_FLAG = "stew_lost"
    STEW_SAVED, STEW_LOST = "stew saved", "stew lost"
    # A cutscene can be skipped from the pause (Frankie, 10/28;
    # core/skip_cutscene.py): while one of SKIPPABLE plays, START asks
    # SKIP_ASK in the NO / YES box instead of pausing, NO first and chosen.
    # YES plays the rest at once behind black, SKIP_STEPS frames of it each
    # frame, up to the scene's end or its fight. Only long scenes are on the
    # list, each with the parts that can be skipped ("scene" up to the fight,
    # then core/story.py's WIN and LOSE), and a scene with a choice in it is
    # never skippable even if listed. Today: the opening, the taro patch with
    # its after-the-fight parts and the words before it (the blurb); and the
    # wake up to Pono's fight, where a skip lands. The wake after that fight
    # is left out for now, because skipping it ends the demo at once
    # (Frankie, 10/28). The cartridge reads this too (make_art.py's skip_end).
    SKIPPABLE: dict = {
        "taro_patch": ("scene", "If you win", "If you lose"),
        "wake": ("scene",),
        "after_jump": ("scene",),
    }
    SKIP_ASK = _FIELD.one('Around the village', "SKIP_ASK")
    SKIP_STEPS = 600
    # The stew saved, the chief's line at the wake is followed by a gift,
    # one of these picked alike: the demo's rare drops (ItemSettings.EQUIP_DROPS)
    # and the three Anana relics nobody wears or finds (Claude's pick, 10/26).
    WAKE_GIFT_FROM = "Chief Ulu"
    WAKE_GIFT_EXTRA: tuple = ("anana_bracer", "anana_sash", "anana_lei")
    WAKE_GIFT_LINE = _FIELD.one("Between the scenes", "WAKE_GIFT_LINE")
    # After the taro patch Hina goes home, out of the party, until Kailo
    # talks to her there: her scene, and the flag that she has joined
    # (Frankie, 10/23). Saves from before this keep her in the party.
    HOME_MEMBER = "hina"
    HOME_SCENE = "hina_joins"
    HOME_FLAG = "story_hina_joined"
    # So she cannot be missed: walking into this room without her, the one
    # before the Great Boar's, she catches up and joins (Frankie, 10/25; it
    # was the hedge garden, before Maika could be met).
    WOODS_SCENE = "hina_woods"
    WOODS_ROOM = "gate_yard"
    # The log yard's west edge, where the painted map ends and the generated
    # woods begin (Frankie, 10/25): stepping onto it, Maika warns Kailo off,
    # else Hina, each once (game/shared/story-deep-woods.md).
    DEEP_ROOM = "log_yard"
    DEEP_COL = 0
    # Every way into the deep forest warns the same way (Frankie, 11/12): the room, the edge tile
    # Kailo stands on (col or row, None for any), and the way he faces walking in. He walks back
    # the other way.
    DEEP_ENTRANCES: tuple = (
        ("log_yard", 0, None, (-1, 0)),           # the west edge
        ("lodge_square", 0, None, (-1, 0)),       # the west edge
        ("harbor_clearing", None, 0, (0, -1)),    # the north edge, the temple's clearing
        ("blocks_room", 15, None, (1, 0)),        # the east edge, the way from Maika's room (Frankie, 11/12)
    )
    # After the warning Kailo walks this many steps east, away from the entrance (Frankie, 11/12).
    DEEP_BACK_STEPS = 3
    DEEP_HINA = "deep_woods_hina"
    DEEP_MAIKA = "deep_woods_maika"
    # The opening on the east edge of Maika's room (the dropped Maki Sages' village, Frankie, 10/26): while he is
    # still at his stall he warns the party off and they walk back this many tiles west.
    VILLAGE_ROOM = "blocks_room"
    VILLAGE_COL = 15
    VILLAGE_BACK_STEPS = 1
    # Maika goes missing in the deep forest (Frankie, 11/12): once his sister's deal is made he is gone from his
    # stall (``MISSING_FLAG``) and a note there says he is digging where the trees are thickest. He is in a
    # hand-made clearing (``CLEARING``) placed in a random slot of the generated woods (``core/generated.py``).
    # Finding him plays the scene, with the Kapre fight; he is in the party for that fight only. Before he goes
    # missing, walking east out of his room (``EAST_COL``, the room's east edge) is warned off by him.
    MISSING_FLAG = "maika_missing"
    FOUND_FLAG = "maika_found"
    EAST_SCENE = "maika_east"
    CLEARING = "maika_clearing"
    CLEARING_SCENE = "maika_clearing"
    DEEP_HINA_MISSING = "deep_woods_hina_missing"
    CLEARING_JOIN_LINE = _FIELD.one('Around the village', "CLEARING_JOIN_LINE")
    CLEARING_GIFT = "awa"
    NIGHT_FLAG = "story_night"
    # The Great Boar beaten, which brings the night only once the stew is made too
    # (Frankie, 10/30; systems/stew.py).
    BOAR_BEATEN_FLAG = "story_boar_beaten"
    # The boars the Great Boar called and the party beat (Frankie, 11/12): for each, one boar fewer stands in
    # his field afterwards, for good. The flag holds the count and saves with the game.
    BOAR_CALLS_FLAG = "great_boar_calls_beaten"
    BOAR_FIELD_ROOM = "farm_field"
    BOAR_FIELD_KIND = "boar"
    # Maika (game/shared/story-maika.md, Frankie 10/23): his scene the first
    # time he is talked to, then his shop; closing it, he says to come back
    # (buying no longer makes him join, Frankie 10/30). The first time the party replants
    # a garden patch with him and Hina along, he teaches her Seed, once
    # (Frankie, 10/24; it was walking into the Great Boar's room).
    JOINER = "maika"
    JOINER_STAFF = "kookoo"  # the staff he came with, in the bag once he holds a doll
    JOINER_ROOM = "blocks_room"  # his stall room: the stall goes with him
    JOINER_MEETS = "maika_meets"
    JOINER_JOINS = "maika_joins"
    JOINER_JOINS_LATE = "maika_joins_late"  # the Great Boar beaten: out for ingredients (Frankie, 11/2)
    JOINER_LEAVES = "maika_leaves"
    # After the lie he asks whether Kailo wants him along: yes joins him, no leaves him, asked again
    # on every talk (Frankie, 11/11). ``JOINER_INVITED_FLAG``: the lie scene has played; the ask is next.
    JOINER_INVITES = "maika_invites"
    JOINER_INVITED_FLAG = "maika_invited"
    JOINER_YES = "yes"
    # Buying no longer makes him join; his sister does (Frankie, 10/30). She is
    # in the hunters' lodge (``sister`` in the room file). Her name is Claude's
    # placeholder (10/30), asked of Frankie; the lines are in
    # ``game/shared/story-sister.md`` and ``story-maika.md``. Party flags, in
    # order: the deal made, Maika asking Kailo not to tell, then what Kailo
    # told her (the lie or the truth), and Maika's sulk, said once.
    SISTER_ASKS = "sister_asks"
    SISTER_REPORT = "sister_report"
    JOINER_ASKS = "maika_asks"
    JOINER_CROSS = "maika_cross"
    SISTER_DEAL_FLAG = "sister_deal"
    JOINER_ASKED_FLAG = "maika_asked"
    SISTER_LIED_FLAG = "sister_lied"
    SISTER_TOLD_FLAG = "sister_told"
    JOINER_CROSS_FLAG = "maika_cross_said"
    SISTER_LIE, SISTER_TRUTH = "lie", "truth"
    # What the sister says when Kailo comes back before there is anything to
    # report, and after the report (Claude's drafts, 10/30).
    SISTER_WAITING = _FIELD.one('Around the village', "SISTER_WAITING")
    SISTER_AFTER_LIE = _FIELD.one('Around the village', "SISTER_AFTER_LIE")
    SISTER_AFTER_TRUTH = _FIELD.one('Around the village', "SISTER_AFTER_TRUTH")
    SISTER_SOY_LINE = _FIELD.one("Between the scenes", "SISTER_SOY_LINE")
    SOY_SAUCE = "soy_sauce"
    SISTER_SOY_COUNT = 1
    # After he joins his stall stays open: pressing on it, he asks first
    # (Frankie, 10/24; Claude's words, a draft in docs/demo-script.md).
    JOINED_SHOP_LINE = _FIELD.one("Between the scenes", "JOINED_SHOP_LINE")
    # A chest (Frankie, 10/24): what it held, then its own line if it has
    # one, said by Kailo; pressed again, it is empty.
    CHEST_FOUND = _FIELD.one('Around the village', "CHEST_FOUND")
    CHEST_EMPTY = _FIELD.one('Around the village', "CHEST_EMPTY")
    # The hunters' lodge keeper mentions the kapa, once, the first time the party talks to him (Frankie, 11/10).
    KAPA_TOLD_FLAG = "lodge_kapa_told"
    KAPA_TALK = _FIELD.many('Around the village', "KAPA_TALK_LINES")
    SEED_SCENE = "maika_seed"
    # The Great Boar's room: its music, and where the cartridge still plays
    # Seed until it catches up with the first planting.
    SEED_ROOM = "farm_field"
    SEED_FLAG = "hina_learned_seed"
    # The Great Boar never starts his fight on touch (Frankie, 10/23): walking
    # into him asks first (story-great-boar.md). The answer that fights; the
    # other walks the party this many steps back, and he asks again next time.
    ASK_KIND = "great_boar"
    ASK_SCENE = "great_boar_ready"
    ASK_FIGHT = "fight"
    BACK_STEPS = 3
    # Night over the field (Claude's call, 10/22): the Super Nintendo's
    # color math taking a fixed color away from every room pixel, the
    # text box left out. 5-bit amounts, red, green, blue (0 to 31).
    NIGHT_SUBTRACT = (16, 12, 2)
    # The scene played when the Great Boar falls, talk and no narration
    # (Frankie, 10/23; story-boar.md); then it is night.
    FALL_SCENE = "boar_falls"
    # The first time Kailo talks to Melia at night with the Great Boar's tusk
    # in the bag, he gives it to her (Claude's call, 10/25); after it she says
    # her ``night_lines``.
    TUSK = "boar_tusk"
    TUSK_SCENE = "melia_tusk"
    TUSK_FLAG = "story_tusk_given"
    # The tusk given, walking into the chief's room has Hina ask; YES starts
    # the wake, NO and she asks again only once the party has left the room
    # and walked back in (Frankie, 10/25; it was Melia, asked when talked to).
    ASK_ROOM = "beach_east"
    ASK_SPEAKER = "Hina"
    ASK_LINE = _FIELD.one("Between the scenes", "ASK_LINE")
    ASK_BOX = _FIELD.one('Around the village', "ASK_BOX")
    WAKE_SCENE = "wake"
    # Tawiri joins at the wake before its fight, with her pop-up.
    WAKE_JOINS = "tawiri"
    WAKE_JOIN_LINE = _FIELD.one("Between the scenes", "WAKE_JOIN_LINE")
    # Whoever came along sits on the bench at the wake (he stays with the food).
    WAKE_BENCH = "maika"
    # After the demo (Frankie, 10/31): the desktop game goes on past the jump
    # into ``story-after-jump.md``, Ama's rescue and the meeting in the chief's
    # hut; the website's demo stops at TO BE CONTINUED, so its build sets
    # DEMO_ONLY (tools/web_build.py). Once the scene is over it is the next
    # morning: AFTER_JUMP_FLAG is set, the night is over (the night flag
    # stays, is_night() reads both), Melia is gone from the map (her
    # ``until``), and Kailo wakes by his bed at AFTER_JUMP_WAKE.
    DEMO_ONLY = True
    AFTER_JUMP_SCENE = "after_jump"
    AFTER_JUMP_FLAG = "story_after_jump"
    AFTER_JUMP_WAKE = ("kailo_house", 5, 8, (0, 1))
    # The boat quest (Frankie, 10/28 and 10/31): Ama asks 200 koa wood (Frankie, 11/2; it was 50) and 3,000
    # pule (Frankie, 11/12; it was 1000). The wood he takes; the pule he hands back for provisions, never
    # taking it from his old teacher's son. The starting wallet holds 1,000, so the
    # first wallet (5,000), Noelani's, is needed (Frankie, 11/12). The flags:
    # BOAT_ASKED once he has asked, BOAT_WOOD once the wood is in, BOAT_FIXED
    # once the Meialana is mended. All the lines are Claude's drafts (10/31).
    BOAT_WOOD = 200
    BOAT_PULE = 3000  # Frankie, 11/12; it was 1000
    BOAT_ASKED, BOAT_WOOD_FLAG, BOAT_FIXED = "boat_asked", "boat_wood", "boat_fixed"
    BOAT_ASK_LINES = _FIELD.many('Around the village', "BOAT_ASK_LINES")
    BOAT_MORE_WOOD = _FIELD.one('Around the village', "BOAT_MORE_WOOD")
    BOAT_TAKES_WOOD = _FIELD.one('Around the village', "BOAT_TAKES_WOOD")
    BOAT_MORE_PULE = _FIELD.one('Around the village', "BOAT_MORE_PULE")
    BOAT_PULE_TALK = _FIELD.pairs('Around the village', "BOAT_PULE_TALK_LINES")
    BOAT_GAVE_WOOD_LINE = _FIELD.one("Around the village", "BOAT_GAVE_WOOD_LINE")
    COUNTER_LEARNED_LINE = _FIELD.one("Around the village", "COUNTER_LEARNED_LINE")
    BOAT_DONE = _FIELD.one('Around the village', "BOAT_DONE")
    # In the wake's fight, with him on the bench, the swap is taught as a talk
    # between Hina and Maika on the first turn, and then forced: the player
    # picks who sits out, Kailo or Hina, the cursor on Hina; swapped in, he
    # grumbles and gives in, and may go straight back out after (game/answers.md,
    # the demo line, Frankie 10/30). Tawiri cannot be swapped out in this fight.
    # Claude's drafts, for Frankie to reword.
    SWAP_TALK = _FIELD.pairs('Around the village', "SWAP_TALK_LINES")
    SWAP_OUT_CURSOR = "hina"
    # Kailo learns Counter on his own at the start of the Great Boar's fight, once (Frankie,
    # 11/10; it was a lontar in the lodge). Each line is (speaker, line, needs Hina along);
    # then "Kailo learned Counter!". The lines are Frankie's words of 11/10.
    COUNTER_BOSS = "great_boar"
    COUNTER_LEARNER = "kailo"
    COUNTER_MOVE = "counter_guard"
    COUNTER_FLAG = "kailo_learned_counter_guard"
    COUNTER_TALK = tuple((s, l, s == "Hina") for s, l in _FIELD.pairs('Around the village', "COUNTER_TALK_LINES"))
    SWAP_GRUMBLE = _FIELD.pairs('Around the village', "SWAP_GRUMBLE_LINES")
    SWAP_LOCKED = "tawiri"
    # The cartridge still plays the 10/26 lesson, one line and one complaint;
    # its make_art reads these until it is ported.
    SWAP_LESSON_SPEAKER, SWAP_LESSON_LINE = SWAP_TALK[-2]
    SWAP_COMPLAINT = SWAP_GRUMBLE[0][1]
    # A script's Fade (Frankie, 10/23: the wake fades in, and the demo fades
    # out): this long, in the Super Nintendo's sixteen brightness steps. The
    # demo ends on its End's words on black (TO BE CONTINUED), at this size.
    FADE_SECONDS = 0.6
    FADE_STEPS = 15
    CARD_SIZE = 16
    # Before the prologue (Frankie, 10/25 and 10/27): four cards, white on black,
    # each typed out letter by letter, then the taro patch. One card a line, in
    # game/shared/story-field.md, so the dialogue editor shows them (Frankie, 11/4).
    BLURB = _FIELD.many("The opening cards", "BLURB_LINES")


class KaigaraSettings:
    """Kaigara, the Kame shell game in the hunters' lodge (systems/kaigara.py, Frankie 10/26-27).

    The board is the chalk grid on a smooth stone, a point every POINT_GAP
    pixels; the right window holds the two players, the bottom one what is
    going on. Claude's layout and colors (10/27).
    """

    # Gajumaru's name as a person's ``speaker``; Kupulau's Bandari is the one with ``bets``.
    # The Kame in the lodge sits at his table and never walks (Frankie, 10/27): his
    # sheet is ``<sheet>-Sit.png``, sitting then blinking, 16 by 16 each
    # (tools/make_kame.py); he blinks for BLINK_SECONDS every BLINK_EVERY.
    SIT_SHEET = "{}-Sit.png"
    BLINK_EVERY = 3.5
    BLINK_SECONDS = 0.2
    # His low table with the board: facing it is talking to him.
    TABLE = "board_table"
    # His scenes (game/shared/story-kaigara.md).
    # His name, Okinawan for the banyan tree (Frankie, 10/27).
    SPEAKER = "Gajumaru"
    # Meeting him the first time, then his questions every time (Frankie, 10/27).
    MEET_SCENE = "kaigara_meet"
    MENU_SCENE = "kaigara_menu"
    # Meeting him finds the Kame's Lore page (Frankie, 10/27).
    MET_EVENT = "event kaigara_met"
    # The questions in his menu, by the flag each answer sets: its scene is
    # ``kaigara_<flag>``, and so is the Lore event it sets off (game/shared/lore.md).
    QUESTIONS: tuple = ("home", "trip", "what")
    # Met once: after that, straight to his questions.
    MET_FLAG = "kaigara_met"
    FIRST_WIN_SCENE = "kaigara_first_win"
    WIN_SCENE = "kaigara_win"
    LOSE_SCENE = "kaigara_lose"
    DRAW_SCENE = "kaigara_draw"
    # The answer in the offer that plays a game.
    PLAY = "play"
    # He talks REALLY slowly, and his lines cannot be hurried (Frankie, 10/26):
    # this many letters a second, Config's message speed or not.
    SLOW_CHARS_PER_SECOND = 9

    # The board, as the mockup (game/pygame/docs/design/kaigara-board-preview.svg,
    # 10/27): a gray stone slab flecked darker, its chalk grid a point every
    # POINT_GAP pixels with five star points; every color here so it is easy to restyle.
    STONE_RECT = (6, 6, 148, 148)
    STONE_CORNER = 6
    POINT_GAP = 16
    FIRST_POINT = (16, 16)
    STONE = (85, 89, 94)
    STONE_EDGE = (44, 47, 51)
    STONE_FLECKS: tuple = ((74, 78, 83), (79, 83, 88), (98, 102, 107))
    FLECK_COUNT = 110
    CHALK = (236, 231, 214)
    STAR_POINTS: tuple = ((2, 2), (6, 2), (4, 4), (2, 6), (6, 6))
    # A cowrie: an oval, its toothed slit, a glint. Black is the player's, cream his.
    SHELL_SIZE = (13, 10)
    BLACK_SHELL = (43, 33, 29)
    BLACK_EDGE = (18, 12, 10)
    BLACK_SLIT = (122, 106, 90)
    WHITE_SHELL = (241, 228, 196)
    WHITE_EDGE = (168, 149, 110)
    WHITE_SLIT = (92, 74, 50)
    # His last shell has a yellow ring; the cursor is four yellow corners.
    MARK = (255, 216, 74)
    RING_RADIUS = 8
    CURSOR_REACH = 7
    CURSOR_ARM = 3

    # The right window: his face, his name, the shells taken, Pass and Resign.
    SIDE_RECT = (158, 6, 92, 148)
    FACE_FRAME = (240, 232, 216)
    TAKEN_COLOR = (138, 138, 138)
    # The bottom window: his slow talk, or what is going on.
    MESSAGE_RECT = (6, 160, 244, 58)

    # He thinks at least this long before each shell, and longer while his line
    # is still typing, then a beat more (he is slow).
    THINK_SECONDS = 1.4
    AFTER_LINE_SECONDS = 0.6

    # The words on the board. Claude's drafts, for Frankie to reword; the
    # mockup's two lines of his are its own.
    TITLE = "Kaigara"
    TAKEN = "Taken"
    MENU: tuple = ("Pass", "Resign")
    START = _FIELD.one('Kaigara', "START")
    THINKING: tuple = _FIELD.many('Kaigara', "THINKING_LINES")
    KAME_PASSES = _FIELD.one('Kaigara', "KAME_PASSES")
    CANNOT = _FIELD.keyed('Kaigara', "CANNOT")
    SCORE = _FIELD.one('Kaigara', "SCORE")
    WIN = _FIELD.one('Kaigara', "WIN")
    LOSE = _FIELD.one('Kaigara', "LOSE")
    DRAW = _FIELD.one('Kaigara', "DRAW")
    RESIGNED = _FIELD.one('Kaigara', "RESIGNED")

    # The Bandari in Kupulau's lodge plays for kupang (Frankie, 11/1): the player picks the
    # stake, one to STAKE_MAX (``systems/kaigara.STAKE_MAX``), and he plays a little smarter
    # than Gajumaru. He is a stand-in: his name and every word here are Claude's
    # placeholders, and he talks at an ordinary speed, being no Kame.
    BANDARI_SPEED = 40
    BANDARI_START = _FIELD.one('Kaigara', "BANDARI_START")
    BANDARI_THINKING: tuple = _FIELD.many('Kaigara', "BANDARI_THINKING_LINES")
    BANDARI_PASSES = _FIELD.one('Kaigara', "BANDARI_PASSES")
    STAKE_LABEL = _FIELD.one('Kaigara', "STAKE_LABEL")
    STAKE_ASK = _FIELD.one('Kaigara', "STAKE_ASK")
    STAKE_NO = _FIELD.one('Kaigara', "STAKE_NO")
    STAKE_NONE = _FIELD.one('Kaigara', "STAKE_NONE")
    STAKE_INTRO = _FIELD.one('Kaigara', "STAKE_INTRO")
    STAKE_WIN = _FIELD.one('Kaigara', "STAKE_WIN")
    STAKE_LOSE = _FIELD.one('Kaigara', "STAKE_LOSE")
    STAKE_DRAW = _FIELD.one('Kaigara', "STAKE_DRAW")
    STAKE_NO_LINE = _FIELD.one('Kaigara', "STAKE_NO_LINE")


class TutorialSettings:
    """Hina's tutorial in the taro patch fight (core/battle_tutorial.py, Frankie 10/26).

    Every line is a draft for Frankie to rewrite, in Hina's voice: bossy,
    a little prickly, caring without saying so. One short box each.
    """

    SPEAKER = "Hina"
    SCENE = "taro_patch"
    ASK = _FIELD.one("Hina's battle lesson", "ASK")
    # NO on top and chosen, so the tutorial is not skipped by accident (Frankie, 10/26).
    ANSWERS: tuple = ("No", "Yes")
    YES = _FIELD.one("Hina's battle lesson", "YES")
    NO = _FIELD.one("Hina's battle lesson", "NO")
    # The lessons the taro patch never reached, kept on the save for later fights (Frankie, 10/26; built 11/3).
    LESSONS_LEFT_FLAG = "hina_lessons_left"
    # The warm-up, on Kailo's first turn: the turn order bar, then Attack.
    TURN_BAR: tuple = _FIELD.many("Hina's battle lesson", "TURN_BAR_LINES")
    ATTACK = _FIELD.one("Hina's battle lesson", "ATTACK")
    # The stroke list: the yellow points, then one Light at a time (Frankie,
    # 10/26): the first two lines are his words, the miss is a draft. A
    # Light that misses gets LIGHT_MISSED and a try again, every time.
    STAMINA = _FIELD.one("Hina's battle lesson", "STAMINA")
    LIGHT_FIRST = _FIELD.one("Hina's battle lesson", "LIGHT_FIRST")
    LIGHT_AGAIN = _FIELD.one("Hina's battle lesson", "LIGHT_AGAIN")
    LIGHT_MISSED = _FIELD.one("Hina's battle lesson", "LIGHT_MISSED")
    # Once a stroke lands: the blue pips under his HP.
    MANA: tuple = _FIELD.many("Hina's battle lesson", "MANA_LINES")
    # Strong, after the second Light lands (drafts): the chance every landed
    # stroke raised, then he moves to Strong himself watching the bar, and
    # FACE_BEAT seconds after the cursor rests there (Claude's number), the
    # bar moving (Frankie's line) and fatigue, which nothing else shows.
    STRONG_CHANCE = _FIELD.one("Hina's battle lesson", "STRONG_CHANCE")
    STRONG_MOVE = _FIELD.one("Hina's battle lesson", "STRONG_MOVE")
    FACE_BEAT = 0.5
    FACE = _FIELD.one("Hina's battle lesson", "FACE")
    FATIGUE = _FIELD.one("Hina's battle lesson", "FATIGUE")
    STRONG_GO = _FIELD.one("Hina's battle lesson", "STRONG_GO")
    MISSED = _FIELD.one("Hina's battle lesson", "MISSED")
    # The warm-up's end. Defend and Weapon build 1 mana; items build none yet.
    OTHER_MANA = _FIELD.one("Hina's battle lesson", "OTHER_MANA")
    # Defend, on the next turn after the warm-up (Frankie, 10/27: she says where it is and has
    # you do it; drafts): left of the commands, then Defend itself.
    DEFEND_WHERE = _FIELD.one("Hina's battle lesson", "DEFEND_WHERE")
    DEFEND_GO = _FIELD.one("Hina's battle lesson", "DEFEND_GO")
    FLAME_KICK = _FIELD.one("Hina's battle lesson", "FLAME_KICK")
    HEAL_KAILO = _FIELD.one("Hina's battle lesson", "HEAL_KAILO")
    HEAL_SELF = _FIELD.one("Hina's battle lesson", "HEAL_SELF")
    # The stance change, once Kailo has done Flame Kick (Frankie, 10/26): the
    # fight has turned when Hina is under STANCE_HINA_BELOW of her HP and
    # Kailo over STANCE_KAILO_ABOVE of his (Claude's numbers).
    STANCE_HINA_BELOW = 0.5
    STANCE_KAILO_ABOVE = 0.75
    STANCE = _FIELD.one("Hina's battle lesson", "STANCE")
    STANCE_GO = _FIELD.one("Hina's battle lesson", "STANCE_GO")
    STANCE_SHOWN = _FIELD.one("Hina's battle lesson", "STANCE_SHOWN")
    WAVE_GUARD = _FIELD.one("Hina's battle lesson", "WAVE_GUARD")
    # An item when someone is under ITEM_LOW_BELOW of their HP and Hina
    # cannot Heal now (Claude's number); {item} is what it uses.
    ITEM_LOW_BELOW = 1 / 3
    # Her "I can't Heal yet" always says why (Frankie, 11/6): it is not her turn yet (Kailo is
    # acting), or she is out of mana (she is acting); Claude's lines.
    ITEM_HINA = _FIELD.one("Hina's battle lesson", "ITEM_HINA")
    ITEM_KAILO = _FIELD.one("Hina's battle lesson", "ITEM_KAILO")
    ITEM_KAILO_MANA = _FIELD.one("Hina's battle lesson", "ITEM_KAILO_MANA")
    ITEM_KAILO_STANCE = _FIELD.one("Hina's battle lesson", "ITEM_KAILO_STANCE")
    ITEM_SELF = _FIELD.one("Hina's battle lesson", "ITEM_SELF")
    # When her Heal is in her other stance, not short of mana (Frankie, 11/3; Claude's draft).
    ITEM_SELF_STANCE = _FIELD.one("Hina's battle lesson", "ITEM_SELF_STANCE")
    # Burning, no heal takes, so she asks for a Kukui, never a heal item; with no Kukui she says
    # nothing (Frankie, 11/4, after Mark's Episode 4 spent a Noni on her burn). Claude's drafts.
    ITEM_HINA_BURN = _FIELD.one("Hina's battle lesson", "ITEM_HINA_BURN")
    ITEM_KAILO_BURN = _FIELD.one("Hina's battle lesson", "ITEM_KAILO_BURN")
    ITEM_SELF_BURN = _FIELD.one("Hina's battle lesson", "ITEM_SELF_BURN")
    # The timed block (Frankie, 10/31): the first time the meter comes up in the
    # taro patch with her lessons on, the fight holds and she points at it. Drafts.
    BLOCK: tuple = _FIELD.many("Hina's battle lesson", "BLOCK_LINES")
    # Three perfect parries in a row, Hina answers that lesson line, in any fight she
    # is in, once ever (Frankie, 11/4: the line and the first-time-only).
    DODGE_PRAISE_FLAG = "hina_praised_dodges"
    DODGE_PRAISE_AFTER = 3
    DODGE_PRAISE = _FIELD.one("Hina's battle lesson", "DODGE_PRAISE")
    # Escape (game/answers.md, Frankie 10/26 and 10/31): in a later fight, never a
    # boss or story fight, once ever, when Kailo and Hina are both under
    # ESCAPE_LOW_BELOW of their HP (Claude's number) and her Heal is not there. She
    # suggests running and the cursor moves to Escape, nothing forced. Drafts.
    ESCAPE_LOW_BELOW = 1 / 3
    ESCAPE_FLAG = "hina_taught_escape"
    # The boar hint (Frankie, 11/3), the only one the game gives for them: the first
    # time a nature monster heals, in any fight, once ever, with Hina standing. The
    # line is Claude's draft; it says nature heals and burns, and leaves the rest
    # to the player (no hand holding, game/answers.md).
    NATURE_HEALS_FLAG = "hina_hinted_nature_heals"
    NATURE_HEALS = _FIELD.one("Hina's battle lesson", "NATURE_HEALS")
    # Team Up (Frankie, 11/3, after Mark's playtest): the first time one is open with Hina in it,
    # in any fight, once ever. Claude's drafts.
    TEAM_UP_FLAG = "hina_taught_team_up"
    TEAM_UP: tuple = _FIELD.many("Hina's battle lesson", "TEAM_UP_LINES")
    ESCAPE: tuple = _FIELD.many("Hina's battle lesson", "ESCAPE_LINES")
    # Her first escape line when Heal is in her other stance, not short of mana (Frankie, 11/3).
    ESCAPE_STANCE = _FIELD.one("Hina's battle lesson", "ESCAPE_STANCE")
    # Her first escape line when it is her turn and she is out of mana (Frankie, 11/6).
    ESCAPE_MANA = _FIELD.one("Hina's battle lesson", "ESCAPE_MANA")
    # The Yes/No window's width, and the dim: everything outside the
    # highlight times this, half (color math on the cartridge).
    CHOICE_WIDTH = 64
    DIM = (128, 128, 128)


class SailingSettings:
    """Sailing the Meialana (Frankie, 10/31; the sailing line in ``game/answers.md``;
    ``systems/sailing.py``, ``core/scenes/sea_scene.py``).

    The sea is the to-scale picture map, 25 miles a tile (``data/sea_map.json``,
    made by ``tools/mapgen/seapic.py``). Moving on it passes the days and eats
    the food; standing still passes nothing. Every number here is Claude's
    first pick, to tune after playing, unless it says otherwise.
    """

    # The boat on the sea is the harbor's Meialana shrunk by a whole number to no
    # wider than this, as the map editor's icon for it is (Frankie, 11/2).
    BOAT_WIDTH = 16
    # Scene select's "Free sailing" (Frankie, 11/2), to explore the sea and check the map: set
    # only there, in the party's flags so it stays with that game and never reaches a normal one.
    # While it is set no day eats food, no hunger warning or game over, no monsters swim.
    FREE_FLAG = "free_sailing"
    # The Meialana's own speed through the water: an ordinary voyaging ship, about five
    # knots, some 140 miles a day (the canon, lore/location/te-pito-o-nuitai.md).
    MILES_PER_DAY = 140.0
    # The whirlpool's current in each zone, outermost first, in knots (the canon), running
    # clockwise: south past Māla Iki and Lanuloa (Frankie, 10/31). A knot is 27.6 miles a day.
    CURRENT_KNOTS: tuple = (1.7, 2.5, 4.0, 5.0, 8.0, 12.0)
    MILES_PER_KNOT_DAY = 27.6
    # The Meialana sails no further in than this zone (2, the Surge Zone): from the
    # Tempest Ring in, only legendary ships live (the canon). How far is open.
    INNERMOST_ZONE = 2
    # One day at sea is this many seconds of sailing; Māla Iki to Lanuloa is about ten days.
    SECONDS_PER_DAY = 1.0
    # The sea's picture at this many screen pixels a tile: 32 by 28 tiles fill the screen.
    TILE_PIXELS = 8
    # Each person aboard eats one food a day (Frankie, 10/31).
    FOOD_PER_PERSON = 1
    # How many days each food keeps at sea; anything not here is not voyage food. Past its
    # days it goes to waste (Frankie, 10/31). What kept on real voyages keeps longest:
    # coconuts, 'uala, poi; fresh fish and cooked dishes spoil in a day or two. Open:
    # each food's days (waiting on Frankie). Pa'i 'ai, dried fish and salted pork keep
    # longest of all, once they are items.
    FOOD_DAYS: dict = {
        "niu": 60, "uala": 30, "taro": 14, "poi": 14, "ulu_poi": 10, "kulolo": 10,
        "noodles": 20, "egg": 7, "pineapple": 5, "breadfruit": 3, "cooked_pork": 4, "cooked_fish": 2, "laulau": 3, "puaa_anana": 3, "haupia": 3,
        "pork": 2, "saimin": 2, "ramen": 2, "seaweed": 2, "fried_egg": 1,
        **dict.fromkeys(ItemSettings.FISH, 1),
    }
    # The number that shows how far the food reaches. Its name is open (waiting on Frankie).
    FOOD_LABEL = "Food"
    # The turn-back warning: when the food reaches no further than the nearest port plus
    # this many days. It comes again once the food reaches further than that.
    WARN_SPARE_DAYS = 1
    WARNING = _FIELD.one('Setting sail', "WARNING")
    STARVED = _FIELD.one('Setting sail', "STARVED")
    TOO_WILD = _FIELD.one('Setting sail', "TOO_WILD")
    # The ports: places on the sea map the Meialana can go ashore at, by the spot's name in
    # sea_map.json. Bumping the coast within REACH tiles of one asks to go ashore.
    PORTS: tuple = ("Kulāiwi", "Māla Iki", "Kupulau")
    # The ports with land built to walk on; the rest only say so.
    BUILT_PORTS: tuple = ("Kulāiwi", "Kupulau")
    # Back ashore at Kulāiwi, Kailo stands on the pier below the Meialana, facing her.
    HOME_ROOM = "harbor"
    HOME_STAND = (5, 10)
    REACH = 3.0
    ASHORE_ASK = _FIELD.one('Setting sail', "ASHORE_ASK")
    # Where the boat lands at each port: the room and the tile Kailo stands on, facing the
    # Meialana (Kupulau: Frankie, 11/1; the town is built, first pass).
    LANDINGS: dict = {"Kulāiwi": ("harbor", (5, 10)), "Kupulau": ("kupulau_harbor", (5, 10))}
    # A place's name shows on the sea once Kailo has been there or someone marked it on his
    # map, never from hearsay (Frankie, 10/31): the flag ``KNOWN_FLAG + name``.
    KNOWN_FLAG = "sea_known:"
    # Leaving Kulāiwi the first time: one last "are you sure" (Frankie, 10/31; words Claude's).
    LEAVE_FLAG = "left_kulaiwi"
    LANDFALL_LINE = _FIELD.one("Setting sail", "LANDFALL_LINE")
    LEAVE_ASK = _FIELD.one('Setting sail', "LEAVE_ASK")
    # Ama explains provisions once, on the dock, before the first voyage (Frankie, 10/31;
    # words Claude's draft).
    AMA_LINES: tuple = tuple(f"{s}: {l}" for s, l in _FIELD.pairs('Setting sail', "AMA_LINES"))
    # The browser version ends its demo at Lanuloa (Frankie, 11/2): landing at Kupulau the
    # first time says so, once a save, then play goes on. ``BROWSER`` is what the field asks
    # ("is this the browser?"); a test sets it True to see the note without one.
    DEMO_END_FLAG = "demo_end_shown"
    DEMO_END_PORT = "Kupulau"
    DEMO_END_LINE = _FIELD.one("Landing", "DEMO_END_LINE")
    BROWSER: bool = sys.platform == "emscripten"
    # The flag set once the Meialana can sail: the boat quest done. Until then the boat
    # offers only Cook, Nap and Leave.
    READY_FLAG = "meialana_ready"
    # Scene select's "Setting sail": the food the village sends with him, until the goodbyes
    # are built: 12 days of food for the four of them (Frankie, 11/1).
    TEST_PROVISIONS: dict = {"niu": 24, "uala": 18, "mackerel": 6}
    # Monsters at sea (Frankie, 10/31): this many swim within ROAM tiles of the boat,
    # drifting at DRIFT tiles a second; running into one starts its fight.
    MONSTERS = 4
    ROAM = 14.0
    DRIFT = 1.2
    HIT = 0.8
    MONSTER_FIGHT = "sirena"   # the sirena pair from the shared fights, a placeholder
    # Seconds after a fight before the next monster can start one.
    GRACE_SECONDS = 1.5
    DOT_COLOR = (248, 224, 32)
    FIN_COLOR = (40, 40, 56)
    LABEL_COLOR = (255, 255, 255)


class LanuSettings:
    """Lanu's posts and the sage's gift (Frankie, 11/3, changed 11/4): leave water at all five of her
    posts on the map, then talk to the Lanu sage, and he gives Hina's Revive, unless the temple's
    priest sold it first, and the priest stops selling it once the sage gives it. The lines are
    Claude's placeholders."""

    # Five posts (Frankie, 11/4): blocks_room, gate_yard, key_room, pono_farm and river_bank.
    # Each watered post is a party flag POST_FLAG.format(cell, col, row); CUPS_FLAG counts them.
    CUPS = 5
    CUPS_FLAG = "lanu_cups"
    POST_FLAG = "lanu_post:{}:{}:{}"
    BLESSED_FLAG = "lanu_blessing"
    GIFT = "revive_shell"
    # The temple's row for the same lontar is "once", so this flag, set when the sage gives it
    # or the priest sells it, shuts both (Frankie, 11/4).
    GONE_FLAG = "sold:revive_shell"
    # Said by the sage when Kailo has not watered them all (Claude's placeholder lines).
    LEFT_ONE = _FIELD.one("Lanu's grove", "LEFT_ONE")
    LEFT_MANY = _FIELD.one("Lanu's grove", "LEFT_MANY")
    ASK = _FIELD.one("Lanu's grove", "ASK")
    # What Kailo says at a post (Claude, 11/4; Frankie wanted an offering, said plainly, and a short
    # direct line once it is done): water in the bag, none in the bag, and already watered.
    OFFER = _FIELD.one("Lanu's grove", "OFFER")
    DRY = _FIELD.one("Lanu's grove", "DRY")
    DONE = _FIELD.one("Lanu's grove", "DONE")
    POURED = _FIELD.one("Lanu's grove", "POURED")
    ENOUGH = _FIELD.one("Lanu's grove", "ENOUGH")
    BLESSING = _FIELD.many("Lanu's grove", "BLESSING_LINES")


class SchoolSettings:
    """The temple school upstairs in Kulaiwi's temple of Haka (Frankie, 11/10). Its children and
    teacher answer questions from ``data/asks/school_*.json``; with Hina in the party each of them
    first speaks to her once, and she answers. Every line is Claude's placeholder."""

    ROOM = "kulaiwi_school"
    # What the children call Hina (Frankie, 11/10: "Bu Hina"; Bu is short for Ibu, how children
    # address a woman teacher in Malay and Indonesian). Written {teacher} in the ask files.
    TEACHER_TITLE = "Bu Hina"
    TEACHER_KEY = "{teacher}"
    # The member whose company changes what the children say, and her party id.
    TEACHER = "hina"
    # A party flag per child, set once Hina has been spoken to by that child.
    MET_FLAG = "school_hina:{}"


class TollSettings:
    """The Nuno sa Tulay, the toll Nuno on the river bend's boardwalk (Frankie, 11/12).

    He blocks the bridge and asks PRICE pule every visit: paid, he stands aside until the party
    leaves the room (Frankie, 11/12). "I'm not paying that.", or asking for it once paid, is a boss fight
    with a stronger, purple Nuno of water and spirit, and beating him opens the tier 2 element slot
    (the shared file's ``unlock_bosses``) and sets the person's ``gone`` flag: he never comes back.
    The lines are Claude's drafts, written like a troll guarding a bridge.
    """

    PRICE = 100   # Frankie, 11/12
    # Every word he says is on the person in ``data/cells/river_bend.json`` (its ``say``), edited in the
    # Workshop (Frankie, 11/13); only numbers and the music are here.
    MUSIC = "boss"
