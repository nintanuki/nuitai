# Nuitai RPG

A turn-based, sprite-based JRPG set in the world of **Nuitai**, an ocean planet of scattered islands that spiral around a permanent whirlpool, where magic is cast by motion and every fighter draws on two of six elements.

Long-term inspirations: *Chrono Trigger*, *Final Fantasy IV*, *Dragon Quest*. The eventual target is a complete SNES-style 2D JRPG with hand-drawn pixel art and an original score, all created by the author without using free assets.

## Status

**Layer 1 in progress.** `python main.py` gives a title screen, a walkable overworld where monsters walk the map, save and load, and a battle. **As of 2026-10-07 the battle runs the rules from the browser battle test** (deleted 11/3): visible turn order, stats shaped by elements, shared element moves and one special each, for Kailo, Hina and Tawiri against the Beast pack. The rest of the browser's roster is not ported yet.

**As of 2026-10-17 the game draws on a Super Nintendo screen** (D-158, D-444, D-445): 256 by 224 pixels, enlarged by a whole number to fill the window (F11 for the whole screen), map tiles 16 pixels, walkers one 16 by 16 tile, Pokémon style (D-573), letters 8 by 8 on 16 pixel rows (32 to a line, so names shorten to first names), portraits 32 on the party screen. The battle window is Final Fantasy's: commands on the left, the party's names, bars and HP on the right. Every size is in `settings.py`; nothing is ever smoothed. Kailo walks as Ninja Adventure's Boy (CC0), unedited; `tools/screens.py` saves a picture of every screen into `docs/screens/`; `python tools/snes_check.py` lists every picture, room, fight or piece of code that breaks the Super Nintendo limits (D-577; colors per 8 by 8 tile, palettes and different tiles per room, a fight's monsters against sprite memory, sprites per room; the numbers are `game/snes/tools/snes_limits.py`, shared with the ROM's `make_art.py`); `tests/test_snes_limits.py` runs it and fails on anything new.

The game is being built in clearly-defined layers. See [docs/ROADMAP.md](docs/ROADMAP.md) for the full plan and acceptance criteria for each layer.

| Layer | Description | Status |
| ----- | ----------- | ------ |
| 0 | Engine spike: scenes, save/load, dialogue box, turn queue, in-window text rendering | In progress |
| 1 | Vertical-slice text demo: three-character party, one small dungeon, one boss | Planned |
| 2 | Content & polish on the same engine: town hub, second dungeon, full element coverage | Planned |
| 3 | Dragon-Quest stage: tile maps + sprite encounters, narration still in the text box | Planned |
| 4 | Art & audio pass: original sprites, original music, animated battles, ship/whirlpool system | Planned |
| 5 | Full vision: airship, Po'lelo stone-speech puzzles, complete world, full story arcs | Planned |

Every layer is **shippable on its own**. The Dragon Quest layer in particular is treated as a legitimate destination, not a stop-over.

## The world

Nuitai is documented in [lore/INDEX.md](../../lore/INDEX.md) — 114 articles across 12 categories (people, places, organizations, languages, professions, species, rituals, technologies). The World Anvil export is preserved at [lore/LOREDUMP.html](../../archive/world-anvil-2026-09/LOREDUMP.html). The original World Anvil Page can be found [here](https://www.worldanvil.com/w/nuitai-nintanuki).

The artistic and design pillars that come from the lore are summarized in [docs/VISION.md](docs/VISION.md).

## The starting party

The Layer-1 demo will have three playable characters with different battle rolls. Together they cover all six elements with no overlap.

| Character | Elements | Role | Source article |
| --------- | -------- | ---- | -------------- |
| **Kailo** | Fire + Water | Fighter / Defender | [lore/person/kailo-the-cook.md](../../lore/person/kailo-the-cook.md) |
| **Hina** | Light + Nature | Enhancer / Healer | [lore/person/hina-the-māla-priestess.md](../../lore/person/hina-the-māla-priestess.md) |
| **Tawiri** | Spirit + Shadow | Blaster / Saboteur | [lore/person/tawiri-the-elderly-caller.md](../../lore/person/tawiri-the-elderly-caller.md) |

A fourth character, **Maika** (Nature + Spirit, healer / blaster: [lore/person/maika-the-maki-sage.md](../../lore/person/maika-the-maki-sage.md)), will also appear as an NPC in the demo and join the party in Layer 2.

## Requirements

- Python 3.10+
- `pygame` 2.5+

## Run

```powershell
python main.py
```

## The Workshop: painting the rooms

The map is screens: every room is one screen of 16 by 14 tiles, its own file in
`data/cells/`, and walking off an edge puts the party in the room next door. **The
Workshop** is the paint program for them (D-663), a program of its own, not in the game
(Frankie, 10/23): double-click `Workshop.pyw`, or run `python workshop.py`. It opens its own window: the room on the left, drawn exactly as the
game draws it, a palette of tiles, monsters and people on the right with a map of the rooms
under it, and a bar of words along the bottom.

Along the top are a menu bar (File, Edit, View, Tools, Help) and a toolbar, drawn in the game's
font (Frankie, 11/2; `workshop_menu.py`). Every menu item shows its key on the right, so the menus
are also the list of keys, and pointing at an item or a button says in the bottom bar what it
does. **Help** (`F1`) opens a help page on every tool; **Options** (Ctrl+,) sets the grid, the map
and the window size the Workshop opens with, kept in `workshop_options.json` on each computer
(git ignores it); **File, Open room** (Ctrl+O) lists every room by name. These three are small
tkinter windows (`workshop_windows.py`). It is the first step toward a full game engine editor,
grown slowly (Frankie, 11/2). `tests/test_workshop_menus.py` checks the menus, redo and the jump
to a person's dialogue.

| Do this | To |
| ------- | -- |
| Left click or drag on the room | Put the brush down: paint a tile, or stand a monster or a person there |
| Press and drag on a thing | Move it; a house keeps its inside and its door |
| Right click on a thing | Take it away |
| Right click on a bare tile | Pick that tile up as the brush |
| Click a brush in the palette | Pick it |
| Click a room in the map, or the arrow keys | Open it |
| Click an empty slot beside a room in the map, twice | Make a new room there (its edges open where the neighbor's do) |
| Right click a room in the map, twice | Drop that room |
| `S` | Save every changed room |
| `Z` | Undo the last change in this room |
| `Shift+Z` or Ctrl+Y | Redo what undo took back |
| `P` | Save, then play the game in this room where the mouse is, with fights off |
| `R` | Rename the room (type, then Enter) |
| `T` | Turn the person under the mouse (or flip the monster) |
| `F` | Make the monster under the mouse stand still, or wander again |
| Double click a person, or `D` | Open the dialogue editor at what they say (someone who says nothing yet gets a small window to type their first words) |
| `L`, or Tools, Dialogue editor | Open the dialogue editor: every line of dialogue, to read and change (below) |
| `G` | Show or hide the grid |
| `Delete` twice | Drop the room |
| Ctrl+`+` and Ctrl+`-` | Make the window bigger or smaller |
| `F1` | Help |
| `Esc` | Close a menu; otherwise leave, twice if something is unsaved |

**The dialogue editor** (`L`, Frankie 10/31, called the lines window until 11/2; `workshop_lines.py`,
its model `core/dialogue_editor.py`) shows every line of dialogue in one place. On the left are
the story scenes by name, from `game/shared/story*.md`, then the *Field lines*, said outside the
scenes (Noelani's, the garden's, the hens' and the rest), then the people in each room and the
questions they answer (`core/dialogue_villagers.py`). A double click on a person in the Workshop
opens it at what they say; the room is saved first, as `P` does, since the editor reads the file.
When the editor saves a room's file, the Workshop takes those people's new words and keeps
anything else not yet saved. Pick one and its rows show numbered, in the order the game
plays them: the speaker in their element's color (people outside the party in plain white), any
condition (`if hina`), and the stage directions dimmed so it is clear where a line falls. Click
a line to edit it in the box under the list: its words, its speaker (the scene's cast to pick
from; blank makes it narration) and its condition; Enter keeps the change. *Add before* and *Add
after* put a new line next to any row, a stage direction too: the game plays it right there,
after the direction above it finishes and before the one below starts. *Delete line* takes a line
out, *Undo* (or Ctrl+Z) steps back. Directions themselves are not edited here yet. A line's typing
speed (`(fast)`, `(quick)`, `(slow)`) stays as it is. Words in curly brackets, like `{things}`,
are filled in by the game and must stay.

The field lines were strings in `settings.py` until 10/31; Frankie wanted every line of dialogue in
one place, so they are in `game/shared/story-field.md`, read by `core/field_lines.py`.
`settings.py` keeps every name (`StewSettings.OFFER_LINES`...) and fills it from that file, so the
game and the cartridge build read them as before. Who says a field line is decided by the game,
so the window does not change a field line's speaker, and it refuses an edit the game could not
read (a second line under a name that takes one).

*Save* (or Ctrl+S) writes only the changed lines; nothing else in the file moves. It first reads
the file again: if it changed since the window opened it (by hand or by another program), the
two sets of changes are put together when they touch different lines, and where both changed the
same lines it shows both, one place at a time, and asks which stays. It never overwrites without
asking. *Play scene* saves, then starts the game at that scene (with the story `C` picked,
fights off). *Light* and *Dark* switch the window's look. Closing it with changes unsaved asks
first, and so does leaving the Workshop. `tests/test_dialogue_editor.py` checks the reading and
the saving on copies of the files: saved with no edits, every file stays the same to the byte.

A monster whose kind has a fixed fight (the Great Boar) is placed as a boss: it stands still
and is gone for good once beaten. A shopkeeper's `shop` is set in the room's file for now.
The Workshop is a desktop tool: it is not in the browser build and never goes on the cartridge,
which reads the same room files through `game/snes/tools/make_art.py`.

## Controls (defaults)

Every in-game action has both a keyboard binding and a controller binding. The controller does only what a Super Nintendo pad can do on the cartridge or in an emulator (Frankie, 10/23), so the window's own keys, fullscreen and mute, are keyboard only. The controller column names the face buttons by position, as on a Super Nintendo pad, whatever the pad prints (Frankie, 10/24); on any pad the button in the same position does the same thing. A pad can be plugged in or out while the game runs.

| Action                       | Keyboard                   | Controller             |
| ---------------------------- | -------------------------- | ---------------------- |
| Move / navigate menus        | Arrow keys *or* `W A S D`  | D-pad *or* left stick  |
| Confirm / advance text (A)   | `Enter` / `Z` / `Space`    | `A` (east)             |
| Cancel / back (B)            | `Backspace` / `X`          | `B` (south)            |
| Open the field menu, move the text box (X) | `Tab`        | `X` (north)            |
| Use the set tool; hold for the tool wheel and pick with a direction (Y) | `C` | `Y` (west) |
| Pause and unpause, anywhere  | `P`                        | `START`                |
| Area map on the field (again: world map once Kailo has one, else close) | `Shift` | `SELECT` |
| Toggle fullscreen            | `F11`                      |                        |
| Mute and unmute all sound (MUTE shows in green, top right) | `M` |  |
| Reset to the title at once (no quitting inside the game; the window's close button closes it) |  | `L1 + R1 + START + SELECT` |

The pad layout is D-575. Config's Buttons swap A with B and X with Y on the keyboard and the pad alike: with A and B swapped, `X` and `Backspace` confirm and `Z`, `Enter` and `Space` cancel. `Enter` is only ever A's key, never the field menu (Frankie, 10/31: mashing A on empty ground kept opening it). A swap made on the Config screen holds once it closes (Frankie, 10/26).

The desktop game is also an emulator, for testing (Frankie, 10/23; `emulator.py`, not in the browser build or on the cartridge): `F1` freezes the game and opens a file menu (Reset, Save State, Load State, Resume; keyboard or mouse, `F1` or `Esc` closes it), `~` held fast-forwards at 4 times speed, `F2` saves a state and `F4` loads it (one state, `saves/state.pickle`, the whole running game: a menu, a story scene or a fight included; the save slots are untouched). `F3` shows the layout debug overlay.

## Documentation

| Document | Purpose |
| -------- | ------- |
| [docs/VISION.md](docs/VISION.md) | The artistic North Star. What "done" feels like. Largely immutable. |
| [docs/ROADMAP.md](docs/ROADMAP.md) | The six-layer plan. Acceptance criteria and asset requirements per layer. |
| [docs/TODO.md](docs/TODO.md) | The current layer's actionable tasks (code, writing, and art alike). |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | How the code currently fits together. |
| [docs/TESTING.md](docs/TESTING.md) | Manual smoke checks. |
| [docs/CHANGELOG.md](docs/CHANGELOG.md) | Append-only history of every change. |
| [lore/INDEX.md](../../lore/INDEX.md) | Per-article TOC of the Nuitai world bible. |
| [.github/copilot-instructions.md](.github/copilot-instructions.md) | Rules for human or AI editors. |

## Project layout

```
core/            Domain types: elements, scenes, save state, event records.
systems/         Gameplay systems: audio, battle, party, dialogue.
ui/              Renderers and widgets: text box, menu, battle view, world view.
utils/           Pure helpers and one-shot tools (e.g. the lore splitter).
data/            JSON content packs: characters, abilities, enemies, dungeons, dialogue.
assets/          Fonts, graphics, audio.
saves/           Player save files (gitignored).
docs/            Vision, roadmap, architecture, testing, changelog, lore.
crt.py           CRT post-processing overlay.
main.py          Entry point + GameManager.
settings.py      All tunable constants.
```

## Asset credits

- `assets/font/PressStart2P-Regular.ttf` — *Press Start 2P* by Cody "CodeMan38" Boisclair, SIL Open Font License 1.1 (the licence is beside it). Until Frankie draws his own 8 by 8 font.
- `assets/graphics/effects/tv.png` — CRT overlay reused from the arcade cabinet asset set. Originally created and coded by Clear Code of YouTube.
- `assets/graphics/player/kailo.png` — Kailo's walking frames, Ninja Adventure's Boy walk sheet (Pixel-boy, CC0), unedited. A stand-in until Kailo is drawn at 16 by 16 (D-573).
- `../../art/sprites/walkers/` — the four heroes' walking frames, built on a body from a knight in Kenney's Tiny Dungeon (CC0). Credited on the website's credits page.
- The long-term goal is for **all** sprite art, music, and writing to be original work by the author. Free placeholder assets used during early layers will be credited here as they are added, and replaced as the project matures.
