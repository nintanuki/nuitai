"""The party's elements (Frankie, 11/28): owned, never used up, as in Chrono Cross.

An element is an item, named for its move (``ItemSettings.SHELLS`` maps item to move). It is in one of three
places, so every copy is in exactly one:

* **slotted** on a member: the move's id is in ``member.loadout`` (move id to row);
* **in the shared bag**: the item is in ``party.inventory``;
* **in a member's battle bag**: the item is in ``member.bag`` (``systems/battle_bag.py``), where a fight can reach it.

Slotting takes the item from the bag; taking it off puts it back. Out of a fight the source and the destination
are the shared bag, in a fight the member's own battle bag, never the shared one. Who can take an element is
by colour: a single element fits anyone with that element, a dual one only the character with both.

Lontars and kapas teach nobody any more: they are lore, and the item is just the move's name.
"""

from __future__ import annotations

from typing import Any

from core.shared import by_id
from settings import ItemSettings
from systems import battle_bag
from systems.loadout import checked, learn, open_slots, place as place_in_row, reach

FLAG = "elements_owned"      # a saved party has been through the move to owned elements (Party.to_dict writes it)
ITEM_OF: dict[str, str] = {move_id: item for item, (_, move_id) in ItemSettings.SHELLS.items()}


def item_of(move_id: str) -> str | None:
    """The element item that is ``move_id``, or None for a move that has none."""
    return ITEM_OF.get(move_id)


def is_element(item_id: str) -> bool:
    """Whether ``item_id`` is an element item."""
    return item_id in ItemSettings.SHELLS


def move_of(item_id: str) -> dict[str, Any]:
    """The move an element item is."""
    return by_id("moves")[ItemSettings.SHELLS[item_id][1]]


def can_take(member, move: dict[str, Any] | str) -> bool:
    """Whether ``member`` can have ``move`` slotted: they carry every element it names (Frankie, 10/26; 11/28)."""
    move = by_id("moves")[move] if isinstance(move, str) else move
    elements = move.get("elements") or move["element"]
    if isinstance(elements, str):
        elements = [elements]
    return set(elements) <= set(member.elements)


def _in_file_order(ids) -> list[dict[str, Any]]:
    ids = set(ids)
    return [m for m in by_id("moves").values() if m["id"] in ids and not m.get("signature")]


def slotted(member) -> list[dict[str, Any]]:
    """The elements slotted on ``member``, in the shared file's order."""
    return _in_file_order(member.loadout or {})


def in_shared_bag(party) -> list[dict[str, Any]]:
    """The elements in the shared bag, one entry each however many copies, in the shared file's order."""
    return _in_file_order(move_id for move_id, item in ITEM_OF.items() if party.inventory.get(item, 0) > 0)


def in_battle_bag(member) -> list[dict[str, Any]]:
    """The elements in ``member``'s own battle bag, in the shared file's order."""
    return _in_file_order(ItemSettings.SHELLS[i][1] for i in member.bag if i in ItemSettings.SHELLS)


def listed(party, member) -> list[dict[str, Any]]:
    """What the Element screen lists for ``member`` out of a fight: what is slotted on them, then what is in the
    shared bag (the ones they cannot take are still listed, greyed by the screen)."""
    mine = {m["id"] for m in slotted(member)}
    return _in_file_order(mine | {m["id"] for m in in_shared_bag(party)})


def in_fight(member) -> list[dict[str, Any]]:
    """What a fight lists for ``member`` (Frankie, 11/28): what is slotted on them and what is in their own battle
    bag that they can take; never the shared bag."""
    return _in_file_order({m["id"] for m in slotted(member)}
                          | {m["id"] for m in in_battle_bag(member) if can_take(member, m)})


def known_for(member, flags: dict[str, bool] | None = None) -> list[dict[str, Any]]:
    """The moves a member has, for the screens that draw their slots: what is slotted on them. A member who has
    never had a loadout (a test, a tool) has their starting kit."""
    if member.loadout is None:
        from core.factories import known_moves
        return known_moves(member.id, member.elements, flags)
    return slotted(member)


def copies(party, move_id: str) -> int:
    """How many copies of ``move_id`` the party owns, wherever they are."""
    item = ITEM_OF.get(move_id)
    count = party.inventory.get(item, 0) if item else 0
    for member in list(party.members) + list(party.away):
        count += (move_id in (member.loadout or {})) + member.bag.count(item)
    return count


# -- moving them ------------------------------------------------------------------------------------------


def _bag_has(party, member, item: str, in_a_fight: bool) -> bool:
    return item in member.bag if in_a_fight else party.inventory.get(item, 0) > 0


def _bag_take(party, member, item: str, in_a_fight: bool) -> None:
    if in_a_fight:
        member.bag.remove(item)
        return
    party.inventory[item] -= 1
    if party.inventory[item] <= 0:
        del party.inventory[item]


def _bag_put(party, member, item: str, in_a_fight: bool) -> bool:
    """Put ``item`` in the bag a change draws on; False when a battle bag has no room."""
    if in_a_fight:
        if battle_bag.room(member) <= 0:
            return False
        member.bag.append(item)
        return True
    party.inventory[item] = party.inventory.get(item, 0) + 1
    return True


def place(party, member, move_id: str, row: int | None, in_a_fight: bool = False,
          swap_with: str | None = None, slots: list[int] | None = None) -> list[tuple[str, str]] | None:
    """Put ``move_id`` in tier ``row`` of ``member``'s slots (None takes it off), the bag it comes from or goes back
    to the shared one, or in a fight the member's own battle bag.

    Returns what changed as ("learned" | "forgot", move id), or None when nothing could be done: the element is
    not in the bag it must come from, ``member`` cannot take it, the tier is locked, or a fight's battle bag has no
    room to take one off into. A tier already full swaps: the one in it (``swap_with``, else the last) goes where
    the incoming one came from, or back in the bag when it came from there.
    """
    moves = by_id("moves")
    move = moves[move_id]
    old = dict(member.loadout or {})
    slots = open_slots(party.flags) if slots is None else slots
    on_member = move_id in old
    item = ITEM_OF.get(move_id)
    if row is None:
        if not on_member or item is None:
            return None
        if not _bag_put(party, member, item, in_a_fight):
            return None
        del old[move_id]
        member.loadout = old
        return [("forgot", move_id)]
    if not on_member and (item is None or not can_take(member, move) or not _bag_has(party, member, item, in_a_fight)):
        return None
    if swap_with is not None and swap_with != move_id and old.get(swap_with) == row and row in reach(move):
        new = dict(old)
        del new[swap_with]
        came_from = new.pop(move_id, None)
        new[move_id] = row
        if came_from is not None and came_from in reach(moves[swap_with]):
            new[swap_with] = came_from
    else:
        new = place_in_row(old, move, row, moves, slots)
    if new is old or new == old:
        return None
    dropped = [m for m in old if m not in new]
    changes: list[tuple[str, str]] = []
    if not on_member:
        _bag_take(party, member, item, in_a_fight)
        changes.append(("learned", move_id))
    for gone in dropped:
        if ITEM_OF.get(gone) is None or not _bag_put(party, member, ITEM_OF[gone], in_a_fight):
            return _undo(party, member, old, move_id, on_member, item, in_a_fight)
        changes.append(("forgot", gone))
    member.loadout = new
    return changes


def _undo(party, member, old, move_id, took, item, in_a_fight):
    """A displaced element had nowhere to go: nothing was done."""
    if not took and item is not None:      # the incoming one was already drawn from the bag
        _bag_put(party, member, item, in_a_fight)
    return None


def say(party, member, changes: list[tuple[str, str]]) -> list[str]:
    """The lines for what ``place`` did: "Kailo learned Wave Fist!" and "Kailo forgot Wave Fist." (Frankie, 11/28)."""
    from core.shared import short_name
    lines = []
    for kind, move_id in changes:
        text = ItemSettings.LEARNED_LINE if kind == "learned" else ItemSettings.FORGOT_LINE
        lines.append(text.format(name=short_name(member.id), move=by_id("moves")[move_id]["name"]))
    return lines


def slot_from_battle_bag(party, member, move_id: str) -> bool:
    """Put ``move_id`` from ``member``'s own battle bag into their lowest open slot; False if it is not there or no slot
    is open. The taro patch win does this for Kailo's Wave Guard (Frankie, 11/28), so Hina's Wave Guard lesson comes in
    the fights after it, as it did when his kit filled the new slot by itself."""
    item = ITEM_OF.get(move_id)
    room = open_slots(party.flags)
    for row in range(1, len(room) + 1):
        if sum(1 for r in (member.loadout or {}).values() if r == row) < room[row - 1]:
            return item in member.bag and place(party, member, move_id, row, in_a_fight=True) is not None
    return False


def reading(party, member_id: str, move_id: str) -> list[tuple[str, str]]:
    """Hina's first reading (flavor, Frankie, 11/28): the first time a lontar is slotted on Kailo with her along, as
    (speaker id, line); marks it said, empty otherwise. Wherever it is slotted: the field, a fight or the story."""
    item = ITEM_OF.get(move_id)
    if (item is None or member_id != ItemSettings.READ_TALK_MEMBER or item in ItemSettings.KAPAS
            or party.flags.get(ItemSettings.READ_FLAG) or party.find(ItemSettings.READER) is None):
        return []
    party.flags[ItemSettings.READ_FLAG] = True
    return list(ItemSettings.READ_TALK)


def grant(party, move_id: str, to: str | None = None, into_battle_bag: bool = False) -> str:
    """The party gets one copy of ``move_id`` (a teacher or the story gives it, Frankie, 11/28).

    With ``to``, it is slotted on that member if they can take it and a slot is open. Returns where the copy is:
    "slotted", "battle bag" or "shared bag". ``into_battle_bag`` puts a copy that found no slot into ``to``'s own
    bag if it has room, for a lesson that must slot it in a fight.
    """
    item = ITEM_OF[move_id]
    party.inventory[item] = party.inventory.get(item, 0) + 1
    member = party.find(to) if to else None
    if member is not None and move_id not in (member.loadout or {}) and can_take(member, move_id):
        move = by_id("moves")[move_id]
        start = dict(member.loadout or {})
        after = learn(start, move, None, open_slots(party.flags))
        if after is not None and move_id in after:
            _bag_take(party, member, item, False)
            member.loadout = after
            return "slotted"
        if into_battle_bag:
            if battle_bag.room(member) <= 0 and member.bag:   # his bag is full: the last thing he carried (a consumable
                # first, else gear) goes back to the shared bag to make room
                spare = next((i for i in reversed(member.bag) if not battle_bag.is_gear(i)), member.bag[-1])
                battle_bag.take_back(party, member, spare)
            if battle_bag.give(party, member, item):
                return "battle bag"
    return "shared bag"


# -- starting out, and old saves --------------------------------------------------------------------------


def start_member(party, member, known: list[dict[str, Any]] | None = None) -> None:
    """A member who has no loadout yet gets one: their starting kit is slotted in the open slots, and what does not
    fit goes in the shared bag as items. ``known`` is their kit; by default what the shared file gives them.
    The party owns the kit as items from here on (Frankie, 11/28)."""
    if member.loadout is not None:
        return
    from core.factories import first_loadout, known_moves
    flags = party.flags
    if known is None:
        known = known_moves(member.id, member.elements)      # the shared file's kit; no learned flags, nothing is learned now
    loadout = checked(None, known, first_loadout(member.id, flags), open_slots(flags))
    member.loadout = loadout
    for move in known:
        item = ITEM_OF.get(move["id"])
        if item is not None and move["id"] not in loadout:
            party.inventory[item] = party.inventory.get(item, 0) + 1


def migrate(party, saved: dict[str, Any]) -> None:
    """An old save, from before elements were owned: each member's learned elements become items. Slotted ones stay
    slotted; the learned ones that were banked go to the shared bag, one copy each (Frankie, 11/28).
    ``saved`` is the save's party dict: a new save says ``elements_owned`` and is left as it is."""
    if saved.get(FLAG):
        return
    from core.factories import known_moves
    for member in list(party.members) + list(party.away):
        known = known_moves(member.id, member.elements, party.flags)      # the kit and every learned flag
        if member.loadout is None:        # never opened the Element page: lay out the kit as a new member's
            start_member(party, member, known)
            continue
        member.loadout = checked(member.loadout, known, None, open_slots(party.flags))
        for move in known:
            item = ITEM_OF.get(move["id"])
            if item is not None and move["id"] not in member.loadout:
                party.inventory[item] = party.inventory.get(item, 0) + 1
