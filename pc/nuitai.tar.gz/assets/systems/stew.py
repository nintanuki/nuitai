"""The stew quest (Frankie, 10/26, reshaped 10/30).

After the opening fight the boars knock the stew pot over as they run into the
forest, so there is nothing for the wake. Noelani, Kailo's cousin, offers to cook
a new one if the player brings her the ingredients (``StewSettings.NEEDS``): fish
from fishing, pork from a wild boar, an egg, niu from chopping trees, soy sauce
from the old man's stall, and 'uala and akai lau, which only grow from seeds. It
is a quest, not the cooking pot. Its point is to make the player try what the game
offers before the Great Boar.

Two party flags: ``stew_quest`` once the opening is over, ``stew_made`` once
Noelani has what she needs. The stew gates the night: it falls only once the stew
is made and the Great Boar is beaten, in either order.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from settings import ItemSettings, StewSettings, StorySettings

if TYPE_CHECKING:
    from systems.party import Party


def active(party: "Party") -> bool:
    """Whether the quest is on: the opening is over and the stew not yet made."""
    return bool(party.flags.get(StewSettings.QUEST_FLAG)) and not made(party)


def made(party: "Party") -> bool:
    """Whether Kailo has cooked the stew, Noelani helping."""
    return bool(party.flags.get(StewSettings.MADE_FLAG))


def have(party: "Party", item: str) -> int:
    """How many of ``item`` the bag holds; "fish" is any kind of fish (Frankie, 11/2)."""
    if item in ItemSettings.FOOD_GROUPS:
        return sum(party.inventory.get(i, 0) for i in ItemSettings.FOOD_GROUPS[item])
    return party.inventory.get(item, 0)


GIVEN_FLAG = "stew_given"


def given(party: "Party") -> dict[str, int]:
    """What Noelani already holds for the stew, handed over in earlier talks (Frankie, 11/12)."""
    return party.flags.setdefault(GIVEN_FLAG, {})


def missing(party: "Party") -> dict[str, int]:
    """What is still lacking, item id to how many more: the bag and what Noelani holds count."""
    held = given(party)
    return {item: need - held.get(item, 0) - have(party, item) for item, need in StewSettings.NEEDS.items()
            if have(party, item) + held.get(item, 0) < need}


def spend(bag: dict[str, int], item: str, count: int) -> None:
    """Take ``count`` of ``item`` from the bag; for a kind such as fish, the commonest first."""
    kinds = ItemSettings.FOOD_GROUPS.get(item, (item,))
    for one in kinds:
        while count > 0 and bag.get(one, 0) > 0:
            bag[one] -= 1
            count -= 1
            if bag[one] <= 0:
                del bag[one]


def carrying(party: "Party") -> dict[str, int]:
    """What the bag holds toward the stew, item id to how many, never more than it needs (Frankie, 11/5)."""
    held = given(party)
    return {item: min(have(party, item), need - held.get(item, 0)) for item, need in StewSettings.NEEDS.items()
            if have(party, item) > 0 and held.get(item, 0) < need}


def give(party: "Party") -> dict[str, int]:
    """Hand Noelani what the bag holds toward the stew, so far (Frankie, 11/12); returns what went."""
    moved = carrying(party)
    held = given(party)
    for item, count in moved.items():
        spend(party.inventory, item, count)
        held[item] = held.get(item, 0) + count
    return moved


def _name(item: str, count: int, numbers: bool = False) -> str:
    name = ItemSettings.NAMES.get(item, item)
    return name if count == 1 and not numbers else f"{count} {name}"


def things(lacking: dict[str, int], hints: bool = False, numbers: bool = False) -> str:
    """The ingredients ``lacking`` as a sentence's list: "a, b and c"; with ``hints`` each says where it is from.

    With ``numbers`` a single one says "1 Coconut" too, so a count is never left to be guessed.
    """
    parts = [StewSettings.HINTS[item] if hints else _name(item, count, numbers) for item, count in lacking.items()]
    return ", ".join(parts[:-1]) + (" and " if len(parts) > 1 else "") + parts[-1]


def cook(party: "Party") -> bool:
    """Hand over the ingredients if the bag has them all: they are used up, the stew is made."""
    if missing(party):
        return False
    held = given(party)
    for item, need in StewSettings.NEEDS.items():
        spend(party.inventory, item, need - held.get(item, 0))
    party.flags.pop(GIVEN_FLAG, None)
    party.flags[StewSettings.MADE_FLAG] = True
    return True


def night_falls(party: "Party") -> bool:
    """Whether it is time for night: the stew made and the Great Boar beaten."""
    return made(party) and bool(party.flags.get(StorySettings.BOAR_BEATEN_FLAG))
