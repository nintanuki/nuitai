"""Felled trees stand again after steps, as crops grow (Frankie, 11/12; ``game/answers.md``).

A tree chopped to its stump, or a stump cleared to grass, stays that way when Kailo leaves
the room and comes back. Once ``ToolSettings.REGROW_STEPS`` steps are walked since the tree
was felled (the garden's step count, ``garden.steps``), it stands whole again the next time
he enters the room. It used to stand again on leaving the room.

Each felled tree is a party flag, ``tree:<room>:<col>:<row>``, ``"stump@<step>"`` or
``"clear@<step>"``: what is left and the step count when the tree was first felled. It saves
with the rest, and the generated woods, built again from the saved seed, find theirs by room.
"""

from __future__ import annotations

import random
from functools import lru_cache

from settings import OverworldSettings, ToolSettings

PREFIX = "tree:"
# The kind a pool tree grew back as, kept so it stays put: ``treekind:<room>:<col>:<row>`` (Frankie, 11/24 night).
KIND_PREFIX = "treekind:"


def _key(room: str, col: int, row: int) -> str:
    return f"{PREFIX}{room}:{col}:{row}"


def _stamp(value: str) -> tuple[str, int]:
    state, _, step = str(value).partition("@")
    return state, int(step or 0)


def _mix(*numbers: int) -> int:
    value = 0x9E3779B9
    for number in numbers:
        value = ((value ^ (number & 0xFFFFFFFF)) * 1274126177) & 0xFFFFFFFF
        value ^= value >> 15
    return value


STAND = 6          # about how many tiles across one stand of a kind is
PALETTE_SIZE = 4   # how many kinds a room mixes
STRAY = 8          # one tree in this many is another of the room's kinds, not its stand's


@lru_cache(maxsize=None)
def _room_number(room: str) -> int:
    return sum(ord(c) * (31 ** i) for i, c in enumerate(room)) & 0xFFFFFFFF


@lru_cache(maxsize=None)   # a pure pick, asked for every tree every frame (the browser build crawled in the woods)
def _stand_kind(seed: int, room: str, col: int, row: int) -> str:
    """The kind of the stand ``(col, row)`` belongs to (Frankie, 11/24 night: trees clump). A room mixes a few
    kinds, chosen from its seed; each stand is the patch nearest one of a jittered grid of seeded centers, so
    neighbors are mostly the same kind and a room has stands of a few kinds, not ten mixed."""
    pool = OverworldSettings.TREE_POOL
    number = _room_number(room)
    order = sorted(range(len(pool)), key=lambda i: _mix(seed, number, i, 7))
    palette = [pool[i] for i in order[:PALETTE_SIZE]]
    gx, gy = col // STAND, row // STAND
    best = None
    for cx in range(gx - 1, gx + 2):
        for cy in range(gy - 1, gy + 2):
            x = cx * STAND + _mix(seed, number, cx, cy, 1) % STAND
            y = cy * STAND + _mix(seed, number, cx, cy, 2) % STAND
            d = (x - col) ** 2 + (y - row) ** 2
            if best is None or d < best[0]:
                best = (d, palette[_mix(seed, number, cx, cy, 3) % len(palette)])
    if _mix(seed, number, col, row, 5) % STRAY == 0:
        return palette[_mix(seed, number, col, row, 6) % len(palette)]
    return best[1]


def pool_kind(flags: dict, seed: int, room: str, col: int, row: int) -> str:
    """Which tree of ``OverworldSettings.TREE_POOL`` a plain Tree tile is in this game: its stand's kind by the
    game's seed (each new game differs, a load shows the same), or the kind it grew back as, kept in ``flags``."""
    kept = flags.get(f"{KIND_PREFIX}{room}:{col}:{row}")
    if kept in OverworldSettings.TREE_POOL:
        return kept
    return _stand_kind(seed, room, col, row)


NO_FRUIT = "nofruit:"


def day_of_year(flags: dict) -> int:
    """The calendar's day (``systems/records.day``): the date the save keeps once days pass, else the start day."""
    from settings import RecordSettings
    if not RecordSettings.DAYS_PASS and not flags.get("clock_on"):
        return RecordSettings.START_DAY
    return int(flags.get("date", RecordSettings.START_DAY))


def fruit_share(day: int) -> float:
    """How many trees fruit or flower on ``day``: 40% in Kau, the warm half, 10% in the cool half."""
    from settings import ItemSettings
    return ItemSettings.FRUIT_SHARE_WARM if 1 <= day <= ItemSettings.WARM_DAYS else ItemSettings.FRUIT_SHARE_COOL


def has_fruit(seed: int, room: str, col: int, row: int, flags: dict | None = None) -> bool:
    """Whether the tree at ``(col, row)`` shows its fruit or flowers (Frankie, 11/24 night): each tree has a fixed
    roll, so a larger share in Kau shows the same trees and more; a tree whose fruit has dropped is plain until it
    grows back."""
    from settings import ItemSettings, ToolSettings
    flags = flags if flags is not None else {}
    if flags.get(f"{NO_FRUIT}{room}:{col}:{row}"):
        return False
    # Lanu's grove always flowers and fruits as in the abundant season, whatever the time of year (Frankie, 11/24 night)
    share = ItemSettings.FRUIT_SHARE_WARM if room == ToolSettings.GROVE else fruit_share(day_of_year(flags))
    return _mix(seed, _room_number(room), col, row, 9) % 1000 < share * 1000


def fruit_dropped(flags: dict, room: str, col: int, row: int) -> None:
    """The fruit is down: the tree is plain until it grows back."""
    flags[f"{NO_FRUIT}{room}:{col}:{row}"] = True


def _regrown_kind(flags: dict, seed: int, room: str, grid: list, col: int, row: int, old: str, named: set) -> str:
    """What a felled tree grows back as: one of its neighbors' kinds, not the old one when a neighbor offers
    another (Frankie, 11/24 night: regrowth follows its neighbors); with no neighbors, any other pool tree."""
    near = [pool_kind(flags, seed, room, c, r) for c in range(col - 2, col + 3) for r in range(row - 2, row + 3)
            if (c, r) != (col, row) and 0 <= r < len(grid) and 0 <= c < len(grid[r])
            and grid[r][c] == OverworldSettings.WALL_CHAR and (c, r) not in named]
    others = [k for k in near if k != old]
    if others:
        return random.choice(others)
    if near:
        return random.choice(near)
    return random.choice([kind for kind in OverworldSettings.TREE_POOL if kind != old])


def felled(flags: dict, room: str, col: int, row: int, cleared: bool) -> None:
    """Record the tree at ``(col, row)`` of ``room`` as a stump, or as cleared to grass; the
    step count it started at is kept from the first chop."""
    key = _key(room, col, row)
    steps = int(flags.get("garden_steps", 0))
    _, begun = _stamp(flags[key]) if key in flags else (None, steps)
    flags[key] = f"{'clear' if cleared else 'stump'}@{begun}"


def apply(flags: dict, room: str, grid: list[list[str]], seed: int = 0, named: set | None = None) -> None:
    """Leave ``room``'s trees as they were felled, and let those whose steps are walked stand again.

    A plain Tree grows back as a random *other* tree of the pool (Frankie, 11/24 night), kept in ``flags``; a
    tree placed as one named kind (``named``, the tiles) grows back as itself."""
    steps = int(flags.get("garden_steps", 0))
    prefix = f"{PREFIX}{room}:"
    for key in [k for k in flags if k.startswith(prefix)]:
        state, begun = _stamp(flags[key])
        col, row = (int(n) for n in key[len(prefix):].split(":"))
        if steps - begun >= ToolSettings.REGROW_STEPS:
            del flags[key]
            flags.pop(f"{NO_FRUIT}{room}:{col}:{row}", None)       # grown back, it can fruit again
            if (col, row) not in (named or ()):
                old = pool_kind(flags, seed, room, col, row)
                flags[f"{KIND_PREFIX}{room}:{col}:{row}"] = _regrown_kind(flags, seed, room, grid, col, row, old,
                                                                         named or set())
            continue
        if 0 <= row < len(grid) and 0 <= col < len(grid[row]):
            grid[row][col] = OverworldSettings.FLOOR_CHAR if state == "clear" else OverworldSettings.STUMP_CHAR
