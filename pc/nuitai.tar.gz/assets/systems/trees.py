"""Felled trees stand again after steps, as crops grow (Frankie, 11/12; ``game/answers.md``).

A tree chopped to its stump, or a stump cleared to grass, stays that way when Kailo leaves
the room and comes back. Once ``ToolSettings.REGROW_STEPS`` steps are walked since the tree
was felled (the garden's step count, ``garden.steps``), it stands whole again the next time
he enters the room. It used to stand again on leaving the room.

Each felled tree is a party flag, ``tree:<room>:<col>:<row>``, ``"stump@<step>"`` or
``"clear@<step>"``: what is left and the step count when the tree was first felled. It saves
with the rest, and the generated woods, built again from the saved seed, find theirs by room.
"""

from __future__ import annotations

from settings import OverworldSettings, ToolSettings

PREFIX = "tree:"


def _key(room: str, col: int, row: int) -> str:
    return f"{PREFIX}{room}:{col}:{row}"


def _stamp(value: str) -> tuple[str, int]:
    state, _, step = str(value).partition("@")
    return state, int(step or 0)


def felled(flags: dict, room: str, col: int, row: int, cleared: bool) -> None:
    """Record the tree at ``(col, row)`` of ``room`` as a stump, or as cleared to grass; the
    step count it started at is kept from the first chop."""
    key = _key(room, col, row)
    steps = int(flags.get("garden_steps", 0))
    _, begun = _stamp(flags[key]) if key in flags else (None, steps)
    flags[key] = f"{'clear' if cleared else 'stump'}@{begun}"


def apply(flags: dict, room: str, grid: list[list[str]]) -> None:
    """Leave ``room``'s trees as they were felled, and let those whose steps are walked stand again."""
    steps = int(flags.get("garden_steps", 0))
    prefix = f"{PREFIX}{room}:"
    for key in [k for k in flags if k.startswith(prefix)]:
        state, begun = _stamp(flags[key])
        if steps - begun >= ToolSettings.REGROW_STEPS:
            del flags[key]
            continue
        col, row = (int(n) for n in key[len(prefix):].split(":"))
        if 0 <= row < len(grid) and 0 <= col < len(grid[row]):
            grid[row][col] = OverworldSettings.FLOOR_CHAR if state == "clear" else OverworldSettings.STUMP_CHAR
