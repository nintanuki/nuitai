"""Ability slots: which techniques a character takes into a fight, and in which row.

The browser battle's slot system (D-318 to D-320, built there as D-327,
here on 2026-10-17): every character has three slots in each mana row,
1 to 7, shared by both stances. A technique sits in its own row (its
``warmup``) or in any other row; if it has an ``upcast`` field a higher row grows it: damage and healing by row over home row, so Heal in row 4
heals four times what it heals in row 1; turns by 1 a row. Any move may
also sit below home (Frankie, 11/1), where it is weaker by the same
ratio, floored so nothing reaches zero. It costs the row it sits in. Whatever is not slotted waits in the bank. The numbers
are the shared file's ``rules.slots``.

A loadout is a plain dict, move id -> row, so it saves as JSON as it is.
"""

from __future__ import annotations

from typing import Any, Iterable

from core.elements import LABELS
from core.shared import SHARED
from core.stats import offense_scale
from settings import BattleSettings, LoadoutSettings
from systems.battle_kits import KITS


# The official order, for sorting the first loadout (Frankie, 11/12).
_ELEMENT_ORDER: tuple[str, ...] = ("lau", "afi", "wai", "ata", "mana", "la")


def knows(move: dict[str, Any], member_id: str, element_ids: Iterable[str]) -> bool:
    """Return True when the character knows ``move``, in either stance.

    A move with an ``owner`` belongs to that one character. A move with
    ``needs`` (a kick or blast in a character's other element, 10/8)
    goes to whoever carries every element it names. Any other move goes
    to everyone carrying its element, unless they are in its ``except``
    list. Anyone in its ``also`` list knows it as well. A move marked
    ``off`` is not built anywhere; one marked ``browser_only`` is built
    here only once ``systems/battle_kits.py`` has its code (10/21: the
    four kits in this game).
    """
    if move.get("off") or (move.get("browser_only") and move["id"] not in KITS):
        return False
    element_ids = list(element_ids)
    if "owner" in move:
        usable = move["owner"] == member_id
    elif "needs" in move:
        usable = all(e in element_ids for e in move["needs"])
    else:
        usable = (
            move["element"] in element_ids
            and member_id not in move.get("except", ())
        )
    return usable or member_id in move.get("also", ())


def bosses_beaten(flags: dict[str, bool] | None) -> list[int]:
    """The rows opened by the fights won that open a slot, from the party's flags.

    Counted from the flags rather than kept apart, so an old save has the
    right slots the day it loads (Frankie, 11/1). None (tests and tools, no story) has them all.
    """
    return [row for boss_flags, row in LoadoutSettings.UNLOCK_BOSSES
            if flags is None or any(flags.get(f) for f in boss_flags)]


def open_slots(flags: dict[str, bool] | None) -> list[int]:
    """How many slots are open in each row, 1 to 7, with the party's ``flags``.

    ``START_OPEN`` at the start; each boss beaten opens one more in its row.
    None (tests and tools, no story) has them all open.
    """
    if flags is None:
        return [LoadoutSettings.PER_ROW] * LoadoutSettings.ROWS
    open_in = [LoadoutSettings.START_OPEN.get(row, 0) for row in range(1, LoadoutSettings.ROWS + 1)]
    for row in bosses_beaten(flags):
        open_in[row - 1] += 1
    return open_in


def slot_grid(loadout: dict[str, int], known: list[dict[str, Any]],
              slots: list[int]) -> list[list[dict[str, Any] | None]]:
    """The open slots as rows, one per row that has any: the move in each, or None when empty.

    The STATUS page draws it (Frankie, 11/1): locked slots are left out, so the
    shape grows as bosses fall. Moves keep the order they have in ``known``.
    """
    rows = []
    for row in range(1, LoadoutSettings.ROWS + 1):
        if slots[row - 1] <= 0:
            continue
        here = [m for m in known if loadout.get(m["id"]) == row][:slots[row - 1]]
        rows.append(here + [None] * (slots[row - 1] - len(here)))
    return rows


def _room(slots: list[int] | None, row: int) -> int:
    """How many slots ``row`` has open: ``slots`` is ``open_slots``, None all of them."""
    return LoadoutSettings.PER_ROW if slots is None else slots[row - 1]


def counter_kick(row: int) -> float:
    """The power of Counter's kick back from ``row``: a weakened Flame Kick at that row (Frankie, 11/2)."""
    from core.shared import by_id
    return grown(by_id("moves")["flame_kick"], row)["power"] * BattleSettings.COUNTER_KICK_SHARE


def home_row(move: dict[str, Any]) -> int:
    """Return the row a technique belongs in: its ``warmup``, 1 to 7."""
    return min(BattleSettings.MANA_CAP, max(1, int(move.get("warmup") or 1)))


def reach(move: dict[str, Any]) -> list[int]:
    """Return the rows ``move`` may sit in: all of them (Frankie, 11/1).

    Any element can be slotted at any tier. Above home a move with an
    ``upcast`` grows; below home it weakens the same way (``grown``).
    """
    return list(range(1, LoadoutSettings.ROWS + 1))


def _nearest(move: dict[str, Any]) -> list[int]:
    """The rows in the order a made loadout tries them: home, then up, then down."""
    home = home_row(move)
    return [home, *range(home + 1, LoadoutSettings.ROWS + 1), *range(home - 1, 0, -1)]


def grown(move: dict[str, Any], row: int) -> dict[str, Any]:
    """Return ``move`` as it plays from ``row`` (D-319).

    "power" grows by row over home row; "turns" adds one turn a row
    above home, carried as ``extra_turns``; "gift" (Nectar) one more
    mana a row; "revive" (Revive) all of the HP above home; "guard"
    (Wave Guard, Frankie 10/28) lets less of a hit through, as
    ``guard_multiplier``, never lasting longer; "counter" (Counter) does
    that and kicks back harder by row over home row, as ``kick``;
    "ward" (Shaka's Light) cuts more of the next shadow hit, as
    ``ward_share``, all of it at the top. Below home each of these runs
    in reverse (Frankie, 11/1, Claude's default), kept above zero: at
    least 1 power, 1 turn, 1 gift, 10% blocked, and a hit never let
    through by more than all of it. Anything else is unchanged.
    """
    home = home_row(move)
    extra = row - home
    # Counter's kick is set by its row even at home (Frankie, 11/2).
    if (extra == 0 and move.get("upcast") != "counter") or not move.get("upcast"):
        return move
    below = extra < 0
    if move["upcast"] == "power" and move.get("power"):
        power = move["power"] * row / home
        return {**move, "power": max(min(move["power"], 1), power) if below else power}
    if move["upcast"] == "turns":
        # Below home, at least one turn is left: a guard's base is its extra turns alone.
        floor = -(move.get("lasts", 1) - 1)
        return {**move, "extra_turns": max(floor, extra * LoadoutSettings.TURNS_PER_ROW)}
    if move["upcast"] == "rise":
        # Green Dream (Frankie, 11/10): half at home, more each row, all in row 7.
        if below:
            return {**move, "revive_share": max(0.1, move.get("revive_share", 0.5) * row / home)}
        base = move.get("revive_share", 0.5)
        top = LoadoutSettings.ROWS
        return {**move, "revive_share": 1.0 if row >= top else float(base + (1 - base) * extra / max(1, top - home))}
    if move["upcast"] == "revive":  # Revive in row 7 brings back all of it (D-711)
        if below:
            return {**move, "revive_share": max(0.1, move.get("revive_share", 0.5) * row / home)}
        return {**move, "revive_share": 1}
    if move["upcast"] in ("guard", "counter"):
        share = min(1.0, BattleSettings.GUARD_MULTIPLIER - extra * LoadoutSettings.GUARD_PER_ROW)
        if move["upcast"] == "guard":
            return {**move, "guard_multiplier": share}
        return {**move, "kick": counter_kick(row), "guard_multiplier": share}
    if move["upcast"] == "ward":
        share = LoadoutSettings.WARD_SHARE + extra * LoadoutSettings.WARD_PER_ROW
        return {**move, "ward_share": min(1.0, max(0.1, share))}
    if move["upcast"] == "gift":
        return {**move, "gift": max(1, move.get("gift", 1) + extra * LoadoutSettings.GIFT_PER_ROW)}
    return move


def _spare(move: dict[str, Any]) -> int:
    """How readily a move waits in the bank when its row is full (Frankie, 10/15).

    Healing never; a single cure first, since Cure All covers it.
    """
    if move.get("effect") == "cure":
        return 0
    name = move["name"]
    if name.startswith("Cure ") and name != "Cure All":
        return 2
    return 1


# A new game opens one slot (Frankie, 11/12): it holds what the taro patch teaches, Kailo's Flame Kick
# and Hina's Heal, ahead of anything else (Claude's rule, so her Heal lesson has its move).
_TAUGHT_FIRST = ("flame_kick", "cure")


def default_loadout(known: list[dict[str, Any]], slots: list[int] | None = None) -> dict[str, int]:
    """Return the first loadout, as the browser makes it.

    Each technique goes in its own row, moved up and then down if the
    row is full. Those that cannot grow go first, so the ones that
    can make room and nothing starts in the bank (Frankie, 10/15). Only
    open ``slots`` are used; what does not fit waits in the bank.
    """
    def key(move: dict[str, Any]) -> tuple:
        element = move.get("element")
        order = _ELEMENT_ORDER.index(element) if element in _ELEMENT_ORDER else 0
        return (
            move["id"] not in _TAUGHT_FIRST,
            bool(move.get("upcast")), _spare(move), home_row(move),
            move.get("tier") == "element", order, move["name"],
        )

    loadout: dict[str, int] = {}
    count: dict[int, int] = {}
    for move in sorted(known, key=key):
        for row in _nearest(move):
            if count.get(row, 0) < _room(slots, row):
                loadout[move["id"]] = row
                count[row] = count.get(row, 0) + 1
                break
    return loadout


def checked(loadout: dict[str, int] | None, known: list[dict[str, Any]],
            preset: dict[str, int] | None = None,
            slots: list[int] | None = None) -> dict[str, int]:
    """Return ``loadout`` with anything no longer known or out of reach dropped to the bank.

    None, a character who has never had one, gets their first loadout:
    the demo's rows (``preset``, from ``core/factories.py``'s
    ``first_loadout``), or else one made by ``default_loadout``.
    """
    if loadout is None:
        if preset:
            return checked(dict(preset), known, None, slots)
        return default_loadout(known, slots)
    by_id = {move["id"]: move for move in known}
    kept: dict[str, int] = {}
    count: dict[int, int] = {}
    # What the taro patch teaches keeps its slot first when there are too few (Frankie, 11/12: one to start).
    for move_id, row in sorted(loadout.items(), key=lambda item: item[0] not in _TAUGHT_FIRST):
        move = by_id.get(move_id)
        if move is None or row not in reach(move):
            continue
        if count.get(row, 0) >= _room(slots, row):
            continue
        kept[move_id] = row
        count[row] = count.get(row, 0) + 1
    return kept


def learn(loadout: dict[str, int] | None, move: dict[str, Any],
          start: dict[str, int] | None = None,
          slots: list[int] | None = None) -> dict[str, int] | None:
    """Return ``loadout`` with a newly learned ``move`` slotted if there is room.

    The lowest row with an open slot free, which can be row 1 now that
    any move sits at any tier (Frankie, 11/1); with no room it waits in
    the bank. Nothing already slotted moves.
    None, a character who has never had a loadout, starts from ``start``,
    the demo's first rows, which do not name the new move; with
    no ``start`` it stays None, and their first one is made from what
    they know, this move included.
    """
    if loadout is None:
        if start is None:
            return None
        loadout = dict(start)
    if move["id"] in loadout:
        return loadout
    count: dict[int, int] = {}
    for row in loadout.values():
        count[row] = count.get(row, 0) + 1
    for row in reach(move):
        if count.get(row, 0) < _room(slots, row):
            return {**loadout, move["id"]: row}
    return loadout


def place(loadout: dict[str, int], move: dict[str, Any], row: int | None,
          others: dict[str, dict[str, Any]],
          slots: list[int] | None = None) -> dict[str, int]:
    """Return a new loadout with ``move`` put in ``row``, or banked when ``row`` is None.

    A full row swaps: the last move in it goes where ``move`` came from
    if it can sit there, and to the bank if not.
    """
    result = dict(loadout)
    came_from = result.pop(move["id"], None)
    if row is None:
        return result
    if row not in reach(move) or _room(slots, row) == 0:
        return loadout
    in_row = [mid for mid, r in result.items() if r == row]
    if len(in_row) >= _room(slots, row):
        bumped = in_row[-1]
        del result[bumped]
        if came_from is not None and came_from in reach(others[bumped]):
            result[bumped] = came_from
    result[move["id"]] = row
    return result


# The ELEMENT page's help line (Frankie, 10/23): the move's one plain sentence,
# then the number for the row it sits in, "Kicks one enemy with fire. 8 physical fire
# damage." Neither names the move nor says the row; another row changes only
# the number.

ELEMENT_WORDS: dict[str, str] = {element: word.lower() for element, word in LABELS.items()}
# Wild cards, whose power is not a hit the player can count on: no number.
_WILD = frozenset({"party", "charm", "cry", "scold"})


def help_number(move: dict[str, Any], row: int,
                points: dict[str, int] | None = None) -> tuple[str, int, str] | None:
    """The number ``move`` has in ``row``, with the words round it: (before, number, after).

    Given the user's stat ``points``, a heal or a hit is scaled by their
    Strength or Magic, as the fight scales it, so Select says what this
    fighter does (Frankie, 11/4, after Mark's Episode 3: Heal said 24 and
    healed 36). The target's defence and weakness still come after.

    ``after`` is plural; ``help_text`` drops its "s" for a 1. None when the
    move has no number. A move's "lasts" is how many turns it holds in its
    own row, which its words used to say.
    """
    played = grown(move, row)
    effect = move.get("effect")
    if effect == "revive":
        if move.get("upcast") == "power":
            share = round(played["power"])
        else:
            share = round(100 * played.get("revive_share", 0))
        return ("Back up with ", share, "% HP.") if share else None
    if move.get("upcast") == "gift" or effect == "mana_gift":
        word = "Takes up to " if effect == "osmose" else "Gives "
        return (word, int(played.get("gift", 1)), " mana.")
    if move.get("upcast") == "ward":
        return ("Blocks ", round(100 * played.get("ward_share", LoadoutSettings.WARD_SHARE)), "% of the damage.")
    if move.get("upcast") == "guard":
        share = played.get("guard_multiplier", BattleSettings.GUARD_MULTIPLIER)
        return ("Takes ", round(100 * share), "% of the damage.")
    if move.get("upcast") == "counter":
        share = played.get("guard_multiplier", BattleSettings.GUARD_MULTIPLIER)
        kick = round(played.get("kick", counter_kick(home_row(move))))
        return ("Kicks back ", kick, f", takes {round(100 * share)}%.")
    if move.get("upcast") == "shell":
        extra = row - home_row(move)
        share = min(1.0, move.get("guard_multiplier", 0.25) - extra * LoadoutSettings.SHELL_PER_ROW)
        return ("Takes ", round(100 * share), "% of the damage.")
    power = played.get("power")
    if power and effect not in _WILD:
        physical = effect == "physical" or move.get("menu") == "skill"
        stat = "magic" if effect == "cure" or not physical else "strength"
        scale = offense_scale(points[stat]) if points and effect not in ("heal", "guard") else 1.0
        amount = round(power * scale)
        if effect in ("cure", "heal", "guard"):
            return ("Heals ", amount, " HP.")
        element = ELEMENT_WORDS.get(move.get("element", ""), "")
        if physical:
            return ("", amount, f" physical {element} damage.")
        return ("", amount, f" {element} magic damage.")
    if move.get("lasts"):
        return ("Lasts ", move["lasts"] + played.get("extra_turns", 0), " turns.")
    return None


HELP_CHARS = 28    # Letters across the help window, on both games.


def wrap_words(text: str, width: int = HELP_CHARS) -> list[str]:
    """``text`` broken into lines of ``width`` letters at most, at spaces."""
    lines: list[str] = []
    line = ""
    for word in text.split():
        if line and len(line) + 1 + len(word) > width:
            lines.append(line)
            line = word
        else:
            line = f"{line} {word}".strip()
    return lines + [line] if line else lines


def number_words(move: dict[str, Any], row: int, points: dict[str, int] | None = None) -> str:
    """The number line for ``move`` in ``row``, "8 physical fire damage.", or ""."""
    number = help_number(move, row, points)
    if number is None:
        return ""
    before, amount, after = number
    if amount == 1 and after.endswith("s."):
        after = after[:-2] + "."
    burn = burn_words(move, row)
    if burn and after.endswith(" damage."):
        # A fire hit says its chance to burn (Frankie, 11/4, after Mark's Episode 2), on the
        # same line: "16 physical fire, 30% burn."
        return f"{before}{amount}{after[:-len(' damage.')]}, {burn}."
    return f"{before}{amount}{after}"


def burn_words(move: dict[str, Any], row: int) -> str:
    """A fire hit's chance to burn in ``row``, "30% burn", "sure burn" for one that always does, or ""."""
    if move.get("element") != "afi":
        return ""
    if "ignite" in move.get("statuses", []):
        return "sure burn"
    rules = SHARED["rules"]
    chance = rules["fire_burn_chance"] + rules.get("fire_burn_per_tier", 0) * (min(7, max(1, row)) - 1)
    return f"{round(100 * min(1.0, chance))}% burn"


def help_lines(move: dict[str, Any], row: int, points: dict[str, int] | None = None) -> list[str]:
    """The help window for ``move`` in ``row``: its sentence, then its number on a line of its own.

    A move with a number has a sentence of one line (the shared file's
    texts are written to fit); one without may take both.
    """
    number = number_words(move, row, points)
    words = wrap_words(move.get("description", ""))
    return (words[:1] + [number]) if number else words[:2]
