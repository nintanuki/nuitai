"""The hunters' lodge's bounties (Frankie, 10/26; ``data/bounties/``).

Bounties are bosses only for now (Frankie, 11/17; optional bosses come later): each post names a boss
fight, pays its pule once, and is paid when the player picks it in the keeper's Hunts list after beating it.
Every post is on offer at once, in the order the board lists them.

A post's ``id`` keys its three party flags, so it saves with the rest: ``bounty_taken:<id>`` (the player took
it, so it shows in the quest log), ``bounty_paid:<id>`` and ``bounty_told:<id>`` (the "back to the lodge" line
after the fight was said once). A post is done when its ``beaten`` flag is set, taken or not, since a boss is
fought once (the Great Boar since 11/1). The Great Boar keeps its two older flags so old saves still count.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from systems.party import Party

TAKEN = "bounty_taken:"
PAID = "bounty_paid:"
TOLD = "bounty_told:"
# The Great Boar's flags before the posts had ids (Frankie, 11/12), so a save from then still counts.
LEGACY: dict[str, tuple[str, str]] = {"great_boar": ("bounty_first_taken", "bounty_first_paid")}


def _flag(party: "Party", key: str, prefix: str, legacy: int | None) -> bool:
    if party.flags.get(prefix + key):
        return True
    return legacy is not None and key in LEGACY and bool(party.flags.get(LEGACY[key][legacy]))


def post_of(board: dict, key: str) -> dict:
    """The post with id ``key``."""
    return next(post for post in board["posts"] if post["id"] == key)


def hunts(party: "Party", board: dict) -> list[str]:
    """The ids of the posts on offer: every one not yet paid, in the board's order."""
    return [post["id"] for post in board["posts"] if not paid(party, post["id"])]


def taken(party: "Party", key: str) -> bool:
    return _flag(party, key, TAKEN, 0)


def paid(party: "Party", key: str) -> bool:
    return _flag(party, key, PAID, 1)


def take(party: "Party", key: str) -> None:
    party.flags[TAKEN + key] = True


def done(party: "Party", board: dict, key: str) -> bool:
    """Whether the boss is beaten, taken or not, and the post not yet paid."""
    post = post_of(board, key)
    return bool(party.flags.get(post["beaten"])) and not paid(party, key)


def pay(party: "Party", board: dict, key: str) -> dict:
    """Pay out a finished post, once; return it."""
    post = post_of(board, key)
    party.pule += post["pule"]
    if post.get("prize"):
        party.inventory[post["prize"]] = party.inventory.get(post["prize"], 0) + 1
    party.flags[PAID + key] = True
    party.flags[TAKEN + key] = False
    return post


def record(party: "Party", board: dict) -> str | None:
    """After a fight: the line for the first taken post whose boss has just fallen, said once; else None."""
    for post in board["posts"]:
        key = post["id"]
        if taken(party, key) and done(party, board, key) and not party.flags.get(TOLD + key):
            party.flags[TOLD + key] = True
            return board["lines"]["kill_done"].format(what=post["what"])
    return None
