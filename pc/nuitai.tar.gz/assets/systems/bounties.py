"""The hunters' lodge's bounties (Frankie, 10/26; ``data/bounties/``).

Beat a monster so many times and the lodge's keeper pays pule and a prize,
more than the monsters drop. One bounty is posted at a time; paid, the next
one goes up, round and round, so they never run out (Skyrim's radiant
quests). Three party flags keep it, so it saves with the rest:
``bounty`` (which post is up), ``bounty_taken`` and ``bounty_count`` (how
many beaten since it was taken). Only a taken bounty counts.

The board's ``first`` post comes before all the rest, once (Frankie, 11/1: the Great Boar is
the lodge's first bounty, and after it the radiant hunts begin). Its ``beaten`` flag makes it done
even if he fell before it was taken, since he is fought only once; ``first_paid`` keeps that it
was paid.

Since 11/12 (Frankie) the keeper lists hunts: the ``first`` post is its own entry while it is open,
apart from the radiant round, so both are on offer at once. ``hunts`` lists them; ``take``, ``tally``,
``done`` and ``pay`` take a hunt key (FIRST or ROUND), and with none act on ``posted``, as before.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from systems.party import Party

POST_FLAG = "bounty"
TAKEN_FLAG = "bounty_taken"
COUNT_FLAG = "bounty_count"
FIRST_FLAG = "bounty_first_paid"
FIRST_TAKEN_FLAG = "bounty_first_taken"
FIRST = "first"  # the hunt keys (Frankie, 11/12): the Great Boar, and the endless round
ROUND = "round"


def posted(party: "Party", board: dict) -> dict:
    """The bounty up on ``board`` now: its ``first`` until that is paid, then the round."""
    if board.get("first") and not party.flags.get(FIRST_FLAG):
        return board["first"]
    return radiant(party, board)


def radiant(party: "Party", board: dict) -> dict:
    """The current radiant hunt, whether or not the first is still open (Frankie, 11/12)."""
    posts = board["posts"]
    return posts[int(party.flags.get(POST_FLAG, 0)) % len(posts)]


def _key(party: "Party", board: dict, key: str | None) -> str:
    if key:
        return key
    return FIRST if posted(party, board) is board.get("first") else ROUND


def post_of(party: "Party", board: dict, key: str | None = None) -> dict:
    return board["first"] if _key(party, board, key) == FIRST else radiant(party, board)


def hunts(party: "Party", board: dict) -> list[str]:
    """The hunt keys on offer: the Great Boar while it is open, and the current radiant hunt."""
    keys = [FIRST] if board.get("first") and not party.flags.get(FIRST_FLAG) else []
    return keys + [ROUND]


def taken(party: "Party", key: str | None = None) -> bool:
    if key == FIRST:
        return bool(party.flags.get(FIRST_TAKEN_FLAG))
    return bool(party.flags.get(TAKEN_FLAG))


def take(party: "Party", key: str | None = None) -> None:
    """Take a hunt; the count starts at nothing."""
    if key == FIRST:
        party.flags[FIRST_TAKEN_FLAG] = True
        return
    party.flags[TAKEN_FLAG] = True
    party.flags[COUNT_FLAG] = 0


def count(party: "Party") -> int:
    return int(party.flags.get(COUNT_FLAG, 0))


def tally(party: "Party", board: dict, key: str | None = None) -> str:
    """The taken hunt's count as the player sees it: "Boars 4/10" (Frankie, 10/28)."""
    key = _key(party, board, key)
    post = post_of(party, board, key)
    got = (post["count"] if done(party, board, key) else 0) if key == FIRST else count(party)
    return board["lines"]["tally"].format(name=post["name"], done=got, count=post["count"])


def record(party: "Party", board: dict, beaten: list[str]) -> str | None:
    """Count the monsters just beaten (shared file ids) toward the taken radiant hunt, up to its number.

    Returns the line to show after the fight ("Boars 4/10."), or None when none counted. The Great Boar
    counts by its own beaten flag, not here (Frankie, 11/12).
    """
    if not taken(party, ROUND) or done(party, board, ROUND):
        return None
    post = radiant(party, board)
    hits = sum(1 for monster in beaten if monster == post["monster"])
    if not hits:
        return None
    party.flags[COUNT_FLAG] = min(post["count"], count(party) + hits)
    line = board["lines"]["kill_done" if done(party, board, ROUND) else "kill"]
    return line.format(tally=tally(party, board, ROUND))


def done(party: "Party", board: dict, key: str | None = None) -> bool:
    key = _key(party, board, key)
    post = post_of(party, board, key)
    if post.get("beaten") and party.flags.get(post["beaten"]):
        return True
    if key == FIRST:
        return False  # taken is not done: only the Great Boar's own beaten flag finishes it
    return taken(party, key) and count(party) >= post["count"]


def pay(party: "Party", board: dict, key: str | None = None) -> dict:
    """Pay out a finished hunt; the round puts up the next, the first is gone for good. Return the one paid."""
    key = _key(party, board, key)
    post = post_of(party, board, key)
    party.pule += post["pule"]
    if post.get("prize"):
        party.inventory[post["prize"]] = party.inventory.get(post["prize"], 0) + 1
    if key == FIRST:
        party.flags[FIRST_FLAG] = True
        party.flags[FIRST_TAKEN_FLAG] = False
    else:
        party.flags[POST_FLAG] = (int(party.flags.get(POST_FLAG, 0)) + 1) % len(board["posts"])
        party.flags[TAKEN_FLAG] = False
        party.flags[COUNT_FLAG] = 0
    return post
