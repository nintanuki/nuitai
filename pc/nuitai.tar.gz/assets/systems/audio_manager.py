"""Portable AudioManager template.

DROP-IN GUIDE
=============
1. Copy this file to ``systems/audio_manager.py`` in your new game.
2. Add an ``AudioSettings`` class to your ``settings.py`` matching the
   contract below. The manager only depends on these names:

       class AudioSettings:
           MUTE = False              # global kill switch (SFX + music)
           MUTE_MUSIC = False        # silence music while keeping SFX
           MUSIC_VOLUME = 1.0        # 0.0 - 1.0
           SFX_VOLUME = 1.0          # 0.0 - 1.0

           # Logical name -> filesystem path. Keys are what gameplay code
           # passes to ``AudioManager.play(name)``.
           SOUND_EFFECTS = {
               "jump":  "assets/audio/sound/jump.ogg",
               "hurt":  "assets/audio/sound/hurt.ogg",
           }

           # Background tracks; one is chosen at random each time music
           # starts, avoiding back-to-back repeats.
           MUSIC_TRACKS = [
               "assets/audio/music/level1.ogg",
           ]

3. Initialise the pygame mixer once at startup (typically in your
   GameManager.__init__) **before** constructing AudioManager:

       pygame.mixer.init()
       self.audio = AudioManager()

4. Trigger sounds from anywhere with one entry point:

       self.audio.play("jump")

5. Manage music with: ``play_random_music``, ``pause_music``,
   ``resume_music``, ``stop_music``, ``toggle_mute``.

DESIGN NOTES
============
- **Data-driven.** Adding a new sound is one line in settings; this file
  never changes per-project.
- **No reserved channels.** Pygame's default 8-channel pool is sufficient
  for casual SFX. If a specific cue MUST never be cut off, fetch a
  dedicated channel for it explicitly:

      pygame.mixer.set_num_channels(N+1)
      self._boss_channel = pygame.mixer.Channel(N)
      ...
      self._boss_channel.play(self.sounds["boss_death"])

  Add that opt-in only for sounds that genuinely need it.
- **Failure is non-fatal.** Missing files or an uninitialised mixer log
  a warning and silently skip; the game keeps running.
- **Mute is honored at the call site**, not by mutating each Sound's
  volume, so toggling mute is instant and reversible.
"""

import os
import pygame
import random
import sys
import time

from settings import AudioSettings, ScreenSettings
from systems import heard


def rendered_copy(track_path: str) -> str:
    """The OGG copy of a field song that the nightfall fade reads (``tools/make_night_fades.py``)."""
    return os.path.join(AudioSettings.MUSIC_DIR, "rendered", os.path.splitext(os.path.basename(track_path))[0] + ".ogg")


def slowed_tail(track_path: str, at: float, seconds: float = 4.0, lowest_speed: float = 0.4, volume: float = 1.0):
    """What the song sounds like running down: ``seconds`` of it from ``at`` seconds in (round the song's length), read
    slower and slower (1 down to ``lowest_speed``) and fading to silence, as an array in the mixer's format.
    Raises if the song has no rendered copy or numpy is missing."""
    import numpy as np

    sound = pygame.mixer.Sound(rendered_copy(track_path))
    raw = pygame.sndarray.array(sound)
    samples = raw.astype(np.float32)
    rate = pygame.mixer.get_init()[0]
    start = int(at * rate) % max(1, len(samples) - int((seconds + 1) * rate))   # the song loops; stay inside it
    speed = np.linspace(1.0, lowest_speed, int(seconds * rate)) ** 1.5      # how fast the song is read
    where = start + np.cumsum(speed)
    where = where[where < len(samples) - 2]
    if len(where) < rate // 2:
        raise ValueError("too near the end of the song")
    low = where.astype(int)
    frac = (where - low)[:, None] if samples.ndim > 1 else (where - low)
    tail = samples[low] * (1 - frac) + samples[low + 1] * frac
    gain = np.linspace(1.0, 0.0, len(tail)) ** 1.5 * volume
    return (tail * (gain[:, None] if tail.ndim > 1 else gain)).astype(raw.dtype)


class AudioManager:
    """Data-driven music and sound-effect playback.

    All sounds are declared in ``AudioSettings.SOUND_EFFECTS`` (logical name
    -> file path). Gameplay code triggers them through ``play(name)``.
    """

    # ------------------------------------------------------------------
    # INIT
    # ------------------------------------------------------------------

    def __init__(self):
        """Load every registered sound effect and start background music."""
        self._load_sounds()

        # Track last played track so the same song never repeats back-to-back.
        self._last_music_track: str | None = None
        self._loops = -1
        self._music_is_paused = False
        # The screen whose song is playing (``play_screen``), its loop
        # points in seconds, and where in the song the last play began.
        self.screen: str | None = None
        self._loop: tuple[float, float] | None = None
        self._music_start = 0.0
        self._once = False      # The screen's song plays once, then silence.
        # Sounds waiting their turn: (time due, name), played by ``update``.
        self._queued: list[tuple[float, str]] = []

        self.play_random_music()

    def _load_sounds(self) -> None:
        """Load every registered sound effect at its volume."""
        self.sounds: dict[str, pygame.mixer.Sound] = {}
        for name, path in AudioSettings.SOUND_EFFECTS.items():
            sound = self._load_sound(path)
            if sound is not None:
                sound.set_volume(self._sfx_volume_for(path))
                self.sounds[name] = sound

    def set_mono(self, mono: bool) -> None:
        """Config's Sound (Frankie, 10/26): mono mixes both channels to the middle, or back to stereo.

        The mixer is opened again with one channel or two, so music and
        sound effects alike come out of the middle; the sounds are loaded
        again for it, and the song playing goes on from where it was.
        """
        mixer = pygame.mixer.get_init()
        channels = 1 if mono else 2
        if not mixer or mixer[2] == channels:
            return
        frequency, size, _ = mixer
        track = self._last_music_track
        at = self._music_start + max(0, pygame.mixer.music.get_pos()) / 1000
        playing = pygame.mixer.music.get_busy() or self._music_is_paused
        paused = self._music_is_paused
        pygame.mixer.quit()
        try:
            # The browser's larger buffer as main.py opens it there.
            pygame.mixer.init(frequency, size, channels, buffer=2048 if ScreenSettings.WEB else 512)
        except pygame.error as error:
            sys.stderr.write(f"Could not reopen the mixer: {error}\n")
            pygame.mixer.init(frequency, size, mixer[2], buffer=2048 if ScreenSettings.WEB else 512)
        self._load_sounds()
        if not (playing and track) or AudioSettings.MUTE or AudioSettings.MUTE_MUSIC:
            return
        try:
            pygame.mixer.music.load(track)
            pygame.mixer.music.set_volume(self._music_volume_for(track))
            pygame.mixer.music.play(loops=self._loops, start=at)
            self._music_start = at
            if paused:
                pygame.mixer.music.pause()
        except pygame.error as error:
            sys.stderr.write(f"Could not pick the song up again: {error}\n")

    def _load_sound(self, path: str) -> pygame.mixer.Sound | None:
        """Load one sound from disk; return None if the asset or mixer is missing."""
        try:
            return pygame.mixer.Sound(path)
        except (pygame.error, FileNotFoundError) as error:
            sys.stderr.write(f"Could not load sound {path}: {error}\n")
            return None

    def _sfx_volume_for(self, path: str) -> float:
        """Return the configured volume for one sound-effect file path."""
        return AudioSettings.SFX_FILE_VOLUMES.get(path, AudioSettings.SFX_VOLUME) * AudioSettings.MASTER_VOLUME

    def _music_volume_for(self, track_path: str) -> float:
        """Return the configured volume for one music file path."""
        return AudioSettings.MUSIC_FILE_VOLUMES.get(
            track_path,
            AudioSettings.MUSIC_VOLUME,
        ) * AudioSettings.MASTER_VOLUME

    def set_master_volume(self, volume: float) -> None:
        """Set the one volume over music and sounds together (0.0 - 1.0) and apply it now."""
        AudioSettings.MASTER_VOLUME = max(0.0, min(1.0, volume))
        for name, sound in self.sounds.items():
            sound.set_volume(self._sfx_volume_for(AudioSettings.SOUND_EFFECTS[name]))
        if pygame.mixer.get_init() and self._last_music_track:
            pygame.mixer.music.set_volume(self._music_volume_for(self._last_music_track))

    # ------------------------------------------------------------------
    # SOUND EFFECTS
    # ------------------------------------------------------------------

    def play(self, name: str, delay: float = 0.0) -> None:
        """Play one registered sound effect by logical name.

        Args:
            name: Key from ``AudioSettings.SOUND_EFFECTS``.
            delay: Seconds to wait first (``update`` plays it), so a hit's
                element sounds just after how it landed (D-151).
        """
        if AudioSettings.MUTE:
            return
        if delay > 0:
            self._queued.append((time.monotonic() + delay, name))
            return
        sound = self.sounds.get(name)
        if sound is None:
            return
        heard.hear_sound(name)
        sound.play()

    def _play_queued(self) -> None:
        """Play the delayed sounds whose time has come."""
        if not self._queued:
            return
        now = time.monotonic()
        due = [name for at, name in self._queued if at <= now]
        self._queued = [(at, name) for at, name in self._queued if at > now]
        for name in due:
            self.play(name)

    # ------------------------------------------------------------------
    # MUSIC
    # ------------------------------------------------------------------

    def play_random_music(self) -> None:
        """Pick a random track (avoiding the last one) and loop it indefinitely."""
        if AudioSettings.MUTE or AudioSettings.MUTE_MUSIC:
            return
        if not AudioSettings.MUSIC_TRACKS:
            return

        available = [t for t in AudioSettings.MUSIC_TRACKS if t != self._last_music_track]
        if not available:
            available = AudioSettings.MUSIC_TRACKS
        track = random.choice(available)
        self.play_music_track(track, loops=-1)

    def play_music_track(self, track_path: str, loops: int = -1) -> bool:
        """Load and play one specific music track.

        Args:
            track_path: Filesystem path to a music file.
            loops: pygame loop count; ``-1`` loops indefinitely.

        Returns:
            True if playback started; False otherwise.
        """
        # Any track played here is no screen's song until play_screen says so.
        self.screen = None
        if AudioSettings.MUTE or AudioSettings.MUTE_MUSIC:
            return False
        try:
            pygame.mixer.music.load(track_path)
            pygame.mixer.music.set_volume(self._music_volume_for(track_path))
            pygame.mixer.music.play(loops=loops)
            self._last_music_track = track_path
            self._loops = loops
            self._music_is_paused = False
            heard.hear_song(track_path)
            return True
        except (pygame.error, FileNotFoundError) as error:
            sys.stderr.write(f"Could not load music track {track_path}: {error}\n")
            return False

    def play_screen(self, screen: str) -> None:
        """Play one of a screen's songs from the shared list, unless that screen's music is on.

        The songs and their loop points are ``game/shared/music/music.json``,
        the same list the cartridge's music build reads. A song with loop points
        plays its intro once, then repeats the loop (``update``).

        Args:
            screen: A key of the list's ``play`` table, such as "battle".
        """
        if screen == self.screen and pygame.mixer.get_init() and (pygame.mixer.music.get_busy() or self._once):
            return
        songs = AudioSettings.SCREEN_MUSIC.get(screen, [])
        if not songs:
            # A quiet screen stops what the last one played (the beach's waves).
            if self.screen is not None and pygame.mixer.get_init():
                self.stop_music()
            return
        name = random.choice(songs)
        # A song with loop points is looped by ``update``; one without repeats
        # whole, unless its screen plays it once and then is quiet.
        once = screen in AudioSettings.PLAY_ONCE
        loops = 0 if once or name in AudioSettings.SONG_LOOPS else -1
        if self.play_music_track(
            os.path.join(AudioSettings.MUSIC_DIR, AudioSettings.music_file(name)), loops=loops
        ):
            self.screen = screen
            self._loop = AudioSettings.SONG_LOOPS.get(name)
            self._music_start = 0.0
            self._once = once

    def update(self) -> None:
        """Once a frame: jump back to a song's loop start when it reaches the loop's end."""
        self._play_queued()
        if (
            self.screen is None or self._once or self._music_is_paused or not pygame.mixer.get_init()
            or AudioSettings.MUTE or AudioSettings.MUTE_MUSIC
        ):
            return
        at = self._music_start + max(0, pygame.mixer.music.get_pos()) / 1000
        start, length = self._loop or (0.0, None)
        if pygame.mixer.music.get_busy() and (length is None or at < start + length):
            return
        try:
            pygame.mixer.music.play(start=start)
            self._music_start = start
        except pygame.error:
            self.screen = None

    def slow_fade(self, seconds: float = 4.0, lowest_speed: float = 0.4) -> None:
        """The field music slows down and fades out, like a tape running down (the clock's nightfall, Frankie, 11/19).

        pygame cannot change a song's speed, so the next ``seconds`` of the song from where it is are
        played again, resampled slower and slower (down to ``lowest_speed``) and quieter, in the music's
        place; then it is silent. Without numpy, or if the song cannot be read, the song only fades out.
        """
        if not pygame.mixer.get_init() or AudioSettings.MUTE or AudioSettings.MUTE_MUSIC                 or not pygame.mixer.music.get_busy() or self._last_music_track is None:
            self.stop_music()
            return
        volume = pygame.mixer.music.get_volume()
        try:
            at = self._music_start + max(0, pygame.mixer.music.get_pos()) / 1000
            tail = slowed_tail(self._last_music_track, at, seconds, lowest_speed, volume)
            self.stop_music()
            pygame.mixer.Sound(buffer=tail.tobytes()).play()
        except Exception:   # numpy missing, an odd format, the web build: a plain fade
            pygame.mixer.music.fadeout(int(seconds * 1000))
            self.screen = None

    def stop_music(self) -> None:
        """Stop the current background track."""
        pygame.mixer.music.stop()
        self._music_is_paused = False
        self.screen = None

    def pause_music(self) -> None:
        """Pause background music if anything is playing."""
        if AudioSettings.MUTE or AudioSettings.MUTE_MUSIC:
            return
        pygame.mixer.music.pause()
        self._music_is_paused = True

    def resume_music(self) -> None:
        """Resume paused music, or start a new random track if nothing is queued."""
        if AudioSettings.MUTE or AudioSettings.MUTE_MUSIC:
            return
        if self._music_is_paused:
            pygame.mixer.music.unpause()
            self._music_is_paused = False
            return
        self.play_random_music()

    # ------------------------------------------------------------------
    # GLOBAL CONTROLS
    # ------------------------------------------------------------------

    def toggle_mute(self, resume_music: bool = True) -> bool:
        """Flip the global mute flag and apply the side effects.

        Args:
            resume_music: When unmuting, whether to restart background music.

        Returns:
            bool: The new mute state (True = muted).
        """
        AudioSettings.MUTE = not AudioSettings.MUTE

        if AudioSettings.MUTE:
            pygame.mixer.stop()
            self._queued.clear()
            pygame.mixer.music.stop()
            self._music_is_paused = False
            return True

        if resume_music and not AudioSettings.MUTE_MUSIC:
            self.play_random_music()
        return False
