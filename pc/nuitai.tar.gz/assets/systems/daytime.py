"""The hour of the day and the light it makes (the light and night things a test, Frankie, 11/19; the clock, 11/20).

One number, the hour from 0 to 24, is what the rest of the game reads: ``hour(party)``. Before the clock
starts it is fixed: noon, except in the story's own night (the Great Boar beaten, until the morning after the
pier jump), which is ``STORY_NIGHT_HOUR``. The clock starts the morning after Ama's rescue
(``ClockSettings.START_FLAG``), is kept in the party's flags, and moves with ``tick`` (real time on the field)
and ``advance`` / ``sleep_until`` (a bed). ``set_debug_hour`` overrides it for looking at the light and the night
monsters; it touches no story flag and no save.

``is_night(party)`` is the one question every night thing asks (the night monsters, a night
backdrop), so the clock can drive them all later by changing only ``hour``. Where night starts
and ends is a placeholder (``NIGHT_FROM`` to ``NIGHT_UNTIL``) until Frankie decides.

The light is the Super Nintendo's color math, as the story night already was: a fixed color taken
away from every pixel of the room (``BLEND_RGB_SUB``), and at dawn and dusk a warm color added (``BLEND_RGB_ADD``). No
shaders. ``tint(hour)`` gives the two colors, 8-bit, blended between the keyframes below.
"""

from __future__ import annotations

import os

import pygame

from settings import ClockSettings, StorySettings

NOON = 12.0
STORY_NIGHT_HOUR = 23.0
# Night is from 6 PM until 6 AM (Frankie, 11/20; ``ClockSettings``).
NIGHT_FROM = ClockSettings.NIGHT_FROM
NIGHT_UNTIL = ClockSettings.NIGHT_UNTIL

# The clock's party flags, so they save with the rest: whether it has started, the hour of the day
# (0 to 24) and the minutes of it that have passed since, as a float.
CLOCK_FLAG = "clock_on"
HOUR_FLAG = "clock_hour"
TOLD_FLAG = "clock_told"

_NIGHT = tuple(amount * 8 for amount in StorySettings.NIGHT_SUBTRACT)   # the story night's color, as it always was
_NONE = (0, 0, 0)

# (hour, color taken away, color added). Blended in a straight line between neighbours; 24 wraps to 0.
KEYFRAMES: tuple[tuple[float, tuple[int, int, int], tuple[int, int, int]], ...] = (
    (0.0, _NIGHT, _NONE),
    (5.0, _NIGHT, _NONE),                    # still night
    (6.0, (50, 64, 34), (26, 6, 22)),        # daybreak at 6: dim, a rose glow
    (7.0, (8, 10, 10), (10, 4, 2)),          # sunrise, nearly day
    (8.0, _NONE, _NONE),                     # full day
    (16.5, _NONE, _NONE),
    (17.25, (0, 10, 30), (10, 4, 0)),        # late sun: a little less blue, a little gold
    (18.0, (40, 60, 32), (38, 8, 14)),       # nightfall at 6 PM: orange going dark
    (19.0, _NIGHT, _NONE),                   # full night an hour later
    (24.0, _NIGHT, _NONE),
)

_debug_hour: float | None = None
if os.environ.get("NUITAI_HOUR"):
    try:
        _debug_hour = float(os.environ["NUITAI_HOUR"]) % 24.0
    except ValueError:
        pass


def set_debug_hour(hour: float | None) -> None:
    """Fix the hour for looking at the light (None goes back to the story's). Changes no flag."""
    global _debug_hour
    _debug_hour = None if hour is None else float(hour) % 24.0


def debug_hour() -> float | None:
    """The hour set by hand, or None."""
    return _debug_hour


def story_night(party) -> bool:
    """Whether the story is in its own night: the Great Boar beaten, until the morning after the jump."""
    flags = party.flags if party is not None else {}
    return bool(flags.get(StorySettings.NIGHT_FLAG)) and not flags.get(StorySettings.AFTER_JUMP_FLAG)


def due(party) -> bool:
    """Whether the clock should be running by now: the story has reached its start (``ClockSettings.START_FLAG``;
    an empty one means from New Game, Q-100). Before that the day stays where it is."""
    if party is None:
        return False
    return not ClockSettings.START_FLAG or bool(party.flags.get(ClockSettings.START_FLAG))


def running(party) -> bool:
    """Whether the clock has been started on this save."""
    return party is not None and bool(party.flags.get(CLOCK_FLAG))


def start(party) -> None:
    """Start the clock: the morning after, at ``ClockSettings.START_HOUR``, the date a day on. Safe to call twice."""
    from systems import records  # local: records reads this module

    if party is None or running(party):
        return
    party.flags[CLOCK_FLAG] = True
    party.flags[HOUR_FLAG] = ClockSettings.START_HOUR
    party.flags[records.DATE_FLAG] = records.next_day(records.day(party))


def advance(party, hours: float) -> None:
    """Let ``hours`` pass. Midnight turns the date a day on. Does nothing until the clock has started."""
    from systems import records  # local, as in ``start``

    if not running(party) or hours <= 0:
        return
    at = float(party.flags.get(HOUR_FLAG, ClockSettings.START_HOUR)) + hours
    while at >= 24.0:
        at -= 24.0
        party.flags[records.DATE_FLAG] = records.next_day(records.day(party))
    party.flags[HOUR_FLAG] = at


def sleep_until(party, wake_hour: float) -> float:
    """Pass the time until the next ``wake_hour`` (today's, if it is still ahead). Returns the hours slept."""
    at = float(party.flags.get(HOUR_FLAG, ClockSettings.START_HOUR))
    slept = (wake_hour - at) % 24.0 or 24.0
    advance(party, slept)
    return slept


def tick(party, seconds: float) -> None:
    """Real time on the field: ``ClockSettings.MINUTES_PER_SECOND`` game minutes for each second."""
    advance(party, seconds * ClockSettings.MINUTES_PER_SECOND / 60.0)


def hour(party=None) -> float:
    """The hour, 0 to 24: the debug hour if one is set, else the clock's once it runs, else the story's
    (night at ``STORY_NIGHT_HOUR``, noon by day)."""
    if _debug_hour is not None:
        return _debug_hour
    if running(party):
        return float(party.flags.get(HOUR_FLAG, ClockSettings.START_HOUR))
    return STORY_NIGHT_HOUR if story_night(party) else NOON


def clock_text(party=None) -> str:
    """The hour as a 12-hour clock, e.g. ``7:05 AM``."""
    at = hour(party)
    minutes = int(at * 60) % (24 * 60)
    h, m = divmod(minutes, 60)
    return f"{h % 12 or 12}:{m:02d} {'AM' if h < 12 else 'PM'}"


def shops_open(party=None) -> bool:
    """Whether the shops that close at night are open: by day (``ClockSettings.SHOP_OPEN`` to ``SHOP_CLOSE``)."""
    return ClockSettings.SHOP_OPEN <= hour(party) < ClockSettings.SHOP_CLOSE


def daylight(party=None) -> bool:
    """Whether the sun is up, for the clock's icon (6 AM to 6 PM)."""
    return ClockSettings.SUN_UP <= hour(party) < ClockSettings.SUN_DOWN


def dark(party=None) -> bool:
    """Whether it is night by the running clock and not the story's own night (the wake keeps its own rules):
    what sends the village indoors."""
    return running(party) and is_night(party) and not story_night(party)


def is_night(party=None) -> bool:
    """Whether it is night: the one question the night monsters and the night backdrops ask."""
    h = hour(party)
    return h >= NIGHT_FROM or h < NIGHT_UNTIL


def tint(at: float) -> tuple[tuple[int, int, int], tuple[int, int, int]]:
    """The color taken away and the color added at hour ``at``."""
    at %= 24.0
    for (h0, sub0, add0), (h1, sub1, add1) in zip(KEYFRAMES, KEYFRAMES[1:]):
        if h0 <= at <= h1:
            t = 0.0 if h1 == h0 else (at - h0) / (h1 - h0)
            return (tuple(round(a + (b - a) * t) for a, b in zip(sub0, sub1)),
                    tuple(round(a + (b - a) * t) for a, b in zip(add0, add1)))
    return _NONE, _NONE


def apply(surface: pygame.Surface, area: pygame.Rect, at: float) -> None:
    """Lay the hour's light over ``area`` of ``surface``."""
    sub, add = tint(at)
    if any(sub):
        surface.fill(sub, area, special_flags=pygame.BLEND_RGB_SUB)
    if any(add):
        surface.fill(add, area, special_flags=pygame.BLEND_RGB_ADD)


def phase(at: float) -> str:
    """A word for the hour, for the debug caption."""
    at %= 24.0
    if at >= NIGHT_FROM + 1 or at < NIGHT_UNTIL - 1:
        return "night"
    if at < 8.0:
        return "dawn"
    if at < 17.25:
        return "day"
    if at < NIGHT_FROM:
        return "sunset"
    return "dusk"
