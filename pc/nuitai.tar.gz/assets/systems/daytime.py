"""The hour of the day and the light it makes (a test, Frankie, 11/19; the full clock is not decided yet).

One number, the hour from 0 to 24, is what the rest of the game reads: ``hour(party)``. Until the
clock exists it is fixed: noon, except in the story's own night (the Great Boar beaten, until the
morning after the pier jump), which is ``STORY_NIGHT_HOUR``. ``set_debug_hour`` overrides it for
looking at the light and the night monsters; it touches no story flag and no save.

``is_night(party)`` is the one question every night thing asks (the night monsters, a night
backdrop), so the clock can drive them all later by changing only ``hour``. Where night starts
and ends is a placeholder (``NIGHT_FROM`` to ``NIGHT_UNTIL``) until Frankie decides.

The light is the Super Nintendo's color math, as the story night already was: a fixed color taken
away from every pixel of the room (``BLEND_RGB_SUB``), and at dawn and dusk a warm color added (``BLEND_RGB_ADD``). No
shaders. ``tint(hour)`` gives the two colors, 8-bit, blended between the keyframes below.
"""

from __future__ import annotations

import os

import pygame

from settings import StorySettings

NOON = 12.0
STORY_NIGHT_HOUR = 23.0
# Placeholder until the clock is decided: night is from 8 PM until 5 AM.
NIGHT_FROM = 20.0
NIGHT_UNTIL = 5.0

_NIGHT = tuple(amount * 8 for amount in StorySettings.NIGHT_SUBTRACT)   # the story night's color, as it always was
_NONE = (0, 0, 0)

# (hour, color taken away, color added). Blended in a straight line between neighbours; 24 wraps to 0.
KEYFRAMES: tuple[tuple[float, tuple[int, int, int], tuple[int, int, int]], ...] = (
    (0.0, _NIGHT, _NONE),
    (5.0, _NIGHT, _NONE),                    # still night
    (6.0, (50, 64, 34), (26, 6, 22)),        # dawn: dim, a rose glow
    (7.5, (8, 10, 10), (10, 4, 2)),          # sunrise, nearly day
    (9.0, _NONE, _NONE),                     # full day
    (16.0, _NONE, _NONE),
    (17.0, (0, 10, 30), (10, 4, 0)),         # late sun: a little less blue, a little gold
    (18.5, (24, 44, 30), (40, 12, 2)),       # sunset: orange
    (19.5, (60, 84, 36), (34, 0, 34)),       # dusk: dark, magenta cast
    (21.0, _NIGHT, _NONE),
    (24.0, _NIGHT, _NONE),
)

_debug_hour: float | None = None
if os.environ.get("NUITAI_HOUR"):
    try:
        _debug_hour = float(os.environ["NUITAI_HOUR"]) % 24.0
    except ValueError:
        pass


def set_debug_hour(hour: float | None) -> None:
    """Fix the hour for looking at the light (None goes back to the story's). Changes no flag."""
    global _debug_hour
    _debug_hour = None if hour is None else float(hour) % 24.0


def debug_hour() -> float | None:
    """The hour set by hand, or None."""
    return _debug_hour


def story_night(party) -> bool:
    """Whether the story is in its own night: the Great Boar beaten, until the morning after the jump."""
    flags = party.flags if party is not None else {}
    return bool(flags.get(StorySettings.NIGHT_FLAG)) and not flags.get(StorySettings.AFTER_JUMP_FLAG)


def hour(party=None) -> float:
    """The hour, 0 to 24: the debug hour if one is set, else the story's (night at ``STORY_NIGHT_HOUR``, noon by day)."""
    if _debug_hour is not None:
        return _debug_hour
    return STORY_NIGHT_HOUR if story_night(party) else NOON


def is_night(party=None) -> bool:
    """Whether it is night: the one question the night monsters and the night backdrops ask."""
    h = hour(party)
    return h >= NIGHT_FROM or h < NIGHT_UNTIL


def tint(at: float) -> tuple[tuple[int, int, int], tuple[int, int, int]]:
    """The color taken away and the color added at hour ``at``."""
    at %= 24.0
    for (h0, sub0, add0), (h1, sub1, add1) in zip(KEYFRAMES, KEYFRAMES[1:]):
        if h0 <= at <= h1:
            t = 0.0 if h1 == h0 else (at - h0) / (h1 - h0)
            return (tuple(round(a + (b - a) * t) for a, b in zip(sub0, sub1)),
                    tuple(round(a + (b - a) * t) for a, b in zip(add0, add1)))
    return _NONE, _NONE


def apply(surface: pygame.Surface, area: pygame.Rect, at: float) -> None:
    """Lay the hour's light over ``area`` of ``surface``."""
    sub, add = tint(at)
    if any(sub):
        surface.fill(sub, area, special_flags=pygame.BLEND_RGB_SUB)
    if any(add):
        surface.fill(add, area, special_flags=pygame.BLEND_RGB_ADD)


def phase(at: float) -> str:
    """A word for the hour, for the debug caption."""
    at %= 24.0
    if at >= NIGHT_FROM + 1 or at < NIGHT_UNTIL:
        return "night"
    if at < 7.5:
        return "dawn"
    if at < 17.0:
        return "day"
    if at < 19.0:
        return "sunset"
    return "dusk"
