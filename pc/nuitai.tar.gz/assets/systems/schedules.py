"""Who is where by the hour (Frankie, 11/20; the real schedules are worked out later).

Every person on the map has an entry in ``data/schedules.json``, keyed ``room/col,row`` (the room's file and where
the person stands by day): ``day`` and ``night`` say ``here`` (stands in that spot) or ``absent`` (not on the map:
home, or simply gone). A person with no entry stands here all day and all night, so a new person is safe until
they are given one. Night is the running clock's (``systems/daytime.dark``); the story's own wake night keeps its
own rules (``core/world.py``). The file was made by ``tools/make_schedules.py`` with the rules below, then is Frankie's
to edit by hand: nobody outdoors in a village at night, the temple school shut, everyone else where they are.
"""

from __future__ import annotations

import json
import os

DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "schedules.json")
HERE, ABSENT = "here", "absent"
_TABLE: dict | None = None


def table() -> dict:
    """The file's entries, read once."""
    global _TABLE
    if _TABLE is None:
        try:
            with open(DATA, encoding="utf-8") as handle:
                _TABLE = json.load(handle).get("people", {})
        except OSError:
            _TABLE = {}
    return _TABLE


def key(cell_name: str, person: dict) -> str:
    """The entry's key for ``person`` standing in ``cell_name``."""
    return f"{cell_name}/{person['col']},{person['row']}"


def entry(cell_name: str, person: dict) -> dict:
    """The person's schedule: ``{"day": ..., "night": ...}``, here all day if none is written."""
    return table().get(key(cell_name, person), {"day": HERE, "night": HERE})


def present(cell_name: str, person: dict, dark: bool) -> bool:
    """Whether the person is on the map at this time of day (``dark``: the clock's night)."""
    return entry(cell_name, person)["night" if dark else "day"] != ABSENT
