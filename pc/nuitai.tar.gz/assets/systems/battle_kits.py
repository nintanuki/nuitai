"""The four kits' moves: what each one does, by move id.

Every move runs with its own few lines of code; this is the
table for the four who are in the pygame game so far, Kailo, Hina,
Tawiri and Maika (``docs/<name>-kit.md``). A move's numbers (power,
turns, how much it gives) come from the shared battle file as always;
only what it does is here.

Each runner takes the battle, the one acting, the target and the move
as it plays from its row (``systems/loadout.py``'s ``grown``), plus
``other``: for a move that takes from an enemy and gives to someone
(Drain, Osmose, Borrowed Life), the target is the enemy and ``other``
the one it gives to. Each returns the events, as the rest of the battle
does. The rules they lean on (burn, guards, boosts, the dead) are in
``systems/battle.py``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable

from core.elements import Element
from core.events import GuardRaisedEvent, NoteEvent, RevivedEvent, StatusAppliedEvent
from core.stats import defense_scale, offense_scale
from settings import BattleSettings, LoadoutSettings

if TYPE_CHECKING:
    from systems.battle import Battle, Combatant

AFI, WAI, LAU, LA, ATA, MANA = (
    Element.AFI, Element.WAI, Element.LAU, Element.LA, Element.ATA, Element.MANA,
)

Runner = Callable[["Battle", "Combatant", "Combatant", dict, "Combatant | None"], list]
KITS: dict[str, Runner] = {}


def kit(move_id: str):
    """Register the function below as the runner for ``move_id``."""
    def register(run: Runner) -> Runner:
        KITS[move_id] = run
        return run
    return register


# ----------------------------------------------------------------------
# SHARED PIECES
# ----------------------------------------------------------------------

def party_side(battle: "Battle", actor: "Combatant") -> bool:
    """True when ``actor`` fights for the party this turn: a hero, Tawiri's spirit, or a charmed monster.

    A monster turned on its own side by Possess is on the other side for that turn.
    """
    side = actor.is_party or actor in battle.party or bool(actor.statuses.get("charmed"))
    return side != actor.turned


def foes_of(battle: "Battle", actor: "Combatant") -> list["Combatant"]:
    """The living fighters on the other side, out of reach if up on a Vault (Frankie, 11/2)."""
    return [c for c in (battle.enemies if party_side(battle, actor) else battle.party)
            if c.alive and not c.aloft and c is not actor]


def allies_of(battle: "Battle", actor: "Combatant") -> list["Combatant"]:
    """The living fighters on the actor's side, out of reach if up on a Vault (Frankie, 11/2)."""
    return [c for c in (battle.party if party_side(battle, actor) else battle.enemies) if c.alive and not c.aloft]


def most_hurt(fighters: list["Combatant"]) -> "Combatant | None":
    """The one with the smallest share of HP left."""
    return min(fighters, key=lambda c: c.hp / c.max_hp, default=None)


def mend(actor: "Combatant", power: float) -> int:
    """A nature heal's size: its power by the healer's Magic (D-342)."""
    return round(power * offense_scale(actor.points["magic"]))


def turns(move: dict[str, Any], base: int) -> int:
    """A timed effect's turns, more for a move slotted above its row (D-319)."""
    return base + move.get("extra_turns", 0)


def haste(target: "Combatant", row: int) -> None:
    """Haste ``target`` from ``row``: each turn waits that much less, all fight (Frankie, 11/10).

    A recast keeps the higher row.
    """
    target.haste = max(target.haste, row)


def raise_guard(actor: "Combatant", kind: str, move: dict[str, Any], left: int | None = None) -> list:
    """Put ``actor`` on guard: ``left`` more turns it holds (a row above home adds them)."""
    actor.guard = kind
    actor.guard_left = move.get("extra_turns", 0) if left is None else left
    actor.guard_m = move.get("guard_multiplier")
    actor.guard_kick = move.get("kick")
    return [GuardRaisedEvent(actor.id, actor.name, kind)]


def each(battle: "Battle", actor: "Combatant", hit: Callable[["Combatant"], list]) -> list:
    """Hit every living foe in turn while the actor stands."""
    events: list[Any] = []
    for foe in foes_of(battle, actor):
        if actor.alive:
            events.extend(hit(foe))
    return events


# ----------------------------------------------------------------------
# KAILO (docs/kailo-kit.md): fire hits, water guards and water hits,
# and guards that turn a hit into one back.
# ----------------------------------------------------------------------

@kit("flambe")
def _flambe(b, u, t, m, o):
    return [NoteEvent(f"{u.name} lights the pan.")] + each(
        b, u, lambda f: b._physical(u, f, m["power"], AFI, unguardable=True))


# ----------------------------------------------------------------------
# HINA (docs/hina-kit.md): nature heals, light buffs, and light making
# the healing grow (D-652).
# ----------------------------------------------------------------------

@kit("seed")
def _seed(b, u, t, m, o):
    # Green Dream is an auto-life (Frankie, 11/10): the same status as Perennial.
    t.statuses["perennial"] = m.get("revive_share", 0.5)  # the share it rises with, grown by row
    return [StatusAppliedEvent(t.id, t.name, "perennial", True)]


@kit("petal_rain")
def _petal_rain(b, u, t, m, o):
    events: list[Any] = [NoteEvent(f"{u.name} rises and falls, and petals fall over the party.")]
    for ally in allies_of(b, u):
        events.extend(b._heal(ally, mend(u, m["power"])))
    return events


@kit("dawn_seal")
def _dawn_seal(b, u, t, m, o):
    t.statuses["protect"] = turns(m, BattleSettings.BUFF_TURNS)
    return [StatusAppliedEvent(t.id, t.name, "protect", True)]


# ----------------------------------------------------------------------
# TAWIRI (docs/tawiri-kit.md): spirit is her lightning, shadow her
# curses, and both are the dead.
# ----------------------------------------------------------------------

@kit("chain_lightning")
def _chain_lightning(b, u, t, m, o):
    events = b._magic(u, t, m["power"], MANA)
    for foe in foes_of(b, u):
        if foe is not t and u.alive:
            events.append(NoteEvent(f"The lightning jumps to {foe.name}.", foe.id))
            events.extend(b._magic(u, foe, m["power"] / 2, MANA))
    return events


# ----------------------------------------------------------------------
# MAIKA (docs/maika-kit.md): nature heals, spirit hits and blocks mana,
# and both move life from the enemy to the party (D-659).
# ----------------------------------------------------------------------

@kit("spin")
def _spin(b, u, t, m, o):
    return b._magic(u, t, m["power"], MANA)


@kit("osmose")
def _osmose(b, u, t, m, o):
    # Take mana from the enemy and give it to Maika or an ally, with a little more (D-409).
    to = o or u
    lost, events = b._lose_mana(t, int(m.get("gift", 1)))
    if lost:
        events = events + b._gain(to, lost + int(m.get("bonus", 0)))
    return events


@kit("drain")
def _drain(b, u, t, m, o):
    # Half the damage comes back, to Maika or the ally he gives it to.
    events = b._magic(u, t, m["power"], LAU)
    dealt = b.dealt(events, t)
    if dealt:
        events.extend(b._heal(o or u, round(dealt / 2)))
    return events


# ----------------------------------------------------------------------
# SHARED ELEMENTS no one owns (Frankie, 11/15): the "All" versions and the ones the monsters
# carry beside the party's. A monster plays them through this same table.
# ----------------------------------------------------------------------

def curse_all(status: str, word: str) -> Runner:
    """A sleep, blind or poison on every enemy, taking hold ``STATUS_ALL_SHARE`` as often on each."""
    def run(b, u, t, m, o):
        events: list[Any] = [NoteEvent(f"{u.name} {word}.")]
        for foe in foes_of(b, u):
            if u.alive:
                events.extend(b._magic(u, foe, 0, ATA, [status], extra_turns=m.get("extra_turns", 0),
                                       share=BattleSettings.STATUS_ALL_SHARE))
        return events
    return run


KITS["sleep_all"] = curse_all("sleep", "hums a lullaby over everyone")
KITS["blind_all"] = curse_all("blind", "throws up a dark cloud")
KITS["poison_all"] = curse_all("poison", "breathes out a sickly cloud")


@kit("shadow_blast_all")
def _shadow_blast_all(b, u, t, m, o):
    return [NoteEvent(f"{u.name}'s shadow spreads.")] + each(b, u, lambda f: b._magic(u, f, m["power"], ATA))


@kit("cyclone_all")
def _cyclone_all(b, u, t, m, o):
    return [NoteEvent(f"{u.name} stirs a great cyclone.")] + each(b, u, lambda f: b._magic(u, f, m["power"], WAI))


@kit("shell")
def _shell(b, u, t, m, o):
    t.statuses["shell"] = turns(m, m.get("lasts", BattleSettings.BUFF_TURNS))
    return [StatusAppliedEvent(t.id, t.name, "shell", True)]


@kit("shell_all")
def _shell_all(b, u, t, m, o):
    events: list[Any] = []
    for ally in allies_of(b, u):
        ally.statuses["shell"] = turns(m, m.get("lasts", BattleSettings.BUFF_TURNS))
        events.append(StatusAppliedEvent(ally.id, ally.name, "shell", True))
    return events


@kit("doom")
def _doom(b, u, t, m, o):
    # The Kaperosa's Doom (Frankie, 11/15: now an element anyone can carry): a count runs down, then it falls.
    if t.boss:
        return [NoteEvent(f"{t.name} does not hear the count.", t.id)]
    return [NoteEvent(f"A count begins over {t.name}.", t.id)] + b._inflict(t, "doom")


def run(battle: "Battle", actor: "Combatant", target: "Combatant", move: dict[str, Any],
        other: "Combatant | None" = None) -> list | None:
    """Run ``move`` if it is a kit move; None if this table does not have it."""
    runner = KITS.get(move["id"])
    if runner is None:
        return None
    return runner(battle, actor, target, move, other)

