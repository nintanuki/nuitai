"""The party — characters, inventory, money, story flags.

This module owns the runtime state that survives across scenes and is
the primary thing saves persist. Everything is plain Python types so
``to_dict`` / ``from_dict`` round-trip cleanly through JSON.

A member's combat stats are not stored content: they are worked out
from the member's two elements by ``core/stats.py`` every time the
member is built, so a change to the stat rule reaches every character
and every old save at once. Only what a member has grown by use in a
fight (D-498, ``growth``) is stored, and added on top.
"""

from __future__ import annotations

from typing import Any

from core.elements import Element
from core.equipment import weapon_multipliers
from core.shared import by_id
from core.stats import max_hp_for, stat_points
from systems.mastery import CAP


class PartyMember:
    """One member of the party."""

    def __init__(
        self,
        member_id: str,
        name: str,
        elements: tuple[str, str],
        stats: dict[str, int] | None = None,
        learnset: list[str] | None = None,
        current_hp: int | None = None,
        stance: int = 0,
        loadout: dict[str, int] | None = None,
        weapon: str | None = None,
        growth: dict[str, int] | None = None,
        relic: str | None = None,
        meters: dict[str, float] | None = None,
        mastery: dict[str, int] | None = None,
        bag: list[str] | None = None,
        bag_tier: int = 0,
    ) -> None:
        """Construct a party member.

        Args:
            member_id: Stable id used for save/load and content lookup
                (e.g. ``"kailo"``).
            name: Display name.
            elements: The member's two element ids (e.g. ``("afi", "wai")``).
            stats: Optional saved or authored stat dict. Only ``level``
                is read from it, plus ``hp`` to notice a save written
                under an older stat rule. Everything else is derived
                from ``elements``. ``self.stats["hp"]`` is the member's
                **max** HP: the value ``current_hp`` is capped against
                and what a full heal restores them to.
            learnset: Optional list of ability ids the member knows.
                Resolved against the ability content pack at battle
                time.
            current_hp: Optional remaining HP. Defaults to the member's
                max HP so freshly-loaded characters spawn full. Saved
                games supply the previously-persisted value here so
                damage carries across sessions. Ignored (full HP) when
                the save's max HP no longer matches the stat rule.
            stance: The stance the member starts each fight in (0 or
                1, the shared file's order), chosen on the party screen.
            loadout: Slotted techniques, move id -> mana row, set on
                the party screen. None until first set: the battle then
                makes the first loadout (``systems/loadout.py``).
            weapon: The id of the weapon held (D-462), from the shared
                file's ``weapons``. None holds nothing.
            growth: Points grown by use in fights (D-498), stat key ->
                points, added on top of what the elements give.
            relic: The id of the relic worn (Frankie, 10/24), from the
                shared file's ``relics``. None wears nothing.
            meters: The hidden meter for each stat's next rise by use
                (Frankie, 10/27), stat key -> points.
            mastery: Total EXP in each weapon type (Frankie, 10/30),
                type id -> EXP; the level is worked out from it
                (``systems/mastery.py``).
            bag: The items in the member's battle bag, one per slot
                (Frankie, 11/12; ``systems/battle_bag.py``).
            bag_tier: Which bag is carried, an index into
                ``BattleBagSettings.TIERS``; 0 is the Grass Sash.
        """
        self.id = member_id
        self.name = name
        self.elements = elements
        given = dict(stats) if stats else {}
        self.growth: dict[str, int] = {k: int(v) for k, v in (growth or {}).items()}
        self.meters: dict[str, float] = {k: float(v) for k, v in (meters or {}).items()}
        self.mastery: dict[str, int] = {k: max(0, min(int(v), CAP)) for k, v in (mastery or {}).items()}
        self._level = int(given.get("level", 1))
        self.weapon = weapon
        self.relic = relic
        self.bag: list[str] = list(bag or [])
        self.bag_tier = int(bag_tier)
        self.refresh_stats()
        max_hp = self.max_hp
        self.learnset = list(learnset) if learnset else []
        hp_is_current = current_hp is not None and given.get("hp") == max_hp
        self.current_hp: int = int(current_hp) if hp_is_current else max_hp
        self.stance = int(stance)
        self.loadout = dict(loadout) if loadout is not None else None

    def refresh_stats(self) -> None:
        """Work ``stats`` out again from the elements, ``growth`` and the weapon held."""
        points = stat_points(
            (Element(element_id) for element_id in self.elements), growth=self.growth,
            multipliers=weapon_multipliers(self.weapon),
        )
        self.stats = {**points, "hp": max_hp_for(points), "level": self._level}

    @property
    def max_hp(self) -> int:
        """Convenience accessor for the member's max HP from ``stats``."""
        return int(self.stats.get("hp", 0))

    def to_dict(self) -> dict[str, Any]:
        """Serialise this member to a JSON-safe dict."""
        return {
            "id": self.id,
            "name": self.name,
            "elements": list(self.elements),
            "stats": dict(self.stats),
            "learnset": list(self.learnset),
            "current_hp": self.current_hp,
            "stance": self.stance,
            "loadout": self.loadout,
            "weapon": self.weapon,
            "relic": self.relic,
            "growth": dict(self.growth),
            "meters": dict(self.meters),
            "mastery": dict(self.mastery),
            "bag": list(self.bag),
            "bag_tier": self.bag_tier,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PartyMember":
        """Reconstruct a ``PartyMember`` from a dict produced by ``to_dict``.

        Backward-compat: when ``current_hp`` is missing (saves written
        before HP persistence shipped), the member is loaded at full HP.
        """
        return cls(
            member_id=data["id"],
            name=data["name"],
            elements=tuple(data["elements"]),
            stats=dict(data.get("stats", {})),
            learnset=list(data.get("learnset", [])),
            current_hp=data.get("current_hp"),
            stance=data.get("stance", 0),
            loadout=data.get("loadout"),
            weapon=data.get("weapon"),
            growth=data.get("growth") or {},
            meters=data.get("meters") or {},
            mastery=data.get("mastery") or {},
            bag=data.get("bag") or [],
            bag_tier=data.get("bag_tier", 0),
            # A save from before relics wears the one the member starts with.
            relic=data["relic"] if "relic" in data else by_id("characters").get(data["id"], {}).get("relic"),
        )


class Party:
    """The whole adventuring party plus shared inventory and flags."""

    def __init__(self) -> None:
        """Construct an empty party."""
        self.members: list[PartyMember] = []
        self.inventory: dict[str, int] = {}
        # What is put away in the woven box aboard the Meialana (Frankie, 11/26; core/scenes/box_scene.py).
        self.stored: dict[str, int] = {}
        self.set_wallet(0)  # everyone starts with the first wallet (Frankie, 11/12)
        # The two currencies (D-069, D-476): kupang, the Bandari gold coin,
        # and pule, the islanders' cowrie shells.
        self.kupang: int = 0
        self._pule: int = 0
        self.flags: dict[str, bool] = {}
        # Who has left for a while (Hina at home after the taro patch), kept as they were.
        self.away: list[PartyMember] = []
        # The job set to Y on the tool wheel, "chop" for the ko'i, or None (systems/tools.py).
        self.tool: str | None = None

    # ------------------------------------------------------------------
    # ROSTER
    # ------------------------------------------------------------------

    def add(self, member: PartyMember) -> None:
        """Append ``member`` to the roster if not already present."""
        if any(m.id == member.id for m in self.members):
            return
        self.members.append(member)

    def remove(self, member_id: str) -> None:
        """Remove the member with ``member_id`` if present."""
        self.members = [m for m in self.members if m.id != member_id]

    def leave(self, member_id: str) -> None:
        """``member_id`` leaves the party for a while, kept as they are for ``rejoin``."""
        member = self.find(member_id)
        if member is not None:
            self.remove(member_id)
            self.away.append(member)

    def rejoin(self, member_id: str) -> PartyMember | None:
        """Bring back someone who left, as they left; None if they never did."""
        member = next((m for m in self.away if m.id == member_id), None)
        if member is not None:
            self.away.remove(member)
            self.add(member)
        return member

    def find(self, member_id: str) -> PartyMember | None:
        """Return the member with ``member_id`` or None if absent."""
        for m in self.members:
            if m.id == member_id:
                return m
        return None

    # ------------------------------------------------------------------
    # PERSISTENCE
    # ------------------------------------------------------------------

    @property
    def pule(self) -> int:
        """The wallet's pule, never more than ``pule_max`` (Frankie, 10/30)."""
        return self._pule

    @property
    def wallet_tier(self) -> int:
        """The tier of the wallet in the bag (0 to 6); the starting one if none is (Frankie, 11/12)."""
        from settings import WalletSettings

        tiers = [i for i, item in enumerate(WalletSettings.ITEMS) if self.inventory.get(item, 0) > 0]
        return max(tiers, default=0)

    @property
    def pule_max(self) -> int:
        """What the wallet the party owns holds (Frankie, 11/12; it was a fixed 999, then 1,000)."""
        from settings import WalletSettings

        return WalletSettings.TIERS[self.wallet_tier][2]

    def set_wallet(self, tier: int) -> None:
        """Own the wallet of ``tier`` and no other: the bought one replaces the last (Frankie, 11/12)."""
        from settings import WalletSettings

        for item in WalletSettings.ITEMS:
            self.inventory.pop(item, None)
        self.inventory[WalletSettings.ITEMS[tier]] = 1

    @pule.setter
    def pule(self, amount: int) -> None:
        self._pule = min(int(amount), self.pule_max)

    def to_dict(self) -> dict[str, Any]:
        """Serialise the whole party to a JSON-safe dict."""
        return {
            "members": [m.to_dict() for m in self.members],
            "inventory": dict(self.inventory),
            "stored": dict(self.stored),
            "kupang": self.kupang,
            "pule": self.pule,
            "flags": dict(self.flags),
            "away": [m.to_dict() for m in self.away],
            "tool": self.tool,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Party":
        """Reconstruct a ``Party`` from a dict produced by ``to_dict``."""
        party = cls()
        party.members = [PartyMember.from_dict(m) for m in data.get("members", [])]
        party.inventory = dict(data.get("inventory", {}))
        party.stored = dict(data.get("stored", {}))
        if party.wallet_tier == 0:   # a save from before 11/12 has no wallet: it starts with the first
            party.set_wallet(0)
        # Saves from before 10/23 carried Potions: Noni heals in their place.
        if "fish" in party.inventory:   # every fish is a kind now (Frankie, 11/2): an old save's are mackerel
            party.inventory["mackerel"] = party.inventory.get("mackerel", 0) + party.inventory.pop("fish")
        if "potion" in party.inventory:
            party.inventory["noni"] = party.inventory.get("noni", 0) + party.inventory.pop("potion")
        # Saves from before 10/18 kept one "gold" figure: it was coin.
        party.kupang = int(data.get("kupang", data.get("gold", 0)))
        party.pule = int(data.get("pule", 0))
        party.flags = dict(data.get("flags", {}))
        # Saves from before 10/24 called the ordinary boar "Boar": it is a Pua'a Hihiu.
        if "beaten:Boar" in party.flags:
            party.flags["beaten:Pua'a Hihiu"] = party.flags.pop("beaten:Boar")
        # Saves from before 11/24 called the ordinary boar's page "Wild Boar": it is Pua'a Hihiu in battle now.
        if "beaten:Wild Boar" in party.flags:
            party.flags["beaten:Pua'a Hihiu"] = party.flags.pop("beaten:Wild Boar")
        # Saves from before 10/30 hold Pono's digging stick under the id of Sarjana's weapon: it is the 'O'o now.
        if party.flags.get("widow_fed") and party.inventory.get("shovel", 0) > 0 and not party.inventory.get("oo"):
            party.inventory["shovel"] -= 1
            if party.inventory["shovel"] <= 0:
                del party.inventory["shovel"]
            party.inventory["oo"] = 1
        party.away = [PartyMember.from_dict(m) for m in data.get("away", [])]
        party.tool = data.get("tool")
        # A save from before 11/12 has no battle bags: each member gets a Grass Sash, filled from the shared bag.
        from systems.battle_bag import fill_starting

        fill_starting(party, [m for m, saved in zip(party.members, data.get("members", [])) if "bag" not in saved])
        return party
