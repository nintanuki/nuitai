"""The timed block meter's logic, apart from any drawing (Frankie, 10/30).

A monster's plain strokes come as round buttons sliding left along a long bar of three
lanes (Y, X, A from the top) toward a yellow zone near its left end, one per stroke, in order. The
player presses the stroke's own button (Y a Light, X a Medium, A a Strong, as
a hero attacks; Frankie, 11/19) as each bar crosses the zone: over the zone is a
catch, centered is perfect, and no press, a press off the zone or the wrong
button is a miss. A Strong comes slower than a Medium and a Medium than a Light,
and every stroke that lands (a catch or a miss, not a perfect) speeds the arrows
after it, as it adds to a hero's next chance (Frankie, 11/19). Each arrow keeps
its own speed the whole way and may pass arrows in other lanes; only arrows of
the same lane keep their room, so two of one button never touch.
The scene draws it (``ui/block_meter.py``) and, as each stroke lands, hands
its result to ``Battle.block_stroke``. A stroke lands when it is decided: at
the press for a catch or a perfect, as the bar leaves the zone for a miss, in
the order they are decided, which is not always the chain's order. Sizes are in ``BlockSettings``.
"""

from __future__ import annotations

from dataclasses import dataclass

from settings import BlockSettings


@dataclass
class _Bar:
    """One incoming stroke."""

    kind: str
    width: int
    x: float  # Its middle column's place, from the well's left end.
    result: str | None = None
    announced: bool = False  # Its swing has been started.
    entered: bool = False  # Its front edge has reached the zone.
    landed: bool = False  # Its stroke has been handed to the battle.
    ready_at: float | None = None  # When its result could land: the press, or the miss once it has left the zone.
    grade: float = 0.0  # How near the sweet spot a catch was, 0 at the zone's edge to 1 beside the perfect (Frankie, 11/10).


class BlockMeter:
    """The red bars on their way across the meter, and what the player did to each."""

    def __init__(self, strokes: tuple, zone: int, speed: float,
                 perfect: int = BlockSettings.PERFECT_PIXELS) -> None:
        """Line the bars up past the right end, the first stroke's nearest."""
        self.zone_left = BlockSettings.ZONE_LEFT
        self.zone = zone
        self.perfect = perfect  # From the defender's Luck (Frankie, 11/1).
        self.speed = speed   # A Light's pixels a second, before any landed stroke speeds it.
        self.bars: list[_Bar] = []
        x = float(BlockSettings.LENGTH)
        for i, kind in enumerate(strokes):
            width = BlockSettings.BAR_WIDTH[kind]
            x = BlockSettings.LENGTH + width / 2 if i == 0 else self.bars[-1].x + BlockSettings.min_gap(
                self.bars[-1].kind, kind)
            self.bars.append(_Bar(kind, width, x))
        self._after = 0.0  # Seconds since the last bar landed.
        self._clock = 0.0  # Seconds since the meter opened, to put landings in the order they were decided.

    @property
    def done(self) -> bool:
        """True once every stroke has landed and the meter has lingered a moment."""
        return all(b.landed for b in self.bars) and self._after >= BlockSettings.LINGER_SECONDS

    @property
    def results(self) -> list[str]:
        """"perfect", "catch" or "miss" for each stroke, in order."""
        return [b.result or "miss" for b in self.bars]

    def update(self, dt: float) -> None:
        """Slide the bars left; one that has gone wholly past the zone is a miss.

        Each bar moves at its own kind's speed, however many strokes have been decided before it in the
        chain, and passes bars of other lanes. Only the bar ahead of it in its own lane holds it back.
        """
        self._clock += dt
        zone_right = self.zone_left + self.zone
        landed = 0   # Strokes decided so far, a catch or a miss; a perfect parry does not count.
        ahead: dict[str, _Bar] = {}   # The last bar of each lane, nearest the zone among those not yet passed.
        for bar in self.bars:
            bar.x -= self.speed * BlockSettings.arrow_factor(bar.kind, landed) * dt
            front = ahead.get(bar.kind)
            if front is not None:
                # Never into the arrow ahead in the same lane, though a later one is quicker after landed strokes.
                bar.x = max(bar.x, front.x + BlockSettings.min_gap(front.kind, bar.kind))
            ahead[bar.kind] = bar
            if bar.result in ("catch", "miss"):
                landed += 1
            if not bar.entered and bar.x - bar.width / 2 <= zone_right:
                bar.entered = True
            if bar.result is None and bar.x + bar.width / 2 < self.zone_left:
                bar.result = "miss"
            if bar.result == "miss" and bar.ready_at is None and bar.x + bar.width / 2 < self.zone_left:
                bar.ready_at = self._clock
        if all(b.landed for b in self.bars):
            self._after += dt

    def entries(self) -> list[int]:
        """The strokes whose bars have just reached the zone, for their swing to begin; each once, the nearest first."""
        fresh = [i for i, b in enumerate(self.bars) if b.entered and not b.announced]
        fresh.sort(key=lambda i: self.bars[i].x)
        for i in fresh:
            self.bars[i].announced = True
        return fresh

    def landings(self) -> list[tuple[int, str]]:
        """The strokes that land now, in the order they were decided: (index, result).

        A catch or a perfect lands at its press; a miss, once its bar has left
        the zone (an early press misses too, but its stroke still waits for
        the bar). A stroke does not wait for the ones ahead of it in the chain,
        since a quicker arrow can be decided first.
        """
        ready = [(b.ready_at, b.x, i) for i, b in enumerate(self.bars) if not b.landed and b.ready_at is not None]
        ready.sort()
        landed: list[tuple[int, str]] = []
        for _, _, i in ready:
            bar = self.bars[i]
            bar.landed = True
            self._after = 0.0
            landed.append((i, bar.result))
        return landed

    def press(self, kind: str | None = None) -> str | None:
        """A stroke's button was pressed (``kind``: "light", "medium" or "strong"): settle its own lane's next bar.

        Each button reads only its own lane (Frankie, 11/19): the bar of that kind nearest the zone that is
        not yet settled. Over the zone it is a catch, within ``perfect`` pixels of centered a perfect;
        otherwise a miss on that bar, so mashing does not help, and no other lane's bar is touched. Only a bar
        near the zone counts (``BlockSettings.PRESS_AHEAD`` before it, or past it): with none that near the
        press does nothing, so a stray early press cannot spend an arrow still far away.
        ``None`` presses no button in particular and reads the unsettled bar nearest the zone. One press
        per bar. Returns the result, or None when no bar of that lane is near.
        """
        waiting = [b for b in self.bars if b.result is None and (kind is None or b.kind == kind)]
        if not waiting:
            return None
        bar = min(waiting, key=lambda b: b.x)
        if bar.x - bar.width / 2 > self.zone_left + self.zone + BlockSettings.PRESS_AHEAD:
            return None   # Nothing of its kind is near the zone: the press does nothing (Frankie, 11/19).
        bar.result = self._judge(bar)
        if bar.result != "miss":
            bar.ready_at = self._clock
        return bar.result

    def grade_of(self, index: int) -> float:
        """How near the sweet spot the press on stroke ``index`` was, for a parry that was not perfect."""
        return self.bars[index].grade

    def _judge(self, bar: _Bar) -> str:
        """How a press at the bar's present place lands."""
        zone_right = self.zone_left + self.zone
        if bar.x + bar.width / 2 <= self.zone_left or bar.x - bar.width / 2 >= zone_right:
            return "miss"
        centers = abs(bar.x - (self.zone_left + self.zone / 2))
        if centers <= self.perfect:
            return "perfect"
        # A catch grows from 0 where the bar only touches the zone to 1 beside the perfect.
        reach = self.zone / 2 + bar.width / 2
        bar.grade = max(0.0, min(1.0, 1 - (centers - self.perfect) / max(1.0, reach - self.perfect)))
        return "catch"
