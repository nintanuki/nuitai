"""The battle bag each fighter carries (Frankie, 11/12, after Dragon Quest).

A member's bag is a list of item ids, one item per slot, no stacks. An item in a bag is out of the
party's shared bag, so every item is in exactly one place. What may go in: anything the Item command can use in a
fight, ingredients that heal included (Frankie, 11/12: medicine and Life Totems were examples, not the whole list),
and since 11/28 the elements, weapons and relics a fight can change, each taking a slot like any item; never key
items. In a fight a member changes an element, a weapon or a relic only from their own bag, never the shared one.
Sizes and names are ``BattleBagSettings``. In a fight the Item command lists only the acting member's consumables;
Kailo's Cook still draws from the shared bag.
"""

from __future__ import annotations

from settings import BattleBagSettings, ItemSettings


def eligible_items() -> list[str]:
    """Every item that may go in a battle bag, in the order the Item command lists them."""
    order = [*ItemSettings.HEALS, *ItemSettings.CURES, *ItemSettings.REVIVES, ItemSettings.SEER_SHELL,
             ItemSettings.SMOKE_BOMB]
    seen: list[str] = []
    for item in order:
        if item in seen or not can_hold(item):
            continue
        seen.append(item)
    return seen


def can_hold(item: str) -> bool:
    """Whether ``item`` may be carried in a battle bag: anything a fight can use, ingredients that
    heal included (Frankie, 11/12), and the elements, weapons and relics a fight can change (Frankie, 11/28)."""
    return (is_gear(item) or item in ItemSettings.HEALS or item in ItemSettings.CURES
            or item in ItemSettings.REVIVES or item in (ItemSettings.SEER_SHELL, ItemSettings.SMOKE_BOMB))


def is_gear(item: str) -> bool:
    """Whether ``item`` is an element, a weapon or a relic: carried to be changed in a fight, never used."""
    from core.equipment import slot_of

    return item in ItemSettings.SHELLS or slot_of(item) is not None


def can_carry(member, item: str) -> bool:
    """Whether ``member`` may carry ``item``: gear only if it is theirs to take or wear (an element of their
    colours, a weapon or relic of their types), anything else the bag can hold."""
    if not can_hold(item):
        return False
    if item in ItemSettings.SHELLS:
        from systems.owned import can_take, move_of

        return can_take(member, move_of(item))
    from core.equipment import can_hold as fits, slot_of

    return fits(member.id, item) if slot_of(item) is not None else True


def tier_name(member) -> str:
    """The name of the bag ``member`` carries."""
    return BattleBagSettings.TIERS[member.bag_tier][0]


def size(member) -> int:
    """How many slots ``member``'s bag has."""
    return BattleBagSettings.TIERS[member.bag_tier][1]


def room(member) -> int:
    """Free slots in ``member``'s bag."""
    return size(member) - len(member.bag)


def full_label(member) -> str:
    """The bag and how full it is, as "Grass Sash 3/4"."""
    return f"{tier_name(member)} {len(member.bag)}/{size(member)}"


def counts(member) -> dict[str, int]:
    """What ``member`` carries to use in a fight, each item with its count, in the Item command's order."""
    return {item: member.bag.count(item) for item in eligible_items() if item in member.bag}


def give(party, member, item: str) -> bool:
    """Move one ``item`` from the shared bag into ``member``'s bag; False if it may not go, or no room."""
    if not can_carry(member, item) or party.inventory.get(item, 0) <= 0 or room(member) <= 0:
        return False
    party.inventory[item] -= 1
    if party.inventory[item] <= 0:
        del party.inventory[item]
    member.bag.append(item)
    return True


def take_back(party, member, item: str) -> bool:
    """Move one ``item`` from ``member``'s bag back into the shared bag; False if they have none."""
    if item not in member.bag:
        return False
    member.bag.remove(item)
    party.inventory[item] = party.inventory.get(item, 0) + 1
    return True


def swap_gear(member, slot: str, item: str) -> bool:
    """In a fight: ``member`` puts on ``item`` ("weapon" or "relic") from their own bag, and what they wore goes into
    the slot it leaves (Frankie, 11/28). False if ``item`` is not in their bag or does not fit them."""
    from core.equipment import can_hold as fits, slot_of
    from core.stats import hp_keeping_share

    if item not in member.bag or slot_of(item) != slot or not fits(member.id, item):
        return False
    member.bag.remove(item)
    worn = getattr(member, slot)
    if worn:
        member.bag.append(worn)
    old_max = member.max_hp
    setattr(member, slot, item)
    member.refresh_stats()
    member.current_hp = hp_keeping_share(member.current_hp, old_max, member.max_hp)
    return True


def spare_gear(member, slot: str) -> list[str]:
    """The weapons or relics ("weapon" or "relic") in ``member``'s own bag that they could put on, one each."""
    from core.equipment import can_hold as fits, slot_of

    worn = getattr(member, slot)
    return [item for item in dict.fromkeys(member.bag)
            if slot_of(item) == slot and item != worn and fits(member.id, item)]


def spend(member, item: str) -> bool:
    """Use up one ``item`` from ``member``'s bag in a fight, emptying its slot."""
    if item not in member.bag:
        return False
    member.bag.remove(item)
    return True


def set_tier(member, tier: int) -> None:
    """``member`` now carries the bag of ``tier``; what was inside stays inside."""
    member.bag_tier = max(0, min(tier, len(BattleBagSettings.TIERS) - 1))


def fill_starting(party, members=None) -> None:
    """Fill the Grass Sash of each of ``members`` (default: the party) from the shared bag (Claude's choice, 11/12).

    Noni Pulu are dealt one at a time round the members until each holds one fewer than the bag's
    size (room for a Life Totem); then one Life Totem each while the party has any; then any Noni
    left fill the rest. So the tutorial fight and early fights still have items.
    """
    members = list(party.members if members is None else members)
    if not members:
        return

    def deal(item: str, limit) -> None:
        dealt = True
        while dealt and party.inventory.get(item, 0) > 0:
            dealt = False
            for member in members:
                if party.inventory.get(item, 0) > 0 and len(member.bag) < limit(member) and give(party, member, item):
                    dealt = True

    deal("noni", lambda m: size(m) - BattleBagSettings.START_ROOM_FOR_TOTEM)
    for member in members:
        if party.inventory.get("life_totem", 0) > 0 and member.bag.count("life_totem") < 1:
            give(party, member, "life_totem")
    deal("noni", size)


def next_size(member, up_to: int | None = None):
    """The bag one size up from ``member``'s, as (tier, name, slots, cost); None at the top or past ``up_to``.

    Sizes are bought one member at a time, always the next size up, so none is skipped (Frankie, 11/12).
    """
    top = len(BattleBagSettings.TIERS) - 1 if up_to is None else min(up_to, len(BattleBagSettings.TIERS) - 1)
    tier = member.bag_tier + 1
    if tier > top:
        return None
    name, slots, cost = BattleBagSettings.TIERS[tier]
    return tier, name, slots, cost
