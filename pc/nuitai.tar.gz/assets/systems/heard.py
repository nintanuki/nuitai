"""What the player has heard, for the sound test (Frankie, 11/11).

The sound test (``core/scenes/sound_test_scene.py``, from Options on the title) lists every piece of
music and every sound effect the game plays, but shows one only once it has played in the game, so it
spoils nothing. ``AudioManager`` calls ``hear_song`` and ``hear_sound`` as each plays. Each save keeps
what it has heard; the sound test on the title shows what any save on hand has heard, so wiping every
save empties it (Frankie, 11/19). Heard before the first save counts once that save is written.

The lists are the game's own: songs from ``AudioSettings.SCREEN_MUSIC``, sounds from
``AudioSettings.SOUND_EFFECTS``. Only the readable names are written here.
"""

from __future__ import annotations

import os

from settings import AudioSettings

_SONG_NAMES = {
    "kulaiwi": "Kulāiwi",
    "potions-poisons-and-forest-mushrooms": "Potions, Poisons and Forest Mushrooms",
    "boss-battle-1": "Boss Battle 1",
}
_SMALL_WORDS = {"of", "the", "and", "a", "in"}
_ELEMENTS = {"afi": "Afi", "lau": "Lau", "wai": "Wai", "la": "La", "ata": "Ata", "mana": "Mana"}
_SOUND_NAMES = {
    "menu_move": "Menu Move", "menu_select": "Menu Select", "chest_open": "Chest Opening",
    "blip": "Stat Blip", "chop": "Ko'i Chop", "cant": "Can't Do That", "field_punch": "Field Punch",
    "scold_nag": "Hina's Scold", "clank": "Clank", "perfect": "Perfect Block", "dig": "Dig",
    "spotted": "Monster Spots You", "lost": "Monster Loses You", "found": "Something Found",
    "hit_blade": "Blade Hit", "hit_blunt": "Blunt Hit", "hit_thrown": "Thrown Hit",
    "hit_punch_1": "Punch", "hit_magic_1": "Magic Zap", "hit_sparkle_1": "Healing Sparkle",
    "hit_miss_1": "Miss", "water_splash": "Water Splash", "swim_stroke": "Swim Stroke",
}

# What this play has heard: a save's own list once one is loaded, else from the start. It goes in each
# save (``snapshot``); the sound test shows the union of every save's (``core/save.py``'s ``heard_on_hand``).
_session: dict[str, set[str]] = {"songs": set(), "sounds": set()}


def song_key(path: str) -> str:
    """A song's key: its file name without folder or extension (.it in the game, .ogg in the browser)."""
    return os.path.splitext(os.path.basename(path))[0]


def song_name(key: str) -> str:
    """A song's readable name."""
    if key in _SONG_NAMES:
        return _SONG_NAMES[key]
    words = key.split("-")
    return " ".join(w if i and w in _SMALL_WORDS else w.capitalize() for i, w in enumerate(words))


def sound_name(key: str) -> str:
    """A sound effect's readable name."""
    if key in _SOUND_NAMES:
        return _SOUND_NAMES[key]
    for prefix, label in (("elem_", "{} Hit"), ("charge_", "{} Charge-up")):
        if key.startswith(prefix) and key[len(prefix):] in _ELEMENTS:
            return label.format(_ELEMENTS[key[len(prefix):]])
    return key.replace("_", " ").title()


def songs() -> list[str]:
    """Every song the game plays, as keys, in the order its screens come."""
    seen: list[str] = []
    for files in AudioSettings.SCREEN_MUSIC.values():
        for file in files:
            if song_key(file) not in seen:
                seen.append(song_key(file))
    return seen


def sounds() -> list[str]:
    """Every sound effect the game plays, as keys."""
    return list(AudioSettings.SOUND_EFFECTS)


def to_dict() -> dict[str, list[str]]:
    """What this play has heard, as a save keeps it."""
    return {kind: sorted(values) for kind, values in _session.items()}


def from_save(data: dict | None) -> None:
    """A save loaded: its list is what this play has heard (a save from before the sound test has none)."""
    global _session
    _session = {"songs": set(), "sounds": set()}
    heard = data.get("heard") if isinstance(data, dict) else None
    if isinstance(heard, dict):
        for kind in _session:
            values = heard.get(kind)
            if isinstance(values, list):
                _session[kind] = {v for v in values if isinstance(v, str)}


def hear_song(path: str) -> None:
    """A song just played."""
    key = song_key(path)
    if key in songs():
        _session["songs"].add(key)


def hear_sound(name: str) -> None:
    """A sound just played."""
    if name in AudioSettings.SOUND_EFFECTS:
        _session["sounds"].add(name)
