"""The date and the records: time played and steps walked (Frankie, 10/23).

Each is a party flag, so it saves with the rest. The date is ``date``, the
day counted from Mohala 1 as 1; a save from before it reads as the start,
the 30th of Kau. For now the date stays there whatever is saved: a nap does
not move it (Frankie, 10/26). With ``RecordSettings.DAYS_PASS`` on, a nap
moves it on a day, Ho'oilo rolling back round to Mohala; nothing in the story
or the fights reads it (Frankie, 10/25). ``slept`` is set by the nap and cleared
when he walks out of his house, where the date shows. The time played is
``play_seconds``, counted while a game is on (``GameManager``). The steps
are the garden's own count (``systems/garden.py``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from settings import RecordSettings
from systems import garden

if TYPE_CHECKING:
    from systems.party import Party

DATE_FLAG = "date"
TIME_FLAG = "play_seconds"
SLEPT_FLAG = "slept"
BATTLES_FLAG = "battles_won"


def day(party: "Party") -> int:
    """The day of the year, 1 (Mohala 1) to 120 (Ho'oilo 30); the start while days do not pass."""
    if not RecordSettings.DAYS_PASS:
        return RecordSettings.START_DAY
    return int(party.flags.get(DATE_FLAG, RecordSettings.START_DAY))


def next_day(today: int) -> int:
    """The day after ``today``, Ho'oilo 30 rolling round to Mohala 1."""
    return today % (RecordSettings.SEASON_DAYS * len(RecordSettings.SEASONS)) + 1


def ordinal(number: int) -> str:
    """``1st``, ``2nd``, ``3rd``, ``4th``, ``11th``, ``21st``."""
    suffix = "th" if 10 <= number % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(number % 10, "th")
    return f"{number}{suffix}"


def date_text(party: "Party") -> str:
    """The date as the pop-up shows it, e.g. ``30th of Kau``."""
    return day_text(day(party))


def day_text(number: int) -> str:
    """Day ``number`` of the year in words, e.g. ``1st of Hauhake``."""
    season, date = divmod(number - 1, RecordSettings.SEASON_DAYS)
    return f"{ordinal(date + 1)} of {RecordSettings.SEASONS[season]}"


def sleep(party: "Party") -> None:
    """A nap in Kailo's bed: the date to show once he walks out, and the next day if days pass."""
    if RecordSettings.DAYS_PASS:
        party.flags[DATE_FLAG] = next_day(day(party))
    party.flags[SLEPT_FLAG] = True


def add_time(party: "Party", seconds: float) -> None:
    """Count ``seconds`` more played."""
    party.flags[TIME_FLAG] = float(party.flags.get(TIME_FLAG, 0.0)) + seconds


def time_text(party: "Party") -> str:
    """Hours and minutes played since New Game, as ``1:05``."""
    minutes = int(party.flags.get(TIME_FLAG, 0.0)) // 60
    return f"{minutes // 60}:{minutes % 60:02d}"


def season(party: "Party") -> int:
    """The season of today's date, 0 Mohala to 3 Ho'oilo."""
    return (day(party) - 1) // RecordSettings.SEASON_DAYS


def win_battle(party: "Party") -> None:
    """Count one more battle won (Frankie, 11/13); a save from before it reads as none."""
    party.flags[BATTLES_FLAG] = battles_won(party) + 1


def battles_won(party: "Party") -> int:
    """Every battle won since New Game."""
    return int(party.flags.get(BATTLES_FLAG, 0))


def monsters_beaten(party: "Party") -> int:
    """The kinds of creature beaten: what the bestiary holds."""
    return sum(1 for key, value in party.flags.items() if key.startswith("beaten:") and value)


def latest_beaten(party: "Party") -> str | None:
    """The creature beaten last (flags keep the order they were set in), by its bestiary name, or None."""
    from core.shared import SHARED  # local: the shared file loads on first use.

    names = {page["name"] for page in SHARED["bestiary"]}
    for key in reversed(list(party.flags)):
        if key.startswith("beaten:") and party.flags[key] and key[7:] in names:
            return key[7:]
    return None


def counts(party: "Party") -> list[tuple[str, int]]:
    """What the Records screen lists (Frankie, 11/13): each label with its number."""
    from core import lore  # local: lore reads the shared pages.
    from systems import quests

    words = len(lore.unlocked(party, lore.GLOSSARY))
    pages = len(lore.unlocked(party)) - words
    return [("Monsters beaten", monsters_beaten(party)), ("Battles won", battles_won(party)),
            ("Words learned", words), ("Lore pages found", pages),
            ("Quests done", sum(1 for q in quests.log(party) if q.done))]


def steps(party: "Party") -> int:
    """Every step walked since New Game."""
    return garden.steps(party)
