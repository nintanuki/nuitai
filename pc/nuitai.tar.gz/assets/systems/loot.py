"""What a beaten monster leaves (Frankie, 11/6; built 11/17), apart from the fight that rolls it.

Two d20s per beaten monster (Frankie, 11/20): the common die (``ItemSettings.COMMON_DIE``) always gives
something, the rare die (``RARE_DIE``) now and then. Each category is a pool, every thing in it alike. Never
pule. ``roll`` is the whole of it; ``battle_scene.roll_drops`` calls it once per monster and adds the
Great Boar's tusk, a key item that is always his and outside the dice.

The gear category is a generated weapon or relic (``core/gear_gen.py``) of a type the party can use
so far: Kailo's, Hina's, Maika's and Tawiri's, and each new island adds its newcomer's, Gen'emon's
on Kupulau (Frankie, 11/6).
"""

from __future__ import annotations

import random
from functools import lru_cache
from typing import Any, Iterable

from core.shared import by_id
from settings import ItemSettings, SailingSettings

# A newcomer's types join the pool when the flag is set: Gen'emon's with Kupulau on the map.
_LATER_OWNERS: dict[str, str] = {"genemon": SailingSettings.KNOWN_FLAG + SailingSettings.PORTS[2]}


def owners(flags: dict[str, Any] | None = None, member_ids: Iterable[str] = ()) -> tuple[str, ...]:
    """Whose types the gear drops are for: the first chapter's four, a newcomer's once he is here or his island is."""
    flags = flags or {}
    here = set(member_ids)
    later = tuple(who for who, flag in _LATER_OWNERS.items() if who in here or flags.get(flag))
    return tuple(ItemSettings.GEAR_OWNERS) + later


@lru_cache(maxsize=8)
def gear_pool(who: tuple[str, ...]) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """The generated weapons and the generated relics ``who`` (character ids) can use."""
    from core.equipment import can_hold

    weapons = tuple(i for i, w in by_id("weapons").items() if w.get("generated") and any(can_hold(m, i) for m in who))
    relics = tuple(i for i, r in by_id("relics").items() if r.get("generated") and any(can_hold(m, i) for m in who))
    return weapons, relics


def _face(rng: random.Random, die: dict[str, int]) -> str:
    """The category one roll of ``die`` (faces per category) lands on."""
    return rng.choices(list(die), weights=list(die.values()))[0]


def roll(kind: dict[str, Any], rng: random.Random, who: tuple[str, ...] | None = None,
         cast: Iterable[str] = (), burning: bool = False) -> list[str]:
    """What one beaten monster leaves: the common die's thing, and the rare die's if it gave one.

    Args:
        kind: The monster's entry in the shared file.
        rng: The dice.
        who: Whose types the gear is for (``owners``); the first chapter's four when not given.
        cast: The move ids it slotted and cast in the fight; only those can drop as an element (Frankie, 11/15).
        burning: Whether it fell burning, which roasts the pork it leaves (Frankie, 11/4).
    """
    S = ItemSettings
    monster = kind.get("id", "")
    elements = sorted(item for item, (_, move_id) in S.SHELLS.items() if move_id in set(cast))
    common = _face(rng, S.COMMON_DIE if elements else S.COMMON_DIE_NO_ELEMENT)
    if common == "loot":
        first = S.MONSTER_LOOT.get(monster)
    elif common == "element":
        first = rng.choice(elements)
    elif common == "medicine":
        first = rng.choice(S.MEDICINE_DROPS)
    else:
        first = rng.choice(S.MONSTER_MATERIALS.get(monster, S.WOODS_MATERIALS))
        first = S.ROASTED.get(first, first) if burning else first
    rare = _face(rng, S.RARE_DIE)
    second = None
    if rare == "special":
        second = rng.choice(S.SPECIAL_DROPS)
    elif rare == "seed":
        second = rng.choice(tuple(S.SEEDS))
    elif rare == "gear":
        weapons, relics = gear_pool(who or owners())
        pool = relics if (rng.random() < 0.5 and relics) or not weapons else weapons
        second = rng.choice(pool) if pool else None
    return [item for item in (first, second) if item]
