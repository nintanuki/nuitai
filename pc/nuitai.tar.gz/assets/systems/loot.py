"""What a beaten monster leaves (Frankie, 11/6; built 11/17), apart from the fight that rolls it.

One roll per beaten monster over ``ItemSettings.DROP_CATEGORIES``, so it leaves one thing or nothing and
never pule. ``roll`` is the whole of it; ``battle_scene.roll_drops`` calls it once per monster and
adds the Great Boar's tusk, a key item that is always his and outside the roll.

The gear category is a generated weapon or relic (``core/gear_gen.py``) of a type the party can use
so far: Kailo's, Hina's, Maika's and Tawiri's, and each new island adds its newcomer's, Gen'emon's
on Kupulau (Frankie, 11/6).
"""

from __future__ import annotations

import random
from functools import lru_cache
from typing import Any, Iterable

from core.shared import by_id
from settings import ItemSettings, SailingSettings

# A newcomer's types join the pool when the flag is set: Gen'emon's with Kupulau on the map.
_LATER_OWNERS: dict[str, str] = {"genemon": SailingSettings.KNOWN_FLAG + SailingSettings.PORTS[2]}


def owners(flags: dict[str, Any] | None = None, member_ids: Iterable[str] = ()) -> tuple[str, ...]:
    """Whose types the gear drops are for: the first chapter's four, a newcomer's once he is here or his island is."""
    flags = flags or {}
    here = set(member_ids)
    later = tuple(who for who, flag in _LATER_OWNERS.items() if who in here or flags.get(flag))
    return tuple(ItemSettings.GEAR_OWNERS) + later


@lru_cache(maxsize=8)
def gear_pool(who: tuple[str, ...]) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """The generated weapons and the generated relics ``who`` (character ids) can use."""
    from core.equipment import can_hold

    weapons = tuple(i for i, w in by_id("weapons").items() if w.get("generated") and any(can_hold(m, i) for m in who))
    relics = tuple(i for i, r in by_id("relics").items() if r.get("generated") and any(can_hold(m, i) for m in who))
    return weapons, relics


def _pick(rng: random.Random, pool: tuple[str, ...], favorite: str | None, share: float) -> str | None:
    """One of ``pool``: the favorite ``share`` of the time, else any alike."""
    if not pool:
        return None
    if favorite and favorite in pool and rng.random() < share:
        return favorite
    return rng.choice(pool)


def roll(kind: dict[str, Any], rng: random.Random, who: tuple[str, ...] | None = None,
         cast: Iterable[str] = (), burning: bool = False) -> str | None:
    """What one beaten monster leaves, or None for nothing.

    Args:
        kind: The monster's entry in the shared file.
        rng: The dice.
        who: Whose types the gear is for (``owners``); the first chapter's four when not given.
        cast: The move ids it slotted and cast in the fight; only one of those can drop as an element (Frankie, 11/15).
        burning: Whether it fell burning, which roasts the pork it leaves (Frankie, 11/4).
    """
    S = ItemSettings
    monster = kind.get("id", "")
    category = rng.choices(list(S.DROP_CATEGORIES), weights=list(S.DROP_CATEGORIES.values()))[0]
    if category == "nothing":
        return None
    if category == "gear":
        weapons, relics = gear_pool(who or owners())
        pool = relics if (rng.random() < 0.5 and relics) or not weapons else weapons
        return rng.choice(pool) if pool else None
    if category == "element":
        elements = sorted(item for item, (_, move_id) in S.SHELLS.items() if move_id in set(cast))
        return rng.choice(elements) if elements else None
    if category == "special":
        return _pick(rng, S.SPECIAL_DROPS, S.SPECIAL_FAVORITES.get(monster), S.DROP_FAVORITE_SHARE)
    if category == "seed":
        return _pick(rng, tuple(S.SEEDS), S.SEED_FAVORITES.get(monster), S.DROP_FAVORITE_SHARE)
    if category == "loot":
        return S.MONSTER_LOOT.get(monster)
    if category == "medicine":
        return _pick(rng, S.MEDICINE_DROPS, S.MEDICINE_FAVORITES.get(monster), S.DROP_FAVORITE_SHARE)
    # Crafting: its signature (pork, egg) most often, then what its kind gives.
    signature = S.MONSTER_DROPS.get(monster)
    kinds = S.CRAFTING_EXTRA.get(monster) or S.CRAFTING_DROPS  # a boar's: taro and wheat; any other's: the woods'
    pool = tuple(dict.fromkeys(((signature,) if signature else ()) + tuple(kinds)))
    drop = _pick(rng, pool, signature, S.DROP_SIGNATURE_SHARE if signature else S.DROP_FAVORITE_SHARE)
    return S.ROASTED.get(drop, drop) if burning and drop else drop
