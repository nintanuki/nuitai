"""Things on the ground (Frankie, 11/25): what a punch, a chop or a felling gives falls from the top of the tree's
crown, bounces a little and lands on the tree's own tile, to be picked up (``DropSettings``).

A drop is its room, item, count and tile, and an age that says where it is in its fall. Drops on one tile stack: the
top one is drawn, and a pick up takes them all. The scene keeps the list (``core/scenes/overworld_scene.py``).
"""

from __future__ import annotations

import os

import pygame

from settings import DropSettings, GridSettings


class Drop:
    """One thing lying (or falling) on a tile."""

    def __init__(self, room: str, item: str, count: int, col: int, row: int) -> None:
        self.room, self.item, self.count, self.col, self.row = room, item, count, col, row
        self.age = 0.0

    @property
    def landed(self) -> bool:
        return self.age >= DropSettings.FALL_SECONDS


def lift(age: float) -> int:
    """How many pixels above its tile a drop of this age is: from the crown top down, then one small bounce."""
    fall, bounce = DropSettings.FALL_SECONDS, DropSettings.BOUNCE_SECONDS
    if age < fall:
        return round(DropSettings.CROWN_HEIGHT * (1 - (max(age, 0.0) / fall) ** 2))
    if age < fall + bounce:
        u = (age - fall) / bounce
        return round(DropSettings.BOUNCE_HEIGHT * 4 * u * (1 - u))
    return 0


def rect(drop: Drop) -> pygame.Rect:
    """Where the drop is drawn: its tile's rectangle (16 by 16), raised by the fall or bounce; at rest, exactly the tile."""
    from settings import OverworldSettings
    size = GridSettings.TILE_SIZE
    return pygame.Rect(OverworldSettings.X + drop.col * size, OverworldSettings.Y + drop.row * size - lift(drop.age), size, size)


_PICTURES: dict[str, pygame.Surface] = {}


def picture(item: str) -> pygame.Surface:
    """The drop's 16 by 16 picture: ``assets/graphics/drops/<item>.png`` if there is one, else a colored blob with a
    dark outline."""
    if item not in _PICTURES:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        path = os.path.join(root, *DropSettings.PICTURE_FOLDER, f"{item}.png")
        if os.path.exists(path):
            _PICTURES[item] = pygame.image.load(path)
        else:
            size = GridSettings.TILE_SIZE
            surface = pygame.Surface((size, size), pygame.SRCALPHA)
            box = pygame.Rect(3, size // 2 - 3, size - 6, size // 2 + 1)
            pygame.draw.ellipse(surface, DropSettings.OUTLINE, box)
            pygame.draw.ellipse(surface, DropSettings.COLORS.get(item, DropSettings.DEFAULT_COLOR), box.inflate(-2, -2))
            _PICTURES[item] = surface
    return _PICTURES[item]


def at(drops: list, room: str, col: int, row: int) -> list:
    """The drops lying on a tile."""
    return [d for d in drops if d.room == room and (d.col, d.row) == (col, row)]


def top_per_tile(drops: list, room: str) -> list:
    """The drop drawn on each tile of the room: the last to land there."""
    top: dict = {}
    for d in drops:
        if d.room == room:
            top[(d.col, d.row)] = d
    return list(top.values())
