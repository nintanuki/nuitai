"""The first lontar talk (Frankie, 11/10): Kailo and Hina, the first time the party gets or reads a lontar.

It never names the move, so it fits any lontar. It plays once, with Hina and Kailo both in the
party (``ItemSettings.FIRST_FLAG`` marks it said), and takes the place of Kailo's old "that's right,
I can't read" exchange when the two would play at the same moment.
"""

from __future__ import annotations

from settings import ItemSettings


def due(party) -> bool:
    """Whether the first lontar talk is still to come, and Hina and Kailo are both along."""
    return (not party.flags.get(ItemSettings.FIRST_FLAG)
            and party.find("kailo") is not None and party.find("hina") is not None)


def take(party) -> list[tuple[str, str]]:
    """The talk's lines as (speaker name, line), marking it said; empty if it is not due."""
    if not due(party):
        return []
    party.flags[ItemSettings.FIRST_FLAG] = True
    return list(ItemSettings.FIRST_TALK)
