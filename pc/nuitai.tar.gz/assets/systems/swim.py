"""Swimming (Frankie, 11/16): who may, who waits ashore, and what rises in the sea.

Only Kailo swims. Going in, everyone else in the party stays where he left them (``Party.leave``, kept as they
are) and the flag ``SwimSettings.WAITING_FLAG`` remembers the room, the spot, the step count and who. They wait
``SwimSettings.WAIT_STEPS`` steps, about as long as monsters take to come back, then go back to the village; they
join him again when he walks back to the spot or into the village. Alone, he fights alone. Sirenas are field monsters that live in salt water (``data/field_monsters/sirena.json``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from settings import OverworldSettings, SwimSettings
from systems import garden

if TYPE_CHECKING:
    from systems.party import Party

SWIMMER = "kailo"


def can_swim(party: "Party", shown: str) -> bool:
    """Whether Kailo is on the map, in the party and on his feet."""
    kailo = party.find(SWIMMER)
    return shown == SWIMMER and kailo is not None and kailo.current_hp > 0


def is_salt(char: str | None) -> bool:
    return char == OverworldSettings.WATER_CHAR


def is_swimmable(char: str | None) -> bool:
    """Sea and fresh water can be swum; a spring cannot (it heals, nothing more)."""
    return char in (OverworldSettings.WATER_CHAR, OverworldSettings.FRESH_CHAR)


def leave_party(party: "Party", room: str, col: int, row: int) -> None:
    """Kailo goes in: everyone else stays behind where he stood."""
    ids = [m.id for m in party.members if m.id != SWIMMER]
    for member_id in ids:
        party.leave(member_id)
    if ids:
        # One of them stands on the shore for the rest, Hina first, then Maika, then Tawiri (Frankie, 11/16).
        who = next((i for i in SwimSettings.STAND_IN if i in ids), ids[0])
        party.flags[SwimSettings.WAITING_FLAG] = {
            "room": room, "col": col, "row": row, "stamp": garden.steps(party), "ids": ids, "home": False, "who": who}


def waiting_person(party: "Party", room: str) -> dict | None:
    """The one left on the shore in ``room``, as a person the map draws and Kailo talks to, or None."""
    left = waiting(party)
    if left is None or left["home"] or left["room"] != room:
        return None
    return {"col": left["col"], "row": left["row"], "facing": [0, 1], "sheet": left["who"].capitalize(),
            "speaker": left["who"].capitalize(), "party_rest": True, "turn": {}}


def waiting(party: "Party") -> dict | None:
    return party.flags.get(SwimSettings.WAITING_FLAG)


def tick(party: "Party") -> bool:
    """Count a step; True the first time the waiting party gives up and heads back to the village, quietly
    (no notice, Frankie, 11/16): the one on the shore is gone and they rejoin when he is next in the village."""
    left = waiting(party)
    if left is None or left["home"]:
        return False
    if garden.steps(party) - left["stamp"] >= SwimSettings.WAIT_STEPS:
        left["home"] = True
        return True
    return False


def waited_long(party: "Party") -> bool:
    """Whether the ones ashore have waited at least half as long as they will before going home (Frankie, 11/16)."""
    left = waiting(party)
    return left is not None and garden.steps(party) - left["stamp"] >= SwimSettings.WAIT_STEPS // 2


def regroup_due(party: "Party", in_village: bool) -> bool:
    """Whether the party that gave up and went home is together again: Kailo, on land, is in the village.
    One still on the shore waits to be talked to instead (``regroup`` then)."""
    left = waiting(party)
    return left is not None and left["home"] and in_village


def regroup(party: "Party") -> list[str]:
    """Everyone who waited rejoins; the ids that did."""
    left = party.flags.pop(SwimSettings.WAITING_FLAG, None)
    if left is None:
        return []
    return [i for i in left["ids"] if party.rejoin(i) is not None]
