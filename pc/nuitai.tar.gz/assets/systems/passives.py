"""The party passives: what a member does for everyone just by travelling along.

Each is on while its member is in the party, bench included, and standing,
HP above 0 (Frankie, 10/21, 10/22 and 10/30), about the journey, not the fight. None is shown on a
menu: one sentence says it when the member joins (``join_line``), and
then it just works.

* **Hina:** after a won fight anyone fainted gets up with 1 HP; without
  her they stay at 0. Hers comes first, so Kailo's meal reaches them too.
* **Kailo:** after a won fight, if he is standing, he feeds everyone, and
  all who are standing get back a tenth of their max HP (``meal_rate`` in
  the shared file's ``cooking``).

Hina's and Kailo's are told on the victory screen's last page
(``core/scenes/victory_scene.py``): narrated every time, after a line in
their own voice the first time.
* **Maika:** shops charge less (``core/scenes/shop_scene.py``).
* **Tawiri:** stats grow from use in a fight faster (``growth_step``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from core.shared import SHARED, short_name
from settings import PassiveSettings

if TYPE_CHECKING:
    from systems.party import Party


def standing(party: "Party", member_id: str) -> bool:
    """Whether ``member_id`` is in the party and on their feet. A passive works only
    while its character is standing, and nobody revives themselves (Frankie, 10/30)."""
    member = party.find(member_id)
    return member is not None and member.current_hp > 0


def join_line(member_id: str) -> str:
    """The pop-up said when ``member_id`` joins: who, and their passive in one sentence."""
    line = f"{short_name(member_id)} joined the party."
    passive = PassiveSettings.JOIN_LINES.get(member_id)
    return f"{line} {passive}" if passive else line


def said_flag(member_id: str) -> str:
    """The save's flag set once ``member_id``'s passive has said its line."""
    return f"passive said:{member_id}"


def _told(party: "Party", member_id: str) -> list[tuple[str | None, str]]:
    """The lines for a passive that just worked: the victory screen's
    narration, after its member's own line the first time (Frankie, 10/26)."""
    narrated = (None, PassiveSettings.NARRATED[member_id])
    flag = said_flag(member_id)
    if party.flags.get(flag):
        return [narrated]
    party.flags[flag] = True
    return [(short_name(member_id), PassiveSettings.FIRST_LINES[member_id]), narrated]


def after_victory(party: "Party", grew: bool = False) -> list[tuple[str | None, str]]:
    """Hina's and Kailo's passives, after a won fight. Returns the lines to
    tell, each as ``(speaker, line)``, the speaker None for narration.

    A passive that did nothing says nothing. One that worked is narrated
    every time; the first time, its member says a line before that, and a
    flag in the save remembers it (Frankie, 10/26; Kailo's line every fight
    was repetitive).

    Tawiri's growth bonus has no narration: the first time a stat rose in a
    won fight (``grew``) with her standing, she says her one line, and never
    again (Frankie, 10/29; the words are Claude's draft, 11/19).
    """
    lines: list[tuple[str | None, str]] = []
    if grew and standing(party, "tawiri") and not party.flags.get(said_flag("tawiri")):
        party.flags[said_flag("tawiri")] = True
        lines.append(("Tawiri", PassiveSettings.FIRST_LINES["tawiri"]))
    if standing(party, "hina"):
        fallen = [m for m in party.members if m.current_hp <= 0]
        for member in fallen:
            member.current_hp = 1
        if fallen:
            lines += _told(party, "hina")
    if not standing(party, "kailo"):
        return lines
    rate = SHARED["cooking"]["meal_rate"]
    hurt = [m for m in party.members if 0 < m.current_hp < m.max_hp]
    if not hurt:
        return lines
    for member in hurt:
        member.current_hp = min(member.max_hp, member.current_hp + max(1, round(member.max_hp * rate)))
    lines += _told(party, "kailo")
    return lines


def growth_step(party: "Party") -> float:
    """What every point toward a stat's next rise is multiplied by: more with Tawiri along."""
    if standing(party, "tawiri"):
        return PassiveSettings.TAWIRI_GROWTH
    return 1.0
