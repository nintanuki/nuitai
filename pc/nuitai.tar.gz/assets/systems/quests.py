"""The quest log (Frankie, 11/12: the menu's Info gets Quests beside Bestiary and Lore).

Nothing is saved here. Every quest is read from the party's story flags
each time the log opens, so it saves and loads with the game and an old
save fills in by itself. A quest shows only once the game has told the
player about it, and stays on the log, marked done, when it is over. The
words are Claude's drafts (11/12), plain, and no spoiler past what the
player has seen. A description is two help lines at most.

The hunts sit in the same list (Claude's suggestion, 11/12; Frankie to
confirm one list or two), each starting "Hunt: ". Their state is read only
through ``systems/bounties.py``'s functions, so the lodge keeper's code can
change under them. The board's first post, the Great Boar, shows as a hunt
once taken, and stands in for the Great Boar quest line then.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Iterable

from settings import ItemSettings, LanuSettings, ShopSettings, StewSettings, StorySettings
from systems import bounties, stew

if TYPE_CHECKING:
    from systems.party import Party

HUNT = "Hunt: "


@dataclass(frozen=True)
class Quest:
    """One line of the log: its name, what to do next, and whether it is over."""

    id: str
    name: str
    text: str
    done: bool = False


def _great_boar(party: "Party") -> Quest | None:
    flags = party.flags
    beaten = bool(flags.get(StorySettings.BOAR_BEATEN_FLAG))
    if not (beaten or flags.get(StewSettings.QUEST_FLAG)):
        return None
    return Quest("great_boar", "The Great Boar",
                 "The Great Boar is beaten." if beaten else "He rules the boars, at the top of the woods.", beaten)


def _stew(party: "Party") -> Quest | None:
    made = stew.made(party)
    if not (made or party.flags.get("stew_offered")):
        return None
    return Quest("stew", "Stew for the wake",
                 "The stew is made." if made else "Bring Noelani what the stew needs.", made)


def _miki(party: "Party") -> Quest | None:
    flags = party.flags
    over = bool(flags.get(StorySettings.SISTER_TOLD_FLAG) or flags.get(StorySettings.SISTER_LIED_FLAG))
    if not (over or flags.get(StorySettings.SISTER_DEAL_FLAG)):
        return None
    return Quest("miki", "Miki's brother",
                 "You told Miki." if over else "Tell Miki where her brother is.", over)


def _soy_sauce(party: "Party") -> Quest | None:
    flags = party.flags
    if not (flags.get(StorySettings.SISTER_DEAL_FLAG) or flags.get(ShopSettings.SOY_HINT_FLAG)):
        return None
    got = stew.made(party) or party.inventory.get(StorySettings.SOY_SAUCE, 0) > 0
    return Quest("soy_sauce", "Soy sauce",
                 "You have the shoyu." if got else "Noelani's stew needs shoyu. The grocer's costs too much.", got)


def _lanu(party: "Party") -> Quest | None:
    flags = party.flags
    cups = int(flags.get(LanuSettings.CUPS_FLAG, 0))
    over = bool(flags.get(LanuSettings.BLESSED_FLAG) or flags.get(LanuSettings.GONE_FLAG))
    if not (over or cups):
        return None
    if over:
        text = "Lanu is fed."
    elif cups >= LanuSettings.CUPS:
        text = "All five are watered. Tell the Lanu sage."
    else:
        text = f"Leave water at her posts: {cups} of {LanuSettings.CUPS}."
    return Quest("lanu_posts", "Lanu's five posts", text, over)


def hunts(party: "Party", boards: Iterable[dict]) -> list[Quest]:
    """The hunts taken and not yet paid: "Hunt: ten wild boars, 3/10", done ones say to go back."""
    out = []
    for board in boards:
        for key in (bounties.FIRST, bounties.ROUND):
            if key == bounties.FIRST and (not board.get("first") or party.flags.get(bounties.FIRST_FLAG)):
                continue
            if not bounties.taken(party, key):
                continue
            post = bounties.post_of(party, board, key)
            over = bounties.done(party, board, key)
            count = post["count"]
            got = count if (key == bounties.FIRST and over) else (0 if key == bounties.FIRST else bounties.count(party))
            name = f"{HUNT}{post['what']}, {got}/{count}"
            pay = f"Pays {post['pule']} pule"
            if post.get("prize"):
                pay += f" and a {ItemSettings.NAMES.get(post['prize'], post['prize'])}"
            text = "Done. Go back to the lodge." if over else pay + "."
            out.append(Quest(f"hunt:{post['monster']}", name, text, False))
    return out


def log(party: "Party", boards: Iterable[dict] = ()) -> list[Quest]:
    """Every quest the player has been told about: the open ones first, the finished ones below."""
    found = [make(party) for make in (_great_boar, _stew, _miki, _soy_sauce, _lanu)]
    hunting = hunts(party, boards)
    if any(h.id == "hunt:great_boar" for h in hunting):
        found = [q for q in found if q is None or q.id != "great_boar"]  # the hunt says it
    quests = [q for q in found if q is not None] + hunting
    return [q for q in quests if not q.done] + [q for q in quests if q.done]
