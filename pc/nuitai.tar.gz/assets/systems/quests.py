"""The quest log (Frankie, 11/12: the menu's Info gets Quests beside Bestiary and Lore).

Nothing is saved here. Every quest is read from the party's story flags
each time the log opens, so it saves and loads with the game and an old
save fills in by itself. A quest shows only once the game has told the
player about it, and stays on the log, marked done, when it is over. The
words are Claude's drafts (11/12), plain, and no spoiler past what the
player has seen. A description is two help lines at most.

The hunts sit in the same list (Claude's suggestion, 11/12; Frankie to
confirm one list or two), each starting "Hunt: ". Their state is read only
through ``systems/bounties.py``'s functions, so the lodge keeper's code can
change under them. The board's first post, the Great Boar, shows as a hunt
once taken, and stands in for the Great Boar quest line then.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Iterable

from settings import ItemSettings, LanuSettings, ShopSettings, StewSettings, StorySettings
from systems import bounties, stew

if TYPE_CHECKING:
    from systems.party import Party

HUNT = "Hunt: "


@dataclass(frozen=True)
class Quest:
    """One line of the log: its name, what to do next, and whether it is over."""

    id: str
    name: str
    text: str
    done: bool = False
    giver: str = ""   # who gave it to the player (Frankie, 11/12)
    place: str = ""   # where it is, or where to take it
    story: str = ""   # the quest told in a short paragraph, for its page (Frankie, 11/21; Claude's drafts)
    count: tuple[str, int, int] | None = None   # (what is counted, how many so far, how many in all), only for a quest that counts

    def source(self) -> str:
        """The log's second help line, who gave it and where: "Noelani, her house." (Claude's wording, 11/19)."""
        return ", ".join(part for part in (self.giver, self.place) if part) + ("." if self.giver or self.place else "")


def _great_boar(party: "Party") -> Quest | None:
    flags = party.flags
    beaten = bool(flags.get(StorySettings.BOAR_BEATEN_FLAG))
    if not (beaten or flags.get(StewSettings.QUEST_FLAG)):
        return None
    return Quest("great_boar", "The Great Boar",
                 "The Great Boar is beaten." if beaten else "He rules the boars.", beaten,
                 giver="Melia", place="top of the woods",
                 story=("Melia told you the Great Boar is the king of the boars in the woods. "
                        + ("You beat him, and the woods are safer now." if beaten else
                           "He has to be beaten before the woods are safe again.")))  # Melia tells the Great Boar story (Frankie, 11/21; it said Noelani)


def _stew(party: "Party") -> Quest | None:
    made = stew.made(party)
    if not (made or party.flags.get("stew_offered")):
        return None
    return Quest("stew", "Stew for the wake",
                 "The stew is made." if made else "Bring Noelani what it needs.", made,
                 giver="Noelani", place="her house",
                 story=("Noelani is cooking a stew for the wake. " + ("The stew is made, and she can serve it now." if made
                        else "She needs help getting everything that goes in it. Bring her what she asks for.")))


def _miki(party: "Party") -> Quest | None:
    flags = party.flags
    over = bool(flags.get(StorySettings.SISTER_TOLD_FLAG) or flags.get(StorySettings.SISTER_LIED_FLAG))
    if not (over or flags.get(StorySettings.SISTER_DEAL_FLAG)):
        return None
    return Quest("miki", "Miki's brother",
                 "You told Miki." if over else "Tell Miki where he is.", over,
                 giver="Miki", place="the hunters' lodge",
                 story=("Miki wants to know where her brother is. "
                        + ("You went to her about it, and that is settled now." if over else
                           "You know now, so go to the hunters' lodge and tell her.")))


def _soy_sauce(party: "Party") -> Quest | None:
    flags = party.flags
    if not (flags.get(StorySettings.SISTER_DEAL_FLAG) or flags.get(ShopSettings.SOY_HINT_FLAG)):
        return None
    got = stew.made(party) or party.inventory.get(StorySettings.SOY_SAUCE, 0) > 0
    return Quest("soy_sauce", "Soy sauce",
                 "You have the shoyu." if got else "The stew needs shoyu.", got,
                 giver="Noelani", place="the grocer's",
                 story=("Noelani's stew needs shoyu, and the grocer is the one who sells it. "
                        + ("You have it now, so the stew can be made." if got else "Buy some and take it to her.")))


def _lanu(party: "Party") -> Quest | None:
    flags = party.flags
    cups = int(flags.get(LanuSettings.CUPS_FLAG, 0))
    over = bool(flags.get(LanuSettings.BLESSED_FLAG) or flags.get(LanuSettings.GONE_FLAG))
    if not (over or cups):
        return None
    if over:
        text = "Lanu is fed."
    elif cups >= LanuSettings.CUPS:
        text = "All watered. Tell the sage."
    else:
        text = f"Water her posts: {cups} of {LanuSettings.CUPS}."
    return Quest("lanu_posts", "Lanu's five posts", text, over, giver="The Lanu sage", place="the grove",
                 story=("The Lanu sage asked you to water the five posts in the grove. "
                        + ("You did, and Lanu is fed." if over else "Water each one, then go back and tell the sage.")),
                 count=("Posts", min(cups, LanuSettings.CUPS), LanuSettings.CUPS))


def _boat(party: "Party") -> Quest | None:
    """Mending the Meialana (Frankie, 11/20): Ama's wood, then his pule. It shows once the hut talk is over
    (the flag a skipped scene sets too) or he has asked; the log never says Ama hands the pule back."""
    flags = party.flags
    fixed = bool(flags.get(StorySettings.BOAT_FIXED))
    if not (fixed or flags.get(StorySettings.BOAT_ASKED) or flags.get(StorySettings.AFTER_JUMP_FLAG)):
        return None
    if fixed:
        text = "The Meialana is mended."
    elif flags.get(StorySettings.BOAT_WOOD_FLAG):
        text = f"Wood done. Next: {StorySettings.BOAT_PULE:,} pule."
    else:
        have = min(party.inventory.get("wood", 0), StorySettings.BOAT_WOOD)
        text = f"Koa wood for Ama: {have} of {StorySettings.BOAT_WOOD}."
    needs_wood = not (fixed or flags.get(StorySettings.BOAT_WOOD_FLAG))
    have = min(party.inventory.get("wood", 0), StorySettings.BOAT_WOOD)
    # Koa, how much more, and where it grows (Frankie, 11/25), while the wood is still wanted.
    left = StorySettings.BOAT_WOOD - have
    more = f"{left} more to bring" if left else "you have enough for him"
    koa = (f"Only koa will do: {more}. It grows on the lagoon shore, south of Nuno's bridge. " if needs_wood else "")
    return Quest("boat", "Mend the Meialana", text, fixed, giver="Ama", place="his bait shop",
                 story=(f"Ama says he can mend the Meialana. He needs {StorySettings.BOAT_WOOD} koa wood first, then "
                        f"{StorySettings.BOAT_PULE:,} pule for the work. " + koa
                        + ("The boat is mended now." if fixed else "Until the boat is fixed, nobody leaves the island.")),
                 count=("Koa wood", have, StorySettings.BOAT_WOOD) if needs_wood else None)


def hunts(party: "Party", boards: Iterable[dict]) -> list[Quest]:
    """The hunts taken and not yet paid: "Hunt: the Great Boar", done ones say to go back."""
    out = []
    for board in boards:
        for key in bounties.hunts(party, board):
            if not bounties.taken(party, key):
                continue
            post = bounties.post_of(board, key)
            over = bounties.done(party, board, key)
            pay = f"Pays {post['pule']} pule"
            if post.get("prize"):
                pay += f" and a {ItemSettings.NAMES.get(post['prize'], post['prize'])}"
            text = "Done. Go back to the lodge." if over else pay + "."
            out.append(Quest(f"hunt:{post['monster']}", f"{HUNT}{post['what']}", text, False,
                              giver="The keeper", place="the lodge",
                              story=(f"The keeper of the hunters' lodge posted a hunt for {post['what']}. "
                                     + ("You beat it, so go back to the lodge to be paid." if over else
                                        "Beat it, then go back to the lodge to be paid. " + pay + "."))))
    return out


def log(party: "Party", boards: Iterable[dict] = ()) -> list[Quest]:
    """Every quest the player has been told about: the open ones first, the finished ones below."""
    found = [make(party) for make in (_great_boar, _stew, _miki, _soy_sauce, _lanu, _boat)]
    hunting = hunts(party, boards)
    if any(h.id == "hunt:great_boar" for h in hunting):
        found = [q for q in found if q is None or q.id != "great_boar"]  # the hunt says it
    quests = [q for q in found if q is not None] + hunting
    return [q for q in quests if not q.done] + [q for q in quests if q.done]
