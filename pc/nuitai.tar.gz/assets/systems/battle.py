"""Turn-based battle simulation. Pure data; emits events; never draws.

The rules began as a port of the browser battle test (deleted 11/3);
what is decided now is in ``game/answers.md``. In short:

* **Conditional turns.** Every combatant has a counter. The lowest
  counter acts next. Acting adds a wait to the actor's counter, and the
  wait is fatigue (D-328): what the turn built, each stroke its points,
  a Skill 7, anything else 1, Defend included. Speed shrinks every wait.
* **Mana is the meter** (D-213 to D-220), up to 7. Attack is a chain
  of strokes on one enemy, light, medium or strong, up to 7 points a
  turn; each stroke that lands builds its points in mana. Defend
  builds 1, and so does dodging or blocking a blow. A technique costs
  the mana row it is slotted in, and a higher row grows it (D-318 to
  D-320, ``systems/loadout.py``). Monsters play by the same rules (D-329): a
  monster picks a move, and if it cannot pay for it yet it attacks
  with strokes instead.
* **Stats come from elements** (``core/stats.py``). Strength and Magic
  scale damage dealt; Vitality and Spirit scale damage taken.
* **Element moves are shared** by everyone who carries that element.
  Each party member also owns one special. Moves are data, in the
  shared battle file (``core/shared.py``); this module knows how to
  run each ``effect``.
* **Stances** (D-257, D-285, D-286, D-365). A party member fights in
  one of two stances, one per element, starting in the first. The
  stance's element counts twice in the stats and the other not at all,
  HP keeping its share. A move works in the stance of each element icon
  it shows (D-362): an element move shows its own element, a special
  both of its owner's unless the file lists ``elements``. Switching
  builds 1 mana and ends the turn.
* **Stats grow by use** (D-498, D-500, D-507). When a party member
  does a stat's action (lands a stroke, casts, is hit, dodges) it puts
  points in that stat's hidden meter; a full meter raises the stat by 1,
  said at once; see ``_fill``.
* **Physical and magic are separate.** Defend and the guard stances
  only work on physical hits. A monster has one element that decides
  what it is weak to; a party member, the element of their stance
  (D-590). A boss has two elements and changes stance for a reason
  (D-591, D-601), and a monster's damage is its strokes (D-598), as
  strong as its own Strength and Magic make them, on the heroes' rules.

The scene drives a battle in two beats:

1. ``start_turn()`` picks the next combatant, runs start-of-turn
   effects, and resolves the turn if it is a monster's. For a party
   member it parks the battle in awaiting-command mode
   (``is_awaiting_command()``).
2. One of the ``submit_*`` methods resolves the player's choice.

Both return a list of events (``core/events.py``) for a view to narrate.
"""

from __future__ import annotations

import math

import random
from fractions import Fraction
from typing import Any, Iterable

from core.elements import Element, NEUTRAL_MULTIPLIER, damage_multiplier
from core.equipment import relic_multiplier
from core.events import (
    AbilityUsedEvent,
    AttackEvent,
    BattleEndedEvent,
    ChainEndedEvent,
    CleansedEvent,
    CureFailedEvent,
    ComboUsedEvent,
    CombatantDefeatedEvent,
    DamageEvent,
    BlockStartEvent,
    DefendEvent,
    DodgeEvent,
    EscapeEvent,
    GuardInterceptEvent,
    HealEvent,
    ManaEvent,
    MissEvent,
    NoteEvent,
    NoniUsedEvent,
    RevivedEvent,
    StatusAppliedEvent,
    StanceEvent,
    StatGrowthEvent,
    StatusResistedEvent,
    StrokeEvent,
    SummonEvent,
    SwapEvent,
    TurnSkippedEvent,
    TurnStartEvent,
    WardBlockedEvent,
    SlotEvent,
    WeaponEvent,
)
from core.shared import SHARED
from systems import diet
from core.stats import defense_scale, max_hp_for, offense_scale, stat_points
from systems import battle_kits, mastery
from systems.loadout import counter_kick, grown, home_row, knows, staircase
from settings import (BattleSettings, BlockSettings, ItemSettings, LoadoutSettings, MasterySettings,
                      MinigameSettings, StatSettings)


# The combos this game can play so far, out of the fifteen in the shared
# file (D-419). Each needs only rules this game already has; the rest
# wait, added slowly (Frankie, 10/18).
COMBOS_BUILT: tuple[str, ...] = ("solar_fist", "vine_whip", "eclipse", "daybreak", "spring_rain", "light_wave")

# Growth by use (D-507): the shared file's numbers, these if it has none.
# ``step`` multiplies every point: 1, or more with Tawiri along.
_GROWTH: dict[str, Any] = {
    "meter": 100, "cap": 255, "step": 1,
    "strong_stroke": 4, "technique_per_row": 10, "spell_per_row": 15, "vitality_share": 0.5,
    "light_streak": 4, "perception_miss": 0.4, "luck_hit": 0.3, "weaker_floor": 0.1,
    **{
        key: value for key, value in SHARED.get("stats", {}).get("growth", {}).items()
        if not key.startswith("_")
    },
}


# Statuses Cure All removes; Cure Blind, Sleep and Poison name their own. Purification removes every status.
_CLEANSABLE: tuple[str, ...] = ("blind", "sleep", "poison")

# The shared file's rules, combos and moves, for the numbers the kits read.
_RULES: dict[str, Any] = SHARED.get("rules", {})
_COMBO: dict[str, dict[str, Any]] = {c["id"]: c for c in SHARED.get("combos", [])}
_MOVE: dict[str, dict[str, Any]] = {m["id"]: m for m in SHARED.get("moves", [])}
SHARED_MONSTERS: dict[str, dict[str, Any]] = {m["id"]: m for m in SHARED.get("monsters", [])}
_ITEM_NAME: dict[str, str] = {i["id"]: i["name"] for i in SHARED.get("items", [])}
# Kailo's Cook (Frankie, 10/22): the shared file's cooking table.
_COOKING: dict[str, Any] = SHARED["cooking"]
_DISH: dict[str, dict[str, Any]] = {d["id"]: d for d in _COOKING["dishes"]}


def fresh_heal(dish_id: str) -> int:
    """What a dish heals served fresh by Cook: half again its bag version, rounded half up as the browser rounds."""
    return int(ItemSettings.HEALS[dish_id] * _COOKING["fresh_multiplier"] + 0.5)

# The guards that step in front of a physical hit (the browser's SENT), and
# those that step in only for fire (FIRE_SENT). A self guard cuts one
# element's hits on its holder only (SELF_EL).
_SENTINELS: tuple[str, ...] = ("sentinel", "counter")

# The curses Hex Bolt counts (the browser's HEXES).
_HEXES: tuple[str, ...] = (
    "blind", "sleep", "poison", "weak", "mbreak", "slow", "possess", "sap", "doom",
    "haunt", "grip", "burn", "wasting", "abreak",
)

# The kinds of element that go at the other side.
_OFFENCE_KINDS: tuple[str, ...] = ("hit", "hit_all", "curse", "curse_all", "doom", "possess")

# The effects that put something good on an ally (a monster aims them at one who lacks it).
_BUFF_EFFECTS: tuple[str, ...] = ("haste", "ward", "protect", "shell", "safeguard", "regen", "auto_life", "boost", "focus")

# Statuses that count down one a turn at the top of their holder's turn.
_COUNTED: tuple[str, ...] = ("weak", "calm", "mleech")

# Stat boosts (D-351, D-716): a stat up by a quarter of base plus the stat,
# until the third turn from now. Max HP up adds a quarter to max HP.
_BOOST_UP = (_RULES.get("stat_steps") or {}).get("up", 0.25)
_DROP_DOWN = (_RULES.get("stat_steps") or {}).get("down", 0.2)

# The shared file's short stat names, as Scold's reactions write them.
_STAT_KEY: dict[str, str] = {
    "hp": "hp", "str": "strength", "mag": "magic", "vit": "vitality",
    "spr": "spirit", "spd": "speed", "acc": "accuracy", "eva": "evasion",
}
# The browser's words for the stats, which its stat messages use.
_STAT_WORD: dict[str, str] = {
    "hp": "Max HP", "strength": "Strength", "magic": "Magic", "vitality": "Vitality",
    "spirit": "Spirit", "speed": "Speed", "accuracy": "Accuracy", "evasion": "Evasion",
}


class Combatant:
    """One participant in a battle."""

    def __init__(
        self,
        combatant_id: str,
        name: str,
        elements: Iterable[Element],
        is_party: bool,
        max_hp: int,
        hp: int | None = None,
        moves: list[dict[str, Any]] | None = None,
        beast: bool = False,
        undead: bool = False,
        immune: Iterable[str] = (),
        poison_rate: float | None = None,
        stances: list[dict[str, Any]] | None = None,
        stance: int = 0,
        loadout: dict[str, int] | None = None,
        growth: dict[str, int] | None = None,
        meters: dict[str, float] | None = None,
        pools: list[tuple[Element, list[dict[str, Any]]]] | None = None,
        switch: list[dict[str, Any]] | None = None,
        kind: str | None = None,
        loot: str | None = None,
        multipliers: dict[str, Fraction] | None = None,
        relic: str | None = None,
        mastery: dict[str, int] | None = None,
        weapon_type: str | None = None,
    ) -> None:
        """Construct a combatant.

        Args:
            combatant_id: Stable id, e.g. a party member or enemy id.
            name: Display name.
            elements: The combatant's elements. Party members carry
                two. A monster carries one, listed twice for a boss.
            is_party: True for party members, False for monsters.
            max_hp: Hit point ceiling.
            hp: Starting HP for this battle; defaults to ``max_hp``.
                A party member who walked in hurt passes less.
            moves: A monster's move list, from the shared battle file.
                Party members leave this empty; their moves come from
                ``Battle.moves_for``.
            beast: True for an animal. Nothing reads this yet; it is
                carried for moves that will care, like Leilagi's Hunt.
            immune: Status ids this combatant can never be given.
            poison_rate: Share of max HP lost to poison each turn, for
                a boss that poison should only nibble at. None means
                the ordinary rate.
            stances: A party member's two stances from the shared file
                (``name``, ``element``). Monsters have none.
            stance: Which stance a party member starts the fight in,
                chosen on the party screen.
            loadout: A party member's slotted techniques, move id ->
                row (``systems/loadout.py``). None offers every move
                they know, each in its own row.
            growth: A party member's points grown by use (D-498), stat
                key -> points. Copied: the battle grows its own, and the
                scene writes them back when the fight ends. A monster's
                are its own stats from the shared file, which never grow.
            meters: A party member's hidden meter for each stat (Frankie,
                10/27), stat key -> points toward the next rise. Copied,
                and written back by the scene like ``growth``.
            pools: A two-stance monster's stances (D-591): for each, its
                element and its moves, the first the one it starts in.
            switch: Why that monster leaves each stance (D-601), from
                the shared file. None switches at random.
            kind: A monster's kind in the shared file ("boar"), which
                Hina's Scold reacts to. None for a party member.
            loot: The item a monster carries (its ``steal``), until it
                is given away.
            multipliers: What a party member's weapon does to their
                stats (core/equipment.py), stat key -> multiplier.
            relic: The relic a party member wears, whose element adds
                its stance weakness to theirs (core/equipment.py).
            mastery: A party member's total weapon mastery EXP, weapon
                type id -> EXP (systems/mastery.py), written back by the
                scene like ``growth``.
            weapon_type: The weapon type that trains when they strike
                (None trains nothing).
        """
        self.id = combatant_id
        self.name = name
        self.elements = tuple(elements)
        self.is_party = is_party
        self.stances = list(stances or [])
        self.stance = stance if 0 <= stance < len(self.stances) else 0
        self.loadout = dict(loadout) if loadout is not None else None
        self.growth: dict[str, int] = dict(growth or {})
        self.meters: dict[str, float] = dict(meters or {})
        # What has grown this fight, stat key -> points, for the victory
        # screen; a stat can rise more than once a fight (Frankie, 10/26).
        self.grown: dict[str, int] = {}
        # What Kailo's Cook has on the fire, served at the start of his next turn (Frankie,
        # 10/25 and 11/4): the dish, what went in, and how steady the stir was, 0 to 1.
        self.dish: str | None = None
        self.dish_parts: tuple[str, ...] = ()
        self.dish_quality: float = 1.0
        # Maika's Vault (Frankie, 11/1): the enemy he will land on while he is up, out of reach.
        self.aloft: str | None = None
        # How well he timed the jump, 0 to 1: a perfect one lands double, never more (Frankie, 11/1).
        self.vault_share: float = 1.0
        self.kind = kind
        self.loot = loot
        self.multipliers = dict(multipliers or {})
        self.relic = relic
        self.mastery: dict[str, int] = dict(mastery or {})
        self.weapon_type = weapon_type
        # The types that rose a level this fight, type id -> the level reached (the victory screen).
        self.mastery_ups: dict[str, int] = {}
        # Left the fight (Scold): down, but not beaten.
        self.gone = False
        self.died_burning = False  # It fell while burning: a boar then leaves roast pork (Frankie, 11/4).
        # Tawiri's spirit (Call): the turns it has left on the party's side; 0 for anyone else.
        self.summon_turns = 0
        # A two-stance monster's pools, and which one it is in (below), come first: its stance's
        # element multiplies its stats on top of its two, as a hero's does (Frankie, 11/15).
        self.pools = list(pools or [])
        self.pool = 0
        # What a monster showed this fight (Frankie, 11/15): the move ids it cast (what it can drop,
        # and what the bestiary learns it has) and the stance elements it was seen in.
        self.casts: set[str] = set()
        self.stances_seen: set[str] = {Element(self.pools[0][0]).value} if self.pools else set()
        self.points = stat_points(self.elements, self.stance_element, self.growth, self.multipliers)
        self.max_hp = max_hp
        self.hp = max_hp if hp is None else hp
        if self.stances:
            self._fit_hp_to_stance()
        self.moves = list(moves) if moves else []
        self.beast = beast
        # Undead take more from Hina's Banish (Frankie, 10/31; which ones, Claude's picks).
        self.undead = undead
        self.immune = frozenset(immune)
        self.poison_rate = (
            BattleSettings.POISON_RATE if poison_rate is None else poison_rate
        )
        # Turn counter. The lowest counter in the battle acts next.
        self.counter = 0.0
        # The mana meter, 0 to ``BattleSettings.MANA_CAP``.
        self.mana = BattleSettings.MANA_START
        # Status id -> turns left. Blind and poison have no timer and
        # hold a 1 until cured; sleep counts down.
        self.statuses: dict[str, int] = {}
        # Shadow Guard: the share of the next shadow hit it cuts, then it is
        # spent (Frankie, 10/28); 0 for none.
        self.ward = 0.0
        # Haste: the row it was cast from, taken off each turn's fatigue for the
        # rest of the fight, until a KO or a dispel (Frankie, 11/10); 0 for none.
        self.haste = 0
        # Safeguard: stops the next blind, sleep or poison, then is spent.
        self.safe = False
        # Regen: turns left that heal a little at the top of the turn.
        self.regen = 0
        self.rain_heal = 0  # What Spring Rain gives back at each turn while it falls (Frankie, 11/4).
        self.wave_keep = 0.5  # The share of magic Light Wave lets through, at best a half (Frankie, 11/4).
        # Set by Defend, cleared at the top of this combatant's turn.
        self.defending = False
        # Guard stance id ("sentinel", "counter", "cooker", Kailo's
        # "bell", "oil", ...) or None. At the top of this combatant's
        # turn it holds while ``guard_left`` counts down (a guard slotted
        # above its row holds longer, D-325), then it drops.
        self.guard: str | None = None
        self.guard_left = 0
        # The share of a hit a guard lets through, when it is not the usual.
        self.guard_m: float | None = None
        # How hard Counter kicks back, when it is not the usual (grown, Frankie 10/28).
        self.guard_kick: float | None = None
        # Simmer and Boil Over (Frankie, 10/19): the enemy it
        # will go off on, and the damage held in since it was raised.
        self.cooker_target: str | None = None
        self.cooker_took = 0
        # Tawiri's called spirit (Call the Dead): turns left and its power.
        self.spirit: dict[str, Any] | None = None
        # Who put a status on: "sap" and "mleech" pay back their caster.
        self.cursed_by: dict[str, str] = {}
        # Haunt's bite, worked out when it was cast.
        self.haunt_damage = 0
        # Stat boosts in force (D-716), stat key -> points added (max HP for "hp").
        self.boosts: dict[str, int] = {}
        # Stat drops in force, stat key -> points taken off.
        self.drops: dict[str, int] = {}
        # A boss: Death Knell does nothing to it, Grave Grip holds it one turn.
        self.boss = False
        # Set by Defend: until their next turn an ally can pull them into
        # a combo (D-182).
        self.ready = False
        # The weapon held, by name, or None. What it does to the stats is ``multipliers``.
        self.weapon: str | None = None
        # A two-stance monster (D-591, D-601): its pools, which one it is
        # in, why it leaves each, its turns in this one, and the physical
        # blows taken since its last turn.
        self.switch = list(switch or [])
        self.in_stance = 0
        self.struck = 0
        # Never changes stance of its own accord (the boar, Frankie, 11/12: no fire moves yet).
        self.holds_stance = False
        # Looked at through a Seer's Shell this fight (Frankie, 10/28): its
        # element and HP stay up on screen. A new fight builds new monsters.
        self.seen = False
        # From the monster's entry in the shared file (Frankie, 10/28): its
        # ``skill``, one signature move as a party member has (the Great
        # Boar's Squeal calls its kind to its side); ``angry`` (what changes
        # below a share of its HP) and whether it is angry yet; the move it
        # is the move it changed stance to use, played on its next turn; and,
        # for a monster called in, who called it and its picture.
        self.skill: dict[str, Any] | None = None
        # A monster's elements are the party's (Frankie, 11/15): ``carry`` is the ids of the shared
        # elements its kind can have, ``slot_count`` how many it slots, and ``loadout`` (above, move id
        # to tier) which of them it took into this fight, filled by ``Battle.arm``. Its kind can have up
        # to three Skills (``skills``); ``skill`` is the one this monster has. Its ``bag`` holds one item
        # at most, used by the party's item rules; ``napping`` is the share of max HP a Nap gives back
        # each turn it sleeps.
        self.carry: list[str] = []
        self.slot_count = 0
        self.skills: list[dict[str, Any]] = []
        self.bag: str | None = None
        self.napping = 0.0
        # Turned on its own side by Possess for this turn.
        self.turned = False
        self.angry_rule: dict[str, Any] | None = None
        self.angry = False
        self.wanting: dict[str, Any] | None = None
        self.caller: str | None = None
        self.picture: str | None = None

    @property
    def alive(self) -> bool:
        """Return True while HP is above zero."""
        return self.hp > 0

    @property
    def stance_element(self) -> Element | None:
        """Return the element of the stance this combatant is in, or None.

        A monster's stance is its pool's element; one with a single element has none.
        """
        if not self.stances:
            return Element(self.pools[self.pool][0]) if self.pools else None
        return Element(self.stances[self.stance]["element"])

    def take_stance(self, index: int) -> None:
        """Move into stance ``index``: new stats, the same share of HP. Boosts and drops stay on.

        A monster's stance is its pool, switched by the same rule (Frankie, 11/15).
        """
        if self.stances:
            self.stance = index
        else:
            self.pool = index
            self.stances_seen.add(Element(self.pools[index][0]).value)
        self.points = stat_points(self.elements, self.stance_element, self.growth, self.multipliers)
        hp_boost = self.boosts.get("hp", 0)
        self.max_hp -= hp_boost
        self._fit_hp_to_stance()
        for key, added in self.boosts.items():
            if key == "hp":
                self.max_hp += added
            else:
                self.points[key] += added
        for key, taken in self.drops.items():
            self.points[key] -= taken

    def _fit_hp_to_stance(self) -> None:
        """Set max HP from the stance's stats, keeping the share of HP (D-365).

        Rounded, never below 1 while standing: a switch never kills or heals.
        """
        new_max = max_hp_for(self.points)
        if new_max == self.max_hp:
            return
        if self.hp > 0:
            # Extra HP from a meal keeps its share too (Kailo's Cook, 10/25).
            top = new_max if self.hp <= self.max_hp else round(self.hp * new_max / self.max_hp)
            self.hp = min(top, max(1, round(self.hp * new_max / self.max_hp)))
        self.max_hp = new_max

    @property
    def element(self) -> Element | None:
        """Return the element that decides weakness, or None.

        A party member has the element of the stance they are in (D-590), and so
        does a two-stance monster; a monster with one element has that.
        """
        return self.stance_element if self.is_party else (self.stance_element or self.elements[0])


class Battle:
    """A turn-based encounter that emits events as it resolves."""

    def __init__(
        self,
        party_combatants: list[Combatant],
        enemy_combatants: list[Combatant],
        moves: dict[str, dict[str, Any]] | None = None,
        noni: int | None = None,
        rng: random.Random | None = None,
        bench: list[Combatant] | None = None,
        combos: dict[str, dict[str, Any]] | None = None,
        opening: str | None = None,
    ) -> None:
        """Construct a battle from two rosters.

        Args:
            party_combatants: The player's side, the three who fight.
            enemy_combatants: The monsters.
            moves: The moves from the shared battle file, keyed by id.
            noni: Shared Noni count; defaults to the new-game stack.
            rng: Random source. Pass a seeded one for a repeatable fight.
            bench: Party members waiting to be swapped in (D-196).
            combos: The combos from the shared battle file, keyed by id.
                Only those in ``COMBOS_BUILT`` are ever offered.
            opening: "preemptive" when the party caught the monsters from
                behind or the side, "ambush" when the monsters caught them;
                the caught side starts with full fatigue (Frankie, 10/27).
        """
        self.party = party_combatants
        self.enemies = enemy_combatants
        self.bench = list(bench or [])
        # Who ran (Frankie, 11/11): out of the fight with the HP they had, kept for the field.
        self.escaped: list[Combatant] = []
        self._left_at: dict[str, int] = {}  # Where each runner stood in the party when they ran.
        self._combos = {
            cid: combo for cid, combo in (combos or {}).items() if cid in COMBOS_BUILT
        }
        self._moves = dict(moves or {})
        self.noni = (
            BattleSettings.STARTING_NONI if noni is None else noni
        )
        self._rng = rng or random.Random()
        # Growth by use (D-507), copied so a test can change the numbers.
        self.growth = dict(_GROWTH)
        # Everyone starts at a random point inside the first tick, so
        # the opening order is not always the same.
        for combatant in self.party + self.enemies:
            combatant.counter = self._rng.random()
        # Each monster fills its slots from its kind's pool and has its one Skill, picked at random
        # (Frankie, 11/15), before it opens in a stance.
        for monster in self.enemies:
            self.arm(monster)
        # An ordinary two-stance monster opens in a random one of its stances (Frankie, 11/12);
        # a boss opens in its first, as before (bosses undecided).
        for monster in self.enemies:
            if len(monster.pools) > 1 and not monster.boss and self._rng.random() < 0.5:
                self._enter_stance(monster, 1)
        caught = {"preemptive": self.enemies, "ambush": self.party}.get(opening or "", [])
        for combatant in caught:
            combatant.counter += BattleSettings.FATIGUE_TECH * defense_scale(combatant.points["speed"])
        self._ended = False
        self._outcome: str | None = None
        # Monsters whose last turn went to sulking: they shrug off the next Scold (Frankie, 10/24).
        self._sulked: set[str] = set()
        # Monsters called this fight by a Squeal, to letter the next one (Frankie, 10/28).
        self._calls = 0
        # Set once the Great Boar's last Squeal, with all his boars beaten, has gone unanswered.
        self._nobody_came = False
        # A caller with ``start`` in its Squeal rule begins the fight with that many of its kind
        # already at its side, so it is never alone (Frankie, 11/1: the Great Boar was beaten in
        # three minutes in the Let's Play, having spent his few turns squealing).
        for monster in list(self.enemies):
            rule = monster.skill or {}
            if rule.get("kind") == "call" and rule.get("start"):
                for called in self._bring(monster, rule["start"]):
                    called.counter = self._rng.random()
        # The row of the move being used, for a fire move's chance to burn
        # (D-561); None for Attack and everything else, which roll at row 1.
        self._tier: int | None = None
        self._current_actor: Combatant | None = None
        self._awaiting_command = False
        # The Attack being chained this turn: the enemy it is aimed at,
        # the stroke points used, and how many strokes landed.
        self._chain: dict[str, Any] | None = None
        # Items given to the party mid-fight (a scolded Aghoy's present),
        # for the scene to put in the bag.
        self.gifts: list[str] = []
        # Timed blocks (Frankie, 10/30): the scene turns them on. A monster's plain
        # strokes at a party member then wait in ``_pending_block`` for the
        # player's catches; off, they land at once, as in tests and autoplay.
        self.timed_blocks = False
        self._block_grade: float | None = None  # How near the sweet spot the stroke being swung was parried (11/10).
        self._pending_block: dict[str, Any] | None = None

    # ------------------------------------------------------------------
    # PUBLIC
    # ------------------------------------------------------------------

    @property
    def is_over(self) -> bool:
        """Return True once the battle has an outcome."""
        return self._ended

    @property
    def outcome(self) -> str | None:
        """Return "victory", "defeat", "flee", or None while running."""
        return self._outcome

    @property
    def current_actor(self) -> Combatant | None:
        """Return the combatant whose turn it is."""
        return self._current_actor

    def is_awaiting_command(self) -> bool:
        """Return True while a party member's turn waits on the player."""
        return self._awaiting_command

    def is_awaiting_block(self) -> bool:
        """Return True while a monster's strokes wait on the player's timed blocks."""
        return self._pending_block is not None

    def arm(self, monster: Combatant, picks: list[str] | None = None) -> None:
        """Give a monster its elements and its Skill for this fight (Frankie, 11/15).

        Its kind lists the shared elements it can carry (``carry``) and how many slots it has; at the
        fight's start it takes a random, distinct pick of that many, in a random order, into the tiers a
        character with as many slots open has (``staircase``). Two of one kind differ. ``picks`` names
        them instead (a test). A kind with several Skills gives each monster one at random.
        """
        if monster.carry and monster.loadout is None:
            count = min(monster.slot_count, len(monster.carry))
            chosen = list(picks) if picks is not None else self._rng.sample(monster.carry, count)
            monster.loadout = dict(zip(chosen, staircase(len(chosen))))
            slotted = [self._moves[move_id] for move_id in chosen]
            if monster.pools:
                monster.pools = [(element, [m for m in slotted if self.works_with(monster, m, element)])
                                 for element, _ in monster.pools]
                monster.moves = list(monster.pools[monster.pool][1])
            else:
                monster.moves = slotted
        if len(monster.skills) > 1:
            monster.skill = self._rng.choice(monster.skills)

    def moves_for(self, combatant: Combatant, stance: int | None = None) -> list[dict[str, Any]]:
        """Return the moves ``combatant`` can pick, shared ones first.

        Moves come back in the order the shared file lists them, which
        is the menu order in both games. A move with an ``owner``
        belongs to that one character (their special, or their own
        version of a shared move). Any other move belongs to everyone
        carrying its element, unless they are named in its ``except``
        list. A move marked ``off`` is not built yet and is left out, and
        so is a Skill with no kit, which the Skill command runs. A party member in a stance gets only the
        moves that work in it (``icons_of``, D-362); ``stance`` asks about
        another of theirs instead, for the switch's preview.
        """
        element_ids = [element.value for element in combatant.elements]
        available: list[dict[str, Any]] = []
        for move in self._moves.values():
            if not knows(move, combatant.id, element_ids):
                continue
            # A signature move (Skill) takes no slot and works in either stance.
            if move.get("signature"):
                available.append(move)
                continue
            if combatant.loadout is not None and move["id"] not in combatant.loadout:
                continue
            if self.works_in_stance(combatant, move, stance):
                available.append(move)
        return available

    def move(self, move_id: str) -> dict[str, Any]:
        """Return the shared file's move ``move_id``."""
        return self._moves[move_id]

    @staticmethod
    def row_of(combatant: Combatant, move: dict[str, Any]) -> int:
        """Return the mana row ``move`` sits in for ``combatant``: its slot, or its own row."""
        if combatant.loadout is not None and move["id"] in combatant.loadout:
            return combatant.loadout[move["id"]]
        return home_row(move)

    @staticmethod
    def icons_of(combatant: Combatant, move: dict[str, Any]) -> list[Element]:
        """Return the element icons ``move`` shows for ``combatant`` (D-361, D-362).

        A move that lists ``elements`` shows those; an element move its
        own element; a special both of its user's, its own element first.
        """
        if move.get("elements"):
            return [Element(e) for e in move["elements"]]
        own = Element(move["element"])
        if move.get("tier") in (None, "element") or not combatant.is_party:
            return [own]
        if own in combatant.elements:
            return [own] + [e for e in combatant.elements if e is not own]
        return list(combatant.elements)

    def works_in_stance(self, combatant: Combatant, move: dict[str, Any], index: int | None = None) -> bool:
        """Return True when ``move`` works in the stance ``combatant`` is in, or in stance ``index``.

        It works in the stance of each icon it shows; a move whose icons
        are all elements the character lacks works in both.
        """
        stance = combatant.stance_element
        if index is not None and combatant.stances:
            stance = Element(combatant.stances[index]["element"])
        return self.works_with(combatant, move, stance)

    def works_with(self, combatant: Combatant, move: dict[str, Any], stance: Element | None) -> bool:
        """Return True when ``move`` works while ``combatant`` is in ``stance``: the party's one rule.

        A monster follows it for each of its own stances (Frankie, 11/15).
        """
        if stance is None:
            return True
        icons = self.icons_of(combatant, move)
        return stance in icons or not any(e in combatant.elements for e in icons)

    def other_stance(self, combatant: Combatant) -> dict[str, Any] | None:
        """Return the stance ``combatant`` could switch to, or None."""
        if len(combatant.stances) < 2:
            return None
        return combatant.stances[1 - combatant.stance]

    def cost_of(self, combatant: Combatant, move: dict[str, Any]) -> int:
        """Return the mana ``move`` costs ``combatant``: the row it sits in.

        A signature move (Skill) costs nothing (Frankie, 10/21).
        """
        return 0 if move.get("signature") else self.row_of(combatant, move)

    def can_afford(self, combatant: Combatant, move: dict[str, Any]) -> bool:
        """Return True when ``combatant`` has the mana for ``move``."""
        # In mana debt (Wili, Frankie, 11/1) no element can be cast until it is built back to 0.
        return combatant.mana >= 0 and combatant.mana >= self.cost_of(combatant, move)

    @property
    def chain_points_left(self) -> int:
        """Return the stroke points left in this turn's Attack."""
        used = self._chain["points"] if self._chain else 0
        return BattleSettings.STROKE_POINTS - used

    @property
    def chaining(self) -> bool:
        """Return True once a stroke has been swung this turn."""
        return self._chain is not None

    def chain_target(self) -> Combatant | None:
        """Return the living enemy the last stroke this turn struck, or None."""
        if self._chain is None:
            return None
        for combatant in self.enemies:
            if combatant.id == self._chain["target"] and combatant.alive:
                return combatant
        return None

    def stroke_chance(self, kind: str, target: Combatant) -> float:
        """Return the current actor's chance, 0 to 1, that a ``kind`` stroke lands on ``target``.

        The same sum ``_physical`` rolls against: the stroke's own aim,
        steadied by each stroke landed this turn on that enemy and the weapon mastery,
        plus Accuracy, minus the Evasion of whoever takes the blow (a sentinel stepping in
        dodges with its own); a blind striker misses half outright.
        """
        actor = self._current_actor
        # The bonus is on one enemy: a new one starts from none (submit_stroke).
        landed = self._chain["landed"] if self._chain and self._chain["target"] == target.id else 0
        struck = self._guard_for(target) or target
        chance = max(0.0, min(1.0, self._land_chance(
            actor, struck, BattleSettings.STROKES[kind]["hit"] + BattleSettings.STROKE_STEADY * landed
            + self._mastery_hit(actor))))
        if "blind" in actor.statuses:
            chance *= 1 - BattleSettings.BLIND_MISS_CHANCE
        return chance

    def preview_wait(self, kind: str) -> float:
        """Return the wait the current actor would pay for ``kind`` now.

        ``kind`` is "attack" (end the chain), "defend", "tech", or
        anything else for a technique or an item. Haste and speed are applied when the
        wait is spent, as for everyone (``_waited``).
        """
        return self._fatigue(kind)

    def upcoming(
        self, count: int, pending_wait: float | None = None
    ) -> list[Combatant]:
        """Predict who acts over the next ``count`` turns.

        The current actor is not included. While a party member's turn
        is waiting, ``pending_wait`` is the wait to assume they pay, so a
        menu can preview its effect on the order. Everyone after that is
        assumed to wait ``BattleSettings.PREVIEW_WAIT``: fatigue depends
        on what they choose, so the order further out is a guess.

        Args:
            count: How many future turns to return.
            pending_wait: The current actor's wait, from ``preview_wait``.

        Returns:
            Combatants in the order they would act. One combatant can
            appear more than once.
        """
        living = [c for c in self.party + self.enemies if c.alive]
        counters = {c.id: c.counter for c in living}

        def spend(combatant: Combatant, base_wait: float) -> None:
            counters[combatant.id] += self._waited(combatant, base_wait)

        actor = self._current_actor
        if self._awaiting_command and actor is not None and actor.alive:
            spend(actor, pending_wait or BattleSettings.PREVIEW_WAIT)
        order: list[Combatant] = []
        while living and len(order) < count:
            nxt = min(living, key=lambda c: counters[c.id])
            order.append(nxt)
            spend(nxt, BattleSettings.PREVIEW_WAIT)
        return order

    def start_turn(self) -> list[Any]:
        """Advance to the next combatant's turn.

        Runs poison and sleep for whoever is up. A monster's turn is
        resolved here; a party member's turn parks the battle until a
        ``submit_*`` call. A turn lost to sleep or ended by poison
        returns with nothing awaiting, so the scene simply calls
        ``start_turn`` again.
        """
        if self._ended or self._awaiting_command or self._pending_block:
            return []
        living = [c for c in self.party + self.enemies if c.alive]
        actor = min(living, key=lambda c: c.counter)
        self._current_actor = actor
        self._tier = None
        events: list[Any] = [TurnStartEvent(actor.id, actor.name)]
        ended = self._check_terminal()
        if ended:
            return events + ended
        # A guard slotted above its row holds for more turns (D-325).
        if actor.guard is not None and actor.guard_left > 0:
            actor.guard_left -= 1
        else:
            actor.guard = None
        actor.defending = False
        actor.ready = False
        self._chain = None
        # Nothing on Maika ticks while he is up; it waits for him to land (Frankie, 11/2).
        if not actor.aloft:
            events.extend(self._turn_ticks(actor))
        if not actor.alive:
            events.extend(self._check_terminal())
            return events
        ended = self._check_terminal()
        if ended:
            return events + ended
        # The hands of the dead hold the gripped one still (Grave Grip).
        if actor.statuses.get("grip"):
            actor.statuses["grip"] -= 1
            if actor.statuses["grip"] <= 0:
                del actor.statuses["grip"]
            events.append(NoteEvent(f"The dead hold {actor.name} still.", actor.id))
            events.extend(self._spend(actor, BattleSettings.FATIGUE_OTHER, still=True))
            events.extend(self._check_terminal())
            return events
        # Scold: a sulking enemy loses SULK_TURNS turns, then stops sulking, and a hit
        # does not snap it out (Frankie, 10/25; it was one turn).
        if actor.statuses.get("sulk"):
            actor.statuses["sulk"] -= 1
            events.append(NoteEvent(f"{actor.name} is still sulking.", actor.id))
            if actor.statuses["sulk"] <= 0:
                del actor.statuses["sulk"]
                self._sulked.add(actor.id)
                events.append(NoteEvent(f"{actor.name} stops sulking.", actor.id))
            events.extend(self._spend(actor, BattleSettings.FATIGUE_OTHER, still=True))
            events.extend(self._check_terminal())
            return events
        self._sulked.discard(actor.id)
        if "sleep" not in actor.statuses:
            # Moepapa's marks go when the sleep does, however it went (Frankie, 10/31).
            actor.statuses.pop("deep", None)
            actor.statuses.pop("nightmare", None)
        if "sleep" in actor.statuses:
            nightmare = actor.statuses.get("nightmare", 0)
            if nightmare:
                # Moepapa's nightmares bite each turn asleep (Frankie, 10/31).
                events.extend(self._deal(actor, nightmare, Element.ATA, cause="nightmare"))
                if not actor.alive:
                    events.extend(self._check_terminal())
                    return events
            actor.statuses["sleep"] -= 1
            events.append(TurnSkippedEvent(actor.id, actor.name, "sleep"))
            if actor.statuses["sleep"] <= 0:
                del actor.statuses["sleep"]
                actor.statuses.pop("deep", None)
                actor.statuses.pop("nightmare", None)
                events.append(StatusAppliedEvent(actor.id, actor.name, "sleep", False))
            events.extend(self._spend(actor, BattleSettings.FATIGUE_OTHER, still=True))
            events.extend(self._check_terminal())
            return events
        if actor.summon_turns:
            events.extend(self._summon_turn(actor))
            events.extend(self._check_terminal())
            return events
        if actor.is_party and actor.aloft:
            # Maika comes down from his Vault; the landing is his turn (Frankie, 11/1).
            events.extend(self._land(actor))
            events.extend(self._turn_ticks(actor))
            events.extend(self._check_terminal())
            return events
        if actor.is_party:
            # What Kailo cooked last turn is served first (Frankie, 10/25).
            if actor.dish:
                events.extend(self._serve(actor))
            self._awaiting_command = True
            return events
        events.extend(self._monster_turn(actor))
        if self._pending_block:
            return events
        events.extend(self._check_terminal())
        return events

    def block_stroke(self, result: str, grade: float | None = None) -> list[Any]:
        """Swing the monster's next waiting stroke with the player's block on it (Frankie, 10/30).

        ``result`` is "perfect", "catch" or "miss"; ``grade`` (0 to 1) says how near the sweet spot
        a catch was and so how much of the stroke it takes off (Frankie, 11/10). The scene calls this as each
        red bar lands. The chain ends after its last stroke, or at once if the
        target or the monster falls, and the rest of the strokes are dropped.
        """
        pending = self._pending_block
        if pending is None:
            return []
        monster, target = pending["monster"], pending["target"]
        kind = pending["kinds"][pending["swung"]]
        pending["swung"] += 1
        self._block_grade = grade
        events = self._stroke(monster, target, kind, pending["chain"], result)
        self._block_grade = None
        pending["events"].extend(events)
        # Three perfect parries in a row within this one attack are answered at once by a Strong stroke
        # from the parrier, after Counter's kick if that is up; any other press, or a miss, breaks the
        # streak (Frankie, 11/10). Only heroes parry, so only heroes counter.
        pending["streak"] = pending["streak"] + 1 if result == "perfect" else 0
        if pending["streak"] >= BlockSettings.PARRY_STREAK:
            pending["streak"] = 0
            events = events + self._parry_counter(events, monster)
        if pending["swung"] < len(pending["kinds"]) and target.alive and monster.alive:
            return events
        self._pending_block = None
        events.extend(self._chain_end(monster, pending["chain"], pending["events"], pending.get("then")))
        events.extend(self._check_terminal())
        return events

    def _parry_counter(self, parried: list[Any], monster: Combatant) -> list[Any]:
        """The counterattack after a streak of perfect parries: the parrier's own Strong stroke at ``monster``."""
        hit = next((e for e in parried if isinstance(e, DamageEvent) and e.timed == "perfect"), None)
        parrier = next((c for c in self.party if hit and c.id == hit.target_id), None)
        if parrier is None or not parrier.alive or not monster.alive:
            return []
        return self._stroke(parrier, monster, "strong", {"target": None, "points": 0, "landed": 0})

    def field_strike(self, striker_id: str) -> list[Any]:
        """The blow a field strike lands before the first turn (Frankie, 11/14): the striker's
        Strong stroke at the first monster standing, sure to hit and dodged by nobody.

        Nothing is spent but what a Strong stroke would give: it builds its mana and trains the
        weapon as it does in a turn. The fight goes on from there, or ends if the blow fells the
        last monster.
        """
        striker = next((c for c in self.party if c.id == striker_id and c.alive), None)
        target = next((c for c in self.enemies if c.alive), None)
        if striker is None or target is None:
            return []
        events = self._stroke(striker, target, "strong", {"target": target.id, "points": 0, "landed": 0}, sure=True)
        return events + self._check_terminal()

    def submit_blocks(self, results: list[str]) -> list[Any]:
        """Swing all the waiting strokes with ``results``, one per stroke, in order."""
        events: list[Any] = []
        for result in results:
            if self._pending_block is None:
                break
            events.extend(self.block_stroke(result))
        return events

    def submit_stroke(self, kind: str, target_id: str) -> list[Any]:
        """Swing one stroke of the Attack at ``target_id``.

        The turn goes on until the player ends the chain, picks a
        technique or Defend, or spends the last of the 7 points; the
        last stroke ends it by itself.

        Args:
            kind: "light", "medium" or "strong".
            target_id: The enemy struck. Any stroke may pick a new one:
                backing out to Attack mid-chain retargets (Frankie, 11/4),
                and the points left carry over.
        """
        actor = self._require_player_actor()
        stroke = BattleSettings.STROKES[kind]
        if stroke["points"] > self.chain_points_left:
            raise ValueError(f"not enough points left for a {kind} stroke")
        if self._chain is None:
            self._chain = {"target": target_id, "points": 0, "landed": 0}
        if self._chain["target"] != target_id:
            # Claude's call (11/4): the 10% each landed stroke adds is momentum on one
            # enemy, so it starts over when the chain moves onto another.
            self._chain["landed"] = 0
        self._chain["target"] = target_id
        target = self._find(self.enemies, target_id)
        events = self._stroke(actor, target, kind, self._chain)
        terminal = self._check_terminal()
        if terminal:
            self._awaiting_command = False
            return events + terminal
        lightest = BattleSettings.STROKES["light"]["points"]
        if self.chain_points_left < lightest or not actor.alive:
            return self._finish_player_turn(events, "attack")
        return events

    def submit_end_chain(self) -> list[Any]:
        """End the turn after one or more strokes."""
        self._require_player_actor()
        return self._finish_player_turn([], "attack")

    def submit_attack(self, target_id: str) -> list[Any]:
        """Attack with the whole chain at once: light, medium, strong.

        The chain monsters use, for tests and anything that plays the
        party's turn by itself.
        """
        actor = self._require_player_actor()
        self._chain = {"target": target_id, "points": 0, "landed": 0}
        target = self._find(self.enemies, target_id)
        events = self._auto_strokes(actor, target, self._chain)
        return self._finish_player_turn(events, "attack")

    def submit_defend(self) -> list[Any]:
        """Resolve Defend: halve physical damage until the next turn, build 1 mana."""
        actor = self._require_player_actor()
        return self._finish_player_turn(self._defend(actor), "defend")

    def _defend(self, actor: Combatant) -> list[Any]:
        """Defend, the one rule for both sides: brace, build DEFEND_MANA (Frankie, 11/15)."""
        actor.defending = True
        actor.ready = True
        events: list[Any] = [DefendEvent(actor.id, actor.name)]
        events.extend(self._gain(actor, BattleSettings.DEFEND_MANA))
        return events

    def _monster_defend(self, monster: Combatant, points: int = 0) -> list[Any]:
        """A monster's Defend: free, builds mana, waits as the party's does (Frankie, 11/15)."""
        events = self._defend(monster)
        return events + self._spend(monster, self._fatigue("defend", points))

    def submit_stance(self) -> list[Any]:
        """Switch to the other stance: builds 1 mana and ends the turn (D-285)."""
        actor = self._require_player_actor()
        other = self.other_stance(actor)
        if other is None:
            raise ValueError(f"{actor.id} has no other stance")
        actor.take_stance(actor.stances.index(other))
        events: list[Any] = [StanceEvent(
            actor.id, actor.name, other["name"], Element(other["element"])
        )]
        events.extend(self._gain(actor, BattleSettings.STANCE_MANA))
        return self._finish_player_turn(events, "move")

    def submit_move(
        self, move_id: str, target_id: str | None = None, give_to_id: str | None = None,
    ) -> list[Any]:
        """Resolve a technique, paying its mana.

        Args:
            move_id: An id from the shared file's move list.
            target_id: The chosen combatant, or None for a move whose
                ``target`` is "none". A "fallen" move names a downed ally.
            give_to_id: For a move with ``give_to`` (Drain, Osmose,
                Borrowed Life), who gets what it takes from the enemy:
                an ally, or a fallen one. None gives it to the one acting.
        """
        actor = self._require_player_actor()
        move = self._moves[move_id]
        if not self.can_afford(actor, move):
            raise ValueError(f"{actor.id} cannot pay for {move_id}")
        if not self.works_in_stance(actor, move):
            raise ValueError(f"{move_id} does not work in {actor.id}'s stance")
        # An element can aim at either side, a heal at an enemy, a blow at an ally (Frankie, 11/3).
        target = self._find(self.party + self.enemies, target_id) if target_id else actor
        if move["target"] == "fallen" and target.alive and target.is_party:
            raise ValueError(f"{target.id} is still standing")
        events: list[Any] = [
            AbilityUsedEvent(
                actor.id, actor.name, move_id, move["name"],
                target.name if target is not actor else None,
            )
        ]
        row = self.row_of(actor, move)
        events.extend(self._pay(actor, self.cost_of(actor, move)))
        # A fire move slotted higher burns more often (D-561).
        self._tier = row
        other = self._find(self.party, give_to_id) if give_to_id else None
        effect = self._run_effect(actor, target, grown(move, row), other)
        events.extend(effect)
        # A technique's own damage grows by its kind (D-527): a physical
        # hit Strength, magic damage or healing Intelligence, more points
        # the higher its mana row (D-528, Frankie, 10/27).
        # Hurting a friend teaches nothing (Frankie, 11/4).
        foes = {c.id for c in self.enemies}
        hurt = [e for e in effect if isinstance(e, DamageEvent) and e.amount > 0 and e.target_id in foes]
        hit = [e.target_id for e in hurt if e.cause == "hit"]
        spell = [e.target_id for e in hurt if e.cause in ("spell", "holy")]
        if hit:
            events.extend(self._fill(actor, "strength", self.growth["technique_per_row"] * max(1, row)
                                     * self._teaches(actor, "strength", hit)))
        if spell or any(
            isinstance(e, HealEvent) and e.amount > 0 or isinstance(e, RevivedEvent)
            for e in effect
        ):
            events.extend(self._fill(actor, "magic", self.growth["spell_per_row"] * max(1, row)
                                     * self._teaches(actor, "magic", spell)))
        if move.get("signature"):
            return self._finish_tech(events)
        return self._finish_player_turn(events, "move")

    def submit_noni(self, target_id: str) -> list[Any]:
        """Resolve putting on, or handing over, a Noni."""
        actor = self._require_player_actor()
        if self.noni <= 0:
            return []
        self.noni -= 1
        target = self._item_target(target_id)
        events: list[Any] = [
            NoniUsedEvent(
                actor.id, actor.name, target.id, target.name, self.noni,
                thrown=not target.is_party,
            )
        ]
        events.extend(self._heal(target, BattleSettings.NONI_HEAL_AMOUNT))
        return self._finish_player_turn(events, "item")

    def submit_bag_heal(self, item_name: str, amount: int, target_id: str, food: bool = False) -> list[Any]:
        """Give an ally something from the bag that heals, a dish from Kailo's pot.

        The bag is the party's, so the scene spends the item (Frankie, 10/22).
        """
        actor = self._require_player_actor()
        target = self._item_target(target_id)
        events: list[Any] = [self._item_note(actor, target, item_name, food)]
        events.extend(self._heal(target, amount))
        return self._finish_player_turn(events, "item")

    def submit_bag_sick(self, item_name: str, target_id: str, food: bool = True) -> list[Any]:
        """Give an ally something that makes them sick (Frankie, 11/2: ???, raw pork, raw fish for
        most): it heals nothing and poisons them, sure to take hold."""
        actor = self._require_player_actor()
        target = self._item_target(target_id)
        events: list[Any] = [self._item_note(actor, target, item_name, food),
                             NoteEvent(f"{target.name} feels sick!", target.id)]
        if target.alive and "poison" not in target.statuses:
            target.statuses["poison"] = 1
            events.append(StatusAppliedEvent(target.id, target.name, "poison", True))
        return self._finish_player_turn(events, "item")

    def submit_bag_revive(self, item_name: str, share: float, target_id: str, food: bool = False) -> list[Any]:
        """Raise a fallen ally with an item from the bag (Frankie, 10/30), ``share`` of max HP.

        The bag is the party's, so the scene spends the item, as for a heal.
        """
        actor = self._require_player_actor()
        target = self._item_target(target_id)
        events: list[Any] = [self._item_note(actor, target, item_name, food)]
        events.extend(self._revive(actor, target, share))
        return self._finish_player_turn(events, "item")

    def _item_target(self, target_id: str) -> Combatant:
        """Whoever an item is used on: an ally, fallen or not, or an enemy (Frankie, 11/3)."""
        return self._find(self.party + self.enemies, target_id)

    def _item_note(self, actor: Combatant, target: Combatant, item_name: str, food: bool = False) -> NoteEvent:
        """The line for using an item: eaten or used by the giver, handed to an ally, thrown at an enemy.

        ``food`` is an ingredient or a dish: the giver eats it (Frankie, 11/3).
        """
        if target is actor:
            return NoteEvent(f"{actor.name} {'eats' if food else 'uses'} the {item_name}.", target.id)
        if target.is_party:
            return NoteEvent(f"{actor.name} gives {target.name} the {item_name}.", target.id)
        return NoteEvent(f"{actor.name} throws the {item_name} at {target.name}.", target.id)

    def submit_bag_cure(self, item_name: str, statuses: tuple[str, ...], target_id: str, food: bool = False) -> list[Any]:
        """Give an ally a plant from the bag that cures (Frankie, 10/23): those ailments are gone.

        The bag is the party's, so the scene spends the item, as for a heal.
        """
        actor = self._require_player_actor()
        target = self._item_target(target_id)
        events: list[Any] = [self._item_note(actor, target, item_name, food)]
        if "fatigue" in statuses and target.is_party and target is not actor and target.alive:
            # Coconut Water (Frankie, 11/4): their fatigue is gone, so their turn comes next.
            events.extend(self._rest(actor, [target]))
            return self._finish_player_turn(events, "item")
        cured = [status for status in statuses if target.statuses.pop(status, None) is not None]
        events += [StatusAppliedEvent(target.id, target.name, status, False) for status in cured]
        if not cured:
            events.append(NoteEvent("Nothing happens.", target.id))
        return self._finish_player_turn(events, "item")

    def skill_ease(self, actor: Combatant, skill_id: str, target_id: str | None = None) -> float:
        """How easy ``actor``'s game for ``skill_id`` is (Frankie, 11/1): their stat against the monster's.

        The stat is the Skill's (``MinigameSettings.STAT``). Against one
        enemy, that enemy's; against none or all of them, the average of
        the living ones'.
        """
        stat = MinigameSettings.STAT.get(skill_id)
        if stat is None:
            return 1.0
        foes = [c for c in self.enemies if c.alive]
        aimed = next((c for c in foes if c.id == target_id), None)
        if aimed is not None:
            theirs = aimed.points.get(stat, 0)
        elif foes:
            theirs = sum(c.points.get(stat, 0) for c in foes) / len(foes)
        else:
            return 1.0
        return MinigameSettings.ease(actor.points.get(stat, 0), theirs)

    def cook_share(self, actor: Combatant) -> float:
        """How much more a dish heals cooked in battle by ``actor``'s tool level (Frankie, 11/4):
        the bag's amount at level 1, COOK_TOP_SHARE times it at COOK_TOP_LEVEL, evenly between."""
        top = MinigameSettings.COOK_TOP_LEVEL
        level = min(top, self._mastery_level(actor))
        return 1 + (MinigameSettings.COOK_TOP_SHARE - 1) * (level - 1) / max(1, top - 1)

    def submit_cook(self, dish: str = "fish_stew", quality: float = 1.0,
                    parts: tuple[str, ...] | list[str] = ()) -> list[Any]:
        """Kailo's Cook, his Skill: he cooks ``dish`` in the normal pot for the whole party (Frankie, 11/4).

        The scene opens the pot and takes the ingredients (``parts``, what went in)
        from the bag. It is served at the start of his next turn (``_serve``), and
        a hit before then ruins it (``_deal``, Frankie, 10/25). ``quality`` is how
        steadily the pot was stirred, 0 to 1 (Frankie, 11/1; ``ui/stir_meter.py``):
        a worse stir heals less. Like every Skill it waits 7 and costs 1 to 7 mana
        by its game (``_finish_tech``), here the stir.
        """
        actor = self._require_player_actor()
        actor.dish, actor.dish_parts = dish, tuple(parts)
        actor.dish_quality = max(0.0, min(1.0, quality))
        name = ItemSettings.NAMES.get(dish, dish)
        events: list[Any] = [NoteEvent(f"{actor.name} starts cooking {name}.", actor.id)]
        return self._finish_tech(events, actor.dish_quality)

    def submit_paddle(self, target_id: str, presses: int) -> list[Any]:
        """Kailo's Paddle, his oar Skill (Frankie, 10/31): one hit for each press of A.

        The player mashes A for PADDLE_SECONDS (the scene counts), and each
        press is a hit as hard as a light stroke, dodged as one can be (Frankie,
        11/1 evening), with no more than PADDLE_MOST, growing with oar mastery
        as every stroke does (Frankie, 11/1 evening). If the target falls the
        rest are lost: nothing spills over (Frankie, 10/31). Each landed
        hit trains the oar; a Skill waits 7 and costs 1 to 7 mana by its game (``_finish_tech``).
        """
        actor = self._require_player_actor()
        target = self._find(self.enemies, target_id)
        stroke = BattleSettings.STROKES["light"]
        # It grows with oar mastery as every stroke does, no faster (Frankie, 11/1 evening).
        growth = 1 + self._mastery_damage(actor)
        power = BattleSettings.STROKE_POWER * stroke["power"] * BattleSettings.PADDLE_POWER * growth
        hits = max(0, min(presses, BattleSettings.PADDLE_MOST))
        events: list[Any] = [NoteEvent(f"{actor.name} paddles!", target.id)]
        for _ in range(hits):
            if not target.alive or not actor.alive:
                break
            events.append(StrokeEvent(actor.id, actor.name, target.id, target.name, "Paddle"))
            # Each hit can be dodged, as a light stroke can (Frankie, 11/1, evening).
            hit = self._physical(actor, target, power, None, accuracy=stroke["hit"], stroke=stroke["name"])
            events.extend(hit)
            if any(isinstance(e, DamageEvent) and e.cause == "stroke" for e in hit):
                self._train(actor, "light")
        if not hits:
            events.append(NoteEvent("But nothing lands.", actor.id))
        return self._finish_tech(events, hits / BattleSettings.PADDLE_MOST)

    def submit_banish(self, target_id: str, share: float) -> list[Any]:
        """Hina's Banish, her bow Skill (Frankie, 10/31): one light arrow, drawn and let go.

        The scene runs the draw (``ui/banish_meter.py``): ``share`` is 0 to 1,
        how small the inner circle was when A was let go, and 0 when the time
        ran out with no arrow loosed. The arrow is BANISH_POWER light strokes
        times the share, by her Intelligence, growing with bow mastery as
        every stroke does (Frankie, 11/1 evening). An enemy can dodge it as a light stroke (Frankie,
        11/1 evening), and out of time it misses (Frankie, 10/31). It hits the undead BANISH_UNDEAD
        times as hard, and the light's own weakness rule applies. First it
        cures Hina of every status. A shot trains the bow; a Skill waits 7 and costs 1 to 7 mana by its game (``_finish_tech``).
        """
        actor = self._require_player_actor()
        target = self._find(self.enemies, target_id)
        events: list[Any] = [NoteEvent(f"{actor.name} draws the bow!", target.id)]
        cured = list(actor.statuses)
        actor.statuses.clear()
        events += [StatusAppliedEvent(actor.id, actor.name, status, False) for status in cured]
        growth = 1 + self._mastery_damage(actor)
        power = (BattleSettings.STROKE_POWER * BattleSettings.STROKES["light"]["power"]
                 * BattleSettings.BANISH_POWER * share * growth)
        if target.undead:
            power *= BattleSettings.BANISH_UNDEAD
        if share <= 0:
            # Out of time before a good release: the arrow goes wide (Frankie, 10/31).
            events.append(MissEvent(actor.id, actor.name, target.id, target.name))
        elif self._rng.random() >= self._land_chance(actor, target, BattleSettings.STROKES["light"]["hit"]):
            # The enemy can still dodge the arrow, as a light stroke (Frankie, 11/1 evening).
            events.append(DodgeEvent(actor.id, actor.name, target.id, target.name, "Banish"))
            events.extend(self._gain(target, BattleSettings.DODGE_MANA))
        else:
            events.append(StrokeEvent(actor.id, actor.name, target.id, target.name, "Banish"))
            events.extend(self._magic(actor, target, max(1.0, power), Element.LA))
            self._train(actor, "strong")
        return self._finish_tech(events, share)

    def pound_moves(self, actor: Combatant) -> list[dict[str, Any]]:
        """The Pound moves ``actor`` has learned: one at each handwraps level in POUND_MOVES (Frankie, 10/31)."""
        level = self._mastery_level(actor)
        return [m for m in BattleSettings.POUND_MOVES if m["level"] <= level]

    def submit_pound(self, move_id: str, target_id: str | None, share: float) -> list[Any]:
        """Kailo's Pound, his handwraps Skill (Frankie, 10/31), like Auron's Bushido.

        The scene times the buttons: ``share`` is 1 when the move was finished,
        else the share of its buttons pressed when the time ran out (a wrong
        button starts it over). Each hit is ``power`` light strokes, times the
        share, and always lands (Frankie, 11/1: the minigame decides, not dice); Whisk hits every enemy, Score
        lowers Vitality. Nothing pressed and nothing lands. Mastery teaches
        moves but adds no power. Each landed hit
        trains the handwraps; a Skill waits 7 and costs 1 to 7 mana by its game (``_finish_tech``).
        """
        actor = self._require_player_actor()
        move = next(m for m in BattleSettings.POUND_MOVES if m["id"] == move_id)
        stroke = BattleSettings.STROKES["medium"]
        # Handwraps mastery adds moves, not power (Frankie, 10/31).
        power = BattleSettings.STROKE_POWER * BattleSettings.STROKES["light"]["power"] * move["power"] * share
        if move["target"] == "all":
            targets = [c for c in self.enemies if c.alive]
        else:
            targets = [self._find(self.enemies, target_id)]
        events: list[Any] = [NoteEvent(f"{actor.name}: {move['name']}!", targets[0].id if targets else actor.id)]
        if share <= 0:
            events.append(NoteEvent("But he fumbles it.", actor.id))
            return self._finish_tech(events, share * self._pound_size(move))
        for target in targets:
            for _ in range(move["hits"]):
                if not target.alive or not actor.alive:
                    break
                events.append(StrokeEvent(actor.id, actor.name, target.id, target.name, "Pound"))
                hit = self._physical(actor, target, power, None, stroke=stroke["name"], sure=True)
                events.extend(hit)
                landed = any(isinstance(e, DamageEvent) and e.cause == "stroke" for e in hit)
                if landed:
                    self._train(actor, "medium")
                    if move.get("drop") and target.alive:
                        events.extend(self._drop(target, move["drop"], move["drop_turns"]))
        return self._finish_tech(events, share * self._pound_size(move))

    def dance_moves(self, actor: Combatant) -> list[dict[str, Any]]:
        """The Dance moves ``actor`` has learned: one at each fan level in DANCE_MOVES (Frankie, 10/31)."""
        level = self._mastery_level(actor)
        return [m for m in BattleSettings.DANCE_MOVES if m["level"] <= level]

    def submit_dance(self, move_id: str, target_id: str | None, share: float) -> list[Any]:
        """Hina's Dance, her fan Skill (Frankie, 10/31): Pound's twin for healing.

        The scene times the buttons as it does Pound's: ``share`` is 1 when
        finished, else the share pressed when the time ran out. A move heals
        as a Heal of its ``power`` does, by her Intelligence, times the share,
        one ally or every ally; Twirl first takes off what Cure All does, and
        burns. Fan mastery teaches moves but adds no power. Each move costs its
        share of the longest dance's steps; a Skill waits 7 and costs 1 to 7 mana by its game (``_finish_tech``).
        """
        actor = self._require_player_actor()
        move = next(m for m in BattleSettings.DANCE_MOVES if m["id"] == move_id)
        if move["target"] == "all":
            targets = self._reach(self.party)
        else:
            targets = [self._find(self.party, target_id)]
        events: list[Any] = [NoteEvent(f"{actor.name}: {move['name']}!", actor.id)]
        if share <= 0:
            events.append(NoteEvent("But she stumbles.", actor.id))
            return self._finish_tech(events, share * self._dance_size(move))
        amount = round(move["power"] * offense_scale(actor.points["magic"]) * share)
        for target in targets:
            if move.get("cures"):
                for status in (*_CLEANSABLE, "burn"):
                    if target.statuses.pop(status, None) is not None:
                        events.append(StatusAppliedEvent(target.id, target.name, status, False))
            events.extend(self._heal(target, amount))
        return self._finish_tech(events, share * self._dance_size(move))

    @staticmethod
    def skill_cost(score: float) -> int:
        """What a Skill costs for how well its minigame went (Frankie, 11/1 late): 1 to 7 mana.

        ``score`` is 0 to 1; a perfect game costs the most, a miss still 1.
        """
        most = BattleSettings.SKILL_MANA_MOST
        return max(1, min(most, math.ceil(most * max(0.0, score) - 1e-9)))

    def _skill_roll(self) -> int:
        """How well a monster's Skill goes, 1 to 7, in place of the party's minigame (Frankie, 11/1 late)."""
        return self._rng.randint(1, BattleSettings.SKILL_MANA_MOST)

    @staticmethod
    def can_use_skill(actor: Combatant) -> bool:
        """No Skill while in mana debt (Frankie, 11/1 late): it is built back to 0 first."""
        return actor.mana >= 0

    @property
    def spirit_out(self) -> bool:
        """Tawiri's called spirit is on the party's side, so she cannot Call (Frankie, 11/2)."""
        return any(c.summon_turns for c in self.party)

    @staticmethod
    def _pound_size(move: dict[str, Any]) -> float:
        """A Pound move's share of the longest one's buttons: a short move costs less at its best."""
        longest = max(len(m["input"].split()) for m in BattleSettings.POUND_MOVES)
        return len(move["input"].split()) / longest

    @staticmethod
    def _dance_size(move: dict[str, Any]) -> float:
        """A Dance move's share of the longest dance's steps: Kagura at its best costs 7."""
        steps = MinigameSettings.DANCE_STEPS
        return len(steps.get(move["id"], ())) / max(len(v) for v in steps.values())

    def _pay_skill(self, actor: Combatant, cost: int) -> list[Any]:
        """Pay a Skill's mana, the bank first, then below zero (Frankie, 11/1 evening).

        The red pips on the mana bar show the debt, and the moment mana first drops below
        zero a line says so: out of breath (Frankie, 11/9 and 11/10; it had no message, 11/1 late).
        """
        before = actor.mana
        actor.mana = max(-BattleSettings.SKILL_MANA_MOST, before - cost)
        if actor.mana == before:
            return []
        events: list[Any] = [ManaEvent(actor.id, actor.name, actor.mana - before, actor.mana)]
        if before >= 0 > actor.mana:
            events.append(NoteEvent(f"{actor.name} is out of breath!", actor.id))
        return events

    @staticmethod
    def wili_debt(casts: int) -> int:
        """The mana points ``casts`` Wili casts cost: the first buys one, the second two more, and so on."""
        points = 0
        while points * (points + 1) // 2 < casts:
            points += 1
        return points

    def submit_wili(self, rotations: int) -> list[Any]:
        """Maika's and Tawiri's Wili, their staff Skill (Frankie, 11/1): a weak spirit attack for every turn of the d-pad.

        The scene counts the rotations against WILI_SECONDS. Each casts
        Spin at tier 1 (the magic light stroke) on a random living enemy,
        picked anew each cast, no more than WILI_MOST however fast; if every
        enemy falls the rest are lost. They
        cost mana debt (``wili_debt``): the bank pays first, then mana goes
        below zero, and while it is below zero no element can be cast
        (``can_afford``); the casts set its 1 to 7 mana (``wili_debt``) and it waits 7.
        """
        actor = self._require_player_actor()
        casts = max(0, min(rotations, BattleSettings.WILI_MOST))
        standing = [c for c in self.enemies if c.alive]
        events: list[Any] = [NoteEvent(f"{actor.name} spins the staff!", standing[0].id if standing else actor.id)]
        power = BattleSettings.WILI_POWER
        landed = False
        done = 0
        struck: list[str] = []
        for _ in range(casts):
            standing = [c for c in self.enemies if c.alive]
            if not standing or not actor.alive:
                break
            target = self._rng.choice(standing)
            done += 1
            events.append(StrokeEvent(actor.id, actor.name, target.id, target.name, "Wili"))
            hit = self._magic(actor, target, power, Element.MANA, stroke="Wili")
            events.extend(hit)
            if any(isinstance(e, DamageEvent) and e.amount > 0 for e in hit):
                landed = True
                if target.id not in struck:
                    struck.append(target.id)
        if not casts:
            events.append(NoteEvent("But nothing comes.", actor.id))
        if landed:
            events.extend(self._fill(actor, "magic", self.growth["spell_per_row"]
                                     * self._teaches(actor, "magic", struck)))
        # Only the casts made are paid for: 1 to 7 mana by how many.
        return self._finish_tech(events, cost=self.wili_debt(done))

    def submit_vault(self, target_id: str, share: float = 1.0) -> list[Any]:
        """Maika's Vault, his spear Skill (Frankie, 11/1): Kain's Jump, as a pole vault.

        He vaults out of the fight: no enemy can reach him until his next
        turn, when he lands on ``target_id`` (``_land``). ``share`` is how
        well the jump was timed on Banish's circles (``ui/banish_meter.py``,
        Frankie, 11/1): 1 lands double, never more, less for a worse one,
        and 0 (held too long, or no jump) misses; a Skill waits 7 and costs 1 to 7 mana by its game (``_finish_tech``).
        """
        actor = self._require_player_actor()
        target = self._find(self.enemies, target_id)
        actor.vault_share = max(0.0, min(1.0, share))
        events: list[Any] = [NoteEvent(f"{actor.name} vaults into the air!", actor.id)]
        events = self._finish_tech(events, actor.vault_share)
        # Up only once the jump is done, so a burn flares as he leaves, not while he is out of reach.
        if actor.alive:
            actor.aloft = target.id
        return events

    def _land(self, actor: Combatant) -> list[Any]:
        """Maika comes down: VAULT_POWER full Attacks on the enemy picked, or another if it fell.

        As well as the jump was timed (``vault_share``), by Strength; a jump
        held too long misses (Frankie, 11/1). The landing is his turn and
        waits only as a small action does (Claude's call, 11/1).
        """
        aimed, actor.aloft = actor.aloft, None
        share, actor.vault_share = actor.vault_share, 1.0
        standing = [c for c in self.enemies if c.alive]
        events: list[Any] = []
        if standing:
            target = next((c for c in standing if c.id == aimed), None) or self._rng.choice(standing)
            power = share * BattleSettings.VAULT_POWER * BattleSettings.STROKE_POWER * sum(
                BattleSettings.STROKES[k]["power"] for k in BattleSettings.AUTO_STROKES)
            events.append(NoteEvent(f"{actor.name} comes down on {target.name}!", target.id))
            if share <= 0:
                # The jump was held too long: he lands wide (Frankie, 11/1).
                events.append(MissEvent(actor.id, actor.name, target.id, target.name))
            else:
                events.append(StrokeEvent(actor.id, actor.name, target.id, target.name, "Vault"))
                hit = self._physical(actor, target, max(1.0, power), None, stroke="Vault", sure=True)
                events.extend(hit)
                if any(isinstance(e, DamageEvent) for e in hit):
                    self._train(actor, "strong")
        else:
            events.append(NoteEvent(f"{actor.name} lands.", actor.id))
        events.extend(self._spend(actor, BattleSettings.FATIGUE_OTHER))
        return events

    def _serve(self, actor: Combatant) -> list[Any]:
        """At the start of Kailo's turn everyone standing eats what he cooked, then he acts (Frankie, 11/4).

        Each gets what one from the bag would do. Who will not eat it gets none,
        judged by what really went in, so a laulau made with taro for the pork
        feeds a vegetarian; cooked from nothing, by the dish. What makes them
        sick (???) poisons them; a cure takes its ailments away, Coconut Water
        their fatigue; anything else heals the bag's amount times
        ``cook_share``, less for a worse stir, and what goes past full stays as
        extra HP, up to that much over, for the rest of the fight (Frankie,
        10/25 and 11/4). A heal that takes is a try at Intelligence (D-527).
        """
        dish, parts, quality = actor.dish, actor.dish_parts, actor.dish_quality
        actor.dish, actor.dish_parts = None, ()
        events: list[Any] = [NoteEvent(f"{actor.name} serves {ItemSettings.NAMES.get(dish, dish)}.", actor.id)]
        least = MinigameSettings.STIR_LEAST
        share = ItemSettings.HEALS.get(dish, 0) * self.cook_share(actor) * (least + (1 - least) * quality)
        healed = False
        eaters = []
        for c in self._reach(self.party):
            if diet.refuses(c.id, parts=parts) if parts else diet.refuses(c.id, dish):
                events.append(NoteEvent(f"{c.name}: \"{diet.refusal(c.id)}\"", c.id))
                continue
            if diet.sickens(c.id, dish):
                events.append(NoteEvent(f"{c.name} feels sick!", c.id))
                if c.alive and "poison" not in c.statuses:
                    c.statuses["poison"] = 1
                    events.append(StatusAppliedEvent(c.id, c.name, "poison", True))
                continue
            eaters.append(c)
        if dish in ItemSettings.CURES:
            cures = ItemSettings.CURES[dish]
            if "fatigue" in cures:
                events.extend(self._rest(actor, [c for c in eaters if c is not actor]))
            for c in eaters:
                for status in cures:
                    if c.statuses.pop(status, None) is not None:
                        events.append(StatusAppliedEvent(c.id, c.name, status, False))
            return events
        if share <= 0:
            return events
        amount = max(1, round(share))
        for c in eaters:
            if "burn" in c.statuses:
                events.append(NoteEvent(f"{c.name} is burning and cannot be healed.", c.id))
                continue
            before = c.hp
            c.hp = max(before, min(c.max_hp + amount, c.hp + amount))
            events.append(HealEvent(c.id, c.name, c.hp - before))
            healed = healed or c.hp > before
            if c.hp > c.max_hp:
                events.append(NoteEvent(f"{c.name} is full: {c.hp - c.max_hp} extra HP.", c.id))
        if healed:
            events += self._fill(actor, "magic", self.growth["spell_per_row"] * self._teaches(actor, "magic", []))
        return events

    def _rest(self, actor: Combatant, who: list[Combatant]) -> list[Any]:
        """Take away ``who``'s fatigue: their turns come right after ``actor``'s, in the order they were in (Frankie, 10/29)."""
        events: list[Any] = []
        for i, c in enumerate(sorted(who, key=lambda c: c.counter), 1):
            c.counter = min(c.counter, actor.counter + 0.001 * i)
            events.append(NoteEvent(f"{c.name} is rested.", c.id))
        return events

    def will_chance(self, actor: Combatant, target: Combatant) -> float:
        """How likely Scold or Charm takes hold: the user's Willpower over theirs and the monster's together, kept in bounds."""
        mine, theirs = actor.points["spirit"], target.points["spirit"]
        share = mine / max(1, mine + theirs)
        return min(BattleSettings.WILL_MOST, max(BattleSettings.WILL_LEAST, share))

    def submit_charm(self, target_id: str, rounds: int | None = None) -> list[Any]:
        """Maika's Charm, his Skill (Frankie, 10/25): the charmed status, if it takes hold.

        For CHARM_TURNS of its turns the monster fights for the party
        (``_charmed_turn``). The player plays Simon for it (``ui/simon_meter.py``,
        Frankie, 11/1): ``rounds`` is how many were got right, and the more,
        the likelier it takes hold (``_takes_hold``, Frankie, 11/1 evening);
        when it does, it lasts the full CHARM_TURNS.
        With no ``rounds`` (the autopilot) it is the old Willpower contest
        (``will_chance``); a Skill waits 7 and costs 1 to 7 mana by its game (``_finish_tech``).
        """
        actor = self._require_player_actor()
        target = self._find(self.enemies, target_id)
        events: list[Any] = [NoteEvent(f"{actor.name} turns on the charm at {target.name}.", target.id)]
        # Bosses cannot be charmed (Frankie, 10/25).
        if target.boss:
            events.append(NoteEvent(f"{target.name} cannot be charmed.", target.id))
        elif "charmed" in target.immune or not (
                self._takes_hold(rounds, MinigameSettings.SIMON_ROUNDS)
                if rounds is not None else self._rng.random() < self.will_chance(actor, target)):
            events.append(StatusResistedEvent(target.id, target.name, "charmed", "charmed" in target.immune))
        else:
            target.statuses["charmed"] = BattleSettings.CHARM_TURNS
            events.append(StatusAppliedEvent(target.id, target.name, "charmed", True))
        return self._finish_tech(events, 1.0 if rounds is None else rounds / MinigameSettings.SIMON_ROUNDS)

    def _takes_hold(self, done: float, full: float) -> bool:
        """Whether Scold or Charm takes hold: the game alone decides, no roll (Frankie, 11/3).

        It takes hold when at least HOLD_SHARE of the game was got right.
        Willpower, the user's against the enemy's, already set how hard the
        game was. It was a roll up to WILL_MOST, 11/1 evening.
        """
        return done / max(1, full) >= MinigameSettings.HOLD_SHARE

    def submit_scold(self, target_id: str, presses: int | None = None, needed: int | None = None) -> list[Any]:
        """Hina's Scold, her Skill (Frankie, 10/25): the monster sulks, if it takes hold.

        For now it only sets the monster sulking for SULK_TURNS of its turns
        (a rework comes later). The player mashes A for it (Frankie, 11/1):
        the more of the ``needed`` presses, the likelier it takes hold
        (``_takes_hold``, Frankie, 11/1 evening); a sulk is always SULK_TURNS. With no ``presses``
        (the autopilot) it takes hold by Willpower (``will_chance``).
        A monster sulking, or that just stopped, shrugs it off, so none can be
        kept sulking (Frankie, 10/24), and a sleeping one does not hear it (Frankie, 11/15); a Skill waits 7 and costs 1 to 7 mana by its game (``_finish_tech``).
        """
        actor = self._require_player_actor()
        target = self._find(self.enemies, target_id)
        events: list[Any] = [NoteEvent(f"{actor.name} scolds {target.name}.", target.id)]
        # Bosses do not listen (Frankie, 10/25).
        if target.boss:
            events.append(NoteEvent(f"{target.name} does not listen.", target.id))
        elif "sleep" in target.statuses:
            # A sleeping monster cannot hear her (Frankie, 11/15, after Super Beard Bros. Episode 1
            # scolded a boar into sulking in its sleep; the line is Claude's).
            events.append(NoteEvent(f"{target.name} is asleep and doesn't hear a word.", target.id))
        elif target.id in self._sulked or target.statuses.get("sulk"):
            events.append(NoteEvent(f"{target.name} shrugs it off.", target.id))
        elif not (self._takes_hold(presses, needed or MinigameSettings.SCOLD_PRESSES)
                  if presses is not None else self._rng.random() < self.will_chance(actor, target)):
            events.append(NoteEvent(f"{target.name} ignores her.", target.id))
        else:
            target.statuses["sulk"] = BattleSettings.SULK_TURNS
            events.append(StatusAppliedEvent(target.id, target.name, "sulk", True))
        return self._finish_tech(events, 1.0 if presses is None else presses / (needed or MinigameSettings.SCOLD_PRESSES))

    def submit_seer_shell(self, target_id: str) -> list[Any]:
        """Look at an enemy through a Seer's Shell: its element, HP and mana, as Scan reads them.

        The shell is the bag's, so the scene spends it (Frankie, 10/22). What
        it shows stays up for the rest of the fight (Frankie, 10/28).
        """
        actor = self._require_player_actor()
        target = self._find(self.enemies, target_id)
        target.seen = True
        now = self._stance_now(target)
        element = now.label
        other = next((e for e, _ in target.pools if e is not now), None)
        if other is not None:
            # Both its stances, as the reading draws them (Frankie, 11/4).
            element = f"{element} and {other.label}, in {element} now"
        events: list[Any] = [
            NoteEvent(f"{actor.name} looks through the Seer's Shell.", target.id),
            NoteEvent(f"{target.name}: {element}.", target.id),
            NoteEvent(f"HP {target.hp}/{target.max_hp}, mana {target.mana}.", target.id),
        ]
        return self._finish_player_turn(events, "item")

    def combos_for(self, actor: Combatant) -> list[tuple[dict[str, Any], Combatant]]:
        """Return the combos ``actor`` could start now, each with its partner.

        The partner is the ally whose turn comes right after on the bar,
        and no one else: Kailo, a monster, then Hina cannot team up
        (Frankie, 11/2; Defend no longer readies a partner). Each brings
        the element of the stance they are in (D-259). Mana is not
        checked here; ``can_pay_combo`` says whether both have it.
        """
        upcoming = self.upcoming(1, self._fatigue("combo"))
        partners = [upcoming[0]] if upcoming and upcoming[0].is_party else []
        found: list[tuple[dict[str, Any], Combatant]] = []
        for partner in partners:
            if partner is actor or not partner.alive or partner.aloft or "sleep" in partner.statuses:
                continue
            for combo in self._combos.values():
                if self._combo_roles(combo, actor, partner) is not None:
                    found.append((combo, partner))
        return found

    def partner_without_combo(self, actor: Combatant) -> Combatant | None:
        """The ally whose turn comes right after ``actor``'s when their stances make no Team Up the
        game can play, or None (Frankie, 11/4: the greyed Team Up says why)."""
        upcoming = self.upcoming(1, self._fatigue("combo"))
        partner = upcoming[0] if upcoming and upcoming[0].is_party else None
        if (partner is None or partner is actor or not partner.alive or partner.aloft
                or "sleep" in partner.statuses):
            return None
        return None if any(self._combo_roles(c, actor, partner) for c in self._combos.values()) else partner

    def can_pay_combo(self, actor: Combatant, partner: Combatant) -> bool:
        """Return True when both partners have the mana a combo takes."""
        need = BattleSettings.COMBO_MANA
        return actor.mana >= need and partner.mana >= need

    @staticmethod
    def _combo_roles(
        combo: dict[str, Any], actor: Combatant, partner: Combatant
    ) -> dict[str, Combatant] | None:
        """Return who brings each of ``combo``'s elements, or None if they cannot."""
        x, y = combo["elements"]
        mine = actor.stance_element.value if actor.stance_element else None
        theirs = partner.stance_element.value if partner.stance_element else None
        if (mine, theirs) == (x, y):
            return {x: actor, y: partner}
        if (mine, theirs) == (y, x):
            return {y: actor, x: partner}
        return None

    def submit_combo(
        self, combo_id: str, partner_id: str, target_id: str | None = None, quality: float = 1.0
    ) -> list[Any]:
        """Strike together with the next ally on the bar. Both pay all 7 mana and take 7 fatigue.

        ``quality`` multiplies the hit by how its minigame went: Pōhuehue's (Frankie, 11/3).
        """
        actor = self._require_player_actor()
        combo = self._combos[combo_id]
        partner = self._find(self.party, partner_id)
        roles = self._combo_roles(combo, actor, partner)
        if roles is None:
            raise ValueError(f"{actor.id} and {partner_id} cannot do {combo_id}")
        if not self.can_pay_combo(actor, partner):
            raise ValueError(f"{combo_id} needs more mana")
        events: list[Any] = [ComboUsedEvent(
            actor.id, actor.name, partner.id, partner.name, combo["name"]
        )]
        events.extend(self._pay(actor, BattleSettings.COMBO_MANA))
        events.extend(self._pay(partner, BattleSettings.COMBO_MANA))
        target = self._find(self.enemies, target_id) if target_id else None
        events.extend(self._run_combo(combo, roles, target, quality))
        partner.ready = False
        events.extend(self._spend(partner, BattleSettings.FATIGUE_COMBO))
        return self._finish_player_turn(events, "combo")

    def _run_combo(
        self,
        combo: dict[str, Any],
        roles: dict[str, Combatant],
        target: Combatant | None,
        quality: float = 1.0,
    ) -> list[Any]:
        """Play one combo's effect, as the browser does."""
        power = combo["power"] * quality if "power" in combo else None
        cid = combo["id"]
        events: list[Any] = []
        if cid == "solar_fist":
            return self._physical(roles["afi"], target, power, Element.LA)
        if cid == "vine_whip":
            return self._physical(roles["afi"], target, power, Element.LAU)
        if cid == "eclipse":
            for foe in [c for c in self.enemies if c.alive]:
                events.extend(self._magic(roles["la"], foe, power, Element.LA))
                if foe.alive:
                    events.extend(self._magic(roles["ata"], foe, power, Element.ATA))
                if foe.alive:
                    events.extend(self._inflict(foe, "blind"))
            return events
        if cid == "spring_rain":
            # Spring Rain (Frankie, 11/4): rain over the party for 3 turns. It washes off poison
            # and burns now, heals each a little at the start of each of their turns while it falls,
            # and halves fire damage on them until it stops. ``quality`` is how both games went.
            for friend in [c for c in self.party if c.alive]:
                for status in ("poison", "burn"):
                    if friend.statuses.pop(status, None):
                        events.append(StatusAppliedEvent(friend.id, friend.name, status, False))
                friend.statuses["rain"] = BattleSettings.RAIN_TURNS
                friend.rain_heal = max(1, round(friend.max_hp * combo["heal_rate"] * max(0.5, quality)))
            events.append(NoteEvent("A warm rain falls over the party."))
            return events
        if cid == "light_wave":
            # Light Wave (Frankie, 11/4): water's guard over the whole party, light's touch against
            # magic. For 3 turns magic on them is cut, at best by half, and shadow is cut again.
            # ``quality`` (how both games went, half to full) sets how much is cut.
            for friend in [c for c in self.party if c.alive]:
                friend.statuses["wave"] = BattleSettings.RAIN_TURNS
                friend.wave_keep = 1.0 - 0.5 * max(0.5, min(1.0, quality))
            events.append(NoteEvent("A wave of light settles over the party."))
            return events
        if cid == "daybreak":
            # Dawn burns away Protect, Shell, Regen and Haste, as its description says (Frankie, 11/2).
            for foe in [c for c in self.enemies if c.alive]:
                had = bool(foe.statuses.pop("protect", None)) | bool(foe.statuses.pop("shell", None))
                had = had or foe.regen > 0 or foe.haste > 0
                foe.regen = 0
                foe.haste = 0
                if had:
                    events.append(NoteEvent(f"Dawn burns away {foe.name}'s guard.", foe.id))
                events.extend(self._magic(roles["mana"], foe, power, Element.LA))
            return events
        raise ValueError(f"combo {cid} is not built")

    def submit_swap(self, bench_id: str, out_id: str | None = None) -> list[Any]:
        """Send the one acting to the bench and bring ``bench_id`` in, as the browser does.

        The one coming in takes the same place and clock, and the turn
        is theirs at once. ``out_id`` sends someone else instead, as the
        wake's swap lesson does (Frankie, 10/30): the newcomer takes their
        place and clock, and the turn stays with the one acting.
        """
        actor = self._require_player_actor()
        leaving = actor if out_id is None else self._find(self.party, out_id)
        newcomer = self._find(self.bench, bench_id)
        if not newcomer.alive:
            raise ValueError(f"{bench_id} cannot fight")
        newcomer.counter = leaving.counter
        newcomer.guard = None
        newcomer.defending = False
        newcomer.ready = False
        self.party[self.party.index(leaving)] = newcomer
        self.bench.remove(newcomer)
        self.bench.append(leaving)
        leaving.guard = None
        leaving.defending = False
        leaving.ready = False
        if leaving is actor:
            self._chain = None
            self._current_actor = newcomer
        return [SwapEvent(leaving.id, leaving.name, newcomer.id, newcomer.name)]

    def submit_weapon(self, weapon_name: str, multipliers: dict[str, Fraction] | None = None,
                      weapon_type: str | None = None) -> list[Any]:
        """Change the weapon held: builds 1 mana, 1 fatigue less, ends the turn (D-455).

        ``multipliers`` is what the new weapon does to the stats (core/equipment.py):
        they change at once, the share of HP kept. None leaves the stats alone.
        """
        actor = self._require_player_actor()
        actor.weapon = weapon_name
        actor.weapon_type = weapon_type
        if multipliers is not None:
            actor.multipliers = dict(multipliers)
            actor.take_stance(actor.stance)
        events: list[Any] = [WeaponEvent(actor.id, actor.name, weapon_name)]
        events.extend(self._gain(actor, BattleSettings.WEAPON_MANA))
        return self._finish_player_turn(events, "defend")

    def submit_slot(self, loadout: dict[str, int], move_name: str, banked: bool = False) -> list[Any]:
        """Put an element in a slot in the fight: the one acting takes ``loadout`` (Frankie, 11/11).

        Like Weapon (Frankie, 11/11): it builds 1 mana and ends the turn.
        """
        actor = self._require_player_actor()
        actor.loadout = dict(loadout)
        events: list[Any] = [SlotEvent(actor.id, actor.name, move_name, banked)]
        events.extend(self._gain(actor, BattleSettings.SLOT_MANA))
        return self._finish_player_turn(events, "defend")

    def escape_chance(self) -> float:
        """Return the one acting's chance, 0 to 1, of running away."""
        actor = self._current_actor
        fastest = max(
            (c.points["speed"] for c in self.enemies if c.alive), default=0
        )
        low, high = BattleSettings.ESCAPE_LIMITS
        chance = BattleSettings.ESCAPE_CHANCE + BattleSettings.ESCAPE_PER_SPEED * (
            actor.points["speed"] - fastest
        )
        return max(low, min(high, chance))

    def escape_ease(self) -> float:
        """How easy the escape game is (Frankie, 11/4): the runner's Speed against the fastest foe's."""
        actor = self._current_actor
        fastest = max((c.points["speed"] for c in self.enemies if c.alive), default=0)
        return MinigameSettings.ease(actor.points["speed"], fastest)

    def submit_escape(self, quality: float | None = None) -> list[Any]:
        """Try to run (D-455). A failure builds no mana, costs a Skill's fatigue (7, Frankie, 11/14) and ends the turn.

        ``quality`` is how steady the L R rhythm was, 0 to 1 (``ui/escape_meter.py``,
        Frankie, 11/4): the chance runs from the low limit at 0 to the high one at 1,
        then it is rolled. None rolls ``escape_chance`` from the stats, as before.
        """
        actor = self._require_player_actor()
        if quality is None:
            chance = self.escape_chance()
        else:
            low, high = BattleSettings.ESCAPE_LIMITS
            chance = low + (high - low) * max(0.0, min(1.0, quality))
        escaped = self._rng.random() < chance
        events: list[Any] = [EscapeEvent(actor.id, actor.name, escaped)]
        if escaped:
            return events + self._leave(actor)
        return self._finish_player_turn(events, "escape")

    def submit_smoke_bomb(self) -> list[Any]:
        """Throw a Smoke Bomb (Frankie, 11/12): the whole party gets away at once, no rhythm, no roll.

        The bomb is the bag's, so the scene spends it, as for a shell.
        """
        actor = self._require_player_actor()
        self._chain = None
        self._awaiting_command = False
        events: list[Any] = [NoteEvent(f"{actor.name} throws a Smoke Bomb!", actor.id)]
        events += [EscapeEvent(c.id, c.name, True) for c in self.party if c.alive and not c.summon_turns]
        return events + self._end("flee")

    @property
    def lineup(self) -> list[Combatant]:
        """The party in its order, every runner back in the place they ran from."""
        order = list(self.party)
        for runner in reversed(self.escaped):
            order.insert(min(self._left_at.get(runner.id, len(order)), len(order)), runner)
        return order

    def _leave(self, actor: Combatant) -> list[Any]:
        """``actor`` got away: only they leave the fight (Frankie, 11/11), with the HP they had.

        The rest fight on. When nobody is left standing, the fight ends as an escape, not a
        defeat: whoever was left behind stays knocked out (``_check_terminal``).
        """
        self._chain = None
        self._awaiting_command = False
        actor.guard = None
        actor.defending = False
        actor.ready = False
        if actor in self.party:
            self._left_at[actor.id] = self.party.index(actor)
            self.party.remove(actor)
        self.escaped.append(actor)
        return self._check_terminal()

    def flee(self) -> list[Any]:
        """End the battle by running away."""
        self._awaiting_command = False
        return self._end("flee")

    # ------------------------------------------------------------------
    # MOVE EFFECTS
    # ------------------------------------------------------------------

    def _run_effect(
        self, actor: Combatant, target: Combatant, move: dict[str, Any],
        other: Combatant | None = None,
    ) -> list[Any]:
        """Run one party move and return its events.

        A kit move (``systems/battle_kits.py``) runs its own code; any
        other runs by its ``effect``.
        """
        ran = battle_kits.run(self, actor, target, move, other)
        if ran is not None:
            return ran
        effect = move["effect"]
        element = Element(move["element"])
        statuses = move.get("statuses", [])
        if effect == "physical":
            return self._physical(
                actor, target, move["power"], element, statuses
            )
        if effect == "magic":
            return self._magic(
                actor, target, move["power"], element, statuses,
                extra_turns=move.get("extra_turns", 0),
            )
        if effect == "guard":
            return battle_kits.raise_guard(actor, move["guard"], move)
        if effect == "cure":
            amount = round(
                move["power"] * offense_scale(actor.points["magic"])
            )
            return self._heal(target, amount)
        if effect == "cleanse":
            # Cure (Frankie, 11/4; the numbers are Claude's): it works by chance, rising a row at a time.
            if "chance" in move:
                row = min(7, max(1, self._tier or 1))
                if self._rng.random() >= min(1.0, move["chance"] + move.get("chance_per_row", 0) * (row - 1)):
                    return [CureFailedEvent(target.id, target.name)]
            for status in move.get("statuses", _CLEANSABLE):
                target.statuses.pop(status, None)
            return [CleansedEvent(target.id, target.name)]
        if effect == "ward":
            target.ward = move.get("ward_share", LoadoutSettings.WARD_SHARE)
            return [StatusAppliedEvent(target.id, target.name, "ward", True)]
        if effect == "haste":
            # Its row is how much each turn waits less (Frankie, 11/10).
            battle_kits.haste(target, min(7, max(1, self._tier or 1)))
            return [StatusAppliedEvent(target.id, target.name, "haste", True)]
        if effect == "safeguard":
            target.safe = True
            return [StatusAppliedEvent(target.id, target.name, "safeguard", True)]
        if effect == "regen":
            target.regen = BattleSettings.REGEN_TURNS + move.get("extra_turns", 0)
            return [StatusAppliedEvent(target.id, target.name, "regen", True)]
        if effect == "mana_gift":
            return self._gain(target, int(move.get("gift", 1)))
        if effect == "purify":
            target.statuses.clear()
            events = self._heal(target, target.max_hp)
            target.ward = LoadoutSettings.WARD_SHARE
            events.append(
                StatusAppliedEvent(target.id, target.name, "ward", True)
            )
            return events
        if effect == "revive":
            return self._revive(actor, target, move.get("revive_share", 0.5))
        if effect == "drain":
            # Half the damage comes back to the caster. The browser can
            # give it to an ally instead; that waits.
            before = target.hp
            events = self._magic(actor, target, move["power"], element, statuses)
            dealt = before - target.hp
            if dealt > 0:
                events.extend(self._heal(actor, round(dealt / 2)))
            return events
        raise ValueError(f"move {move['id']} has unknown effect {effect!r}")

    def _revive(self, actor: Combatant, target: Combatant, share: float) -> list[Any]:
        """Bring a fallen ally back with ``share`` of their max HP (D-456).

        Revive brings half, Full Revive all of it.

        As in the browser, they rejoin the order as if they had just used
        a technique: the reviver's counter plus one technique's wait,
        shortened by their own Speed.
        """
        if target.alive:
            # On the undead it is an instant kill, bosses too (Frankie, 11/3); on anyone else standing, nothing.
            if target.undead:
                return [NoteEvent(f"The life in it destroys {target.name}!", target.id)] + \
                    self._deal(target, target.hp, cause="holy")
            return [NoteEvent("Nothing happens.", target.id)]
        target.hp = max(1, round(target.max_hp * share))
        target.statuses.clear()
        target.counter = actor.counter + BattleSettings.FATIGUE_OTHER * defense_scale(
            target.points["speed"]
        )
        return [RevivedEvent(target.id, target.name, target.hp)]

    def _monster_turn(self, monster: Combatant) -> list[Any]:
        """Pick one of ``monster``'s moves by weight and play it.

        Every named move costs its ``tier`` in mana (D-329). A monster
        that cannot pay yet attacks with a chain of strokes instead,
        which builds the mana, so a big move comes once it is paid for.
        """
        if monster.statuses.get("charmed"):
            return self._charmed_turn(monster, *self._pick_move(monster))
        return self._foe_turn(monster, *self._pick_move(monster, own=True))

    def _pick_move(self, monster: Combatant, own: bool = False) -> tuple[dict, int]:
        """One of a monster's moves by weight, and its cost in mana (D-329).

        Its moves are the party's elements it has slotted (Frankie, 11/15), each costing the tier it
        sits in. On its own side (``own``) it may also pick its Skill, out of mana debt only (its cost
        is rolled when it is used, ``_skill_roll``), the item in its bag, Defend, and an ordinary
        two-stance monster the moves of its other stance too, which it changes stance to use
        (Frankie, 10/28). A Skill or an item with no use now is left out. Squeal is never picked: it
        comes when the Great Boar is short of help.
        """
        moves = list(monster.moves)
        if own:
            moves += [m for m in self._other_moves(monster) if m not in moves]
            # Every monster can Defend, as the party does (Frankie, 11/15); not twice running.
            moves.append(self.DEFEND_MOVE)
            skill = monster.skill
            # In mana debt no Skill, as for the party (Frankie, 11/1 late).
            if skill and skill.get("kind") != "call" and skill.get("weight") and monster.mana >= 0 \
                    and self._plays(monster, skill):
                moves.append(skill)
            if monster.bag and self._plays(monster, self.ITEM_MOVE):
                moves.append(self.ITEM_MOVE)
        if monster.defending:
            moves = [m for m in moves if not m.get("defend")] or moves
        if not moves:  # nothing slotted works in this stance (a charmed one): strokes, by Defend's stand-in
            return self.DEFEND_MOVE, 0
        move = self._rng.choices(moves, weights=[self._weight(m) for m in moves])[0]
        return move, self._cost_for(monster, move)

    # Plain Defend as a monster's pick (Frankie, 11/15); its weight is Claude's number.
    DEFEND_MOVE = {
        "name": "Defend", "kind": "support", "defend": True, "weight": BattleSettings.MONSTER_DEFEND_WEIGHT,
    }
    # Using what is in its bag, as a pick; the party's item rules (Frankie, 11/15).
    ITEM_MOVE = {"name": "Item", "kind": "item", "weight": BattleSettings.MONSTER_ITEM_WEIGHT}

    @staticmethod
    def _kind_of(move: dict) -> str:
        """What kind of element ``move`` is, for how often a monster picks it (``MONSTER_PICK_WEIGHTS``)."""
        effect, many = move.get("effect"), move.get("target") == "none"
        statuses = move.get("statuses", ())
        if effect in ("physical", "magic", "drain"):
            if "doom" in statuses:
                return "doom"
            if "possess" in statuses:
                return "possess"
            if statuses:
                return "curse_all" if many else "curse"
            return "hit_all" if many else "hit"
        if effect == "cure":
            return "heal_all" if many else "heal"
        if effect == "cleanse":
            return "cleanse"
        if effect == "guard":
            return "guard"
        if effect in _BUFF_EFFECTS:
            return "buff_all" if many else "buff"
        return "other"

    def _weight(self, move: dict) -> float:
        """How often a monster picks ``move``: its own ``weight`` (Skill, Defend, item) or its kind's."""
        if "weight" in move:
            return move["weight"]
        return BattleSettings.MONSTER_PICK_WEIGHTS[self._kind_of(move)]

    @staticmethod
    def _cost_for(monster: Combatant, move: dict) -> int:
        """A monster move's cost in mana: the tier it sits in, as the party's (Skills, Defend and items cost none)."""
        if "weight" in move:
            return 0
        return monster.loadout[move["id"]]

    @staticmethod
    def _other_moves(monster: Combatant) -> list[dict]:
        """An ordinary two-stance monster's other stance's moves; none for a boss (Frankie, 10/28).

        A monster with reasons of its own to switch (a boss's ``switch``)
        keeps to the stance it is in until a reason moves it.
        """
        if len(monster.pools) < 2 or monster.switch or monster.holds_stance:
            return []
        return list(monster.pools[1 - monster.pool][1])

    def _foe_turn(self, monster: Combatant, move: dict, cost: int) -> list[Any]:
        """A monster's own turn, on its own side (``_monster_turn``)."""
        # Maika up on his Vault is out of reach (Frankie, 11/1).
        living = self._reach(self.party)
        events: list[Any] = []
        if not living and not monster.statuses.get("possess"):
            events.append(NoteEvent(f"{monster.name} looks up, but cannot reach.", monster.id))
            return events + self._spend(monster, BattleSettings.FATIGUE_OTHER)
        # Possess plays as confusion (D-547): for its next turns, half the
        # time the monster turns on its own side, itself if it is alone.
        monster.turned = False
        if monster.statuses.get("possess"):
            turned = self._rng.random() < BattleSettings.POSSESS_CHANCE
            monster.statuses["possess"] -= 1
            if monster.statuses["possess"] <= 0:
                del monster.statuses["possess"]
                if not turned:
                    events.append(StatusAppliedEvent(monster.id, monster.name, "possess", False))
            if turned:
                kin = [c for c in self.enemies if c.alive and c is not monster]
                living = kin or [monster]
                events.append(StatusAppliedEvent(monster.id, monster.name, "turned", True))
                monster.turned = True
        # The move it changed stance for comes now, whatever else has changed (Frankie, 10/28).
        wanted, monster.wanting = monster.wanting, None
        if wanted is not None:
            move, cost = wanted, self._cost_for(monster, wanted)
            monster.in_stance += 1
        # Its Skill first: short of help, the Great Boar squeals for it (Frankie, 10/28).
        elif self._squeals(monster):
            return events + self._squeal(monster)
        # A boss changes stance for a reason (D-601); the switch is its turn.
        elif self._foe_switches(monster):
            return events + self._foe_switch(monster)
        # An ordinary one changes stance when the move it wants is in its other
        # stance, and uses it next turn (Frankie, 10/28); the switch is its turn.
        elif self._needs_switch(monster, move, cost):
            return events + self._switch_for(monster, move)
        else:
            monster.in_stance += 1
        # What costs no mana (Defend, an item) plays even in mana debt, as the party's does.
        if not self._plays(monster, move) or cost > max(0, monster.mana):
            target = self._rng.choice(living)
            # If it wanted a move it could not pay for, it plays it after the strokes once it can,
            # as a hero's turn may (Frankie, 11/15).
            then = (move, cost) if self._plays(monster, move) and (move in monster.moves or move is monster.skill) else None
            if self.timed_blocks and target.is_party and not monster.is_party:
                plan = self._stroke_plan()
                # A guard who steps in is the one on the meter, said once before the bars come
                # (Frankie, 11/2): the whole chain is his.
                guard = self._guard_for(target)
                if guard is not None:
                    if guard is not target:
                        events.append(GuardInterceptEvent(guard.id, guard.name, target.id, target.name))
                    target = guard
                self._pending_block = {
                    "monster": monster, "target": target, "kinds": plan, "swung": 0,
                    "chain": {"target": None, "points": 0, "landed": 0}, "events": [], "streak": 0, "then": then,
                }
                events.append(BlockStartEvent(
                    monster.id, target.id, target.name, tuple(plan),
                    BlockSettings.zone_width(target.points["accuracy"]),
                    BlockSettings.bar_speed(monster.points["speed"]),
                    BlockSettings.perfect_reach(target.points["evasion"]),
                ))
                return events
            return events + self._foe_chain(monster, target, then=then)
        return events + self._play(monster, move, cost, living)

    def _plays(self, monster: Combatant, move: dict, allies: list[Combatant] | None = None) -> bool:
        """Return True when ``move`` is one a monster plays at all, whatever it has in mana.

        An element with nothing to do (a heal with everyone whole, a buff already up, an item with no
        one hurt) is skipped: the monster attacks instead. Nobody fallen is raised.
        """
        if move.get("defend"):
            return True
        if move is self.ITEM_MOVE:
            return bool(monster.bag) and not self._idle(monster, {"effect": "cure"}, allies)
        if move is monster.skill:
            return self._skill_ready(monster, move)
        if move.get("target") == "fallen":
            return bool(self._fallen(monster))
        return not self._idle(monster, move, allies)

    def _skill_ready(self, monster: Combatant, skill: dict) -> bool:
        """Return True when the monster's Skill would do something now: a Nap only when hurt, a Truffle with an empty bag."""
        if skill["kind"] == "nap":
            return monster.hp < monster.max_hp and "sleep" not in monster.statuses
        if skill["kind"] == "truffle":
            return monster.bag is None
        return True

    def _play(self, monster: Combatant, move: dict, cost: int, living: list[Combatant], points: int = 0) -> list[Any]:
        """Play a monster's move it can pay for; ``points`` are the stroke points it swung first this turn."""
        if move.get("defend"):
            return self._monster_defend(monster, points)
        if move is self.ITEM_MOVE:
            return self._monster_item(monster, points)
        if move is monster.skill:
            return self._play_skill(monster, move, cost, points)
        return self._play_element(monster, move, cost, living, points)

    def _fallen(self, monster: Combatant) -> list[Combatant]:
        """The fallen on ``monster``'s side who could be raised: down, not run off."""
        mine = self.party if battle_kits.party_side(self, monster) else self.enemies
        return [c for c in mine if not c.alive and not c.gone and c is not monster]

    def _camp(self, monster: Combatant) -> tuple[list[Combatant], list[Combatant]]:
        """The living fighters on ``monster``'s side and on the other, out of reach ones left out."""
        mine = battle_kits.party_side(self, monster)
        return (self._reach(self.party if mine else self.enemies),
                [c for c in self._reach(self.enemies if mine else self.party) if c is not monster])

    def _play_element(self, monster: Combatant, move: dict, cost: int, living: list[Combatant],
                      points: int = 0, allies: list[Combatant] | None = None) -> list[Any]:
        """Play one of the party's elements a monster has slotted, by the same code the party's runs (Frankie, 11/15).

        The move plays from the tier it sits in (``grown``) and costs it; its stats decide what it does as
        a character's do. The monster only chooses its target: a hit or a curse at one of ``living``, a
        heal or buff at the ally who needs it most.
        """
        row = monster.loadout[move["id"]]
        played = grown(move, row)
        # Angry, it hits harder: angry only raises his strength (Frankie, 11/12; the number is Claude's).
        if monster.angry and monster.angry_rule and played["effect"] in ("physical", "magic") and played.get("power"):
            played = {**played, "power": played["power"] * monster.angry_rule.get("power", 1)}
        allies = self._camp(monster)[0] if allies is None else allies
        target = self._pick_target(monster, played, allies, living)
        aimed = None if target is monster or move["target"] == "none" else target.name
        events: list[Any] = [AbilityUsedEvent(monster.id, monster.name, move["id"], move["name"], aimed)]
        monster.casts.add(move["id"])
        self._tier = row
        events.extend(self._run_effect(monster, target, played))
        events.extend(self._end_move(monster, move, cost, points=points))
        return events

    def _pick_target(self, monster: Combatant, move: dict, allies: list[Combatant], foes: list[Combatant]) -> Combatant:
        """Who a monster aims ``move`` at: the same choice the AI always made, from the party's targets.

        A hit or curse goes at a random foe, one the curse is not already on if there is one; a heal at
        the most hurt ally (a boss's helpers heal the boss first, the undead are never healed); a buff at
        the most hurt who lacks it. A move with no target names the monster itself.
        """
        if move["target"] == "none":
            return monster
        if move["target"] == "fallen":
            return self._rng.choice(self._fallen(monster))
        if move["target"] != "ally":
            statuses = move.get("statuses", ())
            fresh = [c for c in foes if not any(s in c.statuses for s in statuses)] if statuses else foes
            return self._rng.choice(fresh or foes)
        pool = allies or [monster]
        if move["effect"] == "cure":
            # A healer knows better than to heal the undead (Frankie, 11/3: healing hurts them).
            pool = [c for c in pool if not c.undead] or pool
            # A boss's helpers heal the boss first, the most hurt only once it is whole (Frankie, 11/15).
            if not monster.boss:
                pool = [c for c in pool if c.boss and c.hp < c.max_hp] or pool
        elif move["effect"] == "cleanse":
            pool = [c for c in pool if self._sick(c)] or pool
        elif move["effect"] in _BUFF_EFFECTS:
            # A buff goes to one who lacks it, the most hurt of those (Frankie, 11/2).
            pool = [c for c in pool if not self._has_buff(c, move)] or pool
        return min(pool, key=lambda c: c.hp / c.max_hp)

    @staticmethod
    def _sick(c: Combatant) -> bool:
        """Return True when ``c`` has blind, sleep or poison on it."""
        return any(s in c.statuses for s in _CLEANSABLE)

    @staticmethod
    def _has_buff(c: Combatant, move: dict) -> bool:
        """Return True when ``c`` already has what buff ``move`` would give up."""
        effect = move["effect"]
        if effect == "haste":
            return c.haste > 0
        if effect == "regen":
            return c.regen > 0
        if effect == "ward":
            return c.ward > 0
        if effect == "safeguard":
            return c.safe
        if effect == "auto_life":
            return "perennial" in c.statuses
        return effect in c.statuses  # protect, shell

    def _idle(self, monster: Combatant, move: dict, allies: list[Combatant] | None = None) -> bool:
        """Return True for a caring element with nothing to do: everyone whole and well, its buff already up.

        A buff already up is not cast again (the Aghoy recast Haste on itself, Frankie, 11/2); a heal is
        not wasted on the undead, who it hurts, or when everyone is whole.
        """
        effect = move.get("effect")
        if effect not in ("cure", "cleanse") and effect not in _BUFF_EFFECTS:
            return False
        kin = self._camp(monster)[0] if allies is None else self._reach(allies)
        if effect == "cure":
            kin = [c for c in kin if not c.undead] or kin
            return all(c.hp >= c.max_hp for c in kin)
        if effect == "cleanse":
            return not any(self._sick(c) for c in kin)
        return all(self._has_buff(c, move) for c in kin)

    def _play_skill(self, monster: Combatant, skill: dict, cost: int, points: int = 0) -> list[Any]:
        """Play a monster's Skill, the one thing it does that no element does (Frankie, 11/15).

        A monster plays no minigame, so it rolls how well its Skill goes, 1 to 7, and pays that in mana,
        as the party pays for its game (Frankie, 11/1 late). Truffle digs up an item into its bag; Nap
        puts it to sleep, recovering a share of its HP each turn it sleeps. Squeal is ``_squeal``.
        """
        name = skill["name"]
        events: list[Any] = [AbilityUsedEvent(monster.id, monster.name, name.lower().replace(" ", "_"), name, None)]
        if skill["kind"] == "truffle":
            monster.bag = skill.get("item", "truffle")
            events.append(NoteEvent(f"{monster.name} digs up a {BattleSettings.MONSTER_ITEMS[monster.bag]['name'].lower()}.",
                                    monster.id))
        elif skill["kind"] == "nap":
            monster.statuses["sleep"] = skill.get("turns", BattleSettings.SLEEP_TURNS)
            monster.guard = None
            monster.napping = skill["heal"]
            events.append(NoteEvent(f"{monster.name} curls up.", monster.id))
            events.append(StatusAppliedEvent(monster.id, monster.name, "sleep", True))
        events.extend(self._end_move(monster, skill, cost, self._skill_roll(), points))
        return events

    def _monster_item(self, monster: Combatant, points: int = 0) -> list[Any]:
        """A monster uses the item in its bag on an ally, itself included, by the party's item rules (Frankie, 11/15).

        Using an item builds a mana and waits as the party's item turn does; the item is gone. A truffle
        heals like a Noni (``MONSTER_ITEMS``). It never uses the one it dug up on the same turn: digging
        is its turn. The undead are never given one, and a boss's helpers give it to the boss first.
        """
        item = BattleSettings.MONSTER_ITEMS[monster.bag]
        allies = self._camp(monster)[0]
        target = self._pick_target(monster, {"target": "ally", "effect": "cure"}, allies, [])
        monster.bag = None
        events: list[Any] = [self._item_note(monster, target, item["name"].lower(), food=True)]
        events.extend(self._heal(target, item["heal"]))
        events.extend(self._gain(monster, BattleSettings.ITEM_MANA))
        events.extend(self._spend(monster, self._fatigue("item", points)))
        return events

    def _stroke_plan(self) -> list[str]:
        """The strokes a monster's chain swings, in order: what fits in the points."""
        kinds: list[str] = []
        points = 0
        for kind in BattleSettings.AUTO_STROKES:
            points += BattleSettings.STROKES[kind]["points"]
            if points > BattleSettings.STROKE_POINTS:
                break
            kinds.append(kind)
        return kinds

    def _foe_chain(self, monster: Combatant, target: Combatant,
                   blocks: list[str] | None = None, then: tuple[dict, int] | None = None) -> list[Any]:
        """A monster's chain of plain strokes at ``target``, ``blocks`` being the player's catches."""
        chain = {"target": None, "points": 0, "landed": 0}
        events = self._auto_strokes(monster, target, chain, blocks)
        return events + self._chain_end(monster, chain, events, then)

    def _chain_end(self, monster: Combatant, chain: dict[str, Any], events: list[Any],
                   then: tuple[dict, int] | None = None) -> list[Any]:
        """The line that sums up a monster's chain, and the wait it costs, given the chain's ``events``.

        ``then`` is the move it wanted: if the strokes built the mana to pay for it, it plays it now,
        and the turn waits the strokes' points plus the move's wait, as a hero's does (Frankie, 11/15).
        """
        struck = {e.target_name for e in events if isinstance(e, StrokeEvent)}
        ended: list[Any] = [ChainEndedEvent(
            monster.id, monster.name,
            struck.pop() if len(struck) == 1 else None,
            sum(e.amount for e in events
                if isinstance(e, DamageEvent) and e.cause == "stroke"),
            fell=not monster.alive,
        )]
        living = self._reach(self.party)
        if then is not None and monster.alive and living and self._plays(monster, then[0]) \
                and then[1] <= monster.mana:
            return ended + self._play(monster, then[0], then[1], living, chain["points"])
        ended.extend(self._spend(monster, max(
            BattleSettings.FATIGUE_LEAST,
            chain["points"] * BattleSettings.STROKE_WAIT,
        )))
        return ended

    def _charmed_turn(self, monster: Combatant, move: dict, cost: int) -> list[Any]:
        """A charmed monster's turn (Maika's Charm, Frankie 10/25): it fights for the party.

        It plays as an ally (``_ally_turn``) against its own side; alone, it
        does nothing. It does not change stance while charmed. The last
        charmed turn ends with it snapping out of it.
        """
        monster.statuses["charmed"] -= 1
        monster.wanting = None
        events = self._ally_turn(monster, move, cost, [c for c in self.enemies if c.alive and c is not monster])
        if monster.statuses.get("charmed", 0) <= 0:
            monster.statuses.pop("charmed", None)
            events.append(StatusAppliedEvent(monster.id, monster.name, "charmed", False))
        return events

    def submit_call(self, quality: float = 1.0) -> list[Any]:
        """Tawiri's Call, her Skill (Frankie, 10/25): a spirit joins the party for CALL_TURNS of its turns.

        It is the monster ``tawiri_spirit`` on the party's side, by the
        monsters' rules (``_summon_turn``), with CALL_HP of her max HP and
        CALL_STATS of her points, the spirit element; enemies may hit it.
        One spirit at a time (Frankie, 11/2): while one is out, Call is
        refused (``spirit_out``, greyed in the menu) until it fades or falls.
        ``quality`` is how tight
        the rhythm was, 0 to 1 (``ui/rhythm_meter.py``, Frankie, 11/1): the
        spirit is at its best at 1 and weaker for a worse rhythm, never
        failing (CALL_LEAST of its best at 0); a Skill waits 7 and costs 1 to 7 mana by its game (``_finish_tech``).
        """
        actor = self._require_player_actor()
        if self.spirit_out:
            return [NoteEvent(f"{actor.name}'s spirit is still out.", actor.id)]
        least = MinigameSettings.CALL_LEAST
        strength = least + (1 - least) * max(0.0, min(1.0, quality))
        events: list[Any] = [NoteEvent(f"{actor.name} calls one of the dead to fight beside her.", actor.id)]
        kind = SHARED_MONSTERS["tawiri_spirit"]
        spirit = Combatant(
            combatant_id="tawiri_spirit", name=kind["name"], elements=(Element.MANA,), is_party=True,
            max_hp=max(1, round(actor.max_hp * BattleSettings.CALL_HP * strength)),
            immune=kind.get("immune", ()), stances=[{"name": kind["name"], "element": "mana"}], kind="tawiri_spirit",
        )
        spirit.carry, spirit.slot_count = list(kind["pool"]), kind["slots"]
        self.arm(spirit)
        spirit.points = {k: max(1, round(v * BattleSettings.CALL_STATS * strength)) for k, v in actor.points.items()}
        spirit.max_hp = spirit.hp = max(1, round(actor.max_hp * BattleSettings.CALL_HP * strength))
        spirit.summon_turns = BattleSettings.CALL_TURNS
        # It acts next, ahead of everyone.
        spirit.counter = min(c.counter for c in self.party + self.enemies if c.alive) - 0.01
        self.party.append(spirit)
        events.append(SummonEvent(spirit.id, spirit.name, True))
        return self._finish_tech(events, quality)

    def submit_moepapa(self, share: float) -> list[Any]:
        """Tawiri's Moepapa, her wand Skill (Frankie, 10/31): every enemy sleeps, and nothing wakes them early.

        Every enemy but a boss sleeps MOEPAPA_TURNS of its turns, even beside
        a boss (Frankie, 10/31); no hit wakes them (``deep``). ``share`` is
        the tap on the shrinking circle, 0 to 1, one shot (``ui/banish_meter.py``,
        Frankie, 11/1): the smaller the circle, the worse the nightmares, up
        to MOEPAPA_NIGHTMARE of the sleeper's max HP in shadow each turn
        asleep, and a miss (0) leaves them only asleep (Claude's reading,
        11/1). Nothing is rolled; a Skill waits 7 and costs 1 to 7 mana by its game (``_finish_tech``).
        """
        actor = self._require_player_actor()
        share = max(0.0, min(1.0, share))
        events: list[Any] = [NoteEvent(f"{actor.name} lays a curse of sleep!", actor.id)]
        for foe in [c for c in self.enemies if c.alive]:
            if foe.boss:
                events.append(NoteEvent(f"{foe.name} cannot be put to sleep.", foe.id))
                continue
            if "sleep" in foe.immune:
                events.append(StatusResistedEvent(foe.id, foe.name, "sleep", True))
                continue
            foe.statuses["sleep"] = MinigameSettings.MOEPAPA_TURNS
            foe.statuses["deep"] = 1
            foe.guard = None
            foe.statuses.pop("nightmare", None)
            if share > 0:
                foe.statuses["nightmare"] = max(1, round(foe.max_hp * MinigameSettings.MOEPAPA_NIGHTMARE * share))
            events.append(StatusAppliedEvent(foe.id, foe.name, "sleep", True))
        if share > 0:
            events.append(NoteEvent("Nightmares take hold." if share >= 0.5 else "Bad dreams creep in.", actor.id))
        return self._finish_tech(events, share)

    def _summon_turn(self, spirit: Combatant) -> list[Any]:
        """Tawiri's spirit's turn: a monster's move by weight, played as an ally, then a turn less."""
        move, cost = self._pick_move(spirit)
        events = self._ally_turn(spirit, move, cost, [c for c in self.enemies if c.alive])
        spirit.summon_turns -= 1
        if spirit.summon_turns <= 0 and spirit in self.party:
            events += self._dismiss(spirit)
        return events

    def _dismiss(self, spirit: Combatant) -> list[Any]:
        """Tawiri's spirit fades: out of the fight and off the party's rows."""
        if spirit in self.party:
            self.party.remove(spirit)
        spirit.hp, spirit.gone, spirit.summon_turns = 0, True, 0
        return [NoteEvent(f"The {spirit.name.lower()} fades away.", spirit.id), SummonEvent(spirit.id, spirit.name, False)]

    def _ally_turn(self, monster: Combatant, move: dict, cost: int, foes: list[Combatant]) -> list[Any]:
        """A monster's turn fought for the party: a charmed one, or Tawiri's spirit.

        An element it can pay for is played by the party's code, a caring one at the party; a move that
        goes at foes needs ``foes``. Anything else is strokes at ``foes``; with no foes it does nothing.
        """
        events: list[Any] = []
        allies = self._reach(self.party)
        offence = not move.get("defend") and self._kind_of(move) in _OFFENCE_KINDS
        if not move.get("defend") and self._plays(monster, move, allies) and cost <= monster.mana \
                and (foes or not offence):
            events += self._play_element(monster, move, cost, foes, allies=allies)
        elif not foes:
            events.append(NoteEvent(f"{monster.name} is charmed and does nothing.", monster.id))
            events.extend(self._spend(monster, BattleSettings.FATIGUE_OTHER, still=True))
        else:
            chain = {"target": None, "points": 0, "landed": 0}
            events += self._auto_strokes(monster, self._rng.choice(foes), chain)
            struck = {e.target_name for e in events if isinstance(e, StrokeEvent)}
            events.append(ChainEndedEvent(
                monster.id, monster.name, struck.pop() if len(struck) == 1 else None,
                sum(e.amount for e in events if isinstance(e, DamageEvent) and e.cause == "stroke")))
            events.extend(self._spend(monster, max(
                BattleSettings.FATIGUE_LEAST, chain["points"] * BattleSettings.STROKE_WAIT)))
        return events

    def _end_move(self, monster: Combatant, move: dict, cost: int, roll: int | None = None,
                  points: int = 0) -> list[Any]:
        """Close a monster's move: pay its mana and wait.

        A monster's Skill pays its roll, 1 to 7, into debt if need be, builds
        nothing, and waits its ``wait``, a Skill's (FATIGUE_TECH), as the
        party's do (Frankie, 10/24, 10/28 and 11/1 late). ``points`` are strokes it swung first
        this turn, which add their wait as the party's do (Frankie, 11/15).
        """
        strokes = points * BattleSettings.STROKE_WAIT
        if move is monster.skill:
            return self._pay_skill(monster, roll or self._skill_roll()) + \
                self._spend(monster, strokes + move.get("wait", BattleSettings.FATIGUE_TECH))
        return self._pay(monster, cost) + self._spend(monster, self._fatigue("move", points))

    @property
    def boars_called(self) -> int:
        """How many monsters a Squeal (or the fight's start) called in all, the beaten and the standing."""
        return self._calls

    def _called(self, monster: Combatant) -> list[Combatant]:
        """The monsters ``monster`` has called to its side that still stand."""
        return [c for c in self.enemies if c.alive and c.caller == monster.id]

    def _squeals(self, monster: Combatant) -> bool:
        """Return True when ``monster`` uses its calling Skill now, Squeal (Frankie, 10/28).

        A monster whose Skill is of kind ``call`` uses it only when no other
        monster stands with it (Frankie, 11/4).
        """
        rule = monster.skill
        if not rule or rule.get("kind") != "call" or monster.statuses.get("charmed"):
            return False
        # In mana debt no Skill (Frankie, 11/1 late).
        if monster.mana < 0:
            return False
        # With ``most`` in the rule (the Great Boar, Frankie 11/12): while fewer than that many of his kind
        # stand with him, and no more than ``cap`` have been called in the whole fight, a squeal per turn he
        # takes it. Without it, only when no other monster stands with him (Frankie, 11/4).
        if "most" in rule:
            if self._calls >= rule.get("cap", 99):
                # All of them called and beaten: one last squeal, which nobody answers, once (Frankie, 11/12).
                return not self._nobody_came and not self._called(monster)
            return len(self._called(monster)) < rule["most"]
        return not any(c.alive and c is not monster for c in self.enemies)

    def _squeal(self, monster: Combatant) -> list[Any]:
        """The Great Boar's Skill, Squeal (Frankie, 10/28): its kind come running to its side.

        ``count`` of the encounter entry ``calls`` join the enemies, never
        past the field's room, lettered by how many it has called this
        fight (Wild Boar A, Wild Boar B), each acting after one ordinary
        wait. They fight as any of their kind do, and run off when their
        caller falls. Like any monster's Skill it rolls how well it goes, 1 to
        7, and pays that in mana, building none (Frankie, 11/1 late). The roll
        does not change how many come, for now: filling the room on a good
        roll dropped the boss sim from 19% to 4% (Claude's call, 11/1 late).
        """
        rule = monster.skill or {}
        name = rule.get("name", "Squeal")
        events: list[Any] = [AbilityUsedEvent(
            monster.id, monster.name, name.lower().replace(" ", "_"), name, None)]
        roll = self._skill_roll()
        count = rule.get("count", 1)
        for called in self._bring(monster, count):
            called.counter = monster.counter + BattleSettings.FATIGUE_OTHER * defense_scale(called.points["speed"])
            events.append(NoteEvent(f"{called.name} comes running!", called.id))
            events.append(SummonEvent(called.id, called.name, True))
        if count and not self._called(monster):
            # Nobody answers: the last squeal, once; after it he fights as any monster does.
            self._nobody_came = True
            events.append(NoteEvent("But nobody came.", monster.id))
        events.extend(self._pay_skill(monster, roll))
        events.extend(self._spend(monster, rule.get("wait", BattleSettings.FATIGUE_TECH)))
        return events

    def _bring(self, monster: Combatant, count: int) -> list[Combatant]:
        """Put up to ``count`` of ``monster``'s Skill's ``calls`` at its side, never past the field's
        room, lettered by how many it has called this fight (Wild Boar A, Wild Boar B)."""
        from core.factories import combatant_from_monster_data  # local: factories imports this module.
        from core.shared import by_id

        rule = monster.skill or {}
        template = next(e for en in by_id("encounters").values() for e in en["enemies"]
                        if e["id"] == rule["calls"])
        kind = SHARED_MONSTERS[template["monster"]]
        base = template["name"].removesuffix(" A")
        if "most" in rule:  # room by the rule: so many at his side at once, so many in the whole fight
            room = min(rule["most"] - len(self._called(monster)), rule.get("cap", 99) - self._calls)
        else:
            room = BattleSettings.FOES - sum(1 for c in self.enemies if c.alive)
        brought = []
        for _ in range(min(room, count)):
            self._calls += 1
            letter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"[(self._calls - 1) % 26]
            entry = dict(template, id=f"{monster.id}_call_{self._calls}", name=f"{base} {letter}")
            called = combatant_from_monster_data(entry, kind)
            called.caller = monster.id
            self.arm(called)
            if len(called.pools) > 1 and not called.boss and self._rng.random() < 0.5:
                self._enter_stance(called, 1)  # a random opening stance, as at the start (Frankie, 11/12)
            self.enemies.append(called)
            brought.append(called)
        return brought

    def _foe_switches(self, monster: Combatant) -> bool:
        """Return True when a two-stance monster leaves its stance now (D-601).

        One reason per stance, from the shared file: "hurt" (HP below a
        share), "mended" (back above one), "struck" (that many physical
        blows since its last turn), "after" (that many turns in the
        stance), "cursed" (that many of the party carry a curse). A
        monster with no reasons switches only for a move it wants
        (``_needs_switch``, Frankie, 10/28; it was at random, D-596).
        """
        struck, monster.struck = monster.struck, 0
        if len(monster.pools) < 2 or not monster.switch:
            return False
        why = monster.switch[monster.pool]
        share = monster.hp / monster.max_hp
        when = why.get("when")
        if when == "hurt":
            return share < why["below"]
        if when == "mended":
            return share >= why["above"]
        if when == "struck":
            return struck >= why["n"]
        if when == "after":
            return monster.in_stance >= why["n"]
        if when == "cursed":
            curses = ("poison", "blind", "sleep", "doom", "possess", "slow")
            cursed = [c for c in self.party if c.alive and any(k in c.statuses for k in curses)]
            return len(cursed) >= why["n"]
        return False

    def _needs_switch(self, monster: Combatant, move: dict, cost: int) -> bool:
        """Return True when an ordinary monster changes stance for ``move`` (Frankie, 10/28).

        The move is in its other stance only, it can pay for it, and it
        would do something (a heal with nothing to mend is not worth a turn).
        """
        if move.get("defend") or move in monster.moves or move not in self._other_moves(monster):
            return False
        if cost > monster.mana:
            return False
        return self._plays(monster, move)

    def _switch_for(self, monster: Combatant, move: dict) -> list[Any]:
        """Change stance to use ``move`` next turn; the stance change is the only warning (Frankie, 11/12)."""
        events = self._foe_switch(monster)
        monster.wanting = move
        return events

    def _foe_switch(self, monster: Combatant) -> list[Any]:
        """Move a monster into its other stance: element, stats and moves change, the turn is spent.

        It builds STANCE_MANA, as a hero's switch does (Frankie, 10/28). The
        StanceEvent is always shown, scanned or not: its words and the effect
        over the monster in the new element's color (ui/battle_stage.py).
        """
        self._enter_stance(monster, 1 - monster.pool)
        element = monster.pools[monster.pool][0]
        events: list[Any] = [StanceEvent(monster.id, monster.name, "", element)]
        events.extend(self._gain(monster, BattleSettings.STANCE_MANA))
        return events + self._spend(monster, BattleSettings.FATIGUE_OTHER)

    def _enter_stance(self, monster: Combatant, index: int) -> None:
        """Put a two-stance monster in stance ``index``: element, stats and moves, no turn spent."""
        # The party's own switch: its two elements and the new stance on top, HP keeping its
        # share, boosts and drops staying on (Frankie, 11/15).
        monster.take_stance(index)
        moves = monster.pools[index][1]
        monster.moves = list(moves)
        monster.in_stance = 0

    def _stroke(
        self,
        attacker: Combatant,
        target: Combatant,
        kind: str,
        chain: dict[str, Any],
        block: str | None = None,
        sure: bool = False,
    ) -> list[Any]:
        """Swing one stroke and keep the chain's count.

        ``block`` is the player's timed block against it: "catch", "perfect" or "miss".

        Each stroke that lands this turn steadies the next one, and
        builds the striker its points in mana.
        """
        stroke = BattleSettings.STROKES[kind]
        power = BattleSettings.STROKE_POWER * stroke["power"] * (1 + self._mastery_damage(attacker))
        events: list[Any] = [
            StrokeEvent(
                attacker.id, attacker.name, target.id, target.name, stroke["name"]
            )
        ]
        land = self.stroke_chance(kind, target) if attacker is self._current_actor else 1.0
        hit = self._physical(
            attacker, target, power, None,
            accuracy=stroke["hit"] + BattleSettings.STROKE_STEADY * chain["landed"] + self._mastery_hit(attacker),
            stroke=stroke["name"], block=None if block == "miss" else block, sure=sure or block is not None,
            metered=block is not None,
        )
        events.extend(hit)
        chain["points"] += stroke["points"]
        if any(isinstance(e, DamageEvent) and e.cause == "stroke" for e in hit):
            chain["landed"] += 1
            events.extend(self._gain(attacker, stroke["points"]))
            if target.is_party == attacker.is_party:
                # No stat or mastery grows from hitting a friend (Frankie, 11/4).
                return events
            self._train(attacker, kind)
            # Strength from strong strokes, Agility from light ones landed
            # in a row, the first of a streak giving nothing, and Perception
            # more the less likely the hit was (D-500, D-521, Frankie, 10/27).
            if kind == "strong":
                events.extend(self._fill(attacker, "strength", self.growth["strong_stroke"]
                                         * self._teaches(attacker, "strength", [target.id])))
            chain["lights"] = chain.get("lights", 0) + 1 if kind == "light" else 0
            if chain["lights"] > 1:
                events.extend(self._fill(attacker, "speed", self.growth["light_streak"]))
            events.extend(self._fill(
                attacker, "accuracy", 100 * self.growth["perception_miss"] * (1 - land)))
        else:
            # A miss breaks a streak of light strokes.
            chain["lights"] = 0
        return events

    def _mastery_level(self, who: Combatant) -> int:
        """The level in the weapon type ``who`` holds: 1 for a monster or a type not trained."""
        if not who.is_party or who.summon_turns or who.weapon_type is None:
            return 1
        return mastery.level_for(who.mastery.get(who.weapon_type, 0))

    def _mastery_hit(self, who: Combatant) -> float:
        """What weapon mastery adds to a stroke's chance to land."""
        return mastery.hit_bonus(self._mastery_level(who))

    def _mastery_damage(self, who: Combatant) -> float:
        """What weapon mastery adds to a stroke's damage, as a share."""
        return mastery.damage_bonus(self._mastery_level(who))

    @staticmethod
    def _train(who: Combatant, kind: str) -> None:
        """A landed ``kind`` stroke earns EXP in the weapon type held (Frankie, 10/30)."""
        if not who.is_party or who.summon_turns or who.weapon_type is None:
            return
        rose = mastery.add(who.mastery, who.weapon_type, MasterySettings.EXP_PER_STROKE[kind])
        if rose:
            who.mastery_ups[who.weapon_type] = rose

    def _auto_strokes(
        self, attacker: Combatant, target: Combatant, chain: dict[str, Any],
        blocks: list[str] | None = None,
    ) -> list[Any]:
        """Swing the light, medium and strong chain, as far as the points go.

        If the target falls, the rest of the chain goes to the weakest
        one standing on its side.
        """
        events: list[Any] = []
        for kind in BattleSettings.AUTO_STROKES:
            points = BattleSettings.STROKES[kind]["points"]
            if chain["points"] + points > BattleSettings.STROKE_POINTS or not attacker.alive:
                break
            if not target.alive:
                side = self.party if target.is_party else self.enemies
                standing = self._reach(side)
                if not standing:
                    break
                target = min(standing, key=lambda c: c.hp)
            swung = sum(1 for e in events if isinstance(e, StrokeEvent))
            block = blocks[swung] if blocks and swung < len(blocks) and blocks[swung] != "miss" else None
            events.extend(self._stroke(attacker, target, kind, chain, block))
        return events

    # ------------------------------------------------------------------
    # DAMAGE AND HEALING
    # ------------------------------------------------------------------

    def _physical(
        self,
        attacker: Combatant,
        target: Combatant,
        power: float,
        element: Element | None,
        statuses: Iterable[str] = (),
        unguardable: bool = False,
        accuracy: float | None = None,
        stroke: str | None = None,
        block: str | None = None,
        sure: bool = False,
        metered: bool = False,
    ) -> list[Any]:
        """Resolve one physical hit, including any guard in the way.

        ``metered`` is a stroke on the block meter: a perfect there is a dodge and
        builds its mana, and a kick back is told by its number alone (Frankie, 11/2).

        ``sure`` is a blow never dodged by chance: a stroke the player met with
        the block meter, where the timing decides and a missed press takes the hit
        (Frankie, 11/1: a miss still showed Dodge), or Vault, a sure hit (Frankie, 11/1).

        ``block`` is a timed block on a stroke (Frankie, 10/30): a "catch"
        takes off more of it the nearer the sweet spot (11/10), on top of Defend, a "perfect" takes it all.

        Any blow can be dodged (Evasion against Accuracy), which builds the
        defender 1 mana. There is no hidden block: the only block is the
        timed one (Frankie, 11/3).
        ``accuracy`` is a stroke's chance to land, None for a sure blow
        (9 for one that cannot be dodged, Hot Pan). A status "ignite" is a
        sure burn. Kailo's Counter Guard answers the hit with a kick.
        """
        if (
            "blind" in attacker.statuses
            and self._rng.random() < BattleSettings.BLIND_MISS_CHANCE
        ):
            return [
                MissEvent(attacker.id, attacker.name, target.id, target.name)
            ]
        events: list[Any] = []
        guard = None if unguardable else self._guard_for(target, element)
        struck = guard or target
        if guard is not None and guard is not target:
            events.append(
                GuardInterceptEvent(
                    guard.id, guard.name, target.id, target.name
                )
            )
        land = 1.0 if sure else self._land_chance(attacker, struck, accuracy)
        if self._rng.random() >= land:
            events.append(DodgeEvent(attacker.id, attacker.name, struck.id, struck.name, stroke))
            events.extend(self._gain(struck, BattleSettings.DODGE_MANA))
            # Luck grows from dodging (D-500), more the likelier the hit was; not from a friend's.
            if struck.is_party != attacker.is_party:
                events.extend(self._fill(struck, "evasion", 100 * self.growth["luck_hit"] * land))
            # Counter answers a dodged blow too (Frankie, 10/28).
            if guard is not None and guard.guard == "counter" and attacker.alive:
                events.extend(self._kick_back(guard, attacker, metered))
            return events
        warded = self._spend_ward(struck, element, events)
        if warded <= 0:
            return events
        if guard is not None:
            multiplier = guard.guard_m or BattleSettings.GUARD_MULTIPLIER
            if element is Element.AFI:
                multiplier *= BattleSettings.GUARD_AFI_MULTIPLIER
            elif element is Element.LAU:
                multiplier *= BattleSettings.GUARD_LAU_MULTIPLIER
        else:
            multiplier = self._weakness(element, struck)
            if struck.defending:
                multiplier *= BattleSettings.DEFEND_MULTIPLIER
        if "protect" in struck.statuses:
            multiplier *= BattleSettings.PROTECT_MULTIPLIER
        amount = self._jitter(
            power
            * multiplier
            * warded
            * offense_scale(attacker.points["strength"])
            * defense_scale(struck.points["vitality"])
            * (BlockSettings.catch_multiplier(self._block_grade) if block == "catch" else 1.0)
            * (0 if block == "perfect" else 1.0)
        )
        # Moepapa's sleep is deep: no hit wakes it (Frankie, 10/31).
        woke = "deep" not in struck.statuses and struck.statuses.pop("sleep", None) is not None
        events.extend(
            self._deal(
                struck, amount, element, multiplier,
                guarded=guard is not None, woke=woke,
                cause="stroke" if stroke else "hit",
                attacker_name=attacker.name, stroke=stroke, timed=block,
            )
        )
        events.extend(self._scald(struck, element, amount))
        if amount > 0 and not struck.is_party:
            struck.struck += 1
        if block == "perfect":
            events.extend(self._gain(struck, BattleSettings.DODGE_MANA))
        # A physical hit knocks a possessing spirit out (D-547).
        if amount > 0 and struck.alive and struck.statuses.pop("possess", None):
            events.append(StatusAppliedEvent(struck.id, struck.name, "spirit_knocked", False))
        # Physical damage snaps a monster out of Maika's Charm, never out of a sulk (Frankie, 10/25).
        if amount > 0 and struck.alive and struck.statuses.pop("charmed", None):
            events.append(StatusAppliedEvent(struck.id, struck.name, "charmed", False))
        for status in statuses:
            if status == "ignite":
                events.extend(self._scald(struck, Element.AFI, amount, chance=1.0))
            else:
                events.extend(self._inflict(struck, status))
        if guard is None or not guard.alive:
            return events
        if guard.guard == "counter" and attacker.alive:
            events.extend(self._kick_back(guard, attacker, metered))
        return events

    def _kick_back(self, guard: Combatant, attacker: Combatant, metered: bool = False) -> list[Any]:
        """Counter's or Dinner Bell's fire kick at the one who struck.

        ``metered`` is a kick on the block meter, told by its number alone (Frankie, 11/2).
        """
        counter_multiplier = self._weakness(Element.AFI, attacker)
        # Counter's kick is a weakened Flame Kick at its row (Frankie, 11/2); Dinner Bell's an Attack.
        power = guard.guard_kick or (counter_kick(home_row(self._moves["counter_guard"])) if guard.guard == "counter"
                                     else BattleSettings.ATTACK_POWER)
        counter = self._jitter(
            power
            * counter_multiplier
            * offense_scale(guard.points["strength"])
            * defense_scale(attacker.points["vitality"])
        )
        return self._deal(
            attacker, counter, Element.AFI, counter_multiplier,
            cause="counter", attacker_id=guard.id, stroke="Counter" if metered else None,
        )

    def _magic(
        self,
        attacker: Combatant,
        target: Combatant,
        power: float,
        element: Element | None,
        statuses: Iterable[str] = (),
        extra_turns: int = 0,
        stroke: str | None = None,
        share: float = 1.0,
    ) -> list[Any]:
        """Resolve one spell. Guards and Defend do nothing against it.

        ``share`` is how often a status takes hold, against the usual: an All curse is weaker on each.

        ``extra_turns`` is what a higher row adds to a sleep (D-319). A
        mind broken by Mental Break takes more. ``stroke`` names a Skill's
        rapid cast (Wili), which the floating numbers tell, not a line.
        """
        events: list[Any] = []
        warded = self._spend_ward(target, element, events) if power else 1.0
        if warded <= 0:
            return events
        if power:
            multiplier = self._weakness(element, target)
            if "shell" in target.statuses:
                multiplier *= BattleSettings.SHELL_MULTIPLIER
            if "mbreak" in target.statuses:
                multiplier *= _COMBO["red_hot_poker"]["break_multiplier"]
            amount = self._jitter(
                power
                * multiplier
                * warded
                * offense_scale(attacker.points["magic"])
                * defense_scale(target.points["spirit"])
            )
            events.extend(
                self._deal(target, amount, element, multiplier, cause="spell", stroke=stroke)
            )
            events.extend(self._scald(target, element, amount))
        for status in statuses:
            events.extend(self._inflict(target, status, extra_turns, share))
        return events

    @staticmethod
    def dealt(events: Iterable[Any], target: Combatant | None = None) -> int:
        """Return the damage in ``events``, on ``target`` alone if given (a move's own hit)."""
        return sum(
            e.amount for e in events
            if isinstance(e, DamageEvent) and e.cause in ("hit", "spell", "stroke")
            and (target is None or e.target_id == target.id)
        )

    def _deal(
        self,
        target: Combatant,
        amount: int,
        element: Element | None = None,
        multiplier: float = NEUTRAL_MULTIPLIER,
        guarded: bool = False,
        woke: bool = False,
        cause: str = "hit",
        blocked: bool = False,
        attacker_name: str | None = None,
        stroke: str | None = None,
        attacker_id: str | None = None,
        timed: str | None = None,
    ) -> list[Any]:
        """Take ``amount`` HP off ``target`` and report it."""
        if not target.alive:
            return []
        # Light Wave cuts magic on whoever it covers, and shadow magic twice (Frankie, 11/4).
        if cause == "spell" and target.statuses.get("wave") and amount > 0:
            keep = getattr(target, "wave_keep", 0.5)
            amount = max(1, round(amount * keep * (keep if element is Element.ATA else 1.0)))
        # Spring Rain halves fire on whoever it falls on (Frankie, 11/4).
        if element is Element.AFI and target.statuses.get("rain") and amount > 0:
            amount = max(1, amount // 2)
        target.hp = max(0, target.hp - amount)
        events: list[Any] = [
            DamageEvent(
                target.id, target.name, amount, element, multiplier,
                guarded, woke, cause, blocked, attacker_name, stroke,
                attacker_id, timed,
            )
        ]
        # Tawiri's spirit knocked out fades at once (Frankie, 10/25).
        if not target.alive and target.summon_turns:
            return events + self._dismiss(target)
        # A hit while Kailo cooks ruins it, not poison or the like (Frankie, 10/25).
        if target.dish and amount > 0 and cause in ("hit", "stroke", "spell"):
            events.append(NoteEvent(f"{target.name}'s {ItemSettings.NAMES.get(target.dish, target.dish)} is ruined!", target.id))
            target.dish = None
        # Hina's Perennial (D-653): the first fall of the fight is not the last.
        rise = target.statuses.pop("perennial", None) if not target.alive else None
        if rise:
            share = rise if isinstance(rise, float) else _MOVE["seed"]["revive_share"]
            target.hp = max(1, round(target.max_hp * share))
            events.append(NoteEvent(
                f"{target.name} falls, and gets back up with {target.hp} HP.", target.id))
            return events
        # Her Seed blooms the first time they are hurt.
        if target.alive and amount > 0 and target.statuses.get("sprout"):
            sprout = target.statuses.pop("sprout")
            events.append(NoteEvent(f"The seed on {target.name} blooms.", target.id))
            events.extend(self._heal(target, sprout))
        if not target.alive:
            for key in list(target.boosts):
                self._unboost(target, key)
            for key in list(target.drops):
                self._undrop(target, key)
            target.died_burning = "burn" in target.statuses
            target.statuses.clear()
            target.guard = None
            target.ward = 0.0
            target.haste = 0
            target.safe = False
            target.regen = 0
            target.spirit = None
            target.cursed_by.clear()
            target.wanting = None
            events.append(CombatantDefeatedEvent(target.id, target.name))
            return events
        # Below a share of its HP the Great Boar gets angry, once (Frankie, 10/28).
        rule = target.angry_rule
        if rule and not target.angry and target.hp < target.max_hp * rule["below"]:
            target.angry = True
            events.append(NoteEvent(f"{target.name} is angry!", target.id))
        # Vitality grows from any damage, Endurance from a physical hit,
        # Willpower from a magic one (D-500), by the share of max HP lost;
        # Vitality, which every hit feeds, at a share of that.
        share = 100 * amount / max(1, target.max_hp)
        actor = self._current_actor
        by_friend = (any(c.id == attacker_id for c in self.party) if attacker_id is not None
                     else actor is not None and actor.is_party and cause in ("hit", "stroke", "spell", "holy"))
        if target.is_party and by_friend:
            return events  # Taking a friend's blow grows nothing either (Frankie, 11/4).
        events.extend(self._fill(target, "hp", share * self.growth["vitality_share"]))
        if cause in ("stroke", "hit", "counter"):
            events.extend(self._fill(target, "vitality", share))
        elif cause == "spell":
            events.extend(self._fill(target, "spirit", share))
        return events

    def _teaches(self, actor: Combatant, key: str, foe_ids: list[str]) -> float:
        """How much of a Strength or Intelligence point ``actor`` earns: weaker enemies teach less (Frankie, 10/28).

        Strength is weighed against the foe's Endurance, Intelligence
        against its Willpower: full against an equal or stronger foe,
        their share below that, never under ``weaker_floor``. Of several
        foes hurt the strongest counts; with none, as for a heal, the
        strongest enemy standing does.
        """
        guard = {"strength": "vitality", "magic": "spirit"}[key]
        foes = [c for c in self.enemies if c.id in foe_ids] or [c for c in self.enemies if c.alive]
        if not foes:
            return 1.0
        best = max(c.points[guard] for c in foes)
        return max(self.growth["weaker_floor"], min(1.0, best / max(1, actor.points[key])))

    def _fill(self, combatant: Combatant, key: str, points: float) -> list[Any]:
        """Put ``points`` in ``combatant``'s hidden meter for stat ``key``; each full meter is +1 (D-498, D-507).

        The meter (Frankie, 10/27, replacing the chance): every stat
        has one, ``meter`` points long, kept between fights and saved;
        what goes past full carries into the next. Only party members
        grow, as often as their meters fill (Frankie, 10/26), never past
        the cap. Tawiri's passive multiplies every point (``step``,
        ``systems/passives.py``). The point goes into the base and every
        multiplier applies again; a Vitality point raises max HP at once.
        """
        if not combatant.is_party or combatant.summon_turns or not combatant.alive or points <= 0:
            return []
        filled = combatant.meters.get(key, 0) + points * self.growth["step"]
        events: list[Any] = []
        while filled >= self.growth["meter"]:
            if StatSettings.BASE_POINTS + combatant.growth.get(key, 0) >= self.growth["cap"]:
                break
            filled -= self.growth["meter"]
            events.append(self._raise(combatant, key))
        combatant.meters[key] = filled
        return events

    def _raise(self, combatant: Combatant, key: str) -> StatGrowthEvent:
        """Raise ``combatant``'s stat ``key`` by 1 now, said at once (D-498, D-526)."""
        combatant.grown[key] = combatant.grown.get(key, 0) + 1
        combatant.growth[key] = combatant.growth.get(key, 0) + 1
        points = stat_points(combatant.elements, combatant.stance_element, combatant.growth,
                             combatant.multipliers)
        combatant.points[key] = points[key] + combatant.boosts.get(key, 0) * (key != "hp")
        if key == "hp":
            combatant.max_hp = max_hp_for(points) + combatant.boosts.get("hp", 0)
        return StatGrowthEvent(combatant.id, combatant.name, key, combatant.points[key])

    def _heal(self, target: Combatant, amount: int) -> list[Any]:
        """Restore up to ``amount`` HP on a living ``target``. A burn stops it (D-312)."""
        if not target.alive:
            return []
        # Healing hurts the undead, as in Final Fantasy (Frankie, 11/3).
        if target.undead and amount > 0:
            return [NoteEvent(f"The healing burns {target.name}!", target.id)] + \
                self._deal(target, amount, cause="holy")
        if "burn" in target.statuses:
            return [NoteEvent(f"{target.name} is burning and cannot be healed.", target.id)]
        before = target.hp
        # A heal never takes away the extra HP a meal left (Kailo's Cook, 10/25).
        target.hp = min(max(target.max_hp, before), target.hp + max(0, amount))
        return [HealEvent(target.id, target.name, target.hp - before)]

    def _spend_ward(self, target: Combatant, element: Element | None, events: list[Any]) -> float:
        """Spend ``target``'s ward on a shadow hit; return the share of the hit left (Frankie, 10/28)."""
        if element is not Element.ATA or not target.ward:
            return 1.0
        share, target.ward = target.ward, 0.0
        events.append(WardBlockedEvent(target.id, target.name, share=share))
        return max(0.0, 1.0 - share)

    def _inflict(self, target: Combatant, status: str, extra_turns: int = 0, share: float = 1.0) -> list[Any]:
        """Try to give ``target`` a status; a sleep slotted higher lasts ``extra_turns`` longer.

        It takes hold ``share`` as often as usual (an All curse, less on each).
        """
        if not target.alive:
            return []
        if status in target.immune:
            return [
                StatusResistedEvent(target.id, target.name, status, True)
            ]
        # Hina's Safeguard stops the next blind, sleep or poison (D-291).
        if status in _CLEANSABLE and target.safe:
            target.safe = False
            return [WardBlockedEvent(target.id, target.name, status)]
        if self._rng.random() > BattleSettings.STATUS_HIT_CHANCE * share:
            return [
                StatusResistedEvent(target.id, target.name, status, False)
            ]
        if status == "sleep":
            target.statuses["sleep"] = BattleSettings.SLEEP_TURNS + extra_turns
            target.guard = None
        elif status == "possess":
            target.statuses["possess"] = BattleSettings.POSSESS_TURNS
        elif status == "doom":
            target.statuses.setdefault("doom", _RULES["doom_turns"])
        elif status == "burn":
            target.statuses["burn"] = _COMBO["scorch"]["burn_turns"]
        else:
            target.statuses[status] = 1
        events: list[Any] = [StatusAppliedEvent(target.id, target.name, status, True)]
        # A status that takes hold on an enemy counts like a hit for whoever
        # cast it, by its chance to fail: Perception (D-521).
        caster = self._current_actor
        if caster is not None and caster.is_party and not target.is_party:
            events.extend(self._fill(
                caster, "accuracy",
                100 * self.growth["perception_miss"] * (1 - BattleSettings.STATUS_HIT_CHANCE)))
        return events

    # ------------------------------------------------------------------
    # STATUSES OVER TIME (the browser's startTurn and spend)
    # ------------------------------------------------------------------

    def _turn_ticks(self, actor: Combatant) -> list[Any]:
        """Run what happens at the top of ``actor``'s turn, in the browser's order.

        Leech Seed drinks, poison bites, Sap drains a mana and burns it,
        Doom counts down; then, if they still stand, Regen heals, Haunt
        bites, Tawiri's called spirit strikes, Bloom heals a little more,
        and the timed statuses and stat boosts count down.
        """
        events: list[Any] = []
        statuses = actor.statuses
        if statuses.get("seed"):
            amount = max(1, round(actor.max_hp * _COMBO["leech_seed"]["seed_rate"]))
            other = self.enemies if actor.is_party else self.party
            drinker = min(self._reach(other), key=lambda c: c.hp / c.max_hp, default=None)
            events.append(NoteEvent(f"The seed drinks {amount} from {actor.name}.", actor.id))
            events.extend(self._deal(actor, amount, cause="seed"))
            if drinker is not None:
                events.extend(self._heal(drinker, amount))
            statuses["seed"] = statuses.get("seed", 1) - 1
            if statuses.get("seed", 0) <= 0:
                statuses.pop("seed", None)
        if "poison" in statuses and actor.alive:
            amount = round(actor.max_hp * actor.poison_rate)
            events.extend(self._deal(actor, amount, cause="poison"))
        if actor.alive and statuses.get("doom"):
            statuses["doom"] -= 1
            if statuses["doom"] <= 0:
                events.append(NoteEvent(f"Doom takes {actor.name}.", actor.id))
                events.extend(self._deal(actor, actor.max_hp, cause="doom"))
            else:
                events.append(NoteEvent(f"Doom: {statuses['doom']} turns left for {actor.name}.", actor.id))
        if not actor.alive:
            return events
        if actor.napping:
            # Nap (Frankie, 11/15): it recovers every turn it sleeps; a hit that wakes it ends it.
            if "sleep" in statuses:
                events.extend(self._heal(actor, round(actor.max_hp * actor.napping)))
            else:
                actor.napping = 0.0
        if statuses.get("wave"):
            statuses["wave"] -= 1
            if statuses["wave"] <= 0:
                statuses.pop("wave", None)
                events.append(NoteEvent(f"The light fades from {actor.name}."))
        if statuses.get("rain"):
            # Spring Rain: a little back at the start of each turn it falls (Frankie, 11/4).
            statuses["rain"] -= 1
            events.extend(self._heal(actor, getattr(actor, "rain_heal", 0) or 1))
            if statuses["rain"] <= 0:
                statuses.pop("rain", None)
                events.append(NoteEvent(f"The rain stops over {actor.name}."))
        if actor.regen > 0:
            actor.regen -= 1
            events.extend(self._heal(
                actor, round(actor.max_hp * BattleSettings.REGEN_RATE)
            ))
        if actor.spirit:
            foes = self._reach(self.enemies if actor.is_party else self.party)
            if foes:
                foe = self._rng.choice(foes)
                events.append(NoteEvent(f"{actor.name}'s spirit strikes {foe.name}.", foe.id))
                events.extend(self._magic(actor, foe, actor.spirit["power"], Element.ATA))
            actor.spirit["left"] -= 1
            if actor.spirit["left"] <= 0:
                actor.spirit = None
        for key in ("protect", "shell") + _COUNTED:
            if key in statuses:
                statuses[key] -= 1
                if statuses[key] <= 0:
                    del statuses[key]
                    if key == "mleech":
                        actor.cursed_by.pop("mleech", None)
        for key in list(actor.boosts):
            name = "up_" + key
            statuses[name] = statuses.get(name, 1) - 1
            if statuses[name] <= 0:
                events.extend(self._unboost(actor, key))
        for key in list(actor.drops):
            name = "dn_" + key
            statuses[name] = statuses.get(name, 1) - 1
            if statuses[name] <= 0:
                events.extend(self._undrop(actor, key))
        return events

    def _burn_tick(self, combatant: Combatant, still: bool) -> list[Any]:
        """Burn (D-312) flares when the burned one moves: any action but Defend, not asleep or held."""
        turns = combatant.statuses.get("burn")
        if not turns or not combatant.alive:
            return []
        events: list[Any] = []
        if not combatant.defending and not still:
            amount = round(combatant.max_hp * combatant.poison_rate)
            events.extend(self._deal(combatant, amount, element=Element.AFI, cause="burn"))
        # A burn lasts until it is cured or the burned one falls, never wearing off
        # (Frankie, 11/4; it lasted 3 turns before).
        return events

    def _scald(self, target: Combatant, element: Element | None, dealt: int,
               chance: float | None = None) -> list[Any]:
        """Any fire hit that does damage may leave a burn (D-312, D-561).

        The chance is the shared file's, more for a move slotted higher;
        ``chance`` 1 is a sure burn ("ignite", Char and Open Flame). No one
        burns while in a fire or water stance, so one with both, as Kailo,
        never burns; a burn taken in another stance stays through a switch
        (Frankie, 11/15).
        """
        if (element is not Element.AFI or not dealt or not target.alive
                or "burn" in target.statuses or self._stance_now(target) in (Element.AFI, Element.WAI)
                or "burn" in target.immune):
            return []
        if chance is None:
            tier = min(7, max(1, self._tier or 1))
            chance = _RULES["fire_burn_chance"] + _RULES.get("fire_burn_per_tier", 0) * (tier - 1)
        if self._rng.random() >= chance:
            return []
        target.statuses["burn"] = _RULES["fire_burn_turns"]
        return [StatusAppliedEvent(target.id, target.name, "burn", True)]

    @staticmethod
    def _stance_now(combatant: Combatant) -> Element | None:
        """The element of the stance ``combatant`` is in: a hero's stance, a monster's pool, else its element."""
        return combatant.stance_element or (combatant.elements[0] if combatant.elements else None)

    def _lose_mana(self, target: Combatant, amount: int) -> tuple[int, list[Any]]:
        """Knock up to ``amount`` mana out of ``target``; return how much and the events."""
        lost = min(amount, max(0, target.mana))
        if not lost:
            return 0, [NoteEvent(f"{target.name} has no mana to lose.", target.id)]
        target.mana -= lost
        return lost, [ManaEvent(target.id, target.name, -lost, target.mana)]

    def _mana_burn(self, caster: Combatant | None, target: Combatant, lost: int,
                   power: float) -> list[Any]:
        """Tawiri's mana burn (D-722): each mana knocked out hurts as spirit damage."""
        if not lost or not target.alive or not power:
            return []
        magic = offense_scale(caster.points["magic"]) if caster is not None else 1.0
        multiplier = self._weakness(Element.MANA, target)
        amount = max(1, round(
            lost * power * magic * defense_scale(target.points["spirit"]) * multiplier))
        events: list[Any] = [NoteEvent(f"The burned mana sears {target.name} for {amount}.", target.id)]
        return events + self._deal(target, amount, Element.MANA, multiplier, cause="mana_burn")

    def _toll(self, actor: Combatant, move: dict[str, Any]) -> list[Any]:
        """Tawiri's biggest spells cost her HP: never below 1."""
        share = move.get("hp_cost")
        if not share:
            return []
        cost = min(actor.hp - 1, round(actor.max_hp * share))
        if cost <= 0:
            return []
        actor.hp -= cost
        return [
            DamageEvent(actor.id, actor.name, cost, None, NEUTRAL_MULTIPLIER, cause="toll"),
            NoteEvent(f"The power takes {cost} HP from {actor.name}.", actor.id),
        ]

    def _roll(self) -> bool:
        """Return True when a status cast by a move takes hold (the shared chance)."""
        return self._rng.random() <= BattleSettings.STATUS_HIT_CHANCE

    def _boost(self, target: Combatant, key: str, turns: int) -> list[Any]:
        """One stat up until the third turn from now (D-716), more turns slotted higher.

        ``key`` is a stat key; "hp" raises max HP (and HP) by a quarter.
        Cast again while it holds, it only lasts longer.
        """
        if not target.alive:
            return []
        if key not in target.boosts:
            if key == "hp":
                added = round(target.max_hp * _BOOST_UP)
                target.max_hp += added
                target.hp += added
            else:
                added = round((StatSettings.BASE_POINTS + target.points[key]) * _BOOST_UP)
                target.points[key] += added
            target.boosts[key] = added
        target.statuses["up_" + key] = turns
        return [StatusAppliedEvent(target.id, target.name, "up_" + key, True)]

    def _unboost(self, target: Combatant, key: str) -> list[Any]:
        """Take a stat boost back off."""
        added = target.boosts.pop(key, 0)
        target.statuses.pop("up_" + key, None)
        if key == "hp":
            target.max_hp -= added
            target.hp = min(target.hp, target.max_hp)
        else:
            target.points[key] -= added
        return [StatusAppliedEvent(target.id, target.name, "up_" + key, False)]

    def _drop(self, target: Combatant, key: str, turns: int) -> list[Any]:
        """One stat down by a fifth of base plus the stat, for ``turns`` (the browser's stat down).

        An enemy may shake it off, at the chance any status has to take
        hold. Cast again while it holds, it only lasts longer.
        """
        if not target.alive:
            return []
        if "dn_" + key in target.immune:
            return [NoteEvent(f"{target.name} shrugs it off.", target.id)]
        # Either side may shake a drop off (Frankie, 11/15: the same rules for both).
        if self._rng.random() > BattleSettings.STATUS_HIT_CHANCE:
            return [NoteEvent(f"{_STAT_WORD[key]} down does not take hold on {target.name}.", target.id)]
        if key not in target.drops:
            taken = round((StatSettings.BASE_POINTS + target.points[key]) * _DROP_DOWN)
            target.points[key] -= taken
            target.drops[key] = taken
        target.statuses["dn_" + key] = turns
        return [StatusAppliedEvent(target.id, target.name, "dn_" + key, True)]

    def _undrop(self, target: Combatant, key: str) -> list[Any]:
        """Give a stat drop back."""
        target.points[key] += target.drops.pop(key, 0)
        target.statuses.pop("dn_" + key, None)
        return [StatusAppliedEvent(target.id, target.name, "dn_" + key, False)]

    def _by_id(self, combatant_id: str | None) -> Combatant | None:
        """Return the fighter with ``combatant_id`` on either side, or None."""
        for combatant in self.party + self.enemies + self.bench:
            if combatant.id == combatant_id:
                return combatant
        return None

    # ------------------------------------------------------------------
    # INTERNALS
    # ------------------------------------------------------------------

    def _land_chance(self, attacker: Combatant, struck: Combatant, accuracy: float | None) -> float:
        """The chance a blow lands, before blindness: its aim plus Accuracy minus Evasion.

        Both ``_physical``'s roll and ``stroke_chance``'s preview read this,
        so the number shown is the number rolled.
        """
        # A sleeper is a sure hit, for either side (Frankie, 11/4, after Mark's Episode 2
        # missed two Strong strokes on a sleeping boar).
        if "sleep" in struck.statuses:
            return 1.0
        return (1.0 if accuracy is None else accuracy) + self._aim(attacker) - self._evade(struck)

    @staticmethod
    def _aim(attacker: Combatant) -> float:
        """Accuracy's share of a blow's chance to land."""
        over = attacker.points["accuracy"] - StatSettings.BASE_POINTS
        return BattleSettings.PER_ACCURACY * over

    @staticmethod
    def _evade(target: Combatant) -> float:
        """The chance ``target`` dodges a sure blow. A sleeper cannot."""
        if "sleep" in target.statuses:
            return 0.0
        over = target.points["evasion"] - StatSettings.BASE_POINTS
        return BattleSettings.EVADE_BASE + BattleSettings.PER_EVASION * over

    def _gain(self, combatant: Combatant, amount: int) -> list[Any]:
        """Build ``amount`` mana, up to the cap.

        Stillness blocks it (no mana builds while it holds), and Mana
        Leech (D-723) sends it to whoever leeches instead.
        """
        if not combatant.alive or amount <= 0:
            return []
        if combatant.statuses.get("calm"):
            return [NoteEvent(f"{combatant.name} is stilled and builds no mana.", combatant.id)]
        if combatant.statuses.get("mleech"):
            leech = self._by_id(combatant.cursed_by.get("mleech"))
            if leech is not None and leech.alive and leech is not combatant:
                return [NoteEvent(
                    f"{leech.name} leeches the mana {combatant.name} builds.", leech.id,
                )] + self._gain(leech, amount)
        before = combatant.mana
        combatant.mana = min(BattleSettings.MANA_CAP, before + amount)
        if combatant.mana == before:
            return []
        return [ManaEvent(
            combatant.id, combatant.name, combatant.mana - before, combatant.mana
        )]

    def _pay(self, combatant: Combatant, amount: int) -> list[Any]:
        """Spend ``amount`` mana."""
        before = combatant.mana
        combatant.mana = max(0, before - amount)
        if combatant.mana == before:
            return []
        return [ManaEvent(
            combatant.id, combatant.name, combatant.mana - before, combatant.mana
        )]

    def _fatigue(self, kind: str, points: int | None = None) -> float:
        """Return the wait the current turn has built (D-328).

        Each stroke its points; "attack" adds nothing more, "defend"
        adds 1 like any other action (Frankie, 10/26), "tech" adds 7 (Frankie, 10/24),
        a failed "escape" adds the same 7 as a Skill (Frankie, 11/14), anything else adds 1.
        """
        if points is None:
            points = self._chain["points"] if self._chain else 0
        strokes = points * BattleSettings.STROKE_WAIT
        if kind == "attack":
            return max(BattleSettings.FATIGUE_LEAST, strokes)
        if kind == "defend":
            return max(
                BattleSettings.FATIGUE_DEFEND_LEAST,
                strokes + BattleSettings.FATIGUE_DEFEND,
            )
        if kind in ("tech", "escape"):
            return strokes + BattleSettings.FATIGUE_TECH
        if kind == "combo":
            return strokes + BattleSettings.FATIGUE_COMBO
        return max(BattleSettings.FATIGUE_LEAST, strokes + BattleSettings.FATIGUE_OTHER)

    def _guard_for(self, target: Combatant, element: Element | None = None) -> Combatant | None:
        """Return the living ally on ``target``'s side whose guard steps in front of a hit.

        The sentinel kinds always do.
        """
        kinds = _SENTINELS
        side = self.party if target.is_party else self.enemies
        for combatant in side:
            if combatant.alive and not combatant.aloft and combatant.guard in kinds:
                return combatant
        return None

    def _weakness(
        self, element: Element | None, target: Combatant
    ) -> float:
        """Return the element multiplier for ``element`` hitting ``target``."""
        if element is None or target.element is None:
            return NEUTRAL_MULTIPLIER
        # A relic adds its element stance's weakness, multiplied (Frankie, 10/24).
        return damage_multiplier(element, target.element) * relic_multiplier(element, target.relic)

    def _jitter(self, amount: float) -> int:
        """Roll ``amount`` within the jitter band and round it."""
        spread = BattleSettings.DAMAGE_JITTER
        roll = 1 - spread + self._rng.random() * 2 * spread
        return int(amount * roll + 0.5)

    def _spend(self, combatant: Combatant, base_wait: float, still: bool = False) -> list[Any]:
        """Push ``combatant``'s counter forward by one action's wait.

        A burn flares first, unless the turn was Defend or ``still`` (lost
        to sleep or a grip). Returns what that did.
        """
        events = self._burn_tick(combatant, still)
        combatant.counter += self._waited(combatant, base_wait)
        return events

    @staticmethod
    def _waited(combatant: Combatant, base_wait: float) -> float:
        """Return what ``base_wait`` really pushes ``combatant``'s counter, for the turn and its preview.

        Haste takes its row off the turn's whole fatigue, never below
        ``FATIGUE_LEAST`` (Frankie, 11/10); then the Great Boar's anger,
        then speed.
        """
        wait = base_wait
        if combatant.haste > 0:
            wait = min(wait, max(BattleSettings.FATIGUE_LEAST, wait - combatant.haste))
        return wait * defense_scale(combatant.points["speed"])

    def _find(self, pool: list[Combatant], combatant_id: str) -> Combatant:
        """Return the combatant with ``combatant_id`` from ``pool``.

        Maika up on his Vault cannot be picked by anyone, harm or healing (Frankie, 11/2).
        """
        for combatant in pool:
            if combatant.id == combatant_id:
                if combatant.aloft:
                    raise ValueError(f"{combatant.name} is out of reach")
                return combatant
        raise KeyError(combatant_id)

    @staticmethod
    def _reach(side: list[Combatant]) -> list[Combatant]:
        """The living on ``side`` that anything can touch: not Maika up on his Vault (Frankie, 11/2)."""
        return [c for c in side if c.alive and not c.aloft]

    def _require_player_actor(self) -> Combatant:
        """Return the party member whose turn is waiting on input."""
        if not self._awaiting_command or self._current_actor is None:
            raise RuntimeError("No party command is awaiting input")
        return self._current_actor

    def _finish_tech(self, events: list[Any], score: float = 1.0, cost: int | None = None) -> list[Any]:
        """Close a Skill's turn: it waits 7 and costs 1 to 7 mana by how well its game went.

        It builds no mana (Frankie, 11/1 late; it built 1). ``score`` is 0
        to 1 (``skill_cost``); ``cost`` pays a set number instead (Wili).
        """
        actor = self._current_actor
        events.extend(self._pay_skill(actor, self.skill_cost(score) if cost is None else cost))
        return self._finish_player_turn(events, "tech")

    def _finish_player_turn(self, events: list[Any], kind: str) -> list[Any]:
        """Charge the turn's fatigue and close it.

        ``kind`` is "attack", "defend", "tech", "escape", "combo", "move" or "item" (``_fatigue``).
        """
        if kind == "item":
            events.extend(self._gain(self._current_actor, BattleSettings.ITEM_MANA))
        events.extend(self._spend(self._current_actor, self._fatigue(kind)))
        self._chain = None
        self._awaiting_command = False
        events.extend(self._check_terminal())
        return events

    def _check_terminal(self) -> list[Any]:
        """End the battle if either side has nobody standing."""
        if not any(c.alive for c in self.enemies):
            return self._end("victory")
        # Tawiri's spirit does not hold the fight up when the party is down.
        # Someone got away: those left behind are knocked out, but it is no game over (Frankie, 11/11).
        if not any(c.alive and not c.summon_turns for c in self.party):
            return self._end("flee" if self.escaped else "defeat")
        return []

    def _end(self, outcome: str) -> list[Any]:
        """Record ``outcome`` once and report it."""
        if self._ended:
            return []
        self._ended = True
        self._outcome = outcome
        return [BattleEndedEvent(outcome)]
