# Game data

This directory holds the JSON content the engine reads at runtime.
Code under `core/`, `systems/`, and `ui/` is generic; everything that
defines specific characters, places, abilities, enemies, dungeons, and
dialogue lives here.

Layer 0 ships an empty tree so the engine can boot. Layer 1 will
populate each subfolder with the real opening content.

## Subfolders

- `characters/` — One JSON per party member: id, display name, two
  elements, base stats, learnset.
- `abilities/` — One JSON per ability: id, name, element, power, cost,
  status effects.
- `enemies/` — One JSON per enemy: id, name, element, stats, loot.
- `dungeons/` — One JSON per region: id, name, room layout, encounter
  table, exits.
- `dialogue/` — One JSON per dialogue tree: id, lines, branches.
- `cells/` — One JSON per room of the map (D-663): its `pos` on the
  world grid, its `grid` of 14 rows of 16 tile characters, the `people`
  standing in it and the `monsters` walking it. Written by the Workshop
  (`../workshop.py`) and read by `core/overworld_cells.py`, which also
  documents the tile alphabet.
- `field_monsters/` — One JSON per monster seen on the map (D-576):
  its picture, the tiles it covers, and its fight, either a fixed one
  (`encounter`, for a boss) or a `lead` that always fights plus
  `companions` who may join it, each an enemy id from the shared
  battle file with a weight. See `entities/field_monster.py`.
- `generated/` — One JSON per generated place (D-731), such as the
  woods: the stretch of the map it fills and what its rooms are made
  of. Built fresh from a seed every new game by `core/generated.py`,
  which documents the fields.
- `shops/` — One JSON per shop: id, name, a greeting, and its stock,
  each an item id and a price in pule; `buys`, the kinds of thing it
  buys (`sell_kind` in `core/scenes/shop_scene.py`; Frankie, 10/28).
- `bounties/` — One JSON per bounty board (the hunters' lodge's): its
  posts, each a monster id, how many, the pule and the prize, and the
  keeper's lines. See `systems/bounties.py`.

Every file in every subfolder must contain a top-level `id` field;
that id is what other content and code references.

## Battle content lives outside this folder, since 2026-10-07

Characters, moves, monsters, encounters and every battle number are in
`../../shared/battle.json`, which the browser game reads too. This game
loads it through `core/shared.py`. See `../../shared/README.md`.

Party stats are not authored anywhere. They are worked out from each
character's two elements by `core/stats.py`.

**`characters/`, `abilities/` and `enemies/` here are no longer read by
this game.** They stay because the browser sandbox in `../../sandbox/`
still reads them.

## Loader

`core/data_loader.py` exposes `DataLoader.load(kind)` which reads
every JSON file in `data/<kind>/` and returns them indexed by id. The
loader caches per-kind, so reloading on a save/load round-trip is
free.
