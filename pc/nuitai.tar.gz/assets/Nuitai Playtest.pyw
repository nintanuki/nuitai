"""Nuitai, the playtest version (Frankie's): the game with the testing tools.

F1 file menu, F2 and F4 save and load a state, ~ fast-forward, F6 checkpoint, F3 layout overlay,
F7 and F8 the hour, and scene select on the title menu. Opens the same game as ``Nuitai.pyw`` (the
player version, none of these tools), with the switch set to playtest. A crash is shown and written
to ``crash.log`` the same way.
"""

import os
import runpy

HERE = os.path.dirname(os.path.abspath(__file__))
os.environ["NUITAI_VERSION"] = "playtest"
runpy.run_path(os.path.join(HERE, "Nuitai.pyw"), run_name="__main__")
