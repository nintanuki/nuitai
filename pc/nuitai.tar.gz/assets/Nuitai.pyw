"""Nuitai, the player version: what the desktop and taskbar shortcut opens.

No testing tools (no F1 file menu, states, fast-forward, checkpoints, scene select). Frankie's
own version, with all of them, is ``Nuitai Playtest.pyw`` beside this file, which sets the
switch to playtest and runs this file. Same game, same ``main.py`` (Frankie, 11/20).

A ``.pyw`` file opens with no console window, so a crash would vanish
without a word. This runs ``main.py`` and, if it fails, writes the error
to ``crash.log`` beside this file and shows it in a message box.
"""

import os
import runpy
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))

# The switch settings.py reads. Already set by the playtest file; otherwise this is the player's.
os.environ.setdefault("NUITAI_VERSION", "player")

try:
    os.chdir(HERE)
    runpy.run_path(os.path.join(HERE, "main.py"), run_name="__main__")
except SystemExit:
    raise
except BaseException:
    error = traceback.format_exc()
    with open(os.path.join(HERE, "crash.log"), "w", encoding="utf-8") as log:
        log.write(f"Python: {sys.executable}\n\n{error}")
    if sys.platform == "win32":
        import ctypes

        ctypes.windll.user32.MessageBoxW(
            None, error[-1500:] + "\n(Saved in crash.log in the game folder.)", "Nuitai crashed", 0x10)
    raise
